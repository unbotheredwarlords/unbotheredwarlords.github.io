-- Inside a dungeon: one line at the compass's place, "For you" (Louis, 22 Nov 2026: "'Hack' as much value as
-- possible to add there via all data our currently installed addons, suites, and kits have"). The game gives addons no
-- position inside, so the compass can't point there. ForeverDungeonJournal already shows the run (its bosses, a tick
-- for each kill, its loot and quests) and the quest tracker shows progress. What nothing in the pack says is which
-- boss matters to you, and why: a drop that is an upgrade for your spec (GearScore.lua), or an open quest of yours that
-- names that boss. So the line lists at most ns.FORYOU_BOSSES bosses not killed this visit, in the journal's order,
-- each with its reason, and shows nothing when none applies. It shows while the compass is on, and has its own
-- setting (compass "inside").
-- ForeverDungeonJournal has no licence: its tables are read live, on the member's own client, as the pick in Lead.lua
-- reads them. Nothing of it is copied, saved or sent. The line's words are the game's own: item names from the client's
-- item data, quest titles from your quest log. Only boss names come from the journal, read as it is drawn. The kills
-- this visit are kept as the game's own encounter numbers and names, per character.
local _, ns = ...

local function g(name) return rawget(_G, name) end
local function call(fn, ...)
  if type(fn) ~= "function" and not (type(fn) == "table" and getmetatable(fn)) then return nil end
  local ok, a, b, c, d = pcall(fn, ...)
  if ok then return a, b, c, d end
end
local function secret(v) return ns.isSecret and ns.isSecret(v) end
local function lower(s) return type(s) == "string" and s:lower() or nil end

ns.FORYOU_BOSSES = 3     -- bosses named on the line, at most
ns.FORYOU_MIN = 5        -- percent: the least gain that names a drop (above the tooltip's ns.GEAR_TIP_MIN: an
                         -- upgrade too small to plan a pull around is left out)
ns.FORYOU_LOOT = 12      -- drop rows looked at per boss, at most
ns.FORYOU_AWAY = 30 * 60 -- seconds outside after which a visit's kills are forgotten (the dungeon may have reset)
ns.FORYOU_EVERY = 1      -- seconds: events within this are read once
ns.FORYOU_AGAIN = 3      -- seconds after the way in (plus GearScore's answer life) for a second read

local function journal()
  local fdj = g("ForeverDungeonJournal_NS")
  if type(fdj) ~= "table" then return nil end
  local ok, db = pcall(function() return fdj.DB end)
  if not (ok and type(db) == "table") then return nil end
  return fdj, db
end

-- The dungeon you're in, by the journal's own name for it (its lookup goes by the instance's number first, so it
-- works on every client language), and its entry; nil outside a dungeon or without the journal.
function ns.ForYouDungeon()
  local inside, kind = call(g("IsInInstance"))
  if not inside or secret(kind) or kind ~= "party" then return nil end
  local fdj, db = journal()
  if not fdj then return nil end
  local key = call(fdj.CurrentDungeon)
  local e = type(key) == "string" and db[key]
  if type(e) ~= "table" or type(e.bosses) ~= "table" then return nil end
  return key, e, fdj
end

-- This visit's kills (UW_GuildCharDB.forYouKills = { inst, at, out, ids = { [encounterID] = true },
-- names = { [encounter name, lower case] = true } }): the game's own numbers and names from ENCOUNTER_END.
local function instanceNumber()
  local fn = g("GetInstanceInfo")
  local ok, n = false, nil
  if type(fn) == "function" then ok, n = pcall(function() return (select(8, fn())) end) end
  if not ok then return nil end
  return type(n) == "number" and not secret(n) and n or nil
end
local function kills(fresh)
  local c = g("UW_GuildCharDB")
  if type(c) ~= "table" then return nil end
  local k, inst, now = c.forYouKills, instanceNumber(), time()
  if type(k) ~= "table" or k.inst ~= inst or (k.out and now - k.out > ns.FORYOU_AWAY) then
    if not fresh then return nil end
    k = { inst = inst, at = now, ids = {}, names = {} }
    c.forYouKills = k
  end
  if fresh then k.out = nil end
  return k
end
-- A boss killed again this visit means the dungeon was reset (as ForeverDungeonJournal reads it): a new visit starts
-- with that kill.
function ns.ForYouKill(id, name, success)
  if secret(id) or secret(name) or secret(success) or success ~= 1 then return end
  if not ns.ForYouDungeon() then return end
  local k = kills(true)
  if not k then return end
  name = type(name) == "string" and name ~= "" and name:lower() or nil
  if (type(id) == "number" and k.ids[id]) or (name and k.names[name]) then
    k.ids, k.names, k.at = {}, {}, time()
  end
  if type(id) == "number" then k.ids[id] = true end
  if name then k.names[name] = true end
end
local function leftInstance()
  local c = g("UW_GuildCharDB")
  local k = type(c) == "table" and c.forYouKills
  if type(k) == "table" and not k.out then k.out = time() end
end

-- Killed this visit: by its encounter number in the journal's list, or by the game's name for it (its name or an alias).
local function killed(fdj, key, boss, k)
  if not k then return false end
  local list = type(fdj.RUNLOG_ENCOUNTERS) == "table" and fdj.RUNLOG_ENCOUNTERS or {}
  for id in pairs(k.ids) do
    local hit = list[id]
    if type(hit) == "table" and hit[1] == key and hit[2] == boss.name then return true end
  end
  if k.names[lower(boss.name) or ""] then return true end
  for _, a in ipairs(type(boss.aliases) == "table" and boss.aliases or {}) do
    if k.names[lower(a) or ""] then return true end
  end
  return false
end

-- Your open quests: { [questID] = title } from the game's log, not done.
local function openQuests()
  local ql, out = g("C_QuestLog"), {}
  if type(ql) ~= "table" then return out end
  for i = 1, tonumber((call(ql.GetNumQuestLogEntries))) or 0 do
    local info = call(ql.GetInfo, i)
    local id = type(info) == "table" and not info.isHeader and tonumber(info.questID)
    if id and type(info.title) == "string" and not secret(info.title) and not call(ql.IsComplete, id) then
      out[id] = info.title
    end
  end
  return out
end

-- Which boss a quest's objective names: the longest name or alias found in it ("Sneed's Shredder" over "Sneed").
local function bossNamed(bosses, objective)
  local text, best, bestLen = lower(objective), nil, 0
  if not text then return nil end
  for i, b in ipairs(bosses) do
    if type(b) == "table" then
      local names = { b.name }
      for _, a in ipairs(type(b.aliases) == "table" and b.aliases or {}) do names[#names + 1] = a end
      for _, n in ipairs(names) do
        local l = lower(n)
        if l and #l > bestLen and text:find(l, 1, true) then best, bestLen = i, #l end
      end
    end
  end
  return best
end

-- The quests in your log that name each boss: { [boss index] = { title, ... } }. The journal's quest is matched by
-- number and title both (Forever reuses some numbers), and only its objective is read, to find the boss.
local function questsByBoss(e)
  local mine, out = openQuests(), {}
  for _, q in ipairs(type(e.quests) == "table" and e.quests or {}) do
    local title = type(q) == "table" and type(q.id) == "number" and mine[q.id]
    if title and lower(q.name) == title:lower() then
      local i = bossNamed(e.bosses, q.objective)
      if i then out[i] = out[i] or {} table.insert(out[i], title) end
    end
  end
  return out
end

-- The client's own item data for a drop: its link, or nil while it loads (asked once; the line is read again when it
-- arrives).
local asked, waiting = {}, false
local function itemLink(id)
  local ci = g("C_Item")
  local get = (type(ci) == "table" and ci.GetItemInfo) or g("GetItemInfo")
  local _, link = call(get, id)
  if type(link) == "string" and not secret(link) then return link end
  if not asked[id] and type(ci) == "table" then
    asked[id] = true
    call(ci.RequestLoadItemDataByID, id)
  end
  waiting = true
  return nil
end
local function gearOn() return type(UW_GuildDB) == "table" and UW_GuildDB.gearAuto ~= false end

-- The best drop for you from one boss: { link, pct, empty } or nil.
local function bestDrop(boss)
  if not (gearOn() and ns.GearUpgradeSoon) then return nil end
  local best, n = nil, 0
  for _, row in ipairs(type(boss.loot) == "table" and boss.loot or {}) do
    if n >= ns.FORYOU_LOOT then break end
    local id = type(row) == "table" and tonumber(row[1])
    if id then
      n = n + 1
      local link = itemLink(id)
      local u = link and ns.GearUpgradeSoon(link)
      -- Pawn's answer counts too (its pct is a gain like ours; only the tooltip leaves its line to Pawn).
      if type(u) == "table" and (u.empty or (tonumber(u.pct) or 0) >= math.max(ns.FORYOU_MIN, ns.GEAR_TIP_MIN or 0)) then
        local score = u.empty and math.huge or u.pct
        if not best or score > best.score then best = { link = link, pct = u.pct, empty = u.empty, score = score } end
      end
    end
  end
  return best
end

-- "Bandsaw Wristbands +12%": the item's name in its quality's color (the link without its brackets), and how much.
local function dropWords(d)
  local name = d.link:gsub("|H.-|h%[(.-)%]|h", "%1")
  if d.empty then return name .. " (empty slot)" end
  if (d.pct or 0) >= (ns.GEAR_BIG or 100) then return name .. " (big upgrade)" end
  return ("%s +%d%%"):format(name, d.pct or 0)
end

-- What the line says now, and how many bosses it names; nil when nothing applies.
function ns.ForYouText()
  local key, e, fdj = ns.ForYouDungeon()
  if not key then return nil end
  waiting = false
  local k, quests, parts = kills(false), questsByBoss(e), {}
  for i, boss in ipairs(e.bosses) do
    if #parts >= ns.FORYOU_BOSSES then break end
    if type(boss) == "table" and type(boss.name) == "string" and not killed(fdj, key, boss, k) then
      local why = {}
      local d = bestDrop(boss)
      if d then why[#why + 1] = dropWords(d) end
      for _, title in ipairs(quests[i] or {}) do why[#why + 1] = title end
      if #why > 0 then parts[#parts + 1] = boss.name .. ": " .. table.concat(why, ", ") end
    end
  end
  if #parts == 0 then return nil end
  return table.concat(parts, "  \194\183  "), #parts
end

-- The line: under the top of the screen where the compass sits, in its width, opacity and color.
ns.FORYOU_LINES = 2
local line
local function build()
  if line or not CreateFrame then return line end
  local f = CreateFrame("Frame", "UW_ForYou", g("UIParent"))
  f:SetFrameStrata("LOW")
  f:EnableMouse(false)
  f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  f.text:SetPoint("TOP", f, "TOP", 0, 0)
  f.text:SetJustifyH("CENTER")
  f.text:SetWordWrap(true)
  if f.text.SetMaxLines then f.text:SetMaxLines(ns.FORYOU_LINES) end
  if ns.Skin then ns.Skin("Font", f.text) end
  f:Hide()
  line = f
  return f
end
function ns.ForYouFrame() return line end

local function wanted() return ns.CompassOn and ns.CompassOn() and ns.Setting("compass", "inside") == true end

function ns.ForYouRefresh()
  local text = wanted() and ns.ForYouText()
  if not text then
    if line then line:Hide() end
    return nil
  end
  local f = build()
  if not f then return text end
  local w = ns.Setting("compass", "width")
  local r, gg, b = ns.TerrainColor(ns.Setting("compass", "color"))
  f:SetSize(w, 32)
  f:ClearAllPoints()
  f:SetPoint("TOP", g("UIParent"), "TOP", 0, -ns.Setting("compass", "y"))
  f:SetAlpha(ns.Setting("compass", "opacity") / 100)
  f.text:SetWidth(w)
  f.text:SetText(("|cff%02x%02x%02xFor you:|r %s"):format(r * 255, gg * 255, b * 255, text))
  f:Show()
  return text
end

-- Read again on the way in, after a kill, a quest or gear change, and when a drop's item data arrives; events close
-- together are read once. Outside a dungeon nothing is read.
local soon = false
local function later()
  if soon then return end
  soon = true
  ns.after(ns.FORYOU_EVERY, function() soon = false ns.ForYouRefresh() end)
end
ns.OnSetting("compass", later)

local ev = CreateFrame("Frame")
ns.listen(ev, { "PLAYER_ENTERING_WORLD", "ENCOUNTER_END", "QUEST_LOG_UPDATE", "PLAYER_EQUIPMENT_CHANGED",
  "PLAYER_LEVEL_UP", "GET_ITEM_INFO_RECEIVED" })
ev:SetScript("OnEvent", ns.guard(function(_, event, id, name, _, _, success)
  if event == "PLAYER_ENTERING_WORLD" then
    if not ns.ForYouDungeon() then leftInstance() if line then line:Hide() end return end
    kills(true)
    -- Read at once (it asks the client for drops it hasn't loaded), then again once GearScore's short-lived answers
    -- for those drops have run out (addon lead, 22 Nov: an answer it couldn't give yet is kept GEAR_TIP_SECONDS).
    ns.ForYouRefresh()
    ns.after(ns.FORYOU_AGAIN + (ns.GEAR_TIP_SECONDS or 0), ns.ForYouRefresh)
    return
  end
  if event == "ENCOUNTER_END" then ns.ForYouKill(id, name, success) end
  if event == "GET_ITEM_INFO_RECEIVED" and not waiting then return end
  if line and line:IsShown() or ns.ForYouDungeon() then later() end
end))
