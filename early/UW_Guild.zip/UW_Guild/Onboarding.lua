-- UW_Guild onboarding: welcome panel, /uw near, buddy pairing, first-guild-group tracking.
-- Goal: every recruit is grouped with guildmates within 72 hours (see the guild playbook).
local _, ns = ...
local say = ns.say

-- Guild config -------------------------------------------------------------
ns.DISCORD_INVITE = "https://discord.gg/D5EZm3gAcZ" -- permanent server invite (never expires); an officer's /uw invite overrides it
-- The Guild Master's one contact in game (Louis, 14 Nov 2026: BattleTag only, no Steam); keep in step with
-- bot/uwbot/contact.py.
ns.GM_BATTLETAG = "Storm#110232"
ns.NEAR_RANGE = 3       -- /uw near lists online guildmates within this many levels
ns.GRP_RESEND_DAYS = 7  -- re-announce a first group on each login for this long, so a late officer still hears it
ns.RETURN_DAYS = 14     -- a player logging in after this long away gets one welcome-back line
ns.TAGLINE = "No sweat. No corpse camps. Just zug."
ns.SUBTAGLINE = "Leveling, dungeons and chill. All ages and levels welcome." -- word for word as the site (index.html)
local MEDIA = "Interface\\AddOns\\UW_Guild\\Media\\"
-- The norms that matter in game, keyed by their #welcome-rules number (bot/uwbot/layout.py NORMS: a bot test checks
-- each line starts with that norm's own words, and NORMS_TOTAL). The number only sorts and groups them: the window
-- shows a dot in its place (15 Nov 2026: a newcomer read "1, 7, 9" as missing rules, and published text carries no
-- norm numbers).
ns.NORMS = {
  { 1, "Be unbothered: talk about anything, with respect. No slurs, nothing demeaning. Take issues to an officer: whisper one, or /ask-officers in Discord." },
  { 2, "Raid voice is push-to-talk. Keep callouts concise." },
  { 4, "In raids, turn off ForeverVoice and use Discord voice. In dungeons, use whatever your group likes." },
  { 5, "Sign up 24 hours ahead, and decline if you can't make it." },
  { 7, "Loot Main before Off: /roll for main, /roll 99 for off spec." },
  { 9, "Nothing against ToS." },
}
ns.NORMS_TOTAL = 11
-- docs/norms.md (Louis 9 Nov 01:53): what new people read first leads with grouping, not raids. Norms 2 to 5 keep their
-- numbers under a small "Raid nights" heading at the end.
ns.RAID_NORMS = { [2] = true, [3] = true, [4] = true, [5] = true }
-- Same words as layout.py FREE_HELP (#welcome-rules intro); a bot test compares them.
ns.FREE_HELP = "Helping a guildmate for free is welcome and never expected."
-- The three values the norms sit under in #welcome-rules (layout.py VALUES; the same bot test compares them).
ns.VALUES = { "Unbothered", "Reliable", "Fair" }

local function me() return ns.shortName(ns.me() or UnitName("player")) end
-- Times sent to other clients use the realm's clock: players' PC clocks can be off by minutes or hours.
local function serverNow() return (GetServerTime and GetServerTime()) or time() end

-- Discord invite ---------------------------------------------------------------
-- Officers save it with /uw invite; it spreads by INV on GUILD, and members ask on login (INVQ). Each saved invite
-- carries when an officer set it (inviteAt, realm time), so a member who was offline for a change still gets the
-- newest link, and an older one never replaces it. UW_GuildDB.invite overrides the compiled-in default.
function ns.ValidInvite(url)
  url = (strtrim(tostring(url or "")):gsub("/+$", ""))
  local code = url:match("^https://discord%.gg/([%w%-]+)$") or url:match("^https://discord%.com/invite/([%w%-]+)$")
  if code and #code >= 2 and #code <= 32 then return url end
end
function ns.Invite() return UW_GuildDB.invite or ns.DISCORD_INVITE end
local lastInviteReply = {}

-- Buddy pairing --------------------------------------------------------------
-- UW_GuildDB.buddies[recruit] = { buddy = name, by = officer, at = time }
local lastBuddyReply = {}

local function setBuddy(recruit, buddy, by)
  local cur = UW_GuildDB.buddies[recruit]
  if cur and cur.buddy == buddy then return end
  UW_GuildDB.buddies[recruit] = { buddy = buddy, by = by, at = time() }
  if buddy == me() then say(("You're %s's guild buddy. Say hi and pull them into a group this week."):format(recruit)) end
  if recruit == me() then
    say(("Your guild buddy is %s. Whisper them any time."):format(buddy))
    if ns.RefreshWelcome then ns.RefreshWelcome() end
  end
end

ns.commands.buddy = function(args)
  local recruit, rest = ns.splitName(args, ns.rosterName) -- Forever names are two words: "Mia Stone Rex Hall"
  local buddy, extra = ns.splitName(rest, ns.rosterName)
  if buddy and extra ~= "" and not ns.inRoster(buddy) then buddy, extra = rest, "" end -- named below as not found
  if not buddy or extra ~= "" then say("Usage: /uw buddy Recruit Buddy") return end
  if not ns.isOfficer(me()) then say("Only officers can assign buddies.") return end
  for _, n in ipairs({ recruit, buddy }) do
    if not ns.inRoster(n) then say(n .. " isn't in the guild roster (names are case-sensitive).") return end
  end
  setBuddy(recruit, buddy, me())
  ns.queue("buddy", recruit, buddy)
  if not ns.send(("BUDDY\t%s\t%s"):format(recruit, buddy), "GUILD") then
    say("Saved locally. Couldn't broadcast right now (combat or restricted); it syncs when they log in.")
  end
end

-- Pairings come only from officers. GUILD messages can only come from guildmates;
-- whispers can come from anyone, so both are checked against the roster by full Name-Realm.
-- Handlers receive the sender's full name.
ns.handlers.BUDDY = function(sender, _, recruit, buddy)
  if recruit and buddy and ns.isOfficer(sender) then setBuddy(recruit, buddy, ns.shortName(sender)) end
end

-- A member who was offline when paired asks on login; officers who know the pairing answer.
-- An unpaired recruit gets BUDN instead: their own client can't always tell it is a recruit (a new invite
-- sits in the lowest rank next to social members), but an officer who saw them join can. Join time alone
-- never expires, so it counts only while they are still in the lowest rank: a promoted member isn't waiting.
ns.handlers.BUDQ = function(sender, channel)
  if channel ~= "GUILD" or not ns.isOfficer(me()) or not ns.inRoster(sender) then return end
  local recruit = ns.shortName(sender)
  local pair = UW_GuildDB.buddies[recruit]
  if not pair and not (ns.hasRecruitRank(recruit) or (ns.isRecruit(recruit) and ns.isLowestRank(recruit))) then return end
  if lastBuddyReply[sender] and GetTime() - lastBuddyReply[sender] < 300 then return end
  lastBuddyReply[sender] = GetTime()
  ns.reply(pair and ("BUDDY\t%s\t%s"):format(recruit, pair.buddy) or ("BUDN\t" .. recruit), sender)
end

ns.handlers.BUDN = function(sender, channel, recruit)
  if channel ~= "WHISPER" or recruit ~= me() or not ns.isOfficer(sender) then return end
  UW_GuildCharDB.recruitAt = UW_GuildCharDB.recruitAt or time()
  if ns.RefreshWelcome then ns.RefreshWelcome() end
end

-- Guild jobs (docs/leadership.md): a job is a word in the member's public guild note ("Heal · Buddy"), so
-- everyone sees it in the guild roster, with or without UW_Guild. Members take one by asking an officer in game, or
-- by adding the word to their own note; deleting the word leaves it. Keep in step with bot/uwbot/jobs.py JOBS.
-- Leading isn't a job (Louis, 8 Nov 2026): anyone who wants to lead a raid or dungeon leads, rated by the people they
-- led (/uw rate, Thanks.lua).
ns.JOBS = {
  { key = "buddy", label = "Welcome buddy", words = { "buddy" } },
  { key = "recruiter", label = "Recruiter", words = { "recruiter" } },
  { key = "host", label = "Event host", words = { "event host", "host" } },
}
ns.JOBS_MIN = 2         -- every job has a lead and a backup
ns.JOBS_ASK_GAP = 86400 -- /uw jobs ask: once a day per officer account
local NOTE_STOP = { lf = true, lfm = true, need = true, needs = true, want = true, wants = true, looking = true, wtb = true }
ns.JOBS_ASK = "Anyone want to help out as a welcome buddy, recruiter or event host? Whisper me!"

-- Job keys a note names, in ns.JOBS order. Words after "LF", "need" or "want" are asks, not jobs (as for professions).
function ns.NoteJobs(note)
  if type(note) ~= "string" then return {} end
  local low, cut = note:lower(), nil
  for pos, w in low:gmatch("()(%a+)") do
    if NOTE_STOP[w] then cut = pos break end
  end
  if cut then low = low:sub(1, cut - 1) end
  local padded, out = " " .. low .. " ", {}
  for _, j in ipairs(ns.JOBS) do
    for _, w in ipairs(j.words) do
      local plain = w:gsub("%p", "%%%0")
      if padded:find("%f[%a]" .. plain .. "%f[%A]") then out[#out + 1] = j.key break end
    end
  end
  return out
end

-- job key -> sorted names of present members whose note names it, from the last roster read.
function ns.JobHolders()
  local out = {}
  for _, j in ipairs(ns.JOBS) do out[j.key] = {} end
  for name, m in pairs(UW_GuildDB.members or {}) do
    if type(m) == "table" and not m.left then
      for _, k in ipairs(ns.NoteJobs(m.note)) do table.insert(out[k], name) end
    end
  end
  for _, list in pairs(out) do table.sort(list) end
  return out
end

ns.commands.jobs = function(args)
  args = strtrim(args or ""):lower()
  if args == "ask" then
    if not ns.isOfficer(ns.me()) then say("Officers ask in guild chat. Want a job? Whisper an officer.") return end
    local last = UW_GuildDB.jobsAskedAt or 0
    if time() - last < ns.JOBS_ASK_GAP then say("You asked in guild chat today already. Again tomorrow.") return end
    UW_GuildDB.jobsAskedAt = time()
    ns.chat("jobs.ask", ns.JOBS_ASK, "GUILD")
    return
  end
  local hs = ns.JobHolders()
  say("Guild jobs, from guild notes (open the guild roster to see them):")
  for _, j in ipairs(ns.JOBS) do
    local list = hs[j.key]
    local open = #list < ns.JOBS_MIN and (" · %d more wanted"):format(ns.JOBS_MIN - #list) or ""
    say(("%s: %s%s"):format(j.label, #list > 0 and table.concat(list, ", ", 1, math.min(#list, 6)) or "nobody yet", open))
  end
  -- Public notes are officer-only on Forever: offer editing your own note only to those who can.
  local canEdit = (C_GuildInfo and C_GuildInfo.CanEditPublicNote and C_GuildInfo.CanEditPublicNote() == true)
    or (CanEditPublicNote and CanEditPublicNote() == true)
  if canEdit then
    say("Want one? Whisper an officer, or add it to your note in the guild roster (e.g. \"Heal · Buddy\").")
  else
    say("Want one? Whisper an officer and they'll add it to your guild note.")
  end
end

ns.commands.contact = function()
  say(("Guild Master: add BattleTag %s as a Battle.net friend."):format(ns.GM_BATTLETAG))
end

ns.commands.invite = function(args)
  args = strtrim(args or "")
  if args == "" or args:lower() == "copy" then
    local url = ns.Invite()
    if not url then
      say("No Discord invite saved yet. Officers: /uw invite https://discord.gg/yourcode")
    elseif args == "" then
      say("Our Discord: " .. url .. " (copy it from the guide's Guild page).")
    else
      -- WoW can't open a link or copy from chat: the invite stands selected in the small copy box (KitDoctor.lua),
      -- which is what the guide's Discord row opens.
      ns.TextBox("UW Discord invite", "Press Ctrl+C, then paste it into your browser.", url)
    end
    return
  end
  if not ns.isOfficer(me()) then say("Only officers can set the Discord invite.") return end
  local url = ns.ValidInvite(args)
  if not url then say("That isn't a Discord invite link. Use https://discord.gg/code or https://discord.com/invite/code.") return end
  UW_GuildDB.invite, UW_GuildDB.inviteAt = url, serverNow()
  ns.RefreshWelcome()
  if ns.send("INV\t" .. url .. "\t" .. UW_GuildDB.inviteAt, "GUILD") then
    say("Discord invite saved and sent to guildmates online with UW_Guild.")
  else
    say("Saved. Couldn't broadcast right now (combat or restricted); members get it when they log in.")
  end
end

-- Only officers can change the invite: a link from anyone else could point at a scam server.
-- A link without a time (an older client) is accepted only while ours has none either.
ns.handlers.INV = function(sender, channel, url, at)
  if (channel ~= "GUILD" and channel ~= "WHISPER") or not ns.isOfficer(sender) then return end
  url, at = ns.ValidInvite(url), ns.finite(at)
  if at and at > serverNow() + 600 then at = nil end -- an officer's clock in the future can't pin a link forever
  if not url or (at or 0) < (UW_GuildDB.inviteAt or 0) then return end
  if url == UW_GuildDB.invite and (at or 0) == (UW_GuildDB.inviteAt or 0) then return end
  UW_GuildDB.invite, UW_GuildDB.inviteAt = url, at
  ns.RefreshWelcome()
end

-- A member asks on login: bare INVQ without a saved invite, INVQ\t<inviteAt> with one. Officers answer the first
-- with any invite they know, the second only with a newer one, and at most once per 5 min per member.
ns.handlers.INVQ = function(sender, channel, at)
  if channel ~= "GUILD" or not ns.isOfficer(me()) or not ns.inRoster(sender) then return end
  local url, theirs = ns.Invite(), ns.finite(at)
  if not url or (theirs and not (UW_GuildDB.invite and (UW_GuildDB.inviteAt or 0) > theirs)) then return end
  if lastInviteReply[sender] and GetTime() - lastInviteReply[sender] < 300 then return end
  lastInviteReply[sender] = GetTime()
  ns.reply("INV\t" .. url .. (UW_GuildDB.inviteAt and ("\t" .. UW_GuildDB.inviteAt) or ""), sender)
end

-- Discord ask -------------------------------------------------------------------
-- 8 Nov 2026: 131 of 146 characters joined in game and never saw the Discord; 1 had linked. Raid signups, crafting
-- and the bot's help can't see them, and only members with UW_Guild ever see the invite above.
-- So an officer's client whispers each newcomer once, a minute after they join: where the Discord is, and the exact
-- /link line for their own name. Why: a personal ask from a named member, at the moment of joining, with the next
-- step spelled out, beats any broadcast (Kraut & Resnick 2012, Building Successful Online Communities, ch. 5; Choi et
-- al. 2010, CSCW; Fogg 2009: prompt when motivation is high and the step is easy). Asking twice breeds reactance, so
-- a name is asked once ever: UW_GuildDB.discordAsked[name] = when (the bot can read it for a join-to-link funnel).
-- Officers share each ask as DWA on GUILD, so two officers online at a join don't both whisper.
--   /uw discord        status: asked so far, still to ask, online now
--   /uw discord ask    whisper up to DISCORD_ASK_RUN guildmates online now who joined before this existed
--   /uw discord off|on the join whisper on this account
ns.DISCORD_ASK_DELAY = 60 -- seconds after the join line, plus up to 30 more so officers online together don't collide
ns.DISCORD_ASK_RUN = 25   -- whispers per /uw discord ask
ns.DISCORD_ASK_GAP = 2    -- seconds between them: gentle on the chat throttle
local function askedDB()
  UW_GuildDB.discordAsked = type(UW_GuildDB.discordAsked) == "table" and UW_GuildDB.discordAsked or {}
  return UW_GuildDB.discordAsked
end
local function askKey(name)
  local full = ns.fullName(name)
  return full and ns.shortName(full)
end

-- One line under WoW's 255: the invite without https:// (WoW can't open links anyway) and how to /link. Never
-- "/link <name>" as one line: typed in one go, Discord drops the name and /link runs empty (8 Nov 2026: 3 of 4 first
-- links failed that way). A plain /link + Enter opens the Link form (bot #348), prefilled when their Discord name matches.
function ns.DiscordAskText(name)
  local url = ns.Invite and ns.Invite()
  if not url or not name then return nil end
  -- Discord is optional (Louis, 8 Nov 2026): the whisper invites, it never says the core of the guild lives there.
  -- A member asked in guild chat (8 Nov 21:48) how to post to guild and Discord at once. Louis validated (21:51):
  -- in game, /discord chats into Discord's #guild-chat (Blizzard's link runs as its own chat, not /g).
  return ("Welcome to Unbothered Warlords, %s! Glad you're here. Our Discord is optional (type /discord in game to "
    .. "chat with it): %s If you join, type "
    .. "/link there, press Enter, and type %s in the box."):format(name:match("^(%S+)") or name,
    (url:gsub("^https://", "")), name)
end

-- Who still needs asking: in the roster, not an officer, not you, never asked, and without UW_Guild (that comes
-- from #addon-kit, so they already found the Discord).
local function toAsk(onlineOnly)
  -- A read: counting who to ask (Lead.lua's button does it often) never creates the table.
  local out, self = {}, ns.me()
  local asked = type(UW_GuildDB.discordAsked) == "table" and UW_GuildDB.discordAsked or {}
  for i = 1, GetNumGuildMembers() or 0 do
    local full, _, _, _, _, _, _, _, online = GetGuildRosterInfo(i)
    local key = askKey(full)
    local m = key and UW_GuildDB.members[key]
    if key and key ~= self and not asked[key] and not ns.isOfficer(key) and not (m and m.addonVer)
      and not ns.quiet(key) and (online or not onlineOnly) then
      out[#out + 1] = key
    end
  end
  table.sort(out)
  return out
end
ns.DiscordToAsk = toAsk -- Lead.lua's "now" button counts who /uw discord ask would reach

-- One click, one person (Louis, 15 Nov 2026 13:53-13:54; built 16 Nov, design recruiting/discord-ask-design.md):
-- the Guild Master's Lead window has a Discord tab of online guildmates who may get one whisper with the server's
-- invite, each sent by one click of his, never twice, never queued. Raiders first: Louis, 15 Nov 14:13, "Raiders
-- will be expected to join and link before raiding together". Never asked: anyone linked in Discord, hidden members
-- too (ns.DISCORD_SKIP, which the bot writes on his PC only and the addon never shares), anyone asked before by any
-- path (discordAsked: 73 on 6-8 Nov), anyone who whispered stop, officers, his own characters, and anyone running
-- UW_Guild (it came from the Discord). Not in a fight or inside a dungeon or raid, one every DISCORD_ONE_GAP seconds,
-- DISCORD_ONE_PER_HOUR an hour. Nothing is announced to other clients: with one asker there's nothing to share, and
-- the old DWA mark handed out the not-linked list name by name (red team, 15 Nov).
ns.DISCORD_ONE_GAP, ns.DISCORD_ONE_PER_HOUR = 6, 20
function ns.DiscordOneText(name)
  local url = ns.Invite and ns.Invite()
  if not url or not name then return nil end
  return ("Hey %s! We've got a cozy guild Discord, no pressure. Raiders will need to join and link before we raid "
    .. "together: %s"):format(name:match("^(%S+)") or name, (url:gsub("^https?://", "")))
end
local function plainKey(n) return type(n) == "string" and (n:lower():gsub("[%s%-]+", " ")) or nil end
local function skipSet()
  if type(ns.DISCORD_SKIP) ~= "table" then return nil end
  local out = {}
  for _, n in ipairs(ns.DISCORD_SKIP) do local k = plainKey(n) if k then out[k] = true end end
  return out
end
local function myCharacter(key)
  for name in pairs(type(UW_GuildDB.alts) == "table" and UW_GuildDB.alts or {}) do
    if type(name) == "string" and askKey(name) == key then return true end
  end
  return false
end
-- nil, or why this guildmate isn't asked. skip: skipSet(), passed in by a caller that checks many.
function ns.DiscordNotAsked(full, skip)
  local key = full and askKey(full)
  if not key then return "unknown" end
  skip = skip or skipSet()
  if not skip then return "no list" end
  local fullKey = plainKey(ns.fullName(full) or full)
  if skip[fullKey] or skip[plainKey(key)] then return "linked" end
  local asked = type(UW_GuildDB.discordAsked) == "table" and UW_GuildDB.discordAsked or {}
  if asked[key] then return "asked" end
  if key == askKey(ns.me()) or myCharacter(key) then return "yours" end
  if ns.isOfficer(key) then return "officer" end
  if ns.quiet(key) then return "stop" end
  local m = UW_GuildDB.members and UW_GuildDB.members[key]
  if m and m.addonVer then return "addon" end
  return nil
end
ns.DiscordSkipSet = skipSet
-- When each went, kept in the save so a /reload doesn't reset the gap or the hour (addon lead, 16 Nov 2026).
local function oneSendsDB()
  UW_GuildDB.discordOneSends = type(UW_GuildDB.discordOneSends) == "table" and UW_GuildDB.discordOneSends or {}
  return UW_GuildDB.discordOneSends
end
-- Fixed lower-case shapes for the trace's why (hardening's reads print only these).
local function heldShape(why)
  why = tostring(why)
  if why:find("quiet", 1, true) then return "held: quiet" end
  if why:find("off for now", 1, true) then return "held: off" end
  if why:find("OK'd", 1, true) then return "held: not ok" end
  return "held: other"
end
ns.OnUnsent["discord.one"] = function(target)
  local key = target and askKey(target)
  if key and type(UW_GuildDB.discordAsked) == "table" then UW_GuildDB.discordAsked[key] = nil end
end
ns.OnSent["discord.one"] = function() ns.trace("discord", "one", true) end
-- The click. Returns true when it went (or waits for his OK on the popup), or false and what to tell him.
function ns.DiscordOne(full)
  if UW_GuildDB.gmAccount ~= true then return false, "This is the Guild Master's." end
  if ns.Restricted() then return false, "Not in a fight." end
  local inside, kind = false, "none"
  if type(IsInInstance) == "function" then inside, kind = IsInInstance() end
  if inside and kind ~= "none" then return false, "Not inside a dungeon or raid." end
  if ns.LineWaiting and ns.LineWaiting("discord.one") then return false, "Waiting for your OK on the popup." end
  local why = ns.DiscordNotAsked(full)
  if why then return false, why == "asked" and "Asked already." or "Skipped: already linked or opted out." end
  local now, oneSends = time(), oneSendsDB()
  for i = #oneSends, 1, -1 do if now - oneSends[i] >= 3600 then table.remove(oneSends, i) end end
  local last = oneSends[#oneSends]
  if last and now - last < ns.DISCORD_ONE_GAP then return false, ("One every %d s: wait a moment."):format(ns.DISCORD_ONE_GAP) end
  if #oneSends >= ns.DISCORD_ONE_PER_HOUR then
    return false, ("%d this hour. More next hour."):format(ns.DISCORD_ONE_PER_HOUR)
  end
  local key, to = askKey(full), ns.fullName(full) or full
  local text = ns.DiscordOneText(to)
  if not text then return false, "No Discord invite set." end
  askedDB()[key] = now -- before the send, so a second click can't ask twice; OnUnsent takes it back
  local sent, held = ns.chat("discord.one", text, "WHISPER", to)
  if not sent then
    askedDB()[key] = nil
    local refused = held == nil or held == "the game didn't send it"
    ns.trace("discord", "one", not refused, refused and "game refused" or heldShape(held))
    return false, ("Not sent: %s."):format(held or "the game didn't send it")
  end
  oneSends[#oneSends + 1] = now
  return true, held -- held: "waiting for your OK" the first time, on his popup
end

-- Officers without UW_Guild who aren't linked in Discord (so the officer DM can't reach them): one whisper each, once
-- ever, with the addon page (Louis, 16 Nov 2026 03:55, "whisper ingame with links"). His client only, his click,
-- the same gap and hour as the Discord ask. UW_GuildDB.officerAsked[name] = when.
function ns.OfficerAddonText(name)
  if not name then return nil end
  return ("Hey %s, thanks for officering! One ask: grab our guild addon, UW_Guild. Newcomers decide on day one if "
    .. "they stay, and /uw new shows who's online without a group so you can invite them. Install (2 min): "
    .. "unbotheredwarlords.github.io/addon"):format(name:match("^(%S+)") or name)
end
local function officerAskedDB()
  UW_GuildDB.officerAsked = type(UW_GuildDB.officerAsked) == "table" and UW_GuildDB.officerAsked or {}
  return UW_GuildDB.officerAsked
end
-- nil, or why this officer isn't asked.
function ns.OfficerNotAsked(full, skip)
  local key = full and askKey(full)
  if not key then return "unknown" end
  skip = skip or skipSet()
  if not skip then return "no list" end
  if not ns.isOfficer(key) then return "not officer" end
  if skip[plainKey(ns.fullName(full) or full)] or skip[plainKey(key)] then return "linked" end
  if type(UW_GuildDB.officerAsked) == "table" and UW_GuildDB.officerAsked[key] then return "asked" end
  if key == askKey(ns.me()) or myCharacter(key) then return "yours" end
  if ns.quiet(key) then return "stop" end
  local m = UW_GuildDB.members and UW_GuildDB.members[key]
  if m and m.addonVer then return "addon" end
  return nil
end
ns.OnUnsent["officer.addon"] = function(target)
  local key = target and askKey(target)
  if key and type(UW_GuildDB.officerAsked) == "table" then UW_GuildDB.officerAsked[key] = nil end
end
ns.OnSent["officer.addon"] = function() ns.trace("officer", "addon", true) end
function ns.OfficerAsk(full)
  if UW_GuildDB.gmAccount ~= true then return false, "This is the Guild Master's." end
  if ns.Restricted() then return false, "Not in a fight." end
  local inside, kind = false, "none"
  if type(IsInInstance) == "function" then inside, kind = IsInInstance() end
  if inside and kind ~= "none" then return false, "Not inside a dungeon or raid." end
  if ns.LineWaiting and ns.LineWaiting("officer.addon") then return false, "Waiting for your OK on the popup." end
  local why = ns.OfficerNotAsked(full)
  if why then return false, why == "asked" and "Asked already." or "Skipped: has the addon, linked or opted out." end
  local now, oneSends = time(), oneSendsDB()
  for i = #oneSends, 1, -1 do if now - oneSends[i] >= 3600 then table.remove(oneSends, i) end end
  local last = oneSends[#oneSends]
  if last and now - last < ns.DISCORD_ONE_GAP then return false, ("One every %d s: wait a moment."):format(ns.DISCORD_ONE_GAP) end
  if #oneSends >= ns.DISCORD_ONE_PER_HOUR then
    return false, ("%d this hour. More next hour."):format(ns.DISCORD_ONE_PER_HOUR)
  end
  local key, to = askKey(full), ns.fullName(full) or full
  officerAskedDB()[key] = now -- before the send, so a second click can't ask twice; OnUnsent takes it back
  local sent, held = ns.chat("officer.addon", ns.OfficerAddonText(to), "WHISPER", to)
  if not sent then
    officerAskedDB()[key] = nil
    local refused = held == nil or held == "the game didn't send it"
    ns.trace("officer", "addon", not refused, refused and "game refused" or heldShape(held))
    return false, ("Not sent: %s."):format(held or "the game didn't send it")
  end
  oneSends[#oneSends + 1] = now
  return true, held
end

-- sender: "discord.join" (a new join, automatic) or "discord.ask" (/uw discord ask, pressed). Outbound.lua decides;
-- while it's off nobody is marked asked, so nobody is skipped later.
-- Never sent (Louis's "Don't send" on the first-time popup, Outbound.lua): not marked asked after all.
local function unask(target) local k = target and askKey(target) if k then askedDB()[k] = nil end end
ns.OnUnsent["discord.join"], ns.OnUnsent["discord.ask"] = unask, unask
local function ask(key, delay, sender)
  local text = ns.DiscordAskText(key)
  if not text or ns.quiet(key) or not ns.ChatOn(sender, text, key) then return false end
  askedDB()[key] = time()
  ns.officerSend("DWA\t" .. key, "GUILD")
  ns.after(delay, function() ns.chat(sender, text, "WHISPER", key) end)
  return true
end

-- A join seen by an officer: wait, then ask unless another officer already did (or they're gone, or in combat).
local JOINED = ERR_GUILD_JOIN_S
  and "^" .. ERR_GUILD_JOIN_S:gsub("[%%%(%)%.%+%-%*%?%[%]%^%$]", "%%%0"):gsub("%%%%s", "(.+)") .. "$"
-- A returning member is never asked (stress review, 8 Nov: Donkey Ankle left over the Discord link and got the whisper
-- on rejoining). Returning = the roster knew them RETURN_GAP before this join line; the scan that sees a real newcomer
-- can land before the timer fires, but it stamps first = now, so it never looks old.
ns.DISCORD_ASK_RETURN_GAP = 600
local function returning(key, joinedAt)
  local m = UW_GuildDB.members and UW_GuildDB.members[key]
  return m ~= nil and type(m.first) == "number" and m.first < joinedAt - ns.DISCORD_ASK_RETURN_GAP
end
local function onJoin(name, tries, joinedAt)
  if UW_GuildDB.discordAskOff or not ns.isOfficer(ns.me()) then return end
  local key = askKey(name)
  if not key or key == ns.me() or askedDB()[key] or returning(key, joinedAt) then return end
  if InCombatLockdown() and tries < 10 then
    ns.after(30, function() onJoin(name, tries + 1, joinedAt) end)
    return
  end
  -- New joins only (never the /uw discord ask sweep): the professions ask as its own whisper a moment later, so each
  -- whisper asks one thing and the Discord funnel counts only its own (funnel thread, 8 Nov). Crafts.lua.
  if ask(key, 0, "discord.join") and ns.ProfJoinAsk then ns.ProfJoinAsk(key, ns.PROF_JOIN_DELAY) end
end

ns.handlers.DWA = function(sender, channel, name)
  if channel ~= "GUILD" or not ns.isOfficer(sender) or type(name) ~= "string" or #name > 60 then return end
  local key = askKey(name)
  if key then askedDB()[key] = askedDB()[key] or time() end
end

ns.commands.discord = function(args)
  args = strtrim(args or ""):lower()
  if not ns.isOfficer(ns.me()) then say("Only officers ask guildmates about Discord. Ours: " .. (ns.Invite() or "")) return end
  if args == "off" or args == "on" then
    UW_GuildDB.discordAskOff = args == "off" or nil
    if args == "off" then
      say("Join whisper off on this account. /uw discord on turns it back on.")
    elseif not ns.ChatOn("discord.join") then
      say("Join whisper: on for this account, off for the whole guild. /uw quiet list shows what's off.")
    else
      say("Join whisper on: each new guildmate gets one Discord whisper a minute after joining.")
    end
    return
  end
  -- Retired with the join whisper (Louis, 9 Nov 2026 02:39: "auto-whispering is a bit too...robotic"): both senders
  -- are off in Outbound.lua, so /uw discord says so instead of counting who is "still to ask".
  if not ns.ChatOn("discord.ask") and not ns.ChatOn("discord.join") then
    say("UW_Guild doesn't whisper anyone about Discord.")
    say("Share it yourself when it fits: " .. (ns.Invite() or ""))
    return
  end
  if args == "ask" then
    local todo = toAsk(true)
    if #todo == 0 then say("Everyone online has been asked already, or has UW_Guild.") return end
    if not ns.ChatOn("discord.ask", ns.DiscordAskText(todo[1]) or "", todo[1]) then -- an officer's: Louis OKs it first
      say("Not sent: this whisper waits for the Guild Master's OK. Nobody was marked asked.")
      return
    end
    local n = math.min(#todo, ns.DISCORD_ASK_RUN)
    for i = 1, n do ask(todo[i], ns.DISCORD_ASK_GAP * (i - 1), "discord.ask") end
    say(("Whispering %d guildmates about Discord over %d s, once each."):format(n, ns.DISCORD_ASK_GAP * n)
      .. (#todo > n and (" %d more online: /uw discord ask again after."):format(#todo - n) or ""))
    return
  end
  local asked = 0
  for _ in pairs(askedDB()) do asked = asked + 1 end
  say(("Discord asks: %d sent, %d guildmates still to ask, %d online now. Join whisper is %s."):format(asked,
    #toAsk(false), #toAsk(true), (UW_GuildDB.discordAskOff or not ns.ChatOn("discord.join")) and "off" or "on"))
  say("/uw discord ask whispers those online now (once each); /uw discord off stops the join whisper.")
end

local askFrame = CreateFrame("Frame")
askFrame:RegisterEvent("CHAT_MSG_SYSTEM")
askFrame:SetScript("OnEvent", ns.guard(function(_, _, msg)
  if not (UW_GuildDB and JOINED) or type(msg) ~= "string" or ns.isSecret(msg) then return end
  local who = msg:match(JOINED)
  if who then who = who:gsub("|Hplayer:[^|]*|h%[?([^%]|]*)%]?|h", "%1") end -- a clickable name, if the client sends one
  if who and who ~= "" then
    local at = time()
    -- A rejoin gets a person's hello, never an automatic whisper (Louis, 8 Nov: no auto-whisper). Officers only.
    local key = askKey(who)
    if key and key ~= ns.me() and ns.isOfficer(ns.me()) and returning(key, at) then
      say(("%s is back in the guild. Say hi?"):format(key))
    end
    ns.after(ns.DISCORD_ASK_DELAY + math.random() * 30, function() onJoin(who, 0, at) end)
  end
end))

-- Who invited whom (Louis, 8 Nov 2026: "see who invites who ... I want to reward recruiters") ----------------------
-- The game names a recruiter in one place: the guild event log ("X invited Y"), which keeps only recent entries. So
-- each login, and a few seconds after each "has joined the guild" line, this copies the log's invites into
-- UW_GuildDB.invites[recruit] = { { by, at }, ... }: up to INVITES_PER_RECRUIT invites, newest kept, one per inviter
-- (an invite read again is the same one; the log's time is "N hours ago", so `at` moves by up to an hour between
-- reads). Every invite is kept, not a pick: a declined invite before the accepted one is the bot's call
-- (bot/uwbot/recruiters.py credits the last invite before the roster first saw them, and only a recruit who stayed
-- 7 days or linked Discord). A client without the log still records its own invites ("You have invited X").
-- Read only: nothing is sent, whispered or posted. UW_GuildDB.inviteLog says what the last read found (the
-- launch check reads it after a deploy: api false = this client has no event log).
ns.INVITES_PER_RECRUIT, ns.INVITES_MAX = 3, 3000
local HOUR = 3600
local function invitesDB()
  UW_GuildDB.invites = type(UW_GuildDB.invites) == "table" and UW_GuildDB.invites or {}
  return UW_GuildDB.invites
end
local function plainNum(v) return type(v) == "number" and not ns.isSecret(v) and v >= 0 and v or 0 end
-- recruit and by as any spelling the game gives; at = when (time()). True when it was new.
function ns.NoteInvite(recruit, by, at)
  if type(at) ~= "number" or ns.isSecret(at) then return false end
  recruit, by = askKey(recruit), askKey(by)
  if not recruit or not by or recruit == by then return false end
  local db = invitesDB()
  local list = db[recruit]
  if type(list) ~= "table" then
    local n = 0
    for _ in pairs(db) do n = n + 1 if n >= ns.INVITES_MAX then return false end end
    list = {}
    db[recruit] = list
  end
  for _, e in ipairs(list) do
    if type(e) == "table" and e.by == by then
      -- The same invite read again lands within the log's hour; a re-invite later is newer news for the bot.
      if math.abs((tonumber(e.at) or 0) - at) <= 2 * HOUR then
        e.at = math.min(tonumber(e.at) or at, at)
        return false
      end
      if at > (tonumber(e.at) or 0) then e.at = at return true end
      return false
    end
  end
  list[#list + 1] = { by = by, at = math.floor(at) }
  table.sort(list, function(a, b) return (tonumber(a.at) or 0) > (tonumber(b.at) or 0) end)
  while #list > ns.INVITES_PER_RECRUIT do table.remove(list) end
  return true
end
-- Copy the invites in the event log the server last sent. Returns how many were new.
function ns.ReadInviteLog()
  if not (UW_GuildDB and ns.tracksGuild()) then return 0 end
  local count, info = GetNumGuildEvents, GetGuildEventInfo
  local status = { at = time(), api = type(count) == "function" and type(info) == "function" }
  UW_GuildDB.inviteLog = status
  if not status.api then return 0 end
  local ok, n = pcall(count)
  n = ok and plainNum(n) or 0
  local now, seen, new = time(), 0, 0
  for i = 1, math.min(n, 500) do
    local okI, kind, p1, p2, _, y, mo, d, h = pcall(info, i)
    if okI and kind == "invite" and not ns.isSecret(kind) then
      seen = seen + 1
      local ago = ((plainNum(y) * 365 + plainNum(mo) * 30 + plainNum(d)) * 24 + plainNum(h)) * HOUR
      if ns.NoteInvite(p2, p1, now - ago) then new = new + 1 end
    end
  end
  status.read, status.invites, status.new = n, seen, new
  if ns.ReadGuildLog then ns.protect(ns.ReadGuildLog, n) end
  return new
end

-- The whole guild event log, for years of trends (logging, 16 Nov 2026; addon search shortlist 6): when people
-- join, quit or are removed, and promotions and demotions, from the game's own record rather than a roster read that
-- only happens while an officer plays. The log keeps only its latest entries and says "N hours ago", so each entry is
-- copied once into UW_GuildDB.guildLog.ev (newest first, at most GUILDLOG_MAX, GUILDLOG_DAYS days) as its kind, a
-- hash of its names (never the names) and the time of its first read, which never moves afterwards: an entry read
-- again within 2 hours of that time, with the same kind and hash, is the same one (two alike in one read stay two). Each new entry also adds 1 to days[UTC day][kind],
-- the only part the bot copies (bot/uwbot/history.py, ev.*: counts, never names). Officers' clients only (the bot
-- reads the Guild Master's save); read only: nothing is sent, whispered or posted.
ns.GUILDLOG_MAX, ns.GUILDLOG_DAYS = 300, 120
ns.GUILDLOG_KINDS = { invite = true, join = true, quit = true, remove = true, promote = true, demote = true }
local function logName(v)
  return type(v) == "string" and not ns.isSecret(v) and v ~= "" and v:lower() or ""
end
-- A 32-bit hash of the entry's two names (djb2, exact in Lua 5.1's doubles): enough to tell entries apart, and no
-- name is kept at all (integrator, 16 Nov 2026: a member's /uw-privacy delete can't reach an officer's save).
local function nameHash(a, b)
  local h = 5381
  local str = a .. "\0" .. b
  for k = 1, #str do h = (h * 33 + str:byte(k)) % 4294967296 end
  return h
end
ns.NameHash = nameHash   -- Bank.lua tells gifts apart by it once a giver's name is gone
function ns.ReadGuildLog(n)
  if not (UW_GuildDB and ns.tracksGuild() and ns.isOfficer(ns.me())) then return 0 end
  local info = GetGuildEventInfo
  if type(info) ~= "function" then return 0 end
  local g = type(UW_GuildDB.guildLog) == "table" and UW_GuildDB.guildLog or {}
  UW_GuildDB.guildLog = g
  g.ev = type(g.ev) == "table" and g.ev or {}
  g.days = type(g.days) == "table" and g.days or {}
  local now, claimed, added = time(), {}, 0
  local byKey = {}
  for idx, e in ipairs(g.ev) do
    if type(e) == "table" and type(e.k) == "string" and type(e.h) == "number" then
      local key = e.k .. "\0" .. e.h
      byKey[key] = byKey[key] or {}
      table.insert(byKey[key], idx)
    end
  end
  local fresh = {}
  for i = 1, math.min(plainNum(n), 500) do
    local okI, kind, p1, p2, _, y, mo, d, h = pcall(info, i)
    if okI and type(kind) == "string" and not ns.isSecret(kind) and ns.GUILDLOG_KINDS[kind] then
      local hash = nameHash(logName(p1), logName(p2))
      local at = now - ((plainNum(y) * 365 + plainNum(mo) * 30 + plainNum(d)) * 24 + plainNum(h)) * HOUR
      local key, match = kind .. "\0" .. hash, nil
      for _, idx in ipairs(byKey[key] or {}) do
        if not claimed[idx] and math.abs((tonumber(g.ev[idx].at) or 0) - at) <= 2 * HOUR then match = idx break end
      end
      if match then
        claimed[match] = true
      else
        fresh[#fresh + 1] = { k = kind, h = hash, at = math.floor(at) }
      end
    end
  end
  local oldest = now - ns.GUILDLOG_DAYS * 86400
  for _, e in ipairs(fresh) do
    if e.at >= oldest then
      g.ev[#g.ev + 1] = e
      local day = date and date("!%Y%m%d", e.at)
      if day then
        local c = type(g.days[day]) == "table" and g.days[day] or {}
        g.days[day] = c
        c[e.k] = (tonumber(c[e.k]) or 0) + 1
      end
      added = added + 1
    end
  end
  if added > 0 then
    table.sort(g.ev, function(x, y) return (tonumber(x.at) or 0) > (tonumber(y.at) or 0) end)
  end
  for i = #g.ev, 1, -1 do
    local e = g.ev[i]
    if i > ns.GUILDLOG_MAX or type(e) ~= "table" or (tonumber(e.at) or 0) < oldest then table.remove(g.ev, i) end
  end
  local cut = date and date("!%Y%m%d", oldest)
  for day in pairs(g.days) do if type(day) ~= "string" or (cut and day < cut) then g.days[day] = nil end end
  g.at, g.read, g.new = now, plainNum(n), added
  return added
end
local INVITED = ERR_GUILD_INVITE_S
  and "^" .. ERR_GUILD_INVITE_S:gsub("[%%%(%)%.%+%-%*%?%[%]%^%$]", "%%%0"):gsub("%%%%s", "(.+)") .. "$"
local logFrame = CreateFrame("Frame")
do -- only events this client has (RegisterEvent throws on an unknown one; ns.listen loads later, in Crafts.lua)
  local valid = C_EventUtils and C_EventUtils.IsEventValid
  for _, e in ipairs({ "GUILD_EVENT_LOG_UPDATE", "CHAT_MSG_SYSTEM" }) do
    if not valid or valid(e) then pcall(logFrame.RegisterEvent, logFrame, e) end
  end
end
local function askLog() if type(QueryGuildEventLog) == "function" then pcall(QueryGuildEventLog) end end
logFrame:SetScript("OnEvent", ns.guard(function(_, event, msg)
  if not UW_GuildDB then return end
  if event == "GUILD_EVENT_LOG_UPDATE" then ns.protect(ns.ReadInviteLog) return end
  if type(msg) ~= "string" or ns.isSecret(msg) then return end
  local who = INVITED and msg:match(INVITED)
  if who and ns.tracksGuild() then
    ns.NoteInvite(who:gsub("|Hplayer:[^|]*|h%[?([^%]|]*)%]?|h", "%1"), ns.me(), time())
  elseif JOINED and msg:match(JOINED) then
    ns.after(5, askLog) -- the invite is in the log by now; read it before a busy night pushes it out
  end
end))
-- At login, once the roster is known (tracksGuild needs it). ReadInviteLog also runs now, so a client whose
-- QueryGuildEventLog never answers still records what it can (its status says api true, read 0).
table.insert(ns.onLoad, function()
  ns.afterRoster(function() askLog(); ns.after(10, function() ns.protect(ns.ReadInviteLog) end) end)
end)

-- Whisper words ---------------------------------------------------------------------
-- Most of the guild plays without UW_Guild or Discord (8 Nov 2026: 137 of 149), so whispering an officer is their
-- only way in. Next to "raid" (Charter.lua) and "clear note" (Crafts.lua), an officer's UW_Guild answers:
--   help          one line naming every whisper word
--   idea <text>   (or feedback, suggestion, bug) to the officers: the Guild Master's save carries it to #officer-inbox
--   stop | start  no more automatic whispers from any officer's UW_Guild (Discord ask, professions ask and nudge,
--                 charter, Raider welcome), and back on. Replies to a member's own whisper still answer.
-- Pull only: nothing is said unless a member whispers first. Each answer says where the words go (CONTRIBUTING.md,
-- "Never quietly turn chat into data"). An idea never goes out on GUILD, which every UW_Guild hears: the officer who
-- got it whispers it to the Guild Master's client (IDA). Officers share "stop" as QWS and catch up at login (QWQ/QWL).
ns.IDEA_MAX, ns.IDEA_PER_DAY, ns.QUIET_SHARE = 200, 3, 40
local IDEA = { idea = true, ideas = true, feedback = true, suggestion = true, suggest = true, bug = true }
local function words(msg)
  if type(msg) ~= "string" or ns.isSecret(msg) or #msg > 255 then return nil end
  local first, rest = strtrim(msg):match("^(%S+)%s*(.-)$")
  if not first then return nil end
  return first:lower():gsub("[%p]+$", ""), rest
end
-- The word a whisper starts with when it is one of ours ("help", "idea", "stop", "start"), else nil. Crafts.lua asks
-- first, so "idea mining night" never reads as a professions reply.
function ns.WhisperWord(msg)
  local w, rest = words(msg)
  if not w then return nil end
  if IDEA[w] then return "idea" end
  if rest == "" and (w == "help" or w == "stop" or w == "start") then return w end
  if ns.DungeonWord and ns.DungeonWord(msg) then return "dungeon" end -- QuestChain.lua: "wc" gets the quests to grab
  return nil
end

local function quietDB()
  UW_GuildDB.quiet = type(UW_GuildDB.quiet) == "table" and UW_GuildDB.quiet or {}
  return UW_GuildDB.quiet
end
-- True when this guildmate whispered "stop": every automatic whisper checks it first.
function ns.quiet(name)
  local key = name and askKey(name)
  return key ~= nil and UW_GuildDB ~= nil and type(UW_GuildDB.quiet) == "table" and UW_GuildDB.quiet[key] ~= nil
end
local function setQuiet(key, on, at)
  local q = quietDB()
  if on then q[key] = q[key] or at else q[key] = nil end
end

local function guildMaster()
  for i = 1, GetNumGuildMembers() or 0 do
    local full, _, rank = GetGuildRosterInfo(i)
    if rank == 0 and full then return ns.fullName(full) end
  end
end
local function isGM()
  if IsGuildLeader then return IsGuildLeader() == true end
  return guildMaster() == ns.me()
end
local function keepIdea(name, text)
  if ns.queue then ns.queue("idea", name, text) end
  say(("Idea from %s, kept for #officer-inbox: %s"):format(name, text))
end

ns.HELP_WHISPER = "Hey! Happy to help with a dungeon group, quests or professions, just ask. Whisper a dungeon like "
  .. "wc for its quests, idea plus your idea, clear note, or stop to pause my addon's whispers."   -- no raid line (9 Nov)
local lastWord, ideasToday, lastDungeon = {}, {}, {}
ns.DUNGEON_ANSWER_EVERY = 600 -- seconds between dungeon-list answers to one member for one dungeon
local function answer(to, msg) return ns.chat("whisper.reply", msg, "WHISPER", to) end

function ns.WhisperWords(msg, sender)
  local self = ns.me()
  if not (self and ns.isOfficer(self)) or type(sender) ~= "string" or ns.isSecret(sender) then return false end
  local w = ns.WhisperWord(msg)
  if not w or not ns.inRoster(sender) then return false end
  local key, at = askKey(sender), serverNow()
  if not key or key == ns.shortName(self) then return false end
  if lastWord[key] and at - lastWord[key] < 5 then return true end
  lastWord[key] = at
  local first = key:match("^(%S+)") or key
  if w == "help" then
    answer(sender, ns.HelpWhisper(key))
  elseif w == "dungeon" then
    local d = ns.DungeonWord(msg)
    -- Once per member per dungeon every 10 minutes (red team R8, 8 Nov): a repeat gets nothing.
    local again = key .. "\t" .. d[1]
    if lastDungeon[again] and at - lastDungeon[again] < ns.DUNGEON_ANSWER_EVERY then return true end
    lastDungeon[again] = at
    local lines, got = ns.DungeonWhisperLines(d)
    local went = false
    for _, line in ipairs(lines) do went = answer(sender, line) == true or went end
    -- The status line says what was really sent (journeys re-walk, 8 Nov: it claimed a list when the data was unread;
    -- since 9 Nov whisper answers are off, so it says nothing went and the officer can answer by hand).
    if not went then
      say(("%s asked for the %s quests. Whisper answers are off, so nothing was sent."):format(key, d[1]))
    elseif got == "list" then
      say(("Sent %s the %s quest list they asked for."):format(key, d[1]))
    elseif got == "unread" then
      say(("Couldn't read Questie's data for %s; %s was told to ask in guild chat."):format(d[1], key))
    else
      say(("No %s quests listed; %s was told to ask in guild chat."):format(d[1], key))
    end
    if ns.trace then ns.protect(ns.trace, "whisper", "dungeon quests", went and got == "list", d[1] .. " " .. (went and tostring(got) or "held"), key) end
  elseif w == "stop" or w == "start" then
    setQuiet(key, w == "stop", at)
    ns.officerSend(("QWS\t%s\t%s\t%d"):format(key, w == "stop" and "1" or "0", at), "GUILD")
    say(("%s whispered %s: UW_Guild's automatic whispers to them are %s."):format(key, w, w == "stop" and "off" or "on"))
    answer(sender, w == "stop"
      and ("Done, %s: no more automatic whispers from my addon. Whisper start to undo."):format(first)
      or "You're back on. Whisper stop anytime.")
  else
    local text = strtrim((select(2, words(msg))))
    if #text < 3 then
      answer(sender, "Whisper idea plus your idea in one line, like: idea a fishing night on Sundays")
      return true
    end
    local day = date("!%Y-%m-%d", at)
    local n = ideasToday[key] and ideasToday[key].day == day and ideasToday[key].n or 0
    if n >= ns.IDEA_PER_DAY then
      answer(sender, "Got it, thanks! That's a lot for one day, so this one stays with me.")
      return true
    end
    ideasToday[key] = { day = day, n = n + 1 }
    text = text:sub(1, ns.IDEA_MAX)
    if isGM() then
      keepIdea(key, text)
    else
      say(("Idea from %s: %s"):format(key, text))
      local gm = guildMaster()
      local head = ("IDA\t%s\t%d\t"):format(key, at)
      if gm then ns.officerSend(head .. text:gsub("\t", " "):sub(1, 250 - #head), "WHISPER", gm) end
    end
    answer(sender, ("Thanks %s! Sharing it with the officers, with your name so we can follow up."):format(first))
  end
  return true
end

-- Reach (Louis's priority order, approved 8 Nov 23:22: the addon at 10% of active players). A member's first "help"
-- carries the install page inside the same reply, never as a second whisper (two back to back read as "oh my").
-- Once per member, only to one whose client has never sent UW_Guild traffic (UW_GuildDB.members[name].addon). The
-- variant drops "clear note" and the raid line to fit one whisper. Nothing unasked; "wc" gets nothing added.
ns.HELP_WHISPER_INSTALL = "Hey! Happy to help with a dungeon group, quests or professions, just ask. Whisper a dungeon "
  .. "like wc for its quests, idea plus your idea, or stop to pause my whispers. Our addon, one click: " .. ns.ADDON_URL
function ns.HelpWhisper(key)
  local m = key and type(UW_GuildDB.members) == "table" and UW_GuildDB.members[key]
  if not key or ns.quiet(key) or (type(m) == "table" and m.addon ~= nil) then return ns.HELP_WHISPER end
  UW_GuildDB.installTold = type(UW_GuildDB.installTold) == "table" and UW_GuildDB.installTold or {}
  if UW_GuildDB.installTold[key] then return ns.HELP_WHISPER end
  UW_GuildDB.installTold[key] = serverNow()
  if ns.trace then ns.protect(ns.trace, "whisper", "install line", true, nil, key) end
  return ns.HELP_WHISPER_INSTALL
end

ns.handlers.IDA = function(sender, channel, name, at, text)
  if channel ~= "WHISPER" or not ns.isOfficer(sender) or not isGM() then return end
  at = tonumber(at)
  if type(name) ~= "string" or #name > 60 or not ns.inRoster(name) or not at or type(text) ~= "string" then return end
  text = strtrim(text):sub(1, ns.IDEA_MAX)
  if #text >= 3 then keepIdea(askKey(name) or name, text) end
end
ns.handlers.QWS = function(sender, channel, name, on, at)
  if channel ~= "GUILD" or not ns.isOfficer(sender) or ns.fullName(sender) == ns.me() then return end
  local key = type(name) == "string" and #name <= 60 and askKey(name)
  if key then setQuiet(key, on == "1", tonumber(at) or time()) end
end
-- An officer logging in asks the others for their "stop" list (QWQ); each answers with up to QUIET_SHARE names.
ns.handlers.QWQ = function(sender, channel)
  if channel ~= "GUILD" or not ns.isOfficer(sender) or ns.fullName(sender) == ns.me() or not ns.isOfficer(ns.me()) then
    return
  end
  local names = {}
  for k in pairs(quietDB()) do
    if #names >= ns.QUIET_SHARE then break end
    names[#names + 1] = k
  end
  if #names > 0 then
    table.sort(names)
    ns.catchUpSend("QWL\t" .. table.concat(names, ","), "WHISPER", ns.fullName(sender) or sender)
  end
end
ns.handlers.QWL = function(sender, channel, list)
  if channel ~= "WHISPER" or not ns.isOfficer(sender) or type(list) ~= "string" then return end
  for name in list:gmatch("[^,]+") do
    local key = #name <= 60 and askKey(name)
    if key then setQuiet(key, true, time()) end
  end
end

local wordFrame = CreateFrame("Frame")
do -- as ns.listen (defined later, in Crafts.lua): a client without the event must not stop this file
  local valid = C_EventUtils and C_EventUtils.IsEventValid
  if not valid or valid("CHAT_MSG_WHISPER") then pcall(wordFrame.RegisterEvent, wordFrame, "CHAT_MSG_WHISPER") end
end
wordFrame:SetScript("OnEvent", ns.guard(function(_, _, msg, sender)
  if UW_GuildDB then ns.protect(ns.WhisperWords, msg, sender) end
end))

-- First guild group -----------------------------------------------------------
-- Each member's client announces its first group with a guildmate as GRP\t<server time of that group>,
-- then again on every login, and whenever an officer logs in and asks (GRPQ), for GRP_RESEND_DAYS.
-- Whoever runs the bridge then records it even if they were offline when it happened. Receivers keep
-- the earliest time, for the "grouped within 72h" retention metric.
local function guildmatesInGroup()
  local n, count = GetNumGroupMembers(), 0
  local prefix = IsInRaid() and "raid" or "party"
  local last = IsInRaid() and n or n - 1
  for i = 1, last do
    local unit = prefix .. i
    if not UnitIsUnit(unit, "player") and UnitIsInMyGuild(unit) then count = count + 1 end
  end
  return count
end

-- Sends GRP while the first group is recent. True when it was sent.
local function announceGroup()
  local t = UW_GuildCharDB.firstGuildGroup
  if not t or not IsInGuild() or serverNow() - t > ns.GRP_RESEND_DAYS * 86400 then return false end
  return ns.send("GRP\t" .. t, "GUILD")
end

local function checkFirstGroup()
  local c = UW_GuildCharDB
  if c.groupAnnounced or not IsInGuild() or not IsInGroup() then return end
  if guildmatesInGroup() == 0 then return end
  c.firstGuildGroup = c.firstGuildGroup or serverNow()
  if announceGroup() then c.groupAnnounced = true end -- retried on the next roster change if blocked
end

-- GUILD at the group and on login; WHISPER in answer to our GRPQ, so only guildmates in the roster count.
ns.handlers.GRP = function(sender, channel, at)
  if channel ~= "GUILD" and not (channel == "WHISPER" and ns.inRoster(sender)) then return end
  if not ns.tracksGuild() then return end -- an alt's other guild isn't ours
  sender = ns.shortName(sender)
  local m = UW_GuildDB.members[sender]
  if not m then return end
  -- Older clients send a bare GRP: that means "just now". So does a time from a badly set clock. The time
  -- is the realm's, so it is checked against the realm's clock, not this PC's.
  local now, t = serverNow(), ns.finite(at) -- "nan" would otherwise slip past both bounds below
  if not t or t > now + 600 or t < now - (ns.GRP_RESEND_DAYS + 1) * 86400 then t = now end
  t = math.floor(t)
  local isNew = not m.firstGroup
  if isNew or t < m.firstGroup then m.firstGroup = t end
  -- Veterans also announce after installing; only recruits' first groups are news. Repeats aren't.
  if isNew and ns.isRecruit(sender) then ns.queue("group", sender) end
end

-- An officer logging in asks recent first groups to speak up; each client answers at most every 5 min.
-- The answer is whispered to that officer: at launch nearly everyone grouped this week, and a GUILD answer
-- would send every member's reply to every client. Anyone else online then heard it when it was new.
local lastGroupReply -- nil, not 0: GetTime() counts from PC boot, so 0 would ignore GRPQs for 5 minutes
ns.handlers.GRPQ = function(sender, channel)
  if channel ~= "GUILD" or not ns.isOfficer(sender) then return end
  if lastGroupReply and GetTime() - lastGroupReply < 300 then return end
  local t = UW_GuildCharDB.firstGuildGroup
  if not t or serverNow() - t > ns.GRP_RESEND_DAYS * 86400 then return end
  lastGroupReply = GetTime()
  ns.after(1 + math.random() * 4, function() ns.send("GRP\t" .. t, "WHISPER", sender) end) -- jitter
end

-- HI\tversion on login: lets every client see who runs UW_Guild (Core records members[name].addon).
-- A newer UW_Guild: versions are the UTC date and time of the addon's last change, then its commit
-- (2026.11.08.1446-2036369, bot addonzip.py; builds before 8 Nov 2026 had no time: 2026.11.03-36e763f). A guildmate's
-- login HI with a later one means ours is out of date (after a break, or a missed update). The time orders the
-- several builds of one day; clients from before it compare the date only. Told once a session, and only once two
-- guildmates run a newer one: the officer PC runs each deploy before the download page has it, so one alone would
-- send members to a page that still has their version. A date more than a day past the realm's today is ignored, and
-- so is a dev build. /uw version shows ours and the newest seen.
local function versionKey(v)
  local y, m, d = tostring(v or ""):match("^(%d%d%d%d)%.(%d%d)%.(%d%d)")
  if not y then return nil end
  local hm = tostring(v):match("^%d%d%d%d%.%d%d%.%d%d%.(%d%d%d%d)%-") or "0000"
  return tonumber(y .. m .. d) * 10000 + tonumber(hm), tonumber(y .. m .. d)
end
-- The Windows one-button setup (site/UW-Guild-Setup.cmd) writes "## X-UW-Updater: <date>" into the TOC it installs:
-- that copy updates itself while WoW is closed, so its members never need a link.
local function hasUpdater()
  local v = C_AddOns.GetAddOnMetadata("UW_Guild", "X-UW-Updater")
  return type(v) == "string" and v:match("^%d") ~= nil
end
ns.hasUpdater = hasUpdater
-- The early ring (release rings, 16 Nov 2026): the early download (build_site.py early_files) writes
-- "## X-UW-Ring: early" into its TOC. An early copy adds "early" to its HI, and every other copy leaves it out of the
-- newer count: members get a build only after it has run 48 hours with no new error, so two testers on it would send
-- members to a page that doesn't have it yet. The officer PC (ns.SyncBotPC) runs every build first, so its characters
-- say "early" too. Early copies still count each other. Older copies ignore the extra field.
local function isEarly()
  return C_AddOns.GetAddOnMetadata("UW_Guild", "X-UW-Ring") == "early"
end
ns.isEarly = isEarly
local function ahead() return isEarly() or (ns.SyncBotPC ~= nil and ns.SyncBotPC()) end
local STUCK_DAYS = 3
local newerTold = false
local newestSeen, newestFrom
local newerFrom, newerCount = {}, 0
local function noteNewer(ver, sender)
  local theirs, theirDay = versionKey(ver)
  local ours = versionKey(ns.VERSION)
  if not (theirs and ours) or theirs <= ours then return end
  local today = date and tonumber(date("!%Y%m%d", (GetServerTime and GetServerTime() or time()) + 86400))
  if today and theirDay > today then return end
  if not newestSeen or theirs > versionKey(newestSeen) then newestSeen, newestFrom = ver, sender end
  if sender and not newerFrom[sender] then newerFrom[sender], newerCount = true, newerCount + 1 end
  if newerTold or newerCount < 2 then return end
  newerTold = true
  local v = newestSeen:match("^[%d%.]+")
  -- How long this build has known it's behind, not how old it is: a member back from a break starts WoW before the
  -- updater's catch-up run can install, and that's healthy (hardening, 8 Nov 2026). Reset with each new build.
  local since = UW_GuildDB.newerSince
  if type(since) ~= "table" or since.ver ~= ns.VERSION then
    since = { ver = ns.VERSION, at = time() }
    UW_GuildDB.newerSince = since
  end
  if hasUpdater() and time() - (tonumber(since.at) or time()) >= STUCK_DAYS * 86400 then
    -- Days of closed-WoW time without an install means it stopped (a new site key, a moved WoW folder): the one
    -- thing that fixes it is running the setup again.
    say(("Your automatic updates look stuck (UW_Guild %s is out). Run the setup again from %s"):format(v,
      ns.ADDON_URL))
  elseif hasUpdater() then
    say(("A newer UW_Guild (%s) is out. It installs itself the next time WoW is closed."):format(v))
  else
    say(("A newer UW_Guild (%s) is out. One button installs it and every update after: %s"):format(v, ns.ADDON_URL))
  end
end

-- Members on a hand install (the zip) hear once a week, three times at most, that one button would keep them current
-- (Louis, 8 Nov 2026: one button to install and update, minimal asks). Never on a Mac (the setup is Windows only),
-- the officer PC (the bot installs every build there), an unstamped copy, or a fresh install's first day.
local NUDGE_MAX, NUDGE_GAP = 3, 7 * 86400
local function updaterNudge()
  if hasUpdater() or ns.VERSION == "dev" then return end
  if IsMacClient and IsMacClient() then return end
  if ns.SyncBotPC and ns.SyncBotPC() then return end
  local now = time()
  local at = tonumber(UW_GuildDB.installedAt) or 0
  if at > 0 and now - at < 86400 then return end
  local n = type(UW_GuildDB.updaterNudge) == "table" and UW_GuildDB.updaterNudge or {}
  local count = tonumber(n.count) or 0
  if count >= NUDGE_MAX or now - (tonumber(n.at) or 0) < NUDGE_GAP then return end
  UW_GuildDB.updaterNudge = { count = count + 1, at = now }
  say(("Skip manual updates: %s, Install for Windows. One click, then UW_Guild updates itself."):format(
    ns.ADDON_URL))
end
ns.updaterNudge = updaterNudge

ns.handlers.HI = function(sender, channel, ver, ring)
  if channel ~= "GUILD" or not ns.tracksGuild() then return end
  local m = UW_GuildDB.members[ns.shortName(sender)]
  if type(ver) == "string" then
    ver = ver:gsub("[^%w%.%-]", ""):sub(1, 24)
    if m then m.addonVer = ver end
    if ring == "early" and not ahead() then return end
    noteNewer(ver, ns.shortName(sender))
  end
end

-- /uw version: which UW_Guild this is, so a member can match it against the download page's "Latest version".
ns.commands.version = function()
  say(("UW_Guild %s. The newest is on %s: if its version matches this one, you're up to date."):format(
    ns.VERSION, ns.ADDON_URL))
  if hasUpdater() then say("Automatic updates: on (it installs new versions while WoW is closed).") end
  if newestSeen then
    say(("%s runs a newer one (%s) this session: download it again from that page."):format(
      newestFrom or "A guildmate", newestSeen))
  end
end

-- Welcome back: a player logging in after two weeks or more away gets one line: whether the addon kit needs
-- updates after the break, and what /uw-me in Discord shows (a break set there ends with its I'm back button).
-- UW_GuildDB.lastOn is this WoW account's last login in our guild, on any character, so an alt that sat idle while
-- its main played says nothing. A fresh install has none, so it says nothing either.
function ns.WelcomeBack(now)
  local last = ns.finite(UW_GuildDB.lastOn)
  UW_GuildDB.lastOn = now
  if not last or now - last < ns.RETURN_DAYS * 86400 then return end
  local missReq, _, conflicts = ns.CheckKit()
  local fixes = #missReq + #conflicts
  local kit = fixes == 0 and "Your addon kit is ready."
    or ("/uw kit shows %d addon fix%s."):format(fixes, fixes == 1 and "" or "es")
  say(("Welcome back after %d days! %s In Discord, /uw-me shows your next rank, and I'm back ends a break.")
    :format(math.floor((now - last) / 86400), kit))
end

-- /uw near --------------------------------------------------------------------
-- The guildmates online within NEAR_RANGE levels of this character, and this character's level: each { full, name,
-- level, zone, busy ("away", "busy" or nil), cls }. nil outside a guild. One list for /uw near's lines in chat and
-- for the same people as a table in the UW Guild window (Handbook.lua), so the two never disagree.
function ns.Near()
  if not IsInGuild() then return nil end
  local myLevel, self, rows = UnitLevel("player"), me(), {}
  for i = 1, GetNumGuildMembers() do
    local full, _, _, level, _, zone, _, _, online, status, cls = GetGuildRosterInfo(i)
    if online and full and level then
      local name = Ambiguate(full, "none")
      if name ~= self and math.abs(level - myLevel) <= ns.NEAR_RANGE then
        rows[#rows + 1] = { full = full, name = name, level = level, zone = zone or "?", busy = ns.RosterBusy(status, zone),
          cls = cls }
      end
    end
  end
  -- Free first: an AFK, Do Not Disturb or mid-dungeon guildmate goes to the end of the list, marked, never hidden.
  table.sort(rows, function(a, b)
    if (a.busy ~= nil) ~= (b.busy ~= nil) then return a.busy == nil end
    local da, db = math.abs(a.level - myLevel), math.abs(b.level - myLevel)
    if da ~= db then return da < db end
    return a.name < b.name
  end)
  return rows, myLevel
end
ns.commands.near = function()
  local rows, myLevel = ns.Near()
  if not rows then say("Join Unbothered Warlords to see guildmates near your level.") return end
  if #rows == 0 then say(("No guildmates online within %d levels. Ask in guild chat, or #lfg-dungeons on Discord."):format(ns.NEAR_RANGE)) return end
  -- "in chat": the guide shows this answer too, and a name can only be clicked in chat (render crawl, 13 Nov 2026).
  say(("%d %s near level %d. Click a name in chat to whisper or invite:"):format(#rows,
    #rows == 1 and "guildmate" or "guildmates", myLevel))
  -- One block under one tag (Core.lua say). Chat fonts are proportional, so nothing can line up by spaces: the level,
  -- the short part, leads (padded to two digits' width) and the name and zone, which vary, follow. A free guildmate's
  -- name wears their class colour; a busy or away one's whole line is grey (aesthetic pass, 14 Nov 2026).
  local classes = type(_G.RAID_CLASS_COLORS) == "table" and _G.RAID_CLASS_COLORS or {}
  for i = 1, math.min(#rows, 15) do
    local r = rows[i]
    local lvl = (r.level < 10 and "  " or "") .. r.level
    if r.busy then
      say(("|cff808080%s  |Hplayer:%s|h[%s]|h  %s  (%s)|r"):format(lvl, r.full, r.name, r.zone, r.busy))
    else
      local c = r.cls and classes[r.cls]
      local hex = c and type(c.colorStr) == "string" and c.colorStr or "ffffffff"
      say(("%s  |c%s|Hplayer:%s|h[%s]|h|r  %s"):format(lvl, hex, r.full, r.name, r.zone))
    end
  end
end

-- Welcome panel ---------------------------------------------------------------
-- The first-run window (design director's spec, section 7 and board 1; Louis, 14 Nov 2026: "Build the addon!"). It
-- was about 160 words in seven gold-labelled paragraphs of equal weight over three equal buttons. Now, top to bottom:
-- the art with the crest standing up into it, the motto, what's already helping you as icons, the norms with their
-- numbers in the margin, the one line on who to ask, and one red button. What left it lives in the guide (Handbook.lua):
-- the Discord invite and /link steps are the Guild page's Discord row, the Guild Master's BattleTag its Contact row,
-- the addon kit and the quest arrow their own rows.
local panel

-- What UW_Guild already does for this player, said first (fresh-member audit, 10 Nov 2026: the window never said,
-- while gear, bars, Space and bag Delete were already at work). Only helpers that are on are named: each is a cell
-- with the guide's picture for that helper (Handbook.lua ns.HANDBOOK_ICONS) and its phrase.
ns.WELCOME_HELPERS = {
  { "gear", "Clear gear upgrades go on" },
  { "bars", "New spells land on your bars" },
  { "space", "Space uses quest items" },
  { "bags", "Delete drops your cheapest bag junk" },
}
-- The stated way out of each of them, in grey under the cells.
ns.WELCOME_WHERE = "Switch any off in Esc > Options > AddOns > UW Guild."
local function isOn(sw)
  if not sw then return true end
  local ok, v = pcall(sw.on)
  return not ok or v and true or false
end
-- The helpers that are on, in the list's order: { key, phrase } each.
function ns.WelcomeHelpers()
  local on, byKey = {}, {}
  for _, sw in ipairs(ns.OPTION_SWITCHES or {}) do byKey[sw.key] = sw end
  for _, h in ipairs(ns.WELCOME_HELPERS) do
    if isOn(byKey[h[1]]) then on[#on + 1] = h end
  end
  return on
end
-- Raid-night norms are for raiders: a level-6 Trial reads them as homework (fresh-member audit). Raider rank and up,
-- or level 50 and up, see them, numbers kept.
ns.RAID_NORMS_LEVEL = 50
local function raidNormsFor()
  if ns.canShareRaid and ns.canShareRaid(me()) then return true end
  return (tonumber((UnitLevel("player"))) or 0) >= ns.RAID_NORMS_LEVEL
end
ns.RaidNormsFor = raidNormsFor

-- The welcome in its blocks, top to bottom: what's already helping you, the norms, who to ask. A block is drawn as
-- one piece and a page never cuts one. Where the raid-night norms show they are a block of their own that carries
-- the norms on (soft: its number): it sits close under them, and a page may turn before it (14 Nov 2026: on a
-- 1440x900 screen at UI scale 1.15 the norms whole filled a page by themselves). Each block: kind, and what it
-- holds of label (drawn in capitals), values, cells, norms ({ number, text } each), note (its closing line), text.
local function welcomeBlocks()
  local own, raid = {}, {}
  for _, n in ipairs(ns.NORMS) do
    local list = ns.RAID_NORMS[n[1]] and raid or own
    list[#list + 1] = n
  end
  local blocks, soft = {
    { kind = "helpers", label = "Already helping you", cells = ns.WelcomeHelpers(), note = ns.WELCOME_WHERE },
    -- The norms in #welcome-rules order, a dot in the margin for each. Under them, the line Louis put in this window
    -- on purpose (8 Nov 2026: a brand-new member reads it with the norms).
    { kind = "norms", label = "Our norms", values = table.concat(ns.VALUES, " · "), norms = own, note = ns.FREE_HELP },
  }, nil
  if raidNormsFor() then
    blocks[#blocks + 1] = { kind = "raid", label = "Raid nights", norms = raid }
    soft = #blocks
  end
  local pair, who = UW_GuildDB.buddies[me()]
  if pair then
    who = ("|cffffd100Your buddy:|r %s. Whisper them to group up."):format(pair.buddy)
  -- Never a promise of a pairing (fresh-member audit, 10 Nov 2026: few newcomers got a buddy; coordinator, 13 Nov:
  -- nobody does the pairing, and the guild message of the day stopped offering it). A newcomer is pointed at guild
  -- chat, where groups form; everyone else at the newcomers' asks there.
  elseif ns.isRecruit(me()) or ns.isLowestRank(me()) then -- new invites land in the lowest rank, beside social members
    who = "|cffffd100New here?|r Ask guild chat for a group anytime."
  else
    who = "|cffffd100Mentor a newcomer?|r Answer their asks in guild chat."
  end
  blocks[#blocks + 1] = { kind = "who", text = who }
  return blocks, soft
end
ns.WelcomeBlocks = welcomeBlocks
-- The whole text as one, a line each, top to bottom: what the window says.
local function welcomeText()
  local out = {}
  for _, b in ipairs(welcomeBlocks()) do
    if b.label and not (b.cells and #b.cells == 0) then
      out[#out + 1] = b.label .. (b.values and "  " .. b.values or "")
    end
    for _, c in ipairs(b.cells or {}) do out[#out + 1] = c[2] end
    for _, n in ipairs(b.norms or {}) do out[#out + 1] = "·  " .. n[2] end
    if b.note then out[#out + 1] = b.note end
    if b.text then out[#out + 1] = b.text end
  end
  return table.concat(out, "\n")
end
ns.welcomeText = welcomeText

-- The welcome window's sizes (ns.UI's numbers where it shares them, written out: Skin.lua loads after this file).
--   w, pad: its width, and the margin left and right of everything under the art.
--   art, banner, give: where the art starts under the title bar, how high it is, and how much of that it gives up
--     before the text turns a page (the smallest screen checked, 1440x900 at UI scale 1.15, has 467 px for the whole
--     window: a line that wraps there costs the art 14 px, not the reader a page).
--   bleed, flat: the art's inset from the window's left and right edge inside the game's border, and inside
--     EllesmereUI's flat one. row: the art's first row shown, of the file's 256. fade: the shade at its foot.
--   crest, lap: the crest, and how far it stands up into the art. under: from the art's foot to the first block
--     (the motto and subline sit between). top: where that puts the first block.
--   caps, label: a section label's height, and the gap under it.
--   colGap, cell, cellGap, icon, iconGap: the helpers' cells, two abreast: between the columns, a cell's height (two
--     lines of words), between two rows, the picture, between the picture and its words.
--   num, para, note: the norms: the number's column, between two norms, and over a block's closing line.
--   gap, join: between two blocks, a rule halfway; over the raid-night norms, which carry the norms on.
--   air, foot, btnGap, quiet, red: over the buttons, under them, between the two quiet ones, and each one's width.
--   cap: the most of the screen's height the window takes; a longer text turns pages (design pass, 13 Nov 2026: it
--     stood 600 high, 90% of that smallest screen, over the action bars). per, line: the letters a line of the
--     body's 12 font holds and the step from one line to the next, for a text the client can't measure yet.
ns.WELCOME = { w = 480, pad = 16, art = 26, banner = 104, give = 24, bleed = { 6, 8 }, flat = 1, row = 10, fade = 40,
  crest = 68, lap = 36, under = 50, caps = 10, label = 6, colGap = 12, cell = 28, cellGap = 4, icon = 24, iconGap = 8,
  num = 16, para = 6, note = 8, gap = 16, join = 8, air = 12, foot = 16, btnGap = 8, quiet = { 96, 64 }, red = 136,
  cap = 0.7, per = 64, line = 14 }
local WELCOME = ns.WELCOME
WELCOME.top = WELCOME.art + WELCOME.banner + WELCOME.under
WELCOME.cw = WELCOME.w - 2 * WELCOME.pad -- the blocks' width
-- A text's height: measured, or (a first show the client can't measure yet) on the ruler, or its lines counted.
-- live: the client measured it where it is.
local function textHeight(fs, text)
  local ok, h = pcall(fs.GetStringHeight, fs)
  h = ok and not ns.isSecret(h) and tonumber(h) or nil
  if h and h > 0 then return h, true end
  local UI = ns.UI
  return UI.TextHeight(fs, UI.Lines({ text }, 1, WELCOME.per) * WELCOME.line - UI.SPACING), false
end
-- The height the window may take: its share of the screen's (any height when the client won't say).
local function screenRoom()
  local ok, h = pcall(UIParent.GetHeight, UIParent)
  h = ok and not ns.isSecret(h) and tonumber(h) or nil
  return h and h > 0 and math.floor(h * WELCOME.cap) or math.huge
end
-- The blocks on each page, in order (a block is never split). Of every way to cut them: the one whose pages run
-- least past room (px), not at all where that can be; then the fewest pages; then the lowest tallest page, so two
-- pages come out even instead of a full one and a nearly empty one (render, 13 Nov 2026: a level 52's welcome was
-- 21 px over and left its last part alone on page two). soft: the block that carries on the one before it (the
-- raid-night norms): the two sit WELCOME.join apart on a page. A page may turn between them: the raid-night norms
-- have a label of their own, and that cut puts the norms everyone reads on page one (15 Nov 2026: kept whole, they
-- left what's helping you alone on a first page that was mostly empty). Each page: the numbers of its blocks, and
-- h, the height they take.
function ns.WelcomePages(heights, room, soft)
  local n = #heights
  local function tall(from, to)
    local h = 0
    for i = from, to do h = h + heights[i] + (i > from and (i == soft and WELCOME.join or WELCOME.gap) or 0) end
    return h
  end
  local best
  local function cut(from, pages, over, most)
    if from > n then
      -- A tie goes to the cut found later: the one with more on its earlier pages.
      if not best or over < best.over or (over == best.over and (#pages < #best.pages
        or (#pages == #best.pages and most <= best.most))) then
        best = { pages = { unpack(pages) }, over = over, most = most }
      end
      return
    end
    for to = from, n do
      local page = { h = tall(from, to) }
      for i = from, to do page[#page + 1] = i end
      pages[#pages + 1] = page
      cut(to + 1, pages, over + math.max(0, page.h - room), math.max(most, page.h))
      pages[#pages] = nil
    end
  end
  if n == 0 then return { { h = 0 } } end
  cut(1, {}, 0, 0)
  return best.pages
end

-- The art's place and cut. Its sides: inside the border the game's look draws, edge to edge in EllesmereUI's flat
-- shell; hung once a look (the skin arrives at login, after a window may have been built). Its cut: the file's art
-- is 512 wide, so a banner this wide and high shows that many of its rows, from the same first row.
local function cropArt(f)
  local rows = (WELCOME.banner - f.give) / f.artW * 512
  f.banner:SetTexCoord(0, 1, WELCOME.row / 256, (WELCOME.row + rows) / 256)
end
local function layArt(f)
  local skinned = ns.Skinned()
  if f.artAt == skinned then return end
  f.artAt = skinned
  local left = skinned and WELCOME.flat or WELCOME.bleed[1]
  local right = skinned and WELCOME.flat or WELCOME.bleed[2]
  f.banner:ClearAllPoints()
  f.banner:SetPoint("TOPLEFT", f, "TOPLEFT", left, -WELCOME.art)
  f.banner:SetPoint("TOPRIGHT", f, "TOPRIGHT", -right, -WELCOME.art)
  f.artW = WELCOME.w - left - right
  cropArt(f)
end
-- The art gives up px of its height (0: none): everything under it hangs from its foot, so nothing else is moved.
local function giveArt(f, px)
  if f.give == px then return end
  f.give = px
  f.banner:SetHeight(WELCOME.banner - px)
  f.head:SetHeight(WELCOME.banner - px)
  cropArt(f)
end

-- A section label (Skin.lua UI.Caps), at its block's top.
local function capsLabel(b)
  local fs = ns.UI.Caps(b)
  fs:SetPoint("TOPLEFT")
  return fs
end
-- A block: a frame as wide as the text, as high as what it holds (set on each show), a rule a half gap over it for
-- when another block stands above it on the page, and its closing line (each kind hangs its own).
local function newBlock(f, noteFont)
  local UI = ns.UI
  local b = CreateFrame("Frame", nil, f)
  b:SetSize(WELCOME.cw, 1)
  b.rule = UI.Rule(b, WELCOME.cw)
  b.rule:SetPoint("BOTTOMLEFT", b, "TOPLEFT", 0, WELCOME.gap / 2)
  b.note = noteFont and UI.Body(b, WELCOME.cw, noteFont) or false
  b:Hide()
  return b
end
-- Each kind of block: build makes its frame once; set fills it and returns its height, and whether the client
-- measured every text in it.
local BLOCK = {}
BLOCK.helpers = {
  build = function(f)
    local UI = ns.UI
    local b = newBlock(f, "GameFontDisable")
    b.note:SetPoint("BOTTOMLEFT") -- the cells over it are of one height: the block's foot is where they end
    b.label = capsLabel(b)
    b.cells = {}
    local cw = (WELCOME.cw - WELCOME.colGap) / 2
    for i = 1, #ns.WELCOME_HELPERS do
      local cell = CreateFrame("Frame", nil, b)
      cell:SetSize(cw, WELCOME.cell)
      cell:SetPoint("TOPLEFT", (i - 1) % 2 * (cw + WELCOME.colGap),
        -(WELCOME.caps + WELCOME.label + math.floor((i - 1) / 2) * (WELCOME.cell + WELCOME.cellGap)))
      cell.icon = UI.Icon(cell, WELCOME.icon)
      cell.icon:SetPoint("LEFT")
      cell.text = UI.Body(cell, cw, "GameFontHighlight") -- hung beside its picture on each show (set)
      b.cells[i] = cell
    end
    return b
  end,
  set = function(b, data)
    local UI = ns.UI
    local n, pictured = #data.cells, false
    local icons = ns.HANDBOOK_ICONS and ns.HANDBOOK_ICONS.entry or {}
    for i, cell in ipairs(b.cells) do
      local h = data.cells[i]
      cell:SetShown(h ~= nil)
      if h then
        cell.text:SetText(h[2])
        pictured = UI.IconSet(cell.icon, icons[h[1]]) or pictured
      end
    end
    -- The words stand clear of the pictures in every cell, or (a client with no picture for any) in none.
    local indent = pictured and WELCOME.icon + WELCOME.iconGap or 0
    if b.indent ~= indent then
      b.indent = indent
      for _, cell in ipairs(b.cells) do
        cell.text:ClearAllPoints()
        cell.text:SetPoint("LEFT", indent, 0)
        cell.text:SetWidth((WELCOME.cw - WELCOME.colGap) / 2 - indent)
      end
    end
    b.label:SetShown(n > 0)
    b.label:SetText(data.label:upper())
    b.note:SetText(data.note)
    local noteH, live = textHeight(b.note, data.note)
    -- With none on, the closing line alone, as it was.
    local rows = math.ceil(n / 2)
    local cells = n > 0 and WELCOME.caps + WELCOME.label + rows * WELCOME.cell + (rows - 1) * WELCOME.cellGap + WELCOME.note or 0
    return cells + noteH, live
  end,
}
-- The norms, and the raid-night ones in grey: a grey dot in the margin, each norm's words beside it.
local function buildNorms(f, font, noteFont)
  local b = newBlock(f, noteFont)
  b.label = capsLabel(b)
  b.rows, b.font = {}, font
  return b
end
local function setNorms(b, data)
  local UI = ns.UI
  b.label:SetText(data.label:upper() .. (data.values and "  " .. data.values or ""))
  local h, live = WELCOME.caps + WELCOME.label, true
  for i, n in ipairs(data.norms) do
    local row = b.rows[i]
    if not row then
      row = { text = UI.Body(b, WELCOME.cw - WELCOME.num, b.font), num = b:CreateFontString(nil, "OVERLAY", "GameFontDisable") }
      if i == 1 then row.text:SetPoint("TOPLEFT", WELCOME.num, -h)
      else row.text:SetPoint("TOPLEFT", b.rows[i - 1].text, "BOTTOMLEFT", 0, -WELCOME.para) end
      row.num:SetPoint("TOPLEFT", row.text, "TOPLEFT", -WELCOME.num, 0)
      b.rows[i] = row
    end
    row.num:SetText("·")
    row.text:SetText(n[2])
    local th, measured = textHeight(row.text, n[2])
    h, live = h + th + (i > 1 and WELCOME.para or 0), live and measured
  end
  for i = #data.norms + 1, #b.rows do b.rows[i].text:SetText("") b.rows[i].num:SetText("") end
  if b.note then
    b.note:SetText(data.note or "")
    -- Under the last norm, hung again only when their count changes: a height that had to be guessed, and came out
    -- a line high, then leaves its room under the closing line, never a hole between it and the norms.
    local last = #data.norms
    if b.noteAt ~= last then
      b.noteAt = last
      b.note:ClearAllPoints()
      if last > 0 then b.note:SetPoint("TOPLEFT", b.rows[last].text, "BOTTOMLEFT", -WELCOME.num, -WELCOME.note)
      else b.note:SetPoint("TOPLEFT", 0, -h) end
    end
    if data.note then
      local nh, measured = textHeight(b.note, data.note)
      h, live = h + WELCOME.note + nh, live and measured
    end
  end
  return h, live
end
BLOCK.norms = { build = function(f) return buildNorms(f, "GameFontHighlight", "GameFontHighlight") end, set = setNorms }
BLOCK.raid = { build = function(f) return buildNorms(f, "GameFontDisable") end, set = setNorms }
BLOCK.who = {
  build = function(f)
    local b = newBlock(f)
    b.text = ns.UI.Body(b, WELCOME.cw, "GameFontHighlight")
    b.text:SetPoint("TOPLEFT")
    return b
  end,
  set = function(b, data)
    b.text:SetText(data.text)
    return textHeight(b.text, data.text)
  end,
}

local function buildPanel()
  local UI = ns.UI
  local ok, f = pcall(CreateFrame, "Frame", "UW_GuildWelcome", UIParent, "BasicFrameTemplateWithInset")
  if not ok or not f then f = CreateFrame("Frame", "UW_GuildWelcome", UIParent, "BackdropTemplate") end
  f:SetSize(WELCOME.w, WELCOME.top + 264) -- sized to what's in it on each show (RefreshWelcome)
  f:SetPoint("CENTER")
  f:SetFrameStrata("DIALOG")
  f:SetMovable(true)
  if f.SetClampedToScreen then f:SetClampedToScreen(true) end -- a tall window on a small screen slides down, never off the top
  f:EnableMouse(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  tinsert(UISpecialFrames, "UW_GuildWelcome") -- Esc closes it
  ns.SkinWindow(f) -- EllesmereUI's look when it's installed (Skin.lua)

  UI.Title(f, "Welcome to Unbothered Warlords")

  -- Guild art, on a frame of our own (EllesmereUI fades the textures of a frame it skins): the campfire camp across
  -- the window under the title bar, a shade at its foot so the window takes over from it, and the crest standing up
  -- into its corner.
  f.body = CreateFrame("Frame", nil, f)
  f.body:SetAllPoints()
  f.banner = f.body:CreateTexture(nil, "ARTWORK")
  f.banner:SetTexture(MEDIA .. "header") -- its art fills the top 512x171 of a 512x256 canvas
  f.banner:SetHeight(WELCOME.banner)
  local shade = f.body:CreateTexture(nil, "ARTWORK", nil, 1)
  shade:SetPoint("BOTTOMLEFT", f.banner, "BOTTOMLEFT")
  shade:SetPoint("BOTTOMRIGHT", f.banner, "BOTTOMRIGHT")
  shade:SetHeight(WELCOME.fade)
  shade:SetColorTexture(0, 0, 0, 1)
  local color = rawget(_G, "CreateColor")
  if not (type(color) == "function" and shade.SetGradient
    and pcall(shade.SetGradient, shade, "VERTICAL", color(0, 0, 0, 0.85), color(0, 0, 0, 0))) then
    shade:Hide() -- a client that can't fade it shows the art to its edge
  end
  -- What stands under the art hangs from this: the art's left margin and foot, whatever look and height it has.
  f.head = CreateFrame("Frame", nil, f.body)
  f.head:SetPoint("TOPLEFT", f, "TOPLEFT", WELCOME.pad, -WELCOME.art)
  f.head:SetSize(1, WELCOME.banner)
  f.give = 0
  layArt(f)
  local crest = f.body:CreateTexture(nil, "OVERLAY")
  crest:SetTexture(MEDIA .. "emblem")
  crest:SetSize(WELCOME.crest, WELCOME.crest)
  crest:SetPoint("TOPLEFT", f.head, "BOTTOMLEFT", 0, WELCOME.lap)

  local tag = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  tag:SetPoint("TOPLEFT", f.head, "BOTTOMLEFT", WELCOME.crest + UI.GAP, -UI.HALF)
  tag:SetPoint("RIGHT", f, "RIGHT", -WELCOME.pad, 0)
  tag:SetJustifyH("LEFT")
  tag:SetText(ns.TAGLINE)
  local sub = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  sub:SetPoint("TOPLEFT", tag, "BOTTOMLEFT", 0, -3)
  sub:SetPoint("RIGHT", f, "RIGHT", -WELCOME.pad, 0)
  sub:SetJustifyH("LEFT")
  sub:SetText(ns.SUBTAGLINE)

  f.blocks = {} -- one frame a kind, made when a show first needs it (RefreshWelcome)
  -- More than the window's share of the screen: it turns pages, the arrows in a row of their own over the buttons.
  f.pager = UI.Pager(f, function(way)
    f.page = (f.page or 1) + way
    ns.RefreshWelcome()
  end, function(next)
    next:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -WELCOME.pad, WELCOME.foot + UI.BTN + UI.GAP)
  end)

  -- One red button, the way to a first group, at the right; the two quiet ones at the left (design pass, backlog
  -- 31: it had three red buttons and nothing to read first).
  local near = UI.Button(f, WELCOME.red, "Find guildmates")
  near:SetPoint("BOTTOMRIGHT", -WELCOME.pad, WELCOME.foot)
  near:SetScript("OnClick", function() ns.commands.near() end)
  ns.useButton(near, "welcome find guildmates")

  -- Everything UW_Guild does, with its buttons (Handbook.lua): the welcome's way into the rest of the addon.
  local all = UI.Quiet(f, WELCOME.quiet[1], "All features", nil, true)
  all:SetPoint("BOTTOMLEFT", WELCOME.pad, WELCOME.foot)
  all:SetScript("OnClick", function() f:Hide() ns.protect(ns.OpenEveryFeature) end) -- one window at a time; Got it still marks it read
  ns.useButton(all, "welcome all features")

  local done = UI.Quiet(f, WELCOME.quiet[2], "Got it", nil, true)
  done:SetPoint("BOTTOMLEFT", WELCOME.pad + WELCOME.quiet[1] + WELCOME.btnGap, WELCOME.foot)
  done:SetScript("OnClick", function()
    UW_GuildCharDB.welcomed = time()
    UW_GuildDB.welcomed = UW_GuildDB.welcomed or time() -- someone on this account has read it
    f:Hide()
  end)
  ns.useButton(done, "welcome got it")
  f.buttons = { near, all, done }
  return f
end

function ns.RefreshWelcome(again)
  if not panel or not panel:IsShown() then return end
  local UI = ns.UI
  layArt(panel)
  local blocks, soft = welcomeBlocks()
  local frames, heights, live = {}, {}, true
  for i, data in ipairs(blocks) do
    local b = panel.blocks[data.kind]
    if not b then
      b = BLOCK[data.kind].build(panel)
      panel.blocks[data.kind] = b
    end
    local h, measured = BLOCK[data.kind].set(b, data)
    b:SetHeight(h)
    frames[i], heights[i], live = b, h, live and measured
  end
  -- As high as what's in it and no higher: a long name or a buddy line can wrap. All on one page while that stays
  -- inside the window's share of the screen, the art giving up some of its height first; past that it turns pages,
  -- the arrows in a row of their own over the buttons, and every page is as high as the tallest so the buttons
  -- stay put.
  local frame = WELCOME.top + WELCOME.air + UI.BTN + WELCOME.foot
  local room = screenRoom() - frame
  local pages = ns.WelcomePages(heights, room + WELCOME.give, soft)
  if #pages > 1 then
    frame, room = frame + UI.BTN + UI.GAP, room - UI.BTN - UI.GAP
    pages = ns.WelcomePages(heights, room + WELCOME.give, soft)
  end
  local tall = 0
  for _, page in ipairs(pages) do tall = math.max(tall, page.h) end
  local give = math.max(0, math.min(WELCOME.give, math.ceil(tall - room)))
  giveArt(panel, give)
  panel:SetHeight(math.ceil(frame - give + tall))
  panel.page = math.max(1, math.min(panel.page or 1, #pages))
  local page = pages[panel.page]
  -- Placed again only when the page holds other blocks than it did: a text moved a moment ago can measure 0.
  local held = {}
  for n, i in ipairs(page) do held[n] = blocks[i].kind .. (i == soft and "+" or "") end
  held = table.concat(held, " ")
  if panel.held ~= held then
    panel.held = held
    for _, b in pairs(panel.blocks) do b:Hide() b:ClearAllPoints() end
    for n, i in ipairs(page) do
      local b = frames[i]
      if n == 1 then
        b:SetPoint("TOPLEFT", panel.head, "BOTTOMLEFT", 0, -WELCOME.under)
      else
        b:SetPoint("TOPLEFT", frames[page[n - 1]], "BOTTOMLEFT", 0, -(i == soft and WELCOME.join or WELCOME.gap))
      end
      b.rule:SetShown(n > 1 and i ~= soft)
      b:Show()
    end
  end
  UI.PagerSet(panel.pager, panel.page, #pages)
  -- A first show the client couldn't measure: once more a frame later, when it can.
  if not live and not again then ns.after(0, function() ns.RefreshWelcome(true) end) end
end

local function showWelcome()
  -- Asked for in a fight (/uw welcome, the guide's button): it waits, and says so. The automatic first welcome
  -- never gets here in a fight (autoWelcome holds it until the fight ends).
  if InCombatLockdown() then ns.say("Try /uw welcome again after the fight.") return end
  panel = panel or buildPanel()
  panel.page = 1
  panel:Show()
  ns.RefreshWelcome()
end
ns.commands.welcome = showWelcome

-- Opens by itself at most once per character, and an alt of a player who already read it on this
-- account gets it at most once per account-day. /uw welcome reopens it any time.
local welcomeAfterCombat = false
local function autoWelcome()
  local c, db = UW_GuildCharDB, UW_GuildDB
  if c.welcomed or c.welcomeShown then return end
  if InCombatLockdown() then welcomeAfterCombat = true return end -- a fight at login: shown once it ends
  if not ns.inOurGuild() then return end -- an alt in some other guild: not ours to welcome
  local day = math.floor(time() / 86400)
  if db.welcomed and db.welcomeAutoDay == day then return end
  c.welcomeShown, db.welcomeAutoDay = time(), day
  showWelcome()
end

-- Wiring ----------------------------------------------------------------------
local f = CreateFrame("Frame")
f:RegisterEvent("GROUP_ROSTER_UPDATE")
f:RegisterEvent("PLAYER_REGEN_ENABLED")
f:SetScript("OnEvent", ns.guard(function(_, event)
  if event == "PLAYER_REGEN_ENABLED" then
    if welcomeAfterCombat then welcomeAfterCombat = false; ns.after(3, autoWelcome) end
  elseif UW_GuildCharDB then
    checkFirstGroup()
  end
end))

table.insert(ns.onLoad, function()
  UW_GuildDB.buddies = UW_GuildDB.buddies or {}
  UW_GuildCharDB = UW_GuildCharDB or {}
end)

-- Runs once per session, when the character is first seen in a guild: at login, or on joining mid-session
-- (Core calls ns.onGuildJoin when IsInGuild() turns true).
table.insert(ns.onGuildJoin, function()
  ns.after(12, autoWelcome)
  -- Ask only after our own roster is read, or the officer's reply would fail the officer check.
  ns.afterRoster(function()
    if ns.RefreshWelcome then ns.RefreshWelcome() end -- the rank decides the buddy line
    if not ns.tracksGuild() then return end -- an alt in another guild has nothing to ask ours
    ns.WelcomeBack(time())
    ns.send("HI\t" .. ns.VERSION .. (ahead() and "\tearly" or ""), "GUILD")
    ns.after(25, updaterNudge)
    if not UW_GuildDB.buddies[me()] then ns.send("BUDQ", "GUILD") end
    ns.send(UW_GuildDB.invite and ("INVQ\t" .. (UW_GuildDB.inviteAt or 0)) or "INVQ", "GUILD")
    announceGroup()
    if ns.isOfficer(me()) then ns.send("GRPQ", "GUILD"); ns.send("QWQ", "GUILD") end
  end)
end)
