-- Options: UW_Guild in the two places players look for any addon (Louis, 4 Nov 2026: follow the practices of other
-- addons, toward the best UI and UX possible):
--   * Esc > Options > AddOns > UW Guild, the game's own Settings panel, and /uw options;
--   * the minimap's addon menu (the addon compartment; the .toc names the three functions at the bottom).
-- Every button runs the /uw command its tooltip names, so the page adds no behaviour of its own. Players find what
-- UW_Guild does by looking instead of remembering commands, see the kit's state without asking, and get each answer
-- on the page as well as in chat, because the Settings panel covers chat. These are Nielsen's usability heuristics:
-- recognition rather than recall, visibility of system status, consistency and standards. The page is laid out on
-- the numbers and body text every UW_Guild window shares (ns.UI, Skin.lua; layout pass, 14 Nov 2026), to the design
-- spec's board 6 (15 Nov 2026): the crest and the title, the kit's state on a line of its own with the page's one
-- red button, the switches in one column and the buttons in one beside them, each with the picture the guide gives
-- the same thing, and the answer at the foot.
local _, ns = ...
local say = ns.say

ns.OPTION_NAME = "UW Guild"
-- { button, /uw command, tooltip }. A command that changes something for the whole guild asks for a second click.
ns.OPTION_ACTIONS = {
  { "Check my addon kit", "kit", "What's missing, doubled up or turned off, and how to fix it." },
  { "Fix my kit", "kit fix", "Turns duplicates off and installed kit addons on, then asks to reload. All characters: /uw kit fix all." },
  { "Use the guild layout", "kit layout", "Imports the raid frames, bars and meter the officers shared." },
  { "Optional extras", "kit extras", "One extra addon per goal, and which ones you already have." },
  { "Class macros", "kit macros", "The guild's tested macros for your class, added in one click." },
  { "Report a problem", "kit report", "A short report to paste into /ask-officers in Discord." },
  { "Welcome window", "welcome", "The guild's norms, your buddy and the invite link." },
  { "Who's near my level", "near", "Who's online and close to your level, for leveling groups." },
  { "Call a group", "lead call", "Members and up: a line in guild chat for the dungeon at your level. Invite who types inv, one click each." },
  { "Loot rules", "loot", "How the guild's loot rolls work." },
  { "Raid plan", "plan", "Your own job in each step of the raid leader's plan. Leaders paste the guide's code here." },
  { "Guild jobs", "jobs", "Who holds each guild job, from guild notes, and how to take one." },
  { "Rate a leader", "rate", "How the last guild raid or dungeon leader did. Private." },
  { "Contact Guild Master", "contact", "The Guild Master's BattleTag." },
}
ns.OFFICER_ACTIONS = {
  { "Lead a group", "lead", "Who's on, calling a group, raid sign-ups and bench, leads and lines written ahead. Rehearse inside." },
  { "Check the group's kits", "audit", "Asks every member's UW_Guild what their kit has. Results in 6 seconds." },
  { "Send kit reminders", "kit nudge", "Online members with something to fix get a reminder." },
  { "Share my layout", "kit layout share", "Makes your EllesmereUI and Details layout the guild layout.", true },
  { "Change the guild kit", "kit edit", "Shows the commands that add, remove or pair kit addons for everyone." },
}
-- The automatic helpers, each a switch on the page: { key, label, /uw command (takes on/off), tooltip, on() }. A helper
-- with no command of its own has set(on) instead. Everything starts on, and each tooltip ends with what switching it off
-- loses (Louis, 9 Nov 2026 04:29: on by default, a clear opt-out, no penalty; ns.OPTION_FOOTER).
local function db() return UW_GuildDB or {} end
ns.OPTION_SWITCHES = {
  { key = "craft", label = "Share my crafting with the guild", cmd = "craft",
    tip = "Guildmates see what you can craft and the weapons the guild plan suggests for you. Off: nothing is shared, "
      .. "and online guildmates forget what they had.", on = function() return not (UW_GuildCharDB or {}).craftsOff end },
  { key = "gear", label = "Wear clear gear upgrades", cmd = "gear",
    tip = "Only when it's clear: same slot and armor type, higher item level, no stat lower. Bind on Equip and other "
      .. "upgrades for your class and talents ask first, and say by how much. Never in combat or a loot roll. /uw gear "
      .. "undo swaps back. Off: no swaps, questions or upgrade notes; upgrades stay in your bags until you put them on.",
    on = function() return db().gearAuto ~= false end },
  { key = "space", label = "Space uses quest items", cmd = "space",
    tip = "When your target is part of a quest you carry an item for, and it's in range, Space uses the item. "
      .. "Shift+Space uses it in fights too. Off: Space only jumps.", on = function() return db().spaceItem ~= false end },
  { key = "bags", label = "Delete and Make room in bags", cmd = "bags",
    tip = "Delete on your bags drops the cheapest junk; with full bags, Make room swaps junk for better loot. Junk worth "
      .. "less than anything in full bags stays on the corpse. Shift-click Delete keeps an item. Off: no Delete or Make "
      .. "room buttons; you clear bags by hand.",
    on = function() return db().bagRoom ~= false end },
  { key = "bars", label = "New spells onto my bars", cmd = "bars",
    tip = "A new rank replaces the old one on your bars; a new spell takes the first empty slot. Never macros or items. "
      .. "Off: new spells and ranks wait in your spellbook.",
    on = function() return db().barsAuto ~= false end },
  { key = "chain", label = "Quest chain tags in Questie", cmd = "chain", needs = "Questie",
    tip = "Questie's tracker shows each quest's step in its chain (3/7); hover for every step. /uw chain lists them. "
      .. "Off: Questie's tracker shows quest names only.",
    on = function() return db().chainTags ~= false end },
  { key = "guide", label = "Quest guide marker", cmd = "guide", needs = "Questie",
    tip = "The map pin and on-screen marker point at your tracked quest's next step. Wandering NPCs: along their route, "
      .. "and a line once in sight. Your own pin always wins. Off: no map pin or marker for your next step.",
    on = function() return ns.GuideOn and ns.GuideOn() and not (ns.GuidePaused and ns.GuidePaused()) or false end },
  { key = "mail", label = "Send mats button at a mailbox", cmd = "mail",
    tip = "One click mails crafting materials to your own alt whose professions use them. /uw mail shows what would go. "
      .. "Off: no Send mats button; mail by hand.",
    on = function() return db().mailMats ~= false end },
  { key = "dungeons", label = "Dungeon lines in chat", cmd = "dungeons",
    tip = "At a level where a dungeon opens, one line in your chat names it. Inside one with a group, a line names its "
      .. "quests and who carries each, and a button tells the group. Off: neither line, and no button.",
    on = function() return not db().dungeonLineOff end },
  { key = "events", label = "Rally and group night heads-ups", cmd = "events",
    tip = "A login line and a heads-up 10 minutes before each Rally or group night. /uw events lists them. Off: no login "
      .. "line or 10-minute heads-ups.",
    on = function() return db().eventsQuiet ~= true end },
  { key = "rate", label = "Ask me to rate the leader", cmd = "rate",
    tip = "After a guild group's boss kill, one private ask, at most once a day. Off: no asks; /uw rate still works.",
    on = function() return not db().rateOff end },
  -- Every member since member reports (22 Nov 2026, Reports.lua): the one switch for those and, on officers' and
  -- buddies' addons, the week-one counts.
  { key = "share", label = "Share addon counts", cmd = "share",
    tip = "Once a day, tells the Guild Master's addon which UW_Guild features you used, its errors and your setup. "
      .. "Only totals are kept, never names. On officers' and buddies' addons, also the week-one counts. Off: nothing is "
      .. "sent; nothing in game changes.",
    on = function() return not db().weekOneShareOff end },
  { key = "hold", label = "Keep the quest window open", needs = "DialogueUI",
    tip = "After a turn-in, DialogueUI waits a moment for the next quest. Off: it closes as it normally would.",
    on = function() return db().dialogueHold ~= false end,
    set = function(on)
      if UW_GuildDB then
        if on then UW_GuildDB.dialogueHold = nil else UW_GuildDB.dialogueHold = false end
      end
      say(on and "Quest window stays open for the next quest." or "Quest window closes as DialogueUI decides.")
    end },
  { key = "sharelater", label = "Finish Share Quest after a fight",
    tip = "A Share Quest click the game holds back during a fight goes out when the fight ends. Off: click Share "
      .. "Quest again after the fight.",
    on = function() return ns.ShareLaterOn and ns.ShareLaterOn() or false end,
    set = function(on)
      if UW_GuildDB then
        UW_GuildDB.shareLater = on and true or false -- the choice itself, whatever the default becomes
      end
      say(on and "Share Quest finishes after a fight." or "Share Quest is left to your own click.")
    end,
    -- The one switch that starts off, and why (the tests hold every other to "starts on", Louis, 9 Nov 2026): it
    -- acts on its own, so it is the member's opt-in (coordinator, 16 Nov 2026).
    startsOff = "acts on its own, so the member opts in (ShareLater.lua)",
    -- Only where the late share runs (ns.ShareLaterHere: the bot PC until one of its saves shows the late share
    -- going through), so no client shows a box that does nothing.
    shown = function() return ns.ShareLaterHere and ns.ShareLaterHere() or false end },
}
-- A helper that works through another addon (needs) shows that addon's absence as its state, not as a ticked box that
-- does nothing (fresh-member audit, 10 Nov 2026). The saved choice is untouched: install the addon and it's back on.
-- A switch for helpers only (officers and buddies, ns.WeekOneHelper) is left off the page for everyone else, rather
-- than a box that does nothing for them (integrator review of #583, 13 Nov 2026).
function ns.SwitchShown(sw)
  if type(sw) ~= "table" then return true end
  if sw.shown and not sw.shown() then return false end -- a switch that says where it does something
  if not sw.helpers then return true end
  return ns.WeekOneHelper and ns.WeekOneHelper() and true or false
end

function ns.NeedsMissing(sw)
  local need = type(sw) == "table" and sw.needs
  if not need then return false end
  local ok, loaded = pcall(C_AddOns.IsAddOnLoaded, need)
  return not (ok and loaded)
end
ns.OPTION_FOOTER = "Turning any of these off never changes your rank or your progress."
-- What UW_Guild is, for the title's tooltip (design spec 9: the description leaves the page's face; the version
-- stays under the title).
ns.OPTION_ABOUT = "Keeps the guild's addons working together, does the chores ticked below, and runs the welcome, "
  .. "loot rolls and raid records."
ns.ECHO_SECONDS, ns.CONFIRM_SECONDS = 8, 5
-- The page's grid (layout pass, 14 Nov 2026; design spec 9, 15 Nov 2026). The game's Settings window gives an addon
-- page about 665 x 601 (Blizzard_SettingsPanel.xml). OPTION_W: the content's width between the page's margins.
-- OPTION_LEFT: the switches' column; the buttons stand right of it in one column (OPTION_COLS), OPTION_BUTTON_W
-- wide. OPTION_ROW: from one switch to the next, which is a button's step too (OPTION.step), so the two columns
-- keep one rhythm; at 24 an officer's answer had room for ten of Optional extras' thirteen lines. With more
-- switches than leave that room the rows close up (OPTION.tight; see the layout). OPTION_H: the page's height
-- where the client won't say.
ns.OPTION_W, ns.OPTION_H, ns.OPTION_LEFT, ns.OPTION_ROW = 632, 601, 416, 22
ns.OPTION_COLS, ns.OPTION_BUTTON_W = 1, 200
--   crest: the crest beside the title.
--   strip, bar: the kit line's margin over and under its words, and the bar at its left.
--   caps, label: a section label's height, and the gap under it (as the welcome's).
--   icon: a switch's picture. pic, inset: a button's, and how far inside the button's edge it sits.
--   gap: from a picture to its words. text: from one line of the body's 12 font to the next (the kit line, the
--     no-penalty line). The answer keeps the small font and its 12-unit step: it is what chat said, on a page with
--     little room, and at the body's size Optional extras' thirteen lines no longer fit under a member's switches.
--   step: from one button to the next (18 of them and two labels stand in an officer's column).
--   least: the narrowest a button gets on a page narrower than the game's.
--   red: the kit line's button: the room beside its label (both sides together), its least and most width.
--   lines: the fewest lines of an answer the page keeps room for, before it gives up the page's width for it.
--   answer: the lines of the longest answer a button here gives (Optional extras), which the page keeps room for
--     under the switches. tight: the switches' row step once OPTION_ROW no longer leaves that room (a picture is
--     18, so it is as close as rows can stand). over: how much taller than its row the game's own tick box is at
--     most (its art sits well inside its frame), so closed-up rows get a box that much smaller.
ns.OPTION = { crest = 36, strip = 6, bar = 2, caps = 10, label = 6, icon = 18, pic = 16, inset = 2, gap = 6, text = 14,
  step = 22, least = 120, red = { 24, 120, 176 }, lines = 6, answer = 13, tight = 20, over = 2 }
-- Where each button stands, by its /uw command (design spec 9): the kit check on the kit line, the rest in one
-- column in three groups with no heading (kit, play, guild). A button its owner adds to ns.OPTION_ACTIONS later
-- joins the last group until it's given a place here.
ns.OPTION_ON_STRIP = "kit"
ns.OPTION_GROUPS = {
  { "kit fix", "kit layout", "kit extras", "kit macros" },
  { "near", "lead call", "plan", "loot", "rate" },
  { "welcome", "jobs", "kit report", "contact" },
}
-- A button's picture: the guide's for the entry that has the same button (Handbook.lua ns.HANDBOOK_ICONS.entry), so
-- one thing has one picture everywhere. A switch's is the entry of its own key.
ns.OPTION_ICONS = { kit = "kit", ["kit fix"] = "kit", ["kit extras"] = "kit", ["kit layout"] = "layout",
  ["kit macros"] = "macros", ["kit report"] = "report", welcome = "welcome", near = "near", ["lead call"] = "call",
  loot = "loot", plan = "plan", jobs = "jobs", rate = "rate", contact = "contact",
  lead = "lead", audit = "audit", ["kit nudge"] = "audit", ["kit layout share"] = "layout", ["kit edit"] = "kit" }
-- The buttons' places for a kit state. First: the entry on the kit line, which is the one the status line names
-- (primary, from ns.OptionsStatus) or else the kit check. Second: the column's groups, each a list of entries (by
-- their place in ns.OPTION_ACTIONS). While Fix my kit is on the line, the kit check stands where Fix my kit does.
function ns.OptionPlaces(primary)
  local at, placed, groups = {}, {}, {}
  for i, e in ipairs(ns.OPTION_ACTIONS) do at[e[2]] = at[e[2]] or i end
  local home = at[ns.OPTION_ON_STRIP]
  local strip = primary and at[primary] or home
  if strip then placed[strip] = true end
  for g, cmds in ipairs(ns.OPTION_GROUPS) do
    groups[g] = {}
    for _, c in ipairs(cmds) do
      local i = at[c]
      if i == strip then i = home end
      if i and not placed[i] then
        placed[i] = true
        groups[g][#groups[g] + 1] = i
      end
    end
  end
  local last = groups[#groups]
  for i in ipairs(ns.OPTION_ACTIONS) do
    if not placed[i] and last then last[#last + 1] = i end
  end
  return strip, groups
end

-- The kit's state in a line or two, for the page and the minimap tooltip. Second: the /uw command of the button the
-- first line names ("kit fix" or "kit"), nil while the kit is ready; the page draws that one button red.
function ns.OptionsStatus()
  local missReq, _, conflicts, missRaid = ns.CheckKit()
  local off, on = {}, {}
  if ns.KitFixPlan then off, on = ns.KitFixPlan() end
  local lines, primary = {}, nil
  if #missReq + #conflicts == 0 then
    lines[1] = "|cff40ff40Addon kit: ready.|r"
  else
    local parts = {}
    if #missReq > 0 then parts[#parts + 1] = ("%d missing"):format(#missReq) end
    if #conflicts > 0 then parts[#parts + 1] = ("%d doubled up"):format(#conflicts) end
    primary = #off + #on > 0 and "kit fix" or "kit"
    lines[1] = ("|cffff8000Addon kit: %s.|r %s"):format(table.concat(parts, ", "),
      primary == "kit fix" and "Fix my kit does it in one step." or "Check my addon kit shows which.")
  end
  if #missRaid > 0 then lines[#lines + 1] = ("For raiding: %d more to add."):format(#missRaid) end
  if (ns.ownErrors or 0) > 0 then
    lines[#lines + 1] = ("|cffff8000UW_Guild hit %d problem(s) this session.|r Report a problem copies them for the officers.")
      :format(ns.ownErrors)
  end
  return lines, primary
end

-- A button's answer: what the command says for the next few seconds (an audit's results come 6 s later) is shown on
-- the page too, from its first line; the lines that don't fit are counted ("3 more in chat", UI.AnswerSet). It kept
-- its last six lines, so Check my addon kit showed its tips and hid what was missing.
local answer = {}
local echoUntil = 0
local panel, ui -- the registered frame, and its widgets once it has been shown
local function showAnswer()
  if not ui then return end
  local h = ns.UI.AnswerSet(ui.answer, answer, ui.room, nil, ui.per)
  ui.answerBar:SetHeight(math.max(h, 1))
  ui.answerBar:SetShown(#answer > 0)
end
-- A burst of lines (an audit's results, a line a member) is drawn once, a frame later, not once a line: each draw
-- measures the text a few times (red team, #612). The click's own lines show at once (ns.OptionsRun refreshes).
local drawing = false
ns.echo = function(msg)
  if GetTime() > echoUntil then return end
  answer[#answer + 1] = msg
  if drawing or not ui then return end
  drawing = true
  ns.after(0, function()
    drawing = false
    showAnswer()
  end)
end
function ns.OptionsAnswer() return answer end

local armed -- { command, until }: the first click on a guild-wide action
function ns.OptionsRun(entry)
  local cmd = entry[2]
  wipe(answer)
  echoUntil = GetTime() + ns.ECHO_SECONDS
  if entry[4] and not (armed and armed[1] == cmd and GetTime() <= armed[2]) then
    armed = { cmd, GetTime() + ns.CONFIRM_SECONDS }
    say(("Click %s again within %d seconds: it changes this for the whole guild."):format(entry[1], ns.CONFIRM_SECONDS))
    return
  end
  armed = nil
  ns.useFrom = "options" -- usage counts (Core.lua ns.use): a click here, not a typed command
  if entry.set then entry.set(entry.on) else SlashCmdList.UWGUILD(cmd) end
  if ui then ui.refresh() end
end

-- The page ---------------------------------------------------------------------------------------------------------
-- A control's tooltip is the game's one, as every UW_Guild window shows it (Skin.lua UI.Tip): a dark sheet of our
-- own behind it, and hidden only while it's still that control's.
local function describe(owner, entry) ns.UI.Tip(owner, entry[1], entry[3] .. "\n|cff808080/uw " .. entry[2] .. "|r") end
local function hideTooltip(owner) ns.UI.TipHide(owner) end

-- A number the client gave us, at least `least`, else `fallback` (a value it keeps secret is never compared).
local function measure(get, region, least, fallback)
  local ok, v = pcall(get, region)
  v = ok and not ns.isSecret(v) and tonumber(v) or nil
  return v and v >= least and v or fallback
end

-- Every action but one is a quiet button, a list row's size, in the body's white (UI.Quiet): nineteen red buttons
-- read as a wall, with nothing to say which one matters now (design pass, 13 Nov 2026). Each carries the guide's
-- picture for the same thing at its left, its words after it (design spec 9).
local function buttons(parent, list)
  local UI, O, out = ns.UI, ns.OPTION, {}
  for i, entry in ipairs(list) do
    local b = UI.Quiet(parent, ns.OPTION_BUTTON_W, entry[1], UI.SMALL, true)
    b.icon = UI.Icon(b, O.pic)
    b.icon:SetPoint("LEFT", O.inset, 0)
    b.label:SetJustifyH("LEFT")
    if b.label.SetWordWrap then b.label:SetWordWrap(false) end
    b:SetScript("OnClick", function() ns.protect(ns.OptionsRun, entry) end)
    b:SetScript("OnEnter", function(self) describe(self, entry) end)
    b:SetScript("OnLeave", hideTooltip)
    out[i] = b
  end
  return out
end

local ANSWER_IN = 12 -- the answer starts this far in, behind its bar (as in the UW Guild window)
local BOX_IN = 4     -- the game's tick box art sits this far inside its frame: the box, not the frame, lines up with the text

local function build(parent)
  local UI, O = ns.UI, ns.OPTION -- Skin.lua loads after this file: the shared numbers are read when the page first shows
  local f = { frame = parent }
  -- The head: the crest, the addon's name, its version in grey under it. What UW_Guild is: the head's tooltip.
  f.crest = parent:CreateTexture(nil, "ARTWORK")
  f.crested = f.crest:SetTexture(UI.MARK.old) ~= false -- a client that says it has no such file: no crest, no room kept
  f.crest:SetSize(O.crest, O.crest)
  f.crest:SetShown(f.crested)
  local title = parent:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
  title:SetJustifyH("LEFT")
  title:SetText(ns.OPTION_NAME)
  f.title = title
  f.version = parent:CreateFontString(nil, "ARTWORK", "GameFontDisable")
  f.version:SetJustifyH("LEFT")
  f.version:SetText(("Version %s"):format(ns.VERSION))
  f.about = CreateFrame("Frame", nil, parent)
  f.about:EnableMouse(true)
  f.about:SetScript("OnEnter", function(self) UI.Tip(self, ns.OPTION_NAME, ns.OPTION_ABOUT) end)
  f.about:SetScript("OnLeave", hideTooltip)

  -- The kit line: the kit's state, the Addon kit's picture, and the one button the state names. The button is red
  -- while the kit needs something (the page's one red button) and quiet while it's ready. The strip is orange
  -- behind and at its bar while there is something to fix, plain otherwise.
  f.strip = CreateFrame("Frame", nil, parent)
  f.stripFill = UI.Fill(f.strip, "BACKGROUND", 1, 1, 1, 0.04)
  f.stripFill:SetAllPoints()
  f.stripBar = UI.Fill(f.strip, "BORDER", 1, 1, 1, 0.25)
  f.stripBar:SetPoint("TOPLEFT")
  f.stripBar:SetPoint("BOTTOMLEFT")
  UI.Thin(f.stripBar, O.bar)
  f.kitIcon = UI.Icon(f.strip, UI.SMALL)
  f.kitIcon:SetPoint("LEFT", O.bar + UI.GAP, 0)
  f.status = UI.Body(f.strip, nil, "GameFontHighlight")
  local function stripButton(b)
    b:SetPoint("RIGHT", -UI.GAP, 0)
    b:SetScript("OnClick", function() if f.stripEntry then ns.protect(ns.OptionsRun, f.stripEntry) end end)
    b:SetScript("OnEnter", function(self) if f.stripEntry then describe(self, f.stripEntry) end end)
    b:SetScript("OnLeave", hideTooltip)
    b:Hide()
    return b
  end
  f.primary = stripButton(UI.Button(f.strip, O.red[2]))
  f.kitQuiet = stripButton(UI.Quiet(f.strip, O.red[2], "", UI.BTN, true))

  -- One switch per automatic helper, in one column: its tick box, the guide's picture for it, its words, and at
  -- the row's end the addon it needs while that one is missing. What each does is in its tooltip, and each turns
  -- off here. The row under the pointer is lit, so a box and its words read as one, and its tooltip stands beside
  -- the column, level with the row: over the buttons, never over the switches still to be read (it hung from the
  -- box's corner, over the three rows above it and the kit line).
  f.helpersHeader = UI.Caps(parent, "Automatic helpers")
  f.hover = UI.Fill(parent, "BACKGROUND", 1, 1, 1, 0.05)
  f.hover:Hide()
  f.switches, f.share = {}, nil
  for _, sw in ipairs(ns.OPTION_SWITCHES) do
    local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cb:SetSize(UI.CHECK, UI.CHECK)
    cb.icon = UI.Icon(parent, O.icon)
    local label = UI.Body(parent, nil, "GameFontHighlight")
    if label.SetWordWrap then label:SetWordWrap(false) end
    label:SetText(sw.label)
    cb.label = label
    cb.need = UI.Body(parent, nil, "GameFontHighlight")
    cb.need:SetText(sw.needs and ("|cffff8000Needs %s|r"):format(sw.needs) or "")
    cb.need:Hide()
    cb:SetScript("OnClick", function(self)
      local on = self:GetChecked() and true or false
      if sw.set then
        ns.protect(ns.OptionsRun, { "", sw.key, set = sw.set, on = on })
      else
        ns.protect(ns.OptionsRun, { "", sw.cmd .. (on and " on" or " off") })
      end
    end)
    cb:SetScript("OnEnter", function(self)
      if self.rowTop then
        f.hover:ClearAllPoints()
        f.hover:SetPoint("TOPLEFT", parent, "TOPLEFT", UI.PAD - BOX_IN, -self.rowTop)
        f.hover:Show()
      end
      local need = ns.NeedsMissing(sw) and ("\n|cffffd100Needs %s: /uw kit shows where to get it.|r"):format(sw.needs) or ""
      local text = sw.tip .. need .. (sw.cmd and ("\n|cff808080/uw " .. sw.cmd .. " on, /uw " .. sw.cmd .. " off|r") or "")
      if self.rowTop then UI.TipBeside(self, f.hover, sw.label, text) else UI.Tip(self, sw.label, text) end
    end)
    cb:SetScript("OnLeave", function(self)
      f.hover:Hide()
      hideTooltip(self)
    end)
    ns.Skin("Checkbox", cb)
    f.switches[sw.key] = cb
  end
  f.share = f.switches.craft
  f.footer = UI.Body(parent, nil, "GameFontHighlight")
  f.footer:SetText(ns.OPTION_FOOTER)

  f.everyoneHeader = UI.Caps(parent, "Everyone")
  f.everyone = buttons(parent, ns.OPTION_ACTIONS)
  f.officerHeader = UI.Caps(parent, "Officers")
  f.officer = buttons(parent, ns.OFFICER_ACTIONS)
  -- The answer: at the page's foot, in a place kept for it, so nothing moves when one comes in.
  f.answer = UI.Body(parent, ns.OPTION_W - ANSWER_IN)
  f.answerBar = UI.Thin(UI.Fill(parent, "ARTWORK", 1, 1, 1, 0.25), 2)
  f.answerBar:SetPoint("TOPLEFT", f.answer, "TOPLEFT", -ANSWER_IN, 0)
  f.answerBar:Hide()
  f.room, f.per = UI.LINE, nil

  -- A region hung again only when its place changed: a text let go of can measure 0 until the next frame.
  -- to, toPoint: another region to hang from (the page's top left corner without).
  local placed = {}
  local function at(region, x, top, point, to, toPoint)
    local key = ("%s %.2f %.2f"):format(point or "TOPLEFT", x, top)
    if placed[region] == key then return end
    placed[region] = key
    region:ClearAllPoints()
    region:SetPoint(point or "TOPLEFT", to or parent, toPoint or "TOPLEFT", x, -top)
  end
  -- A column button at its width: its words start after its picture, or at a gap where this client has no pictures.
  local function fit(b, bw, pictured)
    local x = pictured and O.inset + O.pic + O.gap or UI.GAP
    b:SetWidth(bw)
    b.label:SetWidth(bw - x - UI.GAP)
    at(b.label, x, 0, "LEFT", b, "LEFT")
  end
  local function layout(statusLines, primary)
    local row, step = ns.OPTION_ROW, O.step
    local pageH = measure(parent.GetHeight, parent, 300, ns.OPTION_H)
    local cw = math.min(ns.OPTION_W, measure(parent.GetWidth, parent, 400, ns.OPTION_W + 2 * UI.PAD) - 2 * UI.PAD)
    local bw = math.min(ns.OPTION_BUTTON_W, math.max(O.least, cw - ns.OPTION_LEFT - UI.PAD))
    local left = cw - UI.PAD - bw -- the switches' column
    -- The head: the name and the version, centred on the crest.
    local y = UI.PAD
    local th, vh = UI.TextHeight(title, 16), UI.TextHeight(f.version, UI.LINE)
    local words = th + UI.SPACING + vh
    local head = f.crested and math.max(O.crest, words) or words
    local tx = UI.PAD + (f.crested and O.crest + UI.GROUP or 0)
    local ty = y + math.floor((head - words) / 2)
    at(f.crest, UI.PAD, y)
    at(title, tx, ty)
    at(f.version, tx, ty + th + UI.SPACING)
    f.about:SetSize(tx - UI.PAD + math.max(measure(title.GetStringWidth, title, 1, 80),
      measure(f.version.GetStringWidth, f.version, 1, 80)), head)
    at(f.about, UI.PAD, y)
    y = y + head + UI.GAP
    -- The kit line. Its button is as wide as its words; the state's lines take the room left of it.
    local stripAt, groups = ns.OptionPlaces(primary)
    local entry = stripAt and ns.OPTION_ACTIONS[stripAt] or nil
    local red = entry ~= nil and entry[2] == primary
    f.stripEntry = entry
    f.primary:SetShown(red)
    f.kitQuiet:SetShown(entry ~= nil and not red)
    local held = 0
    if entry then
      local b = red and f.primary or f.kitQuiet
      b:SetText(entry[1])
      held = UI.FitButton(b, entry[1], O.red[1], O.red[2], O.red[3]) + UI.GAP
    end
    local sx = O.bar + UI.GAP + (f.kitPictured and UI.SMALL + UI.GAP or 0)
    f.status:SetWidth(cw - sx - UI.GAP - held)
    at(f.status, sx, O.strip, "TOPLEFT", f.strip, "TOPLEFT")
    local sh = math.max(UI.TextHeight(f.status, statusLines * O.text - UI.SPACING) + 2 * O.strip, UI.BTN + 2 * UI.HALF)
    f.strip:SetSize(cw, sh)
    at(f.strip, UI.PAD, y)
    local fix = primary ~= nil or (ns.ownErrors or 0) > 0
    if f.stripFix ~= fix then
      f.stripFix = fix
      f.stripFill:SetColorTexture(1, fix and UI.FIX[2] or 1, fix and UI.FIX[3] or 1, fix and 0.10 or 0.04)
      f.stripBar:SetColorTexture(1, fix and UI.FIX[2] or 1, fix and UI.FIX[3] or 1, fix and 1 or 0.25)
    end
    y = y + sh + UI.GROUP
    -- The two columns, each under its label.
    local x0 = UI.PAD + left + UI.PAD
    at(f.helpersHeader, UI.PAD, y)
    at(f.everyoneHeader, x0, y)
    y = y + O.caps + O.label
    local top = y
    -- A switch's row is a button's step while the answer under the switches keeps room for its longest (O.answer
    -- lines); with more switches than that the rows close up to O.tight, so a new switch never costs an answer its
    -- last lines. It goes by the switches showing and a kit line of one line (the page as it opens with a kit
    -- that's ready), never by the kit line's state now, so the rows don't move while the page is open.
    local showing = 0
    for _, sw in ipairs(ns.OPTION_SWITCHES) do if ns.SwitchShown(sw) then showing = showing + 1 end end
    f.footer:SetWidth(left)
    local footH = UI.TextHeight(f.footer, UI.Lines({ ns.OPTION_FOOTER }, 1, left / 7) * O.text - UI.SPACING)
    local calm = top - sh + UI.BTN + 2 * UI.HALF -- where the rows start under a kit line of one line
    if pageH - (calm + showing * row + UI.HALF + footH + UI.GAP) - UI.GAP < O.answer * UI.LINE - UI.SPACING then
      row = O.tight
    end
    f.row = row
    -- The switches this player sees, one to a row, so a hidden one leaves no gap. EllesmereUI draws a tick box as
    -- big as its frame, so a column of them stood edge to edge: there the box is small enough to leave air under
    -- it (never over a button's height), flush with the text over it, and its picture starts as far from it as it
    -- does from the game's own box art. The game's own box is a little taller than a row (its art sits inside its
    -- frame): its click area is cut to the row, so no click lands on the box above or below.
    local skinned = ns.Skinned() and true or false
    local box, n = skinned and math.min(UI.SMALL, row - UI.HALF) or math.min(UI.CHECK, row + O.over), 0
    f.boxOver = math.max(0, (box - row) / 2)
    local bx = UI.PAD - (skinned and 0 or BOX_IN)
    f.labelGap = UI.SPACING + (skinned and BOX_IN or 0)
    f.wordsIn = f.labelGap + (f.pictured and O.icon + O.gap or 0) -- from a box's right edge to its words
    f.labelW = UI.PAD + left - (bx + box + f.wordsIn)
    f.hover:SetSize(left + BOX_IN, row)
    for _, sw in ipairs(ns.OPTION_SWITCHES) do
      local cb, on = f.switches[sw.key], ns.SwitchShown(sw)
      cb:SetShown(on)
      cb.label:SetShown(on)
      cb:SetSize(box, box)
      cb.label:SetWidth(f.labelW)
      at(cb.icon, f.labelGap, 0, "LEFT", cb, "RIGHT")
      at(cb.label, f.wordsIn, 0, "LEFT", cb, "RIGHT")
      cb.rowTop = nil
      if on then
        cb.rowTop = top + n * row
        at(cb, bx, cb.rowTop + (row - box) / 2)
        at(cb.need, UI.PAD + left, cb.rowTop + row / 2, "RIGHT")
        n = n + 1
      end
    end
    -- The buttons, one column: the groups a gap apart, then the officers' under a label of their own. Each button
    -- is centred on a switch's row where the two columns start. An officer's column runs to the page's foot: where
    -- it would run past it (a kit line of four lines), the groups close up.
    local officer = ns.isOfficer(ns.me())
    local count, gaps = 0, -1
    for _, g in ipairs(groups) do
      count = count + #g
      if #g > 0 then gaps = gaps + 1 end
    end
    gaps = math.max(0, gaps)
    local by = top + (row - UI.SMALL) / 2
    local air = step - UI.SMALL -- under a group's last button there's none
    local run = count * step - air + (officer and UI.GROUP + O.caps + O.label + #f.officer * step - air or 0)
    local gap = UI.GAP
    local over = by + run + gaps * gap - (pageH - UI.GAP)
    if over > 0 and gaps > 0 then gap = math.max(0, gap - math.ceil(over / gaps)) end
    local shown, foot = {}, by
    for _, g in ipairs(groups) do
      for _, i in ipairs(g) do
        local b = f.everyone[i]
        shown[i] = true
        fit(b, bw, f.colPictured)
        at(b, x0, by)
        foot = by + UI.SMALL
        by = by + step
      end
      if #g > 0 then by = by + gap end
    end
    for i, b in ipairs(f.everyone) do b:SetShown(shown[i] == true) end
    f.officerHeader:SetShown(officer)
    by = foot + UI.GROUP
    if officer then
      at(f.officerHeader, x0, by)
      by = by + O.caps + O.label
    end
    for _, b in ipairs(f.officer) do
      b:SetShown(officer)
      if officer then
        fit(b, bw, f.colPictured)
        at(b, x0, by)
        foot = by + UI.SMALL
        by = by + step
      end
    end
    -- Under the switches: the no-penalty line, then the answer down to the page's foot. The answer takes the
    -- page's width where the buttons have ended above it and it still has room for its lines; beside an officer's
    -- longer column it keeps to the switches' column.
    y = top + n * row + UI.HALF
    at(f.footer, UI.PAD, y)
    y = y + footH + UI.GAP
    local under = math.max(y, foot + UI.GAP)
    local wide = pageH - under - UI.GAP >= O.lines * UI.LINE - UI.SPACING
    if wide then y = under end
    local aw = (wide and cw or left) - ANSWER_IN
    f.answer:SetWidth(aw)
    f.per = aw / 6 -- the letters one of its lines holds, for a text the client can't measure yet
    at(f.answer, UI.PAD + ANSWER_IN, y)
    f.room = math.max(UI.LINE, pageH - y - UI.GAP)
  end

  f.refresh = function()
    local lines, primary = ns.OptionsStatus()
    f.status:SetText(table.concat(lines, "\n"))
    -- The pictures first: where the words start depends on whether this client has any.
    local icons = ns.HANDBOOK_ICONS and ns.HANDBOOK_ICONS.entry or {}
    f.pictured, f.colPictured = false, false
    f.kitPictured = UI.IconSet(f.kitIcon, icons.kit)
    for _, sw in ipairs(ns.OPTION_SWITCHES) do
      local cb, missing, seen = f.switches[sw.key], ns.NeedsMissing(sw), ns.SwitchShown(sw)
      local on = not missing and sw.on() and true or false
      cb:SetChecked(on)
      if cb.SetEnabled then cb:SetEnabled(not missing) end
      cb.label:SetText(missing and ("|cff808080%s|r"):format(sw.label) or sw.label)
      cb.need:SetShown(seen and missing)
      -- Grey with a helper that's off or can't run, as in the guide.
      if UI.IconSet(cb.icon, seen and icons[sw.key] or nil, not on) then f.pictured = true end
    end
    for _, set in ipairs({ { f.everyone, ns.OPTION_ACTIONS }, { f.officer, ns.OFFICER_ACTIONS } }) do
      for i, b in ipairs(set[1]) do
        if UI.IconSet(b.icon, icons[ns.OPTION_ICONS[set[2][i][2]] or ""]) then f.colPictured = true end
      end
    end
    layout(#lines, primary)
    for _, sw in ipairs(ns.OPTION_SWITCHES) do
      local cb = f.switches[sw.key]
      -- A click on the picture or the words ticks the box too: its click area runs over them.
      if cb.SetHitRectInsets then
        cb:SetHitRectInsets(0, -(f.wordsIn + math.min(f.labelW, measure(cb.label.GetStringWidth, cb.label, 1, f.labelW))),
          f.boxOver, f.boxOver)
      end
    end
    showAnswer()
  end
  return f
end

-- Registered at start-up: the game's Settings panel (10.0 and later), or the older Interface Options list.
local category
local function register()
  panel = CreateFrame("Frame")
  panel.name = ns.OPTION_NAME
  panel:SetScript("OnShow", function(self)
    ui = ui or build(self)
    -- The page opens without an old answer: one stays only while its lines can still come in (a switch clicked in
    -- the UW Guild window an hour ago left its line here, under no heading now).
    if GetTime() > echoUntil then wipe(answer) end
    ui.refresh()
  end)
  if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
    category = Settings.RegisterCanvasLayoutCategory(panel, ns.OPTION_NAME)
    Settings.RegisterAddOnCategory(category)
  elseif InterfaceOptions_AddCategory then
    InterfaceOptions_AddCategory(panel)
  end
end
table.insert(ns.onLoad, register)
function ns.OptionsPanel() return panel, ui end
-- This page's place in the game's Settings, for the pages that stand under it (SettingsPage.lua).
function ns.OptionsCategory() return category, panel end

function ns.OpenOptions()
  if InCombatLockdown() then say("After combat, please: /uw options") return end
  local id = category and (category.GetID and category:GetID() or category.ID)
  if id and Settings.OpenToCategory then
    Settings.OpenToCategory(id)
  elseif InterfaceOptionsFrame_OpenToCategory and panel then
    InterfaceOptionsFrame_OpenToCategory(panel)
    InterfaceOptionsFrame_OpenToCategory(panel) -- the old list needs two calls to scroll to an addon
  else
    say("This game client has no options window for addons. Type /uw for every command.")
  end
end
ns.commands.options = ns.OpenOptions

-- The UW Guild window (Handbook.lua), or this page when the window isn't loaded: a new TOC file loads only after a full
-- game restart, so the first /reload after an update has no window (integrator finding 39).
function ns.OpenEveryFeature()
  if ns.OpenHandbook then return ns.OpenHandbook() end
  return ns.OpenOptions()
end
-- The minimap's addon menu. Left-click: the UW Guild window. Right-click: the kit check, straight to chat.
function UW_Guild_OnAddonCompartmentClick(_, button)
  if button == "RightButton" then ns.protect(SlashCmdList.UWGUILD, "kit") else ns.protect(ns.OpenEveryFeature) end
end
function UW_Guild_OnAddonCompartmentEnter(_, frame)
  if not GameTooltip then return end
  GameTooltip:SetOwner(type(frame) == "table" and frame or UIParent, type(frame) == "table" and "ANCHOR_LEFT" or "ANCHOR_CURSOR")
  GameTooltip:SetText(ns.OPTION_NAME, 1, 1, 1)
  local ok, lines = pcall(ns.OptionsStatus)
  for _, line in ipairs(ok and lines or {}) do GameTooltip:AddLine(line, nil, nil, nil, true) end
  GameTooltip:AddLine("|cff808080Left-click: every feature. Right-click: check my kit.|r")
  GameTooltip:Show()
end
function UW_Guild_OnAddonCompartmentLeave() if GameTooltip then GameTooltip:Hide() end end
