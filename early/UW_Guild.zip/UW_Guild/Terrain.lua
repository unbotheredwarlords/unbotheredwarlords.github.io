-- Terrain view (Louis, 22 Nov 2026: "like this is I want in uw addon", an ARPG-style overlay as in Path of Exile or
-- Diablo). Two parts, each off until switched on, each with its own key (Bindings.xml) and command:
--   /uw terrain: a faint outline of the ground you can walk on around you, drawn at the middle of the screen and
--     turning with you, so you can see where paths, cliffs, walls and water are with the minimap closed.
--   /uw compass: a strip across the top of the screen with the guide's quest steps, nearby quest givers, services
--     (flight master, innkeeper, bank, repairs, auction house, mailbox, your class trainer) and the map pin, and the
--     name and distance of whatever is straight ahead.
-- Wired, not rebuilt (Louis, 16 Nov: wire before build). The ground comes from Shortest Path Forever's walking maps
-- (ShortestPathForeverPathData, its own global; GPL-3.0-or-later, read at 1.45.2 and only read, never written): each
-- map is cut into 533 yd tiles of 67 x 67 cells, each cell blocked, ground or water. Its file header documents the
-- format; this reads only the cell values, through the game's own base64 and zlib (C_EncodingUtil), and uses SPF's
-- decoded copy when SPF has already made one. Without SPF there is no outline; the compass needs nothing extra. Quest
-- pins are the quest guide's (Guide.lua) and Questie's; services are Questie's townsfolk lists.
-- It steps aside for what owns the same place: FarmHud's HUD (the middle of the screen) and Shortest Path Forever's
-- compass while that one guides a journey. Neither works in dungeons, where the game gives addons no position.
-- Only reads: it never sets the map pin, targets, clicks or sends anything.
local _, ns = ...
local say = ns.say

local function g(name) return rawget(_G, name) end
local function call(fn, ...)
  if type(fn) ~= "function" and not (type(fn) == "table" and getmetatable(fn)) then return nil end
  local ok, a, b, c, d = pcall(fn, ...)
  if ok then return a, b, c, d end
end
local function plain(v)
  local s = g("issecretvalue")
  return type(v) == "number" and not (s and s(v)) and v or nil
end
local floor, sqrt, sin, cos, abs, pi = math.floor, math.sqrt, math.sin, math.cos, math.abs, math.pi
local TURN = 2 * pi

-- Range, size, opacity, line width, color and place are the player's settings (below, ns.SettingsDefine).
ns.TERRAIN_FADE = 0.35      -- the outer share of the radius over which lines fade out
ns.TERRAIN_SPECK = 4        -- blocked cells among a 3 x 3 that make a wall; fewer is a tree or a rock
ns.TERRAIN_LINES = 900      -- the most outline pieces drawn
ns.TERRAIN_HZ = 30
ns.TERRAIN_CACHE = 16       -- decoded tiles kept
ns.TERRAIN_TILE = 1600 / 3  -- yards per tile (one map tile)
ns.TERRAIN_FORMATS = { [1] = true, [2] = true, [3] = true } -- SPF data formats whose cell values this reads

-- Width, place, view, range, color and which pins show are settings too. Its default place, 44 below the top, is
-- under the top bar and above Shortest Path Forever's arrow (-120) and the quest arrow (-150).
ns.COMPASS_PINS = 14
ns.COMPASS_FOCUS = 0.14     -- radians either side of straight ahead that name a pin (8 degrees)
ns.COMPASS_EVERY = 1        -- seconds between pin rereads
ns.COMPASS_GIVERS_EVERY = 5 -- seconds between quest giver rereads (the guide's own reader caches positions)

local Q_ICONS = "Interface\\AddOns\\Questie\\Icons\\"
ns.COMPASS_ICONS = {
  turnin = Q_ICONS .. "complete", available = Q_ICONS .. "available", slay = Q_ICONS .. "slay",
  object = Q_ICONS .. "object", pin = "Interface\\Minimap\\Tracking\\Target",
}
-- Questie's townsfolk lists, one kind at a time: { list key, icon, the line under its name }.
ns.COMPASS_SERVICES = {
  { "Flight Master", "Interface\\Minimap\\Tracking\\FlightMaster", "Flight master", opt = "flight" },
  { "Innkeeper", "Interface\\Minimap\\Tracking\\Innkeeper", "Innkeeper", opt = "inn" },
  { "Banker", "Interface\\Minimap\\Tracking\\Banker", "Bank", opt = "bank" },
  { "Repair", "Interface\\Minimap\\Tracking\\Repair", "Repairs", opt = "repair" },
  { "Auctioneer", "Interface\\Minimap\\Tracking\\Auctioneer", "Auction house", opt = "auction" },
  { "Mailbox", "Interface\\Minimap\\Tracking\\Mailbox", "Mailbox", object = true, opt = "mail" },
  { "Trainer", "Interface\\Minimap\\Tracking\\Class", "Class trainer", class = true, opt = "trainer" },
}

-- Each part's own settings (Louis, 22 Nov 2026: "customization rich, dynamic"), in the shared pattern (Core.lua
-- ns.SettingsDefine): the Options page under UW Guild shows them in this order, and /uw terrain <setting> <value>
-- types them. The defaults are the look the parts shipped with. Colors: the guild's warm gold, EllesmereUI's accent
-- (read live through its skinning interface, so a change of accent recolors both), your class's color, or white.
local COLORS = { "guild", "accent", "class", "white" }
local COLOR_NAMES = { guild = "Guild gold", accent = "EllesmereUI accent", class = "Class color", white = "White" }
ns.SettingsDefine("terrain", {
  { "range", 110, 40, 250, 10, label = "Range", unit = " yd", tip = "How far around you the outline reaches." },
  { "size", 36, 15, 50, 1, label = "Size", unit = "%", tip = "The outline's size, as a share of the screen's height." },
  { "opacity", 65, 10, 100, 5, label = "Opacity", unit = "%" },
  { "thick", 2, 1, 5, 1, label = "Line width" },
  { "y", 0, -300, 300, 10, label = "Up or down", tip = "Moves the outline's middle up or down the screen." },
  { "color", "guild", choices = COLORS, names = COLOR_NAMES, label = "Color" },
  { "combat", "show", choices = { "show", "dim", "hide" }, names = { show = "Show", dim = "Dim", hide = "Hide" },
    label = "In a fight" },
  { "ride", true, label = "Zoom out while riding", tip = "Shows more ground while you move fast." },
  { "arrow", true, label = "Your arrow in the middle" },
  { "pins", true, label = "Quest and service icons" },
  { "roads", true, label = "Roads from AzerothGPS", needs = "AzerothGPS",
    tip = "AzerothGPS's roads near you, as a dashed line." },
}, "terrainSettings")
ns.SettingsDefine("compass", {
  { "width", 440, 240, 900, 20, label = "Width" },
  { "y", 44, 10, 600, 2, label = "From the top", tip = "How far below the top of the screen the compass sits." },
  { "span", 180, 90, 360, 30, label = "View", unit = "\194\176", tip = "How much of the circle around you it shows." },
  { "range", 500, 100, 2000, 50, label = "Range", unit = " yd", tip = "Pins farther away are left off. The guide's "
    .. "target and the map pin always show." },
  { "opacity", 100, 30, 100, 5, label = "Opacity", unit = "%" },
  { "color", "guild", choices = COLORS, names = COLOR_NAMES, label = "Color" },
  { "label", true, label = "Name and distance ahead" },
  { "inside", true, label = "For you inside dungeons", tip = "Inside a dungeon, the bosses that drop an upgrade for "
    .. "you or that a quest of yours names.", needs = "ForeverDungeonJournal" },
  { "quests", true, label = "Quest steps", pair = true }, { "givers", true, label = "Quest givers", pair = true },
  { "pin", true, label = "Map pin", pair = true }, { "flight", true, label = "Flight masters", pair = true },
  { "inn", true, label = "Innkeepers", pair = true }, { "bank", true, label = "Banks", pair = true },
  { "repair", true, label = "Repairs", pair = true }, { "auction", true, label = "Auction house", pair = true },
  { "mail", true, label = "Mailboxes", pair = true }, { "trainer", true, label = "Class trainer", pair = true },
}, "compassSettings")
local function T(key) return ns.Setting("terrain", key) end
local function Cs(key) return ns.Setting("compass", key) end

local GUILD_GOLD = { 1, 0.86, 0.6 }
-- The color a part is drawn in, read each time it draws.
function ns.TerrainColor(mode)
  if mode == "accent" then
    local r, gg, b
    if ns.SkinAccent then r, gg, b = ns.SkinAccent() end
    if r then return r, gg, b end
  elseif mode == "class" then
    local _, cls = call(g("UnitClass"), "player")
    local all = g("RAID_CLASS_COLORS")
    local c = type(all) == "table" and type(cls) == "string" and all[cls]
    if type(c) == "table" and type(c.r) == "number" then return c.r, c.g, c.b end
  elseif mode == "white" then
    return 1, 1, 1
  end
  return GUILD_GOLD[1], GUILD_GOLD[2], GUILD_GOLD[3]
end

local function db() return type(UW_GuildDB) == "table" and UW_GuildDB or nil end
function ns.TerrainOn() local d = db() return d ~= nil and d.terrain == true end
function ns.CompassOn() local d = db() return d ~= nil and d.compass == true end

-- ---------------------------------------------------------------------------------------------------------------
-- Ground: Shortest Path Forever's cells.

local B64 = {}
do
  local abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
  for i = 1, #abc do B64[abc:byte(i)] = i - 1 end
end
-- One tile's cell values from its grid text: a symbol under 48 is a cell (value * 16 + flags), 48 and up repeats
-- the cell before it (symbol - 47) more times. Returns a string of C * C bytes (0 blocked, 1 ground, 2 water), x-major,
-- or nil when the text doesn't fill the tile.
function ns.TerrainDecode(raw, C)
  if type(raw) ~= "string" or type(C) ~= "number" then return nil end
  local out, n, last = {}, 0, "\0"
  local char, byte = string.char, string.byte
  for i = 1, #raw do
    local sym = B64[byte(raw, i)]
    if not sym then return nil end
    if sym < 48 then
      last = char(floor(sym / 16))
      n = n + 1
      out[n] = last
    else
      for _ = 48, sym do n = n + 1; out[n] = last end
    end
    if n > C * C then return nil end -- more cells than the tile holds: refused before building more
  end
  if n ~= C * C then return nil end
  return table.concat(out)
end

local function mapData(map)
  local all = g("ShortestPathForeverPathData")
  local D = type(all) == "table" and all[map]
  if type(D) ~= "table" or type(D.cells) ~= "number" or type(D.cx0) ~= "number" or type(D.cy0) ~= "number"
    or type(D.nx) ~= "number" or type(D.ny) ~= "number" then return nil end
  if not ns.TERRAIN_FORMATS[D.format or 1] then return nil, "format " .. tostring(D.format) end
  return D
end

-- The tile's grid text: SPF's decoded copy, else its packed blocks through the game's base64 and zlib.
local function gridText(D, key)
  local raw = type(D.grid) == "table" and D.grid[key]
  if type(raw) == "string" then return raw end
  local blocks = type(D.packed) == "table" and type(D.packed.grid) == "table" and D.packed.grid[key]
  if type(blocks) ~= "table" then return nil end
  local E, M = g("C_EncodingUtil"), g("Enum")
  local zlib = type(M) == "table" and type(M.CompressionMethod) == "table" and M.CompressionMethod.Zlib
  if type(E) ~= "table" or not zlib then return nil end
  local parts = {}
  for i, block in ipairs(blocks) do
    local z = call(E.DecodeBase64, block)
    local text = z and call(E.DecompressString, z, zlib)
    if type(text) ~= "string" then return nil end
    parts[i] = text
  end
  return table.concat(parts)
end

local tiles, tileOrder = {}, {}
local function tile(D, map, key)
  local id = map .. ":" .. key
  local t = tiles[id]
  if t ~= nil then return t end
  t = ns.TerrainDecode(gridText(D, key), D.cells) or false
  tiles[id] = t
  tileOrder[#tileOrder + 1] = id
  if #tileOrder > ns.TERRAIN_CACHE then tiles[table.remove(tileOrder, 1)] = nil end
  return t
end
function ns.TerrainForget() wipe(tiles) wipe(tileOrder) end

-- The value of global cell (gx, gy) on map: x runs north and y west (UnitPosition's frame), a cell is tile / C yards.
local function cellValue(D, map, gx, gy, memo)
  local C = D.cells
  local tx, ty = floor(gx / C), floor(gy / C)
  local kx, ky = tx - D.cx0, ty - D.cy0
  if kx < 0 or ky < 0 or kx >= D.nx or ky >= D.ny then return 0 end
  local key = kx * D.ny + ky + 1
  local t = memo[key]
  if t == nil then t = tile(D, map, key); memo[key] = t end
  if not t then return 0 end
  return t:byte((gx - tx * C) * C + (gy - ty * C) + 1) or 0
end

-- Marching squares over cell centres: open = ground (a blocked patch smaller than a wall counts as open). Returns
-- flat segment ends in yards, { x1, y1, x2, y2, ... } in UnitPosition's frame, for the cells within reach of (cx, cy).
local CASES = { -- corner bits: 1 (x, y), 2 (x + 1, y), 4 (x + 1, y + 1), 8 (x, y + 1); edges 1 y-side, 2 x+1, 3 y+1, 4 x
  [1] = { 1, 4 }, [2] = { 1, 2 }, [3] = { 2, 4 }, [4] = { 2, 3 }, [5] = { 1, 2, 3, 4 }, [6] = { 1, 3 },
  [7] = { 3, 4 }, [8] = { 3, 4 }, [9] = { 1, 3 }, [10] = { 1, 4, 2, 3 }, [11] = { 2, 3 }, [12] = { 2, 4 },
  [13] = { 1, 2 }, [14] = { 1, 4 },
}
local EDGE = { { 0.5, 0 }, { 1, 0.5 }, { 0.5, 1 }, { 0, 0.5 } } -- each edge's midpoint inside the square
function ns.TerrainOutline(D, map, x, y, radius)
  local C = D.cells
  local size = ns.TERRAIN_TILE / C
  local cgx, cgy = floor(x / size), floor(y / size)
  local reach = math.ceil(radius / size) + 1
  local n0 = 2 * reach + 3
  local raw, open, memo = {}, {}, {}
  for i = 0, n0 - 1 do
    for j = 0, n0 - 1 do
      local v = cellValue(D, map, cgx - reach - 1 + i, cgy - reach - 1 + j, memo)
      raw[i * n0 + j] = v == 1 or v == 3
    end
  end
  local speck = ns.TERRAIN_SPECK
  for i = 1, n0 - 2 do
    for j = 1, n0 - 2 do
      local k = i * n0 + j
      if raw[k] then
        open[k] = true
      else
        local blocked = 0
        for di = -1, 1 do
          for dj = -1, 1 do if not raw[k + di * n0 + dj] then blocked = blocked + 1 end end
        end
        open[k] = blocked < speck
      end
    end
  end
  local out, n = {}, 0
  local r2 = (radius + size) * (radius + size)
  for i = 1, n0 - 3 do
    for j = 1, n0 - 3 do
      local k = i * n0 + j
      local case = (open[k] and 1 or 0) + (open[k + n0] and 2 or 0) + (open[k + n0 + 1] and 4 or 0)
        + (open[k + 1] and 8 or 0)
      local edges = CASES[case]
      if edges then
        -- the square's corner (i, j) is the centre of cell (gx, gy)
        local bx, by = (cgx - reach - 1 + i + 0.5) * size, (cgy - reach - 1 + j + 0.5) * size
        local mx, my = bx + size * 0.5 - x, by + size * 0.5 - y
        if mx * mx + my * my <= r2 then
          for e = 1, #edges, 2 do
            local a, b = EDGE[edges[e]], EDGE[edges[e + 1]]
            out[n + 1], out[n + 2] = bx + a[1] * size, by + a[2] * size
            out[n + 3], out[n + 4] = bx + b[1] * size, by + b[2] * size
            n = n + 4
          end
        end
      end
    end
  end
  return out
end

-- The outline's pieces joined into runs, straight stretches merged and corners rounded once (Chaikin), so walls read
-- as ground shapes rather than cell steps, with fewer lines to draw. Same flat { x1, y1, x2, y2, ... } shape.
function ns.TerrainSmooth(segs, size)
  local q = 2 / size
  local function key(x, y) return floor(x * q + 0.5) .. ":" .. floor(y * q + 0.5) end
  local at, used, nseg = {}, {}, #segs / 4
  for s = 1, nseg do
    local b = (s - 1) * 4
    for _, k in ipairs({ key(segs[b + 1], segs[b + 2]), key(segs[b + 3], segs[b + 4]) }) do
      local l = at[k]
      if not l then l = {}; at[k] = l end
      l[#l + 1] = s
    end
  end
  local function other(s, k) -- the far end of piece s seen from end k, as (x, y, key)
    local b = (s - 1) * 4
    if key(segs[b + 1], segs[b + 2]) == k then return segs[b + 3], segs[b + 4], key(segs[b + 3], segs[b + 4]) end
    return segs[b + 1], segs[b + 2], key(segs[b + 1], segs[b + 2])
  end
  local function walk(pts, k)
    while true do
      local nxt
      for _, s in ipairs(at[k] or {}) do if not used[s] then nxt = s break end end
      if not nxt then return end
      used[nxt] = true
      local x, y, k2 = other(nxt, k)
      pts[#pts + 1], pts[#pts + 2] = x, y
      k = k2
    end
  end
  local out, n = {}, 0
  local function emit(ax, ay, bx, by) out[n + 1], out[n + 2], out[n + 3], out[n + 4] = ax, ay, bx, by n = n + 4 end
  for s = 1, nseg do
    if not used[s] then
      used[s] = true
      local b = (s - 1) * 4
      local fwd = { segs[b + 3], segs[b + 4] }
      walk(fwd, key(segs[b + 3], segs[b + 4]))
      local back = { segs[b + 1], segs[b + 2] }
      walk(back, key(segs[b + 1], segs[b + 2]))
      local pts = {}
      for i = #back - 1, 1, -2 do pts[#pts + 1], pts[#pts + 2] = back[i], back[i + 1] end
      for i = 1, #fwd do pts[#pts + 1] = fwd[i] end
      -- Straight stretches: drop a point on the line between its neighbours.
      local keep = { pts[1], pts[2] }
      for i = 3, #pts - 2, 2 do
        local ax, ay = keep[#keep - 1], keep[#keep]
        local bx, by, cx, cy = pts[i], pts[i + 1], pts[i + 2], pts[i + 3]
        if abs((bx - ax) * (cy - ay) - (by - ay) * (cx - ax)) > 1e-6 then keep[#keep + 1], keep[#keep + 2] = bx, by end
      end
      keep[#keep + 1], keep[#keep + 2] = pts[#pts - 1], pts[#pts]
      local m = #keep / 2
      local closed = m > 2 and abs(keep[1] - keep[#keep - 1]) < 1e-6 and abs(keep[2] - keep[#keep]) < 1e-6
      if m == 2 then
        emit(keep[1], keep[2], keep[3], keep[4])
      else
        -- One Chaikin pass: each stretch keeps its middle half; an open run keeps its two ends.
        local px, py
        if not closed then px, py = keep[1], keep[2] end
        local first
        for i = 1, m - 1 do
          local ax, ay, bx, by = keep[2 * i - 1], keep[2 * i], keep[2 * i + 1], keep[2 * i + 2]
          local qx, qy = 0.75 * ax + 0.25 * bx, 0.75 * ay + 0.25 * by
          local rx, ry = 0.25 * ax + 0.75 * bx, 0.25 * ay + 0.75 * by
          if px then emit(px, py, qx, qy) else first = { qx, qy } end
          emit(qx, qy, rx, ry)
          px, py = rx, ry
        end
        if closed and first then emit(px, py, first[1], first[2])
        elseif not closed then emit(px, py, keep[#keep - 1], keep[#keep]) end
      end
    end
  end
  return out
end

-- ---------------------------------------------------------------------------------------------------------------
-- Where you are and which way you face. Both are nil in dungeons and while the game keeps them secret.

local function position()
  local n, w, _, map = call(g("UnitPosition"), "player")
  n, w, map = plain(n), plain(w), plain(map)
  if not (n and w and map) then return nil end
  return n, w, map
end
local function facing()
  local f = plain((call(g("GetPlayerFacing"))))
  local can = g("canaccessvalue")
  if f and can and not can(f) then return nil end
  return f
end
-- A point (north, west) relative to you, turned so straight ahead is up: screen x (right), screen y (up).
local function project(dn, dw, f)
  local c, s = cos(f), sin(f)
  return -(dw * c - dn * s), dn * c + dw * s
end
ns.TerrainProject = project
-- Bearing from you to a point, the same way GetPlayerFacing turns (0 north, growing towards west).
local function bearing(dn, dw) return math.atan2(dw, dn) % TURN end
local function relative(b, f) return (b - f + pi) % TURN - pi end -- positive: to your left
ns.CompassRelative = relative

-- ---------------------------------------------------------------------------------------------------------------
-- Pins: copied out of the guide's and Questie's tables at read time, never kept by reference (quest guide, 22 Nov).

local pins, pinsAt, giversAt, givers = {}, -math.huge, -math.huge, {}
local services = { area = nil, at = 1, kinds = {} } -- the current area's townsfolk, one kind read per reread

local function questie() return ns.GuideQuestie and ns.GuideQuestie() or nil end

local function faction()
  local f = call(g("UnitFactionGroup"), "player")
  return f == "Horde" and "H" or f == "Alliance" and "A" or nil
end

-- One kind's spots in an area, from Questie: { { n = north, w = west, name } }.
local function readKind(Q, area, kind)
  local loader = g("QuestieLoader")
  local TF = loader and call(loader.ImportModule, loader, "Townsfolk")
  if type(TF) ~= "table" then return {} end
  local ids
  if kind.class then
    local all = call(TF.GetClassTrainers)
    local _, cls = call(g("UnitClass"), "player")
    ids = type(all) == "table" and type(cls) == "string" and all[cls]
  elseif kind.object then
    local fs = TF.factionSpecificTownsfolk
    local mine = call(g("UnitFactionGroup"), "player")
    ids = type(fs) == "table" and type(mine) == "string" and type(fs[mine]) == "table" and fs[mine][kind[1]]
  else
    ids = type(TF.townsfolk) == "table" and TF.townsfolk[kind[1]]
  end
  local out, me = {}, faction()
  local query = kind.object and Q.db.QueryObjectSingle or Q.db.QueryNPCSingle
  local map = call(Q.zone.GetUiMapIdByAreaId, Q.zone, area)
  if type(ids) ~= "table" or type(query) ~= "function" or not map then return out end
  for _, id in ipairs(ids) do
    local spawns = call(query, id, "spawns")
    local here = type(spawns) == "table" and spawns[area]
    if type(here) == "table" then
      local friendly = kind.object and nil or call(query, id, "friendlyToFaction")
      if not (me and type(friendly) == "string" and not friendly:find(me, 1, true)) then
        local name = call(query, id, "name")
        for _, xy in ipairs(here) do
          if type(xy) == "table" and type(xy[1]) == "number" and xy[1] >= 0 then
            local hx, hy = call(Q.hbd.GetWorldCoordinatesFromZone, Q.hbd, xy[1] / 100, xy[2] / 100, map)
            if hx then out[#out + 1] = { n = hy, w = hx, name = type(name) == "string" and name or kind[3] } end
          end
        end
      end
    end
  end
  return out
end

local function add(list, n, w, dn, dw, name, sub, icon, lead)
  local d = sqrt(dn * dn + dw * dw)
  if d > Cs("range") and not lead then return end
  list[#list + 1] = { n = n, w = w, d = d, name = name, sub = sub, icon = icon, lead = lead }
end

-- Every pin in range, nearest first, the guide's own target always kept.
function ns.CompassPins(pn, pw, inst)
  local list, now = {}, (g("GetTime") or time)()
  local Q = questie()
  local cur = ns.GuideCurrent and ns.GuideCurrent()
  local curE = type(cur) == "table" and cur.e or nil
  local function icon(e) return e.turnin and ns.COMPASS_ICONS.turnin or (e.friendly and ns.COMPASS_ICONS.object or ns.COMPASS_ICONS.slay) end
  local quests = Cs("quests")
  if quests and curE and type(cur.p) == "table" and cur.p.inst == inst and type(cur.p.wx) == "number" then
    add(list, cur.p.wy, cur.p.wx, cur.p.wy - pn, cur.p.wx - pw, curE.name, curE.quest, icon(curE), true)
    if list[1] then list[1].guide = true end
  end
  local needs = ns.GuideNeeds and ns.GuideNeeds()
  for _, e in ipairs(quests and type(needs) == "table" and needs or {}) do
    if e ~= curE and type(e.spots) == "table" then
      local best, bd = nil, math.huge
      for _, p in ipairs(e.spots) do
        if p.inst == inst then
          local d = (p.wy - pn) * (p.wy - pn) + (p.wx - pw) * (p.wx - pw)
          if d < bd then best, bd = p, d end
        end
      end
      if best then add(list, best.wy, best.wx, best.wy - pn, best.wx - pw, e.name, e.quest, icon(e)) end
    end
  end
  local wantGivers = Cs("givers")
  if not wantGivers then givers = {} end
  if wantGivers and Q and ns.GuideAvailable and now - giversAt >= ns.COMPASS_GIVERS_EVERY then
    giversAt = now
    givers = {}
    local seen = {}
    for _, s in ipairs(ns.GuideAvailable(Q) or {}) do
      if s.inst == inst and type(s.wx) == "number" then
        local d = (s.wy - pn) * (s.wy - pn) + (s.wx - pw) * (s.wx - pw)
        local k = s.giver or s.qid
        if not seen[k] or d < seen[k].d2 then
          local q = type(s.quest) == "table" and type(s.quest.name) == "string" and s.quest.name or nil
          seen[k] = { n = s.wy, w = s.wx, d2 = d, name = s.giver or q or "Quest", sub = s.giver and q or nil }
        end
      end
    end
    for _, v in pairs(seen) do givers[#givers + 1] = v end
  end
  for _, v in ipairs(givers) do add(list, v.n, v.w, v.n - pn, v.w - pw, v.name, v.sub, ns.COMPASS_ICONS.available) end
  -- Services in the area you're in: the nearest of each kind.
  local M = g("C_Map")
  local ui = M and plain((call(M.GetBestMapForUnit, "player")))
  local area = Q and ui and call(Q.zone.GetAreaIdByUiMapId, Q.zone, ui)
  if area then
    if services.area ~= area then services.area, services.at, services.kinds = area, 1, {} end
    -- A kind switched off is skipped, and read when it is switched back on.
    while services.at <= #ns.COMPASS_SERVICES and not Cs(ns.COMPASS_SERVICES[services.at].opt) do
      services.at = services.at + 1
    end
    if services.at <= #ns.COMPASS_SERVICES then
      local kind = ns.COMPASS_SERVICES[services.at]
      services.kinds[services.at] = readKind(Q, area, kind)
      services.at = services.at + 1
    end
    for i, kind in ipairs(ns.COMPASS_SERVICES) do
      if not Cs(kind.opt) then services.kinds[i] = nil end
      local best, bd = nil, math.huge
      for _, s in ipairs(services.kinds[i] or {}) do
        local d = (s.n - pn) * (s.n - pn) + (s.w - pw) * (s.w - pw)
        if d < bd then best, bd = s, d end
      end
      if best then add(list, best.n, best.w, best.n - pn, best.w - pw, best.name, kind[3], kind[2]) end
    end
  end
  -- The game's map pin, whoever set it (Shortest Path Forever's journey goal included), unless it is the guide's.
  local pin = M and call(M.GetUserWaypoint)
  if Cs("pin") and type(pin) == "table" and pin.uiMapID and pin.position then
    local pinst, wpos = call(M.GetWorldPosFromMapPos, pin.uiMapID, pin.position)
    local pn2, pw2
    if type(wpos) == "table" then pn2, pw2 = call(wpos.GetXY, wpos) end
    pn2, pw2 = plain(pn2), plain(pw2)
    if pinst == inst and pn2 and pw2 then
      local ours = curE and abs(cur.p.wy - pn2) < 3 and abs(cur.p.wx - pw2) < 3
      if not ours then add(list, pn2, pw2, pn2 - pn, pw2 - pw, "Map pin", nil, ns.COMPASS_ICONS.pin, true) end
    end
  end
  table.sort(list, function(a, b) if a.lead ~= b.lead then return a.lead == true end return a.d < b.d end)
  for k = ns.COMPASS_PINS + 1, #list do list[k] = nil end
  return list
end

-- ---------------------------------------------------------------------------------------------------------------
-- Who else owns these places.

-- FarmHud turns the minimap into a HUD at the middle of the screen: the outline steps aside while it's up.
local function farmHudUp()
  local f = g("FarmHud")
  return type(f) == "table" and type(f.IsShown) == "function" and call(f.IsShown, f) == true
end
-- Shortest Path Forever's compass, shown while it guides a journey (its own setting, off by default).
ns.COMPASS_YIELD_TO = {
  { name = "Shortest Path Forever", leads = function()
    local spf, sdb = g("ShortestPathForever"), g("ShortestPathForeverDB")
    local api = type(spf) == "table" and spf.API
    if type(api) ~= "table" or type(api.Active) ~= "function" or type(sdb) ~= "table" then return false end
    if sdb.compass ~= true or sdb.journey == false then return false end
    return api.Active() == true
  end },
}
local function compassLeader()
  for _, o in ipairs(ns.COMPASS_YIELD_TO) do
    local ok, yes = pcall(o.leads)
    if ok and yes then return o.name end
  end
end
local function hiddenScene()
  if call(g("UnitOnTaxi"), "player") then return "taxi" end
  local wm = g("WorldMapFrame")
  if type(wm) == "table" and call(wm.IsShown, wm) then return "world map" end
end

-- ---------------------------------------------------------------------------------------------------------------
-- Drawing.

local outline, compass, driver
local state = { cell = nil, segs = nil, n = nil, w = nil, f = nil, map = nil, why = {} }
local function why(part, reason) -- kept in UW_GuildDB.terrainProbe only when it changes
  if state.why[part] == reason then return end
  state.why[part] = reason
  local d = db()
  if not d then return end
  d.terrainProbe = d.terrainProbe or {}
  d.terrainProbe[part] = reason
  d.terrainProbe.at = time()
end

local function buildOutline()
  if outline or not CreateFrame then return outline end
  local f = CreateFrame("Frame", "UW_TerrainOutline", g("UIParent"))
  f:SetFrameStrata("BACKGROUND")
  f:SetPoint("CENTER", g("UIParent"), "CENTER", 0, T("y"))
  f.atY = T("y")
  f:SetSize(1, 1)
  f:EnableMouse(false)
  f.lines, f.pins, f.roads = {}, {}, {}
  f.me = f:CreateTexture(nil, "OVERLAY")
  f.me:SetSize(16, 16)
  f.me:SetPoint("CENTER", f, "CENTER", 0, 0)
  f.me:SetTexture("Interface\\Minimap\\MinimapArrow")
  f.me:SetVertexColor(1, 0.86, 0.6, 0.8)
  f:Hide()
  outline = f
  return f
end

local function line(f, i, set, thick)
  set = set or f.lines
  local l = set[i]
  if not l then
    if not f.CreateLine then return nil end
    l = f:CreateLine(nil, "ARTWORK")
    l:SetColorTexture(1, 1, 1, 1)
    set[i] = l
  end
  if l.thick ~= thick then l.thick = thick l:SetThickness(thick) end
  return l
end

-- AzerothGPS's roads (its public interface for companion addons, AzerothGPS.Roads(continent), read only; the
-- addon is All Rights Reserved, so nothing of it is copied, only called): each edge's points, in UnitPosition's
-- frame as ours. Indexed once a continent into 200 yd squares, so a redraw looks only at the roads near you.
ns.TERRAIN_ROADS = 300 -- the most road dashes drawn
local ROAD_SQUARE = 200
local roadIndex = {}
local function roadsNear(map, pn, pw, R)
  local A = g("AzerothGPS")
  local net = type(A) == "table" and call(A.Roads, map)
  if type(net) ~= "table" or type(net.e) ~= "table" then return nil end
  local idx = roadIndex[map]
  if not idx or idx.net ~= net then
    idx = { net = net, sq = {} }
    for i, e in ipairs(net.e) do
      if type(e) == "table" then
        for k = 5, #e - 1, 2 do
          local a, b = e[k], e[k + 1]
          if type(a) == "number" and type(b) == "number" then
            local key = floor(a / ROAD_SQUARE) * 100000 + floor(b / ROAD_SQUARE)
            local sq = idx.sq[key]
            if not sq then sq = {} idx.sq[key] = sq end
            if sq[#sq] ~= i then sq[#sq + 1] = i end
          end
        end
      end
    end
    roadIndex[map] = idx
  end
  local out, seen = {}, {}
  for a = floor((pn - R) / ROAD_SQUARE) - 1, floor((pn + R) / ROAD_SQUARE) + 1 do
    for b = floor((pw - R) / ROAD_SQUARE) - 1, floor((pw + R) / ROAD_SQUARE) + 1 do
      for _, i in ipairs(idx.sq[a * 100000 + b] or {}) do
        if not seen[i] then
          seen[i] = true
          local e = net.e[i]
          for k = 5, #e - 3, 2 do
            local an, aw, bn, bw = e[k], e[k + 1], e[k + 2], e[k + 3]
            if type(bn) == "number" and type(bw) == "number" then
              local mn, mw = (an + bn) / 2 - pn, (aw + bw) / 2 - pw
              if mn * mn + mw * mw < R * R then out[#out + 1] = an out[#out + 1] = aw out[#out + 1] = bn out[#out + 1] = bw end
            end
          end
        end
      end
    end
  end
  return out
end
ns.TerrainRoadsNear = roadsNear
-- A road's pieces cut into dashes: 6 yd drawn, 6 left out.
local function dashes(segs, dash)
  local out = {}
  for k = 1, #segs, 4 do
    local an, aw, bn, bw = segs[k], segs[k + 1], segs[k + 2], segs[k + 3]
    local len = sqrt((bn - an) ^ 2 + (bw - aw) ^ 2)
    local t = 0
    while t < len do
      local t2 = math.min(len, t + dash)
      local f1, f2 = t / len, t2 / len
      out[#out + 1] = an + (bn - an) * f1 out[#out + 1] = aw + (bw - aw) * f1
      out[#out + 1] = an + (bn - an) * f2 out[#out + 1] = aw + (bw - aw) * f2
      t = t2 + dash
    end
  end
  return out
end

local function pinTex(f, i, size)
  local t = f.pins[i]
  if not t then
    t = f:CreateTexture(nil, "OVERLAY")
    f.pins[i] = t
  end
  t:SetSize(size, size)
  return t
end
local function setIcon(t, file)
  if t.file ~= file then
    t.file = file
    if t:SetTexture(file) == false then t:SetTexture("Interface\\Minimap\\Tracking\\None") end
  end
end

-- The outline's reach now: wider while you ride or run fast (more than a run's 7 yd a second), if that is on.
local function reach()
  local R = T("range")
  if T("ride") then
    local speed = plain((call(g("GetUnitSpeed"), "player")))
    if speed and speed > 8 then R = floor(R * ns.TERRAIN_RIDE + 0.5) end
  end
  return R
end
ns.TERRAIN_RIDE = 1.6
local function fighting() return call(g("UnitAffectingCombat"), "player") == true end

local function drawOutline(pn, pw, map, f, list)
  local o = buildOutline()
  if not o then return end
  local D, bad = mapData(map)
  local R = reach()
  local ui = g("UIParent")
  local px = (plain((call(ui and ui.GetHeight, ui))) or 768) * T("size") / 100
  local ppy = px / R
  if o.atY ~= T("y") then
    o.atY = T("y")
    o:ClearAllPoints()
    o:SetPoint("CENTER", ui, "CENTER", 0, o.atY)
  end
  local cr, cg, cb = ns.TerrainColor(T("color"))
  local alpha, thick = T("opacity") / 100, T("thick")
  if T("combat") == "dim" and fighting() then alpha = alpha * 0.4 end
  local fadeFrom = R * (1 - ns.TERRAIN_FADE)
  local function put(set, segs, cap, a0, th)
    local n = 0
    for k = 1, #segs, 4 do
      local an, aw, bn, bw = segs[k] - pn, segs[k + 1] - pw, segs[k + 2] - pn, segs[k + 3] - pw
      local mn, mw = (an + bn) / 2, (aw + bw) / 2
      local d = sqrt(mn * mn + mw * mw)
      if d < R and n < cap then
        local l = line(o, n + 1, set, th)
        if not l then break end
        n = n + 1
        local ax, ay = project(an, aw, f)
        local bx, by = project(bn, bw, f)
        l:SetStartPoint("CENTER", o, ax * ppy, ay * ppy)
        l:SetEndPoint("CENTER", o, bx * ppy, by * ppy)
        local a = d <= fadeFrom and 1 or (R - d) / (R - fadeFrom)
        l:SetVertexColor(cr, cg, cb, a0 * a)
        l:Show()
      end
    end
    for k = n + 1, #set do set[k]:Hide() end
    return n
  end
  local key = map .. ":" .. R
  local n
  if D then
    local size = ns.TERRAIN_TILE / D.cells
    local cell = key .. ":" .. floor(pn / size) .. ":" .. floor(pw / size)
    if cell ~= state.cell then state.cell, state.segs = cell, ns.TerrainSmooth(ns.TerrainOutline(D, map, pn, pw, R), size) end
    n = put(o.lines, state.segs, ns.TERRAIN_LINES, alpha, thick)
    why("outline", n > 0 and "drawn" or "no walls in reach")
  else
    put(o.lines, {}, 0, 0, thick)
    why("outline", bad or "no Shortest Path Forever map here")
  end
  -- AzerothGPS's roads, dashed, a little fainter than the walls; read again every 50 yd you move.
  local roads
  if T("roads") then
    local rc = key .. ":" .. floor(pn / 50) .. ":" .. floor(pw / 50)
    if rc ~= state.roadCell then
      local near = roadsNear(map, pn, pw, R + 50)
      state.roadCell, state.roads = rc, near and dashes(near, 6) or nil
    end
    roads = state.roads
  end
  local r = put(o.roads, roads or {}, ns.TERRAIN_ROADS, alpha * 0.7, math.max(1, thick - 1))
  why("roads", not T("roads") and "off" or roads and (r > 0 and "drawn" or "none in reach") or "no AzerothGPS")
  o.me:SetShown(T("arrow"))
  o.me:SetVertexColor(cr, cg, cb, 0.8)
  -- Pins within the outline, at their places.
  local shown = 0
  for _, p in ipairs(T("pins") and list or {}) do
    if p.d < R then
      shown = shown + 1
      local t = pinTex(o, shown, p.lead and 20 or 16)
      setIcon(t, p.icon)
      local x, y = project(p.n - pn, p.w - pw, f)
      t:ClearAllPoints()
      t:SetPoint("CENTER", o, "CENTER", x * ppy, y * ppy)
      t:SetAlpha(p.lead and 1 or 0.8)
      t:Show()
    end
  end
  for k = shown + 1, #o.pins do o.pins[k]:Hide() end
  o:Show()
  state.oShown = true
end

local CARDINALS = { [0] = "N", [45] = "NW", [90] = "W", [135] = "SW", [180] = "S", [225] = "SE", [270] = "E", [315] = "NE" }
local function buildCompass()
  if compass or not CreateFrame then return compass end
  local f = CreateFrame("Frame", "UW_Compass", g("UIParent"))
  f:SetFrameStrata("LOW")
  f:SetSize(Cs("width"), 24)
  f:SetPoint("TOP", g("UIParent"), "TOP", 0, -Cs("y"))
  f:EnableMouse(false)
  f.base = f:CreateTexture(nil, "BACKGROUND")
  f.base:SetPoint("LEFT", f, "LEFT", 0, 0)
  f.base:SetPoint("RIGHT", f, "RIGHT", 0, 0)
  f.base:SetHeight(1)
  f.base:SetColorTexture(1, 0.86, 0.6, 0.35)
  f.ahead = f:CreateTexture(nil, "OVERLAY") -- straight ahead
  f.ahead:SetSize(2, 14)
  f.ahead:SetPoint("CENTER", f, "CENTER", 0, -2)
  f.ahead:SetColorTexture(1, 0.82, 0, 0.9)
  f.ticks, f.marks = {}, {}
  for deg = 0, 345, 15 do
    local t = f:CreateTexture(nil, "ARTWORK")
    local major = deg % 45 == 0
    t:SetSize(1, major and 9 or 5)
    t:SetColorTexture(1, 1, 1, 1)
    local label
    if CARDINALS[deg] then
      label = f:CreateFontString(nil, "OVERLAY", deg % 90 == 0 and "GameFontNormal" or "GameFontNormalSmall")
      label:SetText(CARDINALS[deg])
      if ns.Skin then ns.Skin("Font", label) end
    end
    f.ticks[#f.ticks + 1] = { tex = t, label = label, b = deg / 180 * pi, major = major, main = deg % 90 == 0 }
  end
  f.name = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  f.name:SetPoint("TOP", f, "BOTTOM", 0, -6)
  f.sub = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  f.sub:SetPoint("TOP", f.name, "BOTTOM", 0, -1)
  if ns.Skin then ns.Skin("Font", f.name) ns.Skin("Font", f.sub) end
  f:Hide()
  compass = f
  return f
end

local function edgeAlpha(x, half) local r = abs(x) / half return r >= 1 and 0 or 1 - r * r * r end

function ns.CompassFocus(list, pn, pw, f)
  local best, br = nil, ns.COMPASS_FOCUS
  for _, p in ipairs(list or {}) do
    local r = abs(relative(bearing(p.n - pn, p.w - pw), f))
    if r < br or (p.lead and r < ns.COMPASS_FOCUS * 1.5 and not (best and best.lead)) then best, br = p, r end
  end
  return best
end

-- The strip's size, place, opacity and color, set again only when one of them changed.
local function compassLook(c)
  local r, gg, b = ns.TerrainColor(Cs("color"))
  local key = ("%d %d %d %.3f %.3f %.3f"):format(Cs("width"), Cs("y"), Cs("opacity"), r, gg, b)
  if c.look == key then return end
  c.look = key
  c:SetSize(Cs("width"), 24)
  c:ClearAllPoints()
  c:SetPoint("TOP", g("UIParent"), "TOP", 0, -Cs("y"))
  c:SetAlpha(Cs("opacity") / 100)
  c.base:SetColorTexture(r, gg, b, 0.35)
  for _, t in ipairs(c.ticks) do
    t.tex:SetVertexColor(r, gg, b, t.major and 0.8 or 0.45)
    -- North, east, south and west in the game's gold, as the minimap's; the corners in the part's color.
    if t.label and not t.main then t.label:SetTextColor(r, gg, b) end
  end
end

local function drawCompass(pn, pw, f, list)
  local c = buildCompass()
  if not c then return end
  compassLook(c)
  local half = Cs("width") / 2
  local scale = half / (Cs("span") / 360 * pi)
  for _, t in ipairs(c.ticks) do
    local x = -relative(t.b, f) * scale
    local a = edgeAlpha(x, half)
    if a > 0 then
      t.tex:ClearAllPoints()
      t.tex:SetPoint("CENTER", c, "CENTER", x, 0)
      t.tex:SetAlpha(a)
      t.tex:Show()
      if t.label then
        t.label:ClearAllPoints()
        t.label:SetPoint("BOTTOM", c, "CENTER", x, 6)
        t.label:SetAlpha(a)
        t.label:Show()
      end
    else
      t.tex:Hide()
      if t.label then t.label:Hide() end
    end
  end
  local shown = 0
  for i = #(list or {}), 1, -1 do -- farthest first, so nearer pins draw on top
    local p = list[i]
    local x = -relative(bearing(p.n - pn, p.w - pw), f) * scale
    local a = edgeAlpha(x, half)
    if p.lead and a < 0.5 then x, a = (x < 0 and -half or half) * 0.97, 0.5 end -- the guide's target stays at the edge
    if a > 0 then
      shown = shown + 1
      local t = c.marks[shown]
      if not t then t = c:CreateTexture(nil, "OVERLAY"); c.marks[shown] = t end
      local size = p.lead and 20 or 16
      t:SetSize(size, size)
      setIcon(t, p.icon)
      t:ClearAllPoints()
      t:SetPoint("CENTER", c, "CENTER", x, -1)
      t:SetAlpha(a)
      t:Show()
    end
  end
  for k = shown + 1, #c.marks do c.marks[k]:Hide() end
  local focus = Cs("label") and ns.CompassFocus(list, pn, pw, f) or nil
  -- The quest arrow already names its target and distance under it: never twice on screen.
  local arrow = focus and focus.guide and ns.GuideArrowFrame and ns.GuideArrowFrame()
  if arrow and call(arrow.IsVisible, arrow) then focus = nil end
  if focus then
    c.name:SetFormattedText("%s  |cffffd100%d yd|r", focus.name or "", floor(focus.d + 0.5))
    c.sub:SetText(focus.sub or "")
    c.name:Show()
    c.sub:Show()
  else
    c.name:Hide()
    c.sub:Hide()
  end
  c:Show()
  state.cShown = true
end

local function hideAll(part)
  if (part == nil or part == "outline") and outline then outline:Hide() state.oShown = false end
  if (part == nil or part == "compass") and compass then compass:Hide() state.cShown = false end
end

-- Inside a dungeon or raid: what the game still tells addons there (Louis, 22 Nov 2026, on a marker inside
-- dungeons from facing and speed alone). Kept in UW_GuildDB.terrainProbe.inside, a list of the last few visits, newest
-- last: { at, ver (the addon's build), kind, facing, speed, pos } with "yes", "no" or "secret". Game data only, nothing
-- about anyone.
ns.TERRAIN_INSIDE_KEEP = 8
local insideAt
local function answer(v)
  local s = g("issecretvalue")
  if v ~= nil and s and s(v) then return "secret" end
  return type(v) == "number" and "yes" or "no"
end
local function noteInside()
  local ok, inside, kind = pcall(g("IsInInstance") or function() end)
  if not (ok and inside == true) then insideAt = nil return end
  if insideAt then return end
  insideAt = time()
  local d = db()
  if not d then return end
  d.terrainProbe = d.terrainProbe or {}
  local list = type(d.terrainProbe.inside) == "table" and d.terrainProbe.inside[1] ~= nil and d.terrainProbe.inside or {}
  list[#list + 1] = { at = insideAt, ver = tostring(ns.VERSION or "?"), kind = type(kind) == "string" and kind or "?",
    facing = answer((call(g("GetPlayerFacing")))), speed = answer((call(g("GetUnitSpeed"), "player"))),
    pos = answer((call(g("UnitPosition"), "player"))) }
  while #list > ns.TERRAIN_INSIDE_KEEP do table.remove(list, 1) end
  d.terrainProbe.inside = list
end

local leadTold = false
local elapsedSince = 0
function ns.TerrainTick(elapsed)
  elapsedSince = elapsedSince + (elapsed or 0)
  if elapsed and elapsedSince < 1 / ns.TERRAIN_HZ then return end
  elapsedSince = 0
  local wantO, wantC = ns.TerrainOn(), ns.CompassOn()
  if not (wantO or wantC) then hideAll() if driver then driver:Hide() end return end
  local pn, pw, map = position()
  local f = facing()
  if not (pn and f) then
    if not pn then noteInside() end
    why("outline", pn and "facing hidden" or "no position") why("compass", pn and "facing hidden" or "no position")
    hideAll()
    return
  end
  local now, fresh = (g("GetTime") or time)(), false
  if now - pinsAt >= ns.COMPASS_EVERY then
    pinsAt, fresh = now, true
    local Q, inst = questie(), nil
    if Q then inst = select(3, call(Q.hbd.GetPlayerWorldPosition, Q.hbd)) end
    pins = ns.CompassPins(pn, pw, inst or map)
  end
  local fight = fighting()
  local moved = fresh or pn ~= state.n or pw ~= state.w or f ~= state.f or map ~= state.map or fight ~= state.fight
  state.n, state.w, state.f, state.map, state.fight = pn, pw, f, map, fight
  local scene = hiddenScene()
  if not scene and fight and T("combat") == "hide" then scene = "in a fight" end
  if wantO then
    if scene or farmHudUp() then
      why("outline", scene or "FarmHud is up")
      if outline then outline:Hide() state.oShown = false end
      state.cell = nil
    elseif moved or not state.oShown then
      drawOutline(pn, pw, map, f, pins)
    end
  elseif outline then outline:Hide() state.oShown = false end
  if wantC then
    local leader = compassLeader()
    if leader then
      why("compass", leader .. " leads")
      if compass then compass:Hide() state.cShown = false end
      if not leadTold and UW_GuildCharDB and not UW_GuildCharDB.compassLeadTold then
        leadTold = true
        UW_GuildCharDB.compassLeadTold = time()
        say(("%s's compass is guiding you. Ours returns when it's done."):format(leader))
      end
    elseif scene == "world map" then
      if compass then compass:Hide() state.cShown = false end
    elseif moved or not state.cShown then
      why("compass", "drawn")
      drawCompass(pn, pw, f, pins)
    end
  elseif compass then compass:Hide() state.cShown = false end
end

local function startDriver()
  if not CreateFrame then return end
  if not driver then
    driver = CreateFrame("Frame")
    driver:SetScript("OnUpdate", function(_, elapsed) ns.protect(ns.TerrainTick, elapsed) end)
  end
  pinsAt, giversAt, state.cell = -math.huge, -math.huge, nil
  if ns.TerrainOn() or ns.CompassOn() then driver:Show() else driver:Hide() hideAll() end
  if ns.ForYouRefresh then ns.ForYouRefresh() end -- ForYou.lua: the line inside dungeons goes with the compass
end
ns.TerrainRefresh = startDriver

local function setPart(key, arg)
  local d = db()
  if not d then return nil end
  arg = strtrim(arg or ""):lower()
  if arg == "on" then d[key] = true elseif arg == "off" then d[key] = nil else d[key] = (d[key] ~= true) or nil end
  startDriver()
  return d[key] == true
end

local function keyHint()
  local d = db()
  if d and not d.terrainKeyTold then
    d.terrainKeyTold = time()
    say("Set keys in Options > Keybindings > AddOns > Unbothered Warlords.")
  end
end

-- /uw terrain <setting> [value] and /uw compass <setting> [value]: one setting shown or changed; settings opens the
-- page, reset goes back to the defaults. Anything else that isn't on or off lists the settings.
local PARTS = { terrain = "Walkable outline", compass = "Compass" }
local function settingCommand(part, args)
  local word, rest = strtrim(args or ""):match("^(%S*)%s*(.-)$")
  word = (word or ""):lower()
  if word == "" or word == "on" or word == "off" then return false end
  if word == "settings" or word == "options" then
    if ns.OpenViewSettings then ns.OpenViewSettings() end
    return true
  end
  if word == "reset" then
    ns.SettingReset(part)
    say(("%s settings are back to the defaults."):format(PARTS[part]))
    return true
  end
  local row = ns.SettingRow(part, word)
  if not row then
    local keys = {}
    for _, r in ipairs(ns.SETTINGS[part].rows) do keys[#keys + 1] = r[1] end
    say(("%s settings: %s. /uw %s settings opens them."):format(PARTS[part], table.concat(keys, ", "), part))
    return true
  end
  if rest == "" then
    say(("%s: %s."):format(row.label, ns.SettingShown(row, ns.Setting(part, word))))
    return true
  end
  local v, err = ns.SetSetting(part, word, rest)
  if v == nil then say(("%s takes %s."):format(row.label, err)) return true end
  say(("%s: %s."):format(row.label, ns.SettingShown(row, v)))
  return true
end

ns.commands.terrain = function(args)
  if settingCommand("terrain", args) then return end
  local isOn = setPart("terrain", args)
  if isOn == nil then return end
  if not isOn then say("Walkable outline off.") return end
  say("Walkable outline on. /uw terrain again turns it off.")
  if not g("ShortestPathForeverPathData") then
    say("The walkable outline needs Shortest Path Forever. The compass works without it.")
  end
  keyHint()
end
ns.commands.compass = function(args)
  if settingCommand("compass", args) then return end
  local isOn = setPart("compass", args)
  if isOn == nil then return end
  if not isOn then say("Compass off.") return end
  say("Compass on. /uw compass again turns it off.")
  keyHint()
end

-- A changed setting shows at once: everything is drawn again, and the compass's pins are read again.
ns.OnSetting("terrain", function()
  state.cell, state.roadCell, state.oShown = nil, nil, false
  if outline then outline.atY = nil end
end)
ns.OnSetting("compass", function()
  services.area, pinsAt, state.cShown = nil, -math.huge, false
  if compass then compass.look = nil end
end)

-- The settings page: Options > AddOns > UW Guild > Outline and compass, each part with its own switch on top.
ns.SettingsPage("view", "Outline and compass", {
  { title = "Walkable outline", feature = "terrain",
    part = { label = "Show the walkable outline", on = ns.TerrainOn, cmd = "terrain",
      tip = "The ground you can walk on around you, drawn in the middle of the screen. Needs Shortest Path Forever." } },
  { title = "Compass", feature = "compass",
    part = { label = "Show the compass", on = ns.CompassOn, cmd = "compass",
      tip = "Your quests, quest givers and services across the top of the screen." } },
})
function ns.OpenViewSettings() ns.OpenSettingsPage("view") end

-- Key bindings (Bindings.xml): the names the game's key binding list shows.
BINDING_HEADER_UWGUILD = "Unbothered Warlords"
BINDING_NAME_UWGUILD_TERRAIN = "Walkable outline"
BINDING_NAME_UWGUILD_COMPASS = "Compass"
function UW_Guild_Terrain() ns.useFrom = "key" SlashCmdList.UWGUILD("terrain") end
function UW_Guild_Compass() ns.useFrom = "key" SlashCmdList.UWGUILD("compass") end

local ev = CreateFrame("Frame")
ns.listen(ev, { "PLAYER_ENTERING_WORLD", "ZONE_CHANGED_NEW_AREA" })
ev:SetScript("OnEvent", ns.guard(function(_, event)
  if event == "ZONE_CHANGED_NEW_AREA" then services.area = nil end
  if event == "PLAYER_ENTERING_WORLD" then ns.after(5, noteInside) end
  startDriver()
end))
