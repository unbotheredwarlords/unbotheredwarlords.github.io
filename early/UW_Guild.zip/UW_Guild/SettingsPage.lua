-- Settings pages (Louis, 22 Nov 2026: "customization rich"): a feature's own settings (Core.lua ns.SettingsDefine) on
-- a page of their own under Esc > Options > AddOns > UW Guild, so the main page keeps its one column of switches.
-- One pattern for every feature that has settings (the terrain view and the enchant ask agreed it, 22 Nov):
--   ns.SettingsPage(id, title, sections): sections side by side, each { title, feature, part = { label, on, cmd } };
--   part is the feature's own on/off switch at the section's top, run through its /uw command like every switch.
-- Each row of the feature's settings gets the control its kind needs: a slider for a number (the mouse wheel steps it),
-- a tick box for a yes/no (pair = true: two to a row), a button that steps through the choices for a word (right-click
-- steps back). Every change saves at once and shows at once (ns.OnSetting); the section's Defaults button goes back.
-- A row that works through another addon (needs) is greyed while that addon is off, its choice kept.
-- Built from the shared window pieces (Skin.lua ns.UI): EllesmereUI skins the tick boxes and buttons, our own fills
-- stay ours. Wired, not rebuilt: the game's Settings window hosts the page (a canvas under UW Guild where the client
-- has subpages, else a small window of its own), and nothing of Blizzard's own settings list is touched, so the page
-- can't taint it (Shortest Path Forever's settings note, 1.45.2 UI/Settings.lua: rows built from addon code there
-- tainted the settings search).
local _, ns = ...

ns.SETTINGS_PAGES = {}
function ns.SettingsPage(id, title, sections)
  ns.SETTINGS_PAGES[#ns.SETTINGS_PAGES + 1] = { id = id, title = title, sections = sections }
end

-- A setting's value in words: a number with its unit, a choice by its name, a yes/no as on or off.
function ns.SettingShown(row, v)
  if type(v) == "boolean" then return v and "on" or "off" end
  if type(v) == "number" then return ("%s%s"):format(v == math.floor(v) and ("%d"):format(v) or tostring(v), row.unit or "") end
  return row.names and row.names[v] or tostring(v)
end

local function addonOn(name)
  local A = rawget(_G, "C_AddOns")
  local ok, on = pcall(A and A.IsAddOnLoaded or rawget(_G, "IsAddOnLoaded"), name)
  return ok and on and true or false
end

ns.SETTINGS_ROW = 24      -- one control's row
ns.SETTINGS_LABEL = 0.42  -- a slider row: the label's share of the column; the slider and its value take the rest
ns.SETTINGS_VALUE = 44    -- the value's room, right of a slider

local function tip(owner, row)
  local text = row.tip or ""
  if row.needs and not addonOn(row.needs) then
    text = (text ~= "" and text .. "\n" or "") .. ("|cffffd100Needs %s.|r"):format(row.needs)
  end
  if text ~= "" then ns.UI.Tip(owner, row.label, text) end
end
local function hover(region, row)
  region:EnableMouse(true)
  region:SetScript("OnEnter", function(self) tip(self, row) end)
  region:SetScript("OnLeave", function(self) ns.UI.TipHide(self) end)
end

local function slider(parent, w)
  local UI = ns.UI
  local s = CreateFrame("Slider", nil, parent)
  s:SetOrientation("HORIZONTAL")
  s:SetSize(w, 16)
  s.track = UI.Fill(s, "BACKGROUND", 1, 1, 1, 0.18)
  s.track:SetPoint("LEFT", s, "LEFT", 0, 0)
  s.track:SetPoint("RIGHT", s, "RIGHT", 0, 0)
  UI.Thin(s.track, nil, 4)
  local thumb = s:CreateTexture(nil, "OVERLAY")
  thumb:SetSize(10, 16)
  thumb:SetColorTexture(UI.GOLD[1], UI.GOLD[2], UI.GOLD[3], 1)
  s:SetThumbTexture(thumb)
  if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
  if s.EnableMouseWheel then s:EnableMouseWheel(true) end
  return s
end

-- One section: its controls, in a column x wide from (x, top). Returns its controls' refresh and its height.
local function section(parent, sec, x, top, w)
  local UI, ROW = ns.UI, ns.SETTINGS_ROW
  local feature, refreshers, y = sec.feature, {}, top
  local busy = false -- a refresh setting the controls: no saves from it
  local head = UI.Caps(parent, sec.title)
  head:SetPoint("TOPLEFT", parent, "TOPLEFT", x, -y)
  y = y + 10 + UI.HALF
  local function box(row, bx, bw, get, set)
    local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cb:SetSize(UI.SMALL, UI.SMALL)
    cb:SetPoint("TOPLEFT", parent, "TOPLEFT", bx, -(y + (ROW - UI.SMALL) / 2))
    local label = UI.Body(parent, bw - UI.SMALL - UI.HALF, "GameFontHighlight")
    if label.SetWordWrap then label:SetWordWrap(false) end
    label:SetPoint("LEFT", cb, "RIGHT", UI.HALF, 0)
    label:SetText(row.label)
    cb:SetScript("OnClick", function(self) if not busy then ns.protect(set, self:GetChecked() and true or false) end end)
    cb:SetScript("OnEnter", function(self) tip(self, row) end)
    cb:SetScript("OnLeave", function(self) UI.TipHide(self) end)
    if cb.SetHitRectInsets then cb:SetHitRectInsets(0, -(bw - UI.SMALL), 0, 0) end
    ns.Skin("Checkbox", cb)
    refreshers[#refreshers + 1] = function()
      local missing = row.needs and not addonOn(row.needs)
      cb:SetChecked(get() and not missing)
      if cb.SetEnabled then cb:SetEnabled(not missing) end
      label:SetText(missing and ("|cff808080%s|r"):format(row.label) or row.label)
    end
    return cb
  end
  if sec.part then
    local p = sec.part
    box({ label = p.label, tip = p.tip }, x, w, p.on, function(on)
      ns.useFrom = "options"
      SlashCmdList.UWGUILD(p.cmd .. (on and " on" or " off"))
    end)
    y = y + ROW
  end
  local rows, i = ns.SETTINGS[feature] and ns.SETTINGS[feature].rows or {}, 1
  while i <= #rows do
    local row = rows[i]
    local key = row[1]
    local function get() return ns.Setting(feature, key) end
    local function set(v) ns.SetSetting(feature, key, v) end
    if type(row[2]) == "boolean" then
      local half = (w - UI.GAP) / 2
      local nextRow = rows[i + 1]
      if row.pair and nextRow and nextRow.pair and type(nextRow[2]) == "boolean" then
        box(row, x, half, get, set)
        local k2 = nextRow[1]
        box(nextRow, x + half + UI.GAP, half, function() return ns.Setting(feature, k2) end,
          function(v) ns.SetSetting(feature, k2, v) end)
        i = i + 1
      else
        box(row, x, w, get, set)
      end
    elseif type(row[2]) == "number" then
      local lw = math.floor(w * ns.SETTINGS_LABEL)
      local label = UI.Body(parent, lw - UI.HALF, "GameFontHighlight")
      if label.SetWordWrap then label:SetWordWrap(false) end
      label:SetPoint("TOPLEFT", parent, "TOPLEFT", x, -(y + (ROW - 12) / 2))
      label:SetText(row.label)
      local s = slider(parent, w - lw - ns.SETTINGS_VALUE)
      s:SetPoint("TOPLEFT", parent, "TOPLEFT", x + lw, -(y + (ROW - 16) / 2))
      s:SetMinMaxValues(row[3], row[4])
      s:SetValueStep(row[5] or 1)
      local value = UI.Body(parent, ns.SETTINGS_VALUE - UI.HALF, "GameFontHighlight")
      value:SetJustifyH("RIGHT")
      value:SetPoint("TOPRIGHT", parent, "TOPLEFT", x + w, -(y + (ROW - 12) / 2))
      s:SetScript("OnValueChanged", function(_, v)
        if busy then return end
        local kept = ns.SetSetting(feature, key, v)
        if kept ~= nil then value:SetText(ns.SettingShown(row, kept)) end
      end)
      s:SetScript("OnMouseWheel", function(self, delta)
        local v = ns.Setting(feature, key) + delta * (row[5] or 1)
        self:SetValue(math.max(row[3], math.min(row[4], v)))
      end)
      s:SetScript("OnEnter", function(self) tip(self, row) end)
      s:SetScript("OnLeave", function(self) UI.TipHide(self) end)
      hover(label, row)
      refreshers[#refreshers + 1] = function()
        local v = get()
        s:SetValue(v)
        value:SetText(ns.SettingShown(row, v))
      end
    else
      local lw = math.floor(w * ns.SETTINGS_LABEL)
      local label = UI.Body(parent, lw - UI.HALF, "GameFontHighlight")
      label:SetPoint("TOPLEFT", parent, "TOPLEFT", x, -(y + (ROW - 12) / 2))
      label:SetText(row.label)
      hover(label, row)
      local b = UI.Quiet(parent, w - lw, nil, UI.SMALL, true)
      b:SetPoint("TOPLEFT", parent, "TOPLEFT", x + lw, -(y + (ROW - UI.SMALL) / 2))
      if b.RegisterForClicks then b:RegisterForClicks("LeftButtonUp", "RightButtonUp") end
      b:SetScript("OnClick", function(_, button)
        local list, at = row.choices, 1
        for n, c in ipairs(list) do if c == get() then at = n end end
        at = (at + (button == "RightButton" and -2 or 0)) % #list + 1
        ns.protect(set, list[at])
        b:SetText(ns.SettingShown(row, get()))
      end)
      b:SetScript("OnEnter", function(self) tip(self, row) end)
      b:SetScript("OnLeave", function(self) UI.TipHide(self) end)
      ns.Skin("Button", b)
      refreshers[#refreshers + 1] = function() b:SetText(ns.SettingShown(row, get())) end
    end
    y = y + ROW
    i = i + 1
  end
  local reset = UI.Quiet(parent, 90, "Defaults", UI.SMALL, true)
  reset:SetPoint("TOPLEFT", parent, "TOPLEFT", x, -(y + UI.HALF))
  ns.Skin("Button", reset)
  local function refresh()
    busy = true
    for _, r in ipairs(refreshers) do ns.protect(r) end
    busy = false
  end
  reset:SetScript("OnClick", function()
    ns.SettingReset(feature)
    refresh()
  end)
  return refresh, y + UI.HALF + UI.SMALL - top
end

local function build(page, panel)
  local UI = ns.UI
  local built = { refresh = {} }
  local title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
  title:SetPoint("TOPLEFT", panel, "TOPLEFT", UI.PAD, -UI.PAD)
  title:SetText(page.title)
  local n = #page.sections
  local cw = ns.OPTION_W or 632
  local w = (cw - (n - 1) * UI.PAD) / n
  for k, sec in ipairs(page.sections) do
    local r = section(panel, sec, UI.PAD + (k - 1) * (w + UI.PAD), UI.PAD + 16 + UI.GROUP, w)
    built.refresh[#built.refresh + 1] = r
  end
  return built
end

local registered = {}
-- Under UW Guild in the game's Settings where the client has subpages there; on a client without them, a small window
-- of its own (the main page keeps the game's one category, as every addon has), opened the same ways.
local function window(page)
  local UI = ns.UI
  local f = CreateFrame("Frame", nil, UIParent, "BasicFrameTemplateWithInset")
  f:SetSize((ns.OPTION_W or 632) + 2 * UI.PAD, 470)
  f:SetPoint("CENTER")
  f:SetFrameStrata("DIALOG")
  f:EnableMouse(true)
  f:SetMovable(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  ns.SkinWindow(f)
  f:Hide()
  local body = CreateFrame("Frame", nil, f)
  body:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -UI.TOP + UI.PAD)
  body:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 0)
  local title = rawget(f, "TitleText")
  if type(title) == "table" and title.SetText then title:SetText(ns.OPTION_NAME) end
  local esc = rawget(_G, "UISpecialFrames") -- Esc closes it, as the game's own windows
  if type(esc) == "table" then table.insert(esc, "UW_GuildSettings_" .. page.id) end
  rawset(_G, "UW_GuildSettings_" .. page.id, f)
  return f, body
end
local function hook(page, panel)
  local built
  panel:SetScript("OnShow", function(self)
    built = built or build(page, self)
    for _, r in ipairs(built.refresh) do r() end
  end)
end
local function register()
  local S = rawget(_G, "Settings")
  local parent = ns.OptionsCategory and ns.OptionsCategory()
  for _, page in ipairs(ns.SETTINGS_PAGES) do
    local r = { page = page }
    if S and S.RegisterCanvasLayoutSubcategory and parent then
      r.panel = CreateFrame("Frame")
      r.cat = S.RegisterCanvasLayoutSubcategory(parent, r.panel, page.title)
      hook(page, r.panel)
    end
    registered[page.id] = r
  end
end
table.insert(ns.onLoad, function() ns.protect(register) end)

function ns.OpenSettingsPage(id)
  if InCombatLockdown() then ns.say("After combat, please.") return end
  local r = registered[id]
  if not r then return ns.OpenOptions() end
  if not r.cat then -- the window, made the first time it's asked for
    if not r.shell then
      r.shell, r.panel = window(r.page)
      hook(r.page, r.panel)
    end
    r.shell:Show()
    return
  end
  local S = rawget(_G, "Settings")
  local cid = r.cat.GetID and r.cat:GetID() or r.cat.ID
  if cid and S and S.OpenToCategory then S.OpenToCategory(cid) else ns.OpenOptions() end
end
function ns.SettingsPageFrame(id) return registered[id] and registered[id].panel end
