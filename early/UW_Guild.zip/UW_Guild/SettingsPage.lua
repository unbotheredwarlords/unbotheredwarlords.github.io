-- Settings pages (Louis, 22 Nov 2026: "customization rich"): a feature's own settings (Core.lua ns.SettingsDefine) on
-- a page of their own under Esc > Options > AddOns > UW Guild, so the main page keeps its one column of switches.
-- One pattern for every feature that has settings (the terrain view and the enchant ask agreed it, 22 Nov):
--   ns.SettingsPage(id, title, sections): sections side by side, each { title, feature, part = { label, on, cmd } };
--   part is the feature's own on/off switch at the section's top, run through its /uw command like every switch.
-- Each row of the feature's settings gets the control its kind needs: a slider for a number (the mouse wheel steps it),
-- a tick box for a yes/no (pair = true: two to a row), a button that steps through the choices for a word (right-click
-- steps back). Every change saves at once and shows at once (ns.OnSetting); the section's Defaults button goes back.
-- A row that works through another addon (needs) is greyed while that addon is off, its choice kept.
-- Built from the shared window pieces (Skin.lua ns.UI): EllesmereUI skins the tick boxes and buttons, our own fills
-- stay ours. Wired, not rebuilt: the game's Settings window hosts the page (a canvas under UW Guild where the client
-- has subpages, else a small window of its own), and nothing of Blizzard's own settings list is touched, so the page
-- can't taint it (Shortest Path Forever's settings note, 1.45.2 UI/Settings.lua: rows built from addon code there
-- tainted the settings search).
local _, ns = ...

ns.SETTINGS_PAGES = {}
function ns.SettingsPage(id, title, sections)
  ns.SETTINGS_PAGES[#ns.SETTINGS_PAGES + 1] = { id = id, title = title, sections = sections }
end

-- A setting's value in words: a number with its unit, a choice by its name, a yes/no as on or off.
function ns.SettingShown(row, v)
  if type(v) == "boolean" then return v and "on" or "off" end
  if type(v) == "number" then return ("%s%s"):format(v == math.floor(v) and ("%d"):format(v) or tostring(v), row.unit or "") end
  return row.names and row.names[v] or tostring(v)
end

local function addonOn(name)
  local A = rawget(_G, "C_AddOns")
  local ok, on = pcall(A and A.IsAddOnLoaded or rawget(_G, "IsAddOnLoaded"), name)
  return ok and on and true or false
end

ns.SETTINGS_ROW = 24      -- one control's row
ns.SETTINGS_LABEL = 0.42  -- a slider row: the label's share of the column; the slider and its value take the rest
ns.SETTINGS_VALUE = 52    -- the value's room, right of a slider: "500 yd" on one line (width sweep, 23 Nov 2026)

local function tip(owner, row)
  local text = row.tip or ""
  if row.needs and not addonOn(row.needs) then
    text = (text ~= "" and text .. "\n" or "") .. ("|cffffd100Needs %s.|r"):format(row.needs)
  end
  if text ~= "" then ns.UI.Tip(owner, row.label, text) end
end
local function hover(region, row)
  region:EnableMouse(true)
  region:SetScript("OnEnter", function(self) tip(self, row) end)
  region:SetScript("OnLeave", function(self) ns.UI.TipHide(self) end)
end

-- One section: its controls, in a column x wide from (x, top). Returns its controls' refresh and its height.
local function section(parent, sec, x, top, w)
  local UI, ROW = ns.UI, ns.SETTINGS_ROW
  local feature, refreshers, y = sec.feature, {}, top
  local busy = false -- a refresh setting the controls: no saves from it
  local head = UI.Caps(parent, sec.title)
  head:SetPoint("TOPLEFT", parent, "TOPLEFT", x, -y)
  local rule = UI.Wash(parent, "ARTWORK", "HORIZONTAL", ns.Skinned() and UI.EMBER or UI.GOLD, 0.55, 0.04)
  rule:SetPoint("TOPLEFT", parent, "TOPLEFT", x, -(y + 11))
  rule:SetWidth(math.min(w, 160))
  UI.Thin(rule, nil, 1)
  y = y + 10 + UI.HALF
  local function box(row, bx, bw, get, set)
    local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cb:SetSize(UI.SMALL, UI.SMALL)
    cb:SetPoint("TOPLEFT", parent, "TOPLEFT", bx, -(y + (ROW - UI.SMALL) / 2))
    local hoverBg = UI.Fill(cb, "BACKGROUND", 1, 1, 1, 0.05)
    hoverBg:SetPoint("TOPLEFT", cb, "TOPLEFT", -2, 2)
    hoverBg:SetPoint("BOTTOMRIGHT", cb, "BOTTOMLEFT", bw, -2)
    hoverBg:Hide()
    local label = UI.Body(parent, bw - UI.SMALL - UI.HALF, "GameFontHighlight")
    if label.SetWordWrap then label:SetWordWrap(false) end
    label:SetPoint("LEFT", cb, "RIGHT", UI.HALF, 0)
    label:SetText(row.label)
    cb:SetScript("OnClick", function(self) if not busy then ns.protect(set, self:GetChecked() and true or false) end end)
    cb:SetScript("OnEnter", function(self) hoverBg:Show() tip(self, row) end)
    cb:SetScript("OnLeave", function(self) hoverBg:Hide() UI.TipHide(self) end)
    if cb.SetHitRectInsets then cb:SetHitRectInsets(0, -(bw - UI.SMALL), 0, 0) end
    ns.Skin("Checkbox", cb)
    refreshers[#refreshers + 1] = function()
      local missing = row.needs and not addonOn(row.needs)
      cb:SetChecked(get() and not missing)
      if cb.SetEnabled then cb:SetEnabled(not missing) end
      label:SetText(missing and ("|cff808080%s|r"):format(row.label) or row.label)
    end
    return cb
  end
  if sec.part then
    local p = sec.part
    box({ label = p.label, tip = p.tip }, x, w, p.on, function(on)
      ns.useFrom = "options"
      SlashCmdList.UWGUILD(p.cmd .. (on and " on" or " off"))
    end)
    y = y + ROW
  end
  local rows, i = ns.SETTINGS[feature] and ns.SETTINGS[feature].rows or {}, 1
  while i <= #rows do
    local row = rows[i]
    local key = row[1]
    local function get() return ns.Setting(feature, key) end
    local function set(v) ns.SetSetting(feature, key, v) end
    if type(row[2]) == "boolean" then
      local half = (w - UI.GAP) / 2
      local nextRow = rows[i + 1]
      if row.pair and nextRow and nextRow.pair and type(nextRow[2]) == "boolean" then
        box(row, x, half, get, set)
        local k2 = nextRow[1]
        box(nextRow, x + half + UI.GAP, half, function() return ns.Setting(feature, k2) end,
          function(v) ns.SetSetting(feature, k2, v) end)
        i = i + 1
      else
        box(row, x, w, get, set)
      end
    elseif type(row[2]) == "number" then
      local lw = math.floor(w * ns.SETTINGS_LABEL)
      local label = UI.Body(parent, lw - UI.HALF, "GameFontHighlight")
      if label.SetWordWrap then label:SetWordWrap(false) end
      label:SetPoint("TOPLEFT", parent, "TOPLEFT", x, -(y + (ROW - 12) / 2))
      label:SetText(row.label)
      local s = UI.Slider(parent, w - lw - ns.SETTINGS_VALUE)
      s:SetPoint("TOPLEFT", parent, "TOPLEFT", x + lw, -(y + (ROW - 16) / 2))
      s:SetMinMaxValues(row[3], row[4])
      s:SetValueStep(row[5] or 1)
      local value = UI.Body(parent, ns.SETTINGS_VALUE - UI.HALF, "GameFontHighlight")
      value:SetJustifyH("RIGHT")
      if value.SetWordWrap then value:SetWordWrap(false) end
      value:SetPoint("TOPRIGHT", parent, "TOPLEFT", x + w, -(y + (ROW - 12) / 2))
      s:SetScript("OnValueChanged", function(_, v)
        s.SyncFill()
        if busy then return end
        local kept = ns.SetSetting(feature, key, v)
        if kept ~= nil then value:SetText(ns.SettingShown(row, kept)) end
      end)
      s:SetScript("OnMouseWheel", function(self, delta)
        local v = ns.Setting(feature, key) + delta * (row[5] or 1)
        self:SetValue(math.max(row[3], math.min(row[4], v)))
      end)
      s:SetScript("OnEnter", function(self) self.over = true self.SyncFill() tip(self, row) end)
      s:SetScript("OnLeave", function(self) self.over = false self.SyncFill() UI.TipHide(self) end)
      hover(label, row)
      refreshers[#refreshers + 1] = function()
        local v = get()
        s:SetValue(v)
        s.SyncFill()
        value:SetText(ns.SettingShown(row, v))
      end
    else
      local lw = math.floor(w * ns.SETTINGS_LABEL)
      local label = UI.Body(parent, lw - UI.HALF, "GameFontHighlight")
      label:SetPoint("TOPLEFT", parent, "TOPLEFT", x, -(y + (ROW - 12) / 2))
      label:SetText(row.label)
      hover(label, row)
      local b = UI.Quiet(parent, w - lw, nil, UI.SMALL, true)
      b:SetPoint("TOPLEFT", parent, "TOPLEFT", x + lw, -(y + (ROW - UI.SMALL) / 2))
      if b.RegisterForClicks then b:RegisterForClicks("LeftButtonUp", "RightButtonUp") end
      b:SetScript("OnClick", function(_, button)
        local list, at = row.choices, 1
        for n, c in ipairs(list) do if c == get() then at = n end end
        at = (at + (button == "RightButton" and -2 or 0)) % #list + 1
        ns.protect(set, list[at])
        b:SetText(ns.SettingShown(row, get()))
      end)
      b:SetScript("OnEnter", function(self) tip(self, row) end)
      b:SetScript("OnLeave", function(self) UI.TipHide(self) end)
      ns.Skin("Button", b)
      refreshers[#refreshers + 1] = function() b:SetText(ns.SettingShown(row, get())) end
    end
    y = y + ROW
    i = i + 1
  end
  local function refresh()
    busy = true
    for _, r in ipairs(refreshers) do ns.protect(r) end
    busy = false
  end
  -- A section that is its switch alone (Your characters) has no settings to put back, so no Defaults button.
  if #rows == 0 then return refresh, y - top end
  local reset = UI.Quiet(parent, 90, "Defaults", UI.SMALL, true)
  reset:SetPoint("TOPLEFT", parent, "TOPLEFT", x, -(y + UI.HALF))
  ns.Skin("Button", reset)
  reset:SetScript("OnClick", function()
    ns.SettingReset(feature)
    refresh()
  end)
  return refresh, y + UI.HALF + UI.SMALL - top
end

local function build(page, panel)
  local UI = ns.UI
  local built = { refresh = {} }
  local title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
  title:SetPoint("TOPLEFT", panel, "TOPLEFT", UI.PAD, -UI.PAD)
  title:SetText(page.title)
  local n = #page.sections
  local cw = ns.OPTION_W or 632
  local w = (cw - (n - 1) * UI.PAD) / n
  for k, sec in ipairs(page.sections) do
    local r = section(panel, sec, UI.PAD + (k - 1) * (w + UI.PAD), UI.PAD + 16 + UI.GROUP, w)
    built.refresh[#built.refresh + 1] = r
  end
  return built
end

local registered = {}
-- Under UW Guild in the game's Settings where the client has subpages there; on a client without them, a small window
-- of its own (the main page keeps the game's one category, as every addon has), opened the same ways.
local function window(page)
  local UI = ns.UI
  local f = CreateFrame("Frame", nil, UIParent, "BasicFrameTemplateWithInset")
  f:SetSize((ns.OPTION_W or 632) + 2 * UI.PAD, 470)
  f:SetPoint("CENTER")
  f:SetFrameStrata("DIALOG")
  f:EnableMouse(true)
  f:SetMovable(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  ns.SkinWindow(f)
  f:Hide()
  local body = CreateFrame("Frame", nil, f)
  body:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -UI.TOP + UI.PAD)
  body:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 0)
  local title = rawget(f, "TitleText")
  if type(title) == "table" and title.SetText then title:SetText(ns.OPTION_NAME) end
  local esc = rawget(_G, "UISpecialFrames") -- Esc closes it, as the game's own windows
  if type(esc) == "table" then table.insert(esc, "UW_GuildSettings_" .. page.id) end
  rawset(_G, "UW_GuildSettings_" .. page.id, f)
  return f, body
end
local function hook(page, panel)
  local built
  panel:SetScript("OnShow", function(self)
    built = built or build(page, self)
    for _, r in ipairs(built.refresh) do r() end
  end)
end
local function register()
  local S = rawget(_G, "Settings")
  local parent = ns.OptionsCategory and ns.OptionsCategory()
  for _, page in ipairs(ns.SETTINGS_PAGES) do
    local r = { page = page }
    if S and S.RegisterCanvasLayoutSubcategory and parent then
      r.panel = CreateFrame("Frame")
      r.cat = S.RegisterCanvasLayoutSubcategory(parent, r.panel, page.title)
      hook(page, r.panel)
    end
    registered[page.id] = r
  end
end
table.insert(ns.onLoad, function() ns.protect(register) end)

function ns.OpenSettingsPage(id)
  if InCombatLockdown() then ns.say("After combat, please.") return end
  local r = registered[id]
  if not r then return ns.OpenOptions() end
  if not r.cat then -- the window, made the first time it's asked for
    if not r.shell then
      r.shell, r.panel = window(r.page)
      hook(r.page, r.panel)
    end
    r.shell:Show()
    return
  end
  local S = rawget(_G, "Settings")
  local cid = r.cat.GetID and r.cat:GetID() or r.cat.ID
  if cid and S and S.OpenToCategory then S.OpenToCategory(cid) else ns.OpenOptions() end
end
function ns.SettingsPageFrame(id) return registered[id] and registered[id].panel end

-- The settings toast (Louis, 23 Nov 2026: "as features are turned on and off via addon, maybe a small popup ... that
-- asks if they'd like to view settings and menus for it that fades after like 10 seconds or combat starts"). When a
-- player switches a helper on or off with its tick in the guide, or by typing its /uw command, a small card says
-- which switch moved and offers Open settings: the feature's own settings page where it has one, else the page with
-- every switch. It is a quiet notice, never a dialog:
--   * never in a fight, and gone the moment one starts (PLAYER_REGEN_DISABLED);
--   * one card at most: a second switch replaces the first, and the same switch flipped again (its own tick on the
--     card, the guide's, a typed command) updates the card in place;
--   * once per switch per session, so a switch flipped back and forth asks once; never for a switch moved on the
--     Options page or a settings page (the player is already there), nor from a key binding (a quick show and hide);
--   * it takes no keyboard focus and no Esc: the game keeps the keys; it fades after ns.TOAST.seconds, and the time
--     waits while the pointer is on it (WCAG 2.2.2: a timed message the reader can hold);
--   * /uw hide, which hides every notice above chat, hides it too.
-- The words are the switch's own label (already cleared, Options.lua and the settings pages) and Open settings (the
-- guide's button for the same thing); its state is the tick, as everywhere (design spec: a switch has no On/Off word).
--   w, h: the card. stripe, pad, icon, gap: as a notice (Skin.lua ns.NOTICE). down: from the screen's top when the
--   guide isn't open (under it when it is, by under). seconds, fadeIn, fadeOut: its time; bar: the time line's height.
ns.TOAST = { w = 340, h = 58, stripe = 2, pad = 8, icon = 32, gap = 8, down = 200, under = 8, seconds = 10,
  fadeIn = 0.15, fadeOut = 0.4, bar = 2 }

-- A switch by its /uw command or its key: { key, label, on, cmd, set, page, icon }. The Options page's helpers first,
-- then the switch on top of a settings page (Your characters, Outline and compass, the enchant button), whose Open
-- settings goes to that page.
local function pageOf(match)
  for _, page in ipairs(ns.SETTINGS_PAGES) do
    for _, sec in ipairs(page.sections) do
      local p = sec.part
      if p and match(sec, p) then
        return { key = sec.feature, label = p.label, on = p.on, cmd = p.cmd, page = page.id, icon = page.id }
      end
    end
  end
end
function ns.ToastSwitch(cmd, key)
  for _, sw in ipairs(ns.OPTION_SWITCHES or {}) do
    if (cmd and sw.cmd == cmd) or (key and sw.key == key) then
      if not ns.SwitchShown(sw) then return nil end
      return { key = sw.key, label = sw.label, on = sw.on, cmd = sw.cmd, set = sw.set, icon = sw.key }
    end
  end
  return pageOf(function(sec, p) return (cmd and p.cmd == cmd) or (key and sec.feature == key) end)
end
local function state(sw)
  local ok, v = pcall(sw.on)
  return ok and v and true or false
end

local toast -- the card, made the first time one shows
local seen = {} -- switches that had their card this session
local function fighting()
  if InCombatLockdown() then return true end
  local f = rawget(_G, "UnitAffectingCombat")
  local ok, v = pcall(f or function() return false end, "player")
  return ok and v == true
end
local function guide()
  local g = rawget(_G, "UW_GuildHandbook")
  return type(g) == "table" and g.IsShown and g:IsShown() and g or nil
end

local function place(f)
  local T = ns.TOAST
  f:ClearAllPoints()
  local g = guide()
  if g then f:SetPoint("TOP", g, "BOTTOM", 0, -T.under) else f:SetPoint("TOP", UIParent, "TOP", 0, -T.down) end
end
-- The time line under the card: full when it shows, gone when it fades; it waits while the pointer is on the card.
local function tick(f, elapsed)
  local T = ns.TOAST
  if f.held then return end
  f.left = f.left - (tonumber(elapsed) or 0)
  local share = math.max(0, f.left) / T.seconds
  f.bar:SetWidth(math.max(1, (T.w - T.stripe) * share))
  if f.left <= 0 and not f.going then
    f.going = true
    if f.out then f.out:Play() else f:Hide() end
  end
end
local function settings(f)
  local sw = f.sw
  ns.ToastHide()
  if not sw or InCombatLockdown() then return end
  -- The guide steps aside for the page, as its own Open settings does (Handbook.lua: a window over it).
  local g = guide()
  if g then g:Hide() end
  if sw.page then ns.OpenSettingsPage(sw.page) else ns.OpenOptions() end
end
local function flip(f)
  local sw = f.sw
  if not sw then return end
  local on = not state(sw)
  if sw.set then ns.protect(sw.set, on)
  else
    ns.useFrom = "toast"
    ns.protect(SlashCmdList.UWGUILD, sw.cmd .. (on and " on" or " off"))
  end
  ns.ToastAfter(sw.key, not on, true) -- its own click: the card updates in place
end

local function buildToast()
  local UI, T = ns.UI, ns.TOAST
  local f = CreateFrame("Frame", nil, UIParent)
  f:SetSize(T.w, T.h)
  f:SetFrameStrata("DIALOG")
  if f.SetClampedToScreen then f:SetClampedToScreen(true) end
  f:EnableMouse(true) -- the pointer holds the time; no keyboard, so the game keeps every key
  f:Hide()
  UI.Fill(f, "BACKGROUND", 0.05, 0.05, 0.06, 0.94):SetAllPoints()
  UI.Wash(f, "BORDER", "HORIZONTAL", { 1, 1, 1 }, 0.05, 0):SetAllPoints()
  UI.Edges(f, "BORDER", 1, 1, 1, 0.14)
  local stripe = UI.Fill(f, "ARTWORK", UI.EMBER[1], UI.EMBER[2], UI.EMBER[3], 1)
  stripe:SetPoint("TOPLEFT")
  stripe:SetPoint("BOTTOMLEFT")
  UI.Thin(stripe, T.stripe)
  f.icon = UI.Icon(f, T.icon)
  f.icon:SetPoint("LEFT", f, "LEFT", T.stripe + T.pad, 0)
  f.check = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate")
  f.check:SetSize(UI.SMALL, UI.SMALL)
  ns.Skin("Checkbox", f.check)
  f.check:SetScript("OnClick", function() flip(f) end)
  -- The tick says its state in a word beside it ("On" or "Off"): an empty box alone read as a field to fill (third
  -- pass, 23 Nov 2026; red team: the word follows the state). The word is a click on the tick too.
  f.onWord = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  f.onWord:SetPoint("LEFT", f.check, "RIGHT", 2, 0)
  f.onWord:SetText("On")
  f.onHit = CreateFrame("Button", nil, f)
  f.onHit:SetPoint("TOPLEFT", f.onWord, "TOPLEFT", -2, 4)
  f.onHit:SetPoint("BOTTOMRIGHT", f.onWord, "BOTTOMRIGHT", 4, -4)
  f.onHit:SetScript("OnClick", function() flip(f) end)
  f.label = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  f.label:SetJustifyH("LEFT")
  if f.label.SetWordWrap then f.label:SetWordWrap(false) end
  f.open = UI.Quiet(f, 110, "Open settings", UI.SMALL, true)
  f.open:SetScript("OnClick", function() settings(f) end)
  f.close = UI.CloseMark(f)
  f.close:SetPoint("TOPRIGHT", f, "TOPRIGHT", -T.pad + 2, -T.pad + 2)
  f.close:SetScript("OnClick", function() ns.ToastHide() end)
  f.bar = UI.Fill(f, "OVERLAY", UI.GOLD[1], UI.GOLD[2], UI.GOLD[3], 0.55)
  f.bar:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", T.stripe, 0)
  UI.Thin(f.bar, T.w - T.stripe, T.bar)
  -- The pointer anywhere on it holds the time, the full label in a tooltip when it was cut.
  local function hold(on)
    f.held = on
    if on and f.going then -- caught while fading: back in full, and the time starts again
      if f.out then f.out:Stop() end
      f.going, f.left = false, T.seconds
      f:SetAlpha(1)
    end
  end
  for _, r in ipairs({ f, f.check, f.onHit, f.open, f.close }) do
    local enter, leave = r:GetScript("OnEnter"), r:GetScript("OnLeave")
    r:SetScript("OnEnter", function(self)
      hold(true)
      if enter then enter(self) end
      if self == f and f.cut and f.sw then UI.Tip(f, f.sw.label, "") end
    end)
    r:SetScript("OnLeave", function(self)
      if not (f.IsMouseOver and f:IsMouseOver()) then hold(false) end
      if leave then leave(self) end
      if self == f then UI.TipHide(f) end
    end)
  end
  -- Fades (alpha only: a hidden card is alpha 1, a shown one ends at 1).
  local function anim(from, to, secs, done)
    local g = f.CreateAnimationGroup and f:CreateAnimationGroup()
    local a = g and g.CreateAnimation and g:CreateAnimation("Alpha")
    if not a then return nil end
    a:SetFromAlpha(from)
    a:SetToAlpha(to)
    a:SetDuration(secs)
    if done then g:SetScript("OnFinished", done) end
    return g
  end
  f.inn = anim(0, 1, T.fadeIn)
  f.out = anim(1, 0, T.fadeOut, function() ns.ToastHide() end)
  f:SetScript("OnUpdate", tick)
  return f
end

-- Lays the card out for a switch, as a notice in the big addons reads: the picture, the switch's name on top in
-- white up to the close mark; under it the tick with its word on the left and Open settings on the right.
local function fill(f, sw)
  local UI, T = ns.UI, ns.TOAST
  f.sw = sw
  local row = ns.HANDBOOK_ICONS and ns.HANDBOOK_ICONS.entry[sw.icon] or nil
  if not row and ns.HANDBOOK_ICONS then row = ns.HANDBOOK_ICONS.entry[sw.key] end
  local pictured = UI.IconSet(f.icon, row)
  local left = T.stripe + T.pad + (pictured and T.icon + T.gap or 0)
  f.label:ClearAllPoints()
  f.label:SetPoint("TOPLEFT", f, "TOPLEFT", left, -T.pad - 1)
  f.check:ClearAllPoints()
  f.check:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", left - 3, T.pad - 1)
  f.check:SetChecked(state(sw))
  local c = state(sw) and UI.TEXT or UI.SOFT
  f.onWord:SetTextColor(c[1], c[2], c[3])
  f.onWord:SetText(state(sw) and "On" or "Off")
  local room = T.w - left - ns.NOTICE.close - T.pad - UI.HALF
  f.label:SetWidth(room)
  f.label:SetText(sw.label)
  local tw = f.label.GetStringWidth and tonumber(f.label:GetStringWidth()) or 0
  f.cut = tw > room
  f.open:ClearAllPoints()
  f.open:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -T.pad, T.pad - 1)
  UI.FitButton(f.open, "Open settings", 20, 90, 150)
end

function ns.ToastShown() return toast ~= nil and toast:IsShown() and toast.sw and toast.sw.key or nil end
function ns.ToastHide()
  if not toast then return end
  if toast.inn then toast.inn:Stop() end
  if toast.out then toast.out:Stop() end
  toast.going, toast.held = false, false
  toast:SetAlpha(1)
  toast:Hide()
  ns.UI.TipHide(toast)
end
-- Shows the card for a switch (ns.ToastSwitch) that just moved, if nothing says not to. Returns whether it shows.
function ns.Toast(sw)
  if type(sw) ~= "table" or fighting() or ns.ChatBarHidden() then return false end
  local panel = rawget(_G, "SettingsPanel")
  if type(panel) == "table" and panel.IsShown and panel:IsShown() then return false end -- already in the settings
  local same = ns.ToastShown() == sw.key
  if seen[sw.key] and not same then return false end
  seen[sw.key] = true
  toast = toast or buildToast()
  fill(toast, sw)
  place(toast)
  toast.left, toast.going = ns.TOAST.seconds, false
  toast.bar:SetWidth(ns.TOAST.w - ns.TOAST.stripe)
  if toast.out then toast.out:Stop() end
  toast:SetAlpha(1)
  local was = toast:IsShown()
  toast:Show()
  if not was and toast.inn then toast.inn:Play() end
  return true
end
-- After a switch's command or tick ran: before is its state before. A card only where it moved.
function ns.ToastAfter(key, before, mine)
  local sw = ns.ToastSwitch(nil, key)
  if not sw then return false end
  local now = state(sw)
  if now == before then return false end
  if mine or ns.ToastShown() == sw.key then -- the card's own switch: its tick follows, its time starts again
    if toast and toast:IsShown() then
      toast.check:SetChecked(now)
      local c = now and ns.UI.TEXT or ns.UI.SOFT
      toast.onWord:SetTextColor(c[1], c[2], c[3])
      toast.onWord:SetText(now and "On" or "Off")
      toast.left = ns.TOAST.seconds
      return true
    end
  end
  return ns.Toast(sw)
end
-- Core.lua's /uw: a typed command that names a switch. Its state before the command, or nil (not a switch, or not
-- typed: the Options page, a settings page, the guide (which asks after its own tick) and key bindings never ask).
function ns.ToastBefore(cmd, from)
  if from ~= "cmd" then return nil end
  local sw = ns.ToastSwitch(cmd)
  if not sw then return nil end
  return sw.key, state(sw)
end

local events = CreateFrame("Frame")
ns.listen(events, { "PLAYER_REGEN_DISABLED" })
events:SetScript("OnEvent", ns.guard(function() ns.ToastHide() end)) -- a fight starts: gone at once
