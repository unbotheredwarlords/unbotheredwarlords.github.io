-- Ask a guild enchanter from the character panel (Louis, 22 Nov 2026: "a button to ask a guildie enchanter from the
-- character interface for an enchant on gear from a dropdown"; 19:33: "intelligent, sensing both character and item
-- level and gold amount ... efficient power optimization").
--
-- Wire before build: what guildmates can enchant is the crafting directory's (Crafts.lua, UW_GuildDB.crafts, keys
-- e<spell id> as the enchanting window names them), the mats are its recipeInfo, the class and talent weights are
-- GearScore.lua's (ns.GearSpec: Pawn Forever, MythicSim at 60), and prices are the player's own Auctionator scan. The
-- game's own spell text says what each enchant gives; the recipe name's tier word stands in until that text loads.
--
-- Per equipped slot, the menu lists the enchants an online guild enchanter knows, best value first:
--   * power: what the enchant adds, weighed for this character's class and talents;
--   * how long it lasts: the levels until this piece is likely replaced (required level, quality; 60 keeps it);
--   * price: the mats at this player's Auctionator prices.
-- An enchant no stronger than the one already on the piece is left out, and so is one another enchant beats on both
-- power and price (Pareto). One that costs more than a share of the gold on hand, or a pricey one on a piece about to
-- be replaced, goes to the foot of the list in grey. Unpriced and unrated enchants follow the rated ones.
--
-- A click whispers that one enchanter, in the member's own words, with the item link: one whisper per click, nothing
-- automatic (Outbound.lua "enchant.ask"). Nothing is saved or shared about who asked whom. The guild's own Guild
-- Master, this player's own characters and anyone who left are never offered. /uw enchant off hides the button.
local _, ns = ...
local say = ns.say

local function g(name) return rawget(_G, name) end
local function pass(ok, ...) if ok then return ... end end
local function call(fn, ...)
  if type(fn) ~= "function" then return nil end
  return pass(pcall(fn, ...))
end
local function plain(v) return v ~= nil and not ns.isSecret(v) and v or nil end
local function on() return not (UW_GuildDB and UW_GuildDB.enchantButton == false) end

ns.ENCHANT_MAX_LEVEL = 60
ns.ENCHANT_LIFE_MAX = 20        -- levels: what a piece worn at 60 counts as
ns.ENCHANT_KEEP = { [2] = 6, [3] = 10, [4] = 16 } -- levels past its required level a piece is worn, by quality
ns.ENCHANT_KEEP_PLAIN = 4       -- grey and white pieces
ns.ENCHANT_BUDGET = 0.2         -- share of the gold on hand one enchant may take while leveling
ns.ENCHANT_BUDGET_MAX = 0.5     -- ...and at 60
ns.ENCHANT_SHORT = 2            -- levels left at which a piece counts as about to be replaced
ns.ENCHANT_SHORT_SHARE = 0.05   -- ...and a pricey enchant on it is one over this share of the gold on hand
ns.ENCHANT_FLOOR = 0.1          -- an enchant under this share of the slot's strongest adds next to nothing: left out
ns.ENCHANT_ROWS = 8             -- rows per slot in the menu
ns.ENCHANT_RESEND = 30          -- seconds before the same ask to the same enchanter goes again

-- The slot words in enchanting recipe names, and the equipped slots each fits. "Weapon" fits any melee weapon, a
-- two-hander too; "2H Weapon" only a two-hander; "Shield" only a shield.
local WEAPON = { INVTYPE_WEAPON = true, INVTYPE_WEAPONMAINHAND = true, INVTYPE_WEAPONOFFHAND = true,
  INVTYPE_2HWEAPON = true }
ns.ENCHANT_SLOTS = {
  { id = 5, name = "Chest", words = { Chest = true } },
  { id = 8, name = "Feet", words = { Boots = true } },
  { id = 9, name = "Wrist", words = { Bracer = true, Bracers = true } },
  { id = 10, name = "Hands", words = { Gloves = true } },
  { id = 15, name = "Back", words = { Cloak = true } },
  { id = 16, name = "Main Hand", words = { Weapon = true, ["2H Weapon"] = true } },
  { id = 17, name = "Off Hand", words = { Weapon = true, Shield = true } },
}
function ns.EnchantFits(word, slotID, loc)
  if slotID == 16 or slotID == 17 then
    if word == "Shield" then return slotID == 17 and loc == "INVTYPE_SHIELD" end
    if word == "2H Weapon" then return slotID == 16 and loc == "INVTYPE_2HWEAPON" end
    if word == "Weapon" then return WEAPON[loc or ""] == true end
    return false
  end
  for _, s in ipairs(ns.ENCHANT_SLOTS) do
    if s.id == slotID then return s.words[word] == true end
  end
  return false
end

-- "Enchant Bracer - Lesser Stamina" -> "Bracer", "Lesser Stamina".
function ns.EnchantParts(name)
  if type(name) ~= "string" then return nil end
  local word, effect = name:match("^Enchant (.-) %- (.+)$")
  return word, effect
end

-- What an enchant gives, in GearScore.lua's stat names: stats, kind ("stat", "utility" or "proc"). From the spell's
-- own text when it has loaded ("Permanently enchant bracers to increase Stamina by 3."), else from the recipe name.
local STATS = { "Stamina", "Strength", "Agility", "Intellect", "Spirit" }
local SCHOOL = { fire = "FireResist", frost = "FrostResist", nature = "NatureResist", shadow = "ShadowResist",
  arcane = "ArcaneResist" }
local UTILITY = { "fishing", "herbalism", "mining", "skinning", "speed" }
local function fromText(t, n, speed)
  local out = {}
  if t:find("all stats", 1, true) or t:find("all attributes", 1, true) then
    for _, s in ipairs(STATS) do out[s] = n end
    return out
  end
  if t:find("all resist", 1, true) or t:find("all schools", 1, true) or t:find("all spell resist", 1, true) then
    out.AllResist = n
    return out
  end
  local school = t:match("(%a+) resistance")
  if school and SCHOOL[school] then out[SCHOOL[school]] = n return out end
  if t:find("mana every 5", 1, true) or t:find("mana per 5", 1, true) then out.Mp5 = n return out end
  if t:find("healing", 1, true) then out.Healing = n return out end
  if t:find("spell damage", 1, true) or t:find("spell power", 1, true) then
    out.SpellDamage, out.Healing = n, n
    return out
  end
  for _, s in ipairs(STATS) do
    if t:find(s:lower(), 1, true) then out[s] = n return out end
  end
  if t:find("health", 1, true) then out.Health = n return out end
  if t:find("mana", 1, true) then out.Mana = n return out end
  if t:find("armor", 1, true) then out.Armor = n return out end
  if t:find("defense", 1, true) or t:find("deflect", 1, true) then out.DefenseRating = n return out end
  if t:find("damage", 1, true) or t:find("striking", 1, true) or t:find("impact", 1, true) then
    out.MeleeDps = n / ((tonumber(speed) or 0) > 0 and speed or 2.6) -- a point of weapon damage, per swing
    return out
  end
  return nil
end

-- The recipe name's tier word, for an enchant whose spell text hasn't loaded: the usual Classic amounts by kind.
local TIERS = { Minor = 1, Inferior = 2, Lesser = 3, [""] = 4, Greater = 5, Superior = 6, Major = 7 }
local PER_TIER = { -- the amount at each step of TIERS
  stat = { 1, 2, 3, 5, 7, 9, 11 }, health = { 5, 10, 15, 25, 35, 50, 100 }, mana = { 5, 10, 20, 30, 50, 65, 100 },
  armor = { 10, 15, 20, 30, 50, 70, 90 }, striking = { 1, 1, 2, 3, 4, 5, 6 }, impact = { 2, 2, 3, 5, 7, 9, 11 },
  allstats = { 1, 1, 2, 3, 4, 5, 6 }, resist = { 1, 3, 5, 7, 9, 11, 13 }, allresist = { 1, 1, 2, 3, 5, 7, 9 },
  defense = { 1, 1, 2, 3, 4, 5, 6 },
}
local function tierOf(effect)
  local first, rest = effect:match("^(%a+) (.+)$")
  if first and TIERS[first] then return TIERS[first], rest end
  return TIERS[""], effect
end

function ns.EnchantEffect(name, desc, speed)
  local word, effect = ns.EnchantParts(name)
  if not word then return nil end
  local low = (effect or ""):lower()
  for _, u in ipairs(UTILITY) do
    if low:find(u, 1, true) then return {}, "utility" end
  end
  local t = type(desc) == "string" and not ns.isSecret(desc) and desc:lower() or ""
  if t ~= "" then
    if t:find("chance", 1, true) or t:find("often", 1, true) or t:find("occasionally", 1, true)
      or t:find("sometimes", 1, true) then
      return {}, "proc"
    end
    local n = tonumber(t:match("(%d+)"))
    local st = n and fromText(t, n, speed)
    if st then return st, "stat" end
  end
  -- From the name alone.
  local step, rest = tierOf(effect)
  local r = rest:lower()
  local kind = (r == "stats") and "allstats" or (r == "health") and "health" or (r == "mana") and "mana"
    or (r == "protection" or r == "defense") and "armor" or (r == "striking") and "striking"
    or (r == "impact") and "impact" or (r == "resistance") and "allresist" or r:find("resistance", 1, true) and "resist"
    or (r == "deflect" or r == "deflection") and "defense" or "stat"
  local n = PER_TIER[kind][step]
  local st
  if kind == "allstats" then st = fromText("all stats", n)
  elseif kind == "allresist" then st = { AllResist = n }
  elseif kind == "resist" then st = fromText(r, n)
  elseif kind == "armor" then st = { Armor = n }
  elseif kind == "defense" then st = { DefenseRating = n }
  elseif kind == "striking" or kind == "impact" then st = fromText("damage", n, speed)
  else st = fromText(r, n, speed) end
  if not st or not next(st) then return nil end
  return st, "stat", true -- true: from the name, an estimate
end

-- The spell's text, once the client has it. Asked for ahead (the panel's OnShow), so the first open usually has it.
local descs = {}
local function spellDesc(id)
  if descs[id] then return descs[id] end
  local sp = g("C_Spell")
  local d = call(sp and sp.GetSpellDescription or g("GetSpellDescription"), id)
  if type(d) == "string" and not ns.isSecret(d) and d ~= "" then descs[id] = d return d end
  call(sp and sp.RequestLoadSpellData, id)
end
ns.EnchantSpellDesc = spellDesc

-- Who is never offered: this player's own characters (UW_GuildDB.alts and this one) and the Guild Master's (point
-- members to each other, not to Louis). Short names.
local function notOffered()
  local out = {}
  local me = ns.me and ns.me()
  if me then out[ns.shortName(me)] = true end
  for n in pairs(type(UW_GuildDB) == "table" and type(UW_GuildDB.alts) == "table" and UW_GuildDB.alts or {}) do
    if type(n) == "string" then out[ns.shortName(n)] = true end
  end
  for full, rank in pairs(ns.rankOf or {}) do
    if rank == 0 and type(full) == "string" then out[ns.shortName(full)] = true end
  end
  -- The Guild Master's other characters, where this client knows them (WeekOne.lua: on officers' clients once his
  -- character list is shared; a member's client knows only the rank's holder).
  local his = ns.WeekOneIsHis or ns.IsLouis
  return setmetatable(out, { __index = function(_, name)
    return type(his) == "function" and type(name) == "string" and (call(his, name) and true) or nil
  end })
end

-- Every enchant the guild's directory knows: { [key] = { name, word, effect, who = { name, rank } } }.
function ns.EnchantDirectory()
  local out, skip = {}, notOffered()
  local db = UW_GuildDB or {}
  for who, e in pairs(type(db.crafts) == "table" and db.crafts or {}) do
    local m = type(db.members) == "table" and db.members[who]
    local p = type(e) == "table" and type(e.profs) == "table" and e.profs.Enchanting
    if p and type(p.rec) == "table" and not (type(m) == "table" and m.left) and not skip[who] then
      for k, name in pairs(p.rec) do
        local word, effect = ns.EnchantParts(name)
        if word and type(k) == "string" then
          local d = out[k] or { key = k, name = name, word = word, effect = effect, who = {} }
          out[k] = d
          d.who[#d.who + 1] = { name = who, rank = tonumber(p.r) or 0 }
        end
      end
    end
  end
  return out
end

-- Online guildmates who could be asked, short name -> full name (never one notOffered names).
local function askable()
  local out, mine = {}, notOffered()
  for i = 1, (call(g("GetNumGuildMembers")) or 0) do
    local full, _, rank, _, _, _, _, _, online = call(g("GetGuildRosterInfo"), i)
    full = plain(full) and ns.fullName(full)
    if full and online and rank ~= 0 and not mine[ns.shortName(full)] then out[ns.shortName(full)] = full end
  end
  return out
end
ns.EnchantAskable = askable

-- Mats in "id:count:name,..." (Crafts.lua recipeInfo): their price at this player's Auctionator, and whether the bags
-- hold them all. Price nil when any mat has none.
local function priceOf(id)
  local auc = g("Auctionator")
  local api = type(auc) == "table" and type(auc.API) == "table" and auc.API.v1
  local v = api and call(api.GetAuctionPriceByItemID, "UW_Guild", id)
  if type(v) == "number" and not ns.isSecret(v) and v > 0 then return v end
  v = ns.GoldPrice and call(ns.GoldPrice, id)
  if type(v) == "number" and v > 0 then return v end
end
function ns.EnchantMats(key)
  local info = type(UW_GuildDB) == "table" and type(UW_GuildDB.recipeInfo) == "table" and UW_GuildDB.recipeInfo[key]
  local reag = type(info) == "table" and info.reag
  if type(reag) ~= "string" or reag == "" then return nil end
  local items = g("C_Item")
  local count = items and items.GetItemCount or g("GetItemCount")
  local mats, cost, have = {}, 0, true
  for id, n, name in reag:gmatch("(%d+):(%d+):([^,]*)") do
    id, n = tonumber(id), tonumber(n)
    local p = priceOf(id)
    cost = cost and p and cost + p * n or nil
    if (tonumber((call(count, id))) or 0) < n then have = false end
    mats[#mats + 1] = { id = id, n = n, name = name }
  end
  if #mats == 0 then return nil end
  return mats, cost, have
end

-- Levels until a piece is likely replaced: its required level plus a few by quality; at 60, ENCHANT_LIFE_MAX.
function ns.EnchantLife(level, req, quality)
  level = tonumber(level) or 1
  if level >= ns.ENCHANT_MAX_LEVEL then return ns.ENCHANT_LIFE_MAX end
  local keep = ns.ENCHANT_KEEP[tonumber(quality) or 2] or (tonumber(quality) or 2) > 4 and 16 or ns.ENCHANT_KEEP_PLAIN
  local left = (tonumber(req) and req > 0 and req or level) + keep - level
  return math.max(1, math.min(ns.ENCHANT_LIFE_MAX, left))
end

-- The enchant already on a piece, as power, when the tooltip names it (nil: none, or not readable).
local function current(slotID, link, weights, speed)
  local ench = type(link) == "string" and tonumber(link:match("item:%d+:(%d*)")) or 0
  if ench == 0 then return nil, false end
  local tip, enum = g("C_TooltipInfo"), g("Enum")
  local kind = enum and enum.TooltipDataLineType and enum.TooltipDataLineType.ItemEnchantmentPermanent
  local data = kind and tip and call(tip.GetInventoryItem, "player", slotID)
  for _, l in ipairs(type(data) == "table" and type(data.lines) == "table" and data.lines or {}) do
    local text = plain(l.leftText)
    if l.type == kind and type(text) == "string" then
      local t = text:lower():gsub("^enchanted: ", "")
      local n = tonumber(t:match("(%d+)"))
      local st = n and fromText(t, n, speed)
      if st then return ns.GearValue(st, weights), true end
    end
  end
  return nil, true
end

-- One equipped slot's list: { slot, link, item, life, enchanted, rows = { row... } }, row = { key, name, effect,
-- power, cost, have, mats, who (full names online), offline (short names), note, best, low (demoted), estimate }.
-- ctx (tests): { level, gold, weights, speed = { [16] = n, [17] = n }, online, dir }.
local function equipped(slotID)
  local link = call(g("GetInventoryItemLink"), "player", slotID)
  if type(link) ~= "string" or ns.isSecret(link) then return nil end
  local items = g("C_Item")
  local name, _, quality, ilvl, req, _, _, _, loc = call(items and items.GetItemInfo or g("GetItemInfo"), link)
  return link, name, quality, ilvl, req, loc
end

function ns.EnchantContext()
  local spec = ns.GearSpec and call(ns.GearSpec)
  local mh, oh = call(g("UnitAttackSpeed"), "player")
  return {
    level = tonumber(plain(call(g("UnitLevel"), "player"))) or 1,
    gold = tonumber(plain(call(g("GetMoney")))) or 0,
    weights = spec and spec.weights or { Stamina = 1, Strength = 1, Agility = 1, Intellect = 1, Spirit = 1 },
    speed = { [16] = tonumber(mh), [17] = tonumber(oh) },
    online = askable(),
    dir = ns.EnchantDirectory(),
  }
end

local function rankWho(list, online)
  local up, away = {}, {}
  table.sort(list, function(a, b) return a.rank > b.rank or a.rank == b.rank and a.name < b.name end)
  for _, w in ipairs(list) do
    if online[w.name] then up[#up + 1] = online[w.name] else away[#away + 1] = w.name end
  end
  return up, away
end

function ns.EnchantSlot(slotID, ctx)
  local link, item, quality, _, req, loc = equipped(slotID)
  if not link then return nil end
  local life = ns.EnchantLife(ctx.level, req, quality)
  local speed = ctx.speed and ctx.speed[slotID]
  local have, enchanted = current(slotID, link, ctx.weights, speed)
  local share = ctx.level >= ns.ENCHANT_MAX_LEVEL and ns.ENCHANT_BUDGET_MAX or ns.ENCHANT_BUDGET
  local budget = (ctx.gold or 0) * share
  local rated, unrated = {}, {}
  for key, d in pairs(ctx.dir) do
    if ns.EnchantFits(d.word, slotID, loc) then
      local id = tonumber(key:match("^e(%d+)$"))
      local st, kind, estimate = ns.EnchantEffect(d.name, id and spellDesc(id), speed)
      local power = st and kind == "stat" and ns.GearValue(st, ctx.weights) or nil
      local mats, cost, gotMats = ns.EnchantMats(key)
      local who, offline = rankWho(d.who, ctx.online or {})
      local row = { key = key, name = d.name, effect = d.effect, power = power, cost = cost, have = gotMats, mats = mats,
        who = who, offline = offline, estimate = estimate, kind = kind }
      if power and power > 0 then
        if not (have and power <= have + 1e-9) then rated[#rated + 1] = row end
      elseif kind == "utility" or kind == "proc" or not st then
        unrated[#unrated + 1] = row
      end
    end
  end
  -- Next to nothing for this character (defense for a caster): left out. Then Pareto: drop a priced enchant another
  -- beats on power and price.
  local top = 0
  for _, a in ipairs(rated) do top = math.max(top, a.power) end
  local keep = {}
  for _, a in ipairs(rated) do
    local beaten = a.power < top * ns.ENCHANT_FLOOR
    if a.cost and not beaten then
      for _, b in ipairs(rated) do
        if b ~= a and b.cost and b.power >= a.power and b.cost <= a.cost and (b.power > a.power or b.cost < a.cost) then
          beaten = true
          break
        end
      end
    end
    if not beaten then keep[#keep + 1] = a end
  end
  for _, r in ipairs(keep) do
    r.value = r.cost and r.power * life / math.max(r.cost, 1) or nil
    if r.cost and budget > 0 and r.cost > budget then r.low, r.note = true, "pricey for your gold"
    elseif r.cost and (ctx.gold or 0) <= 0 then r.low, r.note = true, "pricey for your gold"
    elseif r.cost and life <= ns.ENCHANT_SHORT and r.cost > (ctx.gold or 0) * ns.ENCHANT_SHORT_SHARE then
      r.low, r.note = true, "gear replaced soon"
    elseif not r.cost and life <= ns.ENCHANT_SHORT then r.low, r.note = true, "gear replaced soon"
    elseif not r.cost then r.note = "no price yet" end
  end
  -- Order: online first; then affordable priced by value, unpriced by power, demoted by value.
  local function group(r)
    if #r.who == 0 then return 4 end
    if r.low then return 3 end
    if not r.cost then return 2 end
    return 1
  end
  table.sort(keep, function(a, b)
    local ga, gb = group(a), group(b)
    if ga ~= gb then return ga < gb end
    if a.value and b.value and a.value ~= b.value then return a.value > b.value end
    if a.power ~= b.power then return a.power > b.power end
    return a.name < b.name
  end)
  if keep[1] and group(keep[1]) == 1 then keep[1].best = true end
  table.sort(unrated, function(a, b) return a.name < b.name end)
  for _, r in ipairs(unrated) do keep[#keep + 1] = r end
  return { slot = slotID, link = link, item = item, life = life, enchanted = enchanted, rows = keep }
end

-- Every slot with at least one enchant the guild knows.
function ns.EnchantPlan(ctx)
  ctx = ctx or ns.EnchantContext()
  local out = {}
  for _, s in ipairs(ns.ENCHANT_SLOTS) do
    local p = ns.EnchantSlot(s.id, ctx)
    if p and #p.rows > 0 then p.label = s.name out[#out + 1] = p end
  end
  return out, ctx
end

-- The ask -----------------------------------------------------------------------------------------------------------
local sentAt = {}
function ns.EnchantAskText(row, link)
  return ("Hi! Could you put %s on my %s? %s"):format(row.name, link,
    row.have and "I have the mats." or "I can bring the mats.")
end
function ns.EnchantAsk(row, link, to)
  if not (row and link and to) then return false end
  local k = to .. "\t" .. row.key
  local now = GetTime and GetTime() or 0
  if sentAt[k] and now - sentAt[k] < ns.ENCHANT_RESEND then return false end
  local ok = ns.chat("enchant.ask", ns.EnchantAskText(row, link), "WHISPER", to)
  if ok then sentAt[k] = now end
  return ok
end

-- The menu ----------------------------------------------------------------------------------------------------------
local function money(c)
  local cur = g("C_CurrencyInfo")
  return call(g("GetCoinTextureString") or (cur and cur.GetCoinTextureString), c) or (tostring(c) .. "c")
end
-- one: the enchanter every row of this slot would whisper, named once in the slot's title instead of on each row.
function ns.EnchantRowText(r, one)
  local parts = { r.effect }
  if r.cost then parts[#parts + 1] = money(r.cost) end
  if #r.who > 0 then
    if r.who[1] ~= one then parts[#parts + 1] = ns.shortName(r.who[1]) end
  elseif r.offline[1] then parts[#parts + 1] = r.offline[1] .. " offline" end
  if r.note then parts[#parts + 1] = r.note end
  local text = table.concat(parts, " · ")
  if r.best then text = "Best: " .. text end
  if r.low or #r.who == 0 then text = "|cff808080" .. text .. "|r" end
  return text
end
local function rowTip(tooltip, r)
  tooltip:SetText(r.name, 1, 1, 1)
  if r.mats then
    local names = {}
    for _, m in ipairs(r.mats) do names[#names + 1] = m.n > 1 and ("%s x%d"):format(m.name, m.n) or m.name end
    tooltip:AddLine("Mats: " .. table.concat(names, ", ") .. (r.have and " (in your bags)" or ""), 1, 0.82, 0, true)
  end
  if r.best then tooltip:AddLine("Most power for the gold on this piece.", 0.25, 1, 0.25, true) end
  if #r.who > 1 then
    local also = {}
    for i = 2, math.min(#r.who, 4) do also[#also + 1] = ns.shortName(r.who[i]) end
    tooltip:AddLine("Also online: " .. table.concat(also, ", "), 0.8, 0.8, 0.8, true)
  end
  tooltip:AddLine(#r.who > 0 and ("Click to whisper %s."):format(ns.shortName(r.who[1]))
    or "No one who knows it is online.", 0.6, 0.6, 0.6, true)
end

function ns.EnchantMenu(owner)
  local menu = g("MenuUtil")
  if not (menu and menu.CreateContextMenu) then ns.commands.enchant("") return end
  local plan = ns.EnchantPlan()
  menu.CreateContextMenu(owner, function(_, root)
    root:CreateTitle("Ask a guild enchanter")
    if #plan == 0 then
      local none = root:CreateButton("No guild enchanter knows an enchant for your gear yet.", function() end)
      none:SetEnabled(false)
      return
    end
    for _, p in ipairs(plan) do
      local slot = root:CreateButton(("%s: %s%s"):format(p.label, p.item or "?", p.enchanted and " (enchanted)" or ""))
      local one
      for i = 1, math.min(#p.rows, ns.ENCHANT_ROWS) do
        local w = p.rows[i].who[1]
        if w and (one == nil or one == w) then one = w elseif w then one = false break end
      end
      if one then slot:CreateTitle(("Asks go to %s"):format(ns.shortName(one))) end
      for i = 1, math.min(#p.rows, ns.ENCHANT_ROWS) do
        local r = p.rows[i]
        local b = slot:CreateButton(ns.EnchantRowText(r, one or nil), function()
          ns.protect(ns.EnchantAsk, r, p.link, r.who[1])
        end)
        if #r.who == 0 then b:SetEnabled(false) end
        if b.SetTooltip then b:SetTooltip(function(tooltip) rowTip(tooltip, r) end) end
      end
    end
  end)
end

-- /uw enchant: the best ask per slot in chat; on and off for the button.
ns.commands.enchant = function(args)
  local w = strtrim(args or ""):lower()
  if w == "off" or w == "on" then
    if w == "on" then UW_GuildDB.enchantButton = nil else UW_GuildDB.enchantButton = false end
    if ns.EnchantButtonRefresh then ns.EnchantButtonRefresh() end
    say(w == "off" and "Enchant button off. /uw enchant on brings it back."
      or "Enchant button on: bottom left of your character panel.")
    return
  end
  local plan = ns.EnchantPlan()
  if #plan == 0 then say("No guild enchanter knows an enchant for your gear yet.") return end
  for _, p in ipairs(plan) do
    local r = p.rows[1]
    say(("%s: %s"):format(p.label, (ns.EnchantRowText(r):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))))
  end
  say("Click the enchant button on your character panel to ask.")
end

-- The button: bottom left of the character panel, under the wrist slot (Blizzard's sheet and EllesmereUI's skin of
-- it alike), on the slots' own frame so it goes with the paper doll tab.
local button
local function refresh()
  if not button then return end
  button:SetShown(on() and ns.tracksGuild() and true or false)
end
ns.EnchantButtonRefresh = refresh

local function warm() -- ask for the spell texts ahead, so the first open has them
  for key in pairs(ns.EnchantDirectory()) do
    local id = tonumber(key:match("^e(%d+)$"))
    if id then spellDesc(id) end
  end
end

function ns.EnchantButton()
  if button then return button end
  local parent, wrist = g("PaperDollItemsFrame"), g("CharacterWristSlot")
  if not (parent and wrist) then return nil end
  button = CreateFrame("Button", "UW_GuildEnchantButton", parent)
  button:SetSize(22, 22)
  button:SetPoint("TOP", wrist, "BOTTOM", 0, -6)
  button:SetFrameLevel((call(parent.GetFrameLevel, parent) or 1) + 6)
  local edge = button:CreateTexture(nil, "BACKGROUND") -- the grey edge EllesmereUI gives an empty slot
  edge:SetPoint("TOPLEFT", -1, 1)
  edge:SetPoint("BOTTOMRIGHT", 1, -1)
  edge:SetColorTexture(0.25, 0.25, 0.25, 1)
  local icon = button:CreateTexture(nil, "ARTWORK")
  icon:SetAllPoints()
  icon:SetTexture("Interface\\Icons\\Trade_Engraving")
  icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  button:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
  button:SetScript("OnClick", function(self) ns.protect(ns.EnchantMenu, self) end)
  ns.useButton(button, "enchant ask")
  button:SetScript("OnEnter", function(self)
    ns.protect(warm)
    local tip = g("GameTooltip")
    if not tip then return end
    tip:SetOwner(self, "ANCHOR_RIGHT")
    tip:SetText("Ask a guild enchanter")
    tip:AddLine("Best value for your level, gear and gold.", 1, 1, 1, true)
    tip:AddLine("/uw enchant off hides this.", 0.6, 0.6, 0.6, true)
    tip:Show()
  end)
  button:SetScript("OnLeave", function() local tip = g("GameTooltip"); if tip then tip:Hide() end end)
  refresh()
  return button
end

local f = CreateFrame("Frame")
ns.listen(f, { "PLAYER_LOGIN", "PLAYER_GUILD_UPDATE" })
f:SetScript("OnEvent", ns.guard(function()
  if not ns.EnchantButton() then return end
  refresh()
  local frame = g("CharacterFrame")
  if frame and frame.HookScript and not f.hooked then
    f.hooked = true
    frame:HookScript("OnShow", function() ns.protect(refresh); ns.protect(warm) end)
  end
end))
