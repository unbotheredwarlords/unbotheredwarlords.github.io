-- A Share Quest click the game refused in a fight goes out as the fight ends, and every Share Quest click is one
-- trace row (Louis, 15 Nov 2026: "I really don't want to lose open map").
--
-- Why a click is refused: a map addon that drives the game's world map (OpenMap does, to stitch the zones together)
-- makes the game treat the map, and the quest log beside it, as addon code. On Forever addon code may not share a
-- quest while the game restricts addons (combat, an encounter), so the quest details' Share Quest button does
-- nothing there: "AddOn 'OpenMap' tried to call the protected function 'QuestLogPushQuest()'" (Louis's client, 12
-- and 14 Nov 2026). Unrestricted, the same call works from addon code (EllesmereUI's quest tracker shares that way).
-- No patch to OpenMap, option, load order or secure button changes that:
-- /mnt/project-files/ops/openmap/upstream-report.md.
--
-- For now this acts on the bot PC only (ns.ShareLaterHere), and there only once its switch is ticked
-- (ns.SHARE_LATER_DEFAULT); every other client only writes the "refused" row.
--
-- What this does: when the game says it stopped QuestLogPushQuest while it restricts addons, the quest open in the
-- quest details is kept, and shared once when the restriction ends: only if still grouped, still on the quest and
-- within SHARE_LATER_SECONDS. One line at the click says so; the game's own "Sharing quest with ..." follows. If the
-- game refuses the late share too (it may want the player's own click: not known on Forever until a save shows it),
-- one line says to click again, and this client never tries a late share again until the game's build changes.
-- Nothing else is sent. A refusal while nothing is restricted is only recorded (there is nothing to wait for).
--
-- The trace rows (area "share"; read from the save, never asked of the player): "refused" a click the game stopped,
-- "sent" one that went through (on the bot PC only), "after fight" the late share. Each row's why says the state at that moment (in
-- combat, restricted, free), whether OpenMap is loaded, and for a refusal the addon the game named.
local _, ns = ...

ns.SHARE_LATER_SECONDS = 120 -- a fight longer than this: the click is forgotten, as if it had never been held
ns.SHARE_LATER_EVERY = 2     -- seconds between looks at whether the restriction has ended
ns.SHARE_LATER_SETTLE = 0.5  -- seconds the game gets to report a refusal of a call, before its row is written

local function g(name) return rawget(_G, name) end
local function call(fn, ...)
  if type(fn) ~= "function" then return nil end
  local ok, a = pcall(fn, ...)
  if ok then return a end
end
-- The secret test comes first, always: an == or ~= on a secret value throws on this client (QuestItem.lua).
local function plain(v) return not ns.isSecret(v) and v ~= nil end
local function yes(v) return plain(v) and v == true end

-- Off until someone ticks the switch (the coordinator's ruling, 15 Nov 2026 06:06 UTC): if the game forbids the
-- late call it may show its own box naming UW_Guild with a Disable button, on the PC the 24 Nov read depends on.
-- The trace rows are written either way. After that read, if the rows show the late call going through (and the
-- game's own "Sharing quest with" line or a party member confirms it), this becomes true. A choice made by hand is
-- saved as true or false and outlives the change.
ns.SHARE_LATER_DEFAULT = false
function ns.ShareLaterOn()
  local db = g("UW_GuildDB")
  local saved = type(db) == "table" and db.shareLater
  if saved == true or saved == false then return saved end
  return ns.SHARE_LATER_DEFAULT
end

-- Where the late share runs at all. For now the bot PC only: nobody has yet seen the game let addon code share a
-- quest outside the player's own click, and where it doesn't the game may show its own "blocked from an action"
-- box naming UW_Guild, with a Disable button. One save from that PC showing "after fight" done, and this widens to
-- every client by returning true (the addon lead's and the integrator's reviews, 15 Nov 2026). Everywhere else a
-- refused click is a trace row and nothing more, and the switch and the guide row are not shown.
function ns.ShareLaterHere() return ns.SyncBotPC ~= nil and ns.SyncBotPC() == true end

-- "in combat", "restricted" (an encounter or another addon restriction, ns.Restricted) or "free".
local function state()
  if InCombatLockdown() then return "in combat" end
  return ns.Restricted() and "restricted" or "free"
end
local function openMap()
  local addons = g("C_AddOns")
  return addons and yes(call(addons.IsAddOnLoaded, "OpenMap")) and ", OpenMap on" or ", OpenMap off"
end

-- The quest the details pane shows, or nil: a Share from a quest row's right-click menu names no quest we can read.
local function shownQuest()
  local frame = g("QuestMapFrame")
  local details = type(frame) == "table" and frame.DetailsFrame
  if type(details) ~= "table" or not yes(call(details.IsShown, details)) then return nil end
  local id = call(g("QuestMapFrame_GetDetailQuestID"))
  if id == nil then id = details.questID end
  if type(id) == "number" and plain(id) and id > 0 then return id end
end

-- The quest's name for a line of ours, or the plain words when the game gives none we can read.
local function titleOf(id, plainWords)
  local quests = g("C_QuestLog")
  local title = quests and call(quests.GetTitleForQuestID, id)
  return type(title) == "string" and plain(title) and title or plainWords
end

-- False only when the game says outright that this quest can't be shared; unknown counts as shareable.
local function unshareable(id)
  local quests = g("C_QuestLog")
  local can = quests and call(quests.IsPushableQuest, id)
  return plain(can) and can == false
end

local pending   -- { id = questID, at = GetTime() }: one held click, the latest
local refusedAt -- GetTime() of the last refusal: a call made at or before it, still settling, didn't go through
local forbiddenAt -- GetTime() of the last refusal that was a "never" (ADDON_ACTION_FORBIDDEN)
local own       -- true while the late share's own call runs
local ownAt     -- GetTime() of that call: a refusal naming us within the settle time is its answer, not a click
local gaveUp    -- the same, kept here only where there is no save to keep it in (UW_GuildDB.shareLaterStop)

-- The game's own build, as the save keeps it: its rules on what addon code may call change only with it.
local function clientBuild()
  local info = g("GetBuildInfo")
  if type(info) ~= "function" then return "?" end
  local ok, _, build = pcall(info)
  return ok and build ~= nil and tostring(build) or "?"
end
-- A late share the game refused is never tried again on this client until the game itself changes (the
-- integrator's review, 15 Nov 2026): one stopped call at most, not one a session.
local function stopped()
  local db = g("UW_GuildDB")
  return gaveUp or (type(db) == "table" and db.shareLaterStop == clientBuild())
end
local function stop()
  local db = g("UW_GuildDB")
  if type(db) == "table" then db.shareLaterStop = clientBuild() else gaveUp = true end
end

function ns.ShareLaterPending() return pending and pending.id or nil end

local share
local function watch(p)
  ns.after(ns.SHARE_LATER_EVERY, function()
    if pending ~= p then return end -- shared, forgotten or replaced by a newer click meanwhile
    share()
    if pending == p then watch(p) end
  end)
end

-- never: true for ADDON_ACTION_FORBIDDEN, a call the game lets no addon code make at any time (blocked is a call
-- it stops only for now). A click it forbids is not held: there is nothing to wait for.
local function refused(addon, fn, never)
  if type(fn) ~= "string" or not plain(fn) or not fn:find("^QuestLogPushQuest") then return end
  refusedAt = GetTime()
  if never then forbiddenAt = refusedAt end
  local ours = type(addon) == "string" and plain(addon) and addon == "UW_Guild"
  -- The late share's own call: its row is written where it was made. The game may say so a frame after the call.
  if own or (ours and ownAt and refusedAt - ownAt <= ns.SHARE_LATER_SETTLE) then return end
  local now = state()
  local id = now ~= "free" and not never and ns.ShareLaterHere() and not stopped() and ns.ShareLaterOn()
    and shownQuest() or nil
  if id and unshareable(id) then id = nil end -- never a line that promises a share the game won't make
  -- The refused call may have been for another quest than the one the details show (a tracker's own Share): when
  -- the game's selected quest can be read and isn't the shown one, nothing is held, and the row says why
  -- (guardrails' review, 15 Nov 2026). Never a share of a quest the player didn't click.
  local other = ""
  if id then
    local quests = g("C_QuestLog")
    local sel = quests and call(quests.GetSelectedQuest)
    if type(sel) == "number" and plain(sel) and sel > 0 and sel ~= id then id, other = nil, ", another quest selected" end
  end
  local by = type(addon) == "string" and plain(addon) and (", by " .. addon) or ""
  ns.trace("share", "refused", false, now .. openMap() .. by .. (never and ", forbidden" or "") .. other .. (id and ", held" or ""))
  if not id then return end
  local again = pending and pending.id == id
  pending = { id = id, at = GetTime() }
  watch(pending)
  if again then return end -- a second click on the same quest: one line, one share
  ns.say(("Sharing %s when this fight ends."):format(titleOf(id, "your quest")))
end

share = function()
  local p = pending
  if not p then return end
  local waited = GetTime() - p.at
  if state() ~= "free" and waited <= ns.SHARE_LATER_SECONDS then return end -- still held: a later look tries again
  pending = nil
  local quests, why = g("C_QuestLog"), nil
  local index = quests and call(quests.GetLogIndexForQuestID, p.id)
  if waited > ns.SHARE_LATER_SECONDS then why = "too late"
  elseif not ns.ShareLaterOn() then why = "switched off"
  elseif stopped() then why = "stopped" -- refused since this click was held: one stopped call at most (red team)
  elseif not IsInGroup() then why = "left the group"
  elseif type(index) ~= "number" or not plain(index) then why = "quest gone"
  elseif unshareable(p.id) then why = "can't be shared"
  elseif type(g("QuestLogPushQuest")) ~= "function" then why = "no share function" end
  if why then return ns.trace("share", "after fight", false, why .. openMap()) end
  local at = GetTime()
  own, ownAt = true, at
  local ok = pcall(g("QuestLogPushQuest"), index)
  own = false
  if not ok then return ns.trace("share", "after fight", false, "the call failed" .. openMap()) end
  -- The game reports a refusal by event, in the call or just after it: a moment later we know.
  ns.after(ns.SHARE_LATER_SETTLE, function()
    local went = not (refusedAt and refusedAt >= at)
    local never = not went and forbiddenAt and forbiddenAt >= at
    ns.trace("share", "after fight", went, (went and "free" or never and "forbidden" or "refused again") .. openMap())
    -- The line at the click said it would be shared: when the game wants the player's own click, say that too.
    -- And it is this client's last late share: a call of ours the game stops is an error in the save, so from
    -- here a refused click is only recorded (the addon lead's and the integrator's reviews, 15 Nov 2026).
    if not went then stop() end
    if not went then ns.say(("%s wasn't shared. Click Share Quest again."):format(titleOf(p.id, "Your quest"))) end
  end)
end
ns.ShareLaterNow = share

-- Every Share Quest click, whoever's button it was: one row a moment later, once the game has had its say.
local function clicked()
  if own then return end
  local at, now = GetTime(), state()
  ns.after(ns.SHARE_LATER_SETTLE, function()
    if refusedAt and refusedAt >= at then return end -- refused: that row is already written
    ns.trace("share", "sent", true, now .. openMap())
  end)
end

local f = CreateFrame("Frame")
ns.listen(f, { "PLAYER_LOGIN", "ADDON_ACTION_BLOCKED", "ADDON_ACTION_FORBIDDEN", "PLAYER_REGEN_ENABLED" })
f:SetScript("OnEvent", ns.guard(function(_, event, addon, fn)
  if event == "ADDON_ACTION_BLOCKED" then return refused(addon, fn) end
  if event == "ADDON_ACTION_FORBIDDEN" then return refused(addon, fn, true) end
  if event == "PLAYER_LOGIN" then
    -- A secure hook: it runs after the game's own function and leaves that function's callers as they were. Its
    -- only product is the "sent" row, and only the bot PC's save is read, so only that PC carries it until its
    -- saves show the hook is harmless on Forever (the addon lead's review, 15 Nov 2026).
    if ns.SyncBotPC and ns.SyncBotPC() and g("hooksecurefunc") and g("QuestLogPushQuest") then
      pcall(g("hooksecurefunc"), "QuestLogPushQuest", ns.guard(clicked))
    end
    return
  end
  if pending then ns.after(0, share) end -- a frame later: combat is fully over by then
end))
