-- Is this piece an upgrade for this character, and by how much? One answer for every place UW_Guild suggests gear
-- (Louis, 22 Nov 2026: "build a better informed one with all addons we've installed considered in an integrating
-- unified data system"): the bag question (AutoEquip.lua), the quest reward line and the tooltip line below.
--
-- Wire before build: Pawn already scores gear, and Pawn Forever (a kit extra) gives it researched Forever weights for
-- every spec, leveling below 60 and endgame at 60. When Pawn is loaded, its own answer is used, for the scale of this
-- character's talents, and UW_Guild adds no tooltip line of its own (Pawn shows one). Without Pawn, the same Pawn
-- Forever weights (GearWeights.lua, bundled with credit) are applied to what the game says about the item: its stats,
-- and the Forever tooltip lines the stat call leaves out (spell damage, healing, mana per 5, crit and hit). Either way
-- the answer is "+N% for you" or "fills an empty slot", never a guess dressed as a fact: a piece it can't read, an
-- on-use trinket or a weapon the class can't wield gets no answer. Auto-equip stays as strict as before (AutoEquip.lua:
-- plainly better only); this only ranks pieces and words the questions.
local _, ns = ...
local say = ns.say

ns.GEAR_CUE_MIN = 5 -- percent: the least a piece must add before the bag question or the quest line names it
ns.GEAR_TIP_MIN = 1 -- percent: the least the tooltip line shows

local function g(name) return rawget(_G, name) end
local function call(fn, ...)
  if type(fn) ~= "function" then return nil end
  local r = { pcall(fn, ...) }
  if r[1] then return unpack(r, 2) end
end
local function plain(v) return v ~= nil and not ns.isSecret(v) and v or nil end

-- Who this is: class, the talent tree with the most points (Gear.lua ns.ReadTalents; none yet: the class's usual
-- leveling tree), level, and the weights for it. Pawn Forever's leveling weights below 60, its endgame ones at 60.
ns.GEAR_DEFAULT_TREE = { WARRIOR = 1, PALADIN = 3, HUNTER = 1, ROGUE = 2, PRIEST = 3, SHAMAN = 2, MAGE = 3,
  WARLOCK = 1, DRUID = 2 }
function ns.GearSpec()
  local _, class = call(g("UnitClass"), "player")
  class = type(class) == "string" and plain(class)
  if not class then return nil end
  local tree, most, tie = nil, 0, false
  local tal = ns.ReadTalents and call(ns.ReadTalents)
  local n = 0
  for part in (type(tal) == "string" and tal or ""):gmatch("[^/]+") do
    n = n + 1
    local p = tonumber(part) or 0
    if p > most then tree, most, tie = n, p, false elseif p == most and p > 0 then tie = true end
  end
  if tie or most == 0 then tree = ns.GEAR_DEFAULT_TREE[class] end
  local level = tonumber(plain(call(g("UnitLevel"), "player"))) or 1
  for _, w in ipairs(ns.GEAR_WEIGHTS or {}) do
    if w.class == class and w.tree == tree then
      return { class = class, classID = w.classID, spec = w.spec, tree = tree, label = w.label, level = level,
        weights = level >= 60 and w.max or w.leveling }
    end
  end
end

-- What the item gives, in Pawn's stat names. The game's stat call first; then the tooltip, for the lines it leaves
-- out. A percent (crit, hit, dodge, parry, block) is read from the tooltip's "by 1%" text: the stat call may give a
-- rating instead, so its number counts only when no tooltip says and it is a plausible percent (5 or less).
local STAT_KEYS = {
  ITEM_MOD_STRENGTH_SHORT = "Strength", ITEM_MOD_AGILITY_SHORT = "Agility", ITEM_MOD_STAMINA_SHORT = "Stamina",
  ITEM_MOD_INTELLECT_SHORT = "Intellect", ITEM_MOD_SPIRIT_SHORT = "Spirit",
  ITEM_MOD_ATTACK_POWER_SHORT = "Ap", ITEM_MOD_MELEE_ATTACK_POWER_SHORT = "Ap",
  ITEM_MOD_RANGED_ATTACK_POWER_SHORT = "Rap", ITEM_MOD_FERAL_ATTACK_POWER_SHORT = "FeralAp",
  ITEM_MOD_CRIT_RATING_SHORT = "CritRating", ITEM_MOD_CRIT_MELEE_RATING_SHORT = "CritRating",
  ITEM_MOD_CRIT_RANGED_RATING_SHORT = "CritRating", ITEM_MOD_CRIT_SPELL_RATING_SHORT = "CritRating",
  ITEM_MOD_HIT_RATING_SHORT = "HitRating", ITEM_MOD_HIT_MELEE_RATING_SHORT = "HitRating",
  ITEM_MOD_HIT_RANGED_RATING_SHORT = "HitRating", ITEM_MOD_HIT_SPELL_RATING_SHORT = "HitRating",
  ITEM_MOD_SPELL_DAMAGE_DONE_SHORT = "SpellDamage", ITEM_MOD_SPELL_HEALING_DONE_SHORT = "Healing",
  ITEM_MOD_MANA_REGENERATION_SHORT = "Mp5", ITEM_MOD_POWER_REGEN0_SHORT = "Mp5",
  ITEM_MOD_HEALTH_REGEN_SHORT = "Hp5", ITEM_MOD_HEALTH_REGENERATION_SHORT = "Hp5",
  ITEM_MOD_DEFENSE_SKILL_RATING_SHORT = "DefenseRating", ITEM_MOD_DODGE_RATING_SHORT = "DodgeRating",
  ITEM_MOD_PARRY_RATING_SHORT = "ParryRating", ITEM_MOD_BLOCK_RATING_SHORT = "BlockRating",
  ITEM_MOD_BLOCK_VALUE_SHORT = "BlockValue", ITEM_MOD_MANA_SHORT = "Mana", ITEM_MOD_HEALTH_SHORT = "Health",
  RESISTANCE0_NAME = "Armor", RESISTANCE2_NAME = "FireResist", RESISTANCE3_NAME = "NatureResist",
  RESISTANCE4_NAME = "FrostResist", RESISTANCE5_NAME = "ShadowResist", RESISTANCE6_NAME = "ArcaneResist",
}
local PERCENT = { CritRating = true, HitRating = true, DodgeRating = true, ParryRating = true, BlockRating = true }
local RANGED = { INVTYPE_RANGED = true, INVTYPE_RANGEDRIGHT = true, INVTYPE_THROWN = true }
-- Tooltip lines, lower case, "Equip: " taken off (Forever prints some as plain green lines). { pattern, stats... }.
local LINES = {
  { "^improves your chance to get a critical strike[%a ]* by (%d+)%%", "CritRating" },
  { "^improves your chance to hit[%a ]* by (%d+)%%", "HitRating" },
  { "^increases damage and healing done by magical spells and effects by up to (%d+)", "SpellDamage", "Healing" },
  { "^increases spell damage and healing by up to (%d+)", "SpellDamage", "Healing" },
  { "^increases healing done by[%a ]* spells and effects by up to (%d+)", "Healing" },
  { "^increases damage done by magical spells and effects by up to (%d+)", "SpellDamage" },
  { "^restores %+?(%d+) mana per 5 sec", "Mp5" },
  { "^restores %+?(%d+) health per 5 sec", "Hp5" },
  { "^%+(%d+) ranged attack power", "Rap" },
  { "^%+(%d+) attack power in cat, bear", "FeralAp" },
  { "^%+(%d+) attack power", "Ap" },
  { "^increased defense %+(%d+)", "DefenseRating" },
  { "^increases your chance to dodge an attack by (%d+)%%", "DodgeRating" },
  { "^increases your chance to parry an attack by (%d+)%%", "ParryRating" },
  { "^increases your chance to block attacks with a shield by (%d+)%%", "BlockRating" },
  { "^increases the block value of your shield by (%d+)", "BlockValue" },
  { "^%+(%d+) block value", "BlockValue" },
  { "^(%d+) armor$", "Armor" }, -- often only in the tooltip on Forever (AutoEquip.lua ns.WithArmor reads it too)
  { "^(%d+) block$", "BlockValue" },
}
local SCHOOLS = { fire = "FireSpellDamage", frost = "FrostSpellDamage", arcane = "ArcaneSpellDamage",
  shadow = "ShadowSpellDamage", nature = "NatureSpellDamage", holy = "HolySpellDamage" }
function ns.GearStats(raw, lines, loc)
  local out, fromTip = {}, {}
  for _, line in ipairs(type(lines) == "table" and lines or {}) do
    if type(line) == "string" and not ns.isSecret(line) then
      local t = line:lower():gsub("^equip: ", "")
      local dps = t:match("%(?([%d%.]+) damage per second")
      if dps and tonumber(dps) then
        fromTip[RANGED[loc or ""] and "RangedDps" or "MeleeDps"] = tonumber(dps)
      end
      local school, n = t:match("^increases damage done by (%a+) spells and effects by up to (%d+)")
      if school and SCHOOLS[school] then fromTip[SCHOOLS[school]] = tonumber(n) end
      for _, p in ipairs(LINES) do
        local v = tonumber(t:match(p[1]))
        if v then
          for i = 2, #p do fromTip[p[i]] = math.max(fromTip[p[i]] or 0, v) end
          break
        end
      end
    end
  end
  for k, v in pairs(type(raw) == "table" and raw or {}) do
    local key = STAT_KEYS[k]
    if k == "ITEM_MOD_SPELL_POWER_SHORT" and type(v) == "number" then
      out.SpellDamage, out.Healing = math.max(out.SpellDamage or 0, v), math.max(out.Healing or 0, v)
    elseif k == "ITEM_MOD_DAMAGE_PER_SECOND_SHORT" and type(v) == "number" then
      out[RANGED[loc or ""] and "RangedDps" or "MeleeDps"] = v
    elseif key and type(v) == "number" and not (PERCENT[key] and v > 5) then
      out[key] = math.max(out[key] or 0, v)
    end
  end
  for k, v in pairs(fromTip) do
    if PERCENT[k] then out[k] = v else out[k] = math.max(out[k] or 0, v) end
  end
  return out
end

function ns.GearValue(st, weights)
  local v = 0
  for k, n in pairs(st or {}) do
    local w = weights and weights[k]
    if type(w) == "number" and type(n) == "number" then v = v + w * n end
  end
  return v
end

-- Plain names for the stats an upgrade adds most, for "more Strength and weapon damage".
ns.GEAR_STAT_WORDS = {
  Strength = "Strength", Agility = "Agility", Stamina = "Stamina", Intellect = "Intellect", Spirit = "Spirit",
  Ap = "attack power", Rap = "ranged attack power", FeralAp = "attack power", CritRating = "crit", HitRating = "hit",
  MeleeDps = "weapon damage", RangedDps = "ranged damage", SpellDamage = "spell damage", Healing = "healing",
  FireSpellDamage = "spell damage", FrostSpellDamage = "spell damage", ArcaneSpellDamage = "spell damage",
  ShadowSpellDamage = "spell damage", NatureSpellDamage = "spell damage", HolySpellDamage = "spell damage",
  Mp5 = "mana regen", Hp5 = "health regen", Armor = "armor", DefenseRating = "defense", DodgeRating = "dodge",
  ParryRating = "parry", BlockRating = "block", BlockValue = "block", Mana = "mana", Health = "health",
  FireResist = "resistance", NatureResist = "resistance", FrostResist = "resistance", ShadowResist = "resistance",
  ArcaneResist = "resistance",
}
local function reasons(new, old, weights)
  local gain, seen = {}, {}
  for k in pairs(new) do seen[k] = true end
  for k in pairs(old or {}) do seen[k] = true end
  for k in pairs(seen) do
    local word = ns.GEAR_STAT_WORDS[k]
    local d = ((new[k] or 0) - ((old or {})[k] or 0)) * ((weights or {})[k] or 0)
    if word and d > 0 then gain[word] = (gain[word] or 0) + d end
  end
  local list = {}
  for word, d in pairs(gain) do list[#list + 1] = { word, d } end
  table.sort(list, function(a, b) return a[2] > b[2] or a[2] == b[2] and a[1] < b[1] end)
  local out = {}
  for i = 1, math.min(2, #list) do out[i] = list[i][1] end
  return out
end
ns.GearReasons = reasons

-- The game's view of an item: info, stats, tooltip lines, and whether any line is red ("you can't use this").
local function info(link)
  local fn = (C_Item and C_Item.GetItemInfo) or g("GetItemInfo")
  local r = { call(fn, link) }
  if r[1] == nil then return nil end
  return { name = r[1], quality = r[3], ilvl = r[4], req = r[5], loc = r[9], classID = r[12], sub = r[13] }
end
local function linesOf(data)
  if type(data) ~= "table" or type(data.lines) ~= "table" then return nil end
  local out, red = {}, false
  for _, l in ipairs(data.lines) do
    local t = l.leftText
    if type(t) == "string" and not ns.isSecret(t) then out[#out + 1] = t end
    for _, c in ipairs({ l.leftColor, l.rightColor }) do
      if type(c) == "table" and (c.r or 0) > 0.9 and (c.g or 1) < 0.2 and (c.b or 1) < 0.2 then red = true end
    end
  end
  return out, red
end
ns.GearLinesOf = linesOf
local function hyperlinkLines(link)
  local tip = g("C_TooltipInfo")
  return linesOf(tip and call(tip.GetHyperlink, link))
end
local function wornLines(slot)
  local tip = g("C_TooltipInfo")
  return linesOf(tip and call(tip.GetInventoryItem, "player", slot))
end
local function readItem(link, lines)
  local it = info(link)
  if not it then return nil end
  local statsFn = (C_Item and C_Item.GetItemStats) or g("GetItemStats")
  it.stats = ns.GearStats(call(statsFn, link), lines, it.loc)
  return it
end

-- Can this class use it at all? The red text first (level, class, armour type, weapon skill); then what red text
-- doesn't say before the skill is trained: armour heavier than the class ever wears, a shield, a weapon type it
-- can't learn (Gear.lua ns.CLASS_WEAPONS).
local WEAPON, ARMOR, SHIELD = 2, 4, 6
local function usable(class, it, red)
  if red then return false end
  if it.classID ~= WEAPON and it.classID ~= ARMOR then return false end
  local heaviest = ns.GEAR_HEAVIEST and ns.GEAR_HEAVIEST[class]
  if it.classID == ARMOR and type(it.sub) == "number" then
    if it.sub >= 1 and it.sub <= 4 and it.loc ~= "INVTYPE_CLOAK" and heaviest and it.sub > heaviest then return false end
    if it.sub == SHIELD and not (ns.GEAR_SHIELDS and ns.GEAR_SHIELDS[class]) then return false end
  end
  if it.classID == WEAPON and type(it.sub) == "number" and ns.CLASS_WEAPONS and ns.CLASS_WEAPONS[class] then
    local ok = false
    for s in ns.CLASS_WEAPONS[class]:gmatch("%d+") do if tonumber(s) == it.sub then ok = true end end
    if not ok then return false end
  end
  return true
end

-- Pawn's answer, when Pawn is loaded: { pct, oldLink, label, pawn = true }; false when Pawn says it isn't one
-- (Pawn.lua PawnIsItemAnUpgrade: a list of { ScaleName, LocalizedScaleName, PercentUpgrade, ExistingItemLink }, one
-- per shown scale it is an upgrade for; no ExistingItemLink: an empty slot). nil when Pawn hasn't read it yet.
local function pawnLoaded()
  return type(g("PawnGetItemData")) == "function" and type(g("PawnIsItemAnUpgrade")) == "function"
end
ns.GearPawnLoaded = pawnLoaded
local function pawnAnswer(link, spec)
  local item = call(g("PawnGetItemData"), link)
  if type(item) ~= "table" then return nil end
  local ups = call(g("PawnIsItemAnUpgrade"), item)
  if type(ups) ~= "table" then return false end
  local common = g("PawnCommon")
  local scales = type(common) == "table" and type(common.Scales) == "table" and common.Scales or {}
  local pick
  for _, u in ipairs(ups) do
    local sc = type(u) == "table" and scales[u.ScaleName]
    if type(sc) == "table" and sc.ClassID == spec.classID and sc.SpecID == spec.spec then pick = u break end
  end
  pick = pick or (type(ups[1]) == "table" and ups[1]) -- no shown scale for these talents: Pawn's first one
  if not pick or type(pick.PercentUpgrade) ~= "number" then return false end
  local old = type(pick.ExistingItemLink) == "string" and pick.ExistingItemLink or nil
  return { pct = math.floor(pick.PercentUpgrade * 100 + 0.5), oldLink = old, empty = old == nil,
    label = type(pick.LocalizedScaleName) == "string" and pick.LocalizedScaleName or nil, pawn = true, reasons = {} }
end

-- The slots a piece can go in (AutoEquip.lua's map; a one-hander also the off hand once the character can dual
-- wield), and what is worn there now.
local function targetsFor(loc)
  local t = ns.GEAR_SLOTS and ns.GEAR_SLOTS[loc]
  if not t then return nil end
  if loc == "INVTYPE_WEAPON" and call(g("CanDualWield")) then return { 16, 17 } end
  return t
end
local function worn(slot)
  local link = call(g("GetInventoryItemLink"), "player", slot)
  return type(link) == "string" and not ns.isSecret(link) and link or nil
end
local function idOf(link) return type(link) == "string" and tonumber(link:match("item:(%d+)")) or nil end

-- Against what's worn in one slot (a two-hander: against both hands). nil: something worn can't be read yet.
local function against(it, s, new, spec)
  local oldLink = worn(s)
  local off = it.loc == "INVTYPE_2HWEAPON" and s == 16 and worn(17)
  if not oldLink and not off then return { empty = true, target = s, gain = math.huge } end
  local oldStats, oldValue = {}, 0
  for _, w in ipairs({ { oldLink, s }, { off, 17 } }) do
    if w[1] then
      local o = readItem(w[1], (wornLines(w[2])))
      if not o then return nil end
      oldValue = oldValue + ns.GearValue(o.stats, spec.weights)
      for k, v in pairs(o.stats) do oldStats[k] = (oldStats[k] or 0) + v end
    end
  end
  if new <= oldValue then return false end
  local pct = oldValue > 0 and math.floor((new - oldValue) / oldValue * 100 + 0.5) or 100
  return { pct = pct, gain = pct, target = s, oldLink = oldLink, reasons = reasons(it.stats, oldStats, spec.weights) }
end

-- The answer for this character: { pct, empty, target, oldLink, reasons, label, pawn }; false when it isn't an
-- upgrade (or can't be used); nil when it can't say (no weights for this class, the item or a worn piece not read
-- yet, a slot it doesn't judge such as trinkets), so a caller can fall back to its own rule.
-- lines, red: the piece's tooltip lines and red flag when the caller has them (a bag slot, a quest reward).
function ns.GearUpgrade(link, lines, red)
  if type(link) ~= "string" or ns.isSecret(link) then return nil end
  local spec = ns.GearSpec()
  if not spec then return nil end
  local it = info(link)
  local targets = it and targetsFor(it.loc)
  if not targets then return nil end
  if (tonumber(it.req) or 0) > spec.level then return false end
  for _, s in ipairs(targets) do if idOf(worn(s)) == idOf(link) then return false end end -- already worn
  if lines == nil then lines, red = hyperlinkLines(link) end
  if not lines then return nil end
  if not usable(spec.class, it, red) then return false end
  if pawnLoaded() then
    local p = pawnAnswer(link, spec)
    if not p then return p end
    for _, s in ipairs(targets) do
      local w = worn(s)
      if (p.oldLink and idOf(w) == idOf(p.oldLink)) or (p.empty and not w) then p.target = s break end
    end
    p.target = p.target or targets[1]
    if p.empty then p.oldLink = nil end
    return p
  end
  it = readItem(link, lines)
  local new = ns.GearValue(it.stats, spec.weights)
  if new <= 0 then return false end
  local best, unsure = nil, false
  for _, s in ipairs(targets) do
    local main = s == 17 and worn(16)
    if not (main and (info(main) or {}).loc == "INVTYPE_2HWEAPON") then -- nothing beside a two-hander
      local r = against(it, s, new, spec)
      if r == nil then unsure = true end
      if r and (not best or r.gain > best.gain) then best = r end
    end
  end
  if best then
    best.label, best.reasons = spec.label, best.reasons or {}
    return best
  end
  if unsure then return nil end
  return false
end

-- How much, in words: "+12%", "a big upgrade" (at double or more, a first green against a grey with only armour on
-- it, a percent says little; Pawn words it so too), "fills an empty slot"; and why: "more Strength and weapon damage".
ns.GEAR_BIG = 100
local function gainWords(u)
  if u.empty then return "fills an empty slot" end
  if (u.pct or 0) >= ns.GEAR_BIG then return "a big upgrade" end
  return ("+%d%%"):format(u.pct or 0)
end
local function whyWords(u)
  return u.reasons and #u.reasons > 0 and ("more " .. table.concat(u.reasons, " and ")) or nil
end
-- "+12% for you, more Strength and weapon damage" / "a big upgrade for you" / "fills an empty slot".
function ns.GearUpgradeText(u)
  if not u then return nil end
  if u.empty then return gainWords(u) end
  local why = whyWords(u)
  return gainWords(u) .. " for you" .. (why and (", " .. why) or "")
end

local function on() return UW_GuildDB and UW_GuildDB.gearAuto ~= false end

-- Quest rewards: when a turn-in offers a choice, one line names the best one for this character (DialogueUI, in
-- the kit, marks the one that sells for most; this says which one to wear). Nothing when none is an upgrade.
local function rewardLines(i)
  local tip = g("C_TooltipInfo")
  return linesOf(tip and call(tip.GetQuestItem, "choice", i))
end
function ns.GearQuestReward()
  if not on() then return end
  local n = tonumber(plain(call(g("GetNumQuestChoices")))) or 0
  if n < 2 then return end
  local best, bestLink
  for i = 1, n do
    local link = call(g("GetQuestItemLink"), "choice", i)
    if type(link) == "string" and not ns.isSecret(link) then
      local lines, red = rewardLines(i)
      local u = ns.GearUpgrade(link, lines, red)
      local rank = u and (u.empty and math.huge or u.pct or 0)
      if u and (u.empty or (u.pct or 0) >= ns.GEAR_CUE_MIN) and (not best or rank > best.rank) then
        best, bestLink = u, link
        best.rank = rank
      end
    end
  end
  if best then
    local why = not best.empty and whyWords(best)
    say(("Best reward for you: %s, %s%s."):format(bestLink, gainWords(best), why and (", " .. why) or ""))
  end
end
local qf = CreateFrame("Frame")
ns.listen(qf, { "QUEST_COMPLETE" })
qf:SetScript("OnEvent", function() ns.protect(ns.GearQuestReward) end)

-- The tooltip line, for members without Pawn (Pawn shows its own): on gear that would be an upgrade, out of combat.
local TIPS = { GameTooltip = true, ItemRefTooltip = true }
-- A tooltip redraws often while it's shown, and the bags are looked through on every change: one answer per item
-- for a few seconds, kept only while the worn gear, level and talents are the same.
local tipCache, cached = {}, 0
ns.GEAR_TIP_SECONDS = 5
local function gearNow()
  local parts = { tostring(call(g("UnitLevel"), "player")), tostring(ns.ReadTalents and call(ns.ReadTalents)) }
  for slot = 1, 18 do parts[#parts + 1] = worn(slot) or "" end
  return table.concat(parts, "|")
end
function ns.GearUpgradeSoon(link, lines, red)
  if type(link) ~= "string" or ns.isSecret(link) then return nil end
  local now, at = call(g("GetTime")) or 0, gearNow()
  local c = tipCache[link]
  if c and c.gear == at and now - c.at < ns.GEAR_TIP_SECONDS then return c.u end
  local u = ns.GearUpgrade(link, lines, red)
  if not c then
    cached = cached + 1
    if cached > 200 then tipCache, cached = {}, 1 end
  end
  tipCache[link] = { at = now, gear = at, u = u }
  return u
end
local tipAnswer = ns.GearUpgradeSoon
function ns.GearTipText(link)
  if not on() or pawnLoaded() or type(link) ~= "string" or ns.isSecret(link) then return nil end
  local u = tipAnswer(link)
  if not u then return nil end
  if u.empty then return "UW: upgrade for you (empty slot)" end
  if (u.pct or 0) < ns.GEAR_TIP_MIN then return nil end
  if u.pct >= ns.GEAR_BIG then return "UW: big upgrade for you" end
  return ("UW: %s upgrade for you"):format(gainWords(u))
end
function ns.GearTip(tooltip)
  if type(tooltip) ~= "table" or type(tooltip.GetItem) ~= "function" or type(tooltip.AddLine) ~= "function" then return end
  local name = type(tooltip.GetName) == "function" and call(tooltip.GetName, tooltip)
  if not TIPS[name] or call(g("InCombatLockdown")) then return end
  local _, link = call(tooltip.GetItem, tooltip)
  local text = ns.GearTipText(link)
  if text then tooltip:AddLine(text, 0.25, 1, 0.25) end
end
do
  local tdp, enum = g("TooltipDataProcessor"), g("Enum")
  local kind = type(enum) == "table" and type(enum.TooltipDataType) == "table" and enum.TooltipDataType.Item
  if type(tdp) == "table" and type(tdp.AddTooltipPostCall) == "function" and kind ~= nil then
    tdp.AddTooltipPostCall(kind, function(tooltip) ns.protect(function() ns.GearTip(tooltip) end) end)
  else
    for name in pairs(TIPS) do
      local tip = g(name)
      if type(tip) == "table" and type(tip.HookScript) == "function" then
        pcall(tip.HookScript, tip, "OnTooltipSetItem", function(self) ns.protect(function() ns.GearTip(self) end) end)
      end
    end
  end
end
