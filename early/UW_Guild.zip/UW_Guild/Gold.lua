-- /uw gold (Louis, 16 Nov 2026: "What else can you do within TOS to automate and inform gold making?"; built for his
-- own characters only, the bot's PC, never for members). Advice only: it reads, prints to this client's chat, and never
-- buys, posts, sells or mails. Every action at the auction house stays his own click, in Auctionator.
--
-- What it says, for the character he is on, with his other characters on one line after:
--   * each gathering profession at its skill: the three mats that skill gathers worth most at today's prices, and
--     the next mat above it when that one is worth more (how far to level before farming pays better);
--   * the market: how far asking prices across his whole scan moved since the first day Auctionator kept, so he knows
--     whether to sell what he gathers soon or hold it.
-- Where the numbers come from: Auctionator's own price history on this client (Auctionator.Database, the realm it
-- keeps; read-only and protected: a missing or changed shape is "no data", never an error). These are asks, not
-- sales, and the lines say so. A mat's price is the median of the lowest asks on the last three days it was seen. Skills come from UW_GuildDB.crafts (Crafts.lua).
--
-- What was left out, from his scan of 16 Nov 00:00 UTC (6,798 items over 11 days), so nothing here repeats his pack:
--   * craft or sell: Auctionator already shows each recipe's cost and profit on the profession window (its
--     crafting info is on in his settings), and none of his alchemy or cooking recipes beat selling the mats by
--     more than a few silver that day;
--   * a post-ready bag: Auctionator's Selling tab lists the bags with its undercut price, one key a post;
--   * a buy-under-vendor list: 207 items were listed under vendor price, worth 12 silver together;
--   * the guild bank's keep-or-sell list: the guild bank thread's (Bank.lua), which calls ns.ItemWorth.
local _, ns = ...
local say = ns.say

local function g(name) return rawget(_G, name) end
local function call(fn, ...)
  if type(fn) ~= "function" then return nil end
  local ok, a, b = pcall(fn, ...)
  if ok then return a, b end
end

-- What a skill gathers, lowest first: { item id, the skill it needs, its English name for a client that has not
-- loaded the item yet }. Herb and ore skills are the game's own (warcraft.wiki.gg, "Herbalism" and "Mining": the
-- node's required skill). Skinning has no node: a beast of level L needs skill 5 x L from level 20 (10 x (L - 10)
-- below), so a leather is listed at the skill of the lowest beasts that drop it. Forever's own herbs (Marefoil,
-- Demonsage, Stranglevine) are left out until their skill is known. Fishing is left out: the fish he can catch sell
-- for a copper or two.
ns.GOLD_GATHER = {
  Herbalism = {
    { 2447, 1, "Peacebloom" }, { 765, 1, "Silverleaf" }, { 2449, 15, "Earthroot" }, { 785, 50, "Mageroyal" },
    { 2450, 70, "Briarthorn" }, { 3820, 85, "Stranglekelp" }, { 2453, 100, "Bruiseweed" },
    { 3355, 115, "Wild Steelbloom" }, { 3369, 120, "Grave Moss" }, { 3356, 125, "Kingsblood" },
    { 3357, 150, "Liferoot" }, { 3818, 160, "Fadeleaf" }, { 3821, 170, "Goldthorn" },
    { 3358, 185, "Khadgar's Whisker" }, { 3819, 195, "Wintersbite" }, { 4625, 205, "Firebloom" },
    { 8831, 210, "Purple Lotus" }, { 8836, 220, "Arthas' Tears" }, { 8838, 230, "Sungrass" },
    { 8839, 235, "Blindweed" }, { 8845, 245, "Ghost Mushroom" }, { 8846, 250, "Gromsblood" },
    { 13464, 260, "Golden Sansam" }, { 13463, 270, "Dreamfoil" }, { 13465, 280, "Mountain Silversage" },
    { 13466, 285, "Plaguebloom" }, { 13467, 290, "Icecap" }, { 13468, 300, "Black Lotus" },
  },
  Mining = {
    { 2770, 1, "Copper Ore" }, { 2835, 1, "Rough Stone" }, { 2771, 65, "Tin Ore" }, { 2836, 65, "Coarse Stone" },
    { 2775, 75, "Silver Ore" }, { 2772, 125, "Iron Ore" }, { 2838, 125, "Heavy Stone" }, { 2776, 155, "Gold Ore" },
    { 3858, 175, "Mithril Ore" }, { 7912, 175, "Solid Stone" }, { 7911, 230, "Truesilver Ore" },
    { 11370, 230, "Dark Iron Ore" }, { 10620, 245, "Thorium Ore" }, { 12365, 245, "Dense Stone" },
  },
  Skinning = {
    { 2934, 1, "Ruined Leather Scraps" }, { 2318, 1, "Light Leather" }, { 783, 1, "Light Hide" },
    { 2319, 100, "Medium Leather" }, { 4232, 100, "Medium Hide" }, { 4234, 150, "Heavy Leather" },
    { 4235, 150, "Heavy Hide" }, { 4304, 200, "Thick Leather" }, { 8169, 200, "Thick Hide" },
    { 8170, 250, "Rugged Leather" }, { 8171, 250, "Rugged Hide" },
  },
}
ns.GOLD_ORDER = { "Herbalism", "Mining", "Skinning" }
ns.GOLD_TOP, ns.GOLD_DAYS, ns.GOLD_TREND_MIN_DAYS = 3, 3, 6

-- Only on the bot's PC: Louis plays all his characters there and members never get it.
function ns.GoldHere() return ns.SyncBotPC ~= nil and ns.SyncBotPC() == true end

-- A price we can act on: a finite, positive copper amount under the bad-row cap Items.lua uses.
local function price(v)
  return type(v) == "number" and not ns.isSecret(v) and v == v and v > 0 and v <= ns.DE_PRICE_MAX and v or nil
end

-- Auctionator's history table for this realm, or nil.
local function history()
  local auc = g("Auctionator")
  local d = type(auc) == "table" and auc.Database
  return type(d) == "table" and type(d.db) == "table" and d.db or nil
end

-- { [day number] = the lowest ask that day } for one item's history row, from Auctionator's l (lowest) and h (the
-- day's highest lowest, which stands alone when the day had one price).
local function dailyLows(row)
  local out, n = {}, 0
  if type(row) ~= "table" or type(row.h) ~= "table" then return out, 0 end
  local l = type(row.l) == "table" and row.l or {}
  for day, high in pairs(row.h) do
    local d, v = tonumber(day), price(l[day]) or price(high)
    if d and v then out[d], n = v, n + 1 end
  end
  return out, n
end

local function median(t)
  if #t == 0 then return nil end
  table.sort(t)
  local m = math.floor((#t + 1) / 2)
  return #t % 2 == 1 and t[m] or math.floor((t[m] + t[m + 1]) / 2)
end

-- An item's price today: the median of its lowest asks on the last GOLD_DAYS days it was seen, or nil.
function ns.GoldPrice(id, db)
  db = db or history()
  if not db then return nil end
  local lows = dailyLows(db[tostring(id)])
  local days = {}
  for d in pairs(lows) do days[#days + 1] = d end
  table.sort(days, function(a, b) return a > b end)
  local last = {}
  for i = 1, math.min(ns.GOLD_DAYS, #days) do last[#last + 1] = lows[days[i]] end
  return median(last)
end

-- The market: the median across items seen on at least GOLD_TREND_MIN_DAYS days of (lowest ask on the newest day
-- seen) / (median of the first three days seen). Returns that ratio, the items counted and the span in days.
function ns.GoldTrend(db)
  db = db or history()
  if not db then return nil end
  local ratios, first, last = {}, nil, nil
  for _, row in pairs(db) do
    local lows, n = dailyLows(row)
    if n >= ns.GOLD_TREND_MIN_DAYS then
      local days = {}
      for d in pairs(lows) do days[#days + 1] = d end
      table.sort(days)
      local base = median({ lows[days[1]], lows[days[2]], lows[days[3]] })
      if base then
        ratios[#ratios + 1] = lows[days[#days]] / base
        first = math.min(first or days[1], days[1])
        last = math.max(last or days[#days], days[#days])
      end
    end
  end
  if #ratios == 0 then return nil end
  table.sort(ratios)
  return ratios[math.floor((#ratios + 1) / 2)], #ratios, last - first
end

local function money(c)
  local currency = g("C_CurrencyInfo")
  local fmt = g("GetCoinTextureString") or (currency and currency.GetCoinTextureString)
  return call(fmt, c) or (c .. "c")
end

local function itemName(id, fallback)
  local items = g("C_Item")
  local name = call(items and items.GetItemInfo or g("GetItemInfo"), id)
  return type(name) == "string" and not ns.isSecret(name) and name or fallback
end

-- One profession at one skill: { top = { {name, copper}, ... up to GOLD_TOP }, next = {name, copper, skill} or nil }.
function ns.GoldFarm(prof, skill, db)
  local list = ns.GOLD_GATHER[prof]
  db = db or history()
  if not list or not db or type(skill) ~= "number" then return nil end
  local have, best = {}, 0
  for _, m in ipairs(list) do
    local p = m[2] <= skill and ns.GoldPrice(m[1], db)
    if p then have[#have + 1] = { itemName(m[1], m[3]), p } end
  end
  table.sort(have, function(a, b) return a[2] > b[2] end)
  local top = {}
  for i = 1, math.min(ns.GOLD_TOP, #have) do top[i] = have[i]; best = math.max(best, have[i][2]) end
  local nxt
  for _, m in ipairs(list) do
    if m[2] > skill then
      local p = ns.GoldPrice(m[1], db)
      if p and p > best then nxt = { itemName(m[1], m[3]), p, m[2] }; break end
    end
  end
  return { top = top, next = nxt }
end

-- This character's gathering skills, from what Crafts.lua keeps: { {prof, rank}, ... } in GOLD_ORDER.
-- Crafts.lua keys them by the short name; ns.me() and UW_GuildDB.alts carry the realm on a regional client.
local function short(name) return ns.shortName and ns.shortName(name) or name end
local function skillsOf(name)
  local all = type(UW_GuildDB) == "table" and type(UW_GuildDB.crafts) == "table" and UW_GuildDB.crafts or {}
  local crafts = all[short(name)] or all[name]
  local profs = type(crafts) == "table" and type(crafts.profs) == "table" and crafts.profs or {}
  local out = {}
  for _, prof in ipairs(ns.GOLD_ORDER) do
    local p = profs[prof]
    local r = type(p) == "table" and tonumber(p.r)
    if r then out[#out + 1] = { prof, r } end
  end
  return out
end

local function farmLine(prof, rank, db)
  local f = ns.GoldFarm(prof, rank, db)
  if not f or #f.top == 0 then return nil end
  local parts = {}
  for _, m in ipairs(f.top) do parts[#parts + 1] = m[1] .. " " .. money(m[2]) end
  local line = ("%s %d: %s, lowest ask each."):format(prof, rank, table.concat(parts, ", "))
  if f.next then line = line .. (" At skill %d: %s, %s."):format(f.next[3], f.next[1], money(f.next[2])) end
  return line, f.top[1][2]
end

function ns.GoldLines()
  local db = history()
  if not db then return { "No Auctionator price history here yet: open the auction house and scan once." } end
  local lines, me = {}, ns.me()
  for _, s in ipairs(me and skillsOf(me) or {}) do
    local line = farmLine(s[1], s[2], db)
    if line then lines[#lines + 1] = line end
  end
  if #lines == 0 then lines[1] = "No gathering profession on this character." end
  -- His other characters: each one's best mat, the same mat on several characters said once, best first (who to
  -- farm on). UW_GuildDB.alts names his own characters only.
  local best = {}
  local alts = type(UW_GuildDB) == "table" and type(UW_GuildDB.alts) == "table" and UW_GuildDB.alts or {}
  for name in pairs(alts) do
    if type(name) == "string" and short(name) ~= short(me or "") then
      for _, s in ipairs(skillsOf(name)) do
        local f = ns.GoldFarm(s[1], s[2], db)
        local top = f and f.top[1]
        local who = short(name)
        if top and (not best[who] or top[2] > best[who][2]) then best[who] = { top[1], top[2] } end
      end
    end
  end
  local groups, byMat = {}, {}
  for name, b in pairs(best) do
    local grp = byMat[b[1]]
    if not grp then grp = { mat = b[1], copper = b[2], names = {} }; byMat[b[1]] = grp; groups[#groups + 1] = grp end
    grp.names[#grp.names + 1] = name
  end
  table.sort(groups, function(a, b) return a.copper > b.copper or a.copper == b.copper and a.mat < b.mat end)
  if #groups > 0 then
    local parts = {}
    for i = 1, math.min(3, #groups) do
      local grp = groups[i]
      table.sort(grp.names)
      parts[#parts + 1] = ("%s %s (%s)"):format(grp.mat, money(grp.copper), table.concat(grp.names, ", "))
    end
    lines[#lines + 1] = "Best on your other characters: " .. table.concat(parts, "; ") .. "."
  end
  local okAlt, alt = pcall(ns.GoldAltLines, nil, db) -- another addon's save: a changed shape costs only these lines
  for _, line in ipairs(okAlt and alt or {}) do lines[#lines + 1] = line end
  local ratio, _, span = ns.GoldTrend(db)
  if ratio and span and span > 0 then
    local pct = math.floor(math.abs(ratio - 1) * 100 + 0.5)
    if ratio <= 0.95 then
      lines[#lines + 1] = ("Asking prices across your scan are down %d%% over %d days: sell what you gather soon."):format(pct, span)
    elseif ratio >= 1.05 then
      lines[#lines + 1] = ("Asking prices across your scan are up %d%% over %d days."):format(pct, span)
    else
      lines[#lines + 1] = ("Asking prices across your scan held steady over %d days."):format(span)
    end
  end
  return lines
end

-- His other characters, from DataStore (in his pack; Louis, 22 Nov 2026: wire the pack's gold data; coordinator
-- cleared the three lines 12:15). Read only, every field checked (ops/reads/gold-data-shapes-2026-11-22.md):
--   DataStore_CharacterIDs.List[i] = "Account.Realm.Name"; i is the charId of every table below.
--   DataStore_Containers_Characters[i] = { lastUpdate, Containers = { [bag] = { items, links } } },
--   DataStore_Containers_Banks[i] = { items, links }: items[slot] = count + itemID * 65536 (older saves: * 1024),
--   checked against links[slot]'s item id, so a slot whose two disagree is skipped.
--   DataStore_Mails_Characters[i] = { lastUpdate, Mails = { { itemID, count, daysLeft, lastCheck } } }: only those
--   four fields are read, never sender, subject or text (other players' words).
--   DataStore_Characters_Info[i] = { money, lastUpdate }.
-- A character found under two realm strings (the realm name changed on 19-20 Nov) counts once: its newest entry.
ns.GOLD_ALT_MIN, ns.GOLD_ALT_TOP, ns.GOLD_MAIL_DAYS, ns.GOLD_STALE = 10000, 5, 3, 3 * 86400
local function linkId(link) return type(link) == "string" and tonumber(link:match("item:(%d+)")) end
local function unpackSlot(v, link)
  if type(v) ~= "number" or v <= 0 then return nil end
  local want = linkId(link)
  for _, base in ipairs({ 65536, 1024 }) do
    local id, n = math.floor(v / base), v % base
    if n > 0 and (id == want or not want and base == 65536) then return id, n end
  end
end
-- { [charId] = short name } for his other characters, newest entry per name, and each name's newest stamp.
local function dsChars(tbl, me)
  local ids = g("DataStore_CharacterIDs")
  local list = type(ids) == "table" and type(ids.List) == "table" and ids.List
  if not list or type(tbl) ~= "table" then return {} end
  local pick = {}
  for i, key in ipairs(list) do
    local e, name = tbl[i], type(key) == "string" and key:match("([^%.]+)$")
    local at = type(e) == "table" and type(e.lastUpdate) == "number" and e.lastUpdate
    if name and at and name ~= me and (not pick[name] or at > pick[name].at) then pick[name] = { i = i, at = at } end
  end
  local out = {}
  for name, p in pairs(pick) do out[p.i] = { name = name, at = p.at } end
  return out
end
local function dsDate(at, now)
  local d = call(g("date"), "!%d %b", at)
  d = type(d) == "string" and d:gsub("^0", "") or "?"
  return now - at > ns.GOLD_STALE and ("DataStore, %s, over 3 days old."):format(d) or ("DataStore, %s."):format(d)
end
local function sellable(id)
  local items = g("C_Item")
  local ok, _, _, _, _, _, _, _, _, _, _, _, _, _, bind = pcall(items and items.GetItemInfo or g("GetItemInfo"), id)
  return not ok or (bind ~= 1 and bind ~= 4) -- not bound on pickup, not a quest item
end
function ns.GoldAltLines(now, db)
  now = now or call(g("time")) or 0
  local me = short(ns.me() or "")
  local lines, newest = {}, 0
  -- 1. Worth listing: stacks on his other characters, priced as the brief prices them.
  local chars = dsChars(g("DataStore_Containers_Characters"), me)
  local banks, stacks, byKey = g("DataStore_Containers_Banks"), {}, {}
  local function add(c, where, items, links)
    if type(items) ~= "table" then return end
    for slot, v in pairs(items) do
      local id, n = unpackSlot(v, type(links) == "table" and links[slot])
      local each = id and (ns.GoldPrice(id, db) or ns.GoldFwcsAsk(id))
      if each and each >= ns.GOLD_ALT_MIN and sellable(id) then
        local key = c.name .. where .. id
        local st = byKey[key]
        if not st then
          st = { id = id, n = 0, each = each, who = c.name, where = where }
          byKey[key] = st; stacks[#stacks + 1] = st
        end
        st.n = st.n + n
        if c.at > newest then newest = c.at end
      end
    end
  end
  for i, c in pairs(chars) do
    local e = g("DataStore_Containers_Characters")[i]
    if type(e.Containers) == "table" then
      for _, bag in pairs(e.Containers) do
        if type(bag) == "table" then add(c, "bags", bag.items, bag.links) end
      end
    end
    local bank = type(banks) == "table" and banks[i]
    if type(bank) == "table" then add(c, "bank", bank.items, bank.links) end
  end
  table.sort(stacks, function(a, b) return a.each * a.n > b.each * b.n or a.each * a.n == b.each * b.n and a.id < b.id end)
  if #stacks > 0 then
    local tag, parts = dsDate(newest, now), {}
    for i = 1, math.min(ns.GOLD_ALT_TOP, #stacks) do
      local st = stacks[i]
      local part = ("%s%s %s each (%s, %s)"):format(itemName(st.id, "item " .. st.id), st.n > 1 and (" x" .. st.n) or "",
        money(st.each), st.who, st.where)
      local line = "Worth listing from your other characters: " .. table.concat(parts, ", ")
        .. (#parts > 0 and ", " or "") .. part .. ". " .. tag
      if #line > 255 then break end
      parts[#parts + 1] = part
    end
    if #parts > 0 then
      lines[#lines + 1] = "Worth listing from your other characters: " .. table.concat(parts, ", ") .. ". " .. tag
    end
  end
  -- 2. Mail running out: items only, three days or fewer left now.
  local mails, soon = g("DataStore_Mails_Characters"), {}
  for i, c in pairs(dsChars(mails, me)) do
    for _, m in ipairs(type(mails[i].Mails) == "table" and mails[i].Mails or {}) do
      if type(m) == "table" and type(m.itemID) == "number" and type(m.daysLeft) == "number" then
        local left = m.daysLeft - (now - (type(m.lastCheck) == "number" and m.lastCheck or c.at)) / 86400
        if left > 0 and left <= ns.GOLD_MAIL_DAYS then
          soon[#soon + 1] = { id = m.itemID, n = type(m.count) == "number" and m.count or 1, who = c.name,
            days = math.max(1, math.floor(left)) }
        end
      end
    end
  end
  table.sort(soon, function(a, b) return a.days < b.days or a.days == b.days and a.id < b.id end)
  if #soon > 0 then
    local parts = {}
    for _, m in ipairs(soon) do
      local part = ("%s%s (%s, %d day%s)"):format(itemName(m.id, "item " .. m.id), m.n > 1 and (" x" .. m.n) or "",
        m.who, m.days, m.days == 1 and "" or "s")
      if #("Expiring in the mail: " .. table.concat(parts, ", ") .. ", " .. part .. ".") > 255 then break end
      parts[#parts + 1] = part
    end
    if #parts > 0 then lines[#lines + 1] = "Expiring in the mail: " .. table.concat(parts, ", ") .. "." end
  end
  -- 3. Gold across his characters: this one's live, the others' as DataStore last saw them.
  local info, total, at = g("DataStore_Characters_Info"), 0, 0
  for i, c in pairs(dsChars(info, me)) do
    local m = info[i].money
    if type(m) == "number" and m >= 0 then total, at = total + m, math.max(at, c.at) end
  end
  if at > 0 then
    local here = call(g("GetMoney"))
    total = total + (type(here) == "number" and here or 0)
    lines[#lines + 1] = ("Gold across your characters: %s (%s)"):format(money(total), dsDate(at, now):sub(1, -2)) .. "."
  end
  return lines
end

-- Four lines by default (Louis's live screen, 22 Nov 2026: the whole answer took 19 rows of his chat at 4K; coordinator
-- 14:19: the four most useful, the rest behind /uw gold all). Most gold first: what his other characters can list,
-- mail about to run out, this character's best gathering, the market's direction, then the rest.
local RANK = { { "^Worth listing", 1 }, { "^Expiring in the mail", 2 }, { "^Asking prices", 4 }, { "^Gold across", 5 },
  { "^Best on your other", 7 } }
ns.GOLD_SHORT = 4
function ns.GoldShort(lines)
  local ranked, farms = {}, 0
  for i, line in ipairs(lines) do
    local r
    for _, k in ipairs(RANK) do if line:find(k[1]) then r = k[2] end end
    if not r then farms = farms + 1; r = farms == 1 and 3 or 6 end -- this character's first skill, then the others
    ranked[#ranked + 1] = { r = r, i = i, line = line }
  end
  table.sort(ranked, function(a, b) return a.r < b.r or a.r == b.r and a.i < b.i end)
  local out = {}
  for i = 1, math.min(ns.GOLD_SHORT, #ranked) do out[i] = ranked[i].line end
  local more = #ranked - #out
  if more > 0 then
    local tail = (" /uw gold all: %d more."):format(more)
    if #out[#out] + #tail <= 255 then out[#out] = out[#out] .. tail end
  end
  return out
end

-- The disenchant shopping list (Louis, 22 Nov 2026 22:32: "an optimal shopping list for auctionator" of "everything
-- that's worth my time to disenchant"; coordinator cleared the lines 22:37). /uw gold de walks his newest Auctionator
-- scan for green and blue weapons and armour and keeps a piece when its newest ask leaves both GOLD_DE_MARGIN and
-- GOLD_DE_GAIN under what its mats ask: ns.DisenchantWorth (Items.lua: Auctionator's own number, else our estimate
-- from public pre-4.0 rates and his own mat asks; both after the 5% cut), less the deposit to relist those mats at the dearest rate. It writes one Auctionator shopping
-- list, "UW Disenchant", through Auctionator's own API, each entry at the most that still clears the margin; no
-- list of his is touched (his save of 22 Nov held none). Buying stays his click in Auctionator's Shopping tab. Not in
-- his pack already: no TSM; Auctionator has no disenchant search; Crafter's Journal's Make Money prices crafts, not
-- disenchants. Its own margin, not DE_ESTIMATE_MARGIN (that one is "beats the vendor"). Forever lets any Enchanting
-- skill disenchant anything (Items.lua's source), so skill is no gate.
ns.GOLD_DE_LIST, ns.GOLD_DE_MARGIN, ns.GOLD_DE_GAIN, ns.GOLD_DE_MAX = "UW Disenchant", 0.2, 1000, 60
ns.GOLD_DE_DEPOSIT, ns.GOLD_DE_LOADS = 0.2, 200
-- Auctionator's keys on Forever (hardening's read of his 22 Nov save): "id", or "gr:id:suffix" for a piece with a
-- random enchant ("of the Monkey"), one key per suffix. The second is true for those.
local function deKey(key)
  if type(key) == "number" then return key, false end
  if type(key) ~= "string" then return nil end
  local plain = key:match("^(%d+)$")
  if plain then return tonumber(plain), false end
  local id = key:match("^gr?:(%d+):")
  return tonumber(id), id ~= nil
end
local function deDeposit(it) -- relisting the expected mats: their vendor price at the dearest deposit rate
  local sum = 0
  for _, m in ipairs(ns.DisenchantMats(it) or {}) do
    local mi = ns.ItemInfo(m[1])
    sum = sum + m[2] * m[3] * (mi and price(mi.price) or 0)
  end
  return math.ceil(sum * ns.GOLD_DE_DEPOSIT)
end
-- { picks = { { id, name, ask, max, mats }, ... best gain first }, loading = n } from the newest scan day, or nil.
function ns.GoldDisenchantPicks(db)
  db = db or history()
  local items = g("C_Item") or {}
  local instant = items.GetItemInfoInstant or g("GetItemInfoInstant")
  if not db or type(instant) ~= "function" then return nil end
  local newest, rows = nil, {}
  for key, row in pairs(db) do
    local id, suffixed = deKey(key)
    if id then
      local lows = dailyLows(row)
      local day
      for d in pairs(lows) do if not day or d > day then day = d end end
      if day then
        rows[#rows + 1] = { id = id, day = day, ask = lows[day], suffixed = suffixed }
        if not newest or day > newest then newest = day end
      end
    end
  end
  -- Per item, from the newest scan day only: the lowest ask across its suffixes, and whether any were suffixed (those
  -- are searched by the base name, not exactly, so every suffix shows; the max price still holds each one).
  local byId, order = {}, {}
  for _, r in ipairs(rows) do
    if r.day == newest then
      local e = byId[r.id]
      if not e then e = { id = r.id, ask = r.ask, suffixed = r.suffixed }; byId[r.id] = e; order[#order + 1] = e
      else e.ask, e.suffixed = math.min(e.ask, r.ask), e.suffixed or r.suffixed end
    end
  end
  local picks, loading = {}, 0
  for _, r in ipairs(order) do
    local ok, _, _, _, _, _, classID = pcall(instant, r.id)
    if ok and (classID == ns.ITEM_WEAPON or classID == ns.ITEM_ARMOR) then
      local it = ns.ItemInfo(r.id)
      if not it then
        loading = loading + 1
        if loading <= ns.GOLD_DE_LOADS then call(items.RequestLoadItemDataByID, r.id) end
      elseif it.bindType ~= 1 and ns.DisenchantMats(it) then -- green or blue gear only, whoever prices it
        local mats = ns.DisenchantWorth and ns.DisenchantWorth("item:" .. r.id) -- Auctionator's own, else our estimate
        local net = mats and mats - deDeposit(it)
        local max = net and math.floor(math.min(net / (1 + ns.GOLD_DE_MARGIN), net - ns.GOLD_DE_GAIN))
        if max and max >= 1 and r.ask <= max then
          picks[#picks + 1] = { id = r.id, name = it.name, ask = r.ask, max = max, mats = mats, gain = net - r.ask,
            exact = not r.suffixed }
        end
      end
    end
  end
  table.sort(picks, function(a, b) return a.gain > b.gain or a.gain == b.gain and a.id < b.id end)
  for i = #picks, ns.GOLD_DE_MAX + 1, -1 do picks[i] = nil end
  return { picks = picks, loading = loading }
end
local function scanDay()
  local sv = g("AUCTIONATOR_SAVEDVARS")
  local at = type(sv) == "table" and tonumber(sv.TimeOfLastBrowseScan)
  local d = at and call(g("date"), "%d %b", at)
  return type(d) == "string" and (d:gsub("^0", "")) or "your last"
end
function ns.GoldDisenchantList()
  local auc = g("Auctionator")
  local api = type(auc) == "table" and type(auc.API) == "table" and auc.API.v1
  local make, conv = api and api.CreateShoppingList, api and api.ConvertToSearchString
  if type(make) ~= "function" or type(conv) ~= "function" then
    return { "Disenchant list: this Auctionator can't make shopping lists, so the list wasn't made." }
  end
  local res = ns.GoldDisenchantPicks()
  if not res then return { "No Auctionator price history here yet: open the auction house and scan once." } end
  local day = scanDay()
  local tail = res.loading > 0 and (" %d items were still loading; run it again in a minute for those."):format(res.loading) or ""
  if #res.picks == 0 then
    return { ("Disenchant list: nothing in your %s scan leaves enough after its mats to be worth buying. /uw gold de again after your next scan."):format(day) .. tail }
  end
  local terms = {}
  for _, p in ipairs(res.picks) do
    -- maxPrice in copper: Auctionator turns it into gold for the string itself (hardening's read of 351, 22 Nov).
    local s = call(conv, "UW_Guild", { searchString = p.name, isExact = p.exact, maxPrice = p.max })
    if type(s) == "string" then terms[#terms + 1] = s end
  end
  if #terms == 0 then return { "Disenchant list: this Auctionator can't make shopping lists, so the list wasn't made." } end
  local ok = pcall(make, "UW_Guild", ns.GOLD_DE_LIST, terms)
  if not ok then return { "Disenchant list: this Auctionator can't make shopping lists, so the list wasn't made." } end
  local best = res.picks[1]
  local line = ("Disenchant list: %d items worth more as mats, after the 5%% cut and deposit. Best: %s up to %s (mats ~%s). Scan: %s."):format(
    #terms, best.name, money(best.max), money(best.mats), day) .. tail
  if #line > 255 then -- coin icons are ~40 bytes each: the mats' price goes first, then the loading note
    line = ("Disenchant list: %d items worth more as mats, after the 5%% cut and deposit. Best: %s up to %s. Scan: %s."):format(
      #terms, best.name, money(best.max), day)
    if #line + #tail <= 255 then line = line .. tail end
  end
  return {
    line,
    "Auctionator > Shopping > UW Disenchant > Search. Buy on your enchanter to skip mailing. Rerun /uw gold de after each scan.",
  }
end

ns.commands.gold = function(arg)
  if not ns.GoldHere() then return ns.HelpList() end
  if call(g("InCombatLockdown")) then return say("After the fight: /uw gold reads the whole price history.") end
  if type(arg) == "string" and arg:lower():match("^%s*de%s*$") then
    for _, line in ipairs(ns.GoldDisenchantList()) do say(line) end
    return
  end
  if type(arg) == "string" and arg:lower():match("^%s*craft%f[%s%z]") then
    local who = arg:match("^%s*[Cc][Rr][Aa][Ff][Tt]%s+(.-)%s*$")
    for _, line in ipairs(ns.GoldAltCraftLines(who)) do say(line) end
    return
  end
  local lines = ns.GoldLines()
  if not (type(arg) == "string" and arg:lower():match("^%s*all%s*$")) then lines = ns.GoldShort(lines) end
  for _, line in ipairs(lines) do say(line) end
end

-- Alt craft orchestrator (Louis, 25 Nov 2026: "if I'm crafting on one character that can make something helpful or
-- useful for another, I want to know that, so I can send it, and/or compare it to AH options of comparable value,
-- quality, etc."; bot PC only via ns.GoldHere()). Wire before build: reads DataStore_Inventory_Characters,
-- DataStore_Characters_Info, DataStore_Containers_Characters/Banks, DataStore_Mails_Characters, UW_GuildDB.crafts /
-- recipeInfo, and Auctionator/FWCS/vendor prices — read only, zero whispers, advice only.
ns.GOLD_ALT_CRAFT_MIN_GAIN = 3  -- minimum item-level gain over an equipped piece (empty slot always qualifies)
ns.GOLD_ALT_CRAFT_AHEAD = 2     -- show crafts usable now or within 2 levels ("at lv N")
ns.GOLD_ALT_CRAFT_MAX = 6       -- max recommendation lines per /uw gold craft
ns.GOLD_ALT_CRAFT_PER_ALT = 2   -- cap per alt when listing across all alts
local vendorCache
do
  local CLASS_BY_ID = { [1] = "WARRIOR", [2] = "PALADIN", [3] = "HUNTER", [4] = "ROGUE", [5] = "PRIEST",
    [7] = "SHAMAN", [8] = "MAGE", [9] = "WARLOCK", [11] = "DRUID" }
  local SLOTS = {
    INVTYPE_HEAD = { { 1 }, "Head" }, INVTYPE_NECK = { { 2 }, "Neck" }, INVTYPE_SHOULDER = { { 3 }, "Shoulder" },
    INVTYPE_CHEST = { { 5 }, "Chest" }, INVTYPE_ROBE = { { 5 }, "Chest" }, INVTYPE_WAIST = { { 6 }, "Waist" },
    INVTYPE_LEGS = { { 7 }, "Legs" }, INVTYPE_FEET = { { 8 }, "Feet" }, INVTYPE_WRIST = { { 9 }, "Wrist" },
    INVTYPE_HAND = { { 10 }, "Hands" }, INVTYPE_FINGER = { { 11, 12 }, "Ring" },
    INVTYPE_TRINKET = { { 13, 14 }, "Trinket" }, INVTYPE_CLOAK = { { 15 }, "Back" },
    INVTYPE_WEAPON = { { 16 }, "Weapon" }, INVTYPE_WEAPONMAINHAND = { { 16 }, "Weapon" },
    INVTYPE_2HWEAPON = { { 16 }, "2H" }, INVTYPE_SHIELD = { { 17 }, "Shield" },
    INVTYPE_HOLDABLE = { { 17 }, "Off-Hand" }, INVTYPE_WEAPONOFFHAND = { { 17 }, "Off-Hand" },
    INVTYPE_RANGED = { { 18 }, "Ranged" }, INVTYPE_RANGEDRIGHT = { { 18 }, "Ranged" },
    INVTYPE_THROWN = { { 18 }, "Ranged" },
  }
  local function itemMeta(id)
    local items = g("C_Item")
    local fn = items and items.GetItemInfo or g("GetItemInfo")
    if type(fn) ~= "function" then return nil end
    local ok, name, _, qual, ilvl, reqLvl, _, _, _, loc, _, _, clsID, subID, bind = pcall(fn, id)
    if not ok or type(name) ~= "string" or ns.isSecret(name) then return nil end
    return { id = id, name = name, qual = tonumber(qual) or 0, ilvl = tonumber(ilvl) or 0,
      reqLvl = tonumber(reqLvl) or 0, loc = loc, cls = tonumber(clsID), sub = tonumber(subID),
      bind = tonumber(bind) or 0 }
  end
  local function classWeapons(cls)
    local raw = ns.CLASS_WEAPONS and ns.CLASS_WEAPONS[cls]
    if type(raw) ~= "string" then return nil end
    local set = {}
    for n in raw:gmatch("%d+") do set[tonumber(n)] = true end
    return set
  end
  local function maxArmor(cls, lvl)
    local h = ns.GEAR_HEAVIEST and ns.GEAR_HEAVIEST[cls]
    if not h then return nil end
    if lvl < 40 and (cls == "WARRIOR" or cls == "PALADIN") then return math.min(h, 3) end
    if lvl < 40 and (cls == "HUNTER" or cls == "SHAMAN") then return math.min(h, 2) end
    return h
  end
  local function usableByAlt(alt, clsID, subID, loc, reqLvl)
    if not (alt.level and alt.cls and loc and SLOTS[loc]) then return false end
    if (reqLvl or 0) > alt.level + ns.GOLD_ALT_CRAFT_AHEAD then return false end
    if clsID == 4 then
      if subID == 6 then return ns.GEAR_SHIELDS and ns.GEAR_SHIELDS[alt.cls] == true end
      if loc == "INVTYPE_CLOAK" or loc == "INVTYPE_NECK" or loc == "INVTYPE_FINGER" or loc == "INVTYPE_TRINKET"
        or loc == "INVTYPE_HOLDABLE" then return true end
      local cap = maxArmor(alt.cls, alt.level)
      return type(subID) == "number" and subID >= 1 and subID <= 4 and cap ~= nil and subID <= cap
    elseif clsID == 2 then
      local w = classWeapons(alt.cls)
      return type(subID) == "number" and w ~= nil and w[subID] == true
    end
    return false
  end
  local function dsAlts(me, filter)
    local invTbl = g("DataStore_Inventory_Characters")
    local chars = dsChars(invTbl, me)
    local infoTbl = g("DataStore_Characters_Info")
    local bagsTbl = g("DataStore_Containers_Characters")
    local banksTbl = g("DataStore_Containers_Banks")
    local mailsTbl = g("DataStore_Mails_Characters")
    local members = type(UW_GuildDB) == "table" and type(UW_GuildDB.members) == "table" and UW_GuildDB.members or {}
    local want = type(filter) == "string" and filter ~= "" and filter:lower() or nil
    local out, newest = {}, 0
    for i, c in pairs(chars) do
      local lname = c.name:lower()
      if not want or lname == want or lname:sub(1, #want) == want then
        local info = type(infoTbl) == "table" and infoTbl[i]
        local base = type(info) == "table" and type(info.BaseInfo) == "number" and info.BaseInfo or nil
        local lvl = base and (base % 128) or nil
        local cls = base and CLASS_BY_ID[math.floor(base / 128) % 16] or nil
        local mem = members[c.name]
        if (not lvl or lvl == 0) and type(mem) == "table" and type(mem.lvl) == "number" then lvl = mem.lvl end
        if not cls and type(mem) == "table" and type(mem.cls) == "string" then cls = mem.cls end
        if lvl and lvl > 0 and cls then
          local inv = type(invTbl[i]) == "table" and type(invTbl[i].Inventory) == "table" and invTbl[i].Inventory or {}
          local worn, owned = {}, {}
          for s = 1, 18 do
            local raw = inv[s]
            local id = type(raw) == "number" and raw or linkId(raw)
            if id then
              owned[id] = true
              local m = itemMeta(id)
              worn[s] = m and m.ilvl or 0
            end
          end
          local bc = type(bagsTbl) == "table" and type(bagsTbl[i]) == "table" and bagsTbl[i].Containers
          if type(bc) == "table" then
            for _, bag in pairs(bc) do
              if type(bag) == "table" and type(bag.items) == "table" then
                for slot, v in pairs(bag.items) do
                  local id = unpackSlot(v, type(bag.links) == "table" and bag.links[slot])
                  if id then owned[id] = true end
                end
              end
            end
          end
          local bank = type(banksTbl) == "table" and banksTbl[i]
          if type(bank) == "table" and type(bank.items) == "table" then
            for slot, v in pairs(bank.items) do
              local id = unpackSlot(v, type(bank.links) == "table" and bank.links[slot])
              if id then owned[id] = true end
            end
          end
          local mc = type(mailsTbl) == "table" and type(mailsTbl[i]) == "table" and mailsTbl[i].Mails
          if type(mc) == "table" then
            for _, m in ipairs(mc) do
              if type(m) == "table" and type(m.itemID) == "number" then owned[m.itemID] = true end
            end
          end
          if c.at > newest then newest = c.at end
          out[#out + 1] = { name = c.name, level = lvl, cls = cls, worn = worn, owned = owned, at = c.at }
        end
      end
    end
    table.sort(out, function(a, b) return a.name < b.name end)
    return out, newest
  end
  local function ahGearIndex(db)
    local byLoc = {}
    if type(db) ~= "table" then return byLoc end
    for key in pairs(db) do
      local id = type(key) == "string" and key:match("^%d+$") and tonumber(key) or type(key) == "number" and key
      if id then
        local ask = ns.GoldPrice(id, db)
        if ask then
          local m = itemMeta(id)
          if m and (m.cls == 2 or m.cls == 4) and m.loc and SLOTS[m.loc] and m.bind ~= 1 and m.bind ~= 4 and m.ilvl > 0 then
            local bucket = byLoc[m.loc]
            if not bucket then bucket = {}; byLoc[m.loc] = bucket end
            bucket[#bucket + 1] = { id = m.id, name = m.name, ilvl = m.ilvl, reqLvl = m.reqLvl,
              cls = m.cls, sub = m.sub, loc = m.loc, ask = ask }
          end
        end
      end
    end
    return byLoc
  end
  local function bestAhAlt(byLoc, alt, crafted)
    local best
    for _, cand in ipairs(byLoc[crafted.loc] or {}) do
      if cand.id ~= crafted.id and cand.ilvl >= crafted.ilvl - 2
        and usableByAlt(alt, cand.cls, cand.sub, cand.loc, cand.reqLvl) then
        if not best or cand.ask < best.ask or (cand.ask == best.ask and cand.ilvl > best.ilvl) then
          best = cand
        end
      end
    end
    return best
  end
  local function wornBaseline(alt, loc)
    local spec = SLOTS[loc]
    if not spec then return nil end
    local lowest
    for _, s in ipairs(spec[1]) do
      local il = alt.worn[s]
      if not il then return 0 end -- empty slot!
      if not lowest or il < lowest then lowest = il end
    end
    return lowest or 0
  end
  function ns.GoldAltCraft(altFilter, db)
    db = db or history()
    local me = short(ns.me() or "")
    local alts, newest = dsAlts(me, altFilter)
    local crafts = type(UW_GuildDB) == "table" and type(UW_GuildDB.crafts) == "table" and UW_GuildDB.crafts[me]
    local profs = type(crafts) == "table" and type(crafts.profs) == "table" and crafts.profs or nil
    local rinfo = type(UW_GuildDB) == "table" and type(UW_GuildDB.recipeInfo) == "table" and UW_GuildDB.recipeInfo or {}
    if #alts == 0 or not profs then return { picks = {}, alts = #alts, newest = newest, hasRecipes = profs ~= nil } end
    local vendor, seen = vendorCache(), {}
    local function ask(id)
      if seen[id] == nil then seen[id] = ns.GoldPrice(id, db) or ns.GoldFwcsAsk(id) or false end
      return seen[id] or nil
    end
    local function matCost(reag)
      if type(reag) ~= "string" or reag == "" then return nil end
      local total, any = 0, false
      for rid, count in reag:gmatch("(%d+):(%d+)") do
        local a, v = ask(tonumber(rid)), vendor[tonumber(rid)]
        local p = (a and v) and math.min(a, v) or a or v
        if not p then return nil end
        total, any = total + p * tonumber(count), true
      end
      return any and math.max(1, math.floor(total + 0.5)) or nil
    end
    local byLoc = ahGearIndex(db)
    local picks = {}
    for prof, pdata in pairs(profs) do
      for key, rname in pairs(type(pdata) == "table" and type(pdata.rec) == "table" and pdata.rec or {}) do
        local id = type(key) == "string" and tonumber(key:match("^i(%d+)$"))
        local ri = id and type(rinfo[key]) == "table" and rinfo[key]
        if ri and (ri.cls == 2 or ri.cls == 4) and ri.slot and SLOTS[ri.slot] and type(ri.ilvl) == "number" and ri.ilvl > 0 then
          local meta = itemMeta(id)
          if not meta or (meta.bind ~= 1 and meta.bind ~= 4) then
            local crafted = { id = id, name = (meta and meta.name) or rname or ("item " .. id), prof = prof,
              loc = ri.slot, cls = ri.cls, sub = ri.sub, ilvl = ri.ilvl, reqLvl = tonumber(ri.lvl) or 0 }
            local mats, buy = matCost(ri.reag), ask(id)
            for _, alt in ipairs(alts) do
              if not alt.owned[id] and usableByAlt(alt, crafted.cls, crafted.sub, crafted.loc, crafted.reqLvl) then
                local wornIlvl = wornBaseline(alt, crafted.loc)
                local gain = crafted.ilvl - wornIlvl
                if wornIlvl == 0 or gain >= ns.GOLD_ALT_CRAFT_MIN_GAIN then
                  local ahAlt = bestAhAlt(byLoc, alt, crafted)
                  local verdict = "CRAFT"
                  if buy and (not mats or buy < mats) and (not ahAlt or buy <= ahAlt.ask) then
                    verdict = "BUY"
                  elseif ahAlt and ahAlt.ilvl >= crafted.ilvl
                    and ((mats and ahAlt.ask < mats) or (not mats and buy and ahAlt.ask < buy)) then
                    verdict = "AH ALT"
                  end
                  picks[#picks + 1] = { alt = alt.name, altLvl = alt.level, altCls = alt.cls,
                    slot = SLOTS[crafted.loc][2], id = id, name = crafted.name, prof = prof,
                    ilvl = crafted.ilvl, reqLvl = crafted.reqLvl, wornIlvl = wornIlvl, gain = gain,
                    mats = mats, buy = buy, ahAlt = ahAlt, verdict = verdict }
                end
              end
            end
          end
        end
      end
    end
    table.sort(picks, function(a, b)
      if (a.wornIlvl == 0) ~= (b.wornIlvl == 0) then return a.wornIlvl == 0 end
      if a.gain ~= b.gain then return a.gain > b.gain end
      return a.alt < b.alt or (a.alt == b.alt and a.id < b.id)
    end)
    return { picks = picks, alts = #alts, newest = newest, hasRecipes = true }
  end
  function ns.GoldAltCraftLines(altFilter, now, db)
    now = now or call(g("time")) or 0
    local res = ns.GoldAltCraft(altFilter, db)
    if res.alts == 0 then
      return { altFilter and altFilter ~= ""
        and ("Alt craft: no DataStore equipment data found for %s."):format(altFilter)
        or "Alt craft: no other characters found in DataStore yet (log into your alts once)." }
    end
    if not res.hasRecipes then
      return { "Alt craft: no crafting recipes saved for this character yet — open your profession window once." }
    end
    if #res.picks == 0 then
      return { ("Alt craft: nothing this character crafts upgrades your %d alt%s right now."):format(
        res.alts, res.alts == 1 and "" or "s") }
    end
    local me = short(ns.me() or "")
    local tag = res.newest > 0 and dsDate(res.newest, now) or ""
    local lines = { ("Alt craft (%s -> %d alt%s%s):"):format(me, res.alts, res.alts == 1 and "" or "s",
      tag ~= "" and (", " .. tag:sub(1, -2)) or "") }
    local perAlt, shown = {}, 0
    local capPerAlt = (type(altFilter) == "string" and altFilter ~= "") and ns.GOLD_ALT_CRAFT_MAX or ns.GOLD_ALT_CRAFT_PER_ALT
    for _, p in ipairs(res.picks) do
      if shown >= ns.GOLD_ALT_CRAFT_MAX then break end
      perAlt[p.alt] = (perAlt[p.alt] or 0) + 1
      if perAlt[p.alt] <= capPerAlt then
        local up = p.wornIlvl == 0 and "empty" or ("+" .. p.gain .. " ilvl")
        local lvNote = p.reqLvl > p.altLvl and (" at lv" .. p.reqLvl) or ""
        local pricePart = ""
        if p.mats and p.buy then
          pricePart = (" — %s (mats %s, AH %s)"):format(p.verdict, money(p.mats), money(p.buy))
        elseif p.mats then
          pricePart = (" — %s (mats %s)"):format(p.verdict, money(p.mats))
        elseif p.buy then
          pricePart = (" — %s (AH %s)"):format(p.verdict, money(p.buy))
        end
        local altPart = p.ahAlt and (" | AH alt: %s ilvl %d @ %s"):format(p.ahAlt.name, p.ahAlt.ilvl, money(p.ahAlt.ask)) or ""
        local base = ("-> %s (%s): %s (ilvl %d, %s%s)"):format(p.alt, p.slot, p.name, p.ilvl, up, lvNote)
        local line = base .. pricePart .. altPart
        if #line > 255 then line = base .. pricePart end
        if #line > 255 then line = base:sub(1, 255) end
        lines[#lines + 1] = line
        shown = shown + 1
      end
    end
    if not (type(altFilter) == "string" and altFilter ~= "") and #res.picks > shown then
      lines[#lines + 1] = ("/uw gold craft <AltName> for more (%d total upgrades)."):format(#res.picks)
    end
    return lines
  end
end

-- The members' weekly line (Louis, 16 Nov 2026 03:42: "Yes, build it first"; the weekly recap's "Worth a look"
-- block, bot/uwbot/market.py; coordinator 04:00: name the top-asking finds). His scan says found recipes, blueprints
-- and bags are the gold at members' levels (herbs and ore ask under 5s). So on the bot's PC, after a visit to the
-- auction house, the save carries a small brief for the bot:
--   UW_GuildDB.goldBrief = { at, recipes = { n, median, p75 }, trend, span,
--                            finds = { { n = name, c = copper, il = item level }, ... } }
-- finds: the GOLD_FINDS_BAND top asks in each ten item levels, recipes and bags seen on GOLD_FINDS_DAYS days or more
-- (one odd listing is not a market), named only when the client has the item loaded. The bot picks the three that
-- fit members' levels. Asks, not sales: the bot words them as asks. Prices and item names only, nothing about any
-- player. Built at logout (addon lead, 16 Nov: one pass over ~6,800 rows is a hitch at the auctioneer, unseen at
-- logout), and only after a visit, so most logouts do nothing.
ns.GOLD_RECIPE_CLASS, ns.GOLD_BAG_CLASS, ns.GOLD_BRIEF_MIN = 9, 1, 20
ns.GOLD_FINDS_BAND, ns.GOLD_FINDS_DAYS = 4, 3
local function quantile(t, q) return t[math.max(1, math.floor(q * (#t - 1) + 0.5) + 1)] end
-- Crafting between guildmates (coordinator 04:28: the bot's "who can make X" answer says what the mats and the item
-- ask): for each made item the guild's crafters know (UW_GuildDB.recipeInfo, keys "i<id>", reagents
-- "id:count:name,..."), the item's ask and its mats' asks together, only when every mat has one. The bot reads
-- brief.craft = { ["i<id>"] = { i = copper, m = copper } }.
ns.GOLD_CRAFT_MAX = 600
-- pairs() order: past the cap the set kept is arbitrary (a few hundred recipes today, well under it).
-- Other addons in his pack that already price items (Louis, 22 Nov 2026: wire the pack's gold data; read only, every
-- field checked, ops/reads/gold-data-shapes-2026-11-22.md). A vendor's price: Auctionator's cache of what merchants
-- charge (AUCTIONATOR_VENDOR_PRICE_CACHE, "id" -> copper a unit, fractions kept) and ForeverWowCraftScanner's vendors
-- (FWCS_DB.__vendors[npc].items[id].price for a batch of .stack: Places.lua:371, its own Tailor.lua:90 divides), the
-- lower. ForeverWowCraftScanner's own auction scan (FWCS_DB["<realm>|Horde"][id].l = rows of
-- { unit copper, qty, ... }, t = when): the lowest unit ask of the newest realm table that has the item.
vendorCache = function()
  local out, cache, fwcs = {}, g("AUCTIONATOR_VENDOR_PRICE_CACHE"), g("FWCS_DB")
  local function keep(id, c)
    id, c = tonumber(id), price(c)
    if id and c and (not out[id] or c < out[id]) then out[id] = c end
  end
  if type(cache) == "table" then for id, c in pairs(cache) do keep(id, c) end end
  local vendors = type(fwcs) == "table" and fwcs.__vendors
  if type(vendors) == "table" then
    for _, v in pairs(vendors) do
      if type(v) == "table" and type(v.items) == "table" then
        for id, it in pairs(v.items) do -- its price is for the merchant's batch (stack 5, 20, 200): per unit here
          local stack = type(it) == "table" and type(it.stack) == "number" and it.stack >= 1 and it.stack or 1
          if type(it) == "table" and type(it.price) == "number" then keep(id, it.price / stack) end
        end
      end
    end
  end
  return out
end
function ns.GoldFwcsAsk(id)
  local fwcs, best, bestT = g("FWCS_DB"), nil, -1
  if type(fwcs) ~= "table" then return nil end
  for realm, items in pairs(fwcs) do
    local e = type(realm) == "string" and realm:sub(1, 2) ~= "__" and type(items) == "table" and items[id]
    if type(e) == "table" and type(e.l) == "table" and type(e.t) == "number" and e.t > bestT then
      local low
      for _, r in ipairs(e.l) do
        local c = type(r) == "table" and price(r[1])
        if c and (not low or c < low) then low = c end
      end
      if low then best, bestT = low, e.t end
    end
  end
  return best
end
local function craftAsks(db)
  local info, out, n, seen = type(UW_GuildDB) == "table" and UW_GuildDB.recipeInfo, {}, 0, {}
  local vendor = vendorCache()
  local function ask(id) -- mats repeat (cloth, thread): each price worked out once a pass
    if seen[id] == nil then seen[id] = ns.GoldPrice(id, db) or ns.GoldFwcsAsk(id) or false end
    return seen[id] or nil
  end
  local function mat(id) -- a mat: bought from a vendor when that's cheaper or nobody lists it
    local a, v = ask(id), vendor[id]
    if a and v then return math.min(a, v) end
    return a or v
  end
  if type(info) ~= "table" then return out end
  for key, e in pairs(info) do
    local id = type(key) == "string" and key:match("^i(%d+)$")
    local item = id and type(e) == "table" and type(e.reag) == "string" and ask(tonumber(id))
    if item then
      local mats, any = 0, false
      for rid, count in e.reag:gmatch("(%d+):(%d+)") do
        local p = mat(tonumber(rid))
        if not p then mats = nil break end
        mats, any = mats + p * tonumber(count), true
      end
      if mats and any then
        out[key], n = { i = item, m = math.max(1, math.floor(mats + 0.5)) }, n + 1 -- vendor fractions: whole copper
        if n >= ns.GOLD_CRAFT_MAX then break end
      end
    end
  end
  return out
end
function ns.GoldBrief(db, now)
  db = db or history()
  local items = g("C_Item")
  local instant = items and items.GetItemInfoInstant or g("GetItemInfoInstant")
  local info = items and items.GetItemInfo or g("GetItemInfo")
  if not db or type(instant) ~= "function" then return nil end
  local asks, bands = {}, {}
  for key, row in pairs(db) do
    local id = type(key) == "string" and key:match("^%d+$") and tonumber(key) or type(key) == "number" and key
    if id then
      local ok, _, _, _, _, _, classID = pcall(instant, id)
      if not ok then classID = nil end
      if classID == ns.GOLD_RECIPE_CLASS or classID == ns.GOLD_BAG_CLASS then
        local p = ns.GoldPrice(id, db)
        if p and classID == ns.GOLD_RECIPE_CLASS then asks[#asks + 1] = p end
        local _, days = dailyLows(row)
        if p and days >= ns.GOLD_FINDS_DAYS and type(info) == "function" then
          local got, name, _, _, il = pcall(info, id)
          if got and type(name) == "string" and not ns.isSecret(name) and type(il) == "number" and not ns.isSecret(il) then
            local band = math.floor(il / 10)
            bands[band] = bands[band] or {}
            local b = bands[band]
            b[#b + 1] = { n = name, c = p, il = il }
          end
        end
      end
    end
  end
  if #asks < ns.GOLD_BRIEF_MIN then return nil end
  table.sort(asks)
  local finds = {}
  for _, b in pairs(bands) do
    table.sort(b, function(x, y) return x.c > y.c or x.c == y.c and x.n < y.n end)
    for i = 1, math.min(ns.GOLD_FINDS_BAND, #b) do finds[#finds + 1] = b[i] end
  end
  table.sort(finds, function(x, y) return x.il < y.il or x.il == y.il and x.c > y.c end)
  local ratio, _, span = ns.GoldTrend(db)
  return { at = now or time(), recipes = { n = #asks, median = quantile(asks, 0.5), p75 = quantile(asks, 0.75) },
    trend = ratio and math.floor(ratio * 100 + 0.5) or nil, span = span, finds = finds, craft = craftAsks(db) }
end
local visited = false
local function keepBrief()
  if not visited or not ns.GoldHere() or type(UW_GuildDB) ~= "table" then return end
  visited = false
  local b = ns.GoldBrief()
  if b then UW_GuildDB.goldBrief = b end
end
ns.GoldKeepBrief = keepBrief
function ns.GoldVisited() visited = true end
-- Auctionator writes its scan into its history while the house is open; the brief follows at the next logout or
-- /reload, when the save is written anyway.
local f = CreateFrame("Frame")
ns.listen(f, { "AUCTION_HOUSE_CLOSED", "PLAYER_LOGOUT" })
f:SetScript("OnEvent", ns.guard(function(_, event)
  if event == "AUCTION_HOUSE_CLOSED" then visited = true else keepBrief() end
end))
