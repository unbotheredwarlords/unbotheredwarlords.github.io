-- Member reports (Louis, 22 Nov 2026: "addon holders need to scrape and report meaningful data back to us in a
-- secure way that protects privacy and security"). Each member's UW_Guild sends the Guild Master's addon a few counts
-- about the ADDON on that PC for each finished UTC day: which build and setup it runs, which UW_Guild features were
-- used (by name only), and where UW_Guild's own errors happened (file, line and a hash, never the message). Never a
-- name, chat, zone, playtime, groupmate, item or gold. Design, route and the privacy rules: docs/member-reports.md.
--
-- Route (wire before build): the bot's PC already says hello once a session (W1H, WeekOne.lua). A member that hears
-- it from the Guild Master's character whispers its unsent days to that character, spread over a few minutes; at its
-- own login it does the same when that character is online. Only the bot's PC keeps them, by day and a per-day id
-- that can't be joined across days, and folds them into anonymous day totals; the bot copies those into history
-- (bot/uwbot/history.py mr.*). One switch: /uw share off (ns.WeekOneSharing) stops these and the week-one counts.
--   RPV <day> <id> <version> <k=v,...>   mac, upd (automatic updates), kit (addon fixes), ui, h, ad, kb (bands)
--   RPU <day> <id> <key=n;...>           usage counts that day by feature name ("cmd.lead", "button.lfg"); "?" counts
--                                        /uw words that don't exist, never the words
--   RPE <day> <id> <sig=n;...>           UW_Guild errors that day: "<File>:<line>:<hash>" = times (99 at most)
local _, ns = ...

local DAY = 86400
ns.REPORT_BACK_DAYS = 3        -- finished days a member sends: yesterday and the 2 before it
ns.REPORT_RAW_DAYS = 4         -- the bot's PC keeps a day's rows by id this long (a resend replaces), then only totals
ns.REPORT_KEEP_DAYS = 60       -- day totals in the save; the bot keeps them for good as counts (history.py)
ns.REPORT_GAP = 30 * 60        -- one send a session per gap, whatever number of hellos
ns.REPORT_MAX_IDS, ns.REPORT_MAX_KEYS, ns.REPORT_MAX_ERRS, ns.REPORT_DAY_KEYS = 300, 60, 10, 200
ns.REPORT_MSG = 240            -- bytes per message, inside the game's 255

local function fmt(f, t) local d = date or (os and os.date) return d and d(f, t) end
local function dayOf(t) return fmt("!%Y%m%d", t) end
local function botPC() return type(ns.SCHEDULE) == "table" and (tonumber(ns.SCHEDULE.gen) or 0) > 0 end
local function secret(v) return ns.isSecret and ns.isSecret(v) end
local function whole(v)
  local n = tonumber(v)
  if not n or n ~= n or n < 0 or n == math.huge then return nil end
  return math.floor(n)
end
local function clamp(n, hi) return math.min(n, hi) end
local function band(x, step, hi)
  if type(x) ~= "number" or secret(x) or x ~= x then return nil end
  return math.min(math.floor(x / step + 0.5) * step, hi)
end
-- The Guild Master's character, as week one tells it (#805's ns.WeekOneIsHis once it is in; rank 0 until then).
local function his(name)
  if type(name) ~= "string" or secret(name) then return false end
  if ns.WeekOneIsHis then return ns.WeekOneIsHis(name) == true end
  return ns.IsLouis and ns.IsLouis(name) == true or false
end
function ns.ReportsOn() return ns.WeekOneSharing and ns.WeekOneSharing() or false end

-- Member side ------------------------------------------------------------------------------------------------------
-- UW_GuildDB.report = { salt = 16 hex (never sent), to = the Guild Master's character last heard, env = { [day] =
--   setup fields }, err = { [day] = { [sig] = n } }, sent = { [day] = true } }. Days past a week are dropped.
local function mine()
  local db = UW_GuildDB
  local r = type(db.report) == "table" and db.report or {}
  db.report = r
  for _, k in ipairs({ "env", "err", "sent" }) do if type(r[k]) ~= "table" then r[k] = {} end end
  if type(r.salt) ~= "string" or not r.salt:match("^%x+$") or #r.salt ~= 16 then
    local t = {}
    for i = 1, 16 do local k = math.random(16) t[i] = ("0123456789abcdef"):sub(k, k) end
    r.salt = table.concat(t)
  end
  return r
end
-- A day's id: 8 hex from the salt and the day, so two days of one PC don't match.
function ns.ReportId(salt, day) return ("%08x"):format(ns.NameHash(salt, day)) end

local function prune(r, now)
  local oldest = dayOf(now - 7 * DAY)
  for _, k in ipairs({ "env", "err", "sent" }) do
    for day in pairs(r[k]) do if type(day) ~= "string" or day < oldest then r[k][day] = nil end end
  end
end
local function sharingHere() return ns.ReportsOn() and not botPC() and ns.tracksGuild and ns.tracksGuild() end

-- The setup, once a login (the memory band at logout: its walk of every addon is slow, so behind that screen).
local function loadedAddons()
  local A = C_AddOns or {}
  local count = A.GetNumAddOns or _G.GetNumAddOns
  local loaded = A.IsAddOnLoaded or _G.IsAddOnLoaded
  if type(count) ~= "function" or type(loaded) ~= "function" then return nil end
  local n, on = count(), 0
  if type(n) ~= "number" or secret(n) then return nil end
  for i = 1, math.min(n, 500) do if loaded(i) == true then on = on + 1 end end
  return band(on, 5, 200)
end
function ns.ReportSetup()
  if not sharingHere() then return end
  local r, now = mine(), time()
  prune(r, now)
  local day = dayOf(now)
  local e = type(r.env[day]) == "table" and r.env[day] or {}
  r.env[day] = e
  e.mac = (IsMacClient and IsMacClient() == true) and 1 or 0
  e.upd = (ns.hasUpdater and ns.hasUpdater()) and 1 or 0
  if ns.CheckKit then
    local ok, missReq, _, conflicts = pcall(ns.CheckKit)
    if ok and type(missReq) == "table" and type(conflicts) == "table" then e.kit = clamp(#missReq + #conflicts, 9) end
  end
  local scale = UIParent and UIParent.GetEffectiveScale and UIParent:GetEffectiveScale()
  e.ui = band(type(scale) == "number" and scale * 100 or nil, 5, 300)
  local _, h = nil, nil
  if _G.GetPhysicalScreenSize then _, h = _G.GetPhysicalScreenSize() end
  e.h = band(h, 120, 4320)
  e.ad = loadedAddons()
end
function ns.ReportLogout()
  if not sharingHere() or not ns.AddonKB then return end
  local r = mine()
  local e = r.env[dayOf(time())]
  if type(e) == "table" and e.kb == nil then e.kb = band(ns.AddonKB(), 100, 99900) end -- once a day
end

-- An error UW_Guild kept (Core.lua noteError): its place in our code (a bare UW_Guild file name, never a path) and a
-- 16-bit hash of the message with quoted text and numbers blanked first (red team, 22 Nov 2026: a message can quote a
-- name, and an unblanked hash could be matched by hashing each roster name). Never the message itself.
function ns.ReportSig(msg, stack)
  if type(msg) ~= "string" then return nil end
  local file, line = msg:match("UW_Guild[/\\]([%w_]+)%.lua:(%d+)")
  if not file and type(stack) == "string" then file, line = stack:match("UW_Guild[/\\]([%w_]+)%.lua:(%d+)") end
  local text = msg:gsub("^.-%.lua:%d+:%s*", ""):gsub("'[^']*'", "''"):gsub('"[^"]*"', '""'):gsub("%d+", "#")
  local h = ns.NameHash(text, "") % 65536
  return ("%s:%s:%04x"):format(file or "x", line or "0", h)
end
function ns.ReportError(e)
  if not sharingHere() or type(e) ~= "table" then return end
  local sig = ns.ReportSig(e.msg, e.stack)
  if not sig then return end
  local r = mine()
  local day = dayOf(time())
  local d = type(r.err[day]) == "table" and r.err[day] or {}
  r.err[day] = d
  if d[sig] == nil then
    local n = 0
    for _ in pairs(d) do n = n + 1 end
    if n >= ns.REPORT_MAX_ERRS then return end
  end
  d[sig] = clamp((tonumber(d[sig]) or 0) + 1, 99)
end

-- "k=v;k=v" pieces packed into messages of at most REPORT_MSG bytes.
local function pack(head, pairsList, sep)
  local out, cur = {}, nil
  for _, p in ipairs(pairsList) do
    local next = cur and (cur .. sep .. p) or (head .. p)
    if #next > ns.REPORT_MSG and cur then out[#out + 1] = cur cur = head .. p else cur = next end
  end
  if cur then out[#out + 1] = cur end
  return out
end
local function sortedPairs(t, cap)
  local keys = {}
  for k in pairs(t) do keys[#keys + 1] = k end
  table.sort(keys)
  local out = {}
  for i = 1, math.min(#keys, cap) do out[#out + 1] = keys[i] .. "=" .. t[keys[i]] end
  return out
end
-- One finished day's messages, or nil when this PC didn't run UW_Guild in our guild that day.
local ENV_KEYS = { "mac", "upd", "kit", "ui", "h", "ad", "kb" }
function ns.ReportMessages(day)
  local r = mine()
  local env = r.env[day]
  if type(env) ~= "table" then return nil end
  local id = ns.ReportId(r.salt, day)
  local f = {}
  for _, k in ipairs(ENV_KEYS) do
    local v = whole(env[k])
    if v then f[#f + 1] = k .. "=" .. v end
  end
  local ver = tostring(ns.VERSION or "dev"):gsub("[^%w%.%-]", ""):sub(1, 24)
  local msgs = { ("RPV\t%s\t%s\t%s\t%s"):format(day, id, ver, table.concat(f, ",")) }
  local u = UW_GuildDB.usage
  local d = type(u) == "table" and type(u.days) == "table" and u.days[fmt("!%Y-%m-%d", ns.ReportDayTime(day))] or nil
  if type(d) == "table" and ns.UsageOn and ns.UsageOn() then
    local counts, unknown = {}, 0
    for k, n in pairs(d) do
      n = whole(n)
      if type(k) == "string" and n and n > 0 then
        -- A wrong /uw word, first typed or retyped ("repeat unknown <word>"): only how many, never the word
        -- (red team, 22 Nov 2026: the repeat key carried it).
        if k:find("unknown", 1, true) then unknown = unknown + n
        else
          local key = k:gsub(" ", ".")
          if key:match("^%a[%w%.]*$") and #key <= 40 then counts[key] = clamp(n, 999) end
        end
      end
    end
    if unknown > 0 then counts["?"] = clamp(unknown, 999) end
    for _, m in ipairs(pack(("RPU\t%s\t%s\t"):format(day, id), sortedPairs(counts, ns.REPORT_MAX_KEYS), ";")) do
      msgs[#msgs + 1] = m
    end
  end
  if type(r.err[day]) == "table" and next(r.err[day]) then
    for _, m in ipairs(pack(("RPE\t%s\t%s\t"):format(day, id), sortedPairs(r.err[day], ns.REPORT_MAX_ERRS), ";")) do
      msgs[#msgs + 1] = m
    end
  end
  return msgs
end
-- Noon UTC of a "YYYYMMDD" day, for the usage table's "YYYY-MM-DD" key.
function ns.ReportDayTime(day)
  if not tostring(day):match("^%d%d%d%d%d%d%d%d$") then return 0 end
  local now = time()
  local t = now - now % DAY + 12 * 3600
  for _ = 1, 400 do
    if dayOf(t) == day then return t end
    t = t - DAY
  end
  return 0
end

-- Finished days this PC still has to send.
local function pending()
  local r, now = mine(), time()
  for k = 1, ns.REPORT_BACK_DAYS do
    local day = dayOf(now - k * DAY)
    if not r.sent[day] and type(r.env[day]) == "table" then return true end
  end
  return false
end
local sentAt, online
local function sendDays(to)
  if not sharingHere() or not his(to) then return end
  if not online(to) then return end -- he logged off while this waited: a whisper would print "No player named"
  local now = time()
  if sentAt and now - sentAt < ns.REPORT_GAP then return end
  sentAt = now
  local r = mine()
  prune(r, now)
  for k = 1, ns.REPORT_BACK_DAYS do
    local day = dayOf(now - k * DAY)
    local msgs = not r.sent[day] and ns.ReportMessages(day)
    if msgs then
      for i, m in ipairs(msgs) do
        local last = i == #msgs
        ns.craftSend(m, "WHISPER", to, last and function() r.sent[day] = true end or nil,
          function() return not ns.ReportsOn() end) -- /uw share off drops what is still queued
      end
    end
  end
  ns.trace("reports", "sent", true)
end
-- The roster's word on a guildmate being online, and how many are: a whisper to someone offline would print the
-- game's "No player named ..." line, and the delay before sending is spread wider the more guildmates are on.
online = function(full)
  local on, count = false, 0
  local n = GetNumGuildMembers and GetNumGuildMembers() or 0
  if type(n) ~= "number" or secret(n) then return false, 0 end
  for i = 1, n do
    local who, _, _, _, _, _, _, _, isOn = GetGuildRosterInfo(i)
    if isOn == true then
      count = count + 1
      if full and type(who) == "string" and not secret(who) and ns.fullName(who) == full then on = true end
    end
  end
  return on, count
end
local function sendSoon(to)
  if not pending() then return end
  local _, count = online(nil)
  ns.after(15 + math.random() * math.min(600, 60 + 4 * count), function() sendDays(to) end)
end
-- The bot's PC said hello (W1H): week one's handler first, unchanged, then this member's report.
local weekOneHello = ns.handlers.W1H
assert(weekOneHello, "Reports.lua loads after WeekOne.lua")
ns.handlers.W1H = function(sender, channel, ...)
  ns.protect(weekOneHello, sender, channel, ...)
  if channel ~= "GUILD" or not sharingHere() or not ns.inRoster(sender) or not his(sender)
    or ns.shortName(sender) == ns.shortName(ns.me() or "") then
    return
  end
  mine().to = sender
  if sentAt and time() - sentAt < ns.REPORT_GAP then return end
  sendSoon(sender)
end

-- /uw share off (and the options switch, which runs it) stops at once: what this PC held for reports is deleted,
-- and so are the usage counts unless the member turned them on with /uw usage on.
local shareCmd = ns.commands.share
ns.commands.share = function(args)
  shareCmd(args)
  if UW_GuildDB and not ns.ReportsOn() then
    UW_GuildDB.report = nil
    if UW_GuildDB.usageOn == nil and not botPC() then UW_GuildDB.usage = nil end
  end
end

-- Collector side (the bot's PC only) -------------------------------------------------------------------------------
-- UW_GuildDB.reports = { v = 1, raw = { [day] = { [id] = { v, f = {}, u = {}, e = {} } } } (REPORT_RAW_DAYS),
--   days = { [day] = totals } (REPORT_KEEP_DAYS) }. Totals: n (PCs), ver = { [version] = PCs }, f = { mac, upd = PCs
--   with 1; kit, ui, h, ad, kb = { [band] = PCs } }, u = { [key] = { c = PCs, n = uses } }, e = { [sig] = { c, n } }.
--   Who sent a row is never written.
local function theirs()
  local db = UW_GuildDB
  local t = type(db.reports) == "table" and db.reports or {}
  db.reports, t.v = t, 1
  if type(t.raw) ~= "table" then t.raw = {} end
  if type(t.days) ~= "table" then t.days = {} end
  return t
end
-- One id per sending character a day, held in memory only (red team, 22 Nov 2026: 300 made-up ids from one
-- guildmate would be 300 PCs). A second id from the same character that day is refused.
local idOf = {}
local BANDS = { mac = 1, upd = 1, kit = 9, ui = 300, h = 4320, ad = 200, kb = 99900 }
local function rowFor(sender, channel, day, id)
  if channel ~= "WHISPER" or not botPC() or not (ns.tracksGuild and ns.tracksGuild()) then return nil end
  if not ns.inRoster(sender) or ns.shortName(sender) == ns.shortName(ns.me() or "") then return nil end
  if ns.WeekOneGmOwn and ns.WeekOneGmOwn(ns.shortName(sender)) then return nil end -- his characters never count
  if type(day) ~= "string" or not day:match("^%d%d%d%d%d%d%d%d$") or type(id) ~= "string"
    or not id:match("^[0-9a-f]+$") or #id ~= 8 then
    return nil
  end
  local now = time()
  if day > dayOf(now + DAY) or day < dayOf(now - ns.REPORT_BACK_DAYS * DAY) then return nil end
  local who = day .. "\0" .. ns.shortName(sender)
  if idOf[who] and idOf[who] ~= id then return nil end
  idOf[who] = id
  local t = theirs()
  local byId = type(t.raw[day]) == "table" and t.raw[day] or {}
  t.raw[day] = byId
  if not byId[id] then
    local n = 0
    for _ in pairs(byId) do n = n + 1 end
    if n >= ns.REPORT_MAX_IDS then return nil end
    byId[id] = {}
  end
  return byId[id]
end
local function setCounts(dst, text, keyOK, cap, hi)
  if type(text) ~= "string" then return end
  local have = 0
  for _ in pairs(dst) do have = have + 1 end
  for k, v in text:gmatch("([^;=]+)=(%d+)") do
    local n = whole(v)
    if n and #k <= 40 and keyOK(k) and (dst[k] ~= nil or have < cap) then
      if dst[k] == nil then have = have + 1 end
      dst[k] = clamp(n, hi) -- a resend replaces: never added
    end
  end
end
ns.handlers.RPV = function(sender, channel, day, id, ver, fields)
  local row = rowFor(sender, channel, day, id)
  if not row then return end
  row.v = type(ver) == "string" and ver:gsub("[^%w%.%-]", ""):sub(1, 24) or "?"
  row.f = {}
  for k, v in tostring(fields or ""):gmatch("(%a+)=(%d+)") do
    local n = whole(v)
    if BANDS[k] and n then row.f[k] = clamp(n, BANDS[k]) end
  end
end
ns.handlers.RPU = function(sender, channel, day, id, counts)
  local row = rowFor(sender, channel, day, id)
  if not row then return end
  row.u = type(row.u) == "table" and row.u or {}
  setCounts(row.u, counts, function(k)
    return k == "?" or (k:match("^%a[%w%.]*$") ~= nil and not k:find("unknown", 1, true))
  end, ns.REPORT_MAX_KEYS, 999)
end
ns.handlers.RPE = function(sender, channel, day, id, sigs)
  local row = rowFor(sender, channel, day, id)
  if not row then return end
  row.e = type(row.e) == "table" and row.e or {}
  setCounts(row.e, sigs, function(k) return k:match("^[%w_]+:%d+:%x%x%x%x$") ~= nil end, ns.REPORT_MAX_ERRS, 99)
end

-- A day's totals from its rows. A row that sent only usage or errors (its RPV lost) still counts once.
function ns.ReportTotals(byId)
  local d = { n = 0, ver = {}, f = { mac = 0, upd = 0 }, u = {}, e = {} }
  local uKeys = 0
  for _, row in pairs(byId) do
    if type(row) == "table" then
      d.n = d.n + 1
      local v = row.v or "?"
      d.ver[v] = (d.ver[v] or 0) + 1
      for k, n in pairs(type(row.f) == "table" and row.f or {}) do
        if k == "mac" or k == "upd" then d.f[k] = d.f[k] + (n == 1 and 1 or 0)
        else
          d.f[k] = type(d.f[k]) == "table" and d.f[k] or {}
          d.f[k][tostring(n)] = (d.f[k][tostring(n)] or 0) + 1
        end
      end
      for _, part in ipairs({ "u", "e" }) do
        for k, n in pairs(type(row[part]) == "table" and row[part] or {}) do
          local c = d[part][k]
          if not c and (part == "e" or uKeys < ns.REPORT_DAY_KEYS) then
            c = { c = 0, n = 0 }
            d[part][k] = c
            if part == "u" then uKeys = uKeys + 1 end
          end
          if c then c.c, c.n = c.c + 1, c.n + n end
        end
      end
    end
  end
  return d
end
-- Before WoW writes the save (logout or /reload): every day still held by id is totalled again, so the bot always
-- reads current totals; days past REPORT_RAW_DAYS keep only their totals, and totals past REPORT_KEEP_DAYS go.
function ns.ReportFold(now)
  if not botPC() or type(UW_GuildDB.reports) ~= "table" then return end
  local t = theirs()
  now = now or time()
  local rawFrom, keepFrom = dayOf(now - ns.REPORT_RAW_DAYS * DAY), dayOf(now - ns.REPORT_KEEP_DAYS * DAY)
  for day, byId in pairs(t.raw) do
    if type(byId) == "table" and type(day) == "string" then t.days[day] = ns.ReportTotals(byId) end
    if type(day) ~= "string" or day < rawFrom then t.raw[day] = nil end
  end
  for day in pairs(t.days) do if type(day) ~= "string" or day < keepFrom then t.days[day] = nil end end
end

-- Events ------------------------------------------------------------------------------------------------------------
local f = CreateFrame("Frame")
ns.listen(f, { "PLAYER_LOGOUT" })
f:SetScript("OnEvent", ns.guard(function()
  if not UW_GuildDB then return end
  ns.protect(ns.ReportLogout)
  ns.protect(ns.ReportFold)
end))
ns.afterRoster(function()
  ns.protect(ns.ReportSetup)
  -- At login: the Guild Master's character heard last time, if it is on now.
  local r = UW_GuildDB and UW_GuildDB.report
  local to = type(r) == "table" and r.to or nil
  if sharingHere() and his(to) and online(to) then sendSoon(to) end
end)
