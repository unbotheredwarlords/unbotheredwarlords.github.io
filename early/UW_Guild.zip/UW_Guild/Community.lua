-- The Warlords and Peons Community (Louis, 22 Nov 2026: "Whatever can engineer, work-around, etc.; I just want all
-- features optimal and highly functional!"). The in-game Community joins UW and Bothered Peons characters in one chat,
-- but Blizzard's Discord link is one channel per guild and never carries a Community. So its General chat is copied
-- here for the bot to post in Discord (bot/uwbot/community.py), the way the guild event log is copied (Onboarding.lua).
--
-- What is copied, and what never is:
-- - Only on the Guild Master's account (UW_GuildDB.gmAccount): his save is the one the bot reads, so no other PC holds
--   a copy. Members' clients copy nothing.
-- - Only a Character-type club named ns.COMMUNITY_NAME (case, spaces and "&"/"and" ignored): never the guild's own
--   club, a Battle.net community, or any other club.
-- - Only its General stream, and only one everyone can post in: never an officer or leaders-only stream, never a
--   whisper, never guild or officer chat. The game's chat log is not read (it records whispers: coordinator, 22 Nov).
-- - Kept per message: its id (dedupe), when, who wrote it and what (cut to ns.COMMUNITY_TEXT_MAX), at most
--   ns.COMMUNITY_KEEP rows. A deleted message is marked gone, its text dropped, so the bot takes its line down too.
-- - /uw-hide and the Discord privacy hide are applied by the bot, which holds them. Nothing is sent, whispered or
--   shown in game from here.
-- WoW writes SavedVariables only on logout or /reload (DESIGN.md, "Latency"), so the Discord copy comes in batches.
-- On login the stream's recent history is read once (pcall-guarded), so what was said while the GM was away is
-- copied too, on the clients that have it.
-- /uw community off stops the copying on this account (the bot then posts nothing new); /uw community on restarts it.
local _, ns = ...
local say = ns.say

ns.COMMUNITY_NAME = "Warlords and Peons"
ns.COMMUNITY_KEEP, ns.COMMUNITY_TEXT_MAX, ns.COMMUNITY_BACKFILL = 200, 300, 50

local function plain(v) return v ~= nil and not ns.isSecret(v) and v or nil end
local function key(name) return (name:lower():gsub("&", "and"):gsub("[%s%p]", "")) end
local OURS = key(ns.COMMUNITY_NAME)

local function try(fn, ...)
  if type(fn) ~= "function" then return nil end
  local ok, a = pcall(fn, ...)
  if ok then return a end
  return nil
end

local function enum(group, name, fallback)
  local e = rawget(_G, "Enum")
  return type(e) == "table" and type(e[group]) == "table" and e[group][name] or fallback
end

local function store()
  if type(UW_GuildDB) ~= "table" or UW_GuildDB.gmAccount ~= true then return nil end
  local c = type(UW_GuildDB.community) == "table" and UW_GuildDB.community or {}
  UW_GuildDB.community = c
  if c.off then return nil end
  c.msgs = type(c.msgs) == "table" and c.msgs or {}
  return c
end

-- Is this club ours? Character type, our name, never the guild's own club.
local function ours(clubId)
  if not (C_Club and plain(clubId)) then return false end
  local info = try(C_Club.GetClubInfo, clubId)
  if type(info) ~= "table" then return false end
  local kind, name = plain(info.clubType), plain(info.name)
  return kind == enum("ClubType", "Character", 1) and type(name) == "string" and key(name) == OURS
end

local function general(clubId, streamId)
  local s = plain(streamId) and try(C_Club.GetStreamInfo, clubId, streamId)
  if type(s) ~= "table" then return false end
  return plain(s.streamType) == enum("ClubStreamType", "General", 0) and plain(s.leadersAndModeratorsOnly) ~= true
end

local function parts(m)
  local id = type(m) == "table" and m.messageId
  local epoch, pos = type(id) == "table" and plain(id.epoch), type(id) == "table" and plain(id.position)
  if type(epoch) ~= "number" or type(pos) ~= "number" then return nil end
  return epoch, pos
end
local function idOf(m)
  local epoch, pos = parts(m)
  return epoch and string.format("%.0f-%.0f", epoch, pos) or nil
end
local function older(a, b)
  local ea, pa = parts(a)
  local eb, pb = parts(b)
  if not (ea and eb) then return ea ~= nil and eb == nil end
  return ea < eb or (ea == eb and pa < pb)
end

-- The game's timestamp is microseconds since 1970; anything else reads as now.
local function whenOf(m)
  local ts = plain(m.timestamp)
  if type(ts) == "number" and ts > 1e15 and ts < 1e17 then return math.floor(ts / 1e6) end
  return time()
end

-- Chat text as a person reads it: item and spell links keep their [name], colours and textures go.
local function readable(s)
  s = s:gsub("|H.-|h(.-)|h", "%1"):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", "")
  s = s:gsub("|A.-|a", ""):gsub("[%c]", " "):gsub("%s+", " ")
  return (strtrim and strtrim(s) or s:match("^%s*(.-)%s*$")):sub(1, ns.COMMUNITY_TEXT_MAX)
end

local function find(list, id)
  for i = #list, 1, -1 do if list[i].id == id then return i end end
  return nil
end

local function keep(c, m)
  local id = idOf(m)
  if not id then return end
  local i = find(c.msgs, id)
  if plain(m.destroyed) == true then
    if i then c.msgs[i].text, c.msgs[i].gone = nil, true end
    return
  end
  if i then return end
  local author = type(m.author) == "table" and m.author or {}
  local who, text = plain(author.name), plain(m.content)
  if type(who) ~= "string" or who == "" or type(text) ~= "string" then return end
  text = readable(text)
  if text == "" then return end
  c.msgs[#c.msgs + 1] = { id = id, at = whenOf(m), who = who:sub(1, 60), text = text }
  while #c.msgs > ns.COMMUNITY_KEEP do table.remove(c.msgs, 1) end
end

local function onMessage(clubId, streamId, messageId)
  local c = store()
  if not (c and ours(clubId) and general(clubId, streamId)) then return end
  keep(c, try(C_Club.GetMessageInfo, clubId, streamId, messageId))
end
ns.CommunityMessage = onMessage

-- Recent history of each of our clubs' General stream, oldest first.
local function backfill()
  local c = store()
  if not (c and C_Club) then return end
  for _, club in ipairs(try(C_Club.GetSubscribedClubs) or {}) do
    local clubId = type(club) == "table" and plain(club.clubId)
    if clubId and ours(clubId) then
      for _, s in ipairs(try(C_Club.GetStreams, clubId) or {}) do
        local streamId = type(s) == "table" and plain(s.streamId)
        if streamId and general(clubId, streamId) then
          local ranges = try(C_Club.GetMessageRanges, clubId, streamId)
          local last = type(ranges) == "table" and ranges[#ranges]
          local newest = type(last) == "table" and last.newestMessageId
          local got = newest and try(C_Club.GetMessagesBefore, clubId, streamId, newest, ns.COMMUNITY_BACKFILL)
          local list = type(got) == "table" and got or {}
          table.sort(list, older)
          for _, m in ipairs(list) do keep(c, m) end
          local nm = newest and try(C_Club.GetMessageInfo, clubId, streamId, newest)
          if nm then keep(c, nm) end
        end
      end
    end
  end
end
ns.CommunityBackfill = backfill

local f = CreateFrame("Frame")
f:SetScript("OnEvent", ns.guard(function(_, event, ...)
  if event == "PLAYER_ENTERING_WORLD" then
    local login = ...
    if login then ns.after(10, backfill) end
  else
    onMessage(...)
  end
end))
ns.listen(f, { "CLUB_MESSAGE_ADDED", "CLUB_MESSAGE_UPDATED", "PLAYER_ENTERING_WORLD" })

-- The club to invite into: our Community, if this character is in it.
local function ourClub()
  for _, club in ipairs(C_Club and try(C_Club.GetSubscribedClubs) or {}) do
    local clubId = type(club) == "table" and plain(club.clubId)
    if clubId and ours(clubId) then return clubId end
  end
  return nil
end
ns.CommunityClub = ourClub

local HOW = "Open the Guild & Communities window (J), pick " .. ns.COMMUNITY_NAME .. ", then Invite Member."

-- /uw cinvite Name: a Community invite to one player, sent by the person who typed it (one typed command, one
-- invite: the game's own Invite Member, never automatic). Anyone in the Community may invite (Louis, 22 Nov 20:42:
-- "everyone can always invite"); the game says no where it won't.
ns.commands.cinvite = function(args)
  local name = strtrim(args or "")
  if name == "" then say("Type a name: /uw cinvite Name. " .. HOW) return end
  local clubId = ourClub()
  if not clubId then say("You're not in " .. ns.COMMUNITY_NAME .. " on this character yet. Ask any member for an invite.") return end
  local ok = C_Club.SendCharacterInvitation and pcall(C_Club.SendCharacterInvitation, clubId, name)
  if ok then
    say(ns.COMMUNITY_NAME .. " invite sent to " .. name .. ".")
    ns.trace("community", "invite", true)
  else
    say("The game didn't send it from here. " .. HOW)
    ns.trace("community", "invite", false, "SendCharacterInvitation refused")
  end
end

-- /uw community: whether this account copies the Community's chat for Discord; on / off (Guild Master's account).
ns.commands.community = function(args)
  local a = strtrim(args or ""):lower()
  if type(UW_GuildDB) ~= "table" then return end
  if UW_GuildDB.gmAccount ~= true then
    say(ns.COMMUNITY_NAME .. " chat shows in our Discord from the Guild Master's game. Nothing is copied from yours.")
    return
  end
  UW_GuildDB.community = type(UW_GuildDB.community) == "table" and UW_GuildDB.community or {}
  local c = UW_GuildDB.community
  if a == "off" then
    c.off = true
    say(ns.COMMUNITY_NAME .. " chat is no longer copied for Discord. /uw community on starts it again.")
  elseif a == "on" then
    c.off = nil
    say(ns.COMMUNITY_NAME .. " chat is copied for Discord again, from your next /reload or logout.")
  else
    say(ns.COMMUNITY_NAME .. " chat " .. (c.off and "isn't" or "is") .. " copied for Discord from this account. "
      .. "/uw community " .. (c.off and "on" or "off") .. " to change it.")
  end
end
