-- UW_Guild onboarding: welcome panel, /uw near, buddy pairing, first-guild-group tracking.
-- Goal: every recruit is grouped with guildmates within 72 hours (see the guild playbook).
local _, ns = ...
local say = ns.say

-- Guild config -------------------------------------------------------------
ns.DISCORD_INVITE = "https://discord.gg/D5EZm3gAcZ" -- permanent server invite (never expires); an officer's /uw invite overrides it
ns.GM_BATTLETAG = "Storm#110232" -- Guild Master's main contact (Battle.net friend); keep in step with bot/uwbot/contact.py
ns.GM_STEAM = "https://steamcommunity.com/profiles/76561198031386428/" -- backup contact
ns.NEAR_RANGE = 3       -- /uw near lists online guildmates within this many levels
ns.GRP_RESEND_DAYS = 7  -- re-announce a first group on each login for this long, so a late officer still hears it
ns.RETURN_DAYS = 14     -- a player logging in after this long away gets one welcome-back line
ns.TAGLINE = "No sweat. No corpse camps. Just zug."
ns.SUBTAGLINE = "Raids, dungeons & chill. All ages and levels welcome."
local MEDIA = "Interface\\AddOns\\UW_Guild\\Media\\"
-- The norms that matter in game, numbered as Discord's #welcome-rules numbers them (bot/uwbot/layout.py NORMS: a bot
-- test checks each line starts with that norm's own words, and NORMS_TOTAL), so "norm 7" means one thing everywhere.
ns.NORMS = {
  { 1, "Be unbothered: no public drama. Take issues to an officer: whisper one, or /ask-officers in Discord." },
  { 2, "Raid voice is push-to-talk. Keep callouts short and named." },
  { 4, "Prox voice is for the open world only (ForeverVoice off in instances)." },
  { 5, "Sign up 24 hours ahead, and decline if you can't make it." },
  { 7, "Loot is main spec before off spec: /roll for main, /roll 99 for off spec." },
  { 9, "No real-money trading, gold selling, or GDKP." },
}
ns.NORMS_TOTAL = 11
-- Same words as layout.py FREE_HELP (#welcome-rules intro); a bot test compares them.
ns.FREE_HELP = "Helping a guildmate for free is welcome and never expected."
-- The three values the norms sit under in #welcome-rules (layout.py VALUES; the same bot test compares them).
ns.VALUES = { "Unbothered", "Reliable", "Fair" }

local function me() return ns.shortName(ns.me() or UnitName("player")) end
-- Times sent to other clients use the realm's clock: players' PC clocks can be off by minutes or hours.
local function serverNow() return (GetServerTime and GetServerTime()) or time() end

-- Discord invite ---------------------------------------------------------------
-- Officers save it with /uw invite; it spreads by INV on GUILD, and members ask on login (INVQ). Each saved invite
-- carries when an officer set it (inviteAt, realm time), so a member who was offline for a change still gets the
-- newest link, and an older one never replaces it. UW_GuildDB.invite overrides the compiled-in default.
function ns.ValidInvite(url)
  url = (strtrim(tostring(url or "")):gsub("/+$", ""))
  local code = url:match("^https://discord%.gg/([%w%-]+)$") or url:match("^https://discord%.com/invite/([%w%-]+)$")
  if code and #code >= 2 and #code <= 32 then return url end
end
function ns.Invite() return UW_GuildDB.invite or ns.DISCORD_INVITE end
local lastInviteReply = {}

-- Buddy pairing --------------------------------------------------------------
-- UW_GuildDB.buddies[recruit] = { buddy = name, by = officer, at = time }
local lastBuddyReply = {}

local function setBuddy(recruit, buddy, by)
  local cur = UW_GuildDB.buddies[recruit]
  if cur and cur.buddy == buddy then return end
  UW_GuildDB.buddies[recruit] = { buddy = buddy, by = by, at = time() }
  if buddy == me() then say(("You're %s's guild buddy. Say hi and pull them into a group this week."):format(recruit)) end
  if recruit == me() then
    say(("Your guild buddy is %s. Whisper them any time."):format(buddy))
    if ns.RefreshWelcome then ns.RefreshWelcome() end
  end
end

ns.commands.buddy = function(args)
  local recruit, rest = ns.splitName(args, ns.rosterName) -- Forever names are two words: "Mia Stone Rex Hall"
  local buddy, extra = ns.splitName(rest, ns.rosterName)
  if buddy and extra ~= "" and not ns.inRoster(buddy) then buddy, extra = rest, "" end -- named below as not found
  if not buddy or extra ~= "" then say("Usage: /uw buddy Recruit Buddy") return end
  if not ns.isOfficer(me()) then say("Only officers can assign buddies.") return end
  for _, n in ipairs({ recruit, buddy }) do
    if not ns.inRoster(n) then say(n .. " isn't in the guild roster (names are case-sensitive).") return end
  end
  setBuddy(recruit, buddy, me())
  ns.queue("buddy", recruit, buddy)
  if not ns.send(("BUDDY\t%s\t%s"):format(recruit, buddy), "GUILD") then
    say("Saved locally. Couldn't broadcast right now (combat or restricted); it syncs when they log in.")
  end
end

-- Pairings come only from officers. GUILD messages can only come from guildmates;
-- whispers can come from anyone, so both are checked against the roster by full Name-Realm.
-- Handlers receive the sender's full name.
ns.handlers.BUDDY = function(sender, _, recruit, buddy)
  if recruit and buddy and ns.isOfficer(sender) then setBuddy(recruit, buddy, ns.shortName(sender)) end
end

-- A member who was offline when paired asks on login; officers who know the pairing answer.
-- An unpaired recruit gets BUDN instead: their own client can't always tell it is a recruit (a new invite
-- sits in the lowest rank next to social members), but an officer who saw them join can. Join time alone
-- never expires, so it counts only while they are still in the lowest rank: a promoted member isn't waiting.
ns.handlers.BUDQ = function(sender, channel)
  if channel ~= "GUILD" or not ns.isOfficer(me()) or not ns.inRoster(sender) then return end
  local recruit = ns.shortName(sender)
  local pair = UW_GuildDB.buddies[recruit]
  if not pair and not (ns.hasRecruitRank(recruit) or (ns.isRecruit(recruit) and ns.isLowestRank(recruit))) then return end
  if lastBuddyReply[sender] and GetTime() - lastBuddyReply[sender] < 300 then return end
  lastBuddyReply[sender] = GetTime()
  ns.reply(pair and ("BUDDY\t%s\t%s"):format(recruit, pair.buddy) or ("BUDN\t" .. recruit), sender)
end

ns.handlers.BUDN = function(sender, channel, recruit)
  if channel ~= "WHISPER" or recruit ~= me() or not ns.isOfficer(sender) then return end
  UW_GuildCharDB.recruitAt = UW_GuildCharDB.recruitAt or time()
  if ns.RefreshWelcome then ns.RefreshWelcome() end
end

-- Guild jobs (docs/leadership.md): a job is a word in the member's public guild note ("Heal · Buddy"), so
-- everyone sees it in the guild roster, with or without UW_Guild. Members take one by asking an officer in game, or
-- by adding the word to their own note; deleting the word leaves it. Keep in step with bot/uwbot/jobs.py JOBS.
-- Leading isn't a job (Louis, 8 Nov 2026): anyone who wants to lead a raid or dungeon leads, rated by the people they
-- led (/uw rate, Thanks.lua).
ns.JOBS = {
  { key = "buddy", label = "Welcome buddy", words = { "buddy" } },
  { key = "recruiter", label = "Recruiter", words = { "recruiter" } },
  { key = "host", label = "Event host", words = { "event host", "host" } },
}
ns.JOBS_MIN = 2         -- every job has a lead and a backup
ns.JOBS_ASK_GAP = 86400 -- /uw jobs ask: once a day per officer account
local NOTE_STOP = { lf = true, lfm = true, need = true, needs = true, want = true, wants = true, looking = true, wtb = true }
ns.JOBS_ASK = "Anyone want to help out as a welcome buddy, recruiter or event host? Whisper me!"

-- Job keys a note names, in ns.JOBS order. Words after "LF", "need" or "want" are asks, not jobs (as for professions).
function ns.NoteJobs(note)
  if type(note) ~= "string" then return {} end
  local low, cut = note:lower(), nil
  for pos, w in low:gmatch("()(%a+)") do
    if NOTE_STOP[w] then cut = pos break end
  end
  if cut then low = low:sub(1, cut - 1) end
  local padded, out = " " .. low .. " ", {}
  for _, j in ipairs(ns.JOBS) do
    for _, w in ipairs(j.words) do
      local plain = w:gsub("%p", "%%%0")
      if padded:find("%f[%a]" .. plain .. "%f[%A]") then out[#out + 1] = j.key break end
    end
  end
  return out
end

-- job key -> sorted names of present members whose note names it, from the last roster read.
function ns.JobHolders()
  local out = {}
  for _, j in ipairs(ns.JOBS) do out[j.key] = {} end
  for name, m in pairs(UW_GuildDB.members or {}) do
    if type(m) == "table" and not m.left then
      for _, k in ipairs(ns.NoteJobs(m.note)) do table.insert(out[k], name) end
    end
  end
  for _, list in pairs(out) do table.sort(list) end
  return out
end

ns.commands.jobs = function(args)
  args = strtrim(args or ""):lower()
  if args == "ask" then
    if not ns.isOfficer(ns.me()) then say("Officers ask in guild chat. Want a job? Whisper an officer.") return end
    local last = UW_GuildDB.jobsAskedAt or 0
    if time() - last < ns.JOBS_ASK_GAP then say("You asked in guild chat today already. Again tomorrow.") return end
    UW_GuildDB.jobsAskedAt = time()
    pcall((C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage, ns.JOBS_ASK, "GUILD")
    return
  end
  local hs = ns.JobHolders()
  say("Guild jobs, from guild notes (open the guild roster to see them):")
  for _, j in ipairs(ns.JOBS) do
    local list = hs[j.key]
    local open = #list < ns.JOBS_MIN and (" · %d more wanted"):format(ns.JOBS_MIN - #list) or ""
    say(("%s: %s%s"):format(j.label, #list > 0 and table.concat(list, ", ", 1, math.min(#list, 6)) or "nobody yet", open))
  end
  -- Public notes are officer-only on Forever: offer editing your own note only to those who can.
  local canEdit = (C_GuildInfo and C_GuildInfo.CanEditPublicNote and C_GuildInfo.CanEditPublicNote() == true)
    or (CanEditPublicNote and CanEditPublicNote() == true)
  if canEdit then
    say("Want one? Whisper an officer, or add it to your note in the guild roster (e.g. \"Heal · Buddy\").")
  else
    say("Want one? Whisper an officer and they'll add it to your guild note.")
  end
end

ns.commands.contact = function()
  say(("Guild Master: add BattleTag %s as a Battle.net friend. Backup: Steam %s"):format(ns.GM_BATTLETAG, ns.GM_STEAM))
end

ns.commands.invite = function(args)
  args = strtrim(args or "")
  if args == "" then
    local url = ns.Invite()
    say(url and ("Our Discord: " .. url .. " (copy it from /uw welcome).")
      or "No Discord invite saved yet. Officers: /uw invite https://discord.gg/yourcode")
    return
  end
  if not ns.isOfficer(me()) then say("Only officers can set the Discord invite.") return end
  local url = ns.ValidInvite(args)
  if not url then say("That isn't a Discord invite link. Use https://discord.gg/code or https://discord.com/invite/code.") return end
  UW_GuildDB.invite, UW_GuildDB.inviteAt = url, serverNow()
  ns.RefreshWelcome()
  if ns.send("INV\t" .. url .. "\t" .. UW_GuildDB.inviteAt, "GUILD") then
    say("Discord invite saved and sent to guildmates online with UW_Guild.")
  else
    say("Saved. Couldn't broadcast right now (combat or restricted); members get it when they log in.")
  end
end

-- Only officers can change the invite: a link from anyone else could point at a scam server.
-- A link without a time (an older client) is accepted only while ours has none either.
ns.handlers.INV = function(sender, channel, url, at)
  if (channel ~= "GUILD" and channel ~= "WHISPER") or not ns.isOfficer(sender) then return end
  url, at = ns.ValidInvite(url), ns.finite(at)
  if at and at > serverNow() + 600 then at = nil end -- an officer's clock in the future can't pin a link forever
  if not url or (at or 0) < (UW_GuildDB.inviteAt or 0) then return end
  if url == UW_GuildDB.invite and (at or 0) == (UW_GuildDB.inviteAt or 0) then return end
  UW_GuildDB.invite, UW_GuildDB.inviteAt = url, at
  ns.RefreshWelcome()
end

-- A member asks on login: bare INVQ without a saved invite, INVQ\t<inviteAt> with one. Officers answer the first
-- with any invite they know, the second only with a newer one, and at most once per 5 min per member.
ns.handlers.INVQ = function(sender, channel, at)
  if channel ~= "GUILD" or not ns.isOfficer(me()) or not ns.inRoster(sender) then return end
  local url, theirs = ns.Invite(), ns.finite(at)
  if not url or (theirs and not (UW_GuildDB.invite and (UW_GuildDB.inviteAt or 0) > theirs)) then return end
  if lastInviteReply[sender] and GetTime() - lastInviteReply[sender] < 300 then return end
  lastInviteReply[sender] = GetTime()
  ns.reply("INV\t" .. url .. (UW_GuildDB.inviteAt and ("\t" .. UW_GuildDB.inviteAt) or ""), sender)
end

-- Discord ask -------------------------------------------------------------------
-- 8 Nov 2026: 131 of 146 characters joined in game and never saw the Discord; 1 had linked. Raid signups, crafting
-- and the bot's help can't see them, and only members with UW_Guild ever see the invite above.
-- So an officer's client whispers each newcomer once, a minute after they join: where the Discord is, and the exact
-- /link line for their own name. Why: a personal ask from a named member, at the moment of joining, with the next
-- step spelled out, beats any broadcast (Kraut & Resnick 2012, Building Successful Online Communities, ch. 5; Choi et
-- al. 2010, CSCW; Fogg 2009: prompt when motivation is high and the step is easy). Asking twice breeds reactance, so
-- a name is asked once ever: UW_GuildDB.discordAsked[name] = when (the bot can read it for a join-to-link funnel).
-- Officers share each ask as DWA on GUILD, so two officers online at a join don't both whisper.
--   /uw discord        status: asked so far, still to ask, online now
--   /uw discord ask    whisper up to DISCORD_ASK_RUN guildmates online now who joined before this existed
--   /uw discord off|on the join whisper on this account
ns.DISCORD_ASK_DELAY = 60 -- seconds after the join line, plus up to 30 more so officers online together don't collide
ns.DISCORD_ASK_RUN = 25   -- whispers per /uw discord ask
ns.DISCORD_ASK_GAP = 2    -- seconds between them: gentle on the chat throttle
local function askedDB()
  UW_GuildDB.discordAsked = type(UW_GuildDB.discordAsked) == "table" and UW_GuildDB.discordAsked or {}
  return UW_GuildDB.discordAsked
end
local function askKey(name)
  local full = ns.fullName(name)
  return full and ns.shortName(full)
end

-- One line under WoW's 255: the invite without https:// (WoW can't open links anyway) and how to /link. Never
-- "/link <name>" as one line: typed in one go, Discord drops the name and /link runs empty (8 Nov 2026: 3 of 4 first
-- links failed that way). A plain /link + Enter opens the Link form (bot #348), prefilled when their Discord name matches.
function ns.DiscordAskText(name)
  local url = ns.Invite and ns.Invite()
  if not url or not name then return nil end
  -- Discord is optional (Louis, 8 Nov 2026): the whisper invites, it never says the core of the guild lives there.
  -- A member asked in guild chat (8 Nov 21:48) how to post to guild and Discord at once. Louis validated (21:51):
  -- in game, /discord chats into Discord's #guild-chat (Blizzard's link runs as its own chat, not /g).
  return ("Welcome to Unbothered Warlords, %s! Glad you're here. Our Discord is optional (type /discord in game to "
    .. "chat with it): %s If you join, type "
    .. "/link there, press Enter, and type %s in the box."):format(name:match("^(%S+)") or name,
    (url:gsub("^https://", "")), name)
end

-- Who still needs asking: in the roster, not an officer, not you, never asked, and without UW_Guild (that comes
-- from #addon-kit, so they already found the Discord).
local function toAsk(onlineOnly)
  -- A read: counting who to ask (Lead.lua's button does it often) never creates the table.
  local out, self = {}, ns.me()
  local asked = type(UW_GuildDB.discordAsked) == "table" and UW_GuildDB.discordAsked or {}
  for i = 1, GetNumGuildMembers() or 0 do
    local full, _, _, _, _, _, _, _, online = GetGuildRosterInfo(i)
    local key = askKey(full)
    local m = key and UW_GuildDB.members[key]
    if key and key ~= self and not asked[key] and not ns.isOfficer(key) and not (m and m.addonVer)
      and not ns.quiet(key) and (online or not onlineOnly) then
      out[#out + 1] = key
    end
  end
  table.sort(out)
  return out
end
ns.DiscordToAsk = toAsk -- Lead.lua's "now" button counts who /uw discord ask would reach

local sendChat = (C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage
local function ask(key, delay)
  local text = ns.DiscordAskText(key)
  if not text or ns.quiet(key) then return false end
  askedDB()[key] = time()
  ns.officerSend("DWA\t" .. key, "GUILD")
  C_Timer.After(delay, function() pcall(sendChat, text, "WHISPER", nil, key) end)
  return true
end

-- A join seen by an officer: wait, then ask unless another officer already did (or they're gone, or in combat).
local JOINED = ERR_GUILD_JOIN_S
  and "^" .. ERR_GUILD_JOIN_S:gsub("[%%%(%)%.%+%-%*%?%[%]%^%$]", "%%%0"):gsub("%%%%s", "(.+)") .. "$"
-- A returning member is never asked (stress review, 8 Nov: Donkey Ankle left over the Discord link and got the whisper
-- on rejoining). Returning = the roster knew them RETURN_GAP before this join line; the scan that sees a real newcomer
-- can land before the timer fires, but it stamps first = now, so it never looks old.
ns.DISCORD_ASK_RETURN_GAP = 600
local function returning(key, joinedAt)
  local m = UW_GuildDB.members and UW_GuildDB.members[key]
  return m ~= nil and type(m.first) == "number" and m.first < joinedAt - ns.DISCORD_ASK_RETURN_GAP
end
local function onJoin(name, tries, joinedAt)
  if UW_GuildDB.discordAskOff or not ns.isOfficer(ns.me()) then return end
  local key = askKey(name)
  if not key or key == ns.me() or askedDB()[key] or returning(key, joinedAt) then return end
  if InCombatLockdown() and tries < 10 then
    C_Timer.After(30, function() onJoin(name, tries + 1, joinedAt) end)
    return
  end
  -- New joins only (never the /uw discord ask sweep): the professions ask as its own whisper a moment later, so each
  -- whisper asks one thing and the Discord funnel counts only its own (funnel thread, 8 Nov). Crafts.lua.
  if ask(key, 0) and ns.ProfJoinAsk then ns.ProfJoinAsk(key, ns.PROF_JOIN_DELAY) end
end

ns.handlers.DWA = function(sender, channel, name)
  if channel ~= "GUILD" or not ns.isOfficer(sender) or type(name) ~= "string" or #name > 60 then return end
  local key = askKey(name)
  if key then askedDB()[key] = askedDB()[key] or time() end
end

ns.commands.discord = function(args)
  args = strtrim(args or ""):lower()
  if not ns.isOfficer(ns.me()) then say("Only officers ask guildmates about Discord. Ours: " .. (ns.Invite() or "")) return end
  if args == "off" or args == "on" then
    UW_GuildDB.discordAskOff = args == "off" or nil
    say(args == "off" and "Join whisper off on this account. /uw discord on turns it back on."
      or "Join whisper on: each new guildmate gets one Discord whisper a minute after joining.")
    return
  end
  if args == "ask" then
    local todo = toAsk(true)
    if #todo == 0 then say("Everyone online has been asked already, or has UW_Guild.") return end
    local n = math.min(#todo, ns.DISCORD_ASK_RUN)
    for i = 1, n do ask(todo[i], ns.DISCORD_ASK_GAP * (i - 1)) end
    say(("Whispering %d guildmates about Discord over %d s, once each."):format(n, ns.DISCORD_ASK_GAP * n)
      .. (#todo > n and (" %d more online: /uw discord ask again after."):format(#todo - n) or ""))
    return
  end
  local asked = 0
  for _ in pairs(askedDB()) do asked = asked + 1 end
  say(("Discord asks: %d sent, %d guildmates still to ask, %d online now. Join whisper is %s."):format(asked,
    #toAsk(false), #toAsk(true), UW_GuildDB.discordAskOff and "off" or "on"))
  say("/uw discord ask whispers those online now (once each); /uw discord off stops the join whisper.")
end

local askFrame = CreateFrame("Frame")
askFrame:RegisterEvent("CHAT_MSG_SYSTEM")
askFrame:SetScript("OnEvent", function(_, _, msg)
  if not (UW_GuildDB and JOINED) or type(msg) ~= "string" or ns.isSecret(msg) then return end
  local who = msg:match(JOINED)
  if who then who = who:gsub("|Hplayer:[^|]*|h%[?([^%]|]*)%]?|h", "%1") end -- a clickable name, if the client sends one
  if who and who ~= "" then
    local at = time()
    -- A rejoin gets a person's hello, never an automatic whisper (Louis, 8 Nov: no auto-whisper). Officers only.
    local key = askKey(who)
    if key and key ~= ns.me() and ns.isOfficer(ns.me()) and returning(key, at) then
      say(("%s is back in the guild. Say hi? A hello from you beats anything automatic."):format(key))
    end
    C_Timer.After(ns.DISCORD_ASK_DELAY + math.random() * 30, function() onJoin(who, 0, at) end)
  end
end)

-- Who invited whom (Louis, 8 Nov 2026: "see who invites who ... I want to reward recruiters") ----------------------
-- The game names a recruiter in one place: the guild event log ("X invited Y"), which keeps only recent entries. So
-- each login, and a few seconds after each "has joined the guild" line, this copies the log's invites into
-- UW_GuildDB.invites[recruit] = { { by, at }, ... }: up to INVITES_PER_RECRUIT invites, newest kept, one per inviter
-- (an invite read again is the same one; the log's time is "N hours ago", so `at` moves by up to an hour between
-- reads). Every invite is kept, not a pick: a declined invite before the accepted one is the bot's call
-- (bot/uwbot/recruiters.py credits the last invite before the roster first saw them, and only a recruit who stayed
-- 7 days or linked Discord). A client without the log still records its own invites ("You have invited X").
-- Read only: nothing is sent, whispered or posted. UW_GuildDB.inviteLog says what the last read found (the
-- launch check reads it after a deploy: api false = this client has no event log).
ns.INVITES_PER_RECRUIT, ns.INVITES_MAX = 3, 3000
local HOUR = 3600
local function invitesDB()
  UW_GuildDB.invites = type(UW_GuildDB.invites) == "table" and UW_GuildDB.invites or {}
  return UW_GuildDB.invites
end
local function plainNum(v) return type(v) == "number" and not ns.isSecret(v) and v >= 0 and v or 0 end
-- recruit and by as any spelling the game gives; at = when (time()). True when it was new.
function ns.NoteInvite(recruit, by, at)
  if type(at) ~= "number" or ns.isSecret(at) then return false end
  recruit, by = askKey(recruit), askKey(by)
  if not recruit or not by or recruit == by then return false end
  local db = invitesDB()
  local list = db[recruit]
  if type(list) ~= "table" then
    local n = 0
    for _ in pairs(db) do n = n + 1 if n >= ns.INVITES_MAX then return false end end
    list = {}
    db[recruit] = list
  end
  for _, e in ipairs(list) do
    if type(e) == "table" and e.by == by then
      -- The same invite read again lands within the log's hour; a re-invite later is newer news for the bot.
      if math.abs((tonumber(e.at) or 0) - at) <= 2 * HOUR then
        e.at = math.min(tonumber(e.at) or at, at)
        return false
      end
      if at > (tonumber(e.at) or 0) then e.at = at return true end
      return false
    end
  end
  list[#list + 1] = { by = by, at = math.floor(at) }
  table.sort(list, function(a, b) return (tonumber(a.at) or 0) > (tonumber(b.at) or 0) end)
  while #list > ns.INVITES_PER_RECRUIT do table.remove(list) end
  return true
end
-- Copy the invites in the event log the server last sent. Returns how many were new.
function ns.ReadInviteLog()
  if not (UW_GuildDB and ns.tracksGuild()) then return 0 end
  local count, info = GetNumGuildEvents, GetGuildEventInfo
  local status = { at = time(), api = type(count) == "function" and type(info) == "function" }
  UW_GuildDB.inviteLog = status
  if not status.api then return 0 end
  local ok, n = pcall(count)
  n = ok and plainNum(n) or 0
  local now, seen, new = time(), 0, 0
  for i = 1, math.min(n, 500) do
    local okI, kind, p1, p2, _, y, mo, d, h = pcall(info, i)
    if okI and kind == "invite" and not ns.isSecret(kind) then
      seen = seen + 1
      local ago = ((plainNum(y) * 365 + plainNum(mo) * 30 + plainNum(d)) * 24 + plainNum(h)) * HOUR
      if ns.NoteInvite(p2, p1, now - ago) then new = new + 1 end
    end
  end
  status.read, status.invites, status.new = n, seen, new
  return new
end
local INVITED = ERR_GUILD_INVITE_S
  and "^" .. ERR_GUILD_INVITE_S:gsub("[%%%(%)%.%+%-%*%?%[%]%^%$]", "%%%0"):gsub("%%%%s", "(.+)") .. "$"
local logFrame = CreateFrame("Frame")
do -- only events this client has (RegisterEvent throws on an unknown one; ns.listen loads later, in Crafts.lua)
  local valid = C_EventUtils and C_EventUtils.IsEventValid
  for _, e in ipairs({ "GUILD_EVENT_LOG_UPDATE", "CHAT_MSG_SYSTEM" }) do
    if not valid or valid(e) then pcall(logFrame.RegisterEvent, logFrame, e) end
  end
end
local function askLog() if type(QueryGuildEventLog) == "function" then pcall(QueryGuildEventLog) end end
logFrame:SetScript("OnEvent", function(_, event, msg)
  if not UW_GuildDB then return end
  if event == "GUILD_EVENT_LOG_UPDATE" then ns.protect(ns.ReadInviteLog) return end
  if type(msg) ~= "string" or ns.isSecret(msg) then return end
  local who = INVITED and msg:match(INVITED)
  if who and ns.tracksGuild() then
    ns.NoteInvite(who:gsub("|Hplayer:[^|]*|h%[?([^%]|]*)%]?|h", "%1"), ns.me(), time())
  elseif JOINED and msg:match(JOINED) then
    C_Timer.After(5, askLog) -- the invite is in the log by now; read it before a busy night pushes it out
  end
end)
-- At login, once the roster is known (tracksGuild needs it). ReadInviteLog also runs now, so a client whose
-- QueryGuildEventLog never answers still records what it can (its status says api true, read 0).
table.insert(ns.onLoad, function()
  ns.afterRoster(function() askLog(); C_Timer.After(10, function() ns.protect(ns.ReadInviteLog) end) end)
end)

-- Whisper words ---------------------------------------------------------------------
-- Most of the guild plays without UW_Guild or Discord (8 Nov 2026: 137 of 149), so whispering an officer is their
-- only way in. Next to "raid" (Charter.lua) and "clear note" (Crafts.lua), an officer's UW_Guild answers:
--   help          one line naming every whisper word
--   idea <text>   (or feedback, suggestion, bug) to the officers: the Guild Master's save carries it to #officer-chat
--   stop | start  no more automatic whispers from any officer's UW_Guild (Discord ask, professions ask and nudge,
--                 charter, Raider welcome), and back on. Replies to a member's own whisper still answer.
-- Pull only: nothing is said unless a member whispers first. Each answer says where the words go (CONTRIBUTING.md,
-- "Never quietly turn chat into data"). An idea never goes out on GUILD, which every UW_Guild hears: the officer who
-- got it whispers it to the Guild Master's client (IDA). Officers share "stop" as QWS and catch up at login (QWQ/QWL).
ns.IDEA_MAX, ns.IDEA_PER_DAY, ns.QUIET_SHARE = 200, 3, 40
local IDEA = { idea = true, ideas = true, feedback = true, suggestion = true, suggest = true, bug = true }
local function words(msg)
  if type(msg) ~= "string" or ns.isSecret(msg) or #msg > 255 then return nil end
  local first, rest = strtrim(msg):match("^(%S+)%s*(.-)$")
  if not first then return nil end
  return first:lower():gsub("[%p]+$", ""), rest
end
-- The word a whisper starts with when it is one of ours ("help", "idea", "stop", "start"), else nil. Crafts.lua asks
-- first, so "idea mining night" never reads as a professions reply.
function ns.WhisperWord(msg)
  local w, rest = words(msg)
  if not w then return nil end
  if IDEA[w] then return "idea" end
  if rest == "" and (w == "help" or w == "stop" or w == "start") then return w end
  return nil
end

local function quietDB()
  UW_GuildDB.quiet = type(UW_GuildDB.quiet) == "table" and UW_GuildDB.quiet or {}
  return UW_GuildDB.quiet
end
-- True when this guildmate whispered "stop": every automatic whisper checks it first.
function ns.quiet(name)
  local key = name and askKey(name)
  return key ~= nil and UW_GuildDB ~= nil and type(UW_GuildDB.quiet) == "table" and UW_GuildDB.quiet[key] ~= nil
end
local function setQuiet(key, on, at)
  local q = quietDB()
  if on then q[key] = q[key] or at else q[key] = nil end
end

local function guildMaster()
  for i = 1, GetNumGuildMembers() or 0 do
    local full, _, rank = GetGuildRosterInfo(i)
    if rank == 0 and full then return ns.fullName(full) end
  end
end
local function isGM()
  if IsGuildLeader then return IsGuildLeader() == true end
  return guildMaster() == ns.me()
end
local function keepIdea(name, text)
  if ns.queue then ns.queue("idea", name, text) end
  say(("Idea from %s, kept for #officer-chat: %s"):format(name, text))
end

ns.HELP_WHISPER = "Hey! Happy to help with a dungeon group, quests or professions, just ask. Whisper idea plus your "
  .. "idea, clear note, or stop to pause my addon's whispers. Keen on raids later? Whisper raid."
local lastWord, ideasToday = {}, {}
local function answer(to, msg) pcall(sendChat, msg, "WHISPER", nil, to) end

function ns.WhisperWords(msg, sender)
  local self = ns.me()
  if not (self and ns.isOfficer(self)) or type(sender) ~= "string" or ns.isSecret(sender) then return false end
  local w = ns.WhisperWord(msg)
  if not w or not ns.inRoster(sender) then return false end
  local key, at = askKey(sender), serverNow()
  if not key or key == ns.shortName(self) then return false end
  if lastWord[key] and at - lastWord[key] < 5 then return true end
  lastWord[key] = at
  local first = key:match("^(%S+)") or key
  if w == "help" then
    answer(sender, ns.HELP_WHISPER)
  elseif w == "stop" or w == "start" then
    setQuiet(key, w == "stop", at)
    ns.officerSend(("QWS\t%s\t%s\t%d"):format(key, w == "stop" and "1" or "0", at), "GUILD")
    say(("%s whispered %s: UW_Guild's automatic whispers to them are %s."):format(key, w, w == "stop" and "off" or "on"))
    answer(sender, w == "stop"
      and ("Done, %s: no more automatic whispers from my addon. Whisper start to undo."):format(first)
      or "You're back on. Whisper stop anytime.")
  else
    local text = strtrim((select(2, words(msg))))
    if #text < 3 then
      answer(sender, "Whisper idea plus your idea in one line, like: idea a fishing night on Sundays")
      return true
    end
    local day = date("!%Y-%m-%d", at)
    local n = ideasToday[key] and ideasToday[key].day == day and ideasToday[key].n or 0
    if n >= ns.IDEA_PER_DAY then
      answer(sender, "Got it, thanks! That's a lot for one day, so this one stays with me.")
      return true
    end
    ideasToday[key] = { day = day, n = n + 1 }
    text = text:sub(1, ns.IDEA_MAX)
    if isGM() then
      keepIdea(key, text)
    else
      say(("Idea from %s: %s"):format(key, text))
      local gm = guildMaster()
      local head = ("IDA\t%s\t%d\t"):format(key, at)
      if gm then ns.officerSend(head .. text:gsub("\t", " "):sub(1, 250 - #head), "WHISPER", gm) end
    end
    answer(sender, ("Thanks %s! Sharing it with the officers, with your name so we can follow up."):format(first))
  end
  return true
end

ns.handlers.IDA = function(sender, channel, name, at, text)
  if channel ~= "WHISPER" or not ns.isOfficer(sender) or not isGM() then return end
  at = tonumber(at)
  if type(name) ~= "string" or #name > 60 or not ns.inRoster(name) or not at or type(text) ~= "string" then return end
  text = strtrim(text):sub(1, ns.IDEA_MAX)
  if #text >= 3 then keepIdea(askKey(name) or name, text) end
end
ns.handlers.QWS = function(sender, channel, name, on, at)
  if channel ~= "GUILD" or not ns.isOfficer(sender) or ns.fullName(sender) == ns.me() then return end
  local key = type(name) == "string" and #name <= 60 and askKey(name)
  if key then setQuiet(key, on == "1", tonumber(at) or time()) end
end
-- An officer logging in asks the others for their "stop" list (QWQ); each answers with up to QUIET_SHARE names.
ns.handlers.QWQ = function(sender, channel)
  if channel ~= "GUILD" or not ns.isOfficer(sender) or ns.fullName(sender) == ns.me() or not ns.isOfficer(ns.me()) then
    return
  end
  local names = {}
  for k in pairs(quietDB()) do
    if #names >= ns.QUIET_SHARE then break end
    names[#names + 1] = k
  end
  if #names > 0 then
    table.sort(names)
    ns.catchUpSend("QWL\t" .. table.concat(names, ","), "WHISPER", ns.fullName(sender) or sender)
  end
end
ns.handlers.QWL = function(sender, channel, list)
  if channel ~= "WHISPER" or not ns.isOfficer(sender) or type(list) ~= "string" then return end
  for name in list:gmatch("[^,]+") do
    local key = #name <= 60 and askKey(name)
    if key then setQuiet(key, true, time()) end
  end
end

local wordFrame = CreateFrame("Frame")
do -- as ns.listen (defined later, in Crafts.lua): a client without the event must not stop this file
  local valid = C_EventUtils and C_EventUtils.IsEventValid
  if not valid or valid("CHAT_MSG_WHISPER") then pcall(wordFrame.RegisterEvent, wordFrame, "CHAT_MSG_WHISPER") end
end
wordFrame:SetScript("OnEvent", function(_, _, msg, sender)
  if UW_GuildDB then ns.protect(ns.WhisperWords, msg, sender) end
end)

-- First guild group -----------------------------------------------------------
-- Each member's client announces its first group with a guildmate as GRP\t<server time of that group>,
-- then again on every login, and whenever an officer logs in and asks (GRPQ), for GRP_RESEND_DAYS.
-- Whoever runs the bridge then records it even if they were offline when it happened. Receivers keep
-- the earliest time, for the "grouped within 72h" retention metric.
local function guildmatesInGroup()
  local n, count = GetNumGroupMembers(), 0
  local prefix = IsInRaid() and "raid" or "party"
  local last = IsInRaid() and n or n - 1
  for i = 1, last do
    local unit = prefix .. i
    if not UnitIsUnit(unit, "player") and UnitIsInMyGuild(unit) then count = count + 1 end
  end
  return count
end

-- Sends GRP while the first group is recent. True when it was sent.
local function announceGroup()
  local t = UW_GuildCharDB.firstGuildGroup
  if not t or not IsInGuild() or serverNow() - t > ns.GRP_RESEND_DAYS * 86400 then return false end
  return ns.send("GRP\t" .. t, "GUILD")
end

local function checkFirstGroup()
  local c = UW_GuildCharDB
  if c.groupAnnounced or not IsInGuild() or not IsInGroup() then return end
  if guildmatesInGroup() == 0 then return end
  c.firstGuildGroup = c.firstGuildGroup or serverNow()
  if announceGroup() then c.groupAnnounced = true end -- retried on the next roster change if blocked
end

-- GUILD at the group and on login; WHISPER in answer to our GRPQ, so only guildmates in the roster count.
ns.handlers.GRP = function(sender, channel, at)
  if channel ~= "GUILD" and not (channel == "WHISPER" and ns.inRoster(sender)) then return end
  if not ns.tracksGuild() then return end -- an alt's other guild isn't ours
  sender = ns.shortName(sender)
  local m = UW_GuildDB.members[sender]
  if not m then return end
  -- Older clients send a bare GRP: that means "just now". So does a time from a badly set clock. The time
  -- is the realm's, so it is checked against the realm's clock, not this PC's.
  local now, t = serverNow(), ns.finite(at) -- "nan" would otherwise slip past both bounds below
  if not t or t > now + 600 or t < now - (ns.GRP_RESEND_DAYS + 1) * 86400 then t = now end
  t = math.floor(t)
  local isNew = not m.firstGroup
  if isNew or t < m.firstGroup then m.firstGroup = t end
  -- Veterans also announce after installing; only recruits' first groups are news. Repeats aren't.
  if isNew and ns.isRecruit(sender) then ns.queue("group", sender) end
end

-- An officer logging in asks recent first groups to speak up; each client answers at most every 5 min.
-- The answer is whispered to that officer: at launch nearly everyone grouped this week, and a GUILD answer
-- would send every member's reply to every client. Anyone else online then heard it when it was new.
local lastGroupReply -- nil, not 0: GetTime() counts from PC boot, so 0 would ignore GRPQs for 5 minutes
ns.handlers.GRPQ = function(sender, channel)
  if channel ~= "GUILD" or not ns.isOfficer(sender) then return end
  if lastGroupReply and GetTime() - lastGroupReply < 300 then return end
  local t = UW_GuildCharDB.firstGuildGroup
  if not t or serverNow() - t > ns.GRP_RESEND_DAYS * 86400 then return end
  lastGroupReply = GetTime()
  C_Timer.After(1 + math.random() * 4, function() ns.send("GRP\t" .. t, "WHISPER", sender) end) -- jitter
end

-- HI\tversion on login: lets every client see who runs UW_Guild (Core records members[name].addon).
-- A newer UW_Guild: versions are the UTC date and time of the addon's last change, then its commit
-- (2026.11.08.1446-2036369, bot addonzip.py; builds before 8 Nov 2026 had no time: 2026.11.03-36e763f). A guildmate's
-- login HI with a later one means ours is out of date (after a break, or a missed update). The time orders the
-- several builds of one day; clients from before it compare the date only. Told once a session, and only once two
-- guildmates run a newer one: the officer PC runs each deploy before the download page has it, so one alone would
-- send members to a page that still has their version. A date more than a day past the realm's today is ignored, and
-- so is a dev build. /uw version shows ours and the newest seen.
local function versionKey(v)
  local y, m, d = tostring(v or ""):match("^(%d%d%d%d)%.(%d%d)%.(%d%d)")
  if not y then return nil end
  local hm = tostring(v):match("^%d%d%d%d%.%d%d%.%d%d%.(%d%d%d%d)%-") or "0000"
  return tonumber(y .. m .. d) * 10000 + tonumber(hm), tonumber(y .. m .. d)
end
-- The Windows one-button setup (site/UW-Guild-Setup.cmd) writes "## X-UW-Updater: <date>" into the TOC it installs:
-- that copy updates itself while WoW is closed, so its members never need a link.
local function hasUpdater()
  local v = C_AddOns.GetAddOnMetadata("UW_Guild", "X-UW-Updater")
  return type(v) == "string" and v:match("^%d") ~= nil
end
ns.hasUpdater = hasUpdater
local STUCK_DAYS = 3
local newerTold = false
local newestSeen, newestFrom
local newerFrom, newerCount = {}, 0
local function noteNewer(ver, sender)
  local theirs, theirDay = versionKey(ver)
  local ours = versionKey(ns.VERSION)
  if not (theirs and ours) or theirs <= ours then return end
  local today = date and tonumber(date("!%Y%m%d", (GetServerTime and GetServerTime() or time()) + 86400))
  if today and theirDay > today then return end
  if not newestSeen or theirs > versionKey(newestSeen) then newestSeen, newestFrom = ver, sender end
  if sender and not newerFrom[sender] then newerFrom[sender], newerCount = true, newerCount + 1 end
  if newerTold or newerCount < 2 then return end
  newerTold = true
  local v = newestSeen:match("^[%d%.]+")
  -- How long this build has known it's behind, not how old it is: a member back from a break starts WoW before the
  -- updater's catch-up run can install, and that's healthy (hardening, 8 Nov 2026). Reset with each new build.
  local since = UW_GuildDB.newerSince
  if type(since) ~= "table" or since.ver ~= ns.VERSION then
    since = { ver = ns.VERSION, at = time() }
    UW_GuildDB.newerSince = since
  end
  if hasUpdater() and time() - (tonumber(since.at) or time()) >= STUCK_DAYS * 86400 then
    -- Days of closed-WoW time without an install means it stopped (a new site key, a moved WoW folder): the one
    -- thing that fixes it is running the setup again.
    say(("Your automatic updates look stuck (UW_Guild %s is out). Run the setup again from %s"):format(v,
      ns.ADDON_URL))
  elseif hasUpdater() then
    say(("A newer UW_Guild (%s) is out. It installs itself the next time WoW is closed."):format(v))
  else
    say(("A newer UW_Guild (%s) is out. One button installs it and every update after: %s"):format(v, ns.ADDON_URL))
  end
end

-- Members on a hand install (the zip) hear once a week, three times at most, that one button would keep them current
-- (Louis, 8 Nov 2026: one button to install and update, minimal asks). Never on a Mac (the setup is Windows only),
-- the officer PC (the bot installs every build there), an unstamped copy, or a fresh install's first day.
local NUDGE_MAX, NUDGE_GAP = 3, 7 * 86400
local function updaterNudge()
  if hasUpdater() or ns.VERSION == "dev" then return end
  if IsMacClient and IsMacClient() then return end
  if ns.SyncBotPC and ns.SyncBotPC() then return end
  local now = time()
  local at = tonumber(UW_GuildDB.installedAt) or 0
  if at > 0 and now - at < 86400 then return end
  local n = type(UW_GuildDB.updaterNudge) == "table" and UW_GuildDB.updaterNudge or {}
  local count = tonumber(n.count) or 0
  if count >= NUDGE_MAX or now - (tonumber(n.at) or 0) < NUDGE_GAP then return end
  UW_GuildDB.updaterNudge = { count = count + 1, at = now }
  say(("Skip manual updates: %s, Install for Windows. One click, then UW_Guild updates itself."):format(
    ns.ADDON_URL))
end
ns.updaterNudge = updaterNudge

ns.handlers.HI = function(sender, channel, ver)
  if channel ~= "GUILD" or not ns.tracksGuild() then return end
  local m = UW_GuildDB.members[ns.shortName(sender)]
  if type(ver) == "string" then
    ver = ver:gsub("[^%w%.%-]", ""):sub(1, 24)
    if m then m.addonVer = ver end
    noteNewer(ver, ns.shortName(sender))
  end
end

-- /uw version: which UW_Guild this is, so a member can match it against the download page's "Latest version".
ns.commands.version = function()
  say(("UW_Guild %s. The newest is on %s: if its version matches this one, you're up to date."):format(
    ns.VERSION, ns.ADDON_URL))
  if hasUpdater() then say("Automatic updates: on (it installs new versions while WoW is closed).") end
  if newestSeen then
    say(("%s runs a newer one (%s) this session: download it again from that page."):format(
      newestFrom or "A guildmate", newestSeen))
  end
end

-- Welcome back: a player logging in after two weeks or more away gets one line: whether the addon kit needs
-- updates after the break, and what /uw-me in Discord shows (a break set there ends with its I'm back button).
-- UW_GuildDB.lastOn is this WoW account's last login in our guild, on any character, so an alt that sat idle while
-- its main played says nothing. A fresh install has none, so it says nothing either.
function ns.WelcomeBack(now)
  local last = ns.finite(UW_GuildDB.lastOn)
  UW_GuildDB.lastOn = now
  if not last or now - last < ns.RETURN_DAYS * 86400 then return end
  local missReq, _, conflicts = ns.CheckKit()
  local fixes = #missReq + #conflicts
  local kit = fixes == 0 and "Your addon kit is ready."
    or ("/uw kit shows %d addon fix%s."):format(fixes, fixes == 1 and "" or "es")
  say(("Welcome back after %d days! %s In Discord, /uw-me shows your next rank, and I'm back ends a break.")
    :format(math.floor((now - last) / 86400), kit))
end

-- /uw near --------------------------------------------------------------------
ns.commands.near = function()
  if not IsInGuild() then say("Join Unbothered Warlords to see guildmates near your level.") return end
  local myLevel, self, rows = UnitLevel("player"), me(), {}
  for i = 1, GetNumGuildMembers() do
    local full, _, _, level, _, zone, _, _, online = GetGuildRosterInfo(i)
    if online and full and level then
      local name = Ambiguate(full, "none")
      if name ~= self and math.abs(level - myLevel) <= ns.NEAR_RANGE then
        rows[#rows + 1] = { full = full, name = name, level = level, zone = zone or "?" }
      end
    end
  end
  if #rows == 0 then say(("No guildmates online within %d levels. Ask in guild chat, or #lfg-dungeons on Discord."):format(ns.NEAR_RANGE)) return end
  table.sort(rows, function(a, b)
    local da, db = math.abs(a.level - myLevel), math.abs(b.level - myLevel)
    if da ~= db then return da < db end
    return a.name < b.name
  end)
  say(("%d guildmate(s) near level %d. Click a name to whisper or invite:"):format(#rows, myLevel))
  for i = 1, math.min(#rows, 15) do
    local r = rows[i]
    say(("|Hplayer:%s|h[%s]|h  lvl %d  %s"):format(r.full, r.name, r.level, r.zone))
  end
end

-- Welcome panel ---------------------------------------------------------------
local panel

local function welcomeText()
  local lines = { ("|cffffd100Our norms|r  |cff808080%s|r"):format(table.concat(ns.VALUES, " · ")) }
  for _, n in ipairs(ns.NORMS) do lines[#lines + 1] = ("%d. %s"):format(n[1], n[2]) end
  -- Numbered as in Discord, so the gaps are the Discord-only norms: say so, or 1, 2, 4 reads like a bug (journey sim).
  lines[#lines + 1] = ("|cff808080The ones for in game. Numbers match #welcome-rules in Discord, which has all %d.|r")
    :format(ns.NORMS_TOTAL)
  lines[#lines + 1] = ns.FREE_HELP
  lines[#lines + 1] = " "
  local pair = UW_GuildDB.buddies[me()]
  if pair then
    lines[#lines + 1] = ("|cffffd100Your buddy:|r %s. Whisper them to group up."):format(pair.buddy)
  elseif ns.isRecruit(me()) or (UW_GuildCharDB.recruitAt and ns.isLowestRank(me())) then -- not once promoted
    lines[#lines + 1] = "|cffffd100Your buddy:|r an officer will pair you soon."
  elseif ns.isLowestRank(me()) then -- new invites land here, but so do social members: speak to both
    lines[#lines + 1] = "|cffffd100New here?|r An officer will pair you with a buddy soon. Been around a while? Tell an officer if you'd like to mentor a recruit."
  else
    lines[#lines + 1] = "|cffffd100Mentor a recruit?|r Tell an officer and they'll pair you up."
  end
  -- A first-timer reads this before any chat line: name what to add, softly, and where everything lives.
  local missReq, _, conflicts = ns.CheckKit()
  if #missReq + #conflicts == 0 then
    lines[#lines + 1] = "|cff40ff40Addon kit OK.|r"
  elseif #missReq > 0 then
    lines[#lines + 1] = ("|cffffd100Addons to add:|r %s. /uw kit shows how."):format(table.concat(missReq, ", "))
  else
    lines[#lines + 1] = ("|cffff4040Addon kit:|r %d duplicate. Type /uw kit."):format(#conflicts)
  end
  lines[#lines + 1] = "|cffffd100This addon:|r /uw options, or UW in the minimap's addon menu."
  lines[#lines + 1] = ("|cffffd100Guild Master:|r BattleTag %s (Steam: /uw contact)"):format(ns.GM_BATTLETAG)
  lines[#lines + 1] = " "
  -- Discord is optional (Louis, 8 Nov 2026); linking there joins your character to raid signups and /uw-me. The
  -- /link steps as the join whisper gives them (DiscordAskText): never "/link <name>" typed in one go.
  lines[#lines + 1] = ns.Invite()
    and ("|cffffd100Discord (optional):|r type /link there, press Enter, then %s in the box. Invite (click, Ctrl+C):")
      :format(me())
    or "|cffffd100Discord (optional):|r ask an officer for the invite."
  return table.concat(lines, "\n")
end
ns.welcomeText = welcomeText

local function buildPanel()
  local ok, f = pcall(CreateFrame, "Frame", "UW_GuildWelcome", UIParent, "BasicFrameTemplateWithInset")
  if not ok or not f then f = CreateFrame("Frame", "UW_GuildWelcome", UIParent, "BackdropTemplate") end
  f:SetSize(440, 535) -- room for the norms, the buddy and kit lines, and the invite box above the buttons
  f:SetPoint("CENTER")
  f:SetFrameStrata("DIALOG")
  f:SetMovable(true)
  f:EnableMouse(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  tinsert(UISpecialFrames, "UW_GuildWelcome") -- Esc closes it
  ns.SkinWindow(f) -- EllesmereUI's look when it's installed (Skin.lua)

  local title = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  title:SetPoint("TOP", 0, -6)
  title:SetText("Welcome to Unbothered Warlords")
  ns.Skin("Font", title)

  -- Guild art: the campfire camp as a header, the shield emblem overlapping its corner.
  local header = f:CreateTexture(nil, "ARTWORK")
  header:SetTexture(MEDIA .. "header")
  header:SetTexCoord(0, 1, 0, 171 / 256) -- art fills the top 512x171 of a 512x256 canvas
  header:SetSize(408, 136)
  header:SetPoint("TOP", 0, -28)
  local emblem = f:CreateTexture(nil, "OVERLAY")
  emblem:SetTexture(MEDIA .. "emblem")
  emblem:SetSize(76, 76)
  emblem:SetPoint("BOTTOMLEFT", header, "BOTTOMLEFT", -6, -26)

  local tag = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  tag:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 76, -6)
  tag:SetPoint("RIGHT", f, "RIGHT", -16, 0)
  tag:SetJustifyH("LEFT")
  tag:SetText(ns.TAGLINE)
  local sub = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  sub:SetPoint("TOPLEFT", tag, "BOTTOMLEFT", 0, -2)
  sub:SetText(ns.SUBTAGLINE)

  f.body = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightLeft")
  f.body:SetPoint("TOPLEFT", 18, -214)
  f.body:SetWidth(404)
  f.body:SetJustifyH("LEFT")
  f.body:SetSpacing(3)

  -- WoW can't open links, so the invite sits in a read-only box for copying.
  f.link = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
  f.link:SetSize(300, 20)
  f.link:SetPoint("TOPLEFT", f.body, "BOTTOMLEFT", 6, -6) -- sits right under the "Discord" line
  f.link:SetAutoFocus(false)
  f.link:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
  f.link:SetScript("OnTextChanged", function(self, user)
    if user then self:SetText(ns.Invite() or "") self:HighlightText() end
  end)
  ns.Skin("EditBox", f.link)

  local near = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
  near:SetSize(150, 24)
  near:SetPoint("BOTTOMLEFT", 16, 14)
  near:SetText("Find guildmates")
  near:SetScript("OnClick", function() ns.commands.near() end)
  ns.useButton(near, "welcome find guildmates")
  ns.Skin("Button", near)

  local done = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
  done:SetSize(120, 24)
  done:SetPoint("BOTTOMRIGHT", -16, 14)
  done:SetText("Got it")
  done:SetScript("OnClick", function()
    UW_GuildCharDB.welcomed = time()
    UW_GuildDB.welcomed = UW_GuildDB.welcomed or time() -- someone on this account has read it
    f:Hide()
  end)
  ns.useButton(done, "welcome got it")
  ns.Skin("Button", done)
  return f
end

function ns.RefreshWelcome()
  if not panel or not panel:IsShown() then return end
  panel.body:SetText(welcomeText())
  -- Grow to fit: a long name, a recruit's buddy line or a missing kit can wrap and push the invite box onto the buttons.
  local ok, h = pcall(panel.body.GetStringHeight, panel.body)
  h = ok and tonumber(h)
  if h then panel:SetHeight(math.max(535, math.ceil(214 + h + 74))) end
  panel.link:SetText(ns.Invite() or "")
  panel.link:SetShown(ns.Invite() ~= nil)
end

local function showWelcome()
  if InCombatLockdown() then return end
  panel = panel or buildPanel()
  panel:Show()
  ns.RefreshWelcome()
end
ns.commands.welcome = showWelcome

-- Opens by itself at most once per character, and an alt of a player who already read it on this
-- account gets it at most once per account-day. /uw welcome reopens it any time.
local welcomeAfterCombat = false
local function autoWelcome()
  local c, db = UW_GuildCharDB, UW_GuildDB
  if c.welcomed or c.welcomeShown then return end
  if InCombatLockdown() then welcomeAfterCombat = true return end -- a fight at login: shown once it ends
  if not ns.inOurGuild() then return end -- an alt in some other guild: not ours to welcome
  local day = math.floor(time() / 86400)
  if db.welcomed and db.welcomeAutoDay == day then return end
  c.welcomeShown, db.welcomeAutoDay = time(), day
  showWelcome()
end

-- Wiring ----------------------------------------------------------------------
local f = CreateFrame("Frame")
f:RegisterEvent("GROUP_ROSTER_UPDATE")
f:RegisterEvent("PLAYER_REGEN_ENABLED")
f:SetScript("OnEvent", function(_, event)
  if event == "PLAYER_REGEN_ENABLED" then
    if welcomeAfterCombat then welcomeAfterCombat = false; C_Timer.After(3, autoWelcome) end
  elseif UW_GuildCharDB then
    checkFirstGroup()
  end
end)

table.insert(ns.onLoad, function()
  UW_GuildDB.buddies = UW_GuildDB.buddies or {}
  UW_GuildCharDB = UW_GuildCharDB or {}
end)

-- Runs once per session, when the character is first seen in a guild: at login, or on joining mid-session
-- (Core calls ns.onGuildJoin when IsInGuild() turns true).
table.insert(ns.onGuildJoin, function()
  C_Timer.After(12, autoWelcome)
  -- Ask only after our own roster is read, or the officer's reply would fail the officer check.
  ns.afterRoster(function()
    if ns.RefreshWelcome then ns.RefreshWelcome() end -- the rank decides the buddy line
    if not ns.tracksGuild() then return end -- an alt in another guild has nothing to ask ours
    ns.WelcomeBack(time())
    ns.send("HI\t" .. ns.VERSION, "GUILD")
    C_Timer.After(25, updaterNudge)
    if not UW_GuildDB.buddies[me()] then ns.send("BUDQ", "GUILD") end
    ns.send(UW_GuildDB.invite and ("INVQ\t" .. (UW_GuildDB.inviteAt or 0)) or "INVQ", "GUILD")
    announceGroup()
    if ns.isOfficer(me()) then ns.send("GRPQ", "GUILD"); ns.send("QWQ", "GUILD") end
  end)
end)
