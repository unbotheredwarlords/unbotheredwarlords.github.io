-- Rallies and raid nights in the game (addon-value item 1, Louis 5 Nov 2026). Until now, information only flowed from
-- the game to Discord, so someone levelling never heard that a Rally or a raid night was about to start.
--   * The UW bot writes the next ones into Schedule.lua on the Guild Master's PC (bot/uwbot/gamesched.py). It is read
--     at login or /reload and kept in UW_GuildDB.schedule.
--   * Officers' clients share it on the guild channel: once after login, and when a guildmate's client asks for it
--     at login. A copy is only taken from an officer, only when it is newer than the one held, and never dated ahead.
--     Counts only, never names.
--   * One login line names what's on in the next 24 hours plus the next raid night. A heads-up comes 10 minutes before
--     each: a reminder at the moment of action raises turnout (Milkman et al. 2021), and a concrete when-and-where
--     helps people follow through (Gollwitzer & Sheeran 2006). A Rally heads-up is skipped while you're in a group.
--   * /uw events lists them; /uw events off stops the login line and heads-ups, /uw events on brings them back.
-- Limit: as fresh as the last officer login. Rally times are fixed in advance; sign-up counts can lag.
local _, ns = ...
local say = ns.say

local HEADS_UP, AHEAD, DAY = 600, 7 * 86400, 86400
local MAX_EV, TITLE_MAX, SHARE_GAP = 6, 24, 60
local KINDS = { rally = "r", raid = "R", event = "e" }
local FROM = { r = "rally", R = "raid", e = "event" }

local function now() return (GetServerTime and GetServerTime()) or time() end
local function clean(t) return (tostring(t or ""):gsub("[^%w '&:.!?()+/-]", ""):sub(1, TITLE_MAX)) end

-- One event from the file or the wire, checked: { start, stop, kind, going, title }, or nil.
local function event(start, stop, kind, going, title)
  start, stop, going = ns.finite(start), ns.finite(stop), ns.finite(going)
  if not (start and stop and going and KINDS[kind]) or stop <= start then return nil end
  return { math.floor(start), math.floor(stop), kind, math.max(0, math.floor(going)), clean(title) }
end

-- Events that haven't ended and start within a week, soonest first.
local function upcoming(list, at)
  local out = {}
  for _, e in ipairs(type(list) == "table" and list or {}) do
    local ok = type(e) == "table" and event(e[1], e[2], e[3], e[4], e[5])
    if ok and ok[2] > at and ok[1] < at + AHEAD and #out < MAX_EV then out[#out + 1] = ok end
  end
  table.sort(out, function(a, b) return a[1] < b[1] end)
  return out
end

-- The newest schedule this account holds: the file when it's newer than the saved copy.
local function current()
  local held = type(UW_GuildDB.schedule) == "table" and UW_GuildDB.schedule or nil
  local file = type(ns.SCHEDULE) == "table" and ns.SCHEDULE or nil
  local gen = file and ns.finite(file.gen)
  if gen and gen > 0 and gen > (held and ns.finite(held.gen) or 0) and gen <= now() + 600 then
    held = { gen = gen, ev = upcoming(file.ev, now()) }
    UW_GuildDB.schedule = held
  end
  return held
end
ns.ScheduleNow = current

local function when(t, at)
  local d, today = date("*t", t), date("*t", at)
  local day = (d.yday == today.yday and d.year == today.year) and "today" or date("%a", t)
  return day .. " " .. date("%H:%M", t)
end

local function describe(e, at)
  local name = e[3] == "rally" and "Rally" or e[5]
  if e[1] <= at then return name .. " on now" end
  local count = e[4] > 0 and (" (%d %s)"):format(e[4], e[3] == "rally" and "going" or "signed up") or ""
  return name .. " " .. when(e[1], at) .. count
end

-- The login line: what's on in the next 24 hours, plus the next raid night if it's later. Nil when nothing is.
function ns.WhatsOnLine(at)
  local held = current()
  local list = upcoming(held and held.ev, at)
  local parts, raid = {}, false
  for _, e in ipairs(list) do
    if e[1] < at + DAY and #parts < 2 then
      parts[#parts + 1] = describe(e, at)
      raid = raid or e[3] == "raid"
    end
  end
  if not raid then
    for _, e in ipairs(list) do
      if e[3] == "raid" and e[1] >= at + DAY then parts[#parts + 1] = describe(e, at) break end
    end
  end
  if #parts == 0 then return nil end
  return "Coming up: " .. table.concat(parts, "; ") .. ". /uw events lists them."
end

local function quiet() return UW_GuildDB.eventsQuiet == true end

-- Heads-ups, checked every 30 seconds; each event once per session.
local told = {}
function ns.WhatsOnTick(at)
  if quiet() then return end
  local held = current()
  for _, e in ipairs(upcoming(held and held.ev, at)) do
    local key = e[3] .. e[1]
    local left = e[1] - at
    if not told[key] and left > 0 and left <= HEADS_UP then
      told[key] = true
      local mins = math.max(1, math.floor(left / 60 + 0.5))
      if e[3] == "rally" then
        if not IsInGroup() then
          say(("The Rally starts in %d min: pick an activity on its Discord card. Guildmates near your level: /uw near.")
            :format(mins))
        end
      else
        say(("%s starts in %d min (%s). Details are on its Discord card."):format(e[5], mins, date("%H:%M", e[1])))
      end
    end
  end
end

-- Sharing -------------------------------------------------------------------------------------------------------------
local heardAt, lastShared = {}, 0 -- gen -> when any officer's copy of it was last heard on the guild channel
local function heardLately(gen) return (heardAt[gen] or 0) > now() - SHARE_GAP end

local function pack(held)
  local msg = "SCH\t" .. math.floor(held.gen) .. "\t"
  local first = true
  for _, e in ipairs(upcoming(held.ev, now())) do
    local part = ("%d,%d,%s,%d,%s"):format(e[1], e[2] - e[1], KINDS[e[3]], e[4], e[5])
    if #msg + #part + 1 > 250 then break end
    msg = msg .. (first and "" or ";") .. part
    first = false
  end
  return msg
end

local function share()
  local held = current()
  if not (held and ns.finite(held.gen) and held.gen > 0) or not ns.isOfficer(ns.me()) or not ns.inOurGuild() then
    return
  end
  local gen = held.gen
  if now() - lastShared < SHARE_GAP or heardLately(gen) then return end
  lastShared = now()
  ns.relay(pack(held), "GUILD", nil, function() return heardLately(gen) end)
end
ns.ShareSchedule = share

ns.handlers.SCH = function(sender, channel, gen, body)
  gen = ns.finite(gen)
  if channel ~= "GUILD" or not gen or not ns.isOfficer(sender) then return end
  heardAt[gen] = now()
  local held = current()
  if gen <= (held and ns.finite(held.gen) or 0) or gen > now() + 600 then return end
  local list = {}
  for part in tostring(body or ""):gmatch("[^;]+") do
    local start, len, k, going, title = part:match("^(%d+),(%d+),([rRe]),(%d+),(.*)$")
    local e = start and event(start, start + len, FROM[k], going, title)
    if e then list[#list + 1] = e end
  end
  UW_GuildDB.schedule = { gen = gen, ev = upcoming(list, now()) }
end

-- A guildmate logging in asks once; an officer holding a newer copy answers (one answer per minute, guild-wide).
ns.handlers.SCHQ = function(sender, channel, gen)
  if channel ~= "GUILD" or sender == ns.me() then return end
  local held = current()
  if held and ns.finite(held.gen) and held.gen > (ns.finite(gen) or 0) then share() end
end

-- /uw events ----------------------------------------------------------------------------------------------------------
ns.commands.events = function(args)
  local word = strtrim(args or ""):lower()
  if word == "off" or word == "on" then
    UW_GuildDB.eventsQuiet = word == "off" or nil
    say(word == "off" and "No more event lines or heads-ups. /uw events on brings them back."
      or "Event lines and 10-minute heads-ups are on.")
    return
  end
  local at, held = now(), current()
  local list = upcoming(held and held.ev, at)
  if #list == 0 then
    say("Nothing on the guild calendar yet. New events show up here when an officer logs in.")
    return
  end
  for _, e in ipairs(list) do say(describe(e, at)) end
  say(quiet() and "Heads-ups are off: /uw events on." or "A heads-up comes 10 min before each. /uw events off stops them.")
end
ns.WhatsOn = ns.commands.events

local f = CreateFrame("Frame")
ns.listen(f, { "PLAYER_ENTERING_WORLD" })
f:SetScript("OnEvent", ns.guard(function(self, _, isLogin)
  self:UnregisterEvent("PLAYER_ENTERING_WORLD")
  ns.after(10, function()
    if isLogin and not quiet() then
      local ok, line = pcall(ns.WhatsOnLine, now())
      if ok and line then say(line) end
    end
    if IsInGuild() then
      local held = current()
      ns.send("SCHQ\t" .. math.floor(held and ns.finite(held.gen) or 0), "GUILD")
    end
  end)
  ns.after(20 + math.random() * 10, function() ns.protect(share) end)
  C_Timer.NewTicker(30, function() ns.protect(ns.WhatsOnTick, now()) end)
end))
