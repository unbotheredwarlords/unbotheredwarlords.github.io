-- /uw selftest (Louis, 5 Nov 2026): checks UW_Guild on this game client in a few seconds, so a bug shows up before
-- it shows up in play. The Lua tests model the client with stubs; this runs the same code on the real one.
-- Read-only: it calls only functions that look things up (never equip, delete, bind, send or post), runs each check
-- protected, and keeps the last result in UW_GuildDB.selftest, so it can be read from the saved file after /reload.
local _, ns = ...

-- One name each file sets on ns. Missing means that file failed to load on this client.
-- tests/self_test_test.lua fails when a TOC file is missing here.
ns.SELFTEST_FILES = {
  { "Core.lua", "CheckKit" }, { "Outbound.lua", "SENDERS" }, { "KitDoctor.lua", "KitReport" }, { "KitShare.lua", "KitFixPlan" },
  { "KitLook.lua", "KitLookDiff" }, { "MacroLibrary.lua", "MACROS" }, { "Macros.lua", "SpellName" },
  { "Onboarding.lua", "RefreshWelcome" }, { "Cheers.lua", "ReadCheers" }, { "Loot.lua", "StartLoot" },
  { "Crafts.lua", "SearchCrafts" }, { "Bank.lua", "CountBags" }, { "Gear.lua", "RefreshGear" },
  { "Raid.lua", "RecordKill" }, { "Plan.lua", "DecodePlan" }, { "Options.lua", "OpenOptions" },
  { "Skin.lua", "Skin" }, { "Items.lua", "KeepReason" }, { "AutoEquip.lua", "TryGearUpgrade" }, { "QuestItem.lua", "FindQuestItemUse" },
  { "QuestChain.lua", "QuestChain" }, { "Guide.lua", "GuideTarget" }, { "BagRoom.lua", "BagRoomRefresh" }, { "DialogueHold.lua", "WrapDialogueHide" },
  { "SpellBars.lua", "SpellToBars" }, { "Mail.lua", "MailPlan" }, { "Charter.lua", "CharterStatus" }, { "Lead.lua", "Lead" },
  { "Schedule.lua", "SCHEDULE" }, { "WhatsOn.lua", "WhatsOn" }, { "RaidReady.lua", "RaidReadyLine" }, { "Fish.lua", "FishOn" },
  { "Thanks.lua", "GameThanks" }, { "WeekOne.lua", "WeekOneSample" }, { "Sync.lua", "SyncRefresh" }, { "Handbook.lua", "OpenHandbook" },
  { "SelfTest.lua", "SelfTest" },
}
-- Every /uw command the help lists.
ns.SELFTEST_COMMANDS = { "kit", "near", "welcome", "invite", "contact", "loot", "plan", "craft", "bank", "audit",
  "buddy", "leavers", "options", "chain", "guide", "meet", "gear", "space", "bags", "bars", "mail", "ranks", "charter", "lead", "events", "thanks", "rate", "new", "sync", "selftest", "version" }
-- Functions that only look things up; each must run without an error on this client.
local FINDERS = { "FindGearUpgrade", "CheapestJunk", "FindQuestItemUse", "KitFixPlan", "KitFixAllPlan", "CheckKit",
  "KitTroubleCounts", "OptionsStatus", "MailPlan" }
local MAX_LINES, LINE_MAX = 12, 150

local function loaded(name)
  return C_AddOns and C_AddOns.IsAddOnLoaded and select(1, C_AddOns.IsAddOnLoaded(name)) and true or false
end

local CHECKS = {
  { "Files", function()
    local bad = {}
    for _, f in ipairs(ns.SELFTEST_FILES) do if ns[f[2]] == nil then bad[#bad + 1] = f[1] end end
    if #bad > 0 then return "fail", "didn't load: " .. table.concat(bad, ", ") end
    return "ok"
  end },
  { "Commands", function()
    local bad = {}
    for _, c in ipairs(ns.SELFTEST_COMMANDS) do if type(ns.commands[c]) ~= "function" then bad[#bad + 1] = c end end
    if #bad > 0 then return "fail", "missing /uw " .. table.concat(bad, ", ") end
    return "ok"
  end },
  { "Game functions", function()
    local missing = ns.ClientMissing()
    if #missing > 0 then return "fail", "this client lacks " .. table.concat(missing, ", ") end
    return "ok"
  end },
  { "Errors", function()
    local n, first = ns.ownErrors or 0, nil
    for _, e in ipairs(type(UW_GuildDB.errors) == "table" and UW_GuildDB.errors or {}) do
      if type(e) == "table" and e.ver == ns.VERSION then first = first or e.msg end
    end
    if n > 0 or first then return "fail", ("%d this session. %s"):format(n, first or "") end
    return "ok"
  end },
  { "Finders", function()
    local bad = {}
    for _, name in ipairs(FINDERS) do
      local fn = ns[name]
      if type(fn) == "function" then
        local ok, err = pcall(fn)
        if not ok then bad[#bad + 1] = name .. ": " .. tostring(err):gsub("[%c|]", " "):sub(1, 60) end
      end
    end
    if #bad > 0 then return "fail", table.concat(bad, "; ") end
    return "ok"
  end },
  { "Roll text", function()
    local fmt = RANDOM_ROLL_RESULT or "%s rolls %d (%d-%d)"
    local who, roll = fmt:format("Tester", 42, 1, 100):match(ns.RollPattern())
    if who ~= "Tester" or roll ~= "42" then return "fail", "/roll lines aren't read: loot rolls won't count" end
    return "ok"
  end },
  { "Kit", function()
    local missReq, _, conflicts = ns.CheckKit()
    -- /uw kit says where to get them; /uw kit fix can't install anything (render crawl on 112, 13 Nov).
    if #missReq > 0 then return "warn", "missing " .. table.concat(missReq, ", ") .. ". /uw kit shows where to get them." end
    if #conflicts > 0 then return "warn", #conflicts .. " duplicate pair(s). /uw kit fix turns one off." end
    return "ok"
  end },
  { "Quest chains", function()
    if not loaded("Questie") then return "skip", "Questie is off" end
    local p = UW_GuildDB.chainProbe
    if type(p) ~= "table" or not p.lib then return "warn", "Questie's quest data isn't readable: no chain tags" end
    if not p.hooked then return "warn", "Questie's tracker isn't hooked: no chain tags" end
    return "ok"
  end },
  { "Look", function()
    if not loaded("EllesmereUI") then return "skip", "EllesmereUI is off" end
    if not ns.Skinned() then return "warn", "EllesmereUI hasn't skinned UW windows yet" end
    return "ok"
  end },
  { "Version", function()
    if ns.VERSION == "dev" then return "warn", "unstamped (dev): errors can't be tied to a build" end
    return "ok"
  end },
  { "Guild", function()
    if not ns.inOurGuild() then return "warn", "not in the guild: roster and /link wait for it" end
    return "ok"
  end },
}

-- Runs every check; returns the saved result.
function ns.SelfTest()
  local res = { at = time(), ver = ns.VERSION, ok = 0, warn = 0, fail = 0, skip = 0, lines = {} }
  for _, c in ipairs(CHECKS) do
    local ok, status, detail = pcall(c[2])
    if not ok then status, detail = "fail", "check crashed: " .. tostring(status):gsub("[%c|]", " ") end
    if not res[status] then status = "fail" end
    res[status] = res[status] + 1
    if status ~= "ok" and #res.lines < MAX_LINES then
      res.lines[#res.lines + 1] = (status .. " " .. c[1] .. ": " .. tostring(detail or "")):sub(1, LINE_MAX)
    end
  end
  UW_GuildDB.selftest = res
  return res
end

-- A new TOC file loads only on a full restart, not /reload (WoW reads the TOC at start-up). Missing files after an
-- update: say once how to finish it, instead of leaving the features that need them silently off.
ns.RESTART_LINE = "Quit WoW and start it again to finish the UW_Guild update: /reload doesn't load its new files."
local told
function ns.CheckNewFiles()
  if told then return end
  for _, f in ipairs(ns.SELFTEST_FILES) do
    if ns[f[2]] == nil then
      told = true
      ns.say(ns.RESTART_LINE)
      return f[1]
    end
  end
end
local watch = CreateFrame("Frame")
ns.listen(watch, { "PLAYER_ENTERING_WORLD" })
watch:SetScript("OnEvent", ns.guard(function(self)
  self:UnregisterEvent("PLAYER_ENTERING_WORLD")
  pcall(ns.CheckNewFiles)
end))

local COLOR = { fail = "|cffff4040", warn = "|cffff8000", skip = "|cff808080" }
ns.commands.selftest = function()
  local r = ns.SelfTest()
  ns.say(("Selftest v%s: %d ok, %d warn, %d fail."):format(r.ver, r.ok, r.warn, r.fail))
  for _, line in ipairs(r.lines) do
    local status = line:match("^(%a+)")
    ns.say((COLOR[status] or "") .. line .. "|r")
  end
end
