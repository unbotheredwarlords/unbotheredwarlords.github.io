-- /uw selftest (Louis, 5 Nov 2026): checks UW_Guild on this game client in a few seconds, so a bug shows up before
-- it shows up in play. The Lua tests model the client with stubs; this runs the same code on the real one.
-- Read-only: it calls only functions that look things up (never equip, delete, bind, send or post), runs each check
-- protected, and keeps the last result in UW_GuildDB.selftest, so it can be read from the saved file after /reload.
local _, ns = ...

-- One name each file sets on ns. Missing means that file failed to load on this client.
-- tests/self_test_test.lua fails when a TOC file is missing here.
ns.SELFTEST_FILES = {
  { "Core.lua", "CheckKit" }, { "Outbound.lua", "SENDERS" }, { "KitDoctor.lua", "KitReport" }, { "KitShare.lua", "KitFixPlan" },
  { "KitLook.lua", "KitLookDiff" }, { "MacroLibrary.lua", "MACROS" }, { "Macros.lua", "SpellName" },
  { "Onboarding.lua", "RefreshWelcome" }, { "Cheers.lua", "ReadCheers" }, { "Loot.lua", "StartLoot" },
  { "Crafts.lua", "SearchCrafts" }, { "Bank.lua", "CountBags" }, { "Gear.lua", "RefreshGear" },
  { "Raid.lua", "RecordKill" }, { "Plan.lua", "DecodePlan" }, { "Options.lua", "OpenOptions" },
  { "Skin.lua", "Skin" }, { "Items.lua", "KeepReason" }, { "AutoEquip.lua", "TryGearUpgrade" },
  { "GearWeights.lua", "GEAR_WEIGHTS" }, { "GearScore.lua", "GearUpgrade" }, { "QuestItem.lua", "FindQuestItemUse" },
  { "QuestChain.lua", "QuestChain" }, { "Guide.lua", "GuideTarget" }, { "SettingsPage.lua", "SettingsPage" }, { "Terrain.lua", "TerrainDecode" }, { "ForYou.lua", "ForYouText" }, { "BagRoom.lua", "BagRoomRefresh" }, { "DialogueHold.lua", "WrapDialogueHide" }, { "ShareLater.lua", "ShareLaterOn" },
  { "SpellBars.lua", "SpellToBars" }, { "Mail.lua", "MailPlan" }, { "Gold.lua", "GoldLines" }, { "Enchants.lua", "EnchantPlan" }, { "Charter.lua", "CharterStatus" }, { "Community.lua", "CommunityMessage" }, { "Lead.lua", "Lead" },
  { "Schedule.lua", "SCHEDULE" }, { "WhatsOn.lua", "WhatsOn" }, { "RaidReady.lua", "RaidReadyLine" }, { "Fish.lua", "FishOn" },
  { "Thanks.lua", "GameThanks" }, { "WeekOne.lua", "WeekOneSample" }, { "Reports.lua", "ReportFold" }, { "Credit.lua", "CreditNote" }, { "Identity.lua", "IdentityList" }, { "Sync.lua", "SyncRefresh" }, { "Handbook.lua", "OpenHandbook" },
  { "SelfTest.lua", "SelfTest" },
}
-- Every /uw command the help lists.
ns.SELFTEST_COMMANDS = { "kit", "near", "welcome", "invite", "contact", "loot", "plan", "craft", "bank", "audit",
  "buddy", "leavers", "options", "chain", "guide", "terrain", "compass", "meet", "gear", "space", "bags", "bars", "mail", "enchant", "ranks", "charter", "lead", "events", "thanks", "rate", "new", "sync", "selftest", "version" }
-- Functions that only look things up; each must run without an error on this client.
local FINDERS = { "FindGearUpgrade", "CheapestJunk", "FindQuestItemUse", "KitFixPlan", "KitFixAllPlan", "CheckKit",
  "KitTroubleCounts", "OptionsStatus", "MailPlan", "EnchantPlan" }
local MAX_LINES, LINE_MAX = 12, 150

local function loaded(name)
  return C_AddOns and C_AddOns.IsAddOnLoaded and select(1, C_AddOns.IsAddOnLoaded(name)) and true or false
end

local CHECKS = {
  { "Files", function()
    local bad = {}
    for _, f in ipairs(ns.SELFTEST_FILES) do if ns[f[2]] == nil then bad[#bad + 1] = f[1] end end
    if #bad > 0 then return "fail", "didn't load: " .. table.concat(bad, ", ") end
    return "ok"
  end },
  { "Commands", function()
    local bad = {}
    for _, c in ipairs(ns.SELFTEST_COMMANDS) do if type(ns.commands[c]) ~= "function" then bad[#bad + 1] = c end end
    if #bad > 0 then return "fail", "missing /uw " .. table.concat(bad, ", ") end
    return "ok"
  end },
  { "Game functions", function()
    local missing = ns.ClientMissing()
    if #missing > 0 then return "fail", "this client lacks " .. table.concat(missing, ", ") end
    return "ok"
  end },
  { "Errors", function()
    local n, first = ns.ownErrors or 0, nil
    for _, e in ipairs(type(UW_GuildDB.errors) == "table" and UW_GuildDB.errors or {}) do
      if type(e) == "table" and e.ver == ns.VERSION then first = first or e.msg end
    end
    if n > 0 or first then return "fail", ("%d this session. %s"):format(n, first or "") end
    return "ok"
  end },
  { "Finders", function()
    local bad = {}
    for _, name in ipairs(FINDERS) do
      local fn = ns[name]
      if type(fn) == "function" then
        local ok, err = pcall(fn)
        if not ok then bad[#bad + 1] = name .. ": " .. tostring(err):gsub("[%c|]", " "):sub(1, 60) end
      end
    end
    if #bad > 0 then return "fail", table.concat(bad, "; ") end
    return "ok"
  end },
  -- The enchant button (Enchants.lua): built under the wrist slot unless the member turned it off, and its settings
  -- readable.
  { "Enchant button", function()
    if UW_GuildDB.enchantButton == false then return "skip", "turned off (/uw enchant on)" end
    if not ns.inOurGuild() then return "skip", "not in the guild" end
    local b = rawget(_G, "UW_GuildEnchantButton")
    if not b then return "warn", "not on the character panel: its frames weren't there" end
    local _, rel = b:GetPoint(1)
    if rel ~= rawget(_G, "CharacterWristSlot") then return "warn", "moved off the wrist slot by another addon" end
    for _, key in ipairs(ns.ENCHANT_SETTINGS or {}) do
      if not ns.EnchantSetting(key) then return "fail", "setting " .. key .. " unreadable" end
    end
    return "ok"
  end },
  { "Roll text", function()
    local fmt = RANDOM_ROLL_RESULT or "%s rolls %d (%d-%d)"
    local who, roll = fmt:format("Tester", 42, 1, 100):match(ns.RollPattern())
    if who ~= "Tester" or roll ~= "42" then return "fail", "/roll lines aren't read: loot rolls won't count" end
    return "ok"
  end },
  { "Kit", function()
    local missReq, _, conflicts = ns.CheckKit()
    -- /uw kit says where to get them; /uw kit fix can't install anything (render crawl on 112, 13 Nov).
    if #missReq > 0 then return "warn", "missing " .. table.concat(missReq, ", ") .. ". /uw kit shows where to get them." end
    if #conflicts > 0 then return "warn", #conflicts .. " duplicate pair(s). /uw kit fix turns one off." end
    return "ok"
  end },
  { "Quest chains", function()
    if not loaded("Questie") then return "skip", "Questie is off" end
    local p = UW_GuildDB.chainProbe
    if type(p) ~= "table" or not p.lib then return "warn", "Questie's quest data isn't readable: no chain tags" end
    if not p.hooked then return "warn", "Questie's tracker isn't hooked: no chain tags" end
    return "ok"
  end },
  { "Look", function()
    if not loaded("EllesmereUI") then return "skip", "EllesmereUI is off" end
    if not ns.Skinned() then return "warn", "EllesmereUI hasn't skinned UW windows yet" end
    return "ok"
  end },
  { "Version", function()
    if ns.VERSION == "dev" then return "warn", "unstamped (dev): errors can't be tied to a build" end
    return "ok"
  end },
  { "Guild", function()
    if not ns.inOurGuild() then return "warn", "not in the guild: roster and /link wait for it" end
    return "ok"
  end },
}

-- Runs every check; returns the saved result.
function ns.SelfTest()
  local res = { at = time(), ver = ns.VERSION, ok = 0, warn = 0, fail = 0, skip = 0, lines = {} }
  for _, c in ipairs(CHECKS) do
    local ok, status, detail = pcall(c[2])
    if not ok then status, detail = "fail", "check crashed: " .. tostring(status):gsub("[%c|]", " ") end
    if not res[status] then status = "fail" end
    res[status] = res[status] + 1
    if status ~= "ok" and #res.lines < MAX_LINES then
      res.lines[#res.lines + 1] = (status .. " " .. c[1] .. ": " .. tostring(detail or "")):sub(1, LINE_MAX)
    end
  end
  UW_GuildDB.selftest = res
  return res
end

-- A new TOC file loads only on a full restart, not /reload (WoW reads the TOC at start-up). Missing files after an
-- update: say once how to finish it, instead of leaving the features that need them silently off.
ns.RESTART_LINE = "Quit WoW and start it again to finish the UW_Guild update: /reload doesn't load its new files."
local told
function ns.CheckNewFiles()
  if told then return end
  for _, f in ipairs(ns.SELFTEST_FILES) do
    if ns[f[2]] == nil then
      told = true
      ns.say(ns.RESTART_LINE)
      return f[1]
    end
  end
end
local watch = CreateFrame("Frame")
ns.listen(watch, { "PLAYER_ENTERING_WORLD" })
watch:SetScript("OnEvent", ns.guard(function(self)
  self:UnregisterEvent("PLAYER_ENTERING_WORLD")
  pcall(ns.CheckNewFiles)
end))

-- /uw selftest probe (Louis, 22 Nov 2026: "cause some bugs on purpose to gain more information for us to leverage to
-- better coordinate our addon suite"). On the bot's PC only (the Guild Master's client; never a member's). A guided
-- bisect of a few addons he names (at most ns.PROBE_MAX): the rest of the pack's map is settled offline from the code
-- (render/pack/pack_deps.py: every addon's dependencies and unguarded reads of another addon's globals), and the
-- probe is only for what that can't settle. Step 0 runs as is; each next step turns ONE named addon off for this character, he
-- types /reload (Forever may refuse ReloadUI() from addon code, KitShare.lua askReload), and after the reload UW pokes
-- the hooks addons hang on, out of combat: an item tooltip, the bags open and shut, the self-test above with its
-- finders. Then it saves what broke without that addon in UW_GuildDB.probe: BugGrabber's errors and the game's blocked
-- actions per addon, the addons that couldn't load, and the self-test's verdict. Hardening reads the save into the
-- pack's dependency map. The addon goes back on before the next goes off, so at most one is ever off;
-- /uw selftest stop, a probe left 6 hours, or a new UW_Guild build turns it back on. Nothing is sent. The addon that's
-- off isn't loaded, so its own save is untouched; but addons that load after it (OptionalDeps) may tidy settings that
-- point at it, or load an older copy of a shared library, and so rewrite their own saves (red team, #872). Hardening
-- copies the WTF folder before each run and compares the saves after.
-- The world map is left alone on purpose: opening it from addon code taints it (memory uw-openmap-taint).
ns.PROBE_MAX, ns.PROBE_STALE, ns.PROBE_ITEM = 5, 6 * 3600, 2589 -- Linen Cloth: every addon's item tooltip runs on it
local NEVER_OFF = { UW_Guild = true, ["!BugGrabber"] = true, BugSack = true } -- the probe, and what records for it
local function me() return (UnitGUID and UnitGUID("player")) or UnitName("player") end
local function setOn(name, on, who)
  local fn = C_AddOns and (on and C_AddOns.EnableAddOn or C_AddOns.DisableAddOn)
  if fn then pcall(fn, name, who or me()) end
end
local function state(name, who) -- 0 off, 2 on; with no character, across all of them (1 = some)
  if not (C_AddOns and C_AddOns.GetAddOnEnableState) then return nil end
  local ok, v = pcall(C_AddOns.GetAddOnEnableState, name, who)
  return ok and tonumber(v) or nil
end
-- Off for this character only, read back (red team, #872: which character form Forever takes is unproven, and a
-- refusal or an all-characters switch must never stand). Tries the GUID, then the name. On anything else it puts the
-- addon back as it was and says false.
local function turnOff(name)
  local all = state(name)
  if all ~= 2 then return false end -- off on some other character: an all-characters switch couldn't be undone exactly
  for _, who in ipairs({ me(), UnitName("player") }) do
    setOn(name, false, who)
    local mine, now = state(name, who), state(name)
    if mine == 0 and now ~= 0 then return true, who end
    if now == 0 and C_AddOns.EnableAddOn then pcall(C_AddOns.EnableAddOn, name) end -- every character
    setOn(name, true, who)
  end
  return false
end

-- What can be turned off: loaded, not load-on-demand, not Blizzard's, one line per addon (a module whose parent is
-- loaded goes off with it), and on for every character (red team, #872: then any switch can be undone exactly). Only
-- the names asked for, alphabetical, so two runs compare step by step.
function ns.ProbePlan(only)
  local on, plan = {}, {}
  local num = C_AddOns and C_AddOns.GetNumAddOns and C_AddOns.GetNumAddOns() or 0
  for i = 1, num do
    local name = C_AddOns.GetAddOnInfo(i)
    if type(name) == "string" and C_AddOns.IsAddOnLoaded(name) then on[name] = true end
  end
  for name in pairs(on) do
    local parent = name:match("^(.-)_.+$")
    local lod = C_AddOns.IsAddOnLoadOnDemand and select(2, pcall(C_AddOns.IsAddOnLoadOnDemand, name)) == true
    if not NEVER_OFF[name] and not name:find("^Blizzard_") and not lod and not (parent and on[parent])
      and only and only[name:lower()] and state(name) ~= 0 and state(name) ~= 1 then
      plan[#plan + 1] = name
    end
  end
  table.sort(plan)
  while #plan > ns.PROBE_MAX do table.remove(plan) end
  return plan
end

local function poke()
  local tip = rawget(_G, "GameTooltip")
  if tip and tip.SetItemByID then
    pcall(tip.SetOwner, tip, UIParent, "ANCHOR_NONE")
    pcall(tip.SetItemByID, tip, ns.PROBE_ITEM)
    pcall(tip.Hide, tip)
  end
  local open, shut = rawget(_G, "OpenAllBags"), rawget(_G, "CloseAllBags")
  if open then pcall(open) end
  ns.after(1, function() if shut then pcall(shut) end end)
  local st = ns.SelfTest()
  return { ok = st.ok, warn = st.warn, fail = st.fail, lines = { st.lines[1], st.lines[2], st.lines[3] } }
end

-- Addons whose errors or blocks rose against step 0, as "Name (n)".
local function worse(step, base)
  local out = {}
  for _, k in ipairs({ "errors", "blocked" }) do
    for name, n in pairs(step[k] or {}) do
      local was = base and base[k] and base[k][name] or 0
      if n > was then out[#out + 1] = ("%s (%d)"):format(name, n - was) end
    end
  end
  for _, name in ipairs(step.deps or {}) do out[#out + 1] = name .. " (didn't load)" end
  table.sort(out)
  return out
end

local function finish(p, how)
  if p.off then setOn(p.off, true, p.who) end
  local back = p.off
  p.off, p.done = nil, how
  if how == "done" then
    local shown = 0
    for _, step in ipairs(p.steps) do
      local w = step.off and worse(step, p.steps[1]) or {}
      if #w > 0 and shown < 5 then
        shown = shown + 1
        ns.say(("Without %s: %s."):format(step.off, table.concat(w, ", ", 1, math.min(#w, 4))))
      end
    end
    ns.say(("Probe done: %d addons tested, %s. Everything is back on: type /reload to finish."):format(#p.steps - 1,
      shown > 0 and "the lines above are what broke" or "nothing broke"))
  elseif how == "refused" then
    ns.say(("Probe stopped: the game wouldn't turn %s off for this character alone, so it's on as it was. Type "
      .. "/reload."):format(p.refused or "it"))
  elseif back then
    ns.say(("Probe stopped: %s is back on. Type /reload to load it."):format(back))
  end
end

-- After a reload during a probe: record this step, put its addon back, turn the next one off.
local function step()
  local p = UW_GuildDB.probe
  if type(p) ~= "table" or p.done or p.char ~= me() then return end
  if InCombatLockdown() then ns.probeWait = true return end
  ns.probeWait = nil
  local st = poke()
  ns.after(3, function()
    local t = ns.KitTroubleByAddon()
    -- wasLoaded: the game's own word that the addon really was off this step (hardening, 22 Nov: the save had no
    -- trace of it but the probe's own field).
    local rec = { off = p.off, errors = t.errors, blocked = t.blocked, deps = t.deps, own = t.own, selftest = st,
      at = time() }
    if p.off then rec.loaded = C_AddOns.IsAddOnLoaded(p.off) and true or false end
    p.steps[#p.steps + 1] = rec
    if p.off then setOn(p.off, true, p.who) end
    p.off = nil
    local nextName = p.plan[#p.steps]
    if not nextName then return finish(p, "done") end
    local ok, who = turnOff(nextName)
    if not ok then p.refused = nextName return finish(p, "refused") end
    p.off, p.who, p.at = nextName, who, time()
    ns.say(("Probe %d/%d: %s is off on this character. Type /reload to go on, or /uw selftest stop to end it.")
      :format(#p.steps, #p.plan, nextName))
  end)
end

function ns.ProbeStart(only)
  if not (ns.BotPC and ns.BotPC()) then return ns.say("The probe runs only on the PC that runs the guild bot.") end
  if InCombatLockdown() then return ns.say("Try again after combat.") end
  local p = UW_GuildDB.probe
  if type(p) == "table" and not p.done then return ns.say("A probe is already running: /reload, or /uw selftest stop.") end
  if not only then
    return ns.say(("Name up to %d addons: /uw selftest probe Questie OpenMap"):format(ns.PROBE_MAX))
  end
  local plan = ns.ProbePlan(only)
  if #plan == 0 then return ns.say("None of those addons is loaded here.") end
  ns.KitConfirm(("UW probe: turns %s off one at a time on this character (one /reload each), to see what breaks "
    .. "without each. Each goes back on before the next goes off. Start?"):format(table.concat(plan, ", ")), function()
    UW_GuildDB.probe = { plan = plan, steps = {}, char = me(), ver = ns.VERSION, at = time() }
    step()
  end)
end

function ns.ProbeStop()
  local p = UW_GuildDB.probe
  if type(p) ~= "table" or p.done then return ns.say("No probe is running.") end
  finish(p, "stopped")
end

local pw = CreateFrame("Frame")
ns.listen(pw, { "PLAYER_ENTERING_WORLD", "PLAYER_REGEN_ENABLED" })
pw:SetScript("OnEvent", ns.guard(function(_, event, isLogin, isReload)
  local p = UW_GuildDB.probe
  if type(p) ~= "table" or p.done or p.char ~= me() then return end -- another character: its addons were never touched
  if event == "PLAYER_REGEN_ENABLED" then
    if ns.probeWait then step() end
    return
  end
  if not (isLogin or isReload) then return end -- a loading screen between zones isn't a new step
  if p.ver ~= ns.VERSION or time() - (tonumber(p.at) or 0) > ns.PROBE_STALE then return finish(p, "stale") end
  ns.after(5, step) -- other addons finish setting up first
end))

local COLOR = { fail = "|cffff4040", warn = "|cffff8000", skip = "|cff808080" }
ns.commands.selftest = function(arg)
  local verb, rest = tostring(arg or ""):match("^%s*(%S*)%s*(.-)%s*$")
  if verb == "probe" then
    local only
    for name in rest:gmatch("%S+") do only = only or {} only[name:lower()] = true end
    return ns.ProbeStart(only)
  elseif verb == "stop" then
    return ns.ProbeStop()
  end
  local r = ns.SelfTest()
  ns.say(("Selftest v%s: %d ok, %d warn, %d fail."):format(r.ver, r.ok, r.warn, r.fail))
  for _, line in ipairs(r.lines) do
    local status = line:match("^(%a+)")
    ns.say((COLOR[status] or "") .. line .. "|r")
  end
end
