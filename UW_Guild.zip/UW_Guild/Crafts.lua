-- Crafting directory: who in the guild can make what, so "anyone make X?" in guild chat gets an answer without a
-- guild-wide shout. Each client records its own professions (ranks from the skill list, recipes when a profession
-- window is opened) and shares them with the guild over addon messages; every client keeps the guild's directory in
-- UW_GuildDB.crafts, which the bot reads from the guild master's save (/uw-ask "who can make ...", /uw-me).
-- Opt out per character with /uw craft off: that also tells every online client to forget you.
--
-- Wire format (all UWG1, fields tab-separated):
--   CRV  <at> <Prof=rank,...>   GUILD: "my directory entry is from <at>", at login and after a change
--   CRVQ                         GUILD from an officer: everyone, say CRV (once per 10 min per client)
--   CRQ  <at>                    WHISPER from an officer whose copy is older: please send yours
--   CRD  <at> <i> <n> <prof> <rank> <max> <key=name;...>   GUILD: part i of n of an entry, answers CRQ
--   CRX                          GUILD: I opted out, forget my entry
-- Keys: i<itemID> for crafted items, e<id> for enchants, r<recipeID> on the modern trade skill API.
local _, ns = ...

ns.CRAFT_PROFESSIONS = { -- English names (Forever NA/EU); other locales fall back to the skill list's headers
  Alchemy = true, Blacksmithing = true, Enchanting = true, Engineering = true, Leatherworking = true,
  Tailoring = true, Cooking = true, ["First Aid"] = true, Herbalism = true, Mining = true, Skinning = true,
  Fishing = true,
}
ns.CRAFT_SKILL_HEADERS = { Professions = true, ["Secondary Skills"] = true }
ns.CRAFT_MAX_RECIPES = 400   -- per profession; vanilla's largest list is about 200
ns.CRAFT_MSG_MAX = 250       -- addon messages are capped at 255 bytes
ns.CRAFT_RESEND = 600        -- answer CRQ for the same entry at most once per 10 minutes
ns.PROF_MILESTONE = 300      -- a maxed profession gets a guild feed post (outbox "prof\tname\tProfession;300")

local function myName() return ns.shortName(ns.me() or UnitName("player")) end
local function clean(s) return (tostring(s or ""):gsub("[\t;=,|\"\\]", "")) end

local num = ns.finite -- Core.lua: a finite number from a guildmate's message, or nil
ns.num = num

-- Register only the events this client has. Forever runs on the modern client, where RegisterEvent throws on an
-- unknown event (Classic-only ones like TRADE_SKILL_UPDATE and CRAFT_UPDATE), which would stop the whole file.
function ns.listen(frame, events)
  local valid = C_EventUtils and C_EventUtils.IsEventValid
  for _, e in ipairs(events) do
    if not valid or valid(e) then pcall(frame.RegisterEvent, frame, e) end
  end
end
local function sharing() return UW_GuildCharDB and not UW_GuildCharDB.craftsOff end
ns.CraftSharing = sharing

-- Queue the milestone post once per character and profession, only on a crossing this client saw (from a known
-- lower rank), so the first entry heard for a long-time 300 crafter is never news.
local function milestone(name, prof, old, new)
  old, new = num(old), num(new)
  if not (old and new) or old <= 0 or old >= ns.PROF_MILESTONE or new < ns.PROF_MILESTONE then return end
  if not ns.CRAFT_PROFESSIONS[prof] then return end -- a guildmate's message names it: only real professions post
  local done = UW_GuildDB.profPosted
  local key = name .. ";" .. prof
  if done[key] then return end
  done[key] = time()
  ns.queue("prof", name, prof .. ";" .. ns.PROF_MILESTONE)
end
ns.ProfMilestone = milestone

-- Reading the client ---------------------------------------------------------
-- Ranks of every profession this character has: { [prof] = { r = rank, m = max } }, or nil if the skill list
-- couldn't be read (then nothing is removed).
function ns.ReadProfessions()
  local out = {}
  if GetNumSkillLines and GetSkillLineInfo then
    local ok, n = pcall(GetNumSkillLines)
    if not ok or type(n) ~= "number" or ns.isSecret(n) or n == 0 then return nil end
    local header
    for i = 1, n do
      local name, isHeader, _, rank, _, _, max = GetSkillLineInfo(i)
      if type(name) == "string" and not ns.isSecret(name) then
        if isHeader then
          header = name
        elseif ns.CRAFT_PROFESSIONS[name] or ns.CRAFT_SKILL_HEADERS[header or ""] then
          out[clean(name)] = { r = tonumber(rank) or 0, m = tonumber(max) or 0 }
        end
      end
    end
    return out
  elseif GetProfessions and GetProfessionInfo then -- modern client layout
    for _, idx in pairs({ GetProfessions() }) do -- holes for empty slots, so pairs, not ipairs
      local name, _, rank, max = GetProfessionInfo(idx)
      if type(name) == "string" and not ns.isSecret(name) then
        out[clean(name)] = { r = tonumber(rank) or 0, m = tonumber(max) or 0 }
      end
    end
    return out
  end
  return nil
end

local function keyOf(link, fallback)
  if type(link) == "string" and not ns.isSecret(link) then
    local id = link:match("item:(%d+)")
    if id then return "i" .. id end
    id = link:match("enchant:(%d+)") or link:match("spell:(%d+)")
    if id then return "e" .. id end
  end
  return fallback
end

-- Recipe details for crafting recommendations, UW_GuildDB.recipeInfo[key] = { lvl, slot, cls, sub, reag }: the made
-- item's required level, equip slot, item class and subclass (GetItemInfoInstant), and its reagents as
-- "itemID:count:name,...". Game constants, so the first full read wins (a read before the item cache had the
-- required level is redone).
-- Primary stats on an item, as short tags ("agi,sta"), so a caster gets a caster weapon (GetItemStats).
local STAT_TAGS = { { "STRENGTH", "str" }, { "AGILITY", "agi" }, { "INTELLECT", "int" }, { "SPIRIT", "spi" },
  { "STAMINA", "sta" }, { "SPELL_POWER", "sp" }, { "SPELL_DAMAGE", "sp" }, { "HEALING", "sp" } }
function ns.ItemStatTags(id)
  local get = (C_Item and C_Item.GetItemStats) or GetItemStats
  if not get then return nil end
  local ok, stats = pcall(get, "item:" .. id)
  if not ok or type(stats) ~= "table" then return nil end
  local have, out = {}, {}
  for k in pairs(stats) do
    if type(k) == "string" then
      for _, t in ipairs(STAT_TAGS) do
        if k:find(t[1], 1, true) and not have[t[2]] then have[t[2]] = true; out[#out + 1] = t[2] end
      end
    end
  end
  table.sort(out)
  return table.concat(out, ",")
end

local function itemFacts(id)
  local lvl, slot, cls, sub, ilvl
  local instant = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
  if instant then
    local ok, _, _, _, equip, _, classID, subID = pcall(instant, id)
    if ok then slot, cls, sub = equip ~= "" and equip or nil, classID, subID end
  end
  local full = (C_Item and C_Item.GetItemInfo) or GetItemInfo
  if full then
    local ok, _, _, _, itemLevel, minLevel = pcall(full, id)
    if ok and type(minLevel) == "number" and not ns.isSecret(minLevel) then lvl = minLevel end
    if ok and type(itemLevel) == "number" and not ns.isSecret(itemLevel) then ilvl = itemLevel end
  end
  return lvl, slot, cls, sub, ilvl
end

local function reagentList(n, info, link)
  local parts = {}
  for r = 1, tonumber(n) or 0 do
    local name, _, count = info(r)
    local id = link and tostring(link(r) or ""):match("item:(%d+)")
    if id and tonumber(count) and not ns.isSecret(count) then
      parts[#parts + 1] = ("%s:%d:%s"):format(id, count, (clean(name):gsub(":", "")))
    end
  end
  return table.concat(parts, ",")
end

-- An entry is complete once it has the required level and, for gear, the item level (v0.8).
local function complete(e, key)
  if not key:find("^i") then return e ~= nil end
  return e ~= nil and e.lvl ~= nil and (e.ilvl ~= nil or (e.cls ~= 2 and e.cls ~= 4))
end

local function noteInfo(key, reagents)
  local db = UW_GuildDB and UW_GuildDB.recipeInfo
  local old = db and db[key]
  if not db or complete(old, key) then return end -- redone until complete: the item cache can lag
  local ok, reag = pcall(reagents)
  if not ok or reag == "" then return end
  local e = { reag = reag }
  local id = key:match("^i(%d+)$")
  if id then
    e.lvl, e.slot, e.cls, e.sub, e.ilvl = itemFacts(tonumber(id))
    if e.cls == 2 or e.cls == 4 then e.stat = ns.ItemStatTags(id) end -- weapons and armor
  end
  db[key] = e
end
ns.NoteRecipeInfo = noteInfo

-- Modern client: reagents from the recipe's schematic (basic reagents only; optional and finishing slots skipped).
function ns.SchematicReagents(recipeID)
  local s = C_TradeSkillUI.GetRecipeSchematic(recipeID, false)
  local parts = {}
  for _, slot in ipairs(type(s) == "table" and s.reagentSlotSchematics or {}) do
    local first = slot.reagents and slot.reagents[1]
    local id, count = first and first.itemID, slot.quantityRequired
    local basic = slot.reagentType == nil or slot.reagentType == 1 or (Enum and Enum.CraftingReagentType
      and slot.reagentType == Enum.CraftingReagentType.Basic)
    if basic and type(id) == "number" and type(count) == "number" and not ns.isSecret(count) then
      local nameOf = (C_Item and C_Item.GetItemNameByID) or GetItemInfo
      local ok, name = pcall(nameOf, id)
      parts[#parts + 1] = ("%d:%d:%s"):format(id, count, ok and clean(name):gsub(":", "") or "")
    end
  end
  return table.concat(parts, ",")
end

-- The open profession window: prof, rank, max, { [key] = name }. Only what the window lists is seen; recipes
-- are merged in (never removed), so a filter or a collapsed header never makes a recipe disappear.
function ns.ReadTradeSkill()
  local rec = {}
  if GetTradeSkillLine and GetNumTradeSkills then
    local prof, rank, max = GetTradeSkillLine()
    if type(prof) ~= "string" or ns.isSecret(prof) or prof == "UNKNOWN" then return nil end
    for i = 1, GetNumTradeSkills() or 0 do
      local name, kind = GetTradeSkillInfo(i)
      if type(name) == "string" and kind ~= "header" and kind ~= "subheader" and not ns.isSecret(name) then
        local link = GetTradeSkillItemLink and GetTradeSkillItemLink(i)
        local key = keyOf(link, "n" .. clean(name):lower())
        rec[key] = clean(name)
        if GetTradeSkillNumReagents and GetTradeSkillReagentInfo then
          noteInfo(key, function()
            return reagentList(GetTradeSkillNumReagents(i), function(r) return GetTradeSkillReagentInfo(i, r) end,
              GetTradeSkillReagentItemLink and function(r) return GetTradeSkillReagentItemLink(i, r) end)
          end)
        end
      end
    end
    return clean(prof), rank, max, rec
  elseif C_TradeSkillUI and C_TradeSkillUI.GetAllRecipeIDs then
    local info = C_TradeSkillUI.GetBaseProfessionInfo and C_TradeSkillUI.GetBaseProfessionInfo()
    local prof = info and info.professionName
    if type(prof) ~= "string" or ns.isSecret(prof) or prof == "" then return nil end
    for _, id in ipairs(C_TradeSkillUI.GetAllRecipeIDs() or {}) do
      local r = C_TradeSkillUI.GetRecipeInfo(id)
      if r and r.learned and type(r.name) == "string" and not ns.isSecret(r.name) then
        local link = C_TradeSkillUI.GetRecipeItemLink and C_TradeSkillUI.GetRecipeItemLink(id)
        local key = keyOf(link, "r" .. id)
        rec[key] = clean(r.name)
        if C_TradeSkillUI.GetRecipeSchematic then
          noteInfo(key, function() return ns.SchematicReagents(id) end)
        end
      end
    end
    return clean(prof), info.skillLevel, info.maxSkillLevel, rec
  end
  return nil
end

-- Enchanting in Classic uses the separate Craft window (as does Beast Training, which has no skill line).
function ns.ReadCraft()
  if not (GetCraftDisplaySkillLine and GetNumCrafts) then return nil end
  local prof, rank, max = GetCraftDisplaySkillLine()
  if type(prof) ~= "string" or ns.isSecret(prof) then return nil end
  local rec = {}
  for i = 1, GetNumCrafts() or 0 do
    local name, _, kind = GetCraftInfo(i)
    if type(name) == "string" and kind ~= "header" and not ns.isSecret(name) then
      local link = GetCraftItemLink and GetCraftItemLink(i)
      local key = keyOf(link, "n" .. clean(name):lower())
      rec[key] = clean(name)
      if GetCraftNumReagents and GetCraftReagentInfo then
        noteInfo(key, function()
          return reagentList(GetCraftNumReagents(i), function(r) return GetCraftReagentInfo(i, r) end,
            GetCraftReagentItemLink and function(r) return GetCraftReagentItemLink(i, r) end)
        end)
      end
    end
  end
  return clean(prof), rank, max, rec
end

-- Which reading path this client has, for /uw craft check on launch day (Forever's API surface isn't documented).
function ns.CraftApis()
  return {
    skills = (GetNumSkillLines and GetSkillLineInfo) and "classic" or (GetProfessions and GetProfessionInfo)
      and "modern" or "none",
    trade = (GetTradeSkillLine and GetNumTradeSkills) and "classic"
      or (C_TradeSkillUI and C_TradeSkillUI.GetAllRecipeIDs) and "modern" or "none",
    craft = (GetCraftDisplaySkillLine and GetNumCrafts) and "classic" or "none",
  }
end

-- Own entry --------------------------------------------------------------------
local announce
local function ownEntry()
  local c = UW_GuildDB.crafts
  c[myName()] = c[myName()] or { at = 0, profs = {} }
  return c[myName()]
end

local function changed()
  local e = ownEntry()
  e.at = time()
  if announce then announce() end
end

-- Ranks from the skill list: adds new professions, drops ones the character no longer has.
function ns.RefreshProfessions()
  if not sharing() or not ns.tracksGuild() then return end
  local ranks = ns.ReadProfessions()
  if not ranks then return end
  local e, dirty = ownEntry(), false
  for prof, r in pairs(ranks) do
    local p = e.profs[prof]
    if not p then
      e.profs[prof] = { r = r.r, m = r.m, rec = {} }
      dirty = true
    elseif p.r ~= r.r or p.m ~= r.m then
      milestone(myName(), prof, p.r, r.r)
      p.r, p.m, dirty = r.r, r.m, true
    end
  end
  for prof in pairs(e.profs) do
    if not ranks[prof] then e.profs[prof] = nil; dirty = true end
  end
  if dirty then changed() end
end

function ns.RecordRecipes(prof, rank, max, rec)
  if not prof or not sharing() or not ns.tracksGuild() then return 0 end
  local e = ownEntry()
  local p = e.profs[prof] or { r = 0, m = 0, rec = {} }
  e.profs[prof] = p
  local added, count = 0, 0
  for _ in pairs(p.rec) do count = count + 1 end
  for k, name in pairs(rec) do
    if not p.rec[k] and count < ns.CRAFT_MAX_RECIPES then
      p.rec[k], added, count = name, added + 1, count + 1
    end
  end
  rank, max = tonumber(rank), tonumber(max)
  local rankChanged = rank and (p.r ~= rank or (max and p.m ~= max))
  if rank then milestone(myName(), prof, p.r, rank); p.r = rank end
  if max then p.m = max end
  if added > 0 or rankChanged then changed() end
  if added > 0 and not UW_GuildCharDB.craftsScanned then
    UW_GuildCharDB.craftsScanned = true
    ns.say(("Saved %d %s recipe(s) to the guild crafting directory. Guildmates can find you with /uw craft <item>."):
      format(added, prof))
  end
  return added
end

-- Comms ------------------------------------------------------------------------
local function summary(e)
  local parts = {}
  for prof, p in pairs(e.profs) do parts[#parts + 1] = prof .. "=" .. (p.r or 0) end
  table.sort(parts)
  return table.concat(parts, ",")
end

-- Split an entry into CRD lines that fit one addon message each.
function ns.CraftLines(e)
  local profs, lines = {}, {}
  for prof in pairs(e.profs) do profs[#profs + 1] = prof end
  table.sort(profs)
  for _, prof in ipairs(profs) do
    local p = e.profs[prof]
    local keys = {}
    for k in pairs(p.rec or {}) do keys[#keys + 1] = k end
    table.sort(keys)
    local head = ("%s\t%d\t%d\t"):format(prof, p.r or 0, p.m or 0)
    local cur = {}
    local size = #head
    local function flush() lines[#lines + 1] = head .. table.concat(cur, ";"); cur, size = {}, #head end
    for _, k in ipairs(keys) do
      local item = k .. "=" .. p.rec[k]
      -- "CRD\t<at>\t<i>\t<n>\t" takes at most 4+11+4+4 bytes
      if size + #item + 1 > ns.CRAFT_MSG_MAX - 23 and #cur > 0 then flush() end
      cur[#cur + 1] = item
      size = size + #item + 1
    end
    flush()
  end
  return lines
end

-- Paced by Core's send queue (its crafting lane), so the directory and the raid records share one budget under the
-- prefix's throttle instead of each running its own 1.2 s pacer. An item is a GUILD message, or { msg, channel, target }.
local function enqueue(msgs)
  for _, m in ipairs(msgs) do
    if type(m) == "table" then ns.craftSend(m[1], m[2], m[3]) else ns.craftSend(m, "GUILD") end
  end
end

ns.CraftEnqueue = enqueue

local announcePending = false
announce = function()
  if announcePending or not sharing() then return end
  announcePending = true
  C_Timer.After(30, function() -- coalesce: opening four windows in a row is one announcement
    announcePending = false
    local e = UW_GuildDB.crafts[myName()]
    if e and sharing() and ns.tracksGuild() then enqueue({ ("CRV\t%d\t%s"):format(e.at, summary(e)) }) end
  end)
end

local lastFull = 0
local function sendFull()
  local e = UW_GuildDB.crafts[myName()]
  if not e or not sharing() or not ns.tracksGuild() then return end
  if lastFull == e.at then return end -- this entry already went out in full
  lastFull = e.at
  C_Timer.After(ns.CRAFT_RESEND, function() if lastFull == e.at then lastFull = 0 end end)
  local lines = ns.CraftLines(e)
  local msgs = {}
  for i, l in ipairs(lines) do msgs[i] = ("CRD\t%d\t%d\t%d\t%s"):format(e.at, i, #lines, l) end
  enqueue(msgs)
end

local function guildmate(sender, channel, want)
  return channel == want and ns.tracksGuild() and ns.inRoster(sender)
end

-- Someone's entry stamp. Officers (whose saves the bot reads) ask for entries newer than theirs; everyone
-- else just listens to the GUILD answer. Ranks from the summary are kept right away, so a gatherer with no
-- recipes is listed even before any full entry arrives.
local asked = {}
ns.handlers.CRV = function(sender, channel, at, sum)
  if not guildmate(sender, channel, "GUILD") then return end
  local name = ns.shortName(sender)
  if name == myName() then return end
  at = num(at)
  if not at then return end
  local c = UW_GuildDB.crafts
  local e = c[name]
  if e and (e.at or 0) >= at then return end
  if not e then
    e = { at = 0, profs = {} }
    c[name] = e
  end
  for prof, rank in (sum or ""):gmatch("([^,=]+)=(%d+)") do
    e.profs[prof] = e.profs[prof] or { r = 0, m = 0, rec = {} }
    milestone(name, prof, e.profs[prof].r, rank)
    e.profs[prof].r = num(rank) or 0
  end
  e.seen = at -- newest stamp announced; e.at moves only when a full entry arrives
  if ns.isOfficer(ns.me()) and asked[name] ~= at then
    asked[name] = at
    -- Paced, like every crafting message: at an officer's login its CRVQ brings dozens of summaries within seconds,
    -- and direct sends past the game's throttle were refused and never asked again (login_storm_test.lua).
    ns.craftSend("CRQ\t" .. at, "WHISPER", sender)
  end
end

ns.handlers.CRQ = function(sender, channel)
  if not guildmate(sender, channel, "WHISPER") or not ns.isOfficer(sender) then return end
  sendFull()
end

local lastVQ
ns.handlers.CRVQ = function(sender, channel)
  if not guildmate(sender, channel, "GUILD") or not ns.isOfficer(sender) or not sharing() then return end
  if lastVQ and GetTime() - lastVQ < 600 then return end
  lastVQ = GetTime()
  local e = UW_GuildDB.crafts[myName()]
  if not e or e.at == 0 then return end
  C_Timer.After(2 + math.random() * 20, function() enqueue({ ("CRV\t%d\t%s"):format(e.at, summary(e)) }) end)
end

-- members[name].craftsOff: they typed /uw craft off, so the bot leaves their guild note's professions out too.
local function markOff(name, off)
  local m = UW_GuildDB.members and UW_GuildDB.members[name]
  if m then m.craftsOff = off or nil end
end

local partial = {} -- sender -> { at, n, got = { [i] = true }, profs }
ns.handlers.CRD = function(sender, channel, at, i, n, prof, rank, max, list)
  if not guildmate(sender, channel, "GUILD") then return end
  local name = ns.shortName(sender)
  if name == myName() then return end
  at, i, n = num(at), num(i), num(n)
  if not (at and i and n and prof and prof ~= "") or i < 1 or i > n or n > 200 then return end
  local e = UW_GuildDB.crafts[name]
  if e and (e.at or 0) >= at then return end
  local buf = partial[name]
  if not buf or buf.at ~= at then
    buf = { at = at, n = n, got = {}, count = 0, profs = {} }
    partial[name] = buf
  end
  if buf.got[i] then return end
  buf.got[i], buf.count = true, buf.count + 1
  local p = buf.profs[prof] or { r = num(rank) or 0, m = num(max) or 0, rec = {} }
  buf.profs[prof] = p
  for k, v in (list or ""):gmatch("([^;=]+)=([^;]+)") do p.rec[k] = v end
  if buf.count == buf.n then
    C_Timer.After(2 + math.random() * 5, function() ns.AskRecipeInfo(sender, name) end)
    for p2, np in pairs(buf.profs) do
      local op = e and e.profs and e.profs[p2]
      if op then milestone(name, p2, op.r, np.r) end
    end
    UW_GuildDB.crafts[name] = { at = at, profs = buf.profs }
    partial[name] = nil
    markOff(name, false)
  end
end

-- Recipe details: an officer's client (whose save the bot reads) asks a crafter, by whisper and once per session, for
-- the details of their recipes it lacks; the crafter whispers one CRI line per recipe, 1.2 s apart.
--   CRIQ <key,key,...>                          WHISPER, officer -> crafter
--   CRI  <key> <lvl> <slot> <cls> <sub> <reag> [<ilvl> <stat>]  WHISPER, crafter -> officer; accepted only for a
--        recipe the sender lists. ilvl and stat (v0.8) come after the reagents, so a v0.7 reader ignores them.
local infoAsked = {}
function ns.AskRecipeInfo(sender, name)
  if infoAsked[name] or not ns.isOfficer(ns.me()) then return end
  local e, db, keys, size = UW_GuildDB.crafts[name], UW_GuildDB.recipeInfo, {}, 5
  for _, p in pairs(e and e.profs or {}) do
    for k in pairs(p.rec or {}) do
      local old = db[k]
      if not complete(old, k) and not k:find("^n") and size + #k + 1 <= ns.CRAFT_MSG_MAX then
        keys[#keys + 1], size = k, size + #k + 1
      end
    end
  end
  if #keys == 0 then return end
  infoAsked[name] = true
  table.sort(keys)
  ns.craftSend("CRIQ\t" .. table.concat(keys, ","), "WHISPER", sender) -- paced, as CRQ above
end

local infoAnswered = {}
ns.handlers.CRIQ = function(sender, channel, list)
  if not guildmate(sender, channel, "WHISPER") or not ns.isOfficer(sender) or not sharing() then return end
  if infoAnswered[sender] and GetTime() - infoAnswered[sender] < ns.CRAFT_RESEND then return end
  infoAnswered[sender] = GetTime()
  local db, msgs = UW_GuildDB.recipeInfo, {}
  for k in (list or ""):gmatch("[^,]+") do
    local e = db[k]
    if e and e.reag then
      local tail = ("\t%s\t%s"):format(e.ilvl or "", e.stat or "")
      local line = ("CRI\t%s\t%s\t%s\t%s\t%s\t"):format(k, e.lvl or "", e.slot or "", e.cls or "", e.sub or "")
      local room = 255 - #line - #tail -- a long reagent list is cut, never the item level and stats after it
      msgs[#msgs + 1] = { line .. e.reag:sub(1, room) .. tail, "WHISPER", sender }
    end
  end
  enqueue(msgs)
end

ns.handlers.CRI = function(sender, channel, key, lvl, slot, cls, sub, reag, ilvl, stat)
  if not guildmate(sender, channel, "WHISPER") or not key or not reag or reag == "" then return end
  local e = UW_GuildDB.crafts[ns.shortName(sender)]
  local listed = false
  for _, p in pairs(e and e.profs or {}) do if p.rec and p.rec[key] then listed = true end end
  if not listed then return end -- only details for a recipe the sender actually has
  local db = UW_GuildDB.recipeInfo
  local old = db[key]
  if complete(old, key) or num(lvl) == nil then return end
  local clip = reag:match("^(.*%d:%d+:[^,]*)") or reag -- a line cut at 255 bytes loses only its last reagent's name
  db[key] = { lvl = num(lvl), slot = slot ~= "" and slot or nil, cls = num(cls), sub = num(sub),
    reag = clip, ilvl = num(ilvl), stat = stat and stat:match("^[a-z,]+$") or nil }
end

ns.handlers.CRX = function(sender, channel)
  if not guildmate(sender, channel, "GUILD") then return end
  UW_GuildDB.crafts[ns.shortName(sender)] = nil
  partial[ns.shortName(sender)] = nil
  markOff(ns.shortName(sender), true)
end

-- Search -------------------------------------------------------------------------
local function onlineNow()
  local out = {}
  for i = 1, GetNumGuildMembers() do
    local full, _, _, _, _, _, _, _, online = GetGuildRosterInfo(i)
    full = ns.fullName(full)
    if full and online then out[ns.shortName(full)] = true end
  end
  return out
end

-- Recipes whose name contains the text: { { name, key, crafters = { { who, prof, rank } } } }, sorted by name.
function ns.SearchCrafts(q)
  q = strtrim(q or ""):lower()
  local byKey = {}
  if q == "" then return {} end
  for who, e in pairs(UW_GuildDB.crafts) do
    local m = UW_GuildDB.members[who]
    if not (m and m.left) then
      for prof, p in pairs(e.profs or {}) do
        for k, name in pairs(p.rec or {}) do
          if name:lower():find(q, 1, true) then
            local hit = byKey[k] or { name = name, key = k, crafters = {} }
            byKey[k] = hit
            hit.crafters[#hit.crafters + 1] = { who = who, prof = prof, rank = p.r or 0 }
          end
        end
      end
    end
  end
  local out = {}
  for _, h in pairs(byKey) do out[#out + 1] = h end
  table.sort(out, function(a, b) return a.name < b.name end)
  return out
end

local function professionMatch(q)
  q = q:lower()
  for prof in pairs(ns.CRAFT_PROFESSIONS) do if prof:lower() == q then return prof end end
end

-- Guildmates whose public note names the profession but who haven't shared it with the addon (most notes are typed
-- by hand or set from a whisper): listed after the shared ones, marked "note", as the bot's directory does (#343).
-- The note is public in the roster already, so this shows nobody anything new. /uw craft off leaves them out.
local function noteRows(prof, have)
  local out = {}
  for name, m in pairs(UW_GuildDB.members or {}) do
    local who = type(name) == "string" and ns.shortName(name)
    if who and type(m) == "table" and not m.left and not m.craftsOff and not have[who] then
      for _, p in ipairs(ns.NoteProfessions(m.note)) do
        if p == prof then out[#out + 1] = { who = who, note = true } break end
      end
    end
  end
  return out
end

local function listProfession(prof)
  local online, rows, have = onlineNow(), {}, {}
  for who, e in pairs(UW_GuildDB.crafts) do
    local p = e.profs and e.profs[prof]
    local m = UW_GuildDB.members[who]
    if p and not (m and m.left) then rows[#rows + 1] = { who = who, rank = p.r or 0 }; have[who] = true end
  end
  table.sort(rows, function(a, b) return a.rank > b.rank or (a.rank == b.rank and a.who < b.who) end)
  local noted = noteRows(prof, have)
  table.sort(noted, function(a, b)
    local ao, bo = online[a.who] and 1 or 0, online[b.who] and 1 or 0
    return ao > bo or (ao == bo and a.who < b.who)
  end)
  for _, r in ipairs(noted) do rows[#rows + 1] = r end
  if #rows == 0 then ns.say(("No guildmate has shared %s yet, and no guild note names it."):format(prof)) return end
  local parts = {}
  for i = 1, math.min(#rows, 15) do
    local r = rows[i]
    -- Online in green and in words: color alone fails colorblind readers (WCAG 2.2, 1.4.1 Use of Color).
    parts[#parts + 1] = ("%s%s (%s%s)"):format(online[r.who] and "|cff40ff40" or "", r.who,
      r.note and "note" or tostring(r.rank), online[r.who] and ", online" or "") .. (online[r.who] and "|r" or "")
  end
  if #rows > 15 then parts[#parts + 1] = ("and %d more"):format(#rows - 15) end
  ns.say(("%s: %s"):format(prof, table.concat(parts, ", ")))
  if #noted > 0 then
    ns.say("(note) = their guild note names it; they haven't shared recipes yet, so ask what they can make.")
  end
end

local function showOwn()
  local e = UW_GuildDB.crafts[myName()]
  if not sharing() then
    ns.say("You're not sharing professions. Type /uw craft on to list yours in the guild crafting directory.")
    return
  end
  if not e or not next(e.profs) then
    ns.say("No professions recorded for you yet. Train one, then open its window once.")
  else
    for prof, p in pairs(e.profs) do
      local n = 0
      for _ in pairs(p.rec) do n = n + 1 end
      ns.say(("%s %d/%d: %d recipe(s) shared%s"):format(prof, p.r or 0, p.m or 0, n,
        n == 0 and " (open its window once to add them)" or ""))
    end
  end
  local people = 0
  for who in pairs(UW_GuildDB.crafts) do if who ~= myName() then people = people + 1 end end
  ns.say(("Directory: %d guildmate(s). /uw craft <item> finds a crafter, /uw craft <profession> lists them, "
    .. "/uw craft off stops sharing."):format(people))
end

ns.commands.craft = function(args)
  args = strtrim(args or "")
  local word = args:lower()
  if word == "" then showOwn() return end
  if word == "off" then
    UW_GuildCharDB.craftsOff = true
    UW_GuildDB.crafts[myName()] = nil
    markOff(myName(), true)
    if UW_GuildDB.gear then UW_GuildDB.gear[myName()] = nil end
    ns.send("CRX", "GUILD")
    ns.say("Stopped sharing your professions, weapons and talents, and asked online guildmates to forget them. /uw craft on to share again.")
    return
  end
  if word == "check" then
    local a = ns.CraftApis()
    ns.say(("Profession APIs on this client: ranks %s, trade window %s, enchanting window %s."):format(
      a.skills, a.trade, a.craft))
    local g = ns.GearApis and ns.GearApis() or {}
    ns.say(("Weapon plan APIs: weapon skills %s, talents %s, equipped weapons %s, item stats %s."):format(
      g.skills or "no", g.talents or "no", g.equipped or "no", g.stats or "no"))
    if a.skills == "none" or a.trade == "none" then
      ns.say("|cffff8000Something is missing,|r so the crafting directory can't record everything here. " ..
        "Please tell an officer (screenshot this line).")
    else
      ns.say("All good. Open a profession window, then type /uw craft to see what was saved.")
    end
    return
  end
  if word == "on" then
    UW_GuildCharDB.craftsOff = nil
    markOff(myName(), false)
    ns.RefreshProfessions()
    if ns.RefreshGear then pcall(ns.RefreshGear) end
    ns.say("Sharing your professions with the guild. Open each profession window once to add your recipes.")
    return
  end
  local prof = professionMatch(args)
  if prof then listProfession(prof) return end
  local hits = ns.SearchCrafts(args)
  if #hits == 0 then
    ns.say(("Nobody in the directory can make \"%s\" yet. Ask in guild chat, or try part of the name."):format(args))
    return
  end
  local online = onlineNow()
  for i = 1, math.min(#hits, 8) do
    local h = hits[i]
    table.sort(h.crafters, function(a, b)
      local ao, bo = online[a.who] and 1 or 0, online[b.who] and 1 or 0
      return ao > bo or (ao == bo and a.who < b.who)
    end)
    local names = {}
    for j = 1, math.min(#h.crafters, 6) do
      local c = h.crafters[j]
      names[j] = online[c.who] and ("|cff40ff40" .. c.who .. " (online)|r") or c.who
    end
    ns.say(("%s: %s"):format(h.name, table.concat(names, ", ")))
  end
  if #hits > 8 then ns.say(("...and %d more. Type more of the name."):format(#hits - 8)) end
  ns.say("Online now first, in green. Whisper them, or use /uw-ask in Discord.")
end

-- Wiring ---------------------------------------------------------------------------
table.insert(ns.onLoad, function() -- before any event wiring, so nothing below can leave the tables missing
  UW_GuildDB.crafts = UW_GuildDB.crafts or {}
  UW_GuildDB.profPosted = UW_GuildDB.profPosted or {}
  UW_GuildDB.recipeInfo = UW_GuildDB.recipeInfo or {}
  UW_GuildCharDB = UW_GuildCharDB or {}
end)

local f = CreateFrame("Frame")
ns.listen(f, { "SKILL_LINES_CHANGED", "TRADE_SKILL_SHOW", "TRADE_SKILL_UPDATE", "TRADE_SKILL_LIST_UPDATE",
  "TRADE_SKILL_DATA_SOURCE_CHANGED", "CRAFT_SHOW", "CRAFT_UPDATE" })
local scanPending = {}
local function soon(kind, fn) -- the window fires UPDATE many times while it fills; read once it settles
  if scanPending[kind] then return end
  scanPending[kind] = true
  C_Timer.After(1, function()
    scanPending[kind] = nil
    local ok, err = pcall(fn)
    if not ok then ns.say("Couldn't read your professions (" .. tostring(err) .. ").") end
  end)
end
f:SetScript("OnEvent", function(_, event)
  if not UW_GuildDB or not UW_GuildDB.crafts then return end
  if event == "SKILL_LINES_CHANGED" then
    soon("skills", ns.RefreshProfessions)
  elseif event == "CRAFT_SHOW" or event == "CRAFT_UPDATE" then
    soon("craft", function() ns.RecordRecipes(ns.ReadCraft()) end)
  else
    soon("trade", function() ns.RecordRecipes(ns.ReadTradeSkill()) end)
  end
end)

table.insert(ns.onGuildJoin, function()
  ns.afterRoster(function()
    if not ns.tracksGuild() then return end
    if sharing() then
      ns.RefreshProfessions()
      if not UW_GuildCharDB.craftsNoticed then
        UW_GuildCharDB.craftsNoticed = true
        ns.say("Your professions, weapons and talents are shared so guildmates can find a crafter. Open each "
          .. "profession window once to add recipes. /uw craft off stops sharing.")
      end
      local e = UW_GuildDB.crafts[myName()]
      if e and e.at > 0 then
        C_Timer.After(20 + math.random() * 30, function() enqueue({ ("CRV\t%d\t%s"):format(e.at, summary(e)) }) end)
      end
    end
    if ns.isOfficer(ns.me()) then C_Timer.After(25, function() ns.send("CRVQ", "GUILD") end) end
  end)
end)

-- Guild notes (Louis, 8 Nov 2026: a /run loop to set Korvas's and Bong's notes "didn't set"). The old setter takes a
-- roster index, which moves whenever the roster re-sorts, and the roster names people "First Last-Realm", so a loop
-- comparing bare names never matches. /uw note finds the member by name right before setting, prefers the GUID setter,
-- then reads the note back after the next roster update and says whether the game kept it. Public note only: the
-- officer note stays hand-written. Max 31 characters, the game's limit.
ns.NOTE_MAX = 31
local NOTE_WORDS = { -- what members type in guild chat, each to its profession (bot/uwbot/crafting.py NOTE_WORDS)
  alchemy = "Alchemy", alch = "Alchemy", alc = "Alchemy", alchemist = "Alchemy",
  blacksmithing = "Blacksmithing", blacksmith = "Blacksmithing", smithing = "Blacksmithing", smith = "Blacksmithing",
  bs = "Blacksmithing", enchanting = "Enchanting", enchanter = "Enchanting", enchant = "Enchanting", ench = "Enchanting",
  engineering = "Engineering", engineer = "Engineering", engi = "Engineering", eng = "Engineering",
  leatherworking = "Leatherworking", leatherworker = "Leatherworking", leather = "Leatherworking", lw = "Leatherworking",
  tailoring = "Tailoring", tailor = "Tailoring", cooking = "Cooking", cook = "Cooking", firstaid = "First Aid",
  herbalism = "Herbalism", herbalist = "Herbalism", herbing = "Herbalism", herb = "Herbalism", herbs = "Herbalism",
  mining = "Mining", miner = "Mining", skinning = "Skinning", skinner = "Skinning", skin = "Skinning",
  fishing = "Fishing", fish = "Fishing",
  -- More of how members write them (Louis, 8 Nov: "all common abbreviations"). Never "mine": "mine are..." is chat.
  alchy = "Alchemy", alchem = "Alchemy", bsing = "Blacksmithing", enchy = "Enchanting",
  engie = "Engineering", engy = "Engineering", engin = "Engineering", leatherwork = "Leatherworking",
  lwing = "Leatherworking", tail = "Tailoring", tailer = "Tailoring", chef = "Cooking",
  cookin = "Cooking", fa = "First Aid", bandages = "First Aid", herbal = "Herbalism", minin = "Mining",
  minning = "Mining", skinnin = "Skinning", fishin = "Fishing", fisher = "Fishing",
}
-- Not in Forever's professions (max rank 300): read as known, never written to a note.
local NOT_HERE = { jc = true, jewelcrafting = true, jewelcrafter = true, insc = true, inscription = true,
  scribe = true, arch = true, archaeology = true }
-- A word for a profession, plurals too ("skinners").
local function profWord(w)
  return NOTE_WORDS[w] or (#w > 4 and w:sub(-1) == "s" and NOTE_WORDS[w:sub(1, -2)]) or nil
end
-- Professions a guild note names, in order, each once: "Alch/Herb - Heal" -> { "Alchemy", "Herbalism" }. Words after
-- "LF", "need" or "want" are asks, not professions. Same reading as the bot's crafting.note_professions.
local NOTE_STOP = { lf = true, lfm = true, need = true, needs = true, want = true, wants = true, looking = true,
  wtb = true }
function ns.NoteProfessions(note)
  local out, seen = {}, {}
  if type(note) ~= "string" or ns.isSecret(note) then return out end
  for w in note:lower():gsub("first aid", "firstaid"):gmatch("%a+") do
    if NOTE_STOP[w] then break end
    local prof = profWord(w)
    if prof and not seen[prof] then seen[prof] = true; out[#out + 1] = prof end
  end
  return out
end
local SHORT = { Alchemy = "Alch", Blacksmithing = "BS", Enchanting = "Ench", Engineering = "Engi",
  Leatherworking = "LW", Tailoring = "Tailor", Cooking = "Cook", ["First Aid"] = "FA", Herbalism = "Herb",
  Mining = "Mining", Skinning = "Skin", Fishing = "Fish" }
-- Words around the professions in "I'm mining and smithing" or "my profs: herb/alch". Anything else (a question,
-- "anyone", "need", "LF") means the line isn't someone saying what they do, so it never writes a note.
local FILLER = { i = true, im = true, ["i'm"] = true, my = true, profs = true, professions = true, prof = true,
  ["and"] = true, is = true, are = true, am = true, doing = true, ["do"] = true, got = true, have = true, both = true,
  main = true, going = true, ["for"] = true, now = true, rn = true }

-- Words that make a line about someone else's professions: "LF engi", "need a tailor", "anyone mining".
local ASKING = { lf = true, lfw = true, lfm = true, need = true, want = true, wtb = true, anyone = true, any = true,
  who = true, looking = true }
-- Professions a guild chat line states, or nil: "mining and smithing" -> { "Mining", "Blacksmithing" }. loose: just
-- after an officer asked for professions (Louis, 8 Nov: "Ohhh damn yeah i'm doing engi and mining cooking first aid"),
-- so other words are fine; otherwise every word must be a profession or filler.
function ns.ChatProfessions(msg, loose)
  if type(msg) ~= "string" or ns.isSecret(msg) or msg:find("?", 1, true) then return nil end
  local words, out, seen = 0, {}, {}
  for w in msg:lower():gsub("first[%s%-]?aid", "firstaid"):gsub("[%d/&+,:;.!%-]", " "):gmatch("%S+") do
    words = words + 1
    local prof = profWord(w)
    if prof then
      if not seen[prof] then seen[prof] = true; out[#out + 1] = prof end
    elseif ASKING[w] or not (loose or FILLER[w]) then return nil end
  end
  if #out == 0 or words > (loose and 20 or 10) then return nil end
  return out
end
-- The note for those professions: full names when they fit, else the short ones the bot also reads.
-- Words a whispered answer can carry around its professions: "yeah I'm doing herb and alch, thanks!".
local REPLY_FILLER = { yes = true, yeah = true, yep = true, ya = true, yea = true, sure = true, ok = true, okay = true,
  k = true, thanks = true, thank = true, you = true, ty = true, thx = true, pls = true, please = true, plz = true,
  hi = true, hey = true, hello = true, lol = true, haha = true, also = true, plus = true, with = true, a = true,
  an = true, the = true, currently = true, leveling = true, levelling = true, just = true, only = true, x = true,
  n = true, to = true, so = true, far = true, atm = true, picked = true, took = true, taking = true, chose = true,
  went = true, gonna = true, will = true, probably = true, prob = true, maybe = true, ill = true, ["i'll"] = true,
  too = true, as = true, well = true, them = true, it = true, on = true, primary = true, secondary = true,
  mains = true, profession = true, prefs = true, cool = true, nice = true, ["i've"] = true, ive = true,
  learned = true, learning = true, started = true, starting = true, level = true, lvl = true, low = true,
  high = true, both = true, rn = true, now = true, me = true }
-- Words that flip an answer ("not mining", "I dropped herb", "on my alt"): never a note from those.
local NEGATE = { no = true, ["not"] = true, nope = true, dont = true, ["don't"] = true, didnt = true, ["didn't"] = true,
  never = true, hate = true, hated = true, quit = true, quitting = true, dropped = true, dropping = true, drop = true,
  unlearned = true, unlearn = true, was = true, used = true, alt = true, alts = true, ["or"] = true,
  instead = true, without = true }
-- Where an answer moves on from what they do now: "mining+skinning however, at 60 ill be mining+engineering",
-- "tailor is low, only 58, but working on it". Only the first part that names a profession is read.
local CLAUSE_WORDS = { "however", "but", "though", "although", "later", "eventually", "then", "once", "until", "after",
  "when" }
local CLAUSE_PHRASES = { "at%s+%d+", "i'?ll be", "will be", "gonna be", "going to be", "planning", "plan to" }
-- The professions a whispered answer to our ask names, or nil and whether it looked like an answer (worth a hint).
-- Stricter than guild chat: in the part read, every word is a profession, filler or one of at most two others, never
-- a question, a negation or an ask. "Mining, Herbalism", "bs/mining", "prof herb alch", "yeah engi and mining :)",
-- "sure ! im currently mining+skinning however, at 60 ill be mining+engineering" (Louis's log, 8 Nov) all count.
function ns.ReplyProfessions(msg)
  if type(msg) ~= "string" or ns.isSecret(msg) then return nil, false end
  local text = msg:lower():gsub("1st[%s%-]?aid", "firstaid"):gsub("first[%s%-]?aid", "firstaid")
  for _, p in ipairs(CLAUSE_PHRASES) do text = text:gsub(p, "\2") end
  for _, w in ipairs(CLAUSE_WORDS) do text = text:gsub("%f[%a]" .. w .. "%f[%A]", "\2") end
  text = text:gsub("[.;!]", "\2")
  local looked = false
  for clause in (text .. "\2"):gmatch("([^\2]*)\2") do
    local part = clause:gsub("(%a)'(%a)", "%1\1%2"):gsub("[\"'%d/&+,:%-%(%)%*~<>=_|]", " "):gsub("\1", "'")
    local out, seen, other, words, flipped = {}, {}, 0, 0, false
    for w in part:gmatch("[^%s%?]+") do
      words = words + 1
      -- "mine" is Mining after another word ("eng/mine"), chat first ("mine are herb and alch").
      local prof = profWord(w) or (w == "mine" and words > 1 and "Mining") or nil
      if prof then
        if not seen[prof] then seen[prof] = true; out[#out + 1] = prof end
      elseif w == "prof" or w == "profs" or w == "professions" then looked = true
      elseif NEGATE[w] or ASKING[w] then flipped = true
      elseif not (FILLER[w] or REPLY_FILLER[w] or NOT_HERE[w] or w == "mine") then other = other + 1 end
    end
    if #out > 0 then
      if flipped or clause:find("?", 1, true) or other > 2 or words > 20 then return nil, true end
      return out
    end
  end
  return nil, looked
end
function ns.ProfessionNote(profs)
  local text = table.concat(profs, " ")
  if #text <= ns.NOTE_MAX then return text end
  local short = {}
  for i, p in ipairs(profs) do short[i] = SHORT[p] or p end
  return table.concat(short, " "):sub(1, ns.NOTE_MAX)
end

local function plain(v) return type(v) == "string" and not ns.isSecret(v) and v or nil end
-- The roster row for a name typed as "Korvas", "Korvas Soulless" or "Korvas Soulless-Realm": index, full name, note,
-- GUID. A first name two members share returns nil and "several".
local function findMember(want)
  want = strtrim(want or ""):lower()
  if want == "" then return nil end
  local hit, count
  for i = 1, GetNumGuildMembers() do
    local full, _, _, _, _, _, note, _, online, _, _, _, _, _, _, _, guid = GetGuildRosterInfo(i)
    full = plain(full)
    if full then
      local short = ns.shortName(full):lower()
      local row = { i = i, full = full, note = plain(note) or "", guid = plain(guid), online = online == true }
      if full:lower() == want or short == want then return row end
      if short:match("^(%S+)") == want then hit, count = row, (count or 0) + 1 end
    end
  end
  if count == 1 then return hit end
  return nil, count and "several"
end
local function canEdit()
  if C_GuildInfo and C_GuildInfo.CanEditPublicNote then return C_GuildInfo.CanEditPublicNote() == true end
  return CanEditPublicNote and CanEditPublicNote() == true
end
local checks = {}
-- Forever (Louis's client, 8 Nov 2026): no addon can set a public note. C_GuildInfo.SetNote is protected even when
-- called straight from a button click (5x ADDON_ACTION_FORBIDDEN, 20:02), and GuildRosterSetPublicNote isn't in the
-- client. Only Blizzard's own roster saves a note (J, Roster, the member, Public Note). Never call C_GuildInfo.SetNote.
-- So on Forever the addon lists the notes to set and notices them once set (ns.SettleNotes). The index setter below
-- runs only on clients that have it; there the note is read at 3 s, then after a fresh roster at 15 s.
ns.CanSetNotes = function() return GuildRosterSetPublicNote ~= nil end
local SETTERS = {
  function(row, text)
    if not GuildRosterSetPublicNote then return nil end
    return pcall(GuildRosterSetPublicNote, row.i, text)
  end,
}
-- The by-hand step for one note, in Blizzard's roster.
function ns.NoteStep(shown, text)
  if text == "" then return ("Press J, Roster, click %s, then Public Note, and clear it."):format(shown) end
  return ("Press J, Roster, click %s, then Public Note, and type: %s"):format(shown, text)
end
local function refresh() if C_GuildInfo and C_GuildInfo.GuildRoster then C_GuildInfo.GuildRoster() end end
-- Sets row's public note and says whether it stuck. quiet: from guild chat, so only the result prints. onKept runs
-- once the roster shows the note, onLost when no setter made it stick. Returns true when a setter took the call.
-- After one note this session didn't stick, ns.notesStick is false. The decision log says why: "no setter" (none in
-- this client), "refused" (it raised an error) or "not kept" (it ran and the roster never showed the note).
function ns.SetGuildNote(row, text, quiet, onKept, onLost)
  text = strtrim(text or ""):gsub("%c", " "):sub(1, ns.NOTE_MAX)
  local shown = ns.shortName(row.full)
  local function byHand(why)
    if why then ns.say(("%s: %s's note still reads \"%s\"."):format(why, shown, row.note)) end
    ns.say(ns.NoteStep(shown, text))
  end
  local why = "no setter"
  local function try(n)
    local setter = SETTERS[n]
    if not setter then
      byHand(why ~= "no setter" and "The game didn't keep it" or nil)
      -- Not a code error (no red line): the decision log keeps the reason.
      if ns.trace then ns.trace("notes", "set", false, why, row.full) end
      ns.notesStick = false
      if onLost then onLost() end
      return false
    end
    local ok, err = setter(row, text)
    if ok == nil then return try(n + 1) end
    if not ok then
      why = "refused: " .. tostring(err):sub(1, 80)
      ns.protect(error, "guild note refused: " .. tostring(err):sub(1, 120), 0)
      return try(n + 1)
    end
    why = "not kept"
    checks[row.full] = text
    refresh()
    local function look(final)
      if checks[row.full] ~= text then return end
      local now = findMember(row.full)
      if not now then checks[row.full] = nil return end
      if now.note == text then
        checks[row.full] = nil
        ns.say(("%s's note now reads \"%s\"."):format(shown, text))
        if ns.trace then ns.trace("notes", "set", true, nil, row.full) end
        ns.notesStick = true
        if onKept then onKept() end
      elseif final then
        checks[row.full] = nil
        row = now
        try(n + 1)
      end
    end
    C_Timer.After(3, function()
      look(false)
      C_Timer.After(8, function()
        if checks[row.full] ~= text then return end
        refresh()
        C_Timer.After(4, function() look(true) end)
      end)
    end)
    return true
  end
  if not quiet and ns.CanSetNotes() then ns.say(("Setting %s's note to \"%s\"..."):format(shown, text)) end
  return try(1)
end

-- /uw note <name> <text>: GM and officers (any rank the game lets edit public notes). /uw note apply: the notes
-- replies are waiting for (the same as the button above chat). /uw note auto on|off (off at first). On Forever no addon
-- can set a note, so /uw note <name> <text> adds it to that list with the by-hand step.
ns.commands.note = function(args)
  args = strtrim(args or "")
  local word = args:lower()
  if word == "auto off" or word == "auto on" then
    UW_GuildDB.noteAuto = word == "auto on" or nil
    if word == "auto on" then ns.say("On. For 10 minutes after you ask for professions in guild chat, replies there are queued for their notes.")
    else ns.say("Off. Guild chat replies no longer queue notes; whispers still do.") end
    return
  end
  if word == "apply" then ns.ApplyNotes() return end
  if word == "test" or word:match("^test%s") then ns.NoteTest(strtrim(args:sub(5))) return end
  if not canEdit() then ns.say("Your rank can't edit public notes in this guild.") return end
  -- The name is one word, or two ("Korvas Soulless"): two when the first two words name someone.
  local a, b, rest = args:match("^(%S+)%s*(%S*)%s*(.-)$")
  if not a then ns.say("Type /uw note <name> <text>, for example /uw note Korvas Mining Blacksmithing.") return end
  local row = b ~= "" and findMember(a .. " " .. b)
  local text = rest
  if not row then row, text = findMember(a), strtrim(b .. " " .. rest) end
  if not row then ns.say(("No guild member named %s. Use their full name if two share it."):format(a)) return end
  if not ns.CanSetNotes() then
    text = strtrim(text):gsub("%c", " "):sub(1, ns.NOTE_MAX)
    if row.note == text then ns.say(("%s's note already reads \"%s\"."):format(ns.shortName(row.full), text)) return end
    ns.QueueNote(row, text, nil, "typed", true)
    ns.say(ns.NoteStep(ns.shortName(row.full), text))
    return
  end
  ns.SetGuildNote(row, text, false, function()
    local waiting = UW_GuildDB.notePending
    if waiting and waiting[row.full] then ns.SettleNotes(); ns.UpdateNoteButton() end
  end)
end

-- Notes from replies ------------------------------------------------------------
-- On Forever no addon can set a public note (SETTERS above). So a reply waits in UW_GuildDB.notePending[full] =
-- { text, at, who, tell? } (text "" = clear), saved across /reload, and the button above chat lists what to set in
-- the roster. Once the roster shows the note (set by hand), it leaves the list and the member hears "Added ...". The member hears once, when the reply is read, what will be
-- added and how to undo it (CONTRIBUTING.md, "Never quietly turn chat into data"). Never overwrites a note someone
-- set meanwhile, never touches the officer note.
local function whisper(to, msg)
  local send = (C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage
  if send then pcall(send, msg, "WHISPER", nil, to) end
end
local function filled() UW_GuildDB.noteFilled = UW_GuildDB.noteFilled or {} return UW_GuildDB.noteFilled end
local function pending()
  UW_GuildDB.notePending = type(UW_GuildDB.notePending) == "table" and UW_GuildDB.notePending or {}
  return UW_GuildDB.notePending
end
local function trace(what, ok, why, who) if ns.trace then ns.trace("notes", what, ok, why, who) end end
-- "Added ..." whispers for members who were offline when their note was set: UW_GuildDB.noteTell[full] = { msg, at },
-- sent the first roster update they're online (a whisper to someone offline is lost: "No player named ...", Louis's
-- log 8 Nov 20:13), dropped after 14 days.
local function tells() UW_GuildDB.noteTell = type(UW_GuildDB.noteTell) == "table" and UW_GuildDB.noteTell or {} return UW_GuildDB.noteTell end
local function tellWhenOnline(row, msg)
  if row and row.online then whisper(row.full, msg) return end
  tells()[row and row.full or "?"] = { msg = msg, at = time() }
end
-- The 4 of Louis's 8 Nov replies set by hand at 20:13 while offline: their "Added" whisper was lost. Once, GM's client.
ns.NOTE_TELL_SEED = { ["Chunky Souphead"] = "Skinning Leatherworking", ["Sharaa Ishvalda"] = "Skinning Leatherworking",
  ["Rethalia Lumenfall"] = "Blacksmithing Mining", ["Svepa Zeth"] = "Tailoring Enchanting" }
local function sendTells()
  local t = UW_GuildDB.noteTell
  if not UW_GuildDB.noteTellSeeded and ns.shortName(ns.me() or "") == ns.NOTE_SEED_FOR then
    UW_GuildDB.noteTellSeeded = true
    for name, text in pairs(ns.NOTE_TELL_SEED) do
      local row = findMember(name)
      if row and row.note == text then
        tells()[row.full] = { msg = ("Added %s to your guild note. Whisper 'clear note' anytime to undo."):format(text),
          at = time() }
      end
    end
    t = UW_GuildDB.noteTell
  end
  if type(t) ~= "table" then return end
  for full, w in pairs(t) do
    local row = type(w) == "table" and type(w.msg) == "string" and findMember(full)
    if type(w) ~= "table" or time() - (tonumber(w.at) or 0) > ns.NOTE_GONE_AFTER then
      t[full] = nil
    elseif row and row.online then
      t[full] = nil
      whisper(row.full, w.msg)
      trace("tell", true, "sent", full)
    end
  end
  if not next(t) then UW_GuildDB.noteTell = nil end
end
-- The entry for full is done: its note reads the waiting text. A member who was told "an officer will add it" (tell)
-- now hears it's there, once: now if online, else when they next are.
local function settle(full, e, row)
  pending()[full] = nil
  filled()[full] = e.text ~= "" and e.text or nil
  trace("apply", true, "saved", full)
  if e.tell and e.text ~= "" and type(e.who) == "string" then
    tellWhenOnline(row, ("Added %s to your guild note. Whisper 'clear note' anytime to undo."):format(e.text))
  end
end
-- Drops the entries the roster shows done (set by hand in the roster), or no longer able to apply.
-- Returns the ones still to set, oldest first, each with its roster row. A member
-- not in the roster keeps waiting (a roster still loading), and is dropped after 14 days (left the guild).
ns.NOTE_GONE_AFTER = 14 * 86400 -- also how long an "Added" whisper waits for an offline member
function ns.SettleNotes()
  local p, left = pending(), {}
  for full, e in pairs(p) do
    local row = type(e) == "table" and type(e.text) == "string" and findMember(full)
    if type(e) ~= "table" or type(e.text) ~= "string" then
      p[full] = nil
    elseif e.test then
      p[full] = nil -- a /uw note test entry from before 8 Nov 20:00: tests no longer queue
    elseif not row then
      if GetNumGuildMembers() > 0 and time() - (tonumber(e.at) or 0) > ns.NOTE_GONE_AFTER then
        p[full] = nil
        trace("apply", false, "not in roster", full)
      end
    elseif e.text ~= "" and row.note == e.text then
      settle(full, e, row)
    elseif e.text ~= "" and row.note ~= "" and not e.test then
      p[full] = nil
      trace("apply", false, "note set meanwhile", full)
    elseif e.text == "" and not e.test and (row.note == "" or row.note ~= filled()[full]) then
      p[full] = nil
      if row.note == "" then filled()[full] = nil end
    else
      left[#left + 1] = { full = full, e = e, row = row }
    end
  end
  table.sort(left, function(x, y) return (tonumber(x.e.at) or 0) < (tonumber(y.e.at) or 0) end)
  sendTells()
  return left
end

-- Replies from Louis's log (8 Nov, 09:09-09:20) that came before this queue: the game dropped each, and the members
-- were told an officer would add it. Queued once, on the GM's client, so the notes list keeps that promise; each hears
-- "Added ..." once it saves. Jedi Neight's was set by hand.
ns.NOTE_SEED = { ["Chunky Souphead"] = "Skinning Leatherworking", ["Sharaa Ishvalda"] = "Skinning Leatherworking",
  ["Rethalia Lumenfall"] = "Blacksmithing Mining", ["Svepa Zeth"] = "Tailoring Enchanting",
  ["Morticus Voidsworn"] = "Tailoring Enchanting", ["Ronswizz Swizzle"] = "Tailoring Enchanting",
  ["Moro Deepwater"] = "Herbalism Alchemy", ["Sigma Five"] = "Leatherworking", ["Prazz Hornbreaker"] = "Mining Skinning" }
ns.NOTE_SEED_FOR = "Sora Silva"
local function seed()
  if UW_GuildDB.noteSeeded or ns.shortName(ns.me() or "") ~= ns.NOTE_SEED_FOR or GetNumGuildMembers() == 0 then return end
  UW_GuildDB.noteSeeded = true
  local p = pending()
  for name, text in pairs(ns.NOTE_SEED) do
    local row = findMember(name)
    local full = row and row.full or name
    if not p[full] and (not row or row.note == "") then
      p[full] = { text = text, at = time(), who = name, tell = true }
    end
  end
end

-- The notes button, above the chat box while notes wait. A click lists them (ns.ApplyNotes).
function ns.UpdateNoteButton()
  seed()
  local n = GetNumGuildMembers() > 0 and #ns.SettleNotes() or 0
  local b = ns.noteButton
  if n == 0 or not canEdit() then
    if b then b:Hide() end
    return
  end
  if not b then
    b = CreateFrame("Button", "UWGuildApplyNotes", UIParent, "UIPanelButtonTemplate")
    b:SetSize(190, 24)
    b:SetPoint("BOTTOMLEFT", _G.ChatFrame1 or UIParent, "TOPLEFT", 0, 30)
    b:SetScript("OnClick", function() ns.protect(ns.ApplyNotes) end)
    ns.useButton(b, "apply notes")
    ns.noteButton = b
  end
  b.label = n == 1 and "1 guild note to set" or ("%d guild notes to set"):format(n)
  b:SetText(b.label)
  b:Show()
end

-- Queues text for row (who: the member, to whisper). False when the same text already waits.
local function queue(row, text, who, what, silent)
  local p = pending()
  if p[row.full] and p[row.full].text == text then return false end
  p[row.full] = { text = text, at = time(), who = who }
  trace(what, true, "queued", row.full)
  if not silent then
    ns.say(text == "" and ("%s asked to clear their note. It's on the notes list above chat."):format(ns.shortName(row.full))
      or ("%s: \"%s\" is on the notes list above chat."):format(ns.shortName(row.full), text))
  end
  ns.UpdateNoteButton()
  return true
end
ns.QueueNote = queue

-- The button and /uw note apply: lists the notes to set, oldest first, with the by-hand step. No addon call sets a
-- note on Forever; each leaves the list once the roster shows it (and the member hears "Added ...").
-- /uw lead's Notes tab (Lead.lua draws it): one row per note, Copy puts it in a selected box for Ctrl+C, Skip drops
-- it. The same data as the chat list.
function ns.NotesView()
  local v = { head = {}, rows = {}, copy = true, actions = {} }
  if not canEdit() then v.head[1] = "Your rank can't edit public notes in this guild." return v end
  local left = GetNumGuildMembers() > 0 and ns.SettleNotes() or {}
  if #left == 0 then
    v.head[1] = "|cffffd100No guild notes to set.|r Replies to a professions ask show up here."
    return v
  end
  v.head[1] = ("|cffffd100%d guild note%s to set.|r Copy, then in the roster: J, Roster, click the name, Public Note, "
    .. "Ctrl+V, Enter."):format(#left, #left == 1 and "" or "s")
  v.head[2] = "|cff808080Each leaves this list once the roster shows it, and the member hears it's there.|r"
  for _, w in ipairs(left) do
    local shown, text = ns.shortName(w.full), w.e.text
    v.rows[#v.rows + 1] = {
      text = text == "" and ("%s: |cff808080clear the note|r"):format(shown) or ("%s: %s"):format(shown, text),
      b1 = { "Copy", function()
        if ns.Lead and ns.Lead.Copy then ns.Lead.Copy(text ~= "" and text or shown) end
        trace("copy", true, nil, w.full)
      end },
      b2 = { "Skip", function()
        pending()[w.full] = nil
        trace("skip", true, nil, w.full)
        ns.UpdateNoteButton()
      end },
    }
  end
  return v
end

function ns.ApplyNotes()
  if not canEdit() then ns.say("Your rank can't edit public notes in this guild.") return end
  -- The button opens the Notes tab when /uw lead can open (officers, out of combat); else the list prints here.
  if ns.Lead and ns.Lead.OpenTab and ns.Lead.OpenTab("notes", true) then return end
  local left = ns.SettleNotes()
  ns.UpdateNoteButton()
  if #left == 0 then ns.say("No guild notes waiting.") return end
  ns.say(("%d guild note%s to set: press J, Roster, click the name, then Public Note. Each leaves this list once it "
    .. "shows, and the member hears it's there."):format(#left, #left == 1 and "" or "s"))
  for _, w in ipairs(left) do
    ns.say(w.e.text == "" and ("%s: clear it"):format(ns.shortName(w.full))
      or ("%s: %s"):format(ns.shortName(w.full), w.e.text))
  end
  trace("list", true, tostring(#left), nil)
end

-- Asking -------------------------------------------------------------------------
-- One standard ask: "Reply with them, like: Mining Herbalism". Replies are the profession names or their usual
-- abbreviations (ns.ReplyProfessions), "prof" in front optional. It goes out a moment after the join whisper
-- (Onboarding.lua) and from /uw nudge notes, once ever per member, from an officer whose rank can edit notes. An
-- officer's own guild line naming "professions" asks everyone ("Whisper me your professions...", Louis 8 Nov). A
-- whisper back naming professions within the window is an answer to that direct ask. Officers share each personal
-- ask as NPA on GUILD, so nobody is asked twice.
ns.PROF_ASK_LINE = "Your professions? Reply with them, like: Mining Herbalism, and I'll add them to your guild note."
ns.PROF_NUDGE = "Hi %s! Want your professions in your guild note, so guildmates can find your crafts? Reply with "
  .. "them, like: Mining Herbalism. I'll only ask this once."
ns.PROF_REPLY_WINDOW = 3600       -- a personal ask
ns.PROF_GUILD_ASK_WINDOW = 6 * 3600 -- the officer's guild-chat ask (Louis posts it about twice a day)
ns.NOTE_ASK_WINDOW = 600          -- guild chat replies to it, with /uw note auto on
ns.NUDGE_RUN = 25 -- whispers per /uw nudge notes
ns.NUDGE_GAP = 2  -- seconds between them
ns.NUDGE_QUIET = 86400 -- skip anyone whispered the Discord ask this recently: one whisper a day at most
local function profAsked()
  UW_GuildDB.profAsked = type(UW_GuildDB.profAsked) == "table" and UW_GuildDB.profAsked or {}
  return UW_GuildDB.profAsked
end
local function askKey(name)
  local full = ns.fullName(name)
  return full and ns.shortName(full)
end
-- Records an ask sent from here: replies within the window count, and other officers skip them.
local function markAsked(key)
  profAsked()[key] = time()
  ns.officerSend("NPA\t" .. key, "GUILD")
end
ns.handlers.NPA = function(sender, channel, name)
  if channel ~= "GUILD" or not ns.isOfficer(sender) or type(name) ~= "string" or #name > 60 then return end
  local key = askKey(name)
  -- false: asked by another officer, so their reply goes to them, never here.
  if key and profAsked()[key] == nil then profAsked()[key] = false end
end
-- After the join whisper (Onboarding.lua onJoin, which already skips rejoiners), its own whisper: when this client
-- can edit notes, the member wasn't asked and their note is empty. True when one was queued.
ns.PROF_JOIN_DELAY = 5
function ns.ProfJoinAsk(key, delay)
  if not key or not canEdit() or profAsked()[key] ~= nil or (ns.quiet and ns.quiet(key)) then return false end
  local row = findMember(key)
  if row and row.note ~= "" then return false end
  markAsked(key)
  C_Timer.After(delay or 0, function() whisper(key, ns.PROF_ASK_LINE) end)
  return true
end
local function guildAskOpen(window)
  local at = tonumber(UW_GuildDB.noteGuildAskAt)
  return at ~= nil and time() - at <= window
end
-- A whisper answering an ask. True when it was one (handled, so nothing else reads it). A reply that names
-- professions but can't be read safely ("not mining", "alt has herb?") gets one hint; other whispers ("thanks for the
-- invite!") pass through untouched. Each member hears one answer per thing they asked for.
local hinted, told = {}, {}
local function tell(sender, key, msg)
  if told[key] == msg then return end
  told[key] = msg
  whisper(sender, msg)
end
function ns.ProfReply(msg, sender)
  if ns.WhisperWord and ns.WhisperWord(msg) then return false end -- help, idea, stop, start: Onboarding.lua
  local key = askKey(sender)
  if not key or not canEdit() then return false end
  local at = profAsked()[key]
  local personal = type(at) == "number" and time() - at <= ns.PROF_REPLY_WINDOW
  if not personal and not guildAskOpen(ns.PROF_GUILD_ASK_WINDOW) then
    if ns.ReplyProfessions(msg) then trace("whisper reply", false, "not asked", key) end
    return false
  end
  local profs, looked = ns.ReplyProfessions(msg)
  if not profs then
    if not looked or hinted[key] then return false end
    hinted[key] = true
    trace("whisper reply", false, "unreadable", key)
    whisper(sender, "I couldn't read that one. Reply with just your professions, like: Mining Herbalism")
    return true
  end
  local text = ns.ProfessionNote(profs)
  local row = findMember(sender) or findMember((sender:gsub("%-[^-]*$", "")))
  if not row then trace("whisper reply", false, "not in roster", key) return false end
  if row.note == text then tell(sender, key, ("Your guild note already reads %s."):format(text)) return true end
  if row.note ~= "" then
    trace("whisper reply", false, "note not empty", row.full)
    tell(sender, key, ("Your guild note already reads \"%s\", so I left it. Whisper an officer to change it.")
      :format(row.note))
    return true
  end
  if queue(row, text, sender, "whisper reply") then
    tell(sender, key, ("Thanks! Adding %s to your guild note. Whisper 'clear note' anytime to undo."):format(text))
  end
  return true
end

-- "clear note": a note the addon filled, still as it filled it, or one still waiting.
local function clearNote(msg, sender)
  if not msg:lower():find("clear note", 1, true) then return end
  local row = findMember(sender) or findMember((sender:gsub("%-[^-]*$", "")))
  if not row then return end
  local key, p = askKey(sender) or row.full, pending()
  local waiting = p[row.full]
  if waiting and waiting.text ~= "" then
    p[row.full] = nil
    ns.UpdateNoteButton()
    tell(sender, key, "Done, I won't add it.")
    return
  end
  local was = UW_GuildDB.noteFilled and UW_GuildDB.noteFilled[row.full]
  if not was then return end
  if row.note ~= was then
    UW_GuildDB.noteFilled[row.full] = nil
    tell(sender, key, "Your note changed since, so I left it as it is.")
  elseif not canEdit() then
    tell(sender, key, "I couldn't clear it from here, so an officer will.")
    ns.say(("%s asked to clear their note. Set it by hand: press J, Roster, click %s, then clear Public Note.")
      :format(ns.shortName(row.full), ns.shortName(row.full)))
  elseif queue(row, "", sender, "clear note") then
    tell(sender, key, "OK, clearing your guild note.")
  end
end

-- /uw nudge notes: whisper online guildmates with an empty public note, once each ever, NUDGE_RUN per run.
local function toNudge()
  local out, done, discord, me = {}, profAsked(), UW_GuildDB.discordAsked or {}, ns.me()
  for i = 1, GetNumGuildMembers() or 0 do
    local full, _, _, _, _, _, note, _, online = GetGuildRosterInfo(i)
    local key = askKey(plain(full))
    local d = key and discord[key]
    if key and key ~= me and online and (plain(note) or "") == "" and done[key] == nil and not ns.isOfficer(key)
      and not ns.quiet(key) and not (type(d) == "number" and time() - d < ns.NUDGE_QUIET) then
      out[#out + 1] = key
    end
  end
  table.sort(out)
  return out
end
ns.commands.nudge = function(args)
  args = strtrim(args or ""):lower()
  if args ~= "notes" then
    ns.say("/uw nudge notes asks guildmates online with an empty guild note for their professions, once each ever.")
    return
  end
  if not canEdit() then ns.say("Your rank can't edit public notes in this guild, so their replies couldn't fill them.") return end
  local todo = toNudge()
  if #todo == 0 then ns.say("Everyone online has a note, was asked already, or had a whisper today.") return end
  local n = math.min(#todo, ns.NUDGE_RUN)
  for i = 1, n do
    local key = todo[i]
    markAsked(key)
    C_Timer.After(ns.NUDGE_GAP * (i - 1), function()
      whisper(key, ns.PROF_NUDGE:format(key:match("^(%S+)") or key))
    end)
  end
  ns.say(("Asking %d guildmates for their professions over %d s, once each. Replies go on the notes list above chat.")
    :format(n, ns.NUDGE_GAP * n) .. (#todo > n and (" %d more: /uw nudge notes again after."):format(#todo - n) or ""))
end

-- Professions members picked from a list under /link in Discord (bot/uwbot/profpick.py; Louis, 8 Nov 2026: "give them
-- exactly what we want"). Only on the bot PC: the bot writes them into Schedule.lua as ns.NOTE_PICKS =
-- { { "Full Name", pickedAt, "Alchemy", "Herbalism" }, ... }. Each pick is queued once (UW_GuildDB.notePicksDone keeps
-- its time; a newer pick queues again) like a whispered answer, so it joins the officer's notes-to-set list. Nothing is
-- whispered: Discord already told them. Only an empty note takes a pick: a note someone wrote is never replaced (and
-- SettleNotes drops a wait whose note changed meanwhile), so the officer sees it in the roster instead.
function ns.TakeNotePicks()
  local picks = ns.NOTE_PICKS
  if type(picks) ~= "table" or not canEdit() then return 0 end
  UW_GuildDB.notePicksDone = type(UW_GuildDB.notePicksDone) == "table" and UW_GuildDB.notePicksDone or {}
  local done, n = UW_GuildDB.notePicksDone, 0
  for _, e in ipairs(picks) do
    local name, at = type(e) == "table" and e[1], type(e) == "table" and tonumber(e[2])
    local row = type(name) == "string" and at and done[name] ~= at and findMember(name)
    if row and not checks[row.full] then
      done[name] = at
      local profs = {}
      for i = 3, 4 do if type(e[i]) == "string" and e[i] ~= "" then profs[#profs + 1] = e[i] end end
      if row.note == "" and #profs > 0 and queue(row, ns.ProfessionNote(profs), nil, "discord pick") then n = n + 1 end
    end
  end
  return n
end

local askedAt = -math.huge -- the officer's guild ask, for guild chat replies (GetTime)
local nf = CreateFrame("Frame")
ns.listen(nf, { "CHAT_MSG_GUILD", "CHAT_MSG_WHISPER", "PLAYER_ENTERING_WORLD", "GUILD_ROSTER_UPDATE" })
local settledAt = 0
nf:SetScript("OnEvent", function(_, event, msg, sender)
  ns.protect(function()
    if not UW_GuildDB then return end
    if event == "PLAYER_ENTERING_WORLD" then C_Timer.After(10, ns.UpdateNoteButton) return end
    -- A note set by hand shows in the roster: settle it (and say "Added ...", or hold it for an offline member) at
    -- most every 30 s.
    if event == "GUILD_ROSTER_UPDATE" then
      if ns.NOTE_PICKS and GetTime() - settledAt >= 30 then ns.TakeNotePicks() end
      local p, t = UW_GuildDB.notePending, UW_GuildDB.noteTell
      local waits = (type(p) == "table" and next(p)) or (type(t) == "table" and next(t))
      if waits and GetTime() - settledAt >= 30 then settledAt = GetTime(); ns.UpdateNoteButton() end
      return
    end
    if not plain(sender) or not plain(msg) then return end
    if event == "CHAT_MSG_WHISPER" then
      if ns.ProfReply(msg, sender) then return end
      clearNote(msg, sender)
      return
    end
    if ns.shortName(sender) == ns.shortName(ns.me()) then
      if msg:lower():find("profession", 1, true) and canEdit() then
        askedAt, UW_GuildDB.noteGuildAskAt = GetTime(), time()
      end
      return
    end
    -- Guild chat replies to the ask, with /uw note auto on: only those, never a line nobody asked for (Louis, 8 Nov:
    -- things that appear unannounced spook members).
    if not UW_GuildDB.noteAuto or not canEdit() or GetTime() - askedAt > ns.NOTE_ASK_WINDOW then return end
    local profs = ns.ChatProfessions(msg, true)
    if not profs then return end
    local row = findMember(sender) or findMember((sender:gsub("%-[^-]*$", "")))
    if not row or row.note ~= "" or checks[row.full] then return end
    local text = ns.ProfessionNote(profs)
    if queue(row, text, sender, "chat reply") then
      tell(sender, askKey(sender) or row.full,
        ("Thanks! Adding %s to your guild note. Whisper 'clear note' anytime to undo."):format(text))
    end
  end)
end)

-- /uw note test [reply]: the reply path on your own character, nothing whispered, no note touched (Louis, 8 Nov:
-- "help me test this before whispering anyone"; actions run via addon commands we can track and log). Your guild ask,
-- the reply read as a member's ("herb, alch" if none), and what the member would hear. Each step is in the trace.
function ns.NoteTest(reply)
  if not canEdit() then ns.say("Your rank can't edit public notes in this guild.") return end
  local me = findMember(ns.me() or "")
  if not me then ns.say("Your own roster row isn't loaded yet. Open the guild roster (J), then try again.") return end
  if reply:lower() == "clear" then
    local p = pending()
    if p[me.full] and p[me.full].test then p[me.full] = nil end
    UW_GuildDB.noteTestWas = nil
    ns.say("Nothing to undo: the test changes no note.")
    ns.UpdateNoteButton()
    return
  end
  if reply == "" then reply = "herb, alch" end
  ns.say("Test 1/3: a guild line of yours with \"professions\" in it opens a 6-hour ask: whispers back count.")
  local profs = ns.ReplyProfessions(reply)
  if not profs then
    trace("test", false, "unreadable", me.full)
    ns.say(("Test 2/3: \"%s\" doesn't read as professions, so a member would get one hint to try again."):format(reply))
    return
  end
  local text = ns.ProfessionNote(profs)
  trace("test", true, "read " .. text, me.full)
  ns.say(("Test 2/3: the whisper \"%s\" reads as \"%s\"."):format(reply, text))
  ns.say(("Test 3/3: a member would hear \"Thanks! Adding %s to your guild note.\" It goes on the list above chat "
    .. "for you to set in the roster."):format(text))
end

