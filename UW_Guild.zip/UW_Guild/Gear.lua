-- Weapon picture for crafting recommendations (v0.8). Each member's own client reads, from the game itself:
-- weapon skills (what the character can use), talent points per tree (their spec), and the item level of the main hand
-- and ranged weapons they have equipped (so only an upgrade is suggested). Shared with the guild like the crafting
-- directory, under the same opt-out (/uw craft off). UW_GuildDB.gear[name] = { at, tal, mh, rg, sk }:
--   tal = "5/31/0" points per talent tree, in the game's tree order
--   mh, rg = "itemID:itemLevel" of the main hand and ranged slot ("" when empty)
--   sk = "7,8,15" weapon item subclasses the character has the skill for
-- Protocol:
--   CRG <at> <tal> <mh> <rg> <sk>   GUILD, at login (after the roster), 30 s after a change, and with CRVQ answers
local _, ns = ...

-- English weapon skill names (Forever NA/EU) -> weapon item subclass (GetItemInfoInstant's subclassID).
ns.WEAPON_SKILLS = {
  ["Axes"] = 0, ["One-Handed Axes"] = 0, ["Two-Handed Axes"] = 1, ["Bows"] = 2, ["Guns"] = 3, ["Maces"] = 4,
  ["One-Handed Maces"] = 4, ["Two-Handed Maces"] = 5, ["Polearms"] = 6, ["Swords"] = 7, ["One-Handed Swords"] = 7,
  ["Two-Handed Swords"] = 8, ["Staves"] = 10, ["Fist Weapons"] = 13, ["Daggers"] = 15, ["Thrown"] = 16,
  ["Crossbows"] = 18, ["Wands"] = 19,
}
local MAIN_HAND, RANGED = 16, 18

local function myName() return ns.shortName(ns.me() or UnitName("player")) end
local function sharing() return ns.CraftSharing and ns.CraftSharing() end

-- What each class can learn to use in Classic (weapon item subclasses), for clients with no weapon skill list:
-- the modern client Forever runs on has no GetSkillLineInfo. A trainer may still have to teach some of these.
ns.CLASS_WEAPONS = {
  WARRIOR = "0,1,2,3,4,5,6,7,8,10,13,15,16,18", PALADIN = "0,1,4,5,6,7,8", HUNTER = "0,1,2,3,6,7,8,10,13,15,16,18",
  ROGUE = "2,3,4,7,13,15,16,18", PRIEST = "4,10,15,19", SHAMAN = "0,1,4,5,10,13,15", MAGE = "7,10,15,19",
  WARLOCK = "7,10,15,19", DRUID = "4,5,10,13,15",
}

local function classFile()
  local ok, _, file = pcall(UnitClass, "player")
  return ok and type(file) == "string" and not ns.isSecret(file) and file or nil
end

function ns.ReadWeaponSkills()
  if not (GetNumSkillLines and GetSkillLineInfo) then
    return ns.CLASS_WEAPONS[classFile() or ""] -- modern client: the class's weapons
  end
  local subs, seen = {}, {}
  for i = 1, GetNumSkillLines() or 0 do
    local name, header = GetSkillLineInfo(i)
    local sub = not header and type(name) == "string" and ns.WEAPON_SKILLS[name]
    if sub and not seen[sub] then seen[sub] = true; subs[#subs + 1] = sub end
  end
  table.sort(subs)
  return table.concat(subs, ",")
end

-- Points per tree. Classic returns name, icon, pointsSpent, ...; newer clients id, name, description, icon,
-- pointsSpent, ..., so the position depends on whether the first value is a number.
-- Modern client (no talent trees): the chosen specialization, written as 31 points in its Classic tree so the bot
-- reads one format. Druids have four specializations; Guardian counts as Feral, Restoration as the third tree.
local DRUID_SPEC_TREE = { 1, 2, 2, 3 }
local function specAsTalents()
  if not (GetSpecialization and GetNumSpecializations) then return nil end
  local ok, spec = pcall(GetSpecialization)
  local ok2, n = pcall(GetNumSpecializations)
  if not (ok and ok2) or type(spec) ~= "number" or type(n) ~= "number" or ns.isSecret(spec) or spec < 1 then
    return nil
  end
  local trees = n
  if classFile() == "DRUID" and n == 4 then spec, trees = DRUID_SPEC_TREE[spec] or spec, 3 end
  local pts = {}
  for t = 1, trees do pts[t] = t == spec and 31 or 0 end
  return table.concat(pts, "/")
end

function ns.ReadTalents()
  if not (GetNumTalentTabs and GetTalentTabInfo) then return specAsTalents() end
  local pts = {}
  for t = 1, tonumber((GetNumTalentTabs())) or 0 do
    local r = { pcall(GetTalentTabInfo, t) }
    if not r[1] then return nil end
    local p = type(r[2]) == "number" and r[6] or r[4]
    pts[t] = (type(p) == "number" and not ns.isSecret(p)) and p or 0
  end
  return #pts > 0 and table.concat(pts, "/") or nil
end

local function slotItem(slot)
  if not GetInventoryItemLink then return nil end
  local ok, link = pcall(GetInventoryItemLink, "player", slot)
  local id = ok and type(link) == "string" and not ns.isSecret(link) and tonumber(link:match("item:(%d+)"))
  if not id then return "" end
  local full = (C_Item and C_Item.GetItemInfo) or GetItemInfo
  local ilvl
  if full then
    local ok2, _, _, _, itemLevel = pcall(full, link)
    if ok2 and type(itemLevel) == "number" and not ns.isSecret(itemLevel) then ilvl = itemLevel end
  end
  return ("%d:%s"):format(id, ilvl or "")
end

-- Which reading paths this client has, for /uw craft check.
function ns.GearApis()
  return {
    skills = (GetNumSkillLines and GetSkillLineInfo) and "yes" or "class list",
    talents = (GetNumTalentTabs and GetTalentTabInfo) and "yes" or (GetSpecialization and "specialization") or "no",
    equipped = GetInventoryItemLink and "yes" or "no",
    stats = ((C_Item and C_Item.GetItemStats) or GetItemStats) and "yes" or "no",
  }
end

local function line(e)
  return ("CRG\t%d\t%s\t%s\t%s\t%s"):format(e.at, e.tal or "", e.mh or "", e.rg or "", e.sk or "")
end

local pending = false
function ns.ShareGear()
  if pending or not sharing() then return end
  pending = true
  C_Timer.After(30, function()
    pending = false
    local e = UW_GuildDB.gear[myName()]
    if e and sharing() and ns.tracksGuild() and ns.CraftEnqueue then ns.CraftEnqueue({ line(e) }) end
  end)
end

-- Read our own picture; announce only when it changed.
function ns.RefreshGear()
  if not sharing() or not ns.tracksGuild() then return end
  local new = { tal = ns.ReadTalents(), mh = slotItem(MAIN_HAND), rg = slotItem(RANGED), sk = ns.ReadWeaponSkills() }
  local db = UW_GuildDB.gear
  local old = db[myName()]
  if old and old.tal == new.tal and old.mh == new.mh and old.rg == new.rg and old.sk == new.sk then return end
  new.at = time()
  db[myName()] = new
  ns.ShareGear()
end

ns.handlers.CRG = function(sender, channel, at, tal, mh, rg, sk)
  if channel ~= "GUILD" or not ns.tracksGuild() or not ns.inRoster(sender) then return end
  local name = ns.shortName(sender)
  at = ns.num(at)
  if name == myName() or not at then return end
  local old = UW_GuildDB.gear[name]
  if old and (old.at or 0) >= at then return end
  local function ok(v, pat) return type(v) == "string" and v:match(pat) and v or "" end
  UW_GuildDB.gear[name] = { at = at, tal = ok(tal, "^[%d/]+$"), mh = ok(mh, "^%d+:%d*$"), rg = ok(rg, "^%d+:%d*$"),
    sk = ok(sk, "^[%d,]+$") }
end

-- CRX (opt-out) forgets the sender's gear too.
local crx = ns.handlers.CRX
ns.handlers.CRX = function(sender, channel, ...)
  if crx then crx(sender, channel, ...) end
  if channel == "GUILD" and ns.tracksGuild() and ns.inRoster(sender) then UW_GuildDB.gear[ns.shortName(sender)] = nil end
end

-- An officer's CRVQ: everyone says CRV, and their gear line too.
local crvq = ns.handlers.CRVQ
local lastVQ
ns.handlers.CRVQ = function(sender, channel, ...)
  if crvq then crvq(sender, channel, ...) end
  if channel ~= "GUILD" or not ns.isOfficer(sender) or not sharing() then return end
  if lastVQ and GetTime() - lastVQ < 600 then return end
  lastVQ = GetTime()
  ns.ShareGear()
end

table.insert(ns.onLoad, function() -- before the event wiring
  UW_GuildDB.gear = UW_GuildDB.gear or {}
end)

local f = CreateFrame("Frame")
ns.listen(f, { "PLAYER_EQUIPMENT_CHANGED", "CHARACTER_POINTS_CHANGED", "SKILL_LINES_CHANGED",
  "PLAYER_SPECIALIZATION_CHANGED", "ACTIVE_TALENT_GROUP_CHANGED" })
local soon = false
f:SetScript("OnEvent", function()
  if soon or not UW_GuildDB or not UW_GuildDB.gear then return end
  soon = true
  C_Timer.After(3, function()
    soon = false
    local ok, err = pcall(ns.RefreshGear)
    if not ok then ns.say("Couldn't read your weapons and talents (" .. tostring(err) .. ").") end
  end)
end)

table.insert(ns.onGuildJoin, function()
  ns.afterRoster(function()
    if not ns.tracksGuild() then return end -- what is shared is said once, in the crafting notice (Crafts.lua)
    pcall(ns.RefreshGear)
    ns.ShareGear() -- also when unchanged, so officers' clients hear it after a while offline
  end)
end)
