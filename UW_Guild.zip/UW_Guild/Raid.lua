-- Raid nights for the whole guild: kills, attendance and loot awards shared over the guild channel.
--
-- A kill and its attendance are saved by every UW_Guild client in the raid, and a loot award by every client in the
-- group, but the bot reads only the guild master's saved data. When the guild master wasn't in that raid, the night
-- never reached Discord (no raid-night credit toward Raider, no #loot-log), and each raid leader's loot order only
-- knew the awards their own client had seen. So a trusted client in the raid (Guild Master, Officer or Raider rank:
-- the ranks that lead raids, docs/ownership.md) shares each record with the guild:
--   * live, on GUILD, right after the kill or award (RK, RL, RU). Whoever leads goes first; other trusted clients
--     wait a few seconds and stay quiet once they hear someone else share it, so a 20-player raid sends one copy.
--   * later, for clients that were offline: a trusted client asks on login (RQ, with the time it last listened),
--     one trusted client claims the answer (RA) and whispers what it holds from those days.
-- Every client keeps what it hears, so its attendance and loot counts become the guild's, not just its own. Two
-- reports of one kill are merged (same encounter, close in time or sharing half their names); awards are keyed by
-- award time and winner. The protocol is in DESIGN.md ("Raid records").
local _, ns = ...

ns.RAID_LEAD_MAX_RANK = 2    -- rankIndex 0 to 2: Guild Master, Officer, Raider. Only these share raid records.
ns.RAID_SHARE_DAYS = 7       -- records this recent are sent to a trusted guildmate who logs in later
ns.RAID_MSG_MAX = 250        -- addon messages are capped at 255 bytes
ns.RAID_BOSS_MAX = 40        -- bytes of a boss name in a message (Hyjal's longest is 16)
ns.RAID_NAMES_MAX = 40       -- names kept per kill (a 20-player raid plus a few swaps)
ns.KILL_SAME_WINDOW = 12 * 3600 -- two reports of one encounter within 12 hours that share half their names are one kill
ns.KILL_SAME_SECONDS = 120   -- and so are two this close together when either has no names to compare

local function serverNow() return (GetServerTime and GetServerTime()) or time() end
local function me() return ns.me() end
-- Cut to n bytes without leaving half a UTF-8 character.
local function cut(s, n)
  s = tostring(s or ""):gsub("[\t\"\\]", "")
  if #s > n then s = s:sub(1, n):gsub("[\192-\255][\128-\191]*$", "") end
  return s
end

-- Guild Master, Officer or Raider in the current roster (by full Name-Realm, like every officer check).
function ns.canShareRaid(name)
  local full = ns.fullName(name)
  local rank = full and ns.rankOf[full]
  return rank ~= nil and rank <= ns.RAID_LEAD_MAX_RANK
end
local function mayShare() return ns.tracksGuild() and ns.canShareRaid(ns.me()) end
-- Believed as the group's leader: a guildmate of a rank that shares raid records who leads or assists the group. Leading
-- alone isn't enough: anyone can lead a party, and with "everyone is assistant" on, everyone assists. Never ourselves,
-- and only on a guild character of this client. Loot (LOOT, LOOTUNDO) and the raid plan (Plan.lua) both use it.
function ns.trustedLeader(sender)
  local short = ns.shortName(sender)
  if UnitIsUnit(short, "player") or not (ns.tracksGuild() and ns.canShareRaid(sender)) then return false end
  return UnitIsGroupLeader(short) or UnitIsGroupAssistant(short)
end

-- Kills ---------------------------------------------------------------------------------------------------------
local function parseKill(line)
  local t, enc, boss, diff, size, who, via = strsplit("\t", tostring(line))
  local names = {}
  for n in (who or ""):gmatch("[^,]+") do names[#names + 1] = n end
  return { at = tonumber(t), enc = tonumber(enc) or 0, boss = boss or "", diff = tonumber(diff) or 0,
    size = tonumber(size) or 0, names = names, via = via ~= "" and via or nil }
end
ns.ParseKill = parseKill

local function killLine(k)
  local line = table.concat({ k.at, k.enc, k.boss, k.diff, k.size, table.concat(k.names, ",") }, "\t")
  return k.via and (line .. "\t" .. k.via) or line
end

-- A name as two reports compare it: lowercased, "First Last" and "First-Last" alike (a Forever name, spelled either
-- way by different clients). "Name-Realm" stays apart from "Name", so a namesake on another realm is never merged.
function ns.NameKey(n) return (tostring(n):lower():gsub("[%s%-]+", " ")) end

-- One kill seen by two clients: the same encounter (or boss, when a client stored the ID as 0) and difficulty,
-- within 12 hours, and the same people: at least half the smaller name list in common. The parts of one RK share
-- carry different names under the same realm time, so the same second is one kill too; with no names to compare,
-- so is a report moments apart. Two guild groups killing the same boss minutes apart have different people, so they
-- stay two kills (audit B3; before, any two reports 120 s apart were merged and the second group lost its credit).
-- The bot applies the same rule (store.same_kill).
function ns.SameKill(a, b)
  if not (a.at and b.at) then return false end
  if a.enc ~= 0 and b.enc ~= 0 then
    if a.enc ~= b.enc then return false end
  elseif cut(a.boss, ns.RAID_BOSS_MAX):lower() ~= cut(b.boss, ns.RAID_BOSS_MAX):lower() then
    return false
  end
  if a.diff ~= 0 and b.diff ~= 0 and a.diff ~= b.diff then return false end
  local gap = math.abs(a.at - b.at)
  if gap == 0 then return true end
  if gap > ns.KILL_SAME_WINDOW then return false end
  local fewer = math.min(#a.names, #b.names)
  if fewer == 0 then return gap <= ns.KILL_SAME_SECONDS end
  local seen, common = {}, 0
  for _, n in ipairs(a.names) do seen[ns.NameKey(n)] = true end
  for _, n in ipairs(b.names) do if seen[ns.NameKey(n)] then common = common + 1 end end
  return common * 2 >= fewer
end

-- RK messages for a kill: the header repeats in each, names fill the rest, so every part stands on its own and
-- a lost part only costs its names until the next catch-up.
function ns.KillMessages(k)
  local head = ("RK\t%d\t%d\t%d\t%d\t%s\t"):format(k.at, k.enc, k.diff, k.size, cut(k.boss, ns.RAID_BOSS_MAX))
  local out, cur, len = {}, {}, #head
  for _, n in ipairs(k.names) do
    local add = (#cur > 0 and 1 or 0) + #n
    if #cur > 0 and len + add > ns.RAID_MSG_MAX then
      out[#out + 1] = head .. table.concat(cur, ",")
      cur, len, add = {}, #head, #n
    end
    cur[#cur + 1] = n
    len = len + add
  end
  if #cur > 0 then out[#out + 1] = head .. table.concat(cur, ",") end
  return out
end

-- Shares waiting for their turn. Another trusted client sharing the same record first cancels ours, also while
-- ours waits in the send queue. Once our first part has actually gone out, the rest follow, so a kill is never left
-- half shared by two clients that each stopped for the other. A first part the game keeps refusing cancels the
-- rest too (never parts 2 and on without part 1); another raider's copy, or the next catch-up, brings the record.
local pending = {}
local function schedule(entry, delay)
  pending[#pending + 1] = entry
  local function done() for i, e in ipairs(pending) do if e == entry then table.remove(pending, i) break end end end
  local function skip()
    if entry.cancelled and not entry.started then done() return true end
    return false
  end
  local function sent() if not entry.started then entry.started = true; done() end end
  local function dropped() if not entry.started then entry.cancelled = true; done() end end
  ns.after(delay, function()
    if entry.cancelled or not mayShare() then done() return end
    for _, m in ipairs(entry.msgs) do ns.relay(m, "GUILD", nil, skip, sent, dropped) end
  end)
end
local function heard(kind, rec)
  for _, e in ipairs(pending) do
    if e.kind == kind and (kind == "kill" and ns.SameKill(e.rec, rec) or kind ~= "kill" and e.key == rec) then
      e.cancelled = true
    end
  end
end

-- The leader shares first; assistants and other trusted raiders are the backup if the leader has no UW_Guild.
local function killDelay()
  if UnitIsGroupLeader and UnitIsGroupLeader("player") then return 1 + math.random() end
  if UnitIsGroupAssistant and UnitIsGroupAssistant("player") then return 3 + math.random() * 3 end
  return 6 + math.random() * 6
end

-- Records a kill once: from this client's own ENCOUNTER_END (via nil; then shared with the guild) or from a
-- guildmate's share (via = who sent it). A second report of a kill already here adds any names it was missing.
-- True when the kill is new on this client.
function ns.RecordKill(k, via)
  local log = UW_GuildDB.attendance
  table.sort(k.names)
  for i = #log, 1, -1 do
    local old = parseKill(log[i])
    if ns.SameKill(old, k) then
      local have, added = {}, false
      for _, n in ipairs(old.names) do have[ns.NameKey(n)] = true end
      for _, n in ipairs(k.names) do
        local key = ns.NameKey(n)
        if not have[key] and #old.names < ns.RAID_NAMES_MAX then old.names[#old.names + 1] = n; have[key], added = true, true end
      end
      if added then table.sort(old.names); log[i] = killLine(old) end
      return false
    end
  end
  k.via = via
  log[#log + 1] = killLine(k)
  while #log > ns.MAX_ATTENDANCE do table.remove(log, 1) end
  if not via and mayShare() then
    schedule({ kind = "kill", rec = k, msgs = ns.KillMessages(k) }, killDelay())
  end
  return true
end

-- Loot ----------------------------------------------------------------------------------------------------------
local function awardKey(at, name) return ("%d:%s"):format(at, tostring(name):lower()) end
-- The leader's reason comes last and is cut to fit, so a long item and a long two-part cross-realm name never push
-- the message past 255 bytes (where it would be dropped whole).
local function awardMessage(a)
  local msg = ("RL\t%s\t%s\t%s\t%d\t%d"):format(a.item, a.name, a.tier, a.roll, a.at)
  local room = ns.RAID_MSG_MAX - #msg - 1
  return (a.call and room > 0) and (msg .. "\t" .. cut(a.call, room)) or msg
end

-- delay 0: this client handed it out, so it shares now. Otherwise it heard the award in the group and is the
-- backup, in case the leader has no UW_Guild or isn't a trusted rank.
function ns.ShareAward(a, delay)
  if not mayShare() then return end
  local msg = awardMessage(a)
  if delay == 0 then ns.relay(msg, "GUILD") return end
  schedule({ kind = "loot", key = awardKey(a.at, a.name), msgs = { msg } }, delay or (8 + math.random() * 8))
end
function ns.ShareUndo(a, delay)
  if not mayShare() then return end
  local msg = ("RU\t%d\t%s"):format(a.at, a.name)
  if delay == 0 then ns.relay(msg, "GUILD") return end
  schedule({ kind = "undo", key = awardKey(a.at, a.name), msgs = { msg } }, delay or (8 + math.random() * 8))
end

-- Receiving -----------------------------------------------------------------------------------------------------
-- Live on GUILD, or whispered in answer to our RQ. Only from a trusted rank in our roster, never our own echo.
local function trusted(sender, channel)
  if channel ~= "GUILD" and channel ~= "WHISPER" then return false end
  if not ns.tracksGuild() or sender == me() then return false end
  return ns.canShareRaid(sender)
end
-- A record's realm time, whole, when it is at most 10 minutes ahead and 8 days old; else nil. Loot.lua checks
-- awards heard in the group the same way.
local function recent(at)
  at = ns.finite(at)
  local now = serverNow()
  if not at or at > now + 600 or at < now - (ns.RAID_SHARE_DAYS + 1) * 86400 then return nil end
  return math.floor(at)
end
ns.RecentAt = recent
local received -- (sender, at, key): a record whispered in answer to our RQ arrived (catch-up, below)

ns.handlers.RK = function(sender, channel, at, enc, diff, size, boss, names)
  if not trusted(sender, channel) then return end
  at, boss = recent(at), cut(boss, ns.RAID_BOSS_MAX)
  if not at or boss == "" then return end
  local list = {}
  for n in tostring(names or ""):gmatch("[^,]+") do
    n = n:gsub("[\t\"\\]", "")
    if n ~= "" and #n <= 48 and #list < ns.RAID_NAMES_MAX then list[#list + 1] = n end
  end
  if #list == 0 then return end
  local k = { at = at, enc = math.floor(ns.finite(enc) or 0), boss = boss, diff = math.floor(ns.finite(diff) or 0),
    size = math.max(0, math.min(40, math.floor(ns.finite(size) or #list))), names = list }
  if channel == "WHISPER" then received(sender, at, "k" .. at) end
  heard("kill", k)
  -- The kill's own time rides along, so the post shows when it happened, not when this client heard of it.
  if ns.RecordKill(k, ns.shortName(sender)) then ns.queue("kill", boss, k.size, at) end
end

ns.handlers.RL = function(sender, channel, item, winner, tier, roll, at, reason)
  if not trusted(sender, channel) then return end
  at = recent(at)
  if not at or type(winner) ~= "string" then return end
  if channel == "WHISPER" then received(sender, at, "l" .. awardKey(at, winner)) end
  heard("loot", awardKey(at, winner))
  ns.MirrorAward(item, winner, tier, roll, at, reason, true)
end

ns.handlers.RU = function(sender, channel, at, winner)
  if not trusted(sender, channel) then return end
  at = recent(at)
  if not at or type(winner) ~= "string" or winner == "" then return end
  if channel == "WHISPER" then received(sender, at, "u" .. awardKey(at, winner)) end
  heard("undo", awardKey(at, winner))
  ns.UndoAward(at, winner)
end

-- Catch-up ------------------------------------------------------------------------------------------------------
-- UW_GuildDB.raidHeard: realm time this account was last online in the guild and so heard live shares.
-- UW_GuildDB.raidGap: the start of a stretch we asked about and haven't fully heard yet; asked again when another
-- trusted guildmate logs in (their RQ says they're here), until an answer covers it or it is a week old.
-- An answer is one stream, oldest record first, cut to what the answerer's queue has room for, and ends with a
-- whispered RA carrying the last record's time and whether more remain. The gap moves up only to records that
-- actually arrived, so an answer cut short (a full queue, a /reload, a logout) is asked for again from there.
-- Two checks keep a record from ever being skipped: the answerer stops its stream at the first message the game
-- refuses for good and closes it with RA up to the record before (so nothing after a hole is sent), and the asker
-- counts the records it got from the stream. If the closing RA says more than arrived (a whisper lost on the way,
-- or a stream this session never saw claimed), the gap goes back to where this session asked from and is asked
-- again; repeats are harmless, since kills merge and awards are keyed by time and winner.
ns.RAID_REASK = 310 -- seconds before asking for the rest of a cut answer (answerers reply once per 5 min per asker)
local asked, lastAsk, askedSince = false, nil, nil
local stream -- the guildmate whose ordered answer we are receiving (its claim said so)
local streamGot, streamCount = {}, 0 -- records of that answer that arrived, by key
local function ask()
  if not mayShare() then return false end
  if lastAsk and GetTime() - lastAsk < 300 then return false end
  local now = serverNow()
  local floor = now - ns.RAID_SHARE_DAYS * 86400
  local since = UW_GuildDB.raidGap or ((UW_GuildDB.raidHeard or 0) - 120) -- the minute ticker, plus slack
  if since < floor then since = floor end
  if not ns.send(("RQ\t%d"):format(since), "GUILD") then return false end
  lastAsk, asked, stream, askedSince = GetTime(), true, nil, since
  UW_GuildDB.raidGap = since
  return true
end
received = function(sender, at, key)
  if sender ~= stream then return end
  if not streamGot[key] then streamGot[key], streamCount = true, streamCount + 1 end
  local gap = UW_GuildDB.raidGap
  if gap and at > gap then UW_GuildDB.raidGap = at end
end

-- What we hold since `since`: kills, awards, and every undo since then (the asker may have heard the award in its
-- last minutes online, inside the ask's slack; one it never had just leaves a mark), oldest first by when it
-- happened (an undo by when it was undone). room: the most messages to return; whole records only, a kill's parts
-- never split. Returns messages, the number of records, the time of the last one, true when more were left out,
-- and for each message the number of its record (1 = oldest) with that record's time.
function ns.CatchUp(since, room)
  local recs = {}
  for _, line in ipairs(UW_GuildDB.attendance or {}) do
    local k = parseKill(line)
    if k.at and k.at >= since and #k.names > 0 then
      recs[#recs + 1] = { at = k.at, i = #recs, msgs = ns.KillMessages(k) }
    end
  end
  local db = UW_GuildDB.loot
  for _, a in ipairs(type(db) == "table" and db.awards or {}) do
    if a.at and not a.undone and a.at >= since and (a.tier == "ms" or a.tier == "os") then
      recs[#recs + 1] = { at = a.at, i = #recs, msgs = { awardMessage(a) } }
    elseif a.at and a.undone and a.undone >= since then
      recs[#recs + 1] = { at = a.undone, i = #recs, msgs = { ("RU\t%d\t%s"):format(a.at, a.name) } }
    end
  end
  table.sort(recs, function(x, y) if x.at ~= y.at then return x.at < y.at end return x.i < y.i end)
  local msgs, count, last, recNo, recAt = {}, 0, nil, {}, {}
  for _, r in ipairs(recs) do
    if room and #msgs + #r.msgs > room then return msgs, count, last, true, recNo, recAt end
    count, last = count + 1, r.at
    for _, m in ipairs(r.msgs) do msgs[#msgs + 1] = m; recNo[#msgs], recAt[count] = count, r.at end
  end
  return msgs, count, last, false, recNo, recAt
end

local claims, lastAnswer = {}, {}
ns.handlers.RQ = function(sender, channel, since)
  if channel ~= "GUILD" or not ns.tracksGuild() or sender == me() or not ns.canShareRaid(sender) then return end
  since = ns.finite(since)
  if not since then return end
  -- A trusted guildmate just logged in. If they were online during the stretch nobody has answered us about yet
  -- (they last listened after it began), they may hold what we missed: ask again.
  if UW_GuildDB.raidGap and since > UW_GuildDB.raidGap then ask() end
  if not ns.canShareRaid(ns.me()) then return end
  if lastAnswer[sender] and GetTime() - lastAnswer[sender] < 300 then return end
  since = math.max(math.floor(since), serverNow() - ns.RAID_SHARE_DAYS * 86400)
  local _, count = ns.CatchUp(since)
  if count == 0 then return end
  lastAnswer[sender] = GetTime()
  local claim = { count = count }
  claims[sender] = claim
  -- One answer is enough: wait a moment, and stand down if another trusted client claims it with as much.
  ns.after(1 + math.random() * 4, function()
    if claims[sender] == claim then claims[sender] = nil end
    if claim.cancelled or not mayShare() then return end
    -- What fits in the queue now, leaving room for the claim and the closing RA.
    local msgs, n, last, more, recNo, recAt = ns.CatchUp(since, ns.catchUpRoom() - 2)
    if n == 0 then return end
    -- The first message the game refuses for good ends the stream there: the rest is skipped and RA says how far
    -- the answer got, so the asker asks again from the record that didn't go out instead of skipping it.
    local stopped = false
    local function skip() return stopped end
    local function stopAt(i)
      return function()
        if stopped then return end
        stopped = true
        local got = (recNo[i] or 1) - 1
        ns.catchUpSend(("RA\t%s\t%d\t%d\t1"):format(sender, got, got > 0 and recAt[got] or since), "WHISPER", sender)
      end
    end
    -- The claim goes first in the same queue (never refused unseen); its last field says the answer is ordered and
    -- ends with a whispered RA (older askers ignore it).
    ns.catchUpSend(("RA\t%s\t%d\t1"):format(sender, n), "GUILD", nil, skip, stopAt(1))
    for i, m in ipairs(msgs) do ns.catchUpSend(m, "WHISPER", sender, skip, stopAt(i)) end
    ns.catchUpSend(("RA\t%s\t%d\t%d\t%d"):format(sender, n, last, more and 1 or 0), "WHISPER", sender, skip)
  end)
end

-- On GUILD: a claim. Another client about to answer the same asker with no more stands down; when it is about us,
-- an ordered answer from that sender follows (a claim from a client older than this one, with no last field,
-- closes our gap as it always did). By WHISPER, after the records: the answer is over. Complete closes the gap;
-- cut short moves it to the last record sent, and we ask again for the rest in a few minutes.
ns.handlers.RA = function(sender, channel, asker, count, last, more)
  if (channel ~= "GUILD" and channel ~= "WHISPER") or sender == me() or not ns.canShareRaid(sender) then return end
  asker = ns.fullName(asker)
  if asker == me() then
    if not ns.tracksGuild() then return end
    if channel == "GUILD" then
      if last == nil then UW_GuildDB.raidGap = nil else stream, streamGot, streamCount = sender, {}, 0 end
      return
    end
    local n = ns.finite(count) or 0
    local whole = n == 0 or (stream == sender and streamCount >= n)
    if stream == sender then stream = nil end
    if not whole then
      -- Fewer records arrived than were sent: something in between is missing, so ask again from where we asked.
      -- (Nothing to do when no gap is open: an earlier answer already covered it.)
      if UW_GuildDB.raidGap and askedSince then
        UW_GuildDB.raidGap = math.min(UW_GuildDB.raidGap, askedSince)
        ns.after(ns.RAID_REASK, ask)
      end
      return
    end
    last = recent(last)
    if more == "1" and last then
      if not UW_GuildDB.raidGap or last > UW_GuildDB.raidGap then UW_GuildDB.raidGap = last end
      ns.after(ns.RAID_REASK, ask)
    else
      UW_GuildDB.raidGap = nil
    end
    return
  end
  local claim = channel == "GUILD" and asker and claims[asker]
  if claim and (ns.finite(count) or 0) >= claim.count then claim.cancelled = true end
end

table.insert(ns.onLoad, function()
  -- While online in the guild, live shares arrive by themselves; remember until when, for the next login's ask.
  -- A gap over a week old is closed: nothing that old is shared any more.
  C_Timer.NewTicker(60, ns.guard(function()
    if not (asked and ns.tracksGuild()) then return end
    UW_GuildDB.raidHeard = serverNow()
    if UW_GuildDB.raidGap and UW_GuildDB.raidGap < UW_GuildDB.raidHeard - ns.RAID_SHARE_DAYS * 86400 then
      UW_GuildDB.raidGap = nil
    end
  end))
end)
-- Asked once our roster is read (our own rank decides whether we ask). Logging in straight into combat blocks addon
-- messages, so it tries again every 30 seconds for a few minutes.
table.insert(ns.onGuildJoin, function()
  ns.afterRoster(function()
    local tries = 0
    local function try()
      tries = tries + 1
      if not asked and not ask() and tries < 10 and mayShare() then ns.after(30, try) end
    end
    try()
  end)
end)
