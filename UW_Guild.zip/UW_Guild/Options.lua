-- Options: UW_Guild in the two places players look for any addon (Louis, 4 Nov 2026: follow the practices of other
-- addons, toward the best UI and UX possible):
--   * Esc > Options > AddOns > UW Guild, the game's own Settings panel, and /uw options;
--   * the minimap's addon menu (the addon compartment; the .toc names the three functions at the bottom).
-- Every button runs the /uw command its tooltip names, so the page adds no behaviour of its own. Players find what
-- UW_Guild does by looking instead of remembering commands, see the kit's state without asking, and get each answer
-- on the page as well as in chat, because the Settings panel covers chat. These are Nielsen's usability heuristics:
-- recognition rather than recall, visibility of system status, consistency and standards. The page is built from
-- the game's own templates and fonts, so it looks like every other addon's page and UI skins treat it the same way.
local _, ns = ...
local say = ns.say

ns.OPTION_NAME = "UW Guild"
-- { button, /uw command, tooltip }. A command that changes something for the whole guild asks for a second click.
ns.OPTION_ACTIONS = {
  { "Check my addon kit", "kit", "What's missing, doubled up or turned off, and how to fix it." },
  { "Fix my kit", "kit fix", "Turns duplicates off and installed kit addons on, then asks to reload. All characters: /uw kit fix all." },
  { "Use the guild layout", "kit layout", "Imports the raid frames, bars and meter the officers shared." },
  { "Optional extras", "kit extras", "One extra addon per goal, and which ones you already have." },
  { "Class macros", "kit macros", "The guild's tested macros for your class, added in one click." },
  { "Report a problem", "kit report", "A short report to paste into /ask-officers in Discord." },
  { "Welcome window", "welcome", "The guild's norms, your buddy and the invite link." },
  { "Guildmates near my level", "near", "Who's online and close to your level, for leveling groups." },
  { "Loot rules", "loot", "How the guild's loot rolls work." },
  { "Raid plan", "plan", "Your own job in each step of the raid leader's plan. Leaders paste the guide's code here." },
  { "Guild jobs", "jobs", "Who holds each guild job, from guild notes, and how to take one." },
  { "Rate a leader", "rate", "How the last guild raid or dungeon leader did. Private." },
  { "Contact the Guild Master", "contact", "The Guild Master's BattleTag and Steam." },
}
ns.OFFICER_ACTIONS = {
  { "Check the group's kits", "audit", "Asks every member's UW_Guild what their kit has. Results in 6 seconds." },
  { "Nudge members to fix kits", "kit nudge", "Online members with something to fix get a reminder. Nobody else sees it." },
  { "Share my layout", "kit layout share", "Makes your EllesmereUI and Details layout the guild layout.", true },
  { "Change the guild kit", "kit edit", "Shows the commands that add, remove or pair kit addons for everyone." },
}
-- The automatic helpers, each a switch on the page: { key, label, /uw command (takes on/off), tooltip, on() }.
local function db() return UW_GuildDB or {} end
ns.OPTION_SWITCHES = {
  { key = "craft", label = "Share my crafting with the guild", cmd = "craft",
    tip = "Guildmates see what you can craft and the weapons the guild plan suggests for you. Off: nothing is shared, "
      .. "and online guildmates forget what they had.", on = function() return not (UW_GuildCharDB or {}).craftsOff end },
  { key = "gear", label = "Wear clear gear upgrades", cmd = "gear",
    tip = "Only when it's clear: same slot and armour type, higher item level, no stat lower. Bind on Equip and close "
      .. "calls always ask. Never in combat or a loot roll. /uw gear undo swaps back.",
    on = function() return db().gearAuto ~= false end },
  { key = "space", label = "Space uses quest items", cmd = "space",
    tip = "When your target is part of a quest you carry an item for, and it's in range, Space uses the item. "
      .. "Shift+Space uses it in fights too.", on = function() return db().spaceItem ~= false end },
  { key = "bags", label = "Delete and Make room in bags", cmd = "bags",
    tip = "Delete on your bags drops the cheapest junk; with full bags, Make room swaps junk for better loot. Junk worth "
      .. "less than anything in full bags stays on the corpse. Shift-click Delete keeps an item.",
    on = function() return db().bagRoom ~= false end },
  { key = "bars", label = "New spells onto my bars", cmd = "bars",
    tip = "A new rank replaces the old one on your bars; a new spell takes the first empty slot. Never macros or items.",
    on = function() return db().barsAuto ~= false end },
  { key = "chain", label = "Quest chain tags in Questie", cmd = "chain",
    tip = "Questie's tracker shows each quest's step in its chain (3/7); hover for every step. /uw chain lists them.",
    on = function() return db().chainTags ~= false end },
  { key = "guide", label = "Quest guide marker", cmd = "guide",
    tip = "The map pin and on-screen marker point at your tracked quest's next step. Wandering NPCs: along their route, "
      .. "and a line once in sight. Your own pin always wins.", on = function() return ns.GuideOn and ns.GuideOn() or false end },
  { key = "mail", label = "Send mats button at a mailbox", cmd = "mail",
    tip = "One click mails crafting materials to your own alt whose professions use them. /uw mail shows what would go.",
    on = function() return db().mailMats ~= false end },
  { key = "events", label = "Rally and raid night heads-ups", cmd = "events",
    tip = "A login line and a heads-up 10 minutes before each Rally or raid night. /uw events lists them.",
    on = function() return db().eventsQuiet ~= true end },
}
ns.ECHO_SECONDS, ns.ECHO_LINES, ns.CONFIRM_SECONDS = 8, 6, 5

-- The kit's state in a line or two, for the page and the minimap tooltip.
function ns.OptionsStatus()
  local missReq, _, conflicts, missRaid = ns.CheckKit()
  local off, on = {}, {}
  if ns.KitFixPlan then off, on = ns.KitFixPlan() end
  local lines = {}
  if #missReq + #conflicts == 0 then
    lines[1] = "|cff40ff40Addon kit: ready.|r"
  else
    local parts = {}
    if #missReq > 0 then parts[#parts + 1] = ("%d missing"):format(#missReq) end
    if #conflicts > 0 then parts[#parts + 1] = ("%d doubled up"):format(#conflicts) end
    lines[1] = ("|cffff8000Addon kit: %s.|r %s"):format(table.concat(parts, ", "),
      #off + #on > 0 and "Fix my kit does it in one step." or "Check my addon kit shows which.")
  end
  if #missRaid > 0 then lines[#lines + 1] = ("For raiding: %d more to add."):format(#missRaid) end
  if (ns.ownErrors or 0) > 0 then
    lines[#lines + 1] = ("|cffff8000UW_Guild hit %d problem(s) this session.|r Report a problem copies them for the officers.")
      :format(ns.ownErrors)
  end
  return lines
end

-- A button's answer: what the command says for the next few seconds (an audit's results come 6 s later) is shown on
-- the page too, newest last.
local answer = {}
local echoUntil = 0
local panel, ui -- the registered frame, and its widgets once it has been shown
local function showAnswer()
  if ui then ui.answer:SetText(table.concat(answer, "\n")) end
end
ns.echo = function(msg)
  if GetTime() > echoUntil then return end
  answer[#answer + 1] = msg
  while #answer > ns.ECHO_LINES do table.remove(answer, 1) end
  showAnswer()
end
function ns.OptionsAnswer() return answer end

local armed -- { command, until }: the first click on a guild-wide action
function ns.OptionsRun(entry)
  local cmd = entry[2]
  wipe(answer)
  echoUntil = GetTime() + ns.ECHO_SECONDS
  if entry[4] and not (armed and armed[1] == cmd and GetTime() <= armed[2]) then
    armed = { cmd, GetTime() + ns.CONFIRM_SECONDS }
    say(("Click %s again within %d seconds: it changes this for the whole guild."):format(entry[1], ns.CONFIRM_SECONDS))
    return
  end
  armed = nil
  ns.useFrom = "options" -- usage counts (Core.lua ns.use): a click here, not a typed command
  SlashCmdList.UWGUILD(cmd)
  if ui then ui.refresh() end
end

-- The page ---------------------------------------------------------------------------------------------------------
local function tooltip(owner, title, text)
  if not GameTooltip then return end
  GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
  GameTooltip:SetText(title, 1, 1, 1)
  GameTooltip:AddLine(text, nil, nil, nil, true)
  GameTooltip:Show()
end
local function hideTooltip() if GameTooltip then GameTooltip:Hide() end end

local function fontString(parent, font, width)
  local fs = parent:CreateFontString(nil, "ARTWORK", font)
  fs:SetJustifyH("LEFT")
  if width then fs:SetWidth(width) end
  return fs
end

local function buttons(parent, list)
  local out = {}
  for i, entry in ipairs(list) do
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(230, 24)
    b:SetText(entry[1])
    b:SetScript("OnClick", function() ns.protect(ns.OptionsRun, entry) end)
    b:SetScript("OnEnter", function(self) tooltip(self, entry[1], entry[3] .. "\n|cff808080/uw " .. entry[2] .. "|r") end)
    b:SetScript("OnLeave", hideTooltip)
    ns.Skin("Button", b)
    b.col, b.row = (i - 1) % 2, math.floor((i - 1) / 2)
    out[i] = b
  end
  return out
end

local function place(list, header, anchor, gap)
  header:ClearAllPoints()
  header:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -gap)
  for _, b in ipairs(list) do
    b:ClearAllPoints()
    b:SetPoint("TOPLEFT", header, "BOTTOMLEFT", b.col * 240, -6 - b.row * 28)
  end
  return list[#list - (#list % 2 == 0 and 1 or 0)] or header -- the lowest left-hand button
end

local function build(parent)
  local f = { frame = parent }
  local title = fontString(parent, "GameFontNormalLarge")
  title:SetPoint("TOPLEFT", 16, -16)
  title:SetText(ns.OPTION_NAME)
  local sub = fontString(parent, "GameFontHighlightSmall", 560)
  sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -6)
  sub:SetText(("Version %s. Keeps the guild's addons working together, does the chores ticked below, and runs the "
    .. "welcome, loot rolls and raid records. Each switch and button names its /uw command."):format(ns.VERSION))
  f.status = fontString(parent, "GameFontHighlight", 560)
  f.status:SetPoint("TOPLEFT", sub, "BOTTOMLEFT", 0, -12)

  -- One switch per automatic helper, two columns: what each does is visible at a glance, and each turns off here.
  f.switches, f.share = {}, nil
  local last
  for i, sw in ipairs(ns.OPTION_SWITCHES) do
    local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cb:SetSize(24, 24)
    if i == 1 then cb:SetPoint("TOPLEFT", f.status, "BOTTOMLEFT", -4, -10)
    elseif i % 2 == 0 then cb:SetPoint("LEFT", last, "LEFT", 280, 0)
    else cb:SetPoint("TOPLEFT", f.switches[ns.OPTION_SWITCHES[i - 2].key], "BOTTOMLEFT", 0, -2) end
    local label = fontString(parent, "GameFontHighlight", 250)
    label:SetPoint("LEFT", cb, "RIGHT", 2, 0)
    label:SetText(sw.label)
    cb:SetScript("OnClick", function(self)
      ns.protect(ns.OptionsRun, { "", sw.cmd .. (self:GetChecked() and " on" or " off") })
    end)
    cb:SetScript("OnEnter", function(self)
      tooltip(self, sw.label, sw.tip .. "\n|cff808080/uw " .. sw.cmd .. " on, /uw " .. sw.cmd .. " off|r")
    end)
    cb:SetScript("OnLeave", hideTooltip)
    ns.Skin("Checkbox", cb)
    f.switches[sw.key] = cb
    if i % 2 == 1 then last = cb end
  end
  f.share = f.switches.craft
  f.lastSwitch = last

  f.everyoneHeader = fontString(parent, "GameFontNormal")
  f.everyoneHeader:SetText("Everyone")
  f.everyone = buttons(parent, ns.OPTION_ACTIONS)
  f.officerHeader = fontString(parent, "GameFontNormal")
  f.officerHeader:SetText("Officers")
  f.officer = buttons(parent, ns.OFFICER_ACTIONS)
  f.answerHeader = fontString(parent, "GameFontNormal")
  f.answerHeader:SetText("Answer")
  f.answer = fontString(parent, "GameFontHighlightSmall", 560)
  f.answer:SetJustifyV("TOP")
  f.answer:SetPoint("TOPLEFT", f.answerHeader, "BOTTOMLEFT", 0, -6)

  f.refresh = function()
    f.status:SetText(table.concat(ns.OptionsStatus(), "\n"))
    for _, sw in ipairs(ns.OPTION_SWITCHES) do f.switches[sw.key]:SetChecked(sw.on() and true or false) end
    local low = place(f.everyone, f.everyoneHeader, f.lastSwitch, 12)
    local officer = ns.isOfficer(ns.me())
    f.officerHeader:SetShown(officer)
    for _, b in ipairs(f.officer) do b:SetShown(officer) end
    if officer then low = place(f.officer, f.officerHeader, low, 14) end
    f.answerHeader:ClearAllPoints()
    f.answerHeader:SetPoint("TOPLEFT", low, "BOTTOMLEFT", 0, -16)
    showAnswer()
  end
  return f
end

-- Registered at start-up: the game's Settings panel (10.0 and later), or the older Interface Options list.
local category
local function register()
  panel = CreateFrame("Frame")
  panel.name = ns.OPTION_NAME
  panel:SetScript("OnShow", function(self)
    ui = ui or build(self)
    ui.refresh()
  end)
  if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
    category = Settings.RegisterCanvasLayoutCategory(panel, ns.OPTION_NAME)
    Settings.RegisterAddOnCategory(category)
  elseif InterfaceOptions_AddCategory then
    InterfaceOptions_AddCategory(panel)
  end
end
table.insert(ns.onLoad, register)
function ns.OptionsPanel() return panel, ui end

function ns.OpenOptions()
  if InCombatLockdown() then say("After combat, please: /uw options") return end
  local id = category and (category.GetID and category:GetID() or category.ID)
  if id and Settings.OpenToCategory then
    Settings.OpenToCategory(id)
  elseif InterfaceOptionsFrame_OpenToCategory and panel then
    InterfaceOptionsFrame_OpenToCategory(panel)
    InterfaceOptionsFrame_OpenToCategory(panel) -- the old list needs two calls to scroll to an addon
  else
    say("This game client has no options window for addons. Type /uw for every command.")
  end
end
ns.commands.options = ns.OpenOptions

-- The minimap's addon menu. Left-click: this page. Right-click: the kit check, straight to chat.
function UW_Guild_OnAddonCompartmentClick(_, button)
  if button == "RightButton" then ns.protect(SlashCmdList.UWGUILD, "kit") else ns.protect(ns.OpenOptions) end
end
function UW_Guild_OnAddonCompartmentEnter(_, frame)
  if not GameTooltip then return end
  GameTooltip:SetOwner(type(frame) == "table" and frame or UIParent, type(frame) == "table" and "ANCHOR_LEFT" or "ANCHOR_CURSOR")
  GameTooltip:SetText(ns.OPTION_NAME, 1, 1, 1)
  local ok, lines = pcall(ns.OptionsStatus)
  for _, line in ipairs(ok and lines or {}) do GameTooltip:AddLine(line, nil, nil, nil, true) end
  GameTooltip:AddLine("|cff808080Left-click: options. Right-click: check my kit.|r")
  GameTooltip:Show()
end
function UW_Guild_OnAddonCompartmentLeave() hideTooltip() end
