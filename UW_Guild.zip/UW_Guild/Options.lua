-- Options: UW_Guild in the two places players look for any addon (Louis, 4 Nov 2026: follow the practices of other
-- addons, toward the best UI and UX possible):
--   * Esc > Options > AddOns > UW Guild, the game's own Settings panel, and /uw options;
--   * the minimap's addon menu (the addon compartment; the .toc names the three functions at the bottom).
-- Every button runs the /uw command its tooltip names, so the page adds no behaviour of its own. Players find what
-- UW_Guild does by looking instead of remembering commands, see the kit's state without asking, and get each answer
-- on the page as well as in chat, because the Settings panel covers chat. These are Nielsen's usability heuristics:
-- recognition rather than recall, visibility of system status, consistency and standards. The page is laid out on
-- the numbers and body text every UW_Guild window shares (ns.UI, Skin.lua; layout pass, 14 Nov 2026): the switches in
-- one column, the buttons beside them, the answer across the foot.
local _, ns = ...
local say = ns.say

ns.OPTION_NAME = "UW Guild"
-- { button, /uw command, tooltip }. A command that changes something for the whole guild asks for a second click.
ns.OPTION_ACTIONS = {
  { "Check my addon kit", "kit", "What's missing, doubled up or turned off, and how to fix it." },
  { "Fix my kit", "kit fix", "Turns duplicates off and installed kit addons on, then asks to reload. All characters: /uw kit fix all." },
  { "Use the guild layout", "kit layout", "Imports the raid frames, bars and meter the officers shared." },
  { "Optional extras", "kit extras", "One extra addon per goal, and which ones you already have." },
  { "Class macros", "kit macros", "The guild's tested macros for your class, added in one click." },
  { "Report a problem", "kit report", "A short report to paste into /ask-officers in Discord." },
  { "Welcome window", "welcome", "The guild's norms, your buddy and the invite link." },
  { "Guildmates near my level", "near", "Who's online and close to your level, for leveling groups." },
  { "Call a group", "lead call", "Members and up: a line in guild chat for the dungeon at your level. Invite who types inv, one click each." },
  { "Loot rules", "loot", "How the guild's loot rolls work." },
  { "Raid plan", "plan", "Your own job in each step of the raid leader's plan. Leaders paste the guide's code here." },
  { "Guild jobs", "jobs", "Who holds each guild job, from guild notes, and how to take one." },
  { "Rate a leader", "rate", "How the last guild raid or dungeon leader did. Private." },
  { "Contact the Guild Master", "contact", "The Guild Master's BattleTag." },
}
ns.OFFICER_ACTIONS = {
  { "Lead a group", "lead", "Who's on, calling a group, raid sign-ups and bench, leads and lines written ahead. Rehearse inside." },
  { "Check the group's kits", "audit", "Asks every member's UW_Guild what their kit has. Results in 6 seconds." },
  { "Nudge members to fix kits", "kit nudge", "Online members with something to fix get a reminder." },
  { "Share my layout", "kit layout share", "Makes your EllesmereUI and Details layout the guild layout.", true },
  { "Change the guild kit", "kit edit", "Shows the commands that add, remove or pair kit addons for everyone." },
}
-- The automatic helpers, each a switch on the page: { key, label, /uw command (takes on/off), tooltip, on() }. A helper
-- with no command of its own has set(on) instead. Everything starts on, and each tooltip ends with what switching it off
-- loses (Louis, 9 Nov 2026 04:29: on by default, a clear opt-out, no penalty; ns.OPTION_FOOTER).
local function db() return UW_GuildDB or {} end
ns.OPTION_SWITCHES = {
  { key = "craft", label = "Share my crafting with the guild", cmd = "craft",
    tip = "Guildmates see what you can craft and the weapons the guild plan suggests for you. Off: nothing is shared, "
      .. "and online guildmates forget what they had.", on = function() return not (UW_GuildCharDB or {}).craftsOff end },
  { key = "gear", label = "Wear clear gear upgrades", cmd = "gear",
    tip = "Only when it's clear: same slot and armor type, higher item level, no stat lower. Bind on Equip and close "
      .. "calls always ask. Never in combat or a loot roll. /uw gear undo swaps back. Off: upgrades stay in your bags "
      .. "until you put them on.",
    on = function() return db().gearAuto ~= false end },
  { key = "space", label = "Space uses quest items", cmd = "space",
    tip = "When your target is part of a quest you carry an item for, and it's in range, Space uses the item. "
      .. "Shift+Space uses it in fights too. Off: Space only jumps.", on = function() return db().spaceItem ~= false end },
  { key = "bags", label = "Delete and Make room in bags", cmd = "bags",
    tip = "Delete on your bags drops the cheapest junk; with full bags, Make room swaps junk for better loot. Junk worth "
      .. "less than anything in full bags stays on the corpse. Shift-click Delete keeps an item. Off: no Delete or Make "
      .. "room buttons; you clear bags by hand.",
    on = function() return db().bagRoom ~= false end },
  { key = "bars", label = "New spells onto my bars", cmd = "bars",
    tip = "A new rank replaces the old one on your bars; a new spell takes the first empty slot. Never macros or items. "
      .. "Off: new spells and ranks wait in your spellbook.",
    on = function() return db().barsAuto ~= false end },
  { key = "chain", label = "Quest chain tags in Questie", cmd = "chain", needs = "Questie",
    tip = "Questie's tracker shows each quest's step in its chain (3/7); hover for every step. /uw chain lists them. "
      .. "Off: Questie's tracker shows quest names only.",
    on = function() return db().chainTags ~= false end },
  { key = "guide", label = "Quest guide marker", cmd = "guide", needs = "Questie",
    tip = "The map pin and on-screen marker point at your tracked quest's next step. Wandering NPCs: along their route, "
      .. "and a line once in sight. Your own pin always wins. Off: no map pin or marker for your next step.",
    on = function() return ns.GuideOn and ns.GuideOn() or false end },
  { key = "mail", label = "Send mats button at a mailbox", cmd = "mail",
    tip = "One click mails crafting materials to your own alt whose professions use them. /uw mail shows what would go. "
      .. "Off: no Send mats button; mail by hand.",
    on = function() return db().mailMats ~= false end },
  { key = "dungeons", label = "Name dungeons as I level", cmd = "dungeons",
    tip = "At a level where a dungeon opens, one line in your chat names it. Off: no line when you level.",
    on = function() return not db().dungeonLineOff end },
  { key = "events", label = "Rally and group night heads-ups", cmd = "events",
    tip = "A login line and a heads-up 10 minutes before each Rally or group night. /uw events lists them. Off: no login "
      .. "line or 10-minute heads-ups.",
    on = function() return db().eventsQuiet ~= true end },
  { key = "rate", label = "Ask me to rate the leader", cmd = "rate",
    tip = "After a guild group's boss kill, one private ask, at most once a day. Off: no asks; /uw rate still works.",
    on = function() return not db().rateOff end },
  { key = "share", label = "Share my week-one counts", cmd = "share",
    helpers = true, -- only officers' and buddies' addons send these, so nobody else sees the switch
    tip = "Your addon keeps a first-week list on your PC and shares only counts with the guild. Off: those counts miss what "
      .. "you see; your list stays.",
    on = function() return not db().weekOneShareOff end },
  { key = "hold", label = "Keep the quest window open", needs = "DialogueUI",
    tip = "After a turn-in, DialogueUI waits a moment for the next quest. Off: it closes as it normally would.",
    on = function() return db().dialogueHold ~= false end,
    set = function(on)
      if UW_GuildDB then
        if on then UW_GuildDB.dialogueHold = nil else UW_GuildDB.dialogueHold = false end
      end
      say(on and "Quest window stays open for the next quest." or "Quest window closes as DialogueUI decides.")
    end },
}
-- A helper that works through another addon (needs) shows that addon's absence as its state, not as a ticked box that
-- does nothing (fresh-member audit, 10 Nov 2026). The saved choice is untouched: install the addon and it's back on.
-- A switch for helpers only (officers and buddies, ns.WeekOneHelper) is left off the page for everyone else, rather
-- than a box that does nothing for them (integrator review of #583, 13 Nov 2026).
function ns.SwitchShown(sw)
  if not (type(sw) == "table" and sw.helpers) then return true end
  return ns.WeekOneHelper and ns.WeekOneHelper() and true or false
end

function ns.NeedsMissing(sw)
  local need = type(sw) == "table" and sw.needs
  if not need then return false end
  local ok, loaded = pcall(C_AddOns.IsAddOnLoaded, need)
  return not (ok and loaded)
end
ns.OPTION_FOOTER = "Turning any of these off never changes your rank or your progress."
ns.ECHO_SECONDS, ns.CONFIRM_SECONDS = 8, 5
-- The page's grid (layout pass, 14 Nov 2026). The game's Settings window gives an addon page about 665 x 601
-- (Blizzard_SettingsPanel.xml). OPTION_W: the content's width between the page's margins. OPTION_LEFT: the switches'
-- column; the buttons sit right of it, OPTION_COLS abreast, OPTION_BUTTON_W wide at most. OPTION_ROW: one row step
-- for both columns, so a tick box, a button and a group's heading line up across the page (at the windows' 30 an
-- officer's 13 switches left the answer three lines). OPTION_H: the page's height where the client won't say.
ns.OPTION_W, ns.OPTION_H, ns.OPTION_LEFT, ns.OPTION_ROW = 632, 601, 296, 24
ns.OPTION_COLS, ns.OPTION_BUTTON_W = 2, 156

-- The kit's state in a line or two, for the page and the minimap tooltip. Second: the /uw command of the button the
-- first line names ("kit fix" or "kit"), nil while the kit is ready; the page draws that one button red.
function ns.OptionsStatus()
  local missReq, _, conflicts, missRaid = ns.CheckKit()
  local off, on = {}, {}
  if ns.KitFixPlan then off, on = ns.KitFixPlan() end
  local lines, primary = {}, nil
  if #missReq + #conflicts == 0 then
    lines[1] = "|cff40ff40Addon kit: ready.|r"
  else
    local parts = {}
    if #missReq > 0 then parts[#parts + 1] = ("%d missing"):format(#missReq) end
    if #conflicts > 0 then parts[#parts + 1] = ("%d doubled up"):format(#conflicts) end
    primary = #off + #on > 0 and "kit fix" or "kit"
    lines[1] = ("|cffff8000Addon kit: %s.|r %s"):format(table.concat(parts, ", "),
      primary == "kit fix" and "Fix my kit does it in one step." or "Check my addon kit shows which.")
  end
  if #missRaid > 0 then lines[#lines + 1] = ("For raiding: %d more to add."):format(#missRaid) end
  if (ns.ownErrors or 0) > 0 then
    lines[#lines + 1] = ("|cffff8000UW_Guild hit %d problem(s) this session.|r Report a problem copies them for the officers.")
      :format(ns.ownErrors)
  end
  return lines, primary
end

-- A button's answer: what the command says for the next few seconds (an audit's results come 6 s later) is shown on
-- the page too, from its first line; the lines that don't fit are counted ("3 more in chat", UI.AnswerSet). It kept
-- its last six lines, so Check my addon kit showed its tips and hid what was missing.
local answer = {}
local echoUntil = 0
local panel, ui -- the registered frame, and its widgets once it has been shown
local function showAnswer()
  if not ui then return end
  local h = ns.UI.AnswerSet(ui.answer, answer, ui.room, nil, ui.per)
  ui.answerBar:SetHeight(math.max(h, 1))
  ui.answerBar:SetShown(#answer > 0)
end
-- A burst of lines (an audit's results, a line a member) is drawn once, a frame later, not once a line: each draw
-- measures the text a few times (red team, #612). The click's own lines show at once (ns.OptionsRun refreshes).
local drawing = false
ns.echo = function(msg)
  if GetTime() > echoUntil then return end
  answer[#answer + 1] = msg
  if drawing or not ui then return end
  drawing = true
  ns.after(0, function()
    drawing = false
    showAnswer()
  end)
end
function ns.OptionsAnswer() return answer end

local armed -- { command, until }: the first click on a guild-wide action
function ns.OptionsRun(entry)
  local cmd = entry[2]
  wipe(answer)
  echoUntil = GetTime() + ns.ECHO_SECONDS
  if entry[4] and not (armed and armed[1] == cmd and GetTime() <= armed[2]) then
    armed = { cmd, GetTime() + ns.CONFIRM_SECONDS }
    say(("Click %s again within %d seconds: it changes this for the whole guild."):format(entry[1], ns.CONFIRM_SECONDS))
    return
  end
  armed = nil
  ns.useFrom = "options" -- usage counts (Core.lua ns.use): a click here, not a typed command
  if entry.set then entry.set(entry.on) else SlashCmdList.UWGUILD(cmd) end
  if ui then ui.refresh() end
end

-- The page ---------------------------------------------------------------------------------------------------------
local function tooltip(owner, title, text)
  if not GameTooltip then return end
  GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
  GameTooltip:SetText(title, 1, 1, 1)
  GameTooltip:AddLine(text, nil, nil, nil, true)
  GameTooltip:Show()
end
local function hideTooltip() if GameTooltip then GameTooltip:Hide() end end

local function describe(owner, entry) tooltip(owner, entry[1], entry[3] .. "\n|cff808080/uw " .. entry[2] .. "|r") end

-- A number the client gave us, at least `least`, else `fallback` (a value it keeps secret is never compared).
local function measure(get, region, least, fallback)
  local ok, v = pcall(get, region)
  v = ok and not ns.isSecret(v) and tonumber(v) or nil
  return v and v >= least and v or fallback
end

-- Every action but one is a quiet button, a list row's size (UI.Quiet): nineteen red buttons read as a wall, with
-- nothing to say which one matters now (design pass, 13 Nov 2026).
local function buttons(parent, list)
  local UI, out = ns.UI, {}
  for i, entry in ipairs(list) do
    local b = UI.Quiet(parent, ns.OPTION_BUTTON_W, entry[1], UI.SMALL)
    b:SetScript("OnClick", function() ns.protect(ns.OptionsRun, entry) end)
    b:SetScript("OnEnter", function(self) describe(self, entry) end)
    b:SetScript("OnLeave", hideTooltip)
    out[i] = b
  end
  return out
end

local ANSWER_IN = 12 -- the answer starts this far in, behind its bar (as in the UW Guild window)
local BOX_IN = 4     -- the game's tick box art sits this far inside its frame: the box, not the frame, lines up with the text

local function build(parent)
  local UI = ns.UI -- Skin.lua loads after this file: the shared numbers are read when the page first shows
  local f = { frame = parent }
  local title = parent:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
  title:SetJustifyH("LEFT")
  title:SetText(ns.OPTION_NAME)
  local sub = UI.Body(parent, ns.OPTION_W)
  sub:SetText(("Version %s. Keeps the guild's addons working together, does the chores ticked below, and runs the "
    .. "welcome, loot rolls and raid records."):format(ns.VERSION))
  f.status = UI.Body(parent, ns.OPTION_W)

  -- One switch per automatic helper, in one column: what each does is visible at a glance, and each turns off here.
  f.switches, f.share = {}, nil
  local labelW = ns.OPTION_LEFT - UI.CHECK - UI.SPACING
  for _, sw in ipairs(ns.OPTION_SWITCHES) do
    local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cb:SetSize(UI.CHECK, UI.CHECK)
    local label = UI.Body(parent, labelW)
    label:SetText(sw.label)
    cb.label = label
    cb:SetScript("OnClick", function(self)
      local on = self:GetChecked() and true or false
      if sw.set then
        ns.protect(ns.OptionsRun, { "", sw.key, set = sw.set, on = on })
      else
        ns.protect(ns.OptionsRun, { "", sw.cmd .. (on and " on" or " off") })
      end
    end)
    cb:SetScript("OnEnter", function(self)
      local need = ns.NeedsMissing(sw) and ("\n|cffffd100Needs %s: /uw kit shows where to get it.|r"):format(sw.needs) or ""
      tooltip(self, sw.label, sw.tip .. need .. (sw.cmd and ("\n|cff808080/uw " .. sw.cmd .. " on, /uw " .. sw.cmd
        .. " off|r") or ""))
    end)
    cb:SetScript("OnLeave", hideTooltip)
    ns.Skin("Checkbox", cb)
    f.switches[sw.key] = cb
  end
  f.share = f.switches.craft
  f.footer = UI.Body(parent, ns.OPTION_W)
  f.footer:SetText(ns.OPTION_FOOTER)

  f.everyoneHeader = parent:CreateFontString(nil, "ARTWORK", "GameFontNormal")
  f.everyoneHeader:SetText("Everyone")
  f.everyone = buttons(parent, ns.OPTION_ACTIONS)
  f.officerHeader = parent:CreateFontString(nil, "ARTWORK", "GameFontNormal")
  f.officerHeader:SetText("Officers")
  f.officer = buttons(parent, ns.OFFICER_ACTIONS)
  -- The one red button: the action the kit's status line names, while the kit needs something. It takes that
  -- action's place in the grid; with the kit ready the page has none.
  f.primary = UI.Button(parent, ns.OPTION_BUTTON_W)
  f.primary:SetHeight(UI.SMALL)
  f.primary:SetScript("OnClick", function() if f.primaryEntry then ns.protect(ns.OptionsRun, f.primaryEntry) end end)
  f.primary:SetScript("OnEnter", function(self) if f.primaryEntry then describe(self, f.primaryEntry) end end)
  f.primary:SetScript("OnLeave", hideTooltip)
  f.primary:Hide()
  -- The answer: across the page's foot, in a place kept for it, so nothing moves when one comes in.
  f.answer = UI.Body(parent, ns.OPTION_W - ANSWER_IN)
  f.answerBar = UI.Thin(UI.Fill(parent, "ARTWORK", 1, 1, 1, 0.25), 2)
  f.answerBar:SetPoint("TOPLEFT", f.answer, "TOPLEFT", -ANSWER_IN, 0)
  f.answerBar:Hide()
  f.room, f.per = UI.LINE, nil

  -- A region hung again only when its place changed: a text let go of can measure 0 until the next frame.
  -- to, toPoint: another region to hang from (the page's top left corner without).
  local placed = {}
  local function at(region, x, top, point, to, toPoint)
    local key = ("%s %.2f %.2f"):format(point or "TOPLEFT", x, top)
    if placed[region] == key then return end
    placed[region] = key
    region:ClearAllPoints()
    region:SetPoint(point or "TOPLEFT", to or parent, toPoint or "TOPLEFT", x, -top)
  end
  local function layout(statusLines, primary)
    local cols, row = ns.OPTION_COLS, ns.OPTION_ROW
    local cw = math.min(ns.OPTION_W, measure(parent.GetWidth, parent, 400, ns.OPTION_W + 2 * UI.PAD) - 2 * UI.PAD)
    local bw = math.min(ns.OPTION_BUTTON_W, math.floor((cw - ns.OPTION_LEFT - UI.PAD - (cols - 1) * UI.GAP) / cols))
    local y = UI.PAD
    at(title, UI.PAD, y)
    y = y + UI.TextHeight(title, 16) + UI.HALF
    sub:SetWidth(cw)
    at(sub, UI.PAD, y)
    y = y + UI.TextHeight(sub, 2 * UI.LINE - UI.SPACING) + UI.GAP
    f.status:SetWidth(cw)
    at(f.status, UI.PAD, y)
    y = y + UI.TextHeight(f.status, statusLines * UI.LINE - UI.SPACING) + UI.GROUP
    local top = y
    -- The switches this player sees, one to a row, so a hidden one leaves no gap. EllesmereUI draws a tick box as
    -- big as its frame, so a column of them stood edge to edge: there the box is a button's height, flush with the
    -- text over it, and its words start as far from it as they do from the game's own box art.
    local skinned = ns.Skinned() and true or false
    local box, n = skinned and UI.SMALL or UI.CHECK, 0
    f.labelGap = UI.SPACING + (skinned and BOX_IN or 0)
    for _, sw in ipairs(ns.OPTION_SWITCHES) do
      local cb, on = f.switches[sw.key], ns.SwitchShown(sw)
      cb:SetShown(on)
      cb.label:SetShown(on)
      cb:SetSize(box, box)
      at(cb.label, f.labelGap, 0, "LEFT", cb, "RIGHT")
      if on then
        at(cb, UI.PAD - (skinned and 0 or BOX_IN), top + n * row + (row - box) / 2)
        n = n + 1
      end
    end
    -- The buttons: a group's heading takes a row, then its buttons, cols to a row, each centred on its row.
    local x0, r = UI.PAD + ns.OPTION_LEFT + UI.PAD, 0
    f.primary:Hide()
    f.primaryEntry = nil
    local function group(header, list, entries, shown)
      header:SetShown(shown)
      for i, b in ipairs(list) do
        local red = shown and primary ~= nil and entries[i][2] == primary
        b:SetShown(shown and not red)
        b:SetWidth(bw)
        if shown then
          at(b, x0 + ((i - 1) % cols) * (bw + UI.GAP), top + (r + 1 + math.floor((i - 1) / cols)) * row + (row - UI.SMALL) / 2)
        end
        if red then
          f.primaryEntry = entries[i]
          f.primary:SetText(entries[i][1])
          f.primary:SetWidth(bw)
          f.primary:ClearAllPoints()
          f.primary:SetPoint("TOPLEFT", b, "TOPLEFT")
          f.primary:Show()
        end
      end
      if not shown then return end
      at(header, x0, top + r * row + row / 2, "LEFT")
      r = r + 1 + math.ceil(#list / cols)
    end
    group(f.everyoneHeader, f.everyone, ns.OPTION_ACTIONS, true)
    group(f.officerHeader, f.officer, ns.OFFICER_ACTIONS, ns.isOfficer(ns.me()))
    -- Under the longer column: the no-penalty line, then the answer down to the page's foot.
    y = top + math.max(n, r) * row + UI.HALF
    f.footer:SetWidth(cw)
    at(f.footer, UI.PAD, y)
    y = y + UI.TextHeight(f.footer, UI.LINE - UI.SPACING) + UI.GROUP
    f.answer:SetWidth(cw - ANSWER_IN)
    f.per = (cw - ANSWER_IN) / 6 -- the letters one of its lines holds, for a text the client can't measure yet
    at(f.answer, UI.PAD + ANSWER_IN, y)
    f.room = math.max(UI.LINE, measure(parent.GetHeight, parent, 300, ns.OPTION_H) - y - UI.GAP)
  end

  f.refresh = function()
    local lines, primary = ns.OptionsStatus()
    f.status:SetText(table.concat(lines, "\n"))
    layout(#lines, primary)
    for _, sw in ipairs(ns.OPTION_SWITCHES) do
      local cb, missing = f.switches[sw.key], ns.NeedsMissing(sw)
      cb:SetChecked(not missing and sw.on() and true or false)
      if cb.SetEnabled then cb:SetEnabled(not missing) end
      cb.label:SetText(missing and ("|cff808080%s (needs %s)|r"):format(sw.label, sw.needs) or sw.label)
      -- A click on the words ticks the box too: its click area runs over its label.
      if cb.SetHitRectInsets then
        cb:SetHitRectInsets(0, -(f.labelGap + math.min(labelW, measure(cb.label.GetStringWidth, cb.label, 1, labelW))), 0, 0)
      end
    end
    showAnswer()
  end
  return f
end

-- Registered at start-up: the game's Settings panel (10.0 and later), or the older Interface Options list.
local category
local function register()
  panel = CreateFrame("Frame")
  panel.name = ns.OPTION_NAME
  panel:SetScript("OnShow", function(self)
    ui = ui or build(self)
    -- The page opens without an old answer: one stays only while its lines can still come in (a switch clicked in
    -- the UW Guild window an hour ago left its line here, under no heading now).
    if GetTime() > echoUntil then wipe(answer) end
    ui.refresh()
  end)
  if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
    category = Settings.RegisterCanvasLayoutCategory(panel, ns.OPTION_NAME)
    Settings.RegisterAddOnCategory(category)
  elseif InterfaceOptions_AddCategory then
    InterfaceOptions_AddCategory(panel)
  end
end
table.insert(ns.onLoad, register)
function ns.OptionsPanel() return panel, ui end

function ns.OpenOptions()
  if InCombatLockdown() then say("After combat, please: /uw options") return end
  local id = category and (category.GetID and category:GetID() or category.ID)
  if id and Settings.OpenToCategory then
    Settings.OpenToCategory(id)
  elseif InterfaceOptionsFrame_OpenToCategory and panel then
    InterfaceOptionsFrame_OpenToCategory(panel)
    InterfaceOptionsFrame_OpenToCategory(panel) -- the old list needs two calls to scroll to an addon
  else
    say("This game client has no options window for addons. Type /uw for every command.")
  end
end
ns.commands.options = ns.OpenOptions

-- The UW Guild window (Handbook.lua), or this page when the window isn't loaded: a new TOC file loads only after a full
-- game restart, so the first /reload after an update has no window (integrator finding 39).
function ns.OpenEveryFeature()
  if ns.OpenHandbook then return ns.OpenHandbook() end
  return ns.OpenOptions()
end
-- The minimap's addon menu. Left-click: the UW Guild window. Right-click: the kit check, straight to chat.
function UW_Guild_OnAddonCompartmentClick(_, button)
  if button == "RightButton" then ns.protect(SlashCmdList.UWGUILD, "kit") else ns.protect(ns.OpenEveryFeature) end
end
function UW_Guild_OnAddonCompartmentEnter(_, frame)
  if not GameTooltip then return end
  GameTooltip:SetOwner(type(frame) == "table" and frame or UIParent, type(frame) == "table" and "ANCHOR_LEFT" or "ANCHOR_CURSOR")
  GameTooltip:SetText(ns.OPTION_NAME, 1, 1, 1)
  local ok, lines = pcall(ns.OptionsStatus)
  for _, line in ipairs(ok and lines or {}) do GameTooltip:AddLine(line, nil, nil, nil, true) end
  GameTooltip:AddLine("|cff808080Left-click: every feature. Right-click: check my kit.|r")
  GameTooltip:Show()
end
function UW_Guild_OnAddonCompartmentLeave() hideTooltip() end
