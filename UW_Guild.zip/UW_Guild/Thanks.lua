-- /uw thanks <name> (addon-value item 2, Louis 5 Nov 2026): thank a guildmate in game, counted toward their Officer path
-- exactly like Discord's thanks (once per different guildmate, no scores, no reminders). Most help happens in dungeons,
-- where there was no way to thank; being thanked roughly doubles willingness to help again (Grant & Gino 2010).
--   * Only a guildmate you grouped with in the last 3 hours (or are grouped with now), at most once a day each.
--   * Store and forward: the bot reads only the saves on the Guild Master's PC (the client that has the bot's
--     Schedule.lua). Your client sends THK on the guild channel and keeps it until that client answers (THKA);
--     it resends at each login for 7 days, then drops it. The thanker is the game's own sender name, never a field.
local _, ns = ...
local say = ns.say

local RECENT, DAY, KEEP, MAX_OUT = 3 * 3600, 86400, 7 * 86400, 20
local function now() return (GetServerTime and GetServerTime()) or time() end
local function key(name) return ns.shortName(name) or name end

-- Recorder: the client whose saves the bot reads (it has the bot's Schedule.lua).
local function recorder() return type(ns.SCHEDULE) == "table" and (ns.finite(ns.SCHEDULE.gen) or 0) > 0 end

local function guildmate(name)
  local full = ns.fullName(name)
  return full ~= nil and ns.rankOf[full] ~= nil
end

-- Guildmates in the group now; remembered with the time, pruned after 3 hours.
local function noteGroup()
  local seen, t = UW_GuildDB.grouped or {}, now()
  local raid = IsInRaid()
  for i = 1, raid and GetNumGroupMembers() or math.max(0, GetNumGroupMembers() - 1) do
    local unit = (raid and "raid" or "party") .. i
    local name = ns.unitFull(unit)       -- "First Last" on Forever, as the roster has it
    if name and UnitIsInMyGuild(unit) and not UnitIsUnit(unit, "player") then
      seen[key(name)] = t
    end
  end
  for n, at in pairs(seen) do if t - at > RECENT then seen[n] = nil end end
  UW_GuildDB.grouped = seen
end

local function record(from, to, at)
  local seen = UW_GuildDB.thanksIn or {}
  local k = from .. ">" .. to .. ">" .. at
  if seen[k] then return end
  seen[k] = now()
  for kk, t in pairs(seen) do if now() - t > KEEP then seen[kk] = nil end end
  UW_GuildDB.thanksIn = seen
  ns.queue("thanks", from, to .. ";" .. at)
end

local function sendPending()
  local out = UW_GuildDB.thanksOut or {}
  for i = #out, 1, -1 do if now() - (out[i].at or 0) > KEEP then table.remove(out, i) end end
  for i = 1, math.min(#out, 5) do ns.send(("THK\t%s\t%d"):format(out[i].to, out[i].at), "GUILD") end
end

ns.commands.thanks = function(args)
  local name = strtrim(args or "")
  noteGroup()
  if name == "" then
    local recent = {}
    for n in pairs(UW_GuildDB.grouped or {}) do recent[#recent + 1] = n end
    table.sort(recent)
    say(#recent > 0 and ("Thank a guildmate who helped: /uw thanks <name>. Grouped lately: %s."):format(table.concat(recent, ", "))
      or "Thank a guildmate you grouped with in the last 3 hours: /uw thanks <name>.")
    return
  end
  if not IsInGuild() then say("Join Unbothered Warlords to thank guildmates.") return end
  local to = key(name)
  if not guildmate(name) then say(("%s isn't in the guild roster."):format(name)) return end
  if to == key(ns.me()) then say("You can't thank yourself.") return end
  if not (UW_GuildDB.grouped or {})[to] then say(("Thanks count after a group: you haven't grouped with %s in the last 3 hours."):format(to)) return end
  local done = UW_GuildDB.thanked or {}
  if done[to] and now() - done[to] < DAY then say(("You already thanked %s today."):format(to)) return end
  local at = now()
  done[to], UW_GuildDB.thanked = at, done
  if recorder() then
    record(key(ns.me()), to, at)
  else
    local out = UW_GuildDB.thanksOut or {}
    if #out >= MAX_OUT then table.remove(out, 1) end
    out[#out + 1] = { to = to, at = at }
    UW_GuildDB.thanksOut = out
    sendPending()
  end
  say(("Thanks sent to %s. It counts toward their Officer path once the guild's records get it."):format(to))
end
ns.GameThanks = ns.commands.thanks

-- The recorder takes a thank-you from a guildmate about a guildmate, and answers so the sender stops resending.
ns.handlers.THK = function(sender, channel, to, at)
  at = ns.finite(at)
  if channel ~= "GUILD" or not recorder() or not at or at > now() + 600 or now() - at > KEEP then return end
  if type(to) ~= "string" or not guildmate(sender) or not guildmate(to) or key(to) == key(sender) then return end
  record(key(sender), key(to), math.floor(at))
  ns.send(("THKA\t%s\t%d"):format(key(to), at), "WHISPER", sender)
end

ns.handlers.THKA = function(sender, channel, to, at)
  if channel ~= "WHISPER" or not guildmate(sender) then return end
  local out, a = UW_GuildDB.thanksOut or {}, ns.finite(at)
  for i = #out, 1, -1 do if out[i].to == to and out[i].at == a then table.remove(out, i) end end
end

-- The recorder asks at its login, so thanks sent while it was offline arrive without waiting for the sender's login.
ns.handlers.THKQ = function(_, channel)
  if channel == "GUILD" and #(UW_GuildDB.thanksOut or {}) > 0 then
    C_Timer.After(math.random() * 10, function() ns.protect(sendPending) end)
  end
end

local f = CreateFrame("Frame")
ns.listen(f, { "GROUP_ROSTER_UPDATE", "PLAYER_ENTERING_WORLD" })
f:SetScript("OnEvent", function(_, event, isLogin, isReload)
  ns.protect(noteGroup)
  if event == "PLAYER_ENTERING_WORLD" and (isLogin or isReload) and IsInGuild() then
    C_Timer.After(40, function()
      ns.protect(sendPending)
      if recorder() then ns.send("THKQ", "GUILD") end
    end)
  end
end)

-- /uw rate (Louis, 8 Nov 2026): "if a raider wants to lead, that's PERFECT ... the followers get a survey to rank
-- their leader who can make Officer by demonstrating trust, care, integrity, leadership, patience". Nobody is
-- appointed: whoever leads a guild raid or dungeon group is the leader, and the people they led say how it went. The
-- bot counts a good record toward Officer (paths.py, docs/ownership.md); single ratings are never shown to anyone.
--   * Asked only after a boss kill in a guild group (a raid at least half guildmates, or a party mostly guildmates)
--     led by a guildmate who isn't you, once the group ends and you're out of combat. At most one ask a day and three a
--     week, like the bot's ping budget (docs/pings.md); /uw rate off stops them.
--   * Private: the rating goes by whisper to the Guild Master's client only (the recorder), never on the guild
--     channel. Kept and resent for 7 days, as thanks are, until that client acknowledges it.
--   * Gentle rollout (CONTRIBUTING.md): officers can rate at once; asks for everyone from Fri 13 Nov 2026, with one
--     line at login from Thu 12 Nov saying it's coming and how to turn it off.
local RATE_FROM, RATE_HEADSUP = 1794528000, 1794441600   -- Fri 13 Nov / Thu 12 Nov 2026, 00:00 UTC
local STRENGTHS = { t = "trust", c = "care", i = "integrity", l = "leadership", p = "patience" }
local STRENGTH_ORDER = "tcilp"
local LED_KEEP, ASKS_WEEK = DAY, 3

local function rateOpen() return ns.isOfficer(ns.me()) or now() >= RATE_FROM end
local function isGM(name) local full = ns.fullName(name) return full ~= nil and ns.rankOf[full] == 0 end

-- The group's leader when it is a guild group led by a guildmate other than me, with "raid" or "dungeon".
local function guildGroupLeader()
  local raid, n = IsInRaid(), GetNumGroupMembers()
  if n == 0 then return end
  local total, guild, leader = 1, 1, nil     -- counting me
  for i = 1, raid and n or n - 1 do
    local unit = (raid and "raid" or "party") .. i
    if not UnitIsUnit(unit, "player") then
      total = total + 1
      if UnitIsInMyGuild(unit) then guild = guild + 1 end
      if UnitIsGroupLeader(unit) then
        local name = ns.unitFull(unit)   -- "First Last" on Forever: UnitName alone gives the first name
        if name and UnitIsInMyGuild(unit) then leader = key(name) end
      end
    end
  end
  if raid and guild * 2 >= total then return leader, "raid" end
  if not raid and total >= 3 and guild * 2 > total then return leader, "dungeon" end
end

-- A boss kill: remember who led it, for 24 hours (/uw rate names them), and queue one ask for the end of the group.
function ns.NoteLedKill()
  local leader, kind = guildGroupLeader()
  if not leader or leader == key(ns.me()) or not guildmate(leader) then return end
  local led, t = UW_GuildDB.ledBy or {}, now()
  led[leader] = { at = t, kind = kind }
  for n, v in pairs(led) do if type(v) ~= "table" or t - (v.at or 0) > LED_KEEP then led[n] = nil end end
  UW_GuildDB.ledBy = led
  local rated = (UW_GuildDB.rated or {})[leader]
  if not (rated and t - rated < DAY) then UW_GuildDB.rateAsk = { leader = leader, kind = kind, at = t } end
end

-- The ask, at a break: the group has ended (or at login), out of combat, within the caps.
function ns.MaybeAskRate()
  local ask = UW_GuildDB.rateAsk
  if not ask or IsInGroup() or InCombatLockdown() then return end
  local t = now()
  if UW_GuildDB.rateOff or not rateOpen() or t - (ask.at or 0) > LED_KEEP then UW_GuildDB.rateAsk = nil return end
  local asked = UW_GuildDB.rateAsked or {}
  for i = #asked, 1, -1 do if t - asked[i] >= 7 * DAY then table.remove(asked, i) end end
  UW_GuildDB.rateAsked = asked
  if #asked >= ASKS_WEEK or (asked[#asked] and t - asked[#asked] < DAY) then return end   -- keep it for tomorrow
  asked[#asked + 1], UW_GuildDB.rateAsk = t, nil
  say(("How did %s lead? /uw rate 1-5, plus any of: trust, care, integrity, leadership, patience. Private; "
    .. "/uw rate off stops these."):format(ask.leader))
end

local function recordRate(from, r)
  local seen = UW_GuildDB.rateIn or {}
  local k = from .. ">" .. r.leader .. ">" .. r.at
  if seen[k] then return end
  seen[k] = now()
  for kk, at in pairs(seen) do if now() - at > KEEP then seen[kk] = nil end end
  UW_GuildDB.rateIn = seen
  ns.queue("lead", from, ("%s;%d;%s;%s;%d"):format(r.leader, r.score, r.s, r.kind, r.at))
end

local function rateTo(target)
  for i, r in ipairs(UW_GuildDB.rateOut or {}) do
    if i > 5 then break end
    ns.send(("RT\t%s\t%d\t%s\t%s\t%d"):format(r.leader, r.score, r.s ~= "" and r.s or "-", r.kind, r.at), "WHISPER", target)
  end
end
local function rateOutstanding()
  local out, t = UW_GuildDB.rateOut or {}, now()
  for i = #out, 1, -1 do if t - (out[i].at or 0) > KEEP then table.remove(out, i) end end
  return #out > 0
end

-- "5", "5 care patience", "Mia 4 trust", "off", "on".
ns.commands.rate = function(args)
  local words = {}
  for w in (args or ""):lower():gmatch("[%a%d%-]+") do words[#words + 1] = w end
  local led, t = UW_GuildDB.ledBy or {}, now()
  local leader, score
  if words[1] and not tonumber(words[1]) and words[1] ~= "off" and words[1] ~= "on" then
    -- A leader's name can be two words on Forever ("Mia Stone 4 care"): the longest run that names one wins.
    local typed, rest = ns.splitName(args, function(s)
      for n, v in pairs(led) do
        if n:lower() == s:lower() and t - (v.at or 0) <= LED_KEEP then return n end
      end
    end)
    if not (typed and led[typed] and t - (led[typed].at or 0) <= LED_KEEP) then
      if rateOpen() then
        say(("You can rate %s for 24 hours after they lead a guild group to a boss kill."):format(typed or words[1]))
      else
        say("Coming Friday: /uw rate, to say how a guild raid or dungeon leader did. Optional.")
      end
      return
    end
    leader, words = typed, {}
    for w in rest:lower():gmatch("[%a%d%-]+") do words[#words + 1] = w end
  end
  if words[1] == "off" or words[1] == "on" then
    UW_GuildDB.rateOff = words[1] == "off" or nil
    if UW_GuildDB.rateOff then UW_GuildDB.rateAsk = nil end
    say(UW_GuildDB.rateOff and "No more asks to rate a leader. /uw rate on brings them back."
      or "You'll be asked after a guild group's boss kill, at most once a day. /uw rate off stops it.")
    return
  end
  if not rateOpen() then say("Coming Friday: /uw rate, to say how a guild raid or dungeon leader did. Optional.") return end
  if not leader then
    local newest = 0
    for n, v in pairs(led) do
      if t - (v.at or 0) <= LED_KEEP and v.at > newest then leader, newest = n, v.at end
    end
  end
  score = tonumber(words[1] or "")
  if not leader then say("Lead or follow a guild raid or dungeon to a boss kill, then /uw rate 1-5 for its leader.") return end
  if not score or score ~= math.floor(score) or score < 1 or score > 5 then
    say(("How did %s lead? /uw rate 1-5, plus any of: trust, care, integrity, leadership, patience."):format(leader))
    return
  end
  local picked = {}
  for i = 2, #words do
    for c, name in pairs(STRENGTHS) do if name:sub(1, #words[i]) == words[i] and #words[i] >= 3 then picked[c] = true end end
  end
  local s = ""
  for c in STRENGTH_ORDER:gmatch(".") do if picked[c] then s = s .. c end end
  local rated = UW_GuildDB.rated or {}
  if rated[leader] and t - rated[leader] < DAY then say(("You already rated %s today."):format(leader)) return end
  rated[leader], UW_GuildDB.rated = t, rated
  local r = { leader = leader, score = score, s = s, kind = led[leader].kind == "raid" and "r" or "d", at = t }
  if UW_GuildDB.rateAsk and UW_GuildDB.rateAsk.leader == leader then UW_GuildDB.rateAsk = nil end
  if recorder() then
    recordRate(key(ns.me()), r)
  else
    local out = UW_GuildDB.rateOut or {}
    if #out >= MAX_OUT then table.remove(out, 1) end
    out[#out + 1] = r
    UW_GuildDB.rateOut = out
    ns.send("VBH", "GUILD")
  end
  say(("Thanks. Your rating of %s is private: it only ever counts in totals from 5 or more guildmates."):format(leader))
end
ns.GameRate = ns.commands.rate

-- The recorder takes a rating from a guildmate about a guildmate, by whisper only, and answers so it isn't resent.
ns.handlers.RT = function(sender, channel, leader, score, s, kind, at)
  at, score = ns.finite(at), ns.finite(score)
  if channel ~= "WHISPER" or not recorder() or not guildmate(sender) then return end
  if type(leader) ~= "string" or not guildmate(leader) or key(leader) == key(sender) then return end
  if not score or score < 1 or score > 5 or score ~= math.floor(score) or (kind ~= "r" and kind ~= "d") then return end
  if type(s) ~= "string" or (s ~= "-" and not s:match("^[tcilp]+$")) or #s > 5 then return end
  if not at or at > now() + 600 or now() - at > KEEP then return end
  recordRate(key(sender), { leader = key(leader), score = score, s = s == "-" and "" or s,
    kind = kind == "r" and "raid" or "dungeon", at = math.floor(at) })
  ns.send(("RTA\t%s\t%d"):format(key(leader), at), "WHISPER", sender)
end

ns.handlers.RTA = function(sender, channel, leader, at)
  if channel ~= "WHISPER" or not isGM(sender) then return end
  local out, a = UW_GuildDB.rateOut or {}, ns.finite(at)
  for i = #out, 1, -1 do if out[i].leader == leader and out[i].at == a then table.remove(out, i) end end
end

local rf = CreateFrame("Frame")
ns.listen(rf, { "ENCOUNTER_END", "GROUP_ROSTER_UPDATE", "PLAYER_REGEN_ENABLED", "PLAYER_ENTERING_WORLD" })
rf:SetScript("OnEvent", function(_, event, ...)
  if event == "ENCOUNTER_END" then
    local success = select(5, ...)
    if success == 1 and IsInGuild() then ns.protect(ns.NoteLedKill) end
  elseif event == "PLAYER_ENTERING_WORLD" then
    local isLogin, isReload = ...
    if not ((isLogin or isReload) and IsInGuild()) then return end
    C_Timer.After(50, function()
      ns.protect(ns.MaybeAskRate)
      if not UW_GuildDB.rateTold and now() >= RATE_HEADSUP and not recorder() then
        UW_GuildDB.rateTold = true
        say((now() >= RATE_FROM and "New" or "From Friday")
          .. ": after a guild raid or dungeon boss kill you may get asked how its leader did. Private; /uw rate off.")
      end
    end)
  else
    ns.protect(ns.MaybeAskRate)
  end
end)

-- Keeping the Officer rank (Louis, 8 Nov 2026: "maintained by a good ratio of positive and helpful interactions";
-- the Guild Master too). The bot writes a private note into ns.UPKEEP (Schedule.lua, bot/uwbot/upkeep.py) for an
-- officer whose last 8 weeks fell under 3 in 4 positive, or who is back above it. Only they hear it first, in game:
-- this client (the Guild Master's) whispers it when they're online (UPK), their UW_Guild prints it and answers (UPKA),
-- and the bot is told it arrived, which starts their four weeks. Only the Guild Master's client is believed.
local function upkeepList() return type(ns.UPKEEP) == "table" and ns.UPKEEP or {} end

local function upkeepDelivered(id, to)
  local done = UW_GuildDB.upkeepDone or {}
  if done[id] then return end
  done[id], UW_GuildDB.upkeepDone = now(), done
  ns.queue("upkeep", to, id)
end

function ns.DeliverUpkeep()
  if not recorder() then return end
  local online = {}
  for _, n in ipairs(ns.silentOnline({})) do online[key(n)] = true end
  local done = UW_GuildDB.upkeepDone or {}
  for id, at in pairs(done) do if now() - at > 30 * DAY then done[id] = nil end end
  for _, u in ipairs(upkeepList()) do
    local id, to, text = u[1], u[2], u[3]
    if type(id) == "string" and type(to) == "string" and type(text) == "string" and not done[id] then
      if key(to) == key(ns.me()) then
        say(text)
        upkeepDelivered(id, key(to))
      elseif online[key(to)] then
        ns.send(("UPK\t%s\t%s"):format(id, text), "WHISPER", to)
      end
    end
  end
end

ns.handlers.UPK = function(sender, channel, id, text)
  if channel ~= "WHISPER" or not isGM(sender) or type(id) ~= "string" or type(text) ~= "string" then return end
  local seen = UW_GuildDB.upkeepSeen or {}
  if not seen[id] then say(text) end
  seen[id], UW_GuildDB.upkeepSeen = now(), seen
  for k, at in pairs(seen) do if now() - at > 30 * DAY then seen[k] = nil end end
  ns.send("UPKA\t" .. id, "WHISPER", sender)
end

ns.handlers.UPKA = function(sender, channel, id)
  if channel ~= "WHISPER" or not recorder() then return end
  for _, u in ipairs(upkeepList()) do
    if u[1] == id and type(u[2]) == "string" and key(u[2]) == key(sender) then upkeepDelivered(id, key(sender)) end
  end
end

local uf, upkeepAt = CreateFrame("Frame"), 0
ns.listen(uf, { "GUILD_ROSTER_UPDATE", "PLAYER_ENTERING_WORLD" })
uf:SetScript("OnEvent", function(_, event, isLogin, isReload)
  if event == "PLAYER_ENTERING_WORLD" then
    if (isLogin or isReload) and IsInGuild() then C_Timer.After(55, function() ns.protect(ns.DeliverUpkeep) end) end
  elseif now() - upkeepAt >= 300 then            -- the roster updates often; an officer coming online is enough
    upkeepAt = now()
    ns.protect(ns.DeliverUpkeep)
  end
end)

-- /uw vibe goofy|chill|either (Louis, 8 Nov 2026: "I can make it an onboarding choice"; core interactions stay in
-- game). How you like guild chat: goofy welcome, or keep it chill. Same store and rules as the Discord question in
-- the /uw-match extras: officers see totals only, from 5 answers, so nobody's pick can be worked out.
--   * Private: the pick is never put on the guild channel, where any guildmate's addon could read it. Your client says
--     hello (VBH, no value) on the guild channel; the recorder whispers VBQ; you whisper the pick (VB) to it, and only
--     to an officer. The recorder asks at its login too (VBQ on GUILD), so a pick made while it was offline arrives.
--   * One answer per WoW account (vibeId, random): changing it on an alt replaces it, never adds a second one.
--   * Gentle rollout (CONTRIBUTING.md): officers can use it at once; members from Thu 12 Nov 2026, with one line at
--     login from Wed 11 Nov saying it's coming and how to clear it.
local VIBES = { goofy = "Goofy chat welcome", chill = "Keep it chill", either = "Either is fine" }
local VIBE_FROM, VIBE_HEADSUP = 1794441600, 1794355200    -- Thu 12 Nov / Wed 11 Nov 2026, 00:00 UTC

local function vibeOpen() return ns.isOfficer(ns.me()) or now() >= VIBE_FROM end
ns.RateOpen, ns.VibeOpen = rateOpen, vibeOpen   -- /uw help lists each command once it's open (Core.lua)

local function vibeId()
  local id = UW_GuildDB.vibeId
  if type(id) ~= "string" or not id:match("^%x%x%x%x%x%x%x%x%x%x%x%x$") then
    id = ("%06x%06x"):format(math.random(0, 0xffffff), math.random(0, 0xffffff))
    UW_GuildDB.vibeId = id
  end
  return id
end

local function recordVibe(from, v, id, at)
  local seen = UW_GuildDB.vibeIn or {}
  if (seen[id] or 0) >= at then return end    -- an older or repeated pick from this account
  seen[id], UW_GuildDB.vibeIn = at, seen
  ns.queue("vibe", from, ("%s;%s;%d"):format(v, id, at))
end

local function vibeTo(target)
  local out = UW_GuildDB.vibeOut
  if out and target then ns.send(("VB\t%s\t%s\t%d"):format(out.v, out.id, out.at), "WHISPER", target) end
end

ns.commands.vibe = function(args)
  local pick = strtrim(args or ""):lower()
  if not vibeOpen() then say("Coming Thursday: /uw vibe, to say how you like guild chat. Optional.") return end
  local mine = UW_GuildDB.vibe and VIBES[UW_GuildDB.vibe.v]
  if not VIBES[pick] then
    say(("Guild chat: %s. Change it: /uw vibe goofy, /uw vibe chill, or /uw vibe either to clear it.")
      :format(mine or "no answer yet"))
    say("Optional. Officers only ever see totals, never who picked what.")
    return
  end
  if not IsInGuild() then say("Join Unbothered Warlords to answer this.") return end
  local at = now()
  UW_GuildDB.vibe = pick ~= "either" and { v = pick, at = at } or nil
  if recorder() then
    recordVibe(key(ns.me()), pick, vibeId(), at)
  else
    UW_GuildDB.vibeOut = { v = pick, id = vibeId(), at = at }
    ns.send("VBH", "GUILD")
  end
  say(pick == "either" and "Cleared: either is fine. Nothing about your guild chat is saved now."
    or ("Saved: %s. Officers see totals only. /uw vibe either clears it."):format(VIBES[pick]))
end
ns.GameVibe = ns.commands.vibe

-- The recorder answers a hello with a private ask; members answer only an officer's ask.
ns.handlers.VBH = function(sender, channel)
  if channel == "GUILD" and recorder() and guildmate(sender) then ns.send("VBQ", "WHISPER", sender) end
end

-- Ratings (/uw rate) answer the same ask, but only the Guild Master's: officers may be the ones rated.
local function privateTo(target)
  if ns.isOfficer(target) then vibeTo(target) end
  if isGM(target) and rateOutstanding() then rateTo(target) end
end

ns.handlers.VBQ = function(sender, channel)
  if not ((UW_GuildDB.vibeOut and ns.isOfficer(sender)) or (isGM(sender) and rateOutstanding())) then return end
  if channel == "GUILD" then
    C_Timer.After(math.random() * 10, function() ns.protect(privateTo, sender) end)
  elseif channel == "WHISPER" then
    privateTo(sender)
  end
end

ns.handlers.VB = function(sender, channel, v, id, at)
  at = ns.finite(at)
  if channel ~= "WHISPER" or not recorder() or not guildmate(sender) or not VIBES[v or ""] then return end
  if type(id) ~= "string" or not id:match("^%x%x%x%x%x%x%x%x%x%x%x%x$") then return end
  if not at or at > now() + 600 or now() - at > KEEP then return end
  recordVibe(key(sender), v, id, math.floor(at))
  ns.send(("VBA\t%d"):format(at), "WHISPER", sender)
end

ns.handlers.VBA = function(sender, channel, at)
  local out = UW_GuildDB.vibeOut
  if channel == "WHISPER" and out and ns.isOfficer(sender) and ns.finite(at) == out.at then UW_GuildDB.vibeOut = nil end
end

local vf = CreateFrame("Frame")
ns.listen(vf, { "PLAYER_ENTERING_WORLD" })
vf:SetScript("OnEvent", function(_, _, isLogin, isReload)
  if not ((isLogin or isReload) and IsInGuild()) then return end
  C_Timer.After(45, function()
    ns.protect(function()
      local out = UW_GuildDB.vibeOut
      if out and now() - (out.at or 0) > KEEP then UW_GuildDB.vibeOut, out = nil, nil end
      if out or rateOutstanding() then ns.send("VBH", "GUILD") end
      if recorder() then ns.send("VBQ", "GUILD") end
      if not UW_GuildDB.vibeTold and now() >= VIBE_HEADSUP and not recorder() then
        UW_GuildDB.vibeTold = true
        say((now() >= VIBE_FROM and "New" or "From Thursday")
          .. ": /uw vibe says if you like goofy guild chat or chill. Optional; officers see totals only.")
      end
    end)
  end)
end)
