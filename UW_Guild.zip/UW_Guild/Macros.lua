-- /uw kit macros: the guild's vetted macros for the player's class (macro library thread, Louis's OK 4 Nov 2026,
-- 18:10). The library is MacroLibrary.lua, generated from docs/macros by the bot's checker: the same macros, in the
-- same order, as the macro card in each class hub in Discord. /uw kit macros lists the class's S tier;
-- /uw kit macros leveling, dungeon, raid, pvp or all lists more. One click adds only the S tier, and leaves
-- ns.MACRO_KEEP_FREE character slots for the player's own macros; any other is added by its number, which is the same
-- in every view. Add checks each macro the way the bot's reference does (bot/tests/test_macros.py add_problem; both
-- read bot/tests/fixtures/macro_vectors.lua), in this order: combat, name (1 to 16 bytes), body (1 to 255 bytes),
-- tooltip (a macro that casts a spell starts with #showtooltip or #show), spell (this client knows every spell ID),
-- renamed (and calls it by the same name), exists (no macro of that name yet), full (a free slot). It never changes or
-- deletes a macro the player already has. A class macro goes in this character's macros only, so another class's
-- alts never see it in their General tab; an every-class one goes in the General tab (once for every character), or
-- this character's when that is full.
-- The client check: once a session, out of combat, every spell ID in the whole library is looked up, and what this
-- client lacks or names differently is kept in UW_GuildDB.client.spells, so the bot can mark macros as checked on
-- Forever's client.
local _, ns = ...
local say = ns.say

ns.MACRO_NAME_MAX, ns.MACRO_BODY_MAX = 16, 255
ns.MACRO_ICON = "INV_Misc_QuestionMark" -- with #showtooltip, the game shows the spell's own icon

local function pass(ok, ...) if ok then return ... end end
-- This client's name for a spell ID, or nil when it doesn't know the spell. By ID, not name: by name the game only
-- finds spells in the player's own spellbook.
function ns.SpellName(id)
  local name
  if C_Spell and C_Spell.GetSpellInfo then
    local info = pass(pcall(C_Spell.GetSpellInfo, id))
    name = type(info) == "table" and info.name or nil
  elseif GetSpellInfo then
    name = pass(pcall(GetSpellInfo, id))
  end
  return type(name) == "string" and not ns.isSecret(name) and name ~= "" and name or nil
end

-- Names differ on a client in another language, so there a different name isn't a rename.
local function english() return not GetLocale or tostring(GetLocale()):match("^en") ~= nil end

-- The first reason Add refuses this macro, or nil. state = { combat, have = names already there, free = slots left }.
function ns.MacroProblem(m, state, spellName)
  spellName = spellName or ns.SpellName
  if state.combat then return "combat" end
  if #m.name == 0 or #m.name > ns.MACRO_NAME_MAX then return "name" end
  if #m.body == 0 or #m.body > ns.MACRO_BODY_MAX then return "body" end
  if next(m.spells) ~= nil then
    local first = ((m.body:match("^[^\n]*") or ""):match("^[^ ]*") or ""):lower()
    if first ~= "#showtooltip" and first ~= "#show" then return "tooltip" end
  end
  for id in pairs(m.spells) do
    if not spellName(id) then return "spell" end
  end
  if english() then
    for id, name in pairs(m.spells) do
      if spellName(id) ~= name then return "renamed" end
    end
  end
  for _, have in ipairs(state.have or {}) do
    if have == m.name then return "exists" end
  end
  if (state.free or 1) <= 0 then return "full" end
end

local WHY = {
  combat = "after combat",
  name = "its name is too long for the game (tell an officer)",
  body = "it's too long for the game (tell an officer)",
  tooltip = "it's missing its #showtooltip line (tell an officer)",
  spell = "your client doesn't know one of its spells (tell an officer)",
  renamed = "one of its spells has another name on Forever (tell an officer)",
  exists = "you have it",
  full = "no free slot in this character's macros: delete one in /macro",
}
ns.MACRO_WHY = WHY

-- This class's library, best first, then the one for every class.
function ns.MyMacros()
  local _, token = UnitClass("player")
  local out = {}
  for _, key in ipairs({ token or "", "GENERAL" }) do
    for _, m in ipairs(ns.MACROS and ns.MACROS[key] or {}) do out[#out + 1] = m end
  end
  return out
end

-- The player's macros now: their names, and the free character and account slots.
local function macroState()
  local nAccount, nChar = 0, 0
  if GetNumMacros then nAccount, nChar = GetNumMacros() end
  -- Forever's counts (the bot's macro_vectors.lua slots), when the game's globals aren't loaded.
  -- The live client keeps the limits in Constants.MacroConsts (120 and 30); older ones have the globals.
  local mc = Constants and Constants.MacroConsts or {}
  local maxAccount = tonumber(mc.MAX_ACCOUNT_MACROS) or MAX_ACCOUNT_MACROS or 120
  local maxChar = tonumber(mc.MAX_CHARACTER_MACROS) or MAX_CHARACTER_MACROS or 30
  local have = {}
  if GetMacroInfo then
    for i = 1, nAccount or 0 do have[#have + 1] = GetMacroInfo(i) end
    for i = maxAccount + 1, maxAccount + (nChar or 0) do have[#have + 1] = GetMacroInfo(i) end
  end
  return { combat = InCombatLockdown(), have = have, charFree = math.max(0, maxChar - (nChar or 0)),
    accountFree = math.max(0, maxAccount - (nAccount or 0)) }
end

local function everyClass(m)
  for _, g in ipairs(ns.MACROS and ns.MACROS.GENERAL or {}) do if g == m then return true end end
  return false
end
-- Where this macro goes: perCharacter, and the free slots there. It's the state MacroProblem checks.
local function slot(m, state)
  local perCharacter = not (everyClass(m) and state.accountFree > 0)
  state.free = perCharacter and state.charFree or state.accountFree
  return perCharacter, state
end

-- Returns the new macro's index and whether it went in this character's macros, or nil and the problem.
local function add(m)
  local perCharacter, state = slot(m, macroState())
  local problem = ns.MacroProblem(m, state)
  if problem then return nil, problem end
  local ok, index = pcall(CreateMacro, m.name, ns.MACRO_ICON, m.body, perCharacter)
  if not ok or not index then return nil, "full" end
  return index, perCharacter
end
local function where(perCharacter) return perCharacter and "this character's macros" or "your General macros" end

ns.MACRO_SITUATIONS = { "leveling", "dungeon", "raid", "pvp" } -- the library's situation words, in its order
ns.MACRO_KEEP_FREE = 10 -- add-all leaves this many character macro slots for the player's own macros

-- Which macros a view shows: nil = the S tier, "all", or one situation word.
local function inView(m, word)
  if word == "all" then return true end
  if not word then return m.tier == "S" end
  for _, w in ipairs(m.situation or {}) do if w == word then return true end end
  return false
end

-- Numbers are each macro's place in ns.MyMacros(), the class hub card's order, so they're the same in every view.
local function list(word)
  local macros = ns.MyMacros()
  if #macros == 0 then say("No guild macros for your class yet. The class hub in Discord shows what's coming.") return end
  local _, token = UnitClass("player")
  local className = UnitClass("player") or token or "class"
  local view = word == "all" and "all of them" or word and ("for " .. word) or "S tier"
  say(("Guild macros for your %s, %s, best first (checked against Forever's client %s):"):format(className, view,
    ns.MACROS_BUILD or "?"))
  local state, ready, more = macroState(), {}, 0
  for i, m in ipairs(macros) do
    if inView(m, word) then
      local perCharacter, st = slot(m, state)
      local problem = ns.MacroProblem(m, st)
      if not problem and m.tier == "S" then ready[#ready + 1] = { m = m, perCharacter = perCharacter } end
      say(("%d. [%s] %s (%s): %s"):format(i, m.tier, m.name, table.concat(m.situation or {}, ", "),
        problem and WHY[problem] or "ready to add"))
    else
      more = more + 1
    end
  end
  if more == #macros then say(word and ("None for %s yet."):format(word) or "No S tier macros yet.") end
  if more > 0 then
    say(("%d more: /uw kit macros %s · all."):format(more, table.concat(ns.MACRO_SITUATIONS, " · ")))
  end
  say("Add one: /uw kit macros add <number>. It goes on your cursor for an action bar slot.")
  -- One click adds only the S tier, and leaves room on the character for the player's own macros: a full library
  -- would fill most of its slots. (An every-class one goes in the General tab's 120; add() checks again either way.)
  local charRoom = math.max(0, state.charFree - ns.MACRO_KEEP_FREE)
  local offer, waiting = {}, 0
  for _, r in ipairs(ready) do
    if not r.perCharacter then offer[#offer + 1] = r.m
    elseif charRoom > 0 then charRoom = charRoom - 1 offer[#offer + 1] = r.m
    else waiting = waiting + 1 end
  end
  if waiting > 0 then
    say(("%d S tier macro%s not in the one-click add: it keeps %d of this character's macro slots free for your own. "
      .. "Add by number instead."):format(waiting, waiting == 1 and " is" or "s are", ns.MACRO_KEEP_FREE))
  end
  if #offer == 0 then return end
  local names = {}
  for i, m in ipairs(offer) do names[i] = m.name end
  ns.KitConfirm(("Add %d S tier guild macro%s to your macros: %s?"):format(#offer, #offer == 1 and "" or "s",
    table.concat(names, ", ")), function()
    local added, skipped = {}, {}
    for _, m in ipairs(offer) do
      local index, detail = add(m) -- where it went, or why not
      if index then
        added[#added + 1] = ("%s (%s)"):format(m.name, where(detail))
      else
        skipped[#skipped + 1] = ("%s (%s)"):format(m.name, WHY[detail])
      end
    end
    if #added > 0 then say("Added: " .. table.concat(added, ", ") .. ". Drag them from /macro to your action bars.") end
    if #skipped > 0 then say("Not added: " .. table.concat(skipped, "; ") .. ".") end
  end, nil, "UW_GUILD_MACROS")
end

local USAGE = "/uw kit macros shows your class's S tier; /uw kit macros leveling · dungeon · raid · pvp · all shows "
  .. "more; /uw kit macros add <number> adds one."
ns.kitCommands.macros = function(rest)
  rest = (rest or ""):lower():match("^%s*(.-)%s*$")
  local n = tonumber(rest:match("^add%s+(%d+)$"))
  if n then
    local m = ns.MyMacros()[n]
    if not m then say("No guild macro with that number. /uw kit macros all lists them.") return end
    local index, detail = add(m)
    if not index then say(("%s wasn't added: %s."):format(m.name, WHY[detail])) return end
    if PickupMacro and not InCombatLockdown() then pcall(PickupMacro, index) end
    say(("Added %s to %s. It's on your cursor: click an action bar slot to place it."):format(m.name, where(detail)))
    return
  end
  if rest == "" or rest == "all" then list(rest == "all" and "all" or nil) return end
  for _, w in ipairs(ns.MACRO_SITUATIONS) do
    if rest == w then list(w) return end
  end
  say(USAGE)
end

-- The client check, for the bot: { build = the library's, checked = spell IDs looked up, missing = "id,id",
-- renamed = "id,id", or "?" on a client in another language, where names can't be compared }: IDs only, no names, so
-- the save stays small. Once a session, out of combat.
function ns.ProbeSpells()
  local seen, ids = {}, {}
  for _, lib in pairs(ns.MACROS or {}) do
    for _, m in ipairs(lib) do
      for id, name in pairs(m.spells) do
        if not seen[id] then seen[id] = name ids[#ids + 1] = id end
      end
    end
  end
  table.sort(ids)
  local missing, renamed = {}, {}
  for _, id in ipairs(ids) do
    local got = ns.SpellName(id)
    if not got then missing[#missing + 1] = id
    elseif english() and got ~= seen[id] then renamed[#renamed + 1] = id end
  end
  return { build = ns.MACROS_BUILD, checked = #ids, missing = table.concat(missing, ","),
    renamed = english() and table.concat(renamed, ",") or "?" }
end

local spellsRead = false
function ns.NoteSpells()
  if spellsRead or InCombatLockdown() or type(UW_GuildDB.client) ~= "table" then return end
  spellsRead = true
  UW_GuildDB.client.spells = ns.ProbeSpells()
end
table.insert(ns.onGuildJoin, function()
  ns.afterRoster(function() ns.after(25, function() ns.protect(ns.NoteSpells) end) end)
end)
