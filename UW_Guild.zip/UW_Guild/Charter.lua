-- Guild charter helper (Louis, 5 Nov 2026): the guild needs 9 other players' signatures before it exists. Members
-- offer to sign under the #camp-goals board in Discord; the officers' signer list there gives `/uw charter add ...`
-- lines to paste here. At the Guild Master NPC, /uw charter whispers everyone on the list who hasn't signed, then says
-- who was online (the game answers "No player named ..." for the rest). Opening the charter marks who has signed.
--   /uw charter add A, B   add names (comma between them; Forever names have a space)
--   /uw charter            whisper the list from here
--   /uw charter list       who's on the list, who signed
--   /uw charter clear      empty the list (once the guild exists it has done its job)
-- Founding day: the #camp-goals board's Founding invites list (officers, the guild's first week) gives
-- `/uw charter invite ...` lines for accepted members not in the guild yet. `/uw charter invite` alone then sends the
-- next guild invite, one per key press, skipping anyone already in the guild.
-- Nothing is sent to the guild or Discord. The game sends the signature request: target a signer, open the charter
-- from your bags, click Request Signature.
local _, ns = ...
local say = ns.say

ns.CHARTER_NEEDED = 9
ns.CHARTER_WHISPER_GAP = 0.3 -- seconds between whispers, well under the chat throttle

local function db()
  local c = type(UW_GuildDB.charter) == "table" and UW_GuildDB.charter or {}
  c.names = type(c.names) == "table" and c.names or {}
  c.signed = type(c.signed) == "table" and c.signed or {}
  UW_GuildDB.charter = c
  return c
end
local function key(name) return (strtrim(name):gsub("%-.*$", ""):lower()) end
local function short(name) return ns.shortName(name) or name end

function ns.CharterAdd(text)
  local c, added = db(), 0
  local have = {}
  for _, n in ipairs(c.names) do have[key(n)] = true end
  for raw in (text or ""):gmatch("[^,]+") do
    local n = strtrim(raw):gsub("%s+", " ")
    if #n >= 2 and #n <= 40 and not n:find("%d") then
      if not have[key(n)] and key(n) ~= key(ns.me() or "") then
        c.names[#c.names + 1], have[key(n)], added = n, true, added + 1
      end
    end
  end
  return added
end

-- Founding invites: a separate list, one invite per press (a key press is what the game allows an invite on).
local function invites()
  local c = db()
  c.invites = type(c.invites) == "table" and c.invites or {}
  c.invited = type(c.invited) == "table" and c.invited or {}
  return c
end
local function inGuild(name)
  for i = 1, GetNumGuildMembers() or 0 do
    local n = GetGuildRosterInfo(i)
    if type(n) == "string" and not ns.isSecret(n) and key(n) == key(name) then return true end
  end
  return false
end
function ns.CharterInviteAdd(text)
  local c, have, added = invites(), {}, 0
  for _, n in ipairs(c.invites) do have[key(n)] = true end
  for raw in (text or ""):gmatch("[^,]+") do
    local n = strtrim(raw):gsub("%s+", " ")
    if #n >= 2 and #n <= 40 and not n:find("%d") and not have[key(n)] then
      c.invites[#c.invites + 1], have[key(n)], added = n, true, added + 1
    end
  end
  return added
end
function ns.CharterInviteNext()
  local c = invites()
  local left = {}
  for _, n in ipairs(c.invites) do
    if not c.invited[key(n)] and not inGuild(n) then left[#left + 1] = n end
  end
  if #left == 0 then
    say(#c.invites == 0 and "No invite list. Paste the /uw charter invite lines from the #camp-goals board."
      or "Everyone on the invite list is invited or in the guild.")
    return nil
  end
  local invite = (C_GuildInfo and C_GuildInfo.Invite) or GuildInvite
  if not invite or not pcall(invite, left[1]) then say("The game didn't take that invite. Try /ginvite " .. left[1] .. ".") return nil end
  c.invited[key(left[1])] = true
  say(("Invited %s. %d left: type /uw charter invite again."):format(left[1], #left - 1))
  return left[1]
end

-- Names still to sign, and the signed count.
function ns.CharterStatus()
  local c, todo, done = db(), {}, 0
  for _, n in ipairs(c.names) do
    if c.signed[key(n)] then done = done + 1 else todo[#todo + 1] = n end
  end
  return todo, done
end

local pending -- the names whispered in the last /uw charter, and which the game said are offline
local OFFLINE = ERR_CHAT_PLAYER_NOT_FOUND_S
  and "^" .. ERR_CHAT_PLAYER_NOT_FOUND_S:gsub("[%%%(%)%.%+%-%*%?%[%]%^%$]", "%%%0"):gsub("%%%%s", "(.+)") .. "$"

function ns.CharterWhisper()
  local todo = ns.CharterStatus()
  if #todo == 0 then
    say(#db().names == 0 and "No signers yet. Paste the /uw charter add lines from the #camp-goals signer list."
      or "Everyone on the list has signed.")
    return 0
  end
  local zone, sub = GetZoneText and GetZoneText() or "", GetSubZoneText and GetSubZoneText() or ""
  local where = (sub ~= "" and sub ~= zone) and (sub .. ", " .. zone) or zone
  local msg = ("Hey, it's %s! I'm in %s with the guild charter, come sign when you can?"):format(
    short(ns.me() or UnitName("player")), where ~= "" and where or "town")
  pending = { names = todo, offline = {} }
  for i, n in ipairs(todo) do
    if not ns.quiet(n) then -- whispered "stop" (Onboarding.lua): skipped, still on the list for in person
      ns.after(ns.CHARTER_WHISPER_GAP * (i - 1), function() ns.chat("charter.ask", msg, "WHISPER", n) end)
    end
  end
  ns.after(ns.CHARTER_WHISPER_GAP * #todo + 3, function()
    if not pending then return end
    local on, off = {}, {}
    for _, n in ipairs(pending.names) do
      if pending.offline[key(n)] then off[#off + 1] = n else on[#on + 1] = n end
    end
    pending = nil
    say(#on > 0 and ("Online and whispered: %s."):format(table.concat(on, ", "))
      or "Nobody on the list is online right now. Try again later.")
    if #off > 0 then say(("Offline: %s."):format(table.concat(off, ", "))) end
    if #on > 0 then say("Target each one, open the charter from your bags, and click Request Signature.") end
  end)
  return #todo
end

-- The game's own list of signatures, read when the charter opens.
function ns.CharterReadSigned()
  if not (GetPetitionInfo and GetNumPetitionNames and GetPetitionNameInfo) then return nil end
  local ptype, _, _, _, _, isOriginator, minSigs = GetPetitionInfo()
  if ptype ~= "guild" or not isOriginator then return nil end
  local c = db()
  for i = 1, GetNumPetitionNames() or 0 do
    local n = GetPetitionNameInfo(i)
    if type(n) == "string" and n ~= "" then c.signed[key(n)] = true end
  end
  local todo = ns.CharterStatus()
  local signed = GetNumPetitionNames() or 0
  local need = math.max((tonumber(minSigs) or ns.CHARTER_NEEDED) - signed, 0)
  say(need == 0 and ("Charter: %d signed. Turn it in at the Guild Master."):format(signed)
    or ("Charter: %d signed, %d to go.%s"):format(signed, need,
      #todo > 0 and (" Not yet: " .. table.concat(todo, ", ", 1, math.min(#todo, 6)) .. ".") or ""))
  return signed
end

ns.commands.charter = function(args)
  local sub, rest = strtrim(args or ""):match("^(%S*)%s*(.-)$")
  sub = (sub or ""):lower()
  if sub == "add" then
    local n = ns.CharterAdd(rest)
    say(("Added %d. The list has %d names. At the Guild Master, type /uw charter to whisper them."):format(n,
      #db().names))
  elseif sub == "invite" then
    if rest ~= "" then
      local n = ns.CharterInviteAdd(rest)
      say(("Added %d to the invite list. Type /uw charter invite to send the next one."):format(n))
    else
      ns.CharterInviteNext()
    end
  elseif sub == "clear" then
    UW_GuildDB.charter = nil
    say("Charter list cleared.")
  elseif sub == "list" then
    local todo, done = ns.CharterStatus()
    if #db().names == 0 then say("The list is empty. Paste the /uw charter add lines from Discord.") return end
    say(("%d on the list, %d signed. Not yet: %s."):format(#db().names, done,
      #todo > 0 and table.concat(todo, ", ", 1, math.min(#todo, 8)) or "nobody"))
  elseif sub == "" then
    if IsInGuild() then say("This character is in a guild already. Use the one holding the charter.") return end
    ns.CharterWhisper()
  else
    say("/uw charter add <names>, /uw charter, list, clear. Founding day: /uw charter invite <names>, then /uw charter invite.")
  end
end

-- Recruit whispers (Louis, 8 Nov 2026: his mouseover macro whispered the same people twice and a bank alt, about 25 in
-- 4 minutes). /uw recruit, on a macro key, asks the player under the mouse (or the target) once: never someone in a
-- guild, of the other faction, asked in the last 30 days, or who answered (Louis can still whisper them himself), and
-- at most one ask per RECRUIT_GAP seconds and RECRUIT_PER_HOUR an hour, so nobody has reason to report it as spam.
-- Kept apart from UW_GuildDB.discordAsked (the post-join Discord ask, Onboarding.lua).
--
-- A yes becomes one click (Louis, 15 Nov 2026: recruiting is what takes most of his time in game). The slow step was
-- after the ask: finding the answer among his own outgoing lines, then inviting by hand. When someone he asked
-- writes back a clear yes (ns.SaysYes), or a stranger's whisper plainly asks for an invite, one notice above chat
-- names them; a click on it sends the guild invite (the game takes one invite per click), its close mark sets it
-- aside. Nothing is whispered and nothing is invited without the click. Any other answer (a no, a question, small
-- talk) raises nothing: it is his to read. Not for someone in the guild, never in a fight or inside a dungeon or
-- raid, gone after RECRUIT_NOTICE_SECS. On the Guild Master's account only for now.
-- recruitAsked[name] = { at = asked, answered = true, back = when they wrote back, inv = when he clicked }: with
-- UW_GuildDB.invites and the roster, the save says what an ask leads to (counts only, read by hardening).
ns.RECRUIT_GAP, ns.RECRUIT_PER_HOUR, ns.RECRUIT_AGAIN_DAYS = 6, 40, 30
local function recruitKey(name) return (strtrim(name):gsub("%-", " "):gsub("%s+", " "):lower()) end
local function asked()
  UW_GuildDB.recruitAsked = type(UW_GuildDB.recruitAsked) == "table" and UW_GuildDB.recruitAsked or {}
  return UW_GuildDB.recruitAsked
end
-- A recruit whisper that never went (Louis's "Don't send" on its first popup, Outbound.lua): not asked after all.
ns.OnUnsent["recruit.whisper"] = function(target) if target then asked()[recruitKey(target)] = nil end end
local recentSends = {}
local function plainString(v) return type(v) == "string" and not ns.isSecret(v) and v ~= "" end
-- The line is Louis's own, word for word (15 Nov 2026): the one his own macro whispered, so the key that asks once
-- and skips the guilded says what he already says. No Discord link: recruiting is whisper-only.
function ns.RecruitMessage()
  return ("Hi! [%s] is recruiting; want a cozy guild invite?"):format(ns.GUILD_NAME)
end
function ns.Recruit()
  if not IsInGuild() then say("Join or found the guild first.") return false end
  local unit = UnitExists("mouseover") and "mouseover" or (UnitExists("target") and "target" or nil)
  if not unit or not UnitIsPlayer(unit) or UnitIsUnit(unit, "player") then
    say("Point at a player (mouse over them, or target them), then /uw recruit.") return false
  end
  local n, r = UnitName(unit)
  if not plainString(n) then say("Can't read that player's name here.") return false end
  -- The target is spelled as the roster and every other whisper here spell a name (ns.unitFull: "First Last" on
  -- Forever, where the old "First-Last" was never seen to reach anyone; 8 Nov's Discord asks went as "First Last").
  local to = ns.unitFull(unit) or (plainString(r) and (n .. "-" .. r) or n)
  local shown = plainString(r) and (n .. " " .. r) or n
  local guild = GetGuildInfo(unit)
  if plainString(guild) then say(("%s is in <%s>: skipped."):format(shown, guild)) return false end
  if UnitFactionGroup(unit) ~= UnitFactionGroup("player") then say(("%s is the other faction: skipped."):format(shown)) return false end
  local now, k = time(), recruitKey(to)
  local e = asked()[k]
  if e and e.answered then say(("%s answered you already: whisper them yourself if you like."):format(shown)) return false end
  if e and now - (e.at or 0) < ns.RECRUIT_AGAIN_DAYS * 86400 then
    local mins = math.floor((now - e.at) / 60)
    say(("Already asked %s %s ago."):format(shown, mins < 90 and (mins .. " min") or (math.floor(mins / 60) .. " h")))
    return false
  end
  for i = #recentSends, 1, -1 do if now - recentSends[i] >= 3600 then table.remove(recentSends, i) end end
  local last = recentSends[#recentSends]
  if last and now - last < ns.RECRUIT_GAP then say(("One every %d s: wait a moment."):format(ns.RECRUIT_GAP)) return false end
  if #recentSends >= ns.RECRUIT_PER_HOUR then
    say(("%d asks this hour: a break keeps us clear of spam reports."):format(ns.RECRUIT_PER_HOUR)) return false
  end
  local sent, why = ns.chat("recruit.whisper", ns.RecruitMessage(), "WHISPER", to)
  if not sent then say(("Not sent: %s."):format(why or "the game didn't send it")) return false end
  asked()[k] = { at = now }
  recentSends[#recentSends + 1] = now
  return true
end
-- Asks older than 60 days are forgotten at login, so the list stays small.
table.insert(ns.onLoad, function()
  local now, list = time(), UW_GuildDB.recruitAsked
  if type(list) ~= "table" then return end
  for k, e in pairs(list) do if type(e) ~= "table" or now - (tonumber(e.at) or 0) > 60 * 86400 then list[k] = nil end end
end)

ns.RECRUIT_NOTICE_SECS, ns.RECRUIT_NOTICE_KEEP = 120, 600
local wrote, noticeButton = {}, nil -- wrote: who waits for a click, oldest first: { to, shown, key, at, since }
-- Lower case, letters and apostrophes only, a space each side of every word. A curly apostrophe is a plain one.
local function wordsOf(msg)
  return " " .. (msg:lower():gsub("\226\128[\152\153]", "'"):gsub("[^%a']+", " ")) .. " "
end
-- "inv", "invite me", "can I join the guild": a whisper that plainly asks for a guild invite.
function ns.AsksForInvite(msg)
  if not plainString(msg) then return false end
  local m = wordsOf(msg)
  return (m:find(" inv ", 1, true) or m:find(" invite ", 1, true) or m:find(" ginvite ", 1, true)
    or (m:find(" join ", 1, true) and m:find(" guild ", 1, true))) and true or false
end
-- "guild", "ginvite": a whisper that names what the invite is to.
local function namesGuild(m) return (m:find(" guild ", 1, true) or m:find(" ginvite ", 1, true)) and true or false end
-- "No.", "nah I'm good", "nty", "not interested": an answer that is plainly a no, whatever else it says.
-- "No way, yes please!" and "no problem, invite me" open with a no that isn't one.
-- "I'm in a guild", "not now", "stop whispering me", "I'm good": a no as well, unless the same whisper asks for an
-- invite ("I'm not in a guild atm, can I get an inv?", "can't stop playing, guild invite pls"): there the ask wins.
local NO_FIRST = { no = true, nah = true, nope = true, nty = true }
local NOT_A_NO = { way = true, problem = true, prob = true, worries = true }
local NO_WORDS = { " not interested ", " no thanks ", " no thank you ", " no ty ", " nty ", " don't invite ", " dont invite ",
  " don't inv ", " dont inv ", " no invite ", " no inv ", " don't send ", " dont send ",
  -- "don't want an invite", "don't want to join": a refusal. Not the bare words: "I don't want to level alone, inv".
  " don't want a ", " dont want a ", " don't want an ", " dont want an ", " don't want any ", " dont want any ",
  " don't want to join ", " dont want to join ",
  -- "stop the invite spam", "stop with the guild invite": told to stop, even with the word invite in it. On a tie
  -- the safer side is no: a missed yes costs nothing (he can still invite by hand), a notice under a no might.
  " stop the ", " stop with ", " stop sending ", " stop asking ", " stop whispering ", " stop inviting " }
local NO_UNLESS_ASKING = { " not now ", " not right now ", " in a guild ", " have a guild ", " got a guild ", " stop ",
  " i'm good ", " im good " }
local GUILDLESS = { " not in a guild ", " don't have a guild ", " dont have a guild ", " haven't got a guild ",
  " havent got a guild " } -- the opposite of a no: these never count as one
function ns.SaysNo(msg)
  if not plainString(msg) then return false end
  local m = wordsOf(msg)
  local first, second = m:match("^ (%S+) ?(%S*)")
  if NO_FIRST[first] and not (first == "no" and NOT_A_NO[second]) then return true end
  for _, w in ipairs(NO_WORDS) do if m:find(w, 1, true) then return true end end
  if ns.AsksForInvite(msg) then return false end
  for _, w in ipairs(GUILDLESS) do
    local from, to = m:find(w, 1, true)
    if from then m = m:sub(1, from) .. m:sub(to) end
  end
  for _, w in ipairs(NO_UNLESS_ASKING) do if m:find(w, 1, true) then return true end end
  return false
end
-- A clear yes to "want a cozy guild invite?": "yes", "sure!", "ok", "yeah why not", "sounds good", "pls inv", "can I
-- get an invite?". Only that raises the notice (Louis, 15 Nov 2026: "detecting any whisper back as an affirmative ...
-- clearly a mistake"). The rule is a list of what a yes may hold, not of what it may not (red team on #731): a short
-- reply, every word of it a yes word or a filler word, with at least one yes in it. One word off the list ("ok
-- reported", "I'm in a dungeon", "invite to what", "yeah right") and it is not a yes. A question counts only as a
-- plain ask for the invite ("inv?", "can I join the guild?"; not "yes?"). Whatever is not a yes raises nothing: the
-- whisper is in his chat to read.
ns.RECRUIT_YES_WORDS = 10
local function set(words) local t = {} for w in words:gmatch("%S+") do t[w] = true end return t end
local YES = set("yes yeah yea yeh yep yup yess yesss yessir ya ye yah sure ok okay okey k kk alright aight absolutely "
  .. "definitely totally certainly gladly ofc bet please pls plz down inv invite ginvite")
local YES_FILLER = set("i i'd id i'll ill i'm im me a an the that this it to in for of would will can "
  .. "could may u you get join guild love like want sounds good great nice cool cozy awesome thanks "
  .. "thank thx ty man mate bro dude hey hi hello lol haha oh ah really send let's lets "
  .. "course thing now be hell heck sign count glad saw your ur ad trade chat atm rn currently")
local YES_PHRASES = { " sign me up ", " go for it ", " go ahead ", " let's go ", " lets go " }
local OK, THANKS = set("ok okay okey k kk"), set("thanks thank thx ty you")
local SOCIAL = set("lol haha thanks thank you thx ty please pls plz") -- after "I'm in"
local YES_WORDS = { " sounds good ", " sounds great ", " sounds fun ", " sounds nice ", " i'm in ", " im in ", " i'm down ",
  " im down ", " count me in ", " sign me up ", " love to ", " love one ", " would love ", " i'd like ", " id like ",
  " of course ", " go ahead ", " go for it ", " let's go ", " lets go ", " i'll join ", " ill join ", " happy to ",
  " want to join ", " want one " }
function ns.SaysYes(msg)
  if not plainString(msg) or ns.SaysNo(msg) then return false end
  local m, why = wordsOf(msg):gsub(" why not ", " ")
  -- Whole yes phrases whose words are not on the lists alone ("pls go", "please give up" stay no yes).
  for _, p in ipairs(YES_PHRASES) do m = m:gsub(p, " sure ") end
  for _, w in ipairs(GUILDLESS) do -- "sure, I'm not in a guild": that not is no refusal
    local from, to = m:find(w, 1, true)
    if from then m = m:sub(1, from) .. m:sub(to) end
  end
  if m:find(" i'?m oka?y? ") or m:find(" i am oka?y? ") then return false end -- "I'm ok": thanks, but no
  -- "I'm in": a yes only on its own or with social words ("I'm in!", "im in lol"); "I'm in one", "im in my guild" is a no.
  local rest = m:match(" i'?m in (.*)$")
  if rest then
    for w in rest:gmatch("%S+") do if not SOCIAL[w] then return false end end
  end
  -- "ok thanks", "ok ty man": as likely a polite no as a yes, so not a yes. "sure ty", "yes thanks" still are.
  local okOnly, thanked = true, false
  for w in m:gmatch("%S+") do
    if THANKS[w] then thanked = true elseif not (OK[w] or SOCIAL[w] or w == "man" or w == "bro" or w == "dude") then
      okOnly = false
    end
  end
  if okOnly and thanked then return false end
  local n, yes = 0, why > 0
  for w in m:gmatch("%S+") do
    n = n + 1
    if YES[w] then yes = true elseif not YES_FILLER[w] then return false end
  end
  if n > ns.RECRUIT_YES_WORDS then return false end
  local asks = ns.AsksForInvite(msg)
  -- A question counts only as a plain ask for the invite.
  if msg:gsub("[Ww]hy%s+not%s*%?", ""):find("?", 1, true) then return asks end
  if yes or asks then return true end
  for _, w in ipairs(YES_WORDS) do if m:find(w, 1, true) then return true end end
  return false
end
local function inFight()
  if ns.Restricted() then return true end -- combat and the client's addon restrictions; unknown counts as yes
  if type(IsInInstance) ~= "function" then return false end
  local inside, kind = IsInInstance()
  return (inside and kind ~= "none") and true or false
end
local function setAside()
  table.remove(wrote, 1)
  ns.RecruitNotice()
end
-- The click: one guild invite to the person the notice names, called straight from the click (the game takes an
-- invite only from a key or mouse press). pcall can't see a call the game blocks or a player it can't find, so the
-- game's own "You have invited X" line is what says it went: with it, the row keeps when; without it
-- RECRUIT_CONFIRM seconds later, he hears the typed way and the save's trace says so.
-- RECRUIT_READ: a click lands only once the name on the notice has been up that long, so a second quick click
-- can't invite the next person waiting before he has read who it is.
ns.RECRUIT_CONFIRM, ns.RECRUIT_READ = 3, 1
local named, namedAt -- who the notice names (their key) and since when (GetTime)
local INVITED = type(ERR_GUILD_INVITE_S) == "string"
  and "^" .. ERR_GUILD_INVITE_S:gsub("[%%%(%)%.%+%-%*%?%[%]%^%$]", "%%%0"):gsub("%%%%s", "(.+)") .. "$"
local invitedLine = {} -- recruitKey -> true once the game's line named them
function ns.RecruitInvite()
  -- A restriction can begin with no event to hide the notice (an encounter, a restricted map): never under one.
  if inFight() then ns.RecruitNotice() return false end
  local w = wrote[1]
  if not w then return false end
  if named ~= w.key or GetTime() - (namedAt or 0) < ns.RECRUIT_READ then return false end
  local invite = (C_GuildInfo and C_GuildInfo.Invite) or GuildInvite
  local at, k = time(), recruitKey(w.to)
  invitedLine[k] = nil
  if not invite or not pcall(invite, w.to) then
    ns.trace("recruit", "invite", false, "the game refused the invite", w.to)
    say(("The game didn't take that invite. Try /ginvite %s."):format(w.to))
    return false
  end
  local function went()
    local e = asked()[w.key]
    if e then e.inv = at end
    ns.trace("recruit", "invite", true, nil, w.to)
  end
  if not INVITED then
    went() -- a client with no such line can't say more
  else
    ns.after(ns.RECRUIT_CONFIRM, function()
      if invitedLine[k] then went() return end
      ns.trace("recruit", "invite", false, "no invite line from the game", w.to)
      say(("The game didn't take that invite. Try /ginvite %s."):format(w.to))
    end)
  end
  setAside()
  return true
end
-- Shows, relabels or hides the notice. Returns who it names, or nil.
function ns.RecruitNotice()
  local now = time()
  for i = #wrote, 1, -1 do
    local w = wrote[i]
    if now - w.at > ns.RECRUIT_NOTICE_KEEP or (w.since and now - w.since >= ns.RECRUIT_NOTICE_SECS)
      or ns.inRoster(w.to) then
      table.remove(wrote, i)
    end
  end
  local w = wrote[1]
  if not w or inFight() or not ns.ChatBarAdd or (ns.ChatBarHidden and ns.ChatBarHidden()) then
    if noticeButton then noticeButton:Hide() end
    named = nil -- shown again, it counts as new: the read pause starts over
    return nil
  end
  if not noticeButton then
    -- A plain button: the bar above chat draws it as a notice about people, with a close mark (Skin.lua).
    noticeButton = CreateFrame("Button", "UWGuildRecruitBack", UIParent)
    noticeButton:SetScript("OnClick", function() ns.protect(ns.RecruitInvite) end)
    ns.useButton(noticeButton, "recruit invite")
    noticeButton.uwClose = function() setAside() end
    ns.recruitButton = noticeButton
    ns.ChatBarAdd("recruit back", noticeButton, 15) -- after a guildmate's ask, before the chores
  end
  if not w.since then
    w.since = now
    ns.after(ns.RECRUIT_NOTICE_SECS + 1, ns.RecruitNotice)
  end
  local icons = ns.HANDBOOK_ICONS
  noticeButton.uwIcon = type(icons) == "table" and type(icons.page) == "table" and icons.page.guild or nil
  noticeButton.label = ("%s wrote back: invite to guild"):format(w.shown)
  if named ~= w.key then named, namedAt = w.key, GetTime() end
  noticeButton:Show()
  ns.ChatBarText(noticeButton, noticeButton.label)
  return w
end
-- A whisper came in. e: their row if they were asked, k: its key (theirs by name if they weren't).
-- Asked within RECRUIT_YES_SECS: a clear yes raises the notice. Not asked, or asked longer ago: only a clear yes that
-- plainly asks for the invite. A clear no takes them off a notice that was waiting. Anything else does nothing.
ns.RECRUIT_YES_SECS = 86400
local function wroteBack(msg, sender, e, k)
  if UW_GuildDB.gmAccount ~= true or ns.inRoster(sender) then return end
  if ns.SaysNo(msg) then
    for i, w in ipairs(wrote) do
      if w.key == k then table.remove(wrote, i) ns.RecruitNotice() break end
    end
    return
  end
  if not ns.SaysYes(msg) then return end
  local fresh = e and time() - (tonumber(e.at) or 0) <= ns.RECRUIT_YES_SECS
  if not fresh and not ns.AsksForInvite(msg) then return end
  -- In a group, a stranger's bare "inv" is most likely about the group: only one that names the guild counts there.
  if not fresh and IsInGroup and IsInGroup() and not namesGuild(wordsOf(msg)) then return end
  if e and e.inv then return end -- invited from a notice already: what they write next is theirs to talk about
  for _, w in ipairs(wrote) do if w.key == k then return end end
  wrote[#wrote + 1] = { to = sender, shown = sender, key = k, at = time() }
  ns.trace("recruit", "notice", true) -- counts only: how many notices against how many invites
  ns.RecruitNotice()
end

-- The trade ad, one post per press (16 Nov 2026). People who whispered Louis first joined 4 of 7, against about 1 in 20
-- of those he whispered cold (recruiting/read-2026-11-15.md, a small sample), so the ad is the better lever. /uw trade
-- (a macro key) or the Lead window's Say tab posts his own trade line, word for word (Louis, 14 Nov 2026 00:50; the
-- bot's sharecard.trade), to the Trade channel, which the game has only in a city. One post every TRADE_GAP seconds:
-- Blizzard sets no number, but the same line posted again and again is what players report as spam, and enough
-- reports silence an account. The post goes straight from the press (the game takes a channel line only from a key
-- or mouse press), never queued or on a timer. Anyone who answers it asking for an invite gets the notice above.
-- On the Guild Master's account for now; UW_GuildDB.tradeAds keeps when each went (counts only, read by hardening).
ns.TRADE_GAP, ns.TRADE_KEEP = 900, 100
ns.TRADE_LINE = "<Unbothered Warlords> is a cozy Horde crew: no pressure, every level welcome, and someone's usually "
  .. "up for a group. Whisper me for an invite!"
-- The Trade channel's number, or nil when this character isn't in it (outside a city).
function ns.TradeChannel()
  if type(GetChannelList) ~= "function" then return nil end
  local list = { GetChannelList() }
  for i = 1, #list, 3 do
    local id, name, off = list[i], list[i + 1], list[i + 2]
    if type(name) == "string" and not ns.isSecret(name) and name:lower():find("^trade") and not off then
      return tonumber(id)
    end
  end
  return nil
end
local function tradeAds()
  UW_GuildDB.tradeAds = type(UW_GuildDB.tradeAds) == "table" and UW_GuildDB.tradeAds or {}
  return UW_GuildDB.tradeAds
end
-- Seconds until the next post may go (0: now).
function ns.TradeWait()
  local ads = tradeAds()
  local last = tonumber(ads[#ads])
  if not last then return 0 end
  return math.max(0, ns.TRADE_GAP - (time() - last))
end
-- Returns true when it went (or waits for his OK on the popup), or false and what to tell him.
function ns.TradeAd()
  if not IsInGuild() then return false, "Join or found the guild first." end
  if UW_GuildDB.gmAccount ~= true then return false, "The trade ad is the Guild Master's for now." end
  local wait = ns.TradeWait()
  if wait > 0 then
    return false, ("Sent %d min ago. Next one in %d min."):format(
      math.floor((ns.TRADE_GAP - wait) / 60), math.ceil(wait / 60))
  end
  if ns.LineWaiting and ns.LineWaiting("recruit.trade") then return false, "Waiting for your OK on the popup." end
  local channel = ns.TradeChannel()
  if not channel then return false, "Trade chat is only in a city: post from there." end
  local sent, why = ns.chat("recruit.trade", ns.TRADE_LINE, "CHANNEL", channel)
  if not sent then
    -- A miss only when the game refused it; a line held by choice (off, quiet) is a done row that says so.
    local refused = why == nil or why == "the game didn't send it"
    ns.trace("recruit", "trade", not refused, refused and "game refused" or ("held: " .. tostring(why)))
    return false, ("Not sent: %s."):format(why or "the game didn't send it")
  end
  return true
end
-- Counted when the game took it: right away, or after his first OK on the popup.
ns.OnSent["recruit.trade"] = function()
  local ads = tradeAds()
  ads[#ads + 1] = time()
  while #ads > ns.TRADE_KEEP do table.remove(ads, 1) end
  ns.trace("recruit", "trade", true)
end
ns.commands.trade = function()
  local _, msg = ns.TradeAd()
  if msg then say(msg) end
end

ns.commands.recruit = function() ns.Recruit() end
-- Louis's WHISPER macro reads /uw whisper (8 Nov 2026), so that word does the same, with no macro edit.
ns.commands.whisper = ns.commands.recruit

local f = CreateFrame("Frame")
ns.listen(f, { "CHAT_MSG_SYSTEM", "PETITION_SHOW", "CHAT_MSG_WHISPER", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED",
  "PLAYER_ENTERING_WORLD" })
f:SetScript("OnEvent", ns.guard(function(_, event, msg, sender)
  if not UW_GuildDB then return end
  if event == "PLAYER_REGEN_DISABLED" or event == "PLAYER_REGEN_ENABLED" or event == "PLAYER_ENTERING_WORLD" then
    if #wrote > 0 or noticeButton then ns.protect(ns.RecruitNotice) end -- a fight hides it, the end of one shows it
    return
  end
  if event == "CHAT_MSG_WHISPER" then
    -- Any answer to an ask: /uw recruit never asks them again.
    -- Where there are realms, same-realm asks are keyed by name alone, so a "Name-Realm" sender is tried without
    -- its realm too.
    if not plainString(sender) then return end
    sender = ns.fullName(sender) or sender -- as the roster spells it: "First Last" on Forever
    local k = recruitKey(sender)
    local e = asked()[k]
    if not e and not ns.REGIONAL then -- Forever has no realms: a "-X" there is part of the name, never one to drop
      k = recruitKey(sender:gsub("%-[^-]*$", ""))
      e = asked()[k]
    end
    if e then e.answered, e.back = true, e.back or time() end
    ns.protect(wroteBack, msg, sender, e, e and k or recruitKey(sender))
    return
  end
  if event == "CHAT_MSG_SYSTEM" then
    if type(msg) ~= "string" or ns.isSecret(msg) then return end
    local invitee = INVITED and msg:match(INVITED)
    if invitee then invitedLine[recruitKey((invitee:gsub("|Hplayer:[^|]*|h%[?([^%]|]*)%]?|h", "%1")))] = true end
    if not pending or not OFFLINE then return end
    local who = msg:match(OFFLINE)
    if who then pending.offline[key(who)] = true end
  elseif event == "PETITION_SHOW" then
    ns.protect(ns.CharterReadSigned)
  end
end))

-- Raise your hand to raid (Louis, 8 Nov 2026: he asked in guild chat who wants to raid, then promoted six people to
-- Raider by hand). /uw raiders, officers only, says one line in guild chat. For RAIDERS_WINDOW seconds, anyone who
-- answers with the word "raid" joins the list: a direct ask answered just then, nothing read before or after it
-- (CONTRIBUTING.md, gentle rollouts, rule 6). Then one Promote button promotes the next name to Raider, one name
-- per press. Forever blocks the rank API, so the button runs /gpromote as a macro (a secure click), and each name's
-- /gpromote lines are also printed to paste if the button can't. Nobody is whispered on promotion (9 Nov 2026).
--   /uw raiders        ask in guild chat (again: shows the list so far)
--   /uw raiders list   who answered, and the Promote button
ns.RAIDERS_WINDOW, ns.RAIDER_RANK = 300, "Raider"
ns.RAIDERS_ASK = "Anyone keen to raid down the road? Say raid and I'll note it, no commitment."
-- No whisper when someone is promoted to Raider (removed 9 Nov 2026 with the catch-up below: Louis, "why is the addon
-- whispering people about raids we can't even do yet"). The rank itself is the thank-you; raids come later.
local raidAsk -- { at, names = { short name, ... }, seen = { [short] = true }, next = index of the next to promote }

local function raiderIndex()
  local n = GuildControlGetNumRanks and GuildControlGetNumRanks()
  if type(n) ~= "number" or ns.isSecret(n) then return nil end
  for i = 1, n do
    local name = GuildControlGetRankName(i)
    if type(name) == "string" and not ns.isSecret(name) and name == ns.RAIDER_RANK then return i - 1 end
  end
end

-- How many /gpromote steps take this guildmate to Raider (0: Raider or above already; nil: not in the roster).
function ns.RaiderSteps(name)
  local full = ns.fullName(name)
  local rank, raider = full and ns.rankOf[full], raiderIndex()
  if rank == nil or raider == nil then return nil end
  return math.max(0, rank - raider)
end

local function waiting()
  local out = {}
  for _, n in ipairs(raidAsk and raidAsk.names or {}) do
    local steps = ns.RaiderSteps(n)
    if steps and steps > 0 then out[#out + 1] = { name = n, steps = steps } end
  end
  return out
end

local promoteButton
-- One press, one promotion: a click disarms the button (empty macro, hidden) before anything else can run it, and
-- only a roster scan showing that name's new rank arms it again. Where a client fires a secure button on both the
-- press and the release, the second fire finds nothing to run, so a Member never goes past Raider to Officer.
local armed, sent -- the name and steps the button holds; the ones it last ran, until the roster shows them
local function promoteLines(w)
  local t = {}
  for i = 1, w.steps do t[i] = "/gpromote " .. w.name end
  return t
end
local function showButton()
  if InCombatLockdown() then say("After the fight: /uw raiders list.") return end
  if not promoteButton then
    promoteButton = CreateFrame("Button", "UW_GuildPromoteRaider", UIParent, "SecureActionButtonTemplate,UIPanelButtonTemplate")
    ns.useButton(promoteButton, "promote raider")
    promoteButton:SetSize(220, 26)
    promoteButton:SetPoint("CENTER", UIParent, "CENTER", 0, 120)
    promoteButton:RegisterForClicks("AnyUp", "AnyDown")
    promoteButton:SetAttribute("type", "macro")
    promoteButton:HookScript("PostClick", function()
      if not armed or InCombatLockdown() then return end
      sent, armed = armed, nil
      promoteButton:SetAttribute("macrotext", "")
      promoteButton:Hide()
      local ask = C_GuildInfo and C_GuildInfo.GuildRoster
      if ask then pcall(ask) end
    end)
  end
  local w = waiting()[1]
  armed = w
  promoteButton:SetAttribute("macrotext", w and table.concat(promoteLines(w), "\n") or "")
  if not w then promoteButton:Hide() return end
  promoteButton:SetText(("Promote %s (%d left)"):format(w.name, #waiting()))
  promoteButton:Show()
end
-- After a press: arm the next name once the roster shows the last one moved up. Unchanged (the scan came before the
-- server's change, or the game refused it): stays disarmed; /uw raiders list arms it again after you've looked.
table.insert(ns.onScan, function()
  if not sent then return end
  local steps = ns.RaiderSteps(sent.name)
  if steps and steps >= sent.steps then
    if not sent.unchanged then ns.trace("raiders", "promote", false, "rank unchanged after the press", sent.name) end
    sent.unchanged = true
    return
  end
  ns.trace("raiders", "promote", true, nil, sent.name)
  sent = nil
  showButton()
end)

function ns.RaidersList()
  local list = waiting()
  if not raidAsk then say("Nobody asked yet: /uw raiders asks in guild chat.") return list end
  local open = time() - raidAsk.at < ns.RAIDERS_WINDOW
  if #list == 0 then
    say(open and "No answers yet; the ask is open for a few more minutes." or "Everyone who answered is a Raider.")
  else
    local names = {}
    for i, w in ipairs(list) do names[i] = w.name end
    say(("Said raid: %s. Any line with the word raid counts, \"not raiding\" too: check before you press. "
      .. "Promote button: one name per press. If it does nothing, paste:"):format(table.concat(names, ", ")))
    for _, w in ipairs(list) do say(table.concat(promoteLines(w), "  ")) end
  end
  if sent and not sent.unchanged then say(("Waiting for the roster to show %s's new rank."):format(sent.name)) return list end
  sent = nil
  showButton()
  return list
end

function ns.RaidersAsk()
  local me = ns.me()
  if not (me and ns.isOfficer(me)) then
    ns.trace("raiders", "ask", false, "not an officer on this character")
    say("Officers only: /uw raiders asks guild chat who wants to raid.")
    return false
  end
  if not raiderIndex() then
    ns.trace("raiders", "ask", false, "no " .. ns.RAIDER_RANK .. " rank in the guild")
    say(("No %s rank in this guild yet: /uw ranks shows the steps."):format(ns.RAIDER_RANK))
    return false
  end
  if raidAsk and time() - raidAsk.at < ns.RAIDERS_WINDOW then ns.RaidersList() return false end
  local posted, why = ns.chat("raiders.ask", ns.RAIDERS_ASK, "GUILD")   -- off while raids aren't running (Outbound.lua)
  if not posted then
    ns.trace("raiders", "ask", false, why or "the game didn't send it")
    if why == "the game didn't send it" then say("The game didn't send it.") end
    return false
  end
  ns.trace("raiders", "ask", true)
  raidAsk = { at = time(), names = raidAsk and raidAsk.names or {}, seen = raidAsk and raidAsk.seen or {} }  -- whispers kept
  say("Asked in guild chat. In 5 minutes (or now) /uw raiders list shows who said raid.")
  ns.after(ns.RAIDERS_WINDOW, function() ns.protect(ns.RaidersList) end)
  return true
end

ns.commands.raiders = function(args)
  if strtrim(args or ""):lower() == "list" then ns.RaidersList() else ns.RaidersAsk() end
end

local hands = CreateFrame("Frame")
ns.listen(hands, { "CHAT_MSG_GUILD" })
hands:SetScript("OnEvent", ns.guard(function(_, event, msg, sender)
  if not UW_GuildDB or type(msg) ~= "string" or ns.isSecret(msg) then return end
  if event ~= "CHAT_MSG_GUILD" then return end
  if not raidAsk or time() - raidAsk.at >= ns.RAIDERS_WINDOW then return end
  if type(sender) ~= "string" or ns.isSecret(sender) then return end
  if not (" " .. msg:lower() .. " "):find("%f[%a]raid") then return end
  local n = short(sender)
  if n == short(ns.me() or "") or raidAsk.seen[n] then return end
  raidAsk.seen[n] = true
  raidAsk.names[#raidAsk.names + 1] = n
end))

-- No catch-up whisper for Raiders promoted before the welcome existed (removed 9 Nov 2026: Louis, "why is the addon
-- whispering people about raids we can't even do yet"). The GM's client sent it to every online Raider, unasked.
-- Nothing in this file whispers a member unless an officer just promoted them by hand or they whispered first.

-- A whisper that asks about the rank ("raider?", "what is raider rank", "can I be raider") gets what it is, and the
-- name goes on /uw raiders list for the officer's Promote press. Addons can't change ranks: the press stays theirs.
ns.RAIDER_WHAT = "Raider just means you're keen on raids for later; there are none yet. I've passed your name on for "
  .. "the rank!"
function ns.RaiderWhisper(msg, sender)
  local me = ns.me()
  if not (me and ns.isOfficer(me)) or type(msg) ~= "string" or ns.isSecret(msg) or #msg > 60 then return false end
  if type(sender) ~= "string" or ns.isSecret(sender) or not ns.inRoster(sender) then return false end
  local words = 0
  for _ in msg:gmatch("%S+") do words = words + 1 end
  if words > 6 or not (" " .. msg:lower() .. " "):find("%f[%a]raider%f[%A]") then return false end
  if (ns.WhisperWord and ns.WhisperWord(msg)) or (ns.ParseRaidWhisper and ns.ParseRaidWhisper(msg)) then
    return false     -- "idea ...", "raid ...": their own answer already goes, never two replies
  end
  local who = short(sender)
  local steps = ns.RaiderSteps(who)
  if not steps or steps == 0 then return false end
  raidAsk = raidAsk or { at = 0, names = {}, seen = {} }   -- at = 0: guild chat's 5-minute window stays closed
  if raidAsk.seen[who] then return true end
  raidAsk.seen[who] = true
  raidAsk.names[#raidAsk.names + 1] = who
  ns.chat("raiders.what", ns.RAIDER_WHAT, "WHISPER", ns.fullName(sender) or sender)
  say(("%s asked about Raider by whisper. /uw raiders list has the Promote button."):format(who))
  return true
end
local raiderFrame = CreateFrame("Frame")
ns.listen(raiderFrame, { "CHAT_MSG_WHISPER" })
raiderFrame:SetScript("OnEvent", ns.guard(function(_, _, msg, sender)
  if UW_GuildDB then ns.protect(ns.RaiderWhisper, msg, sender) end
end))

-- Raid sign-up by whisper (Louis, 8 Nov 2026: "yes on all"; most guildmates aren't on Discord). Anyone in the guild
-- whispers an officer "raid", or "raid tank", "raid heal", "raid out", or a raid's name ("raid barrow"). The officer's
-- UW_Guild answers at once, notes it in the officer's chat frame and keeps it in UW_GuildDB.raidSignups. Officers'
-- clients pass it to each other (RSU), and one logging in asks the others for what they hold (RSQ), so the Guild
-- Master's save, which the bot reads, has it. The bot applies it to the raid card like a button press
-- (bot/uwbot/gamesignup.py): the same slots, bench and sign-up order as Discord. The game names a whisper's sender, so
-- nobody can sign up someone else, and an RSU counts only from an officer.
ns.RAID_SIGNUP_KEEP, ns.RAID_SIGNUP_MAX, ns.RAID_SIGNUP_SHARE = 14 * 86400, 300, 40
local ROLE = { tank = "tank", tanking = "tank", prot = "tank", protection = "tank", bear = "tank", heal = "healer",
  heals = "healer", healer = "healer", healing = "healer", resto = "healer", holy = "healer", disc = "healer",
  dps = "dps", damage = "dps", dd = "dps" }
local ROLE_LABEL = { tank = "Tank", healer = "Healer", dps = "DPS" }
local OUT = { out = true, no = true, cancel = true, cant = true, ["can't"] = true, off = true, drop = true }
local ASK = { when = true, what = true, time = true, where = true, how = true, which = true, who = true }
local FILLER = { me = true, please = true, pls = true, ["for"] = true, the = true, up = true, ["in"] = true,
  next = true, as = true, a = true }
local function serverNow() return (GetServerTime and GetServerTime()) or time() end

-- { role = "tank"|"healer"|"dps"|nil, out = true|nil, ask = true|nil, hint = a word that may name a raid|nil }, or nil
-- if it isn't one. Short lines only, starting with "raid" (or "can't raid"), so chat between officers never signs
-- anyone up. A question ("raid?", "raid when") is ask: it gets the next raid's time and never signs anyone up.
function ns.ParseRaidWhisper(msg)
  if type(msg) ~= "string" or ns.isSecret(msg) or #msg > 40 then return nil end
  local words = {}
  for w in msg:lower():gmatch("[%a']+") do words[#words + 1] = w end
  if #words == 0 or #words > 4 then return nil end
  local first = (words[1] == "raid" and 1) or (OUT[words[1]] and words[2] == "raid" and 2) or nil
  if not first then return nil end
  local p = { ask = msg:find("?", 1, true) and true or nil }
  for i, w in ipairs(words) do
    if ROLE[w] then p.role = ROLE[w]
    elseif OUT[w] then p.out = true
    elseif ASK[w] then p.ask = true
    elseif i ~= first and not FILLER[w] then p.hint = p.hint or w end
  end
  if p.ask then p.out, p.role = nil, nil end
  return p
end

local function signups()
  UW_GuildDB.raidSignups = type(UW_GuildDB.raidSignups) == "table" and UW_GuildDB.raidSignups or {}
  return UW_GuildDB.raidSignups
end
-- A new one waits for the next save, like guild news: on the bot's PC the Send guild news button shows (Sync.lua).
local function record(e)
  local list = signups()
  for _, x in ipairs(list) do if x.n == e.n and x.at == e.at then return false end end
  list[#list + 1] = e
  while #list > ns.RAID_SIGNUP_MAX do table.remove(list, 1) end
  for _, fn in ipairs(ns.onQueue or {}) do ns.protect(fn, "raidsignup") end
  return true
end
-- The role this name last asked for on this raid, from what this client holds.
local function lastRole(name, ev)
  local r
  for _, x in ipairs(signups()) do
    if x.n == name and x.ev == ev then
      if x.out then r = nil else r = x.r or r end
    end
  end
  return r
end
-- The next raid that hasn't started, from the schedule the bot writes (WhatsOn.lua): the next one whose name holds
-- hint, or when no raid's name does ("can't raid tonight", "raid thanks"), simply the next one. The reply names it.
local function nextRaid(hint, at)
  local held = ns.ScheduleNow and ns.ScheduleNow()
  local first
  for _, e in ipairs(held and held.ev or {}) do
    if e[3] == "raid" and e[1] > at then
      if not hint or e[5]:lower():find(hint, 1, true) then return e end
      first = first or e
    end
  end
  return first
end
local function startsIn(secs)
  local d, h = math.floor(secs / 86400), math.floor(secs % 86400 / 3600)
  if d > 0 then return ("in %d day%s %d h"):format(d, d == 1 and "" or "s", h) end
  return ("in %d h %d min"):format(h, math.floor(secs % 3600 / 60))
end
-- by: the officer whose client got the whisper, kept as an audit trail (the bot logs it with each sign-up).
-- t: the raid's name, so the bot still finds it if an officer moves it before the save is read.
local function wire(e)
  return table.concat({ "RSU", e.n, e.at, e.ev, e.r or "", e.out and "1" or "", e.by or "", e.t or "" }, "\t")
end

-- The answer whispered back, from what was asked and the raid it picked (nil: no raid open).
-- Raids need Discord (Louis, 8 Nov 2026 23:22: "discord will be mandatory for raids"; everywhere else it stays
-- optional). This client can't tell who has linked, so every sign-up and question reply says it once, plainly. The
-- bot counts a whisper only from a linked character, and keeps an unlinked one waiting: it counts, in its original
-- sign-up order, once they /link (gamesignup.py DISCORD_REQUIRED). So the reply says "got you", never "signed up".
function ns.RaidDiscordLine()
  local url = (ns.Invite and ns.Invite() or ns.DISCORD_INVITE or ""):gsub("^https?://", "")
  return ("Raids run on our Discord, so if you're not on it yet: %s, then /link."):format(url)
end
function ns.RaidSignupReply(p, raid, role, at)
  if not raid then
    return "No raid open yet. I'll say so in guild chat when there is one!"
  end
  if p.ask then
    return ("Next raid is %s, starting %s. Whisper raid to sign up, or raid tank or raid heal. %s"):format(raid[5],
      startsIn(raid[1] - at), ns.RaidDiscordLine())
  end
  if p.out then return ("No worries, you're off %s. Whisper raid if plans change."):format(raid[5]) end
  local url = (ns.Invite and ns.Invite() or ns.DISCORD_INVITE or ""):gsub("^https?://", "")
  return ("Got you for %s as %s, starting %s! Raids run on our Discord: if you're not on it yet, join %s and /link, "
    .. "and you keep this spot in line. Whisper raid out if plans change."):format(raid[5], ROLE_LABEL[role] or "DPS",
    startsIn(raid[1] - at), url)
end

local lastFrom = {}
function ns.RaidSignupWhisper(msg, sender)
  local me = ns.me()
  if not (me and ns.isOfficer(me)) or type(sender) ~= "string" or ns.isSecret(sender) then return false end
  local p = ns.ParseRaidWhisper(msg)
  if not p or not ns.inRoster(sender) then return false end
  local name, at = short(sender), serverNow()
  if lastFrom[name] and at - lastFrom[name] < 5 then return true end
  lastFrom[name] = at
  local raid = nextRaid(p.hint, at)
  local role = p.role or (raid and lastRole(name, raid[1])) or "dps"
  if raid and not p.ask then
    local e = { n = name, at = at, ev = raid[1], r = not p.out and role or nil, out = p.out or nil, by = short(me),
      t = raid[5] }
    record(e)
    ns.officerSend(wire(e), "GUILD")
    say(("%s whispered raid: %s %s."):format(name, p.out and "off" or ("signed up as " .. ROLE_LABEL[role] .. " for"),
      raid[5]))
  end
  ns.chat("raid.signup", ns.RaidSignupReply(p, raid, role, at), "WHISPER", ns.fullName(sender) or sender)
  return true
end

ns.handlers.RSU = function(sender, _, name, at, ev, role, out, by, title)
  local me = ns.me()
  if not (me and ns.isOfficer(me) and ns.isOfficer(sender)) or ns.fullName(sender) == me then return end
  at, ev = ns.finite(at), ns.finite(ev)
  if type(name) ~= "string" or name == "" or #name > 40 or not at or not ev or not ns.inRoster(name) then return end
  by = type(by) == "string" and ns.isOfficer(by) and by or short(sender)
  record({ n = name, at = math.floor(at), ev = math.floor(ev), r = ROLE_LABEL[role or ""] and role or nil,
    out = out == "1" or nil, by = by, t = type(title) == "string" and title ~= "" and title:sub(1, 24) or nil })
end

-- An officer logging in asks the others for the sign-ups they hold for raids still to come; each answers once per
-- ask, newest first, at most RAID_SIGNUP_SHARE, in the catch-up lane so it never crowds out live messages.
ns.handlers.RSQ = function(sender)
  local me = ns.me()
  if not (me and ns.isOfficer(me) and ns.isOfficer(sender)) or ns.fullName(sender) == me then return end
  local list, at, n = signups(), serverNow(), 0
  for i = #list, 1, -1 do
    local e = list[i]
    if n >= ns.RAID_SIGNUP_SHARE then break end
    if type(e) == "table" and (tonumber(e.ev) or 0) > at then
      n = n + 1
      ns.catchUpSend(wire(e), "WHISPER", ns.fullName(sender) or sender)
    end
  end
end

local whisperFrame = CreateFrame("Frame")
ns.listen(whisperFrame, { "CHAT_MSG_WHISPER" })
whisperFrame:SetScript("OnEvent", ns.guard(function(_, _, msg, sender)
  if UW_GuildDB then ns.protect(ns.RaidSignupWhisper, msg, sender) end
end))
table.insert(ns.onLoad, function()
  local now, list, keep = serverNow(), UW_GuildDB.raidSignups, {}
  if type(list) == "table" then
    for _, e in ipairs(list) do
      if type(e) == "table" and now - (tonumber(e.at) or 0) <= ns.RAID_SIGNUP_KEEP then keep[#keep + 1] = e end
    end
    UW_GuildDB.raidSignups = keep
  end
  ns.after(30 + math.random() * 10, function()
    local me = ns.me()
    if me and ns.isOfficer(me) then ns.protect(ns.officerSend, "RSQ", "GUILD") end
  end)
end)
