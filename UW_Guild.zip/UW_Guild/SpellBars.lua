-- New spells and ranks onto the action bars (Louis, 5 Nov 2026: "auto add max spell rank to bars AND any newly acquired
-- spells"). Forever's client, like Classic's, leaves both to the player: a new rank never replaces the old one on the
-- bars, and a new spell lands only in the spellbook.
--   * A new rank replaces the highest rank of that spell on the bars, in every slot that holds it. A lower rank kept
--     on purpose (a cheap heal) stays.
--   * A new spell from a class tab of the spellbook, with no rank of it on the bars yet, goes into the first empty
--     slot of the bars on screen (main bar first: the page showing now, so a stance, form or stealth page when one
--     is up). Never a passive, a profession or a pet spell. No empty slot: one line says where to find it.
--   * Only slots holding a plain spell are ever changed: never a macro, an item or a slot the player filled.
--   * Out of combat only (the bars are locked in a fight); what's learned in one waits for its end. One line in chat
--     and on screen each time. /uw bars off stops it for the account.
local _, ns = ...
local say = ns.say

local function g(name) return rawget(_G, name) end
local function call(fn, ...)
  if type(fn) ~= "function" then return nil end
  local ok, a, b, c = pcall(fn, ...)
  if ok then return a, b, c end
end
local function on() return UW_GuildDB and UW_GuildDB.barsAuto ~= false end

-- The first slot of the main bar as it shows now. A warrior's stance, a druid's form or a rogue's stealth swaps in
-- a bonus page (slots 73-120); paging (Shift+wheel) shows another; otherwise slots 1-12.
local function mainBarStart()
  local page = tonumber((call(g("GetActionBarPage")))) or 1
  local offset = tonumber((call(g("GetBonusBarOffset")))) or 0
  if page == 1 and offset > 0 then
    return ((tonumber(g("NUM_ACTIONBAR_PAGES")) or 6) + offset - 1) * 12 + 1
  end
  return (page - 1) * 12 + 1
end
ns.MainBarStart = mainBarStart

-- Bar slots in the order a new spell takes them: the main bar as it shows now, then the bottom left, bottom right,
-- right and left bars, each only when the game has it turned on.
local function slotOrder()
  local out = {}
  local function add(from) for s = from, from + 11 do out[#out + 1] = s end end
  add(mainBarStart())
  local bl, br, r, l = call(g("GetActionBarToggles"))
  local known = bl ~= nil
  if not known or bl then add(61) end
  if not known or br then add(49) end
  if not known or r then add(25) end
  if not known or l then add(37) end
  return out
end

local function spellInfo(id)
  local name = ns.SpellName and ns.SpellName(id)
  local sub
  local spell = g("C_Spell")
  if spell and spell.GetSpellSubtext then sub = call(spell.GetSpellSubtext, id) else sub = call(g("GetSpellSubtext"), id) end
  local rank = type(sub) == "string" and tonumber(sub:match("(%d+)")) or nil
  return name, rank, sub
end

local function passive(id)
  local spell = g("C_Spell")
  if spell and spell.IsSpellPassive then return call(spell.IsSpellPassive, id) == true end
  return call(g("IsPassiveSpell"), id) == true
end

-- The slots holding the highest rank of this spell on the bars (by name), and that rank.
local function slotsOf(name, except)
  local best, slots = nil, {}
  for slot = 1, 120 do
    local kind, id = call(g("GetActionInfo"), slot)
    if kind == "spell" and id and id ~= except then
      local n, rank = spellInfo(id)
      if n == name then
        rank = rank or 0
        if not best or rank > best then best, slots = rank, { slot }
        elseif rank == best then slots[#slots + 1] = slot end
      end
    end
  end
  return slots, best
end

local function pickup(id)
  local spell = g("C_Spell")
  if spell and spell.PickupSpell then return pcall(spell.PickupSpell, id) end
  return pcall(g("PickupSpell"), id)
end

-- Puts spell `id` into `slot`; whatever was there lands on the cursor and is dropped (it is a lower rank or nothing).
local function place(id, slot)
  if not pickup(id) then return false end
  local kind = call(g("GetCursorInfo"))
  if kind ~= "spell" then call(g("ClearCursor")) return false end
  call(g("PlaceAction"), slot)
  call(g("ClearCursor"))
  return true
end

local function notice(msg)
  say(msg)
  local frame = g("UIErrorsFrame")
  if type(frame) == "table" and type(frame.AddMessage) == "function" then
    pcall(frame.AddMessage, frame, "UW: " .. msg, 1, 0.82, 0)
  end
end

local pending = {} -- spell ID -> spellbook tab, learned in a fight

local retrying = false
local flush

-- One learned spell onto the bars. `tab` is the spellbook tab it went into (1 = General).
function ns.SpellToBars(id, tab)
  if not on() or not id or passive(id) then return end
  if InCombatLockdown() then pending[id] = tab return end
  if call(g("GetCursorInfo")) then -- the player is dragging something: never drop it; try again shortly
    pending[id] = tab
    if not retrying then retrying = true; ns.after(2, function() retrying = false; flush() end) end
    return
  end
  local name, rank, sub = spellInfo(id)
  if not name then return end
  local label = sub and sub ~= "" and ("%s (%s)"):format(name, sub) or name
  local slots, best = slotsOf(name, id)
  if #slots > 0 then
    if rank and best and rank <= best then return end -- the bars already hold this rank or a higher one
    local done = 0
    for _, slot in ipairs(slots) do if place(id, slot) then done = done + 1 end end
    if done > 0 then notice(("%s replaces the old rank on your bars."):format(label)) end
    return
  end
  if (tonumber(tab) or 0) < 2 then return end -- General tab: professions, Attack, riding; class tabs only
  for _, slot in ipairs(slotOrder()) do
    if not call(g("HasAction"), slot) then
      if place(id, slot) then notice(("%s is on your bars."):format(label)) end
      return
    end
  end
  say(("No empty bar slot for %s: drag it from your spellbook (P)."):format(label))
end

flush = function()
  if InCombatLockdown() then return end
  local list = pending
  pending = {}
  for spell, t in pairs(list) do ns.protect(ns.SpellToBars, spell, t) end
end

-- /uw bars keys (Louis, 8 Nov 2026: one keybind role map for every character). The same 12 keys play the same role
-- on every class: 1-5 rotation, 6 rare, Q interrupt, E defensive, R crowd control, F move, C heal or cleanse, V threat
-- or pet; Shift = the bigger version, Ctrl = stances, forms or help on someone else. Louis's bindings point 1-6 Q E R
-- F C V at slots 1-12, Shift at 61-72 (bottom left) and Ctrl at 49-60 (bottom right); stance, form and stealth pages
-- repeat the main keys (druid cat 73-84, bear 97-108; warrior 73/85/97; rogue stealth 73). Bars only shown on mouseover
-- still hold their slots, so nothing has to be visible. Only learned spells, only empty slots unless "force", never
-- in combat; a macro or item the player put there is kept even with force.
local KEYS = { "1", "2", "3", "4", "5", "6", "Q", "E", "R", "F", "C", "V" }
local KEY_INDEX = {}
for i, k in ipairs(KEYS) do KEY_INDEX[k] = i end
ns.ROLE_MAP = {
  WARRIOR = { pages = { 73, 85, 97 }, ["1"] = "Heroic Strike", ["2"] = "Overpower", ["3"] = "Execute", ["4"] = "Rend",
    ["5"] = "Thunder Clap", ["6"] = "Sunder Armor", Q = "Pummel", E = "Shield Block", R = "Hamstring", F = "Charge",
    V = "Taunt", ["S-1"] = "Retaliation", ["S-E"] = "Shield Wall", ["S-R"] = "Intimidating Shout",
    ["S-F"] = "Berserker Rage", ["S-V"] = "Mocking Blow", ["C-1"] = "Battle Stance", ["C-2"] = "Defensive Stance",
    ["C-3"] = "Berserker Stance" },
  PALADIN = { ["1"] = "Judgement", ["3"] = "Exorcism", ["5"] = "Consecration", Q = "Hammer of Justice",
    E = "Divine Protection", R = "Turn Undead", F = "Blessing of Freedom", C = "Flash of Light", V = "Righteous Fury",
    ["S-E"] = "Divine Shield", ["S-C"] = "Holy Light", ["C-C"] = "Blessing of Protection",
    ["C-1"] = "Seal of Righteousness", ["C-2"] = "Seal of the Crusader", ["C-3"] = "Devotion Aura" },
  HUNTER = { ["1"] = "Auto Shot", ["2"] = "Arcane Shot", ["3"] = "Aimed Shot", ["4"] = "Serpent Sting",
    ["5"] = "Multi-Shot", ["6"] = "Raptor Strike", Q = "Scatter Shot", E = "Feign Death", R = "Freezing Trap",
    F = "Disengage", C = "Mend Pet", V = "Hunter's Mark", ["S-5"] = "Volley", ["S-R"] = "Flare",
    ["S-F"] = "Aspect of the Cheetah", ["C-1"] = "Aspect of the Hawk", ["C-2"] = "Aspect of the Monkey" },
  ROGUE = { pages = { 73 }, ["1"] = "Sinister Strike", ["2"] = "Cheap Shot", ["3"] = "Eviscerate", ["4"] = "Garrote",
    ["5"] = "Blade Flurry", ["6"] = "Throw", Q = "Kick", E = "Evasion", R = "Gouge", F = "Sprint", V = "Sap",
    ["S-1"] = "Cold Blood", ["S-E"] = "Vanish", ["S-R"] = "Blind", ["C-V"] = "Pick Pocket", ["C-1"] = "Stealth" },
  PRIEST = { ["1"] = "Smite", ["2"] = "Mind Blast", ["3"] = "Mind Flay", ["4"] = "Shadow Word: Pain",
    ["5"] = "Holy Nova", ["6"] = "Shoot", E = "Power Word: Shield", R = "Psychic Scream", C = "Flash Heal",
    V = "Dispel Magic", ["S-E"] = "Fade", ["S-C"] = "Greater Heal", ["C-C"] = "Renew", ["S-V"] = "Abolish Disease" },
  SHAMAN = { ["1"] = "Lightning Bolt", ["2"] = "Stormstrike", ["3"] = "Flame Shock", ["5"] = "Chain Lightning",
    Q = "Earth Shock", E = "Lightning Shield", R = "Frost Shock", F = "Ghost Wolf", C = "Healing Wave",
    ["S-E"] = "Grounding Totem", ["S-C"] = "Chain Heal" },
  MAGE = { ["1"] = "Frostbolt", ["2"] = "Fireball", ["3"] = "Fire Blast", ["4"] = "Arcane Missiles",
    ["5"] = "Arcane Explosion", ["6"] = "Shoot", Q = "Counterspell", E = "Mana Shield", R = "Polymorph", F = "Blink",
    C = "Remove Lesser Curse", V = "Frost Nova", ["S-5"] = "Flamestrike", ["S-E"] = "Ice Block" },
  WARLOCK = { ["1"] = "Shadow Bolt", ["2"] = "Corruption", ["3"] = "Immolate", ["4"] = "Drain Life",
    ["5"] = "Rain of Fire", ["6"] = "Shoot", E = "Death Coil", R = "Fear", C = "Health Funnel",
    ["S-4"] = "Drain Soul", ["S-R"] = "Howl of Terror", ["S-2"] = "Curse of Agony" },
  DRUID = { ["1"] = "Wrath", ["2"] = "Moonfire", ["3"] = "Starfire", ["4"] = "Faerie Fire", ["5"] = "Hurricane",
    E = "Barkskin", R = "Entangling Roots", F = "Travel Form", C = "Healing Touch", V = "Remove Curse",
    ["S-F"] = "Dash", ["S-C"] = "Regrowth", ["S-V"] = "Abolish Poison", ["C-C"] = "Rejuvenation", ["C-F"] = "Prowl",
    ["C-1"] = "Bear Form", ["C-2"] = "Cat Form", ["C-3"] = "Aquatic Form",
    cat = { ["1"] = "Claw", ["2"] = "Rake", ["3"] = "Ferocious Bite", ["4"] = "Faerie Fire (Feral)", F = "Dash", E = "Barkskin" },
    bear = { ["1"] = "Maul", ["4"] = "Faerie Fire (Feral)", ["5"] = "Swipe", Q = "Bash", V = "Growl", E = "Barkskin" } },
}

local function keySlot(key, base)
  local mod, k = key:match("^([SC])%-(.+)$")
  local i = KEY_INDEX[k or key]
  if not i then return nil end
  if mod == "S" then return 60 + i elseif mod == "C" then return 48 + i end
  return (base or 1) + i - 1
end
ns.KeySlot = keySlot

-- Places the role map for this character's class. Returns placed, kept (slot already used), and the names skipped
-- because they aren't learned yet.
function ns.PlaceRoleMap(force)
  local _, class = UnitClass("player")
  local m = ns.ROLE_MAP[class]
  if not m then return nil end
  local out = { placed = 0, kept = 0, unknown = {}, seen = {} }
  local function put(spell, slot)
    if not slot then return end
    local kind = call(g("GetActionInfo"), slot)
    if call(g("HasAction"), slot) and (not force or (kind and kind ~= "spell")) then out.kept = out.kept + 1 return end
    call(g("ClearCursor"))
    pickup(spell)
    if call(g("GetCursorInfo")) ~= "spell" then
      call(g("ClearCursor"))
      if not out.seen[spell] then out.seen[spell] = true out.unknown[#out.unknown + 1] = spell end
      return
    end
    call(g("PlaceAction"), slot)
    call(g("ClearCursor"))
    out.placed = out.placed + 1
  end
  for key, spell in pairs(m) do
    if type(spell) == "string" then
      put(spell, keySlot(key))
      if m.pages and not key:find("%-") then
        for _, base in ipairs(m.pages) do put(spell, keySlot(key, base)) end
      end
    end
  end
  for key, spell in pairs(m.cat or {}) do put(spell, keySlot(key, 73)) end
  for key, spell in pairs(m.bear or {}) do put(spell, keySlot(key, 97)) end
  table.sort(out.unknown)
  return out.placed, out.kept, out.unknown
end

ns.commands.bars = function(args)
  local sub = strtrim(args or ""):lower()
  if sub == "keys" or sub == "keys force" then
    if InCombatLockdown() then say("After combat, please: /uw bars keys") return end
    if call(g("GetCursorInfo")) then say("Put down what you're dragging first.") return end
    local placed, kept, unknown = ns.PlaceRoleMap(sub == "keys force")
    if not placed then say("No keybind map for this class yet.") return end
    say(("Keybind map: %d placed, %d slots kept as they were%s."):format(placed, kept,
      sub == "keys" and kept > 0 and " (/uw bars keys force replaces spells, never macros or items)" or ""))
    if #unknown > 0 then say("Not learned yet: " .. table.concat(unknown, ", ")) end
    return
  end
  if sub == "off" then
    UW_GuildDB.barsAuto = false
  elseif sub == "on" then
    UW_GuildDB.barsAuto = nil
  end
  if on() then
    say("Bars on: new spells go into an empty bar slot, and a new rank replaces the old one. /uw bars off stops it.")
  else
    say("Bars off: new spells and ranks stay in the spellbook. /uw bars on brings them back.")
  end
end

local f = CreateFrame("Frame")
ns.listen(f, { "LEARNED_SPELL_IN_TAB", "PLAYER_REGEN_ENABLED" })
f:SetScript("OnEvent", ns.guard(function(_, event, id, tab)
  if event == "LEARNED_SPELL_IN_TAB" then
    -- After the spellbook has the spell (the event comes before SPELLS_CHANGED settles).
    ns.after(0.5, function() ns.protect(ns.SpellToBars, id, tab) end)
    return
  end
  flush()
end))
