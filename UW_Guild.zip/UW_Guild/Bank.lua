-- Guild bank snapshot for crafting recommendations: what materials the guild has on hand.
-- Forever has a guild vault (Louis's save, 15 Nov 2026: tab 1 was read at the vault). Every tab this character may
-- view is counted while someone with UW_Guild has the vault open: item counts, slots used, the tab's name as the
-- officers wrote it, and what this rank may do there. Who gave or took is never read: not the vault log, and no
-- member list. A character an officer flags with /uw bank on is counted as well: its bags whenever they change and
-- its bank whenever the bank window is open. Personal characters are never read. Counts only (item id -> count), in
-- UW_GuildDB.bank[name] and UW_GuildDB.vault; the bot reads them from the guild master's save.
local _, ns = ...

local BANK_CONTAINER = BANK_CONTAINER or -1
local BAGS = NUM_BAG_SLOTS or 4
local BANK_BAGS = NUM_BANKBAGSLOTS or 6
local VAULT_SLOTS = MAX_GUILDBANK_SLOTS_PER_TAB or 98

local function isBank() return UW_GuildCharDB and UW_GuildCharDB.isBank end
local function me() return ns.shortName(ns.me() or UnitName("player")) end

-- Item id and count in one slot, on the modern C_Container API or the legacy one.
local function slotItem(bag, slot)
  if C_Container and C_Container.GetContainerItemInfo then
    local info = C_Container.GetContainerItemInfo(bag, slot)
    if type(info) == "table" then return info.itemID, info.stackCount end
    return nil
  end
  if GetContainerItemInfo then
    local _, count, _, _, _, _, link, _, _, id = GetContainerItemInfo(bag, slot)
    id = id or (type(link) == "string" and tonumber(link:match("item:(%d+)")))
    return id, count
  end
end

local function numSlots(bag)
  local f = (C_Container and C_Container.GetContainerNumSlots) or GetContainerNumSlots
  return f and tonumber(f(bag)) or 0
end

-- { [itemID] = count } over the given bag ids.
function ns.CountBags(bags)
  local out = {}
  for _, bag in ipairs(bags) do
    for slot = 1, numSlots(bag) do
      local id, count = slotItem(bag, slot)
      if type(id) == "number" and type(count) == "number" and not ns.isSecret(id) and not ns.isSecret(count) then
        out[id] = (out[id] or 0) + count
      end
    end
  end
  return out
end

local function carried()
  local bags = {}
  for b = 0, BAGS do bags[#bags + 1] = b end
  return bags
end

local function bankBags()
  local bags = { BANK_CONTAINER }
  for b = BAGS + 1, BAGS + BANK_BAGS do bags[#bags + 1] = b end
  return bags
end

local bankOpen = false
local function entry()
  local db = UW_GuildDB.bank
  db[me()] = db[me()] or { bags = {}, bank = {} }
  return db[me()]
end

local function snapshot(withBank)
  if not isBank() or not ns.tracksGuild() then return end
  local e = entry()
  e.bags, e.at = ns.CountBags(carried()), time()
  if withBank then e.bank, e.bankAt = ns.CountBags(bankBags()), time() end
end
ns.BankSnapshot = snapshot

-- Which vault calls this client has, as one string: what the vault can do on Forever is read from the game itself.
local VAULT_CALLS = { "GetNumGuildBankTabs", "GetGuildBankTabInfo", "GetGuildBankTabPermissions", "GetGuildBankTabCost",
  "QueryGuildBankText", "GetGuildBankText", "SetGuildBankText", "SetGuildBankTabInfo", "QueryGuildBankLog",
  "GetGuildBankTransaction", "GetGuildBankWithdrawMoney", "C_GuildBank" }
local function vaultCalls()
  local have = {}
  for _, name in ipairs(VAULT_CALLS) do
    if rawget(_G, name) ~= nil then have[#have + 1] = name end
  end
  return table.concat(have, ",")
end

-- A plain value from the game, or nil: never a secret one, and a failed call reads as nothing.
local function plain(kind, v)
  if type(v) == kind and not ns.isSecret(v) then return v end
  return nil
end
local function try(name, ...)
  local fn = rawget(_G, name)
  if type(fn) ~= "function" then return nil end
  local r = { pcall(fn, ...) }
  if not r[1] then return nil end
  return r[2], r[3], r[4], r[5], r[6]
end

-- One tab: { [itemID] = count } and how many of its slots hold something.
local function tabItems(tab)
  local items, used = {}, 0
  for slot = 1, VAULT_SLOTS do
    local link = GetGuildBankItemLink(tab, slot)
    local _, count = GetGuildBankItemInfo(tab, slot)
    local id = type(link) == "string" and not ns.isSecret(link) and tonumber(link:match("item:(%d+)"))
    if id and type(count) == "number" and not ns.isSecret(count) then
      items[id], used = (items[id] or 0) + count, used + 1
    end
  end
  return items, used
end

-- What the game itself says about the things that help most per vault slot (bags, cloth, wands): the most that
-- stack in one slot, and for a bag the slots it adds, from its own tooltip. Item ids from the recipes in the guild
-- master's save. An item the client hasn't loaded yet reads as nothing and is tried again at the next visit.
ns.VAULT_FACT_ITEMS = { 2589, 2592, 4306, 2996, 2997, 2320, 10940, 4238, 4240, 4245, 253664, 253667, 277715,
  247789, 11287, 11288 }
local function itemFacts()
  local facts = {}
  local stackOf = (C_Item and C_Item.GetItemMaxStackSizeByID) or rawget(_G, "GetItemMaxStackSizeByID")
  local tip = rawget(_G, "C_TooltipInfo")
  for _, id in ipairs(ns.VAULT_FACT_ITEMS) do
    local f = {}
    if stackOf then
      local ok, n = pcall(stackOf, id)
      f.stack = ok and plain("number", n) or nil
    end
    if tip and tip.GetItemByID then
      local ok, data = pcall(tip.GetItemByID, id)
      for _, l in ipairs(ok and type(data) == "table" and type(data.lines) == "table" and data.lines or {}) do
        local t = type(l) == "table" and plain("string", l.leftText) or nil
        f.bag = f.bag or tonumber(t and t:match("^(%d+) Slot") or nil)
      end
    end
    if next(f) then facts[id] = f end
  end
  return facts
end

-- Tabs the server was asked for since the vault opened. Only those, and the tab on screen, are counted. A tab off
-- screen may not have arrived yet, and then it reads as empty: so an empty read off screen never replaces a count
-- that holds items (a tab that really was emptied is put right the next time it is on screen). onScreen = tabs
-- counted while they were the one shown, this visit: those counts are certain. perVisit = the calls and item facts
-- are still to be read this visit (once is enough).
local asked, onScreen, perVisit = {}, {}, true

-- Guild vault: every tab this character may view, after the server sends it.
local function vaultRead()
  if not (GetGuildBankItemLink and GetGuildBankItemInfo) or not ns.tracksGuild() then return end
  local v = UW_GuildDB.vault
  v.tabs = v.tabs or {}
  local now = time()
  local shown = plain("number", try("GetCurrentGuildBankTab"))
  local n = plain("number", try("GetNumGuildBankTabs"))
  for tab = 1, math.max(n or 0, shown or 0) do
    local name, _, view, deposit, takes = try("GetGuildBankTabInfo", tab)
    local items, used
    if tab == shown or (asked[tab] and view ~= false) then items, used = tabItems(tab) end
    local old = v.tabs[tab]
    if items and tab ~= shown and used == 0 and type(old) == "table" and type(old.items) == "table"
      and next(old.items) then
      items = nil
    end
    if items then
      onScreen[tab] = onScreen[tab] or tab == shown or nil
      -- used = slots holding something, on = counted while on screen, dep = this rank may put things in, wd = how
      -- many items this rank may take a day.
      v.tabs[tab] = { at = now, items = items, used = used, on = onScreen[tab],
        name = (plain("string", name) or ""):sub(1, 40), dep = plain("boolean", deposit), wd = plain("number", takes) }
    end
  end
  -- n = tabs the guild owns, slots = slots in a tab, next = the game's price for the next tab (copper), api = the
  -- vault calls this client has, facts = stack and bag sizes.
  v.n, v.slots, v.next, v.at = n, VAULT_SLOTS, plain("number", try("GetGuildBankTabCost")), now
  if perVisit then
    perVisit = false
    v.api = vaultCalls()
    local facts = itemFacts()
    if next(facts) then v.facts = facts end
  end
end
ns.VaultRead = vaultRead

local pending = {}
local function soon(kind, fn)
  if pending[kind] then return end
  pending[kind] = true
  ns.after(2, function()
    pending[kind] = nil
    local ok, err = pcall(fn)
    if not ok then ns.say("Couldn't count the guild bank (" .. tostring(err) .. ").") end
  end)
end

table.insert(ns.onLoad, function()
  UW_GuildDB.bank = UW_GuildDB.bank or {}
  UW_GuildDB.vault = UW_GuildDB.vault or {}
  UW_GuildCharDB = UW_GuildCharDB or {}
end)

local f = CreateFrame("Frame")
ns.listen(f, { "BAG_UPDATE_DELAYED", "BANKFRAME_OPENED", "BANKFRAME_CLOSED", "PLAYERBANKSLOTS_CHANGED",
  "GUILDBANKFRAME_OPENED", "GUILDBANKBAGSLOTS_CHANGED" })
f:SetScript("OnEvent", ns.guard(function(_, event)
  if not UW_GuildDB or not UW_GuildDB.bank then return end
  if event == "BANKFRAME_OPENED" then
    bankOpen = true
    soon("bank", function() snapshot(true) end)
  elseif event == "BANKFRAME_CLOSED" then
    bankOpen = false
  elseif event == "BAG_UPDATE_DELAYED" or event == "PLAYERBANKSLOTS_CHANGED" then
    soon("bags", function() snapshot(bankOpen) end)
  elseif event == "GUILDBANKFRAME_OPENED" then
    asked, onScreen, perVisit = {}, {}, true
    local query = rawget(_G, "QueryGuildBankTab")
    for tab = 1, query and plain("number", try("GetNumGuildBankTabs")) or 0 do
      asked[tab] = pcall(query, tab) or nil
    end
  elseif event == "GUILDBANKBAGSLOTS_CHANGED" then
    soon("vault", vaultRead)
  end
end))

ns.commands.bank = function(args)
  local word = strtrim(args or ""):lower()
  if word == "on" then
    if not ns.tracksGuild() then ns.say("This character isn't in the guild UW_Guild tracks.") return end
    UW_GuildCharDB.isBank = true
    snapshot(bankOpen)
    ns.say("This character is now the guild bank. Open its bank once so those slots count too. Only item counts are "
      .. "saved. /uw bank off undoes this.")
  elseif word == "off" then
    UW_GuildCharDB.isBank = nil
    UW_GuildDB.bank[me()] = nil
    ns.say("This character is no longer the guild bank, and its counts were removed.")
  else
    local e = UW_GuildDB.bank[me()]
    if not isBank() then
      ns.say("This character isn't the guild bank. On the guild's bank character, type /uw bank on.")
    else
      local n = 0
      for _ in pairs(e and e.bank or {}) do n = n + 1 end
      ns.say(("Guild bank: %s. %d kinds of item counted in the bank%s."):format(me(), n,
        e and e.bankAt and "" or " (open the bank once)"))
    end
  end
end
