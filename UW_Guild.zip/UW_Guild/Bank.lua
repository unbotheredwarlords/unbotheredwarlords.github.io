-- Guild bank snapshot for crafting recommendations: what materials the guild has on hand.
-- Forever has a guild vault (Louis's save, 22 Nov 2026: its gold was read there, before any tab was bought). Every tab this character may
-- view is counted while someone with UW_Guild has the vault open: item counts, slots used, the tab's name as the
-- officers wrote it, and what this rank may do there. Who took is never read, and neither is the item log. Who put
-- gold in is read, on the Guild Master's account only, so that the giver can be thanked (Louis, 22 Nov 2026). A character an officer flags with /uw bank on is counted as well: its bags whenever they change and
-- its bank whenever the bank window is open. Personal characters are never read. Counts only (item id -> count), in
-- UW_GuildDB.bank[name] and UW_GuildDB.vault; the bot reads them from the guild master's save.
local _, ns = ...

local BANK_CONTAINER = BANK_CONTAINER or -1
local BAGS = NUM_BAG_SLOTS or 4
local BANK_BAGS = NUM_BANKBAGSLOTS or 6
local VAULT_SLOTS = MAX_GUILDBANK_SLOTS_PER_TAB or 98

local function isBank() return UW_GuildCharDB and UW_GuildCharDB.isBank end
local function me() return ns.shortName(ns.me() or UnitName("player")) end

-- Item id and count in one slot, on the modern C_Container API or the legacy one.
local function slotItem(bag, slot)
  if C_Container and C_Container.GetContainerItemInfo then
    local info = C_Container.GetContainerItemInfo(bag, slot)
    if type(info) == "table" then return info.itemID, info.stackCount end
    return nil
  end
  if GetContainerItemInfo then
    local _, count, _, _, _, _, link, _, _, id = GetContainerItemInfo(bag, slot)
    id = id or (type(link) == "string" and tonumber(link:match("item:(%d+)")))
    return id, count
  end
end

local function numSlots(bag)
  local f = (C_Container and C_Container.GetContainerNumSlots) or GetContainerNumSlots
  return f and tonumber(f(bag)) or 0
end

-- { [itemID] = count } over the given bag ids.
function ns.CountBags(bags)
  local out = {}
  for _, bag in ipairs(bags) do
    for slot = 1, numSlots(bag) do
      local id, count = slotItem(bag, slot)
      if type(id) == "number" and type(count) == "number" and not ns.isSecret(id) and not ns.isSecret(count) then
        out[id] = (out[id] or 0) + count
      end
    end
  end
  return out
end

local function carried()
  local bags = {}
  for b = 0, BAGS do bags[#bags + 1] = b end
  return bags
end

local function bankBags()
  local bags = { BANK_CONTAINER }
  for b = BAGS + 1, BAGS + BANK_BAGS do bags[#bags + 1] = b end
  return bags
end

local bankOpen = false
local function entry()
  local db = UW_GuildDB.bank
  db[me()] = db[me()] or { bags = {}, bank = {} }
  return db[me()]
end

local function snapshot(withBank)
  if not isBank() or not ns.tracksGuild() then return end
  local e = entry()
  e.bags, e.at = ns.CountBags(carried()), time()
  if withBank then e.bank, e.bankAt = ns.CountBags(bankBags()), time() end
end
ns.BankSnapshot = snapshot

-- Which vault calls this client has, as one string: what the vault can do on Forever is read from the game itself.
local VAULT_CALLS = { "GetNumGuildBankTabs", "GetGuildBankTabInfo", "GetGuildBankTabPermissions", "GetGuildBankTabCost",
  "QueryGuildBankText", "GetGuildBankText", "SetGuildBankText", "SetGuildBankTabInfo", "QueryGuildBankLog",
  "GetGuildBankTransaction", "GetGuildBankMoney", "GetGuildBankWithdrawMoney", "GetNumGuildBankMoneyTransactions",
  "GetGuildBankMoneyTransaction", "C_GuildBank" }
local function vaultCalls()
  local have = {}
  for _, name in ipairs(VAULT_CALLS) do
    if rawget(_G, name) ~= nil then have[#have + 1] = name end
  end
  return table.concat(have, ",")
end

-- A plain value from the game, or nil: never a secret one, and a failed call reads as nothing.
local function plain(kind, v)
  if type(v) == kind and not ns.isSecret(v) then return v end
  return nil
end
local function try(name, ...)
  local fn = rawget(_G, name)
  if type(fn) ~= "function" then return nil end
  return (function(ok, ...) if ok then return ... end end)(pcall(fn, ...))
end

-- What one of an item is worth, in copper: Items.lua's one price rule (the higher of the vendor price and
-- Auctionator's last scan). 0 when the client hasn't loaded the item yet or nothing prices it.
local function worthOf(link)
  if not (ns.ItemInfo and ns.ItemWorth) then return 0 end
  local ok, each = pcall(function() return (ns.ItemWorth(link, ns.ItemInfo(link))) end)
  return ok and plain("number", each) or 0
end

-- One tab: { [itemID] = count }, how many of its slots hold something, what it is all worth (copper) and how many
-- of those slots had a price.
local function tabItems(tab)
  local items, used, worth, priced = {}, 0, 0, 0
  for slot = 1, VAULT_SLOTS do
    local link = GetGuildBankItemLink(tab, slot)
    local _, count = GetGuildBankItemInfo(tab, slot)
    local id = type(link) == "string" and not ns.isSecret(link) and tonumber(link:match("item:(%d+)"))
    if id and type(count) == "number" and not ns.isSecret(count) then
      items[id], used = (items[id] or 0) + count, used + 1
      local each = worthOf(link)
      if each > 0 then worth, priced = worth + each * count, priced + 1 end
    end
  end
  return items, used, math.floor(worth + 0.5), priced
end

-- What the game itself says about the things that help most per vault slot (bags, cloth, wands): the most that
-- stack in one slot, and for a bag the slots it adds, from its own tooltip. Item ids from the recipes in the guild
-- master's save. An item the client hasn't loaded yet reads as nothing and is tried again at the next visit.
ns.VAULT_FACT_ITEMS = { 2589, 2592, 4306, 2996, 2997, 2320, 10940, 4238, 4240, 4245, 253664, 253667, 277715,
  247789, 11287, 11288 }
local function itemFacts()
  local facts = {}
  local stackOf = (C_Item and C_Item.GetItemMaxStackSizeByID) or rawget(_G, "GetItemMaxStackSizeByID")
  local tip = rawget(_G, "C_TooltipInfo")
  for _, id in ipairs(ns.VAULT_FACT_ITEMS) do
    local f = {}
    if stackOf then
      local ok, n = pcall(stackOf, id)
      f.stack = ok and plain("number", n) or nil
    end
    if tip and tip.GetItemByID then
      local ok, data = pcall(tip.GetItemByID, id)
      for _, l in ipairs(ok and type(data) == "table" and type(data.lines) == "table" and data.lines or {}) do
        local t = type(l) == "table" and plain("string", l.leftText) or nil
        f.bag = f.bag or tonumber(t and t:match("^(%d+) Slot") or nil)
      end
    end
    if next(f) then facts[id] = f end
  end
  return facts
end

-- A tab's name as the officers wrote it, 40 bytes at most. Only a name that was cut loses its last character if
-- the cut fell inside it (as Loot.lua and Raid.lua do); a short name is kept whole.
local function tabName(name)
  name = plain("string", name) or ""
  if #name > 40 then name = name:sub(1, 40):gsub("[\192-\255][\128-\191]*$", "") end
  return name
end

-- Tabs the server was asked for since the vault opened. Only those, and the tab on screen, are counted. A tab off
-- screen may not have arrived yet, and then it reads as empty: so an empty read off screen never replaces a count
-- that holds items (a tab that really was emptied is put right the next time it is on screen). onScreen = tabs
-- counted while they were the one shown, this visit: those counts are certain. perVisit = the calls and item facts
-- are still to be read this visit (once is enough). reads = vault reads this visit: the first can come before the
-- tab on screen has arrived. openAt = when this visit began, nil once the vault closed.
local asked, onScreen, perVisit, openedVia, reads, openAt = {}, {}, true, nil, 0, nil

-- The rank this character holds (0 = guild master): what a tab or the money allows depends on it.
local function myRank()
  local _, _, rank = try("GetGuildInfo", "player")
  return plain("number", rank)
end

-- Guild vault: every tab this character may view, after the server sends it.
local function vaultRead()
  if not (GetGuildBankItemLink and GetGuildBankItemInfo) or not ns.tracksGuild() then return end
  local v = UW_GuildDB.vault
  v.tabs = v.tabs or {}
  local now = time()
  local shown = plain("number", try("GetCurrentGuildBankTab"))
  local n = plain("number", try("GetNumGuildBankTabs"))
  local rank = myRank()
  reads = reads + 1
  -- A guild with no tab yet has none to count, even though the client still names tab 1 as the one shown.
  for tab = 1, n or shown or 0 do
    local name, _, view, deposit, takes = try("GetGuildBankTabInfo", tab)
    local items, used, worth, priced
    -- A tab this rank can't view is never read, on screen or off: the client holds nothing for it.
    if plain("boolean", view) ~= false and (tab == shown or asked[tab]) then
      items, used, worth, priced = tabItems(tab)
    end
    -- An empty read never replaces a count that holds items when it may simply be early: off screen, or on screen
    -- at the visit's first read.
    local old = v.tabs[tab]
    if items and used == 0 and (tab ~= shown or reads == 1) and type(old) == "table" and type(old.items) == "table"
      and next(old.items) then
      items = nil
    end
    if items then
      onScreen[tab] = onScreen[tab] or tab == shown or nil
      -- used = slots holding something, on = counted while on screen, dep = this rank may put things in, wd = how
      -- many items this rank may take a day, rank = the rank dep and wd are for, worth = what the tab holds is worth
      -- (copper), priced = slots with a price.
      v.tabs[tab] = { at = now, items = items, used = used, on = onScreen[tab], worth = worth, priced = priced,
        name = tabName(name), dep = plain("boolean", deposit), wd = plain("number", takes), rank = rank }
    end
  end
  -- An empty tab past the ones the guild owns was never really there (an early read of a guild with no tab named
  -- tab 1). A record that holds items is kept: the client may answer 0 tabs before it knows.
  if n then
    for tab, rec in pairs(v.tabs) do
      if type(tab) == "number" and tab > n and not (type(rec) == "table" and type(rec.items) == "table"
        and next(rec.items)) then
        v.tabs[tab] = nil
      end
    end
  end
  -- n = tabs the guild owns, slots = slots in a tab, next = the game's price for the next tab (copper), api = the
  -- vault calls this client has, facts = stack and bag sizes.
  v.n, v.slots, v.next, v.at = n, VAULT_SLOTS, plain("number", try("GetGuildBankTabCost")), now
  -- ah = Auctionator is there to price things (without it worth is the vendor price alone). via = which of the
  -- client's events said the vault opened this visit, if either did.
  v.ah, v.via = type(rawget(_G, "Auctionator")) == "table" or nil, openedVia
  if perVisit then
    perVisit = false
    v.api = vaultCalls()
    local facts = itemFacts()
    if next(facts) then v.facts = facts end
  end
end
ns.VaultRead = vaultRead

-- The guild bank's money, when the server sends it: gold = copper, goldWd = how much of it this rank may take a day,
-- goldRank = that rank. That also happens away from the vault (at login, or a repair on guild funds), where the client
-- holds no tab contents: so this reads the money alone and never touches a tab's count. Away from the vault the
-- client may also answer 0 before it knows: a 0 there never replaces a total, it is kept as goldZeroAt. A 0 read at
-- the vault is taken as read. A failing call leaves the last reading.
-- The guild's own total, for the guild master and officers: nothing here is shown or sent by the addon.
local function goldRead()
  if not ns.tracksGuild() then return end
  local gold = plain("number", try("GetGuildBankMoney"))
  if not gold then return end
  local v = UW_GuildDB.vault
  if gold == 0 and not openAt and (v.gold or 0) > 0 then
    v.goldZeroAt = time()
    return
  end
  v.gold, v.goldWd, v.goldRank, v.goldAt = gold, plain("number", try("GetGuildBankWithdrawMoney")), myRank(), time()
  v.goldZeroAt = nil
end
ns.VaultGold = goldRead

-- Gold put in the guild bank, so Louis can thank each giver himself (22 Nov 2026: "thank specifically those who've
-- given gold"; 23 Nov: "track gold deposits of more than 5g and give me whispers to send citing exact amount(s)").
-- Only deposits are read: never a withdrawal, a repair or anything about items. Only on the Guild Master's account
-- (UW_GuildDB.gmAccount): he is the one who thanks, and his save is the one the bot reads, so no other PC holds a copy.
-- A character on this account (UW_GuildDB.alts, or this one) is not a giver. The game's money log keeps only its
-- latest entries and says "N hours ago", so each deposit is copied once, as the guild event log is (Onboarding.lua):
-- h = a hash of the giver, copper, and the time of its first read, which never moves; an entry read again within 2
-- hours of that time, with the same hash and amount, is the same one. who = the giver's name, kept only on a gift
-- over ns.BANK_THANKS_MIN and only until it is thanked (ns.VaultGiftThanked), at most GIFTS_DAYS; a smaller gift keeps
-- no name. Nothing is sent, shown, whispered or posted from here.
ns.GIFTS_MAX, ns.GIFTS_DAYS = 200, 60
ns.BANK_THANKS_MIN = 50000   -- copper: a gift of MORE than 5g is offered for a thank-you (Louis, 23 Nov 2026)
local MONEY_LOG = (rawget(_G, "MAX_GUILDBANK_TABS") or 8) + 1
local HOUR = 3600

local function count0(v) return plain("number", v) or 0 end
local function lowerShort(name) return (ns.shortName(name) or name):lower() end

local function ownCharacter(name)
  local who = lowerShort(name)
  local mine = ns.me()
  if type(mine) == "string" and lowerShort(mine) == who then return true end
  for alt in pairs(type(UW_GuildDB.alts) == "table" and UW_GuildDB.alts or {}) do
    if type(alt) == "string" and lowerShort(alt) == who then return true end
  end
  return false
end

local function gmAccount() return UW_GuildDB.gmAccount == true and ns.tracksGuild() end

local function giftsRead()
  if not gmAccount() then return end
  local total = plain("number", try("GetNumGuildBankMoneyTransactions"))
  if not total then return end
  local v = UW_GuildDB.vault
  v.gifts = type(v.gifts) == "table" and v.gifts or {}
  local list, now, claimed, fresh = v.gifts, time(), {}, {}
  local owned = plain("number", v.n)   -- tabs owned at this read: a gift goes toward the next one
  for i = 1, math.min(total, 100) do
    local kind, who, copper, y, mo, d, hr = try("GetGuildBankMoneyTransaction", i)
    kind, who, copper = plain("string", kind), plain("string", who), plain("number", copper)
    if kind == "deposit" and who and who ~= "" and copper and copper > 0 and not ownCharacter(who) then
      local at = now - ((count0(y) * 365 + count0(mo) * 30 + count0(d)) * 24 + count0(hr)) * HOUR
      local h, match = ns.NameHash(lowerShort(who), ""), nil
      for idx, e in ipairs(list) do
        if not claimed[idx] and e.h == h and e.c == copper and math.abs((tonumber(e.at) or 0) - at) <= 2 * HOUR then
          match = idx
          break
        end
      end
      if match then
        claimed[match] = true
      else
        fresh[#fresh + 1] = { h = h, who = copper > ns.BANK_THANKS_MIN and who or nil, c = copper,
          at = math.floor(at), tab = owned and owned + 1 or nil }
      end
    end
  end
  for _, e in ipairs(fresh) do list[#list + 1] = e end
  table.sort(list, function(a, b) return (tonumber(a.at) or 0) > (tonumber(b.at) or 0) end)
  local oldest = now - ns.GIFTS_DAYS * 86400
  for i = #list, 1, -1 do
    if i > ns.GIFTS_MAX or (tonumber(list[i].at) or 0) < oldest then table.remove(list, i) end
  end
  ns.VaultGiftsTidy()
  v.giftsAt = now
  if ns.BankThanksNotice then ns.after(1, ns.BankThanksNotice) end
end
ns.VaultGifts = giftsRead

-- Thanking givers (Louis, 23 Nov 2026 03:42: "no more addon thanks for guild tab contributions, but track gold
-- deposits of more than 5g and give me whispers to send citing exact amount(s)!"). On his account only: the notice
-- above chat names one giver, and his click whispers them his line with the exact amount of each gift over 5g not
-- yet thanked, oldest first. Nothing goes without his click (no automatic whispers, ever).
ns.BANK_THANKS = "Thank you for giving %s to the guild bank! <3"
ns.BANK_THANKS_REST = 86400   -- a giver thanked isn't offered again for a day: a second gift waits until tomorrow

local function vaultDB() return type(UW_GuildDB) == "table" and type(UW_GuildDB.vault) == "table" and UW_GuildDB.vault end

-- How close tab 1 is, for /uw bank on his account (a giver asked "how close are we?", 22 Nov):
-- "We're at 62g of 100g.", whole gold rounded down. Only the true amount now (Louis, 22 Nov 19:55: "so long as you
-- can actually detect the true current amount"): only while the vault is open, where the game sends the bank's money
-- as it changes, and only once it has this visit (goldAt); then the live GetGuildBankMoney. Nil otherwise, or when the
-- gold already covers the tab.
function ns.BankProgress()
  if not openAt then return nil end
  local v = vaultDB()
  local gold, at = plain("number", try("GetGuildBankMoney")), v and plain("number", v.goldAt)
  local target = plain("number", try("GetGuildBankTabCost")) or (v and plain("number", v.next))
  if not (gold and target and at) or at < openAt or gold <= 0 or target <= 0 or gold >= target then return nil end
  return ("We're at %dg of %dg."):format(math.floor(gold / 10000), math.floor(target / 10000))
end

-- Guildmates online now, by lower-case short name. A whisper to someone offline never arrives ("No player named ...
-- is currently playing"): on 22 Nov half of Louis's first thank-yous went that way. Givers are offered only while
-- online, and the rest wait until they log in.
local function onlineNow()
  local out = {}
  for i = 1, plain("number", try("GetNumGuildMembers")) or 0 do
    local full, _, _, _, _, _, _, _, online = try("GetGuildRosterInfo", i)
    if type(full) == "string" and not ns.isSecret(full) and online and not ns.isSecret(online) then
      out[lowerShort(full)] = true
    end
  end
  return out
end

-- Gold as the game writes it in chat, exact: 125000 -> "12g 50s", 50001 -> "5g 1c".
function ns.BankGoldText(copper)
  copper = math.floor(tonumber(copper) or 0)
  local g, si, c, out = math.floor(copper / 10000), math.floor(copper / 100) % 100, copper % 100, {}
  if g > 0 then out[#out + 1] = g .. "g" end
  if si > 0 then out[#out + 1] = si .. "s" end
  if c > 0 or #out == 0 then out[#out + 1] = c .. "c" end
  return table.concat(out, " ")
end

-- His line for these gifts (copper, oldest first): "12g", "12g and 8g 50s", "12g, 8g and 6g". A list too long for
-- one chat line names their exact total instead.
function ns.BankThanksLine(amounts)
  local parts, total = {}, 0
  for i, c in ipairs(amounts) do parts[i], total = ns.BankGoldText(c), total + c end
  if #parts == 0 then return nil end
  local listed = #parts == 1 and parts[1] or table.concat(parts, ", ", 1, #parts - 1) .. " and " .. parts[#parts]
  local line = ns.BANK_THANKS:format(listed)
  return #line <= ns.CHAT_BYTES and line or ns.BANK_THANKS:format(ns.BankGoldText(total))
end

local function thankable(e)
  return type(e) == "table" and type(e.who) == "string" and not e.t and not e.d
    and (tonumber(e.c) or 0) > ns.BANK_THANKS_MIN
end

-- A giver's gifts still to thank, by their hash: copper oldest first, and the total.
local function giverGifts(v, h)
  local amounts, total = {}, 0
  for i = #v.gifts, 1, -1 do
    local e = v.gifts[i]
    if e.h == h and thankable(e) then amounts[#amounts + 1], total = e.c, total + e.c end
  end
  return amounts, total
end

-- Names kept only where a thank-you is still to come: none on a gift thanked, closed, or of 5g or less. (Before 23 Nov a gift
-- toward tab 1 kept its name after a thank-you, for the one when the tab was bought; that thank-you is retired.)
function ns.VaultGiftsTidy()
  local v = vaultDB()
  if not v or type(v.gifts) ~= "table" then return end
  for _, e in ipairs(v.gifts) do
    if type(e) == "table" and e.who and (e.t or e.d or (tonumber(e.c) or 0) <= ns.BANK_THANKS_MIN) then e.who = nil end
  end
end

-- He closed a giver's notice (Louis, 24 Nov 2026: "I keep getting donation notices that I've already dismissed"): d =
-- when, on each of their gifts still to thank, and their name leaves them, so it stays closed after a /reload. A later
-- gift from them is offered as usual.
function ns.VaultGiftDismissed(h)
  local v = vaultDB()
  if h == nil or not v or type(v.gifts) ~= "table" then return 0 end
  local n, now = 0, time()
  for _, e in ipairs(v.gifts) do
    if e.h == h and thankable(e) then e.d, e.who, n = now, nil, n + 1 end
  end
  return n
end

-- A giver was thanked: t = when, on each of their gifts not yet thanked, and their name leaves them. Each stays as a
-- hash, copper and time, so the same log line is never taken for a new gift. Returns how many, and what each was, for
-- the undo when the game says the whisper never arrived.
function ns.VaultGiftThanked(who)
  local v = vaultDB()
  if type(who) ~= "string" or not v or type(v.gifts) ~= "table" then return 0 end
  local h, n, now, was = ns.NameHash(lowerShort(who), ""), 0, time(), {}
  for _, e in ipairs(v.gifts) do
    if e.h == h and thankable(e) then
      was[#was + 1] = { e = e, who = e.who }
      e.t, e.who, n = now, nil, n + 1
    end
  end
  return n, was
end

-- The next giver to thank, or nil: { who, h, amounts, total, line }. The oldest gift over 5g not thanked, from
-- someone not thanked in the last BANK_THANKS_REST, with all of that giver's gifts still to thank. Only guildmates in
-- the guild and online now, never this account's, and none in skip (lower-case short names set aside this session).
function ns.BankThanksNext(skip)
  local v = vaultDB()
  if not v or type(v.gifts) ~= "table" then return nil end
  local now, recent, online = time(), {}, onlineNow()
  for _, e in ipairs(v.gifts) do
    if e.t and now - e.t < ns.BANK_THANKS_REST then recent[e.h] = true end
  end
  for i = #v.gifts, 1, -1 do -- oldest first
    local e = v.gifts[i]
    if thankable(e) and not recent[e.h] and not (skip and skip[lowerShort(e.who)]) and not ownCharacter(e.who)
      and ns.inRoster(e.who) and online[lowerShort(e.who)] then
      local amounts, total = giverGifts(v, e.h)
      return { who = e.who, h = e.h, amounts = amounts, total = total, line = ns.BankThanksLine(amounts) }
    end
  end
  return nil
end

-- The vault opened: ask the server for every tab, and start a new visit. A client may say so with both events: the
-- second, a moment later, only adds its name to via (frame+manager) and asks for nothing again.
local function vaultOpened(via)
  local now = time()
  if openAt and now - openAt < 5 then
    if not openedVia:find(via, 1, true) then openedVia = openedVia .. "+" .. via end
    return
  end
  asked, onScreen, perVisit, openedVia, reads, openAt = {}, {}, true, via, 0, now
  local query = rawget(_G, "QueryGuildBankTab")
  for tab = 1, query and plain("number", try("GetNumGuildBankTabs")) or 0 do
    asked[tab] = pcall(query, tab) or nil
  end
  if gmAccount() then try("QueryGuildBankLog", MONEY_LOG) end
end

-- The notice above chat, on the Guild Master's account only: "Mia put 12g in the guild bank: say thanks". One click
-- whispers his line to that one guildmate (ns.chat: each new shape of it first in his OK popup); the close mark skips
-- that giver's gifts for good (ns.VaultGiftDismissed). Nothing goes without his click.
local thanksButton, current = nil, nil
function ns.BankThanksNotice()
  current = type(UW_GuildDB) == "table" and UW_GuildDB.gmAccount == true and ns.ChatOn("bank.thanks")
    and ns.BankThanksNext() or nil
  if not current or ns.Restricted() or not ns.ChatBarAdd or (ns.ChatBarHidden and ns.ChatBarHidden()) then
    if thanksButton then thanksButton:Hide() end
    return nil
  end
  if not thanksButton then
    thanksButton = CreateFrame("Button", "UWGuildBankThanks", UIParent)
    thanksButton:SetScript("OnClick", function() ns.protect(ns.BankThank) end)
    ns.useButton(thanksButton, "bank thanks")
    thanksButton.uwClose = function()
      if current then ns.VaultGiftDismissed(current.h) end
      ns.BankThanksNotice()
    end
    ns.ChatBarAdd("bank thanks", thanksButton, 17,
      "Whispers them your thank-you. Close to skip it.")
  end
  local shown = ns.shortName(current.who) or current.who
  thanksButton:Show()
  ns.ChatBarText(thanksButton, ("%s put %s in the guild bank: say thanks"):format(shown,
    ns.BankGoldText(current.total)))
  return current
end

-- The click: one whisper of his line, with the amounts as they are now, to the guildmate on the notice. Marked
-- thanked once the game takes it.
function ns.BankThank()
  local c = current
  if not c then return false end
  if ns.Restricted() then ns.say("Not in a fight.") return false end
  if ns.LineWaiting and ns.LineWaiting("bank.thanks") then ns.say("Waiting for your OK on the popup.") return false end
  local v = vaultDB()
  local line = v and type(v.gifts) == "table" and ns.BankThanksLine((giverGifts(v, c.h)))
  if not line then return false end
  local sent, held = ns.chat("bank.thanks", line, "WHISPER", ns.fullName(c.who) or c.who)
  if not sent then ns.say(("Not sent: %s."):format(held or "the game didn't send it")) end
  return sent
end
-- [lower-case short name] = { at, was }: thank-yous of the last few seconds, undone if the game says that giver
-- isn't online. Several, as he may click through a few in a second.
local justThanked = {}
ns.OnSent["bank.thanks"] = function(target)
  local _, was = ns.VaultGiftThanked(target)
  local now = time()
  for k, j in pairs(justThanked) do if now - j.at > 10 then justThanked[k] = nil end end
  justThanked[lowerShort(target)] = { at = now, was = was }
  ns.trace("bank", "thanks", true) -- counts only
  ns.after(0.5, ns.BankThanksNotice)
end

-- The game's "No player named '%s' is currently playing." just after a thank-you: it never arrived, so that giver is
-- not marked thanked and is offered again once online.
local function offlineName(text) -- the game's own string, in the client's language
  local fmt = rawget(_G, "ERR_CHAT_PLAYER_NOT_FOUND_S")
  if type(fmt) ~= "string" or type(text) ~= "string" or ns.isSecret(text) then return nil end
  return text:match("^" .. fmt:gsub("[%%%(%)%.%+%-%*%?%[%]%^%$]", "%%%0"):gsub("%%%%s", "(.+)") .. "$")
end
ns.BANK_UNDELIVERED = "%s didn't get your thank-you (not online). It shows again when they are."
function ns.BankThanksUndelivered(text)
  local who = next(justThanked) and offlineName(text)
  local j = who and justThanked[lowerShort(who)]
  if not (j and time() - j.at <= 10) then return false end
  for _, w in ipairs(j.was or {}) do w.e.t, w.e.who = nil, w.who end
  justThanked[lowerShort(who)] = nil
  ns.trace("bank", "thanks offline", true) -- counts only
  -- Said, so a notice he answered doesn't seem to come back for no reason (Louis, 24 Nov 2026).
  ns.say(ns.BANK_UNDELIVERED:format(ns.shortName(who) or who))
  ns.after(0.5, ns.BankThanksNotice)
  return true
end

local pending = {}
local function soon(kind, fn)
  if pending[kind] then return end
  pending[kind] = true
  ns.after(2, function()
    pending[kind] = nil
    local ok, err = pcall(fn)
    if not ok then ns.say("Couldn't count the guild bank (" .. tostring(err) .. ").") end
  end)
end

table.insert(ns.onLoad, function()
  UW_GuildDB.bank = UW_GuildDB.bank or {}
  UW_GuildDB.vault = UW_GuildDB.vault or {}
  UW_GuildCharDB = UW_GuildCharDB or {}
  if UW_GuildDB.gmAccount == true then ns.VaultGiftsTidy() end
end)

local f = CreateFrame("Frame")
ns.listen(f, { "BAG_UPDATE_DELAYED", "BANKFRAME_OPENED", "BANKFRAME_CLOSED", "PLAYERBANKSLOTS_CHANGED",
  "GUILDBANKFRAME_OPENED", "PLAYER_INTERACTION_MANAGER_FRAME_SHOW", "GUILDBANKBAGSLOTS_CHANGED",
  "GUILDBANK_UPDATE_MONEY", "GUILDBANKFRAME_CLOSED", "PLAYER_INTERACTION_MANAGER_FRAME_HIDE", "GUILDBANKLOG_UPDATE",
  "PLAYER_ENTERING_WORLD", "PLAYER_REGEN_ENABLED", "GUILD_ROSTER_UPDATE", "CHAT_MSG_SYSTEM" })
f:SetScript("OnEvent", ns.guard(function(_, event, kind)
  if not UW_GuildDB or not UW_GuildDB.bank then return end
  if event == "BANKFRAME_OPENED" then
    bankOpen = true
    soon("bank", function() snapshot(true) end)
  elseif event == "BANKFRAME_CLOSED" then
    bankOpen = false
  elseif event == "BAG_UPDATE_DELAYED" or event == "PLAYERBANKSLOTS_CHANGED" then
    soon("bags", function() snapshot(bankOpen) end)
  elseif event == "GUILDBANKFRAME_OPENED" then
    vaultOpened("frame")
  elseif event == "GUILDBANKFRAME_CLOSED" then
    openAt = nil
  elseif event == "PLAYER_INTERACTION_MANAGER_FRAME_SHOW" or event == "PLAYER_INTERACTION_MANAGER_FRAME_HIDE" then
    -- The modern client's way of saying a window opened or closed; only the guild vault's is ours.
    local types = rawget(_G, "Enum") and Enum.PlayerInteractionType
    if type(types) == "table" and types.GuildBanker ~= nil and not ns.isSecret(kind) and kind == types.GuildBanker then
      if event == "PLAYER_INTERACTION_MANAGER_FRAME_SHOW" then vaultOpened("manager") else openAt = nil end
    end
  elseif event == "GUILDBANKBAGSLOTS_CHANGED" then
    soon("vault", vaultRead)
  elseif event == "GUILDBANK_UPDATE_MONEY" then
    soon("gold", goldRead)
  elseif event == "GUILDBANKLOG_UPDATE" then
    soon("gifts", giftsRead)
  elseif event == "PLAYER_ENTERING_WORLD" or event == "PLAYER_REGEN_ENABLED" then
    soon("thanks", ns.BankThanksNotice) -- after login, a reload or a fight: the roster may need a moment
  elseif event == "GUILD_ROSTER_UPDATE" then
    if UW_GuildDB.gmAccount == true then soon("thanks", ns.BankThanksNotice) end -- a giver came online, or left
  elseif event == "CHAT_MSG_SYSTEM" then
    if next(justThanked) then ns.BankThanksUndelivered(kind) end
  end
end))

ns.BANK_SISTER = "The guild bank is for <%s>. Switch to a character in it."   -- as Charter.lua's ns.RECRUIT_SISTER
ns.BANK_NOT_OURS = "This character isn't in <%s>."
ns.commands.bank = function(args)
  local word = strtrim(args or ""):lower()
  if word == "on" then
    if not ns.tracksGuild() then
      ns.say((ns.inSisterGuild and ns.inSisterGuild() and ns.BANK_SISTER or ns.BANK_NOT_OURS):format(ns.GUILD_NAME))
      return
    end
    UW_GuildCharDB.isBank = true
    snapshot(bankOpen)
    ns.say("This character is now the guild bank. Open its bank once so those slots count too. Only item counts are "
      .. "saved. /uw bank off undoes this.")
  elseif word == "off" then
    UW_GuildCharDB.isBank = nil
    UW_GuildDB.bank[me()] = nil
    ns.say("This character is no longer the guild bank, and its counts were removed.")
  else
    local progress = UW_GuildDB.gmAccount == true and ns.BankProgress()
    if progress then ns.say("Guild bank vault, toward tab 1: " .. progress) end
    local e = UW_GuildDB.bank[me()]
    if not isBank() then
      ns.say("This character isn't the guild bank. On the guild's bank character, type /uw bank on.")
    else
      local n = 0
      for _ in pairs(e and e.bank or {}) do n = n + 1 end
      ns.say(("Guild bank: %s. %d kinds of item counted in the bank%s."):format(me(), n,
        e and e.bankAt and "" or " (open the bank once)"))
    end
  end
end
