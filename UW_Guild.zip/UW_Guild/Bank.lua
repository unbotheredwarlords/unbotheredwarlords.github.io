-- Guild bank snapshot for crafting recommendations: what materials the guild has on hand.
-- Forever has no confirmed guild vault (beta reports only), so the guild bank is a character an officer flags with
-- /uw bank on: its bags are counted whenever they change and its bank whenever the bank window is open. If Forever
-- does have a guild vault, each tab is counted while someone with UW_Guild views it. Personal characters are never
-- read. Counts only (item id -> count), in UW_GuildDB.bank[name] and UW_GuildDB.vault; the bot reads them from the
-- guild master's save.
local _, ns = ...

local BANK_CONTAINER = BANK_CONTAINER or -1
local BAGS = NUM_BAG_SLOTS or 4
local BANK_BAGS = NUM_BANKBAGSLOTS or 6
local VAULT_SLOTS = MAX_GUILDBANK_SLOTS_PER_TAB or 98

local function isBank() return UW_GuildCharDB and UW_GuildCharDB.isBank end
local function me() return ns.shortName(ns.me() or UnitName("player")) end

-- Item id and count in one slot, on the modern C_Container API or the legacy one.
local function slotItem(bag, slot)
  if C_Container and C_Container.GetContainerItemInfo then
    local info = C_Container.GetContainerItemInfo(bag, slot)
    if type(info) == "table" then return info.itemID, info.stackCount end
    return nil
  end
  if GetContainerItemInfo then
    local _, count, _, _, _, _, link, _, _, id = GetContainerItemInfo(bag, slot)
    id = id or (type(link) == "string" and tonumber(link:match("item:(%d+)")))
    return id, count
  end
end

local function numSlots(bag)
  local f = (C_Container and C_Container.GetContainerNumSlots) or GetContainerNumSlots
  return f and tonumber(f(bag)) or 0
end

-- { [itemID] = count } over the given bag ids.
function ns.CountBags(bags)
  local out = {}
  for _, bag in ipairs(bags) do
    for slot = 1, numSlots(bag) do
      local id, count = slotItem(bag, slot)
      if type(id) == "number" and type(count) == "number" and not ns.isSecret(id) and not ns.isSecret(count) then
        out[id] = (out[id] or 0) + count
      end
    end
  end
  return out
end

local function carried()
  local bags = {}
  for b = 0, BAGS do bags[#bags + 1] = b end
  return bags
end

local function bankBags()
  local bags = { BANK_CONTAINER }
  for b = BAGS + 1, BAGS + BANK_BAGS do bags[#bags + 1] = b end
  return bags
end

local bankOpen = false
local function entry()
  local db = UW_GuildDB.bank
  db[me()] = db[me()] or { bags = {}, bank = {} }
  return db[me()]
end

local function snapshot(withBank)
  if not isBank() or not ns.tracksGuild() then return end
  local e = entry()
  e.bags, e.at = ns.CountBags(carried()), time()
  if withBank then e.bank, e.bankAt = ns.CountBags(bankBags()), time() end
end
ns.BankSnapshot = snapshot

-- Guild vault (only if Forever has one): the tab on screen, after the server sends it.
local function vaultTab()
  if not (GetCurrentGuildBankTab and GetGuildBankItemLink and GetGuildBankItemInfo) or not ns.tracksGuild() then return end
  local tab = GetCurrentGuildBankTab()
  if type(tab) ~= "number" then return end
  local items = {}
  for slot = 1, VAULT_SLOTS do
    local link = GetGuildBankItemLink(tab, slot)
    local _, count = GetGuildBankItemInfo(tab, slot)
    local id = type(link) == "string" and not ns.isSecret(link) and tonumber(link:match("item:(%d+)"))
    if id and type(count) == "number" and not ns.isSecret(count) then items[id] = (items[id] or 0) + count end
  end
  local v = UW_GuildDB.vault
  v.tabs = v.tabs or {}
  v.tabs[tab] = { at = time(), items = items }
  v.at = time()
end
ns.VaultTab = vaultTab

local pending = {}
local function soon(kind, fn)
  if pending[kind] then return end
  pending[kind] = true
  C_Timer.After(2, function()
    pending[kind] = nil
    local ok, err = pcall(fn)
    if not ok then ns.say("Couldn't count the guild bank (" .. tostring(err) .. ").") end
  end)
end

table.insert(ns.onLoad, function()
  UW_GuildDB.bank = UW_GuildDB.bank or {}
  UW_GuildDB.vault = UW_GuildDB.vault or {}
  UW_GuildCharDB = UW_GuildCharDB or {}
end)

local f = CreateFrame("Frame")
ns.listen(f, { "BAG_UPDATE_DELAYED", "BANKFRAME_OPENED", "BANKFRAME_CLOSED", "PLAYERBANKSLOTS_CHANGED",
  "GUILDBANKFRAME_OPENED", "GUILDBANKBAGSLOTS_CHANGED" })
f:SetScript("OnEvent", function(_, event)
  if not UW_GuildDB or not UW_GuildDB.bank then return end
  if event == "BANKFRAME_OPENED" then
    bankOpen = true
    soon("bank", function() snapshot(true) end)
  elseif event == "BANKFRAME_CLOSED" then
    bankOpen = false
  elseif event == "BAG_UPDATE_DELAYED" or event == "PLAYERBANKSLOTS_CHANGED" then
    soon("bags", function() snapshot(bankOpen) end)
  elseif event == "GUILDBANKFRAME_OPENED" then
    if QueryGuildBankTab and GetNumGuildBankTabs then
      for tab = 1, GetNumGuildBankTabs() or 0 do QueryGuildBankTab(tab) end
    end
  elseif event == "GUILDBANKBAGSLOTS_CHANGED" then
    soon("vault", vaultTab)
  end
end)

ns.commands.bank = function(args)
  local word = strtrim(args or ""):lower()
  if word == "on" then
    if not ns.tracksGuild() then ns.say("This character isn't in the guild UW_Guild tracks.") return end
    UW_GuildCharDB.isBank = true
    snapshot(bankOpen)
    ns.say("This character is now the guild bank. Open its bank once so those slots count too. Only item counts are "
      .. "saved. /uw bank off undoes this.")
  elseif word == "off" then
    UW_GuildCharDB.isBank = nil
    UW_GuildDB.bank[me()] = nil
    ns.say("This character is no longer the guild bank, and its counts were removed.")
  else
    local e = UW_GuildDB.bank[me()]
    if not isBank() then
      ns.say("This character isn't the guild bank. On the guild's bank character, type /uw bank on.")
    else
      local n = 0
      for _ in pairs(e and e.bank or {}) do n = n + 1 end
      ns.say(("Guild bank: %s. %d kinds of item counted in the bank%s."):format(me(), n,
        e and e.bankAt and "" or " (open the bank once)"))
    end
  end
end
