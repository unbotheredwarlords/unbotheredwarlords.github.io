-- Make room for better loot (Louis, 5 Nov 2026: "does the addon evaluate the suggest loot removal when picking up
-- more valuable stuff?").
--
-- Bags full and the loot window holds something that won't fit: a button under the loot window offers to drop the
-- cheapest piece of junk in the bags, but only when that junk is worth less than the loot. One click deletes it and
-- picks up the loot.
--   * Worth = the higher of the vendor price and Auctionator's last scanned price (when Auctionator is installed),
--     times the stack. A quest item in the loot always counts as worth more. So does a crafting material (meat, cloth,
--     herbs, hides), unless Auctionator prices the junk higher (Louis, 5 Nov: leg meat on a druid with full bags got no
--     offer: a grey sells for more than meat at a vendor, but junk is for selling and mats are kept on purpose).
--   * Only greys, and plain white weapons and armour, are ever offered. Never a quest item, a locked item, a shirt,
--     tabard, bag, ammo or a profession tool (pick, hammer, knife, fishing pole), never a piece in an equipment set.
--     Crafting materials, food and water are never offered: they're white too, but people keep them on purpose.
--   * Nothing happens without the click, and never in combat (same as EnhanceQoL's loot junk button). When that button
--     is on, it's the one shown: one button, never two.
--   * The bag window gets a "Delete" button for that same cheapest junk, bags full or not (Louis, 5 Nov: "add a delete
--     lowest value item button to inventory bag management interface"). It sits above the top left of EllesmereUI's bags, EnhanceQoL's,
--     Baganator's or the game's own, whichever is open, and its tooltip names the item and its worth.
--   * Left behind (Louis, 5 Nov: "delete loot that is lower value than anything in inventory when grey or white
--     (materials excluded for crafting ofc)"): bags full, and everything left in the loot window is a grey or plain
--     white weapon or armour worth no more than the cheapest thing in the bags: the loot window closes and one line
--     names what stayed on the corpse. Never a material, food, quest item, locked (rolled) item, anything Auctionator
--     prices higher, or a piece that could be an upgrade.
--   * /uw bags off hides both buttons and leaves all loot alone.
local _, ns = ...
-- WoW reads the TOC only at start-up: after a /reload into this version, Items.lua (new) isn't loaded yet. Stay off
-- until a full restart; SelfTest.lua tells the player once.
if not ns.KeepReason then return end
local say = ns.say

local function g(name) return rawget(_G, name) end
local function call(fn, ...)
  if type(fn) ~= "function" then return nil end
  local ok, a, b, c, d, e, f, h, i, j, k, l, m, n, o = pcall(fn, ...)
  if ok then return a, b, c, d, e, f, h, i, j, k, l, m, n, o end
end
local function cnt() return g("C_Container") or {} end
local function on() return UW_GuildDB and UW_GuildDB.bagRoom ~= false end

-- The item rules are shared (Items.lua): worth, what counts as junk, and why something must stay.
local info, unitValue = ns.ItemInfo, ns.ItemWorth

local function money(c)
  local currency = g("C_CurrencyInfo")
  local fmt = g("GetCoinTextureString") or (currency and currency.GetCoinTextureString)
  return call(fmt, c) or (c .. "c")
end

-- Free general slots, and bag item stacks by item ID (to see whether loot stacks onto them).
local function bagState()
  local free, stacks = 0, {}
  for bag = 0, NUM_BAG_SLOTS or 4 do
    local n, family = call(cnt().GetContainerNumFreeSlots, bag)
    if family == 0 then free = free + (n or 0) end
    for slot = 1, (call(cnt().GetContainerNumSlots, bag) or 0) do
      local c = call(cnt().GetContainerItemInfo, bag, slot)
      if c and c.itemID then
        stacks[c.itemID] = stacks[c.itemID] or {}
        table.insert(stacks[c.itemID], c.stackCount or 1)
      end
    end
  end
  return free, stacks
end

-- The cheapest junk in the bags: { bag, slot, id, link, count, value }, or nil.
function ns.CheapestJunk()
  local sets, best = ns.EquipmentSetItems(), nil
  for bag = 0, NUM_BAG_SLOTS or 4 do
    for slot = 1, (call(cnt().GetContainerNumSlots, bag) or 0) do
      local c = call(cnt().GetContainerItemInfo, bag, slot)
      local it = c and c.itemID and not c.isLocked and c.hyperlink and info(c.hyperlink)
      local junk = it and ns.IsJunkKind(it)
        and not ns.KeepReason({ id = c.itemID, link = c.hyperlink, bag = bag, slot = slot }, it, false, sets)
      if junk then
        local count = c.stackCount or 1
        local each, fromAH = unitValue(c.hyperlink, it)
        local value = each * count
        if not best or value < best.value then
          best = { bag = bag, slot = slot, id = c.itemID, link = c.hyperlink, count = count, value = value, ah = fromAH }
        end
      end
    end
  end
  return best
end

local TRADE_GOODS = ns.ITEM_TRADE_GOODS
-- The most valuable loot that won't fit: { slot, link, value, ah, quest, mat }, or nil; then the most valuable
-- crafting material that won't fit.
function ns.LootThatWontFit()
  local free, stacks = bagState()
  if free > 0 then return nil end
  local best, bestMat
  for i = 1, (call(g("GetNumLootItems")) or 0) do
    local link = call(g("GetLootSlotLink"), i)
    local _, _, quantity, _, _, locked, isQuest = call(g("GetLootSlotInfo"), i)
    local it = link and not locked and info(link)
    if it then
      quantity = quantity or 1
      local id = tonumber(link:match("item:(%d+)"))
      local stacksOn = false
      for _, n in ipairs(id and stacks[id] or {}) do
        if n + quantity <= it.stackMax then stacksOn = true end
      end
      if not stacksOn then
        local each, fromAH = unitValue(link, it)
        local value = isQuest and math.huge or each * quantity
        local mat = not isQuest and it.classID == TRADE_GOODS
        local entry = { slot = i, link = link, value = value, ah = fromAH, quest = isQuest, mat = mat }
        if not best or value > best.value then best = entry end
        if mat and (not bestMat or value > bestMat.value) then bestMat = entry end
      end
    end
  end
  return best, bestMat
end

-- The cheapest thing of any kind in the bags that sells for something (its worth, times the stack), or nil.
local function cheapestAnything()
  local best
  for bag = 0, NUM_BAG_SLOTS or 4 do
    for slot = 1, (call(cnt().GetContainerNumSlots, bag) or 0) do
      local c = call(cnt().GetContainerItemInfo, bag, slot)
      local it = c and c.hyperlink and info(c.hyperlink)
      if it then
        local value = unitValue(c.hyperlink, it) * (c.stackCount or 1)
        if value > 0 and (not best or value < best) then best = value end
      end
    end
  end
  return best
end

-- Loot that isn't worth the room: bags full, grey or plain white gear, worth no more than the cheapest thing in the
-- bags (Louis: "lower value than anything in inventory"; integrator finding 38: not merely the cheapest junk, which
-- may not exist), never a quest item or a possible upgrade. A list of { slot, link, value }, and
-- whether that's everything left in the loot window.
function ns.LootToLeave()
  local free, stacks = bagState()
  if free > 0 then return {}, false end
  local floor = cheapestAnything()
  if not floor then return {}, false end
  local out, all = {}, true
  for i = 1, (call(g("GetNumLootItems")) or 0) do
    local link = call(g("GetLootSlotLink"), i)
    if link then
      local _, _, quantity, _, _, locked, isQuest = call(g("GetLootSlotInfo"), i)
      local it = info(link)
      local id = tonumber(link:match("item:(%d+)"))
      local fits = false
      for _, n in ipairs(id and stacks[id] or {}) do
        if it and n + (quantity or 1) <= it.stackMax then fits = true end
      end
      local each = it and unitValue(link, it) or 0
      local value = each * (quantity or 1)
      local leave = it and not locked and not fits and ns.IsJunkKind(it) and value <= floor
        and not ns.KeepReason({ id = id, link = link }, it, isQuest)
      if leave then out[#out + 1] = { slot = i, link = link, value = value } else all = false end
    elseif call(g("GetLootSlotInfo"), i) ~= nil then
      all = false -- coins or currency still there (an empty slot has no icon): never closed on them
    end
  end
  return out, all and #out > 0
end


-- EnhanceQoL's own loot junk button is on: that one's shown instead.
local function eqolButton()
  local e = g("EnhanceQoL")
  return type(e) == "table" and type(e.db) == "table" and e.db.vendorLootJunkButton == true
end

local button, offer, lootOpen, pendingLoot
local function hide() if button then button:Hide() end offer = nil end

local leaveAt -- GetTime() of the loot window's opening, to let auto loot take what fits first
local function leaveJunkLoot()
  if not (lootOpen and on()) then return end
  local list, all = ns.LootToLeave()
  if not all then return end
  local names = {}
  for _, l in ipairs(list) do names[#names + 1] = l.link end
  call(g("CloseLoot"))
  say(("Left %s: worth less than anything in your full bags. /uw bags off keeps all loot."):format(
    table.concat(names, ", ")))
end
ns.LeaveJunkLoot = leaveJunkLoot

local function build()
  if button then return button end
  local parent = g("LootFrame")
  if not parent then return nil end
  button = CreateFrame("Button", "UW_GuildBagRoomButton", parent, "UIPanelButtonTemplate")
  button:SetSize(220, 24)
  button:SetPoint("TOP", parent, "BOTTOM", 0, -4)
  button:SetScript("OnClick", function() ns.protect(ns.BagRoomClick, call(g("IsShiftKeyDown")) == true) end)
  button:SetScript("OnEnter", function(self)
    local tip = g("GameTooltip")
    if not (tip and offer) then return end
    tip:SetOwner(self, "ANCHOR_RIGHT")
    tip:SetText("Make room")
    tip:AddLine(("Drop %s (%s)"):format(offer.junk.link, money(offer.junk.value)), 1, 1, 1)
    tip:AddLine(("for %s (%s%s)"):format(offer.loot.link, offer.loot.quest and "quest item"
      or offer.loot.mat and offer.junk.value >= offer.loot.value and "crafting material" or money(offer.loot.value),
      offer.loot.ah and ", Auctionator" or ""), 1, 1, 1)
    tip:AddLine("Shift-click: keep it, never offer it again. /uw bags off hides this.", 0.6, 0.6, 0.6, true)
    tip:Show()
  end)
  button:SetScript("OnLeave", function() local tip = g("GameTooltip"); if tip then tip:Hide() end end)
  ns.Skin("Button", button)
  return button
end

function ns.BagRoomRefresh()
  if not (lootOpen and on()) or eqolButton() or InCombatLockdown() then hide() return end
  local loot, mat = ns.LootThatWontFit()
  local junk = loot and ns.CheapestJunk()
  -- The most valuable loot when it's worth more than the junk; otherwise a crafting material, which beats junk priced
  -- only by a vendor (Auctionator's price for the junk still decides).
  if junk and junk.value >= loot.value then loot = mat and not junk.ah and mat or nil end
  if not (junk and loot) or not build() then hide() return end
  offer = { loot = loot, junk = junk }
  button:SetText(("Make room: drop %s"):format(junk.link))
  button:Show()
end

-- Deletes exactly the junk that was shown (re-found first, so a bag change in between deletes nothing). true when
-- it went. Only from a button's click: never from an event or a timer.
local function dropJunk(was)
  if not was or InCombatLockdown() or call(g("GetCursorInfo")) ~= nil then return false end
  local now = ns.CheapestJunk()
  if not now or now.bag ~= was.bag or now.slot ~= was.slot or now.link ~= was.link or now.count ~= was.count then
    return false
  end
  call(cnt().PickupContainerItem, was.bag, was.slot)
  local kind, id = call(g("GetCursorInfo"))
  if kind ~= "item" or id ~= was.id then call(g("ClearCursor")) return false end
  call(g("DeleteCursorItem"))
  if call(g("CursorHasItem")) then
    call(g("ClearCursor"))
    say("Couldn't delete it. Nothing was deleted.")
    return false
  end
  say(("Deleted %s%s (%s)."):format(was.link, was.count > 1 and (" x" .. was.count) or "", money(was.value)))
  return true
end

-- Shift-click: keep this item from now on (Delete, Make room and Left behind skip it; /uw bags forget clears the list).
local function keepJunk(was)
  if not was then return end
  UW_GuildCharDB.keepItems = type(UW_GuildCharDB.keepItems) == "table" and UW_GuildCharDB.keepItems or {}
  UW_GuildCharDB.keepItems[was.id] = true
  say(("Kept %s: Delete skips it from now on. /uw bags forget clears your kept items."):format(was.link))
end

-- Deleting can't be bought back: junk worth 1 gold or more asks first (as Scrap and Dejunk do for selling).
local function confirmDrop(was, after)
  if not was then return end
  if was.value < ns.DELETE_ASK_COPPER or not ns.KitConfirm then
    after(dropJunk(was))
    return
  end
  ns.KitConfirm(("Delete %s%s? It's worth %s and can't be bought back."):format(was.link,
    was.count > 1 and (" x" .. was.count) or "", money(was.value)),
    function() ns.protect(function() after(dropJunk(was)) end) end, function() end, "UW_GUILD_DELETE")
end

-- Loot window: the junk goes, then the loot is picked up once the space shows.
function ns.BagRoomClick(shift)
  if not offer then return end
  if shift then keepJunk(offer.junk) ns.BagRoomRefresh() return end
  local slot = offer.loot.slot
  confirmDrop(offer.junk, function(ok) if ok then pendingLoot = slot hide() else ns.BagRoomRefresh() end end)
end

-- Bag window -------------------------------------------------------------------------------------------------------
-- The first of these that exists is the bag window (EllesmereUI, EnhanceQoL, Baganator, the game's combined bags,
-- then the game's backpack).
local HOSTS = { "EUI_MainBagFrame", "BagsMainFrame", "Baganator_SingleViewBackpackViewFrame",
  "Baganator_CategoryViewBackpackViewFrame", "ContainerFrameCombinedBags", "ContainerFrame1" }
local bagButtons, bagJunk = {}, nil

local function refreshBagButtons()
  bagJunk = on() and not InCombatLockdown() and ns.CheapestJunk() or nil
  for host, b in pairs(bagButtons) do
    local show = bagJunk and call(host.IsShown, host)
    if show then
      b:SetText(("Delete %s"):format(bagJunk.link))
      local fs = call(b.GetFontString, b)
      local w = fs and tonumber(call(fs.GetStringWidth, fs)) or 120
      b:SetWidth(math.min(math.max(w + 24, 120), 280))
      b:Show()
    else
      b:Hide()
    end
  end
end
ns.BagDeleteRefresh = refreshBagButtons

local function bagButton(host)
  if bagButtons[host] then return end
  local b = CreateFrame("Button", nil, host, "UIPanelButtonTemplate")
  b:SetSize(160, 22)
  b:SetPoint("BOTTOMLEFT", host, "TOPLEFT", 0, 2) -- left: clear of the close button (Louis, 5 Nov)
  b:SetFrameStrata("HIGH")
  b:SetScript("OnClick", function()
    ns.protect(function()
      if call(g("IsShiftKeyDown")) == true then keepJunk(bagJunk) refreshBagButtons() return end
      confirmDrop(bagJunk, function() refreshBagButtons() end)
    end)
  end)
  b:SetScript("OnEnter", function(self)
    local tip = g("GameTooltip")
    if not (tip and bagJunk) then return end
    tip:SetOwner(self, "ANCHOR_TOP")
    tip:SetText("Delete your cheapest junk")
    tip:AddLine(("%s%s: %s"):format(bagJunk.link, bagJunk.count > 1 and (" x" .. bagJunk.count) or "",
      money(bagJunk.value)), 1, 1, 1)
    tip:AddLine("Greys and plain white gear only, priced by vendor or Auctionator. Never quest items, tools, "
      .. "equipment sets, upgrades or EnhanceQoL's never-sell list.", 0.6, 0.6, 0.6, true)
    tip:AddLine("Shift-click: keep it instead. /uw bags off hides this.", 0.6, 0.6, 0.6, true)
    tip:Show()
  end)
  b:SetScript("OnLeave", function() local tip = g("GameTooltip"); if tip then tip:Hide() end end)
  ns.Skin("Button", b)
  bagButtons[host] = b
  if type(host.HookScript) == "function" then
    host:HookScript("OnShow", function() ns.protect(refreshBagButtons) end)
  end
end

local function findHosts()
  for _, name in ipairs(HOSTS) do
    local host = g(name)
    if type(host) == "table" and type(host.IsShown) == "function" then bagButton(host) end
  end
end

ns.commands.bags = function(args)
  local sub = strtrim(args or ""):lower()
  if sub == "forget" then
    UW_GuildCharDB.keepItems = nil
    say("Kept items cleared: Delete may offer them again.")
    refreshBagButtons()
    return
  end
  if sub == "off" then
    UW_GuildDB.bagRoom = false
    hide()
    refreshBagButtons()
    say("Bag buttons are off. /uw bags on brings them back.")
  else
    UW_GuildDB.bagRoom = nil
    say("Bag buttons are on: Delete for your cheapest junk, and Make room on the loot window when bags are full.")
    ns.BagRoomRefresh()
    refreshBagButtons()
  end
end

local f = CreateFrame("Frame")
ns.listen(f, { "PLAYER_ENTERING_WORLD", "LOOT_OPENED", "LOOT_CLOSED", "LOOT_SLOT_CLEARED", "BAG_UPDATE_DELAYED",
  "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED" })
f:SetScript("OnEvent", function(_, event)
  if event == "PLAYER_ENTERING_WORLD" then
    -- Bag addons build their windows at login; look once they have.
    C_Timer.After(3, function() ns.protect(findHosts); ns.protect(refreshBagButtons) end)
    return
  end
  if event == "LOOT_OPENED" then
    lootOpen = true
    leaveAt = GetTime()
    -- After auto loot has taken what fits.
    C_Timer.After(0.5, function() if lootOpen and leaveAt then ns.protect(leaveJunkLoot) end end)
  elseif event == "LOOT_CLOSED" then lootOpen, pendingLoot, leaveAt = false, nil, nil end
  if event == "BAG_UPDATE_DELAYED" and pendingLoot and lootOpen then
    local slot = pendingLoot
    pendingLoot = nil
    ns.protect(g("LootSlot"), slot)
  end
  ns.protect(ns.BagRoomRefresh)
  if event ~= "LOOT_SLOT_CLEARED" then ns.protect(refreshBagButtons) end
end)
