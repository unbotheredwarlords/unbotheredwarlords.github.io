-- Week one (Louis, 8 Nov 2026): help every new guildmate play with guildmates in their first week, and measure it.
-- Newcomers who never group drift off: playing alongside others isn't playing with them (Ducheneaut, Yee, Nickell &
-- Moore 2006), and early contact from existing members is what keeps newcomers (Kraut & Resnick 2012). Discord's LFG
-- went unused, and on 8 Nov 3 of 150 guildmates ran UW_Guild, so this reads the guild roster, which every client has.
--   * Measure, counts only. An officer's or welcome buddy's client reads the roster once per 15-minute slot. Two or
--     more guildmates online in one dungeon or raid count as grouped (an instance holds one group; two guild groups in
--     one dungeon at once are rare at our size, so it can overcount a little). The helper's own group counts too, and
--     so does a newcomer's own UW_Guild report (GRP, Onboarding.lua).
--   * Names stay on this PC only until the newcomer's day 8, to keep the grouped off /uw new. Then the newcomer is
--     added to their join day's counts and the name goes. The bot reads counts only (bot/uwbot/weekone.py).
--   * Act through people. /uw new lists newcomers online now with no guild group seen yet, each with their buddy and
--     up to two online guildmates near their level, so an officer or buddy can invite them. It never contacts the
--     newcomer. At login, helpers get one line saying how many are waiting (/uw new off stops it).
-- UW_GuildDB.weekOne = { slot, through, off, seen = { [name] = time }, dungeon = { [name] = time },
--   inst = { [zone] = true }, cover = { ["YYYYMMDD"] = samples },
--   days = { ["YYYYMMDD"] = { n, g3, g7, s3, s0, q, a, a3, ab3, p3n, v, d7, e, ed7, na, da, vl, nl, dl, nx, dx } },
--   live = { at, new, grouped, quiet, waiting, addon, dungeon, eligible, edungeon } }
-- First dungeon (Louis, 8 Nov 23:22: priority 1; definition in project file journeys/first-dungeon-metric.md):
-- "dungeon" holds only instance-zone reads, plus the helper's own group while the helper is inside an instance.
-- "seen" stays any guild group. A join day made by this version carries v = 2 and starts its first-dungeon fields at 0,
-- so the bot reads an older day's missing fields as missing, never as 0; vl = 1 likewise when the Discord split
-- (ns.LINKED from the bot's Schedule.lua) was known.
local _, ns = ...
local say = ns.say

local DAY, SLOT = 86400, 900
ns.WEEK1_DAYS = 7         -- a newcomer's first week
ns.WEEK1_FINAL_DAYS = 8   -- counted once day 7 is over, so "still playing on day 7" can be read
ns.WEEK1_GROUP_DAYS = 3   -- the playbook goal: grouped with guildmates within 72 hours
ns.WEEK1_QUIET_DAYS = 2   -- not seen for this long with no group yet: going quiet
ns.WEEK1_NEAR = 3         -- levels either side for "near them"
ns.WEEK1_KEEP_DAYS = 120  -- join-day counts kept this long
ns.WEEK1_SHOW = 8         -- house style: lists of 8 lines at most
ns.WEEK1_INST_MAX = 80    -- learned instance names kept
ns.WEEK1_DUNGEON_LEVEL = 13 -- Ragefire Chasm, the lowest dungeon: "eligible" for a first dungeon
ns.WEEK1_COVER_DAYS = 60  -- helper samples per day kept (coverage, so more helpers isn't read as more dungeons)
-- Dungeons and raids as the roster names them. A zone a helper's own client enters as a party or raid instance is
-- learned too (weekOne.inst), so a dungeon Forever adds or renames counts without an update.
ns.INSTANCE_ZONES = {}
for _, z in ipairs({ "Ragefire Chasm", "Wailing Caverns", "The Deadmines", "Shadowfang Keep", "Blackfathom Deeps",
  "The Stockade", "Gnomeregan", "Razorfen Kraul", "Scarlet Monastery", "Razorfen Downs", "Uldaman", "Zul'Farrak",
  "Maraudon", "The Temple of Atal'Hakkar", "Sunken Temple", "Blackrock Depths", "Blackrock Spire", "Dire Maul",
  "Stratholme", "Scholomance", "Molten Core", "Onyxia's Lair", "Blackwing Lair", "Zul'Gurub", "Ruins of Ahn'Qiraj",
  "Ahn'Qiraj", "Temple of Ahn'Qiraj", "Naxxramas", "Hyjal Summit", "Barrow Deeps" }) do
  ns.INSTANCE_ZONES[z] = true
end

local function store()
  local w = UW_GuildDB.weekOne
  if type(w) ~= "table" then w = {}; UW_GuildDB.weekOne = w end
  for _, k in ipairs({ "seen", "dungeon", "days", "inst", "nights", "cover", "on" }) do if type(w[k]) ~= "table" then w[k] = {} end end
  return w
end

local function members() return type(UW_GuildDB.members) == "table" and UW_GuildDB.members or {} end

-- Officers, and members whose public guild note names the Welcome buddy job (Onboarding.lua ns.JOBS).
function ns.WeekOneHelper()
  local full = ns.me()
  if not full then return false end
  if ns.isOfficer(full) then return true end
  local m = members()[ns.shortName(full)]
  if type(m) ~= "table" or not ns.NoteJobs then return false end
  for _, k in ipairs(ns.NoteJobs(m.note)) do if k == "buddy" then return true end end
  return false
end

-- When a newcomer joined, for week one. The roster first sees a joiner only while some UW_Guild client plays, so
-- m.first is the next login after the join: a joiner while nobody was on would get a later join day and a 7-day window
-- that starts after a first dungeon nobody saw (D7 readout check, 9 Nov). The guild event log's invite dates it
-- better (Onboarding.lua, UW_GuildDB.invites; recruiters.py credits the same one): the latest invite at or before the
-- roster's first sight, with an hour's slack as the log says "N hours ago", from up to WEEK1_JOIN_LOOKBACK days before.
-- Otherwise m.first. A rejoin keeps its old m.first and has no invite before it, so it stays out as before.
-- An invite at or before m.w1prior is never the one they joined on: m.w1prior is the last full helper read before the
-- roster first saw them (WeekOneSample stamps it once), and they weren't in the guild then. Such an invite is an older
-- one they declined; dated by it, they could fall before weekOne.through and never be counted (red team, #534 LOW).
-- The log's "N hours ago" only ever makes an invite look later than it was, so a real one is never refused this way.
ns.WEEK1_JOIN_LOOKBACK = 14
local function joined(name, m)
  local first = type(m) == "table" and ns.finite(m.first)
  if not first then return nil end
  local list, best = type(UW_GuildDB.invites) == "table" and UW_GuildDB.invites[name], nil
  local floor = math.max(ns.finite(m.w1prior) or 0, first - ns.WEEK1_JOIN_LOOKBACK * DAY)
  for _, e in ipairs(type(list) == "table" and list or {}) do
    local at = type(e) == "table" and ns.finite(e.at)
    if at and at <= first + 3600 and at > floor and (not best or at > best) then
      best = at
    end
  end
  return best and math.min(best, first) or first
end
ns.WeekOneJoined = joined

-- A guildmate in their first `days` days who joined after this account's addon started (ns.isRecruit) or holds Trial.
-- A guildmate the addon hasn't recorded yet (a join a moment ago, grouped before the next roster read) is no newcomer
-- yet: m is nil (Louis's log, 8 Nov: "attempt to index local 'm'" when El Bonacho joined his group).
local function newcomer(name, m, now, days)
  local first = joined(name, m)
  if not first then return false end
  return not m.left and now - first < (days or ns.WEEK1_DAYS) * DAY and ns.isRecruit(name)
end

-- Earliest group with a guildmate seen for this member: their own UW_Guild's report or this client's.
local function groupedAt(w, name, m)
  local a, b = ns.finite(m.firstGroup), ns.finite(w.seen[name])
  if a and b then return math.min(a, b) end
  return a or b
end

local function mark(w, name, now)
  if not name or w.seen[name] then return end
  if newcomer(name, members()[name], now, ns.WEEK1_FINAL_DAYS) then w.seen[name] = now end
end

-- A dungeon with a guildmate, for the first-dungeon count: instance-zone reads only.
local function markDungeon(w, name, now)
  if not name or w.dungeon[name] then return end
  if newcomer(name, members()[name], now, ns.WEEK1_FINAL_DAYS) then w.dungeon[name] = now end
end

-- Characters linked in Discord (the bot writes ns.LINKED into Schedule.lua on the Guild Master's PC; never shared).
-- nil when this client has no list: then the Discord split isn't counted at all.
local function linkedSet()
  if type(ns.LINKED) ~= "table" then return nil end
  local out = {}
  for _, n in ipairs(ns.LINKED) do
    if type(n) == "string" then out[(n:lower():gsub("[%s%-]+", " "))] = true end
  end
  return out
end

local function isInstance(w, zone) return zone ~= nil and (ns.INSTANCE_ZONES[zone] or w.inst[zone]) and true or false end
-- The same test for other files (Lead.lua's suggested call and helpers), learned zones included.
function ns.IsInstanceZone(zone)
  local w = type(UW_GuildDB) == "table" and type(UW_GuildDB.weekOne) == "table" and UW_GuildDB.weekOne or nil
  return type(zone) == "string" and (ns.INSTANCE_ZONES[zone] or (w and type(w.inst) == "table" and w.inst[zone]))
    and true or false
end

local function inc(d, k) d[k] = (tonumber(d[k]) or 0) + 1 end

-- Adds one newcomer to their join day's counts: n joined; g3/g7 grouped within 3/7 days; s3/s0 still playing on day 7
-- having grouped within 3 days or not; q gone by day 7 without ever grouping.
-- Calibration, so the guild-wide rate can be corrected as more members run UW_Guild: a runs it; a3 of those reported
-- their own group within 3 days (GRP: the truth for them); ab3 of a3 the roster also caught; p3n newcomers without
-- UW_Guild the roster caught within 3 days. The bot divides p3n by the roster's hit rate ab3/a3 (weekone.py).
-- First dungeon: d7 in a dungeon with a guildmate within 7 days; e level 13+ when counted (day 8, so a day late at
-- most); ed7 both. Exclusive segments: a (UW_Guild since joining), l (linked in Discord, not a), x (neither); n? joined
-- and d? of them with d7.
local function count(w, name, m, first, linked)
  local key = date("!%Y%m%d", first)
  local d = w.days[key]
  if type(d) ~= "table" then
    d = { v = 2, d7 = 0, e = 0, ed7 = 0, na = 0, da = 0 }
    if linked then d.vl, d.nl, d.dl, d.nx, d.dx = 1, 0, 0, 0, 0 end
    w.days[key] = d
  end
  local g = groupedAt(w, name, m)
  local g3 = g ~= nil and g - first <= ns.WEEK1_GROUP_DAYS * DAY
  local g7 = g ~= nil and g - first <= ns.WEEK1_DAYS * DAY
  local left = ns.finite(m.left)
  local stayed = (ns.finite(m.seen) or 0) >= first + ns.WEEK1_DAYS * DAY
    and not (left and left < first + ns.WEEK1_DAYS * DAY)
  inc(d, "n")
  if g3 then inc(d, "g3") end
  if g7 then inc(d, "g7") end
  if stayed then inc(d, g3 and "s3" or "s0") end
  if not g7 and not stayed then inc(d, "q") end
  local own, seen = ns.finite(m.firstGroup), ns.finite(w.seen[name])
  local seen3 = seen ~= nil and seen - first <= ns.WEEK1_GROUP_DAYS * DAY
  if ns.finite(m.addon) then
    inc(d, "a")
    if own and own - first <= ns.WEEK1_GROUP_DAYS * DAY then
      inc(d, "a3")
      if seen3 then inc(d, "ab3") end
    end
  elseif seen3 then
    inc(d, "p3n")
  end
  if d.v ~= 2 then return end -- a day an older version started: its first-dungeon fields stay missing
  local dg = ns.finite(w.dungeon[name])
  local d7 = dg ~= nil and dg - first <= ns.WEEK1_DAYS * DAY
  local e = (ns.finite(m.lvl) or 0) >= ns.WEEK1_DUNGEON_LEVEL
  if d7 then inc(d, "d7") end
  if e then inc(d, "e") end
  if e and d7 then inc(d, "ed7") end
  local seg
  if (ns.finite(m.addon) or 0) >= first then seg = "a"
  elseif d.vl == 1 and linked then
    local k = (name:lower():gsub("[%s%-]+", " ")) -- as the bot's text.name_key; a bare first-name link counts too
    seg = (linked[k] or linked[k:match("^%S+") or k]) and "l" or "x"
  end
  if seg then
    inc(d, "n" .. seg)
    if d7 then inc(d, "d" .. seg) end
  end
end

-- Newcomers whose day 8 has passed go into the counts once. Only joins after this client started measuring count
-- (w.through starts then): earlier ones were never watched, so they would look like nobody grouped.
local function finalize(w, now)
  local through = ns.finite(w.through)
  if not through then w.through = now return end
  local cutoff = now - ns.WEEK1_FINAL_DAYS * DAY
  if cutoff <= through then return end
  local linked = linkedSet()
  for name, m in pairs(members()) do
    local first = joined(name, m)
    if first and first > through and first <= cutoff and ns.isRecruit(name) then count(w, name, m, first, linked) end
  end
  w.through = cutoff
  for _, t in ipairs({ w.seen, w.dungeon }) do
    for name in pairs(t) do
      local first = joined(name, members()[name])
      if not first or first <= cutoff then t[name] = nil end -- counted (or gone): the name isn't needed any more
    end
  end
  local oldest = date("!%Y%m%d", now - ns.WEEK1_KEEP_DAYS * DAY)
  for k in pairs(w.days) do if type(k) ~= "string" or k < oldest then w.days[k] = nil end end
end

-- This week so far, counts only: newcomers, how many grouped, how many went quiet first, how many are online solo,
-- and the first-dungeon count. Only joins after measuring began (w.through): earlier ones were never watched.
local function live(w, online, now)
  local out = { at = now, new = 0, grouped = 0, quiet = 0, waiting = 0, addon = 0, dungeon = 0, eligible = 0,
    edungeon = 0 }
  local through = ns.finite(w.through) or now
  for name, m in pairs(members()) do
    if newcomer(name, m, now) and joined(name, m) > through then
      out.new = out.new + 1
      if ns.finite(m.addon) then out.addon = out.addon + 1 end
      local dg, e = w.dungeon[name] ~= nil, (ns.finite(m.lvl) or 0) >= ns.WEEK1_DUNGEON_LEVEL
      if dg then out.dungeon = out.dungeon + 1 end
      if e then out.eligible = out.eligible + 1 end
      if dg and e then out.edungeon = out.edungeon + 1 end
      if groupedAt(w, name, m) then
        out.grouped = out.grouped + 1
      elseif online[name] then
        out.waiting = out.waiting + 1
      elseif now - (ns.finite(m.seen) or ns.finite(m.first) or now) >= ns.WEEK1_QUIET_DAYS * DAY then
        out.quiet = out.quiet + 1
      end
    end
  end
  return out
end

-- Groups per night (Louis, 8 Nov: yes to a groups-per-night count), counts only, no names. A night runs 12:00 to 12:00
-- UTC, so an evening anywhere in the Americas or Europe stays in one night. Per night: f groups formed (a dungeon with
-- 2+ guildmates that wasn't one at the sample before; after a gap of more than 2 samples every group counts as new),
-- peak groups at once, q group quarter-hours (samples x groups), c calls from /uw lead on this client, a answers.
-- Seen only while a helper plays, like the rest of this file: a floor, not a full count.
ns.WEEK1_NIGHT_KEEP = 60
local function nightKey(now) return date("!%Y%m%d", now - 12 * 3600) end
local function night(w, now)
  local k = nightKey(now)
  if type(w.nights[k]) ~= "table" then w.nights[k] = {} end
  return w.nights[k]
end

local function noteNight(w, now, slot, byZone)
  local n, prev = night(w, now), (type(w.groupZones) == "table" and (tonumber(w.groupSlot) or 0) >= slot - 2)
    and w.groupZones or {}
  local cur, groups = {}, 0
  for zone, list in pairs(byZone) do
    if #list >= 2 then
      cur[zone], groups = true, groups + 1
      if not prev[zone] then inc(n, "f") end
    end
  end
  n.q = (tonumber(n.q) or 0) + groups
  n.p = math.max(tonumber(n.p) or 0, groups)
  w.groupZones, w.groupSlot = cur, slot
  local oldest = nightKey(now - ns.WEEK1_NIGHT_KEEP * DAY)
  for k in pairs(w.nights) do if type(k) ~= "string" or k < oldest then w.nights[k] = nil end end
end

-- Lead.lua: a call sent in guild chat ("c") or an answer to it ("a"), on a helper's client.
function ns.WeekOneNight(kind)
  if (kind ~= "c" and kind ~= "a") or not date or not ns.WeekOneHelper() then return end
  inc(night(store(), time()), kind)
end

-- When newcomers are on (Louis 8 Nov 23:52, priority 1: plan a first dungeon for when most newcomers who haven't
-- grouped are online). w.on[name] = { lv = level, h = { [hour] = samples online } } by this PC's clock, for newcomers
-- not yet grouped; kept on this PC like w.seen, and dropped once they group or their first week ends.
local function noteOn(w, rows, now)
  local hour = tonumber(date("%H", now))
  for _, r in ipairs(rows) do
    local m = members()[r.name]
    if r.online and ns.finite(r.level) and newcomer(r.name, m, now) and not groupedAt(w, r.name, m) then
      local o = type(w.on[r.name]) == "table" and w.on[r.name] or {}
      if type(o.h) ~= "table" then o.h = {} end
      o.lv, o.h[hour] = r.level, (tonumber(o.h[hour]) or 0) + 1
      w.on[r.name] = o
    end
  end
  for name in pairs(w.on) do
    local m = members()[name]
    if not newcomer(name, m, now) or groupedAt(w, name, m) then w.on[name] = nil end
  end
end

-- The plan: the dungeon (Lead.lua's ns.LEAD_DUNGEONS, the same rule as the suggested call) and the hour of the day
-- (this PC's clock) when the most newcomers who haven't grouped have been online at its levels, at least 3 (with the
-- caller and a helper, a group of 5), online right now or not. Ties: more samples, then the range centred on their
-- levels. { name, dlo, dhi, hour, n, lo, hi } or nil; worked out once per 15-minute sample.
ns.WEEK1_PLAN_MIN = 3
local planCache
function ns.WeekOnePlan()
  local w = store()
  if planCache and planCache.slot == w.slot then return planCache.plan end
  local cand, now, best = {}, time(), nil
  for name, o in pairs(w.on) do
    local m = members()[name]
    if type(o) == "table" and type(o.h) == "table" and ns.finite(o.lv) and newcomer(name, m, now)
      and not groupedAt(w, name, m) then
      cand[#cand + 1] = o
    end
  end
  for _, d in ipairs(ns.LEAD_DUNGEONS or {}) do
    for hour = 0, 23 do
      local n, total, sum, a, b = 0, 0, 0, nil, nil
      for _, o in ipairs(cand) do
        local k = tonumber(o.h[hour]) or 0
        if k > 0 and o.lv >= d[2] and o.lv <= d[3] then
          n, total, sum = n + 1, total + k, sum + o.lv
          a, b = math.min(a or o.lv, o.lv), math.max(b or o.lv, o.lv)
        end
      end
      if n >= ns.WEEK1_PLAN_MIN then
        local off = math.abs((d[2] + d[3]) / 2 - sum / n)
        if not best or n > best.n or (n == best.n and (total > best.total or (total == best.total and off < best.off)))
        then
          best = { name = d[1], dlo = d[2], dhi = d[3], hour = hour, n = n, total = total, off = off, lo = a, hi = b }
        end
      end
    end
  end
  planCache = { slot = w.slot, plan = best }
  return best
end

-- Core.lua calls this after each complete roster read (rows: name, level, online, zone).
local noDateTold
function ns.WeekOneSample(rows, now)
  if not ns.WeekOneHelper() then return end
  if not date then
    if not noDateTold then noDateTold = true ns.trace("week1", "sample", false, "no date() on this client") end
    return
  end
  local w = store()
  local slot = math.floor(now / SLOT)
  if w.slot == slot then return end -- one sample per slot, also across /reload
  -- Once per member: the last full read before the roster first saw them (0 when already here then, or before any
  -- read). joined() refuses invites up to it. A new field only: members from before it read 0, as before.
  local prior = ns.finite(w.slot) and w.slot * SLOT or nil
  for _, m in pairs(members()) do
    local first = type(m) == "table" and ns.finite(m.first)
    if first and m.w1prior == nil then m.w1prior = (prior and first > prior) and prior or 0 end
  end
  w.slot = slot
  local byZone, online = {}, {}
  for _, r in ipairs(rows) do
    if r.online then
      online[r.name] = true
      if isInstance(w, r.zone) then
        byZone[r.zone] = byZone[r.zone] or {}
        table.insert(byZone[r.zone], r.name)
      end
    end
  end
  for _, list in pairs(byZone) do
    if #list >= 2 then for _, n in ipairs(list) do mark(w, n, now) markDungeon(w, n, now) end end
  end
  local day = date("!%Y%m%d", now)
  w.cover[day] = (tonumber(w.cover[day]) or 0) + 1 -- a helper's 15-minute read: coverage, counts only
  local oldest = date("!%Y%m%d", now - ns.WEEK1_COVER_DAYS * DAY)
  for k in pairs(w.cover) do if type(k) ~= "string" or k < oldest then w.cover[k] = nil end end
  noteNight(w, now, slot, byZone)
  noteOn(w, rows, now)
  finalize(w, now)
  w.live = live(w, online, now)
  local seen = 0
  for _ in pairs(online) do seen = seen + 1 end
  ns.trace("week1", "sample", true, seen .. " online")
end

-- The helper's own group: every guildmate in it, and the helper too when there is one. It counts as a dungeon only
-- while the helper is inside a party or raid instance.
local function helperInInstance(w)
  if IsInInstance then
    local inside, kind = IsInInstance()
    if inside and (kind == "party" or kind == "raid") then return true end
  end
  local zone = GetRealZoneText and GetRealZoneText()
  return type(zone) == "string" and not ns.isSecret(zone) and isInstance(w, zone)
end

local function noteGroup()
  if not IsInGroup() or not ns.WeekOneHelper() then return end
  local w, now, raid, any = store(), time(), IsInRaid(), false
  local dungeon = helperInInstance(w)
  for i = 1, raid and GetNumGroupMembers() or math.max(0, GetNumGroupMembers() - 1) do
    local unit = (raid and "raid" or "party") .. i
    local full = ns.unitFull(unit) -- first name and surname, as the members keys hold them (not UnitName's first part)
    if full and UnitIsInMyGuild(unit) and not UnitIsUnit(unit, "player") then
      mark(w, ns.shortName(full), now)
      if dungeon then markDungeon(w, ns.shortName(full), now) end
      any = true
    end
  end
  if any then
    mark(w, ns.shortName(ns.me() or ""), now)
    if dungeon then markDungeon(w, ns.shortName(ns.me() or ""), now) end
  end
end

local function learnInstance()
  if not (IsInInstance and GetRealZoneText) or not ns.WeekOneHelper() then return end
  local inside, kind = IsInInstance()
  local zone = GetRealZoneText()
  if not inside or (kind ~= "party" and kind ~= "raid") or type(zone) ~= "string" or ns.isSecret(zone) or zone == "" then return end
  local w, n = store(), 0
  if w.inst[zone] or ns.INSTANCE_ZONES[zone] then return end
  for _ in pairs(w.inst) do n = n + 1 end
  if n < ns.WEEK1_INST_MAX then w.inst[zone] = true end
end

-- Online newcomers with no guild group seen yet, longest in the guild first, each with up to two guildmates near them.
function ns.WeekOneWaiting()
  local w, now, rows, me = store(), time(), {}, ns.shortName(ns.me() or "")
  for i = 1, GetNumGuildMembers() do
    local full, _, _, level, _, zone, _, _, online = GetGuildRosterInfo(i)
    if online and type(full) == "string" and not ns.isSecret(full) and level then
      if type(zone) ~= "string" or ns.isSecret(zone) then zone = nil end
      rows[#rows + 1] = { full = full, name = ns.shortName(full), level = level, zone = zone }
    end
  end
  local out, byName = {}, {}
  for _, r in ipairs(rows) do byName[r.name] = r end
  for _, r in ipairs(rows) do
    local m = members()[r.name]
    if r.name ~= me and newcomer(r.name, m, now) and not groupedAt(w, r.name, m) then
      local near = {}
      for _, o in ipairs(rows) do
        if o.name ~= r.name and o.name ~= me and math.abs(o.level - r.level) <= ns.WEEK1_NEAR then near[#near + 1] = o end
      end
      table.sort(near, function(a, b)
        local za, zb = a.zone == r.zone, b.zone == r.zone
        if za ~= zb then return za end
        local da, db = math.abs(a.level - r.level), math.abs(b.level - r.level)
        if da ~= db then return da < db end
        return a.name < b.name
      end)
      local pair = type(UW_GuildDB.buddies) == "table" and UW_GuildDB.buddies[r.name]
      local buddy = type(pair) == "table" and byName[pair.buddy] or nil
      out[#out + 1] = { row = r, day = math.floor((now - joined(r.name, m)) / DAY) + 1, buddy = buddy,
        near = { near[1], near[2] } }
    end
  end
  table.sort(out, function(a, b) if a.day ~= b.day then return a.day > b.day end return a.row.name < b.row.name end)
  return out
end

local function link(r) return ("|Hplayer:%s|h[%s]|h"):format(r.full, r.name) end

local function weekLine(w)
  local l = type(w.live) == "table" and w.live or nil
  if not l or not ns.finite(l.new) then return end
  say(("This week: %d joined, %d grouped with guildmates, %d quiet %d+ days with no group yet."):format(l.new,
    ns.finite(l.grouped) or 0, ns.finite(l.quiet) or 0, ns.WEEK1_QUIET_DAYS))
end

ns.commands.new = function(args)
  args = strtrim(args or ""):lower()
  if not ns.WeekOneHelper() then
    say("/uw new is for officers and welcome buddies. Want to help newcomers find a group? /uw jobs shows how.")
    return
  end
  local w = store()
  if args == "off" or args == "on" then
    w.off = args == "off" or nil
    say(w.off and "No login line about newcomers. /uw new still lists them; /uw new on brings the line back."
      or "At login you'll see how many newcomers online haven't grouped yet.")
    return
  end
  local list = ns.WeekOneWaiting()
  if #list == 0 then
    say("No newcomer online right now is still waiting for a group with the guild.")
  else
    say(("%d newcomer%s online, not yet seen in a dungeon with a guildmate. Click a name to whisper or invite:")
      :format(#list, #list == 1 and "" or "s"))
    for i = 1, math.min(#list, ns.WEEK1_SHOW) do
      local e, r = list[i], list[i].row
      local near = {}
      for _, o in ipairs(e.near) do near[#near + 1] = ("%s %d"):format(link(o), o.level) end
      say(("%s %d, %s, day %d%s%s"):format(link(r), r.level, r.zone or "?", e.day,
        e.buddy and (" · buddy " .. link(e.buddy)) or "",
        #near > 0 and (" · near: " .. table.concat(near, ", ")) or ""))
    end
    if #list > ns.WEEK1_SHOW then say(("...and %d more."):format(#list - ns.WEEK1_SHOW)) end
    -- For the helper to type when they group up, never sent by the addon (Louis, 8 Nov: no addon whispers).
    say(("Grouped with someone who lacks UW_Guild? Tell them: Our guild addon is free and takes 2 minutes: %s")
      :format(ns.ADDON_URL))
  end
  weekLine(w)
end

local told -- once a session
local function loginLine()
  if told or not ns.WeekOneHelper() or store().off then return end
  local n = #ns.WeekOneWaiting()
  if n == 0 then return end
  told = true
  -- "seen": only dungeons and the helper's own group count, so open-world questing together still reads as waiting.
  -- Officers get the one action that reaches them all (Lead.lua's suggested call); buddies get the list.
  say(("%d newcomer%s online, not yet seen in a dungeon with a guildmate. %s"):format(n, n == 1 and "" or "s",
    ns.isOfficer(ns.me()) and ns.Lead and "/uw lead call suggests a group for them." or "/uw new shows who's near them."))
end

local f = CreateFrame("Frame")
ns.listen(f, { "GROUP_ROSTER_UPDATE", "PLAYER_ENTERING_WORLD" })
f:SetScript("OnEvent", ns.guard(function(_, event)
  if not (UW_GuildDB and ns.inOurGuild and ns.inOurGuild()) then return end
  if event == "GROUP_ROSTER_UPDATE" then
    ns.protect(noteGroup)
  else
    ns.protect(learnInstance)
  end
end))
ns.afterRoster(function() ns.after(30, function() ns.protect(loginLine) end) end)
