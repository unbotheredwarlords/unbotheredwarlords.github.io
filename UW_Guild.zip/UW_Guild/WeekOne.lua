-- Week one (Louis, 8 Nov 2026): help every new guildmate play with guildmates in their first week, and measure it.
-- Newcomers who never group drift off: playing alongside others isn't playing with them (Ducheneaut, Yee, Nickell &
-- Moore 2006), and early contact from existing members is what keeps newcomers (Kraut & Resnick 2012). Discord's LFG
-- went unused, and on 8 Nov 3 of 150 guildmates ran UW_Guild, so this reads the guild roster, which every client has.
--   * Measure, counts only. An officer's or welcome buddy's client reads the roster once per 15-minute slot. Two or
--     more guildmates online in one dungeon or raid count as grouped (an instance holds one group; two guild groups in
--     one dungeon at once are rare at our size, so it can overcount a little). The helper's own group counts too, and
--     so does a newcomer's own UW_Guild report (GRP, Onboarding.lua).
--   * Names stay on this PC only until the newcomer's day 8, to keep the grouped off /uw new. Then the newcomer is
--     added to their join day's counts and the name goes. The bot reads counts only (bot/uwbot/weekone.py).
--   * Act through people. /uw new lists newcomers online now with no guild group seen yet, each with their buddy and
--     up to two online guildmates near their level, so an officer or buddy can invite them. It never contacts the
--     newcomer. At login, helpers get one line saying how many are waiting (/uw new off stops it).
-- UW_GuildDB.weekOne = { slot, through, off, seen = { [name] = time }, dungeon = { [name] = time },
--   inst = { [zone] = true }, cover = { ["YYYYMMDD"] = samples },
--   days = { ["YYYYMMDD"] = { n, g3, g7, s3, s0, q, a, a3, ab3, p3n, v, d7, e, ed7, na, da, vl, nl, dl, nx, dx } },
--   live = { at, new, grouped, quiet, waiting, addon, dungeon, eligible, edungeon },
--   together = { ["A|B"] = time } (Discord-linked pairs read in one instance; noteTogether) }
-- First dungeon (Louis, 8 Nov 23:22: priority 1; definition in project file journeys/first-dungeon-metric.md):
-- "dungeon" holds only instance-zone reads, plus the helper's own group while the helper is inside an instance.
-- "seen" stays any guild group. A join day made by this version carries v = 2 and starts its first-dungeon fields at 0,
-- so the bot reads an older day's missing fields as missing, never as 0; vl = 1 likewise when the Discord split
-- (ns.LINKED from the bot's Schedule.lua) was known.
local _, ns = ...
local say = ns.say

local DAY, SLOT = 86400, 900
ns.WEEK1_DAYS = 7         -- a newcomer's first week
ns.WEEK1_FINAL_DAYS = 8   -- counted once day 7 is over, so "still playing on day 7" can be read
ns.WEEK1_GROUP_DAYS = 3   -- the playbook goal: grouped with guildmates within 72 hours
ns.WEEK1_QUIET_DAYS = 2   -- not seen for this long with no group yet: going quiet
ns.WEEK1_NEAR = 3         -- levels either side for "near them"
ns.WEEK1_KEEP_DAYS = 120  -- join-day counts kept this long
ns.WEEK1_SHOW = 8         -- house style: lists of 8 lines at most
ns.WEEK1_INST_MAX = 80    -- learned instance names kept
ns.WEEK1_ZONE_MAX = 150   -- distinct roster zone strings tallied (weekOne.zones): every zone and instance fits
ns.WEEK1_DUNGEON_LEVEL = 13 -- Ragefire Chasm, the lowest dungeon: "eligible" for a first dungeon
ns.WEEK1_COVER_DAYS = 60  -- helper samples per day kept (coverage, so more helpers isn't read as more dungeons)
-- Dungeons and raids as the roster names them. A zone a helper's own client enters as a party or raid instance is
-- learned too (weekOne.inst), so a dungeon Forever adds or renames counts without an update.
ns.INSTANCE_ZONES = {}
for _, z in ipairs({ "Ragefire Chasm", "Wailing Caverns", "The Deadmines", "Shadowfang Keep", "Blackfathom Deeps",
  "The Stockade", "Gnomeregan", "Razorfen Kraul", "Scarlet Monastery", "Razorfen Downs", "Uldaman", "Zul'Farrak",
  "Maraudon", "The Temple of Atal'Hakkar", "Sunken Temple", "Blackrock Depths", "Blackrock Spire", "Dire Maul",
  "Stratholme", "Scholomance", "Molten Core", "Onyxia's Lair", "Blackwing Lair", "Zul'Gurub", "Ruins of Ahn'Qiraj",
  "Ahn'Qiraj", "Temple of Ahn'Qiraj", "Naxxramas", "Hyjal Summit", "Barrow Deeps",
  -- Forever's nine new dungeons (Blizzard, "Explore the New Dungeons of World of Warcraft: Forever"), with the other
  -- spellings guides use, since the roster's exact names were never read on our client. The game's own list below
  -- adds the names the client really uses.
  "Hall of Thanes", "The Hall of Thanes", "Ruins of Lordaeron", "Excavation Site", "Excavation Site: Wetlands",
  "City of Dalaran", "The Drowned City", "Drowned City", "Krol'dok Stronghold", "Alcaz Prison", "Alcaz Island Prison",
  "Blackmaw Hold", "Shaper's Terrace" }) do
  ns.INSTANCE_ZONES[z] = true
end

-- The game's own dungeon list (addon search, 13 Nov 2026: the nine above were missing everywhere, so a newcomer's
-- first dungeon in Ruins of Lordaeron counted only if a helper had happened to walk in first). Forever's group finder
-- lists every dungeon and raid with its instance map and suggested levels (C_LFGList; Blizzard's own finder builds
-- its list the same way). Once per session each instance's name as the roster shows it (GetRealZoneText(mapID)) joins
-- INSTANCE_ZONES, and a dungeon whose name matches a row of Lead.lua's ns.LEAD_DUNGEONS takes the game's suggested
-- levels, so a dungeon Forever adds, renames or retunes is counted and suggested right with no UW_Guild update.
-- Read only, every call protected; a client without the API, or one that answers nothing yet, keeps the lists above.
-- What it read is kept in UW_GuildDB.gameDungeons (names and levels, no player data) so a save shows it.
ns.GAME_DUNGEON_CATEGORIES = { 2, 114 } -- the group finder's Dungeons and Raids (LFGVanilla_Constants.lua)
ns.GAME_DUNGEONS_MAX = 80
local function plainKey(s) return (s:lower():gsub("['`]", ""):gsub("[%p%s]+", " "):gsub("^the ", ""):gsub("^ +", ""):gsub(" +$", "")) end
local function readable(v) return v ~= nil and not ns.isSecret(v) and v or nil end
local function call(fn, ...)
  if type(fn) ~= "function" then return nil end
  local ok, a = pcall(fn, ...)
  if ok then return readable(a) end
end
function ns.LearnGameDungeons()
  local L, zoneText = rawget(_G, "C_LFGList"), rawget(_G, "GetRealZoneText")
  if type(L) ~= "table" or type(L.GetAvailableActivities) ~= "function" or type(L.GetActivityInfoTable) ~= "function"
    or type(zoneText) ~= "function" then
    ns.trace("week1", "game dungeons", false, "no group finder API")
    return nil
  end
  local rows, byKey, seen, n, retuned = {}, {}, {}, 0, 0
  for _, d in ipairs(ns.LEAD_DUNGEONS or {}) do byKey[plainKey(d[1])] = d end
  for _, cat in ipairs(ns.GAME_DUNGEON_CATEGORIES) do
    local ids = call(L.GetAvailableActivities, cat)
    for _, id in ipairs(type(ids) == "table" and ids or {}) do
      local info = call(L.GetActivityInfoTable, id)
      local mapID = type(info) == "table" and readable(info.mapID)
      if type(mapID) == "number" and mapID > 0 and readable(info.isPvpActivity) ~= true and n < ns.GAME_DUNGEONS_MAX then
        local name = readable(info.fullName)
        local zone = call(zoneText, mapID)
        local lo = readable(info.minLevelSuggestion)
        local hi = readable(info.maxLevelSuggestion)
        if type(lo) ~= "number" or lo < 1 then lo = readable(info.minLevel) end
        local sane = type(lo) == "number" and type(hi) == "number" and lo >= 1 and lo <= hi and hi <= 60
        -- Only a zone whose name is part of the activity's ("Scarlet Monastery" of "Scarlet Monastery - Graveyard"),
        -- so a map the client doesn't know can never make a city or an outdoor zone count as a dungeon.
        local zk, nk = type(zone) == "string" and plainKey(zone) or "", type(name) == "string" and plainKey(name) or ""
        if zk ~= "" and nk ~= "" and (nk:find(zk, 1, true) or zk:find(nk, 1, true)) and not seen[zone] then
          seen[zone], n = true, n + 1
          ns.INSTANCE_ZONES[zone] = true
        end
        if type(name) == "string" and name ~= "" then
          rows[name:sub(1, 48)] = sane and ("%d-%d"):format(lo, hi) or "?"
          local d = byKey[plainKey(name)]
          if d and sane and (d[2] ~= lo or d[3] ~= hi) then d[2], d[3], retuned = lo, hi, retuned + 1 end
        end
      end
    end
  end
  if type(UW_GuildDB) == "table" then
    UW_GuildDB.gameDungeons = { at = time(), zones = n, retuned = retuned, list = rows }
  end
  ns.trace("week1", "game dungeons", n > 0, ("%d instances, %d levels from the game"):format(n, retuned))
  return n
end

local function store()
  local w = UW_GuildDB.weekOne
  if type(w) ~= "table" then w = {}; UW_GuildDB.weekOne = w end
  for _, k in ipairs({ "seen", "dungeon", "days", "inst", "nights", "cover", "on", "slots", "peerCover", "peerSlots",
    "peerDays", "coverAll", "zones", "together" }) do
    if type(w[k]) ~= "table" then w[k] = {} end
  end
  return w
end

local function members() return type(UW_GuildDB.members) == "table" and UW_GuildDB.members or {} end

-- Officers, and members whose public guild note names the Welcome buddy job (Onboarding.lua ns.JOBS). name: anyone's
-- (a sender's full name, for the shared counts below); this character's own when nil.
function ns.WeekOneHelper(name)
  local full = name or ns.me()
  if not full then return false end
  if ns.isOfficer(full) then return true end
  local m = members()[ns.shortName(full)]
  if type(m) ~= "table" or not ns.NoteJobs then return false end
  for _, k in ipairs(ns.NoteJobs(m.note)) do if k == "buddy" then return true end end
  return false
end

-- When a newcomer joined, for week one. The roster first sees a joiner only while some UW_Guild client plays, so
-- m.first is the next login after the join: a joiner while nobody was on would get a later join day and a 7-day window
-- that starts after a first dungeon nobody saw (D7 readout check, 9 Nov). The guild event log's invite dates it
-- better (Onboarding.lua, UW_GuildDB.invites; recruiters.py credits the same one): the latest invite at or before the
-- roster's first sight, with an hour's slack as the log says "N hours ago", from up to WEEK1_JOIN_LOOKBACK days before.
-- Otherwise m.first. A rejoin keeps its old m.first and has no invite before it, so it stays out as before.
-- An invite at or before m.w1prior is never the one they joined on: m.w1prior is the last full helper read before the
-- roster first saw them (WeekOneSample stamps it once), and they weren't in the guild then. Such an invite is an older
-- one they declined; dated by it, they could fall before weekOne.through and never be counted (red team, #534 LOW).
-- The log's "N hours ago" only ever makes an invite look later than it was, so a real one is never refused this way.
ns.WEEK1_JOIN_LOOKBACK = 14
local function joined(name, m)
  local first = type(m) == "table" and ns.finite(m.first)
  if not first then return nil end
  local list, best = type(UW_GuildDB.invites) == "table" and UW_GuildDB.invites[name], nil
  local floor = math.max(ns.finite(m.w1prior) or 0, first - ns.WEEK1_JOIN_LOOKBACK * DAY)
  for _, e in ipairs(type(list) == "table" and list or {}) do
    local at = type(e) == "table" and ns.finite(e.at)
    if at and at <= first + 3600 and at > floor and (not best or at > best) then
      best = at
    end
  end
  return best and math.min(best, first) or first
end
ns.WeekOneJoined = joined

-- A guildmate in their first `days` days who joined after this account's addon started (ns.isRecruit) or holds Trial.
-- A guildmate the addon hasn't recorded yet (a join a moment ago, grouped before the next roster read) is no newcomer
-- yet: m is nil (Louis's log, 8 Nov: "attempt to index local 'm'" when El Bonacho joined his group).
local function newcomer(name, m, now, days)
  local first = joined(name, m)
  if not first then return false end
  return not m.left and now - first < (days or ns.WEEK1_DAYS) * DAY and ns.isRecruit(name)
end

-- Earliest group with a guildmate seen for this member: their own UW_Guild's report or this client's.
local function groupedAt(w, name, m)
  local a, b = ns.finite(m.firstGroup), ns.finite(w.seen[name])
  if a and b then return math.min(a, b) end
  return a or b
end

local function mark(w, name, now)
  if not name or w.seen[name] then return end
  if newcomer(name, members()[name], now, ns.WEEK1_FINAL_DAYS) then w.seen[name] = now end
end

-- A dungeon with a guildmate, for the first-dungeon count: instance-zone reads only.
local function markDungeon(w, name, now)
  if not name or w.dungeon[name] then return end
  if newcomer(name, members()[name], now, ns.WEEK1_FINAL_DAYS) then w.dungeon[name] = now end
end

-- Characters linked in Discord (the bot writes ns.LINKED into Schedule.lua on the Guild Master's PC; never shared).
-- nil when this client has no list: then the Discord split isn't counted at all.
local function linkedSet()
  if type(ns.LINKED) ~= "table" then return nil end
  local out = {}
  for _, n in ipairs(ns.LINKED) do
    if type(n) == "string" then out[(n:lower():gsub("[%s%-]+", " "))] = true end
  end
  return out
end

-- Two Discord-linked guildmates read in one dungeon or raid at once: "A|B" (sorted) -> when, kept TOGETHER_DAYS. The bot
-- reads it only to close its match introductions as grouped (bot/uwbot/profiles.py label_game_pairs): the guild groups
-- in game, and Discord's /lfg, which the bot used to count, goes unused (13 Nov). Linked characters only, on this PC.
ns.WEEK1_TOGETHER_DAYS = 15
local function noteTogether(w, byZone, now)
  local linked = linkedSet()
  if linked then
    for _, list in pairs(byZone) do
      local ln = {}
      for _, n in ipairs(list) do
        if linked[(n:lower():gsub("[%s%-]+", " "))] then table.insert(ln, n) end
      end
      table.sort(ln)
      for i = 1, #ln - 1 do
        for j = i + 1, #ln do w.together[ln[i] .. "|" .. ln[j]] = now end
      end
    end
  end
  for k, t in pairs(w.together) do
    if type(k) ~= "string" or not ns.finite(t) or t < now - ns.WEEK1_TOGETHER_DAYS * DAY then w.together[k] = nil end
  end
end

local function isInstance(w, zone) return zone ~= nil and (ns.INSTANCE_ZONES[zone] or w.inst[zone]) and true or false end
-- The same test for other files (Lead.lua's suggested call and helpers), learned zones included.
function ns.IsInstanceZone(zone)
  local w = type(UW_GuildDB) == "table" and type(UW_GuildDB.weekOne) == "table" and UW_GuildDB.weekOne or nil
  return type(zone) == "string" and (ns.INSTANCE_ZONES[zone] or (w and type(w.inst) == "table" and w.inst[zone]))
    and true or false
end

local function inc(d, k) d[k] = (tonumber(d[k]) or 0) + 1 end

-- Adds one newcomer to their join day's counts: n joined; g3/g7 grouped within 3/7 days; s3/s0 still playing on day 7
-- having grouped within 3 days or not; q gone by day 7 without ever grouping.
-- Calibration, so the guild-wide rate can be corrected as more members run UW_Guild: a runs it; a3 of those reported
-- their own group within 3 days (GRP: the truth for them); ab3 of a3 the roster also caught; p3n newcomers without
-- UW_Guild the roster caught within 3 days. The bot divides p3n by the roster's hit rate ab3/a3 (weekone.py).
-- First dungeon: d7 in a dungeon with a guildmate within 7 days; e level 13+ when counted (day 8, so a day late at
-- most); ed7 both. Exclusive segments: a (UW_Guild since joining), l (linked in Discord, not a), x (neither); n? joined
-- and d? of them with d7.
local function count(w, name, m, first, linked)
  local key = date("!%Y%m%d", first)
  local d = w.days[key]
  if type(d) ~= "table" then
    d = { v = 2, d7 = 0, e = 0, ed7 = 0, na = 0, da = 0 }
    if linked then d.vl, d.nl, d.dl, d.nx, d.dx = 1, 0, 0, 0, 0 end
    w.days[key] = d
  end
  local g = groupedAt(w, name, m)
  local g3 = g ~= nil and g - first <= ns.WEEK1_GROUP_DAYS * DAY
  local g7 = g ~= nil and g - first <= ns.WEEK1_DAYS * DAY
  local left = ns.finite(m.left)
  local stayed = (ns.finite(m.seen) or 0) >= first + ns.WEEK1_DAYS * DAY
    and not (left and left < first + ns.WEEK1_DAYS * DAY)
  inc(d, "n")
  if g3 then inc(d, "g3") end
  if g7 then inc(d, "g7") end
  if stayed then inc(d, g3 and "s3" or "s0") end
  if not g7 and not stayed then inc(d, "q") end
  local own, seen = ns.finite(m.firstGroup), ns.finite(w.seen[name])
  local seen3 = seen ~= nil and seen - first <= ns.WEEK1_GROUP_DAYS * DAY
  if ns.finite(m.addon) then
    inc(d, "a")
    if own and own - first <= ns.WEEK1_GROUP_DAYS * DAY then
      inc(d, "a3")
      if seen3 then inc(d, "ab3") end
    end
  elseif seen3 then
    inc(d, "p3n")
  end
  if d.v ~= 2 then return end -- a day an older version started: its first-dungeon fields stay missing
  local dg = ns.finite(w.dungeon[name])
  local d7 = dg ~= nil and dg - first <= ns.WEEK1_DAYS * DAY
  local e = (ns.finite(m.lvl) or 0) >= ns.WEEK1_DUNGEON_LEVEL
  if d7 then inc(d, "d7") end
  if e then inc(d, "e") end
  if e and d7 then inc(d, "ed7") end
  local seg
  if (ns.finite(m.addon) or 0) >= first then seg = "a"
  elseif d.vl == 1 and linked then
    local k = (name:lower():gsub("[%s%-]+", " ")) -- as the bot's text.name_key; a bare first-name link counts too
    seg = (linked[k] or linked[k:match("^%S+") or k]) and "l" or "x"
  end
  if seg then
    inc(d, "n" .. seg)
    if d7 then inc(d, "d" .. seg) end
  end
end

-- Newcomers whose day 8 has passed go into the counts once. Only joins after this client started measuring count
-- (w.through starts then): earlier ones were never watched, so they would look like nobody grouped.
local function finalize(w, now)
  local through = ns.finite(w.through)
  if not through then w.through = now return end
  local cutoff = now - ns.WEEK1_FINAL_DAYS * DAY
  if cutoff <= through then return end
  local linked = linkedSet()
  for name, m in pairs(members()) do
    local first = joined(name, m)
    if first and first > through and first <= cutoff and ns.isRecruit(name) then count(w, name, m, first, linked) end
  end
  w.through = cutoff
  for _, t in ipairs({ w.seen, w.dungeon }) do
    for name in pairs(t) do
      local first = joined(name, members()[name])
      if not first or first <= cutoff then t[name] = nil end -- counted (or gone): the name isn't needed any more
    end
  end
  local oldest = date("!%Y%m%d", now - ns.WEEK1_KEEP_DAYS * DAY)
  for k in pairs(w.days) do if type(k) ~= "string" or k < oldest then w.days[k] = nil end end
end

-- This week so far, counts only: newcomers, how many grouped, how many went quiet first, how many are online solo,
-- and the first-dungeon count. Only joins after measuring began (w.through): earlier ones were never watched.
local function live(w, online, now)
  local out = { at = now, new = 0, grouped = 0, quiet = 0, waiting = 0, addon = 0, dungeon = 0, eligible = 0,
    edungeon = 0 }
  local through = ns.finite(w.through) or now
  for name, m in pairs(members()) do
    if newcomer(name, m, now) and joined(name, m) > through then
      out.new = out.new + 1
      if ns.finite(m.addon) then out.addon = out.addon + 1 end
      local dg, e = w.dungeon[name] ~= nil, (ns.finite(m.lvl) or 0) >= ns.WEEK1_DUNGEON_LEVEL
      if dg then out.dungeon = out.dungeon + 1 end
      if e then out.eligible = out.eligible + 1 end
      if dg and e then out.edungeon = out.edungeon + 1 end
      if groupedAt(w, name, m) then
        out.grouped = out.grouped + 1
      elseif online[name] then
        out.waiting = out.waiting + 1
      elseif now - (ns.finite(m.seen) or ns.finite(m.first) or now) >= ns.WEEK1_QUIET_DAYS * DAY then
        out.quiet = out.quiet + 1
      end
    end
  end
  return out
end

-- Groups per night (Louis, 8 Nov: yes to a groups-per-night count), counts only, no names. A night runs 12:00 to 12:00
-- UTC, so an evening anywhere in the Americas or Europe stays in one night. Per night: f groups formed (a dungeon with
-- 2+ guildmates that wasn't one at the sample before; after a gap of more than 2 samples every group counts as new),
-- peak groups at once, q group quarter-hours (samples x groups), c calls this helper made or heard (typed or the Call
-- button, Lead.lua L.HeardCall), a answers to them.
-- Seen only while a helper plays, like the rest of this file: a floor, not a full count.
ns.WEEK1_NIGHT_KEEP = 60
local function nightKey(now) return date("!%Y%m%d", now - 12 * 3600) end
local function night(w, now)
  local k = nightKey(now)
  if type(w.nights[k]) ~= "table" then w.nights[k] = {} end
  return w.nights[k]
end

local function noteNight(w, now, slot, byZone)
  local n, prev = night(w, now), (type(w.groupZones) == "table" and (tonumber(w.groupSlot) or 0) >= slot - 2)
    and w.groupZones or {}
  local cur, groups = {}, 0
  for zone, list in pairs(byZone) do
    if #list >= 2 then
      cur[zone], groups = true, groups + 1
      if not prev[zone] then inc(n, "f") end
    end
  end
  n.q = (tonumber(n.q) or 0) + groups
  n.p = math.max(tonumber(n.p) or 0, groups)
  w.groupZones, w.groupSlot = cur, slot
  local oldest = nightKey(now - ns.WEEK1_NIGHT_KEEP * DAY)
  for k in pairs(w.nights) do if type(k) ~= "string" or k < oldest then w.nights[k] = nil end end
end

-- Lead.lua: a call sent in guild chat ("c") or an answer to it ("a"), on a helper's client.
function ns.WeekOneNight(kind)
  if (kind ~= "c" and kind ~= "a") or not date or not ns.WeekOneHelper() then return end
  inc(night(store(), time()), kind)
end

-- When newcomers are on (Louis 8 Nov 23:52, priority 1: plan a first dungeon for when most newcomers who haven't
-- grouped are online). w.on[name] = { lv = level, h = { [hour] = samples online } } by this PC's clock, for newcomers
-- not yet grouped; kept on this PC like w.seen, and dropped once they group or their first week ends.
local function noteOn(w, rows, now)
  local hour = tonumber(date("%H", now))
  for _, r in ipairs(rows) do
    local m = members()[r.name]
    if r.online and ns.finite(r.level) and newcomer(r.name, m, now) and not groupedAt(w, r.name, m) then
      local o = type(w.on[r.name]) == "table" and w.on[r.name] or {}
      if type(o.h) ~= "table" then o.h = {} end
      o.lv, o.h[hour] = r.level, (tonumber(o.h[hour]) or 0) + 1
      w.on[r.name] = o
    end
  end
  for name in pairs(w.on) do
    local m = members()[name]
    if not newcomer(name, m, now) or groupedAt(w, name, m) then w.on[name] = nil end
  end
end

-- The plan: the dungeon (Lead.lua's ns.LEAD_DUNGEONS, the same rule as the suggested call) and the hour of the day
-- (this PC's clock) when the most newcomers who haven't grouped have been online at its levels, at least 3 (with the
-- caller and a helper, a group of 5), online right now or not. Ties: more samples, then the range centred on their
-- levels. { name, dlo, dhi, hour, n, lo, hi } or nil; worked out once per 15-minute sample.
ns.WEEK1_PLAN_MIN = 3
local planCache
function ns.WeekOnePlan()
  local w = store()
  if planCache and planCache.slot == w.slot then return planCache.plan end
  local cand, now, best = {}, time(), nil
  for name, o in pairs(w.on) do
    local m = members()[name]
    if type(o) == "table" and type(o.h) == "table" and ns.finite(o.lv) and newcomer(name, m, now)
      and not groupedAt(w, name, m) then
      cand[#cand + 1] = o
    end
  end
  for _, d in ipairs(ns.LEAD_DUNGEONS or {}) do
    for hour = 0, 23 do
      local n, total, sum, a, b = 0, 0, 0, nil, nil
      for _, o in ipairs(cand) do
        local k = tonumber(o.h[hour]) or 0
        if k > 0 and o.lv >= d[2] and o.lv <= d[3] then
          n, total, sum = n + 1, total + k, sum + o.lv
          a, b = math.min(a or o.lv, o.lv), math.max(b or o.lv, o.lv)
        end
      end
      if n >= ns.WEEK1_PLAN_MIN then
        local off = math.abs((d[2] + d[3]) / 2 - sum / n)
        if not best or n > best.n or (n == best.n and (total > best.total or (total == best.total and off < best.off)))
        then
          best = { name = d[1], dlo = d[2], dhi = d[3], hour = hour, n = n, total = total, off = off, lo = a, hi = b }
        end
      end
    end
  end
  planCache = { slot = w.slot, plan = best }
  return best
end

-- Core.lua calls this after each complete roster read (rows: name, level, online, zone).
local noDateTold
-- Which zone strings the roster really shows (red team Z1, 13 Nov): INSTANCE_ZONES matches them by name, and some
-- dungeon names are also outdoor places (Ruins of Lordaeron, The Deadmines). If the roster gives a subzone, someone
-- outdoors would count as in a dungeon. weekOne.zones = { [zone string] = online members seen there, summed over
-- reads }: zone names and counts only, never who. Never reset or aged out. At most WEEK1_ZONE_MAX strings, which
-- covers every Classic zone, city and instance with room to spare; past it a new string is dropped, never an old one.
local function tallyZone(w, zone)
  if type(zone) ~= "string" or zone == "" or ns.isSecret(zone) or #zone > 64 then return end
  local z = w.zones
  if z[zone] == nil then
    local n = 0
    for _ in pairs(z) do n = n + 1 end
    if n >= ns.WEEK1_ZONE_MAX then return end
  end
  z[zone] = (tonumber(z[zone]) or 0) + 1
end

function ns.WeekOneSample(rows, now)
  if not ns.WeekOneHelper() then return end
  if not date then
    if not noDateTold then noDateTold = true ns.trace("week1", "sample", false, "no date() on this client") end
    return
  end
  local w = store()
  local slot = math.floor(now / SLOT)
  if w.slot == slot then return end -- one sample per slot, also across /reload
  -- Once per member: the last full read before the roster first saw them (0 when already here then, or before any
  -- read). joined() refuses invites up to it. A new field only: members from before it read 0, as before.
  local prior = ns.finite(w.slot) and w.slot * SLOT or nil
  for _, m in pairs(members()) do
    local first = type(m) == "table" and ns.finite(m.first)
    if first and m.w1prior == nil then m.w1prior = (prior and first > prior) and prior or 0 end
  end
  w.slot = slot
  local byZone, online = {}, {}
  for _, r in ipairs(rows) do
    if r.online then
      online[r.name] = true
      tallyZone(w, r.zone)
      if isInstance(w, r.zone) then
        byZone[r.zone] = byZone[r.zone] or {}
        table.insert(byZone[r.zone], r.name)
      end
    end
  end
  for _, list in pairs(byZone) do
    if #list >= 2 then for _, n in ipairs(list) do mark(w, n, now) markDungeon(w, n, now) end end
  end
  noteTogether(w, byZone, now)
  local day = date("!%Y%m%d", now)
  w.cover[day] = (tonumber(w.cover[day]) or 0) + 1 -- a helper's 15-minute read: coverage, counts only
  w.slots[day] = ns.WeekOneSlotSet(w.slots[day], math.floor(now % DAY / SLOT))
  local oldest = date("!%Y%m%d", now - ns.WEEK1_COVER_DAYS * DAY)
  for _, t in ipairs({ w.cover, w.slots, w.peerCover, w.peerSlots }) do
    for k in pairs(t) do if type(k) ~= "string" or k < oldest then t[k] = nil end end
  end
  ns.WeekOneMerge(w, day)
  noteNight(w, now, slot, byZone)
  noteOn(w, rows, now)
  local before = ns.finite(w.through)
  finalize(w, now)
  w.live = live(w, online, now)
  -- finished days go out when counting passes into a new UTC day (once a day), today's reads once per read
  local through = ns.finite(w.through)
  ns.WeekOneShare(day, before and through and date("!%Y%m%d", before) ~= date("!%Y%m%d", through))
  local seen = 0
  for _ in pairs(online) do seen = seen + 1 end
  ns.trace("week1", "sample", true, seen .. " online")
end

-- The helper's own group: every guildmate in it, and the helper too when there is one. It counts as a dungeon only
-- while the helper is inside a party or raid instance.
local function helperInInstance(w)
  if IsInInstance then
    local inside, kind = IsInInstance()
    if inside and (kind == "party" or kind == "raid") then return true end
  end
  local zone = GetRealZoneText and GetRealZoneText()
  return type(zone) == "string" and not ns.isSecret(zone) and isInstance(w, zone)
end

local function noteGroup()
  if not IsInGroup() or not ns.WeekOneHelper() then return end
  local w, now, raid, any = store(), time(), IsInRaid(), false
  local dungeon = helperInInstance(w)
  for i = 1, raid and GetNumGroupMembers() or math.max(0, GetNumGroupMembers() - 1) do
    local unit = (raid and "raid" or "party") .. i
    local full = ns.unitFull(unit) -- first name and surname, as the members keys hold them (not UnitName's first part)
    if full and UnitIsInMyGuild(unit) and not UnitIsUnit(unit, "player") then
      mark(w, ns.shortName(full), now)
      if dungeon then markDungeon(w, ns.shortName(full), now) end
      any = true
    end
  end
  if any then
    mark(w, ns.shortName(ns.me() or ""), now)
    if dungeon then markDungeon(w, ns.shortName(ns.me() or ""), now) end
  end
end

local function learnInstance()
  if not (IsInInstance and GetRealZoneText) or not ns.WeekOneHelper() then return end
  local inside, kind = IsInInstance()
  local zone = GetRealZoneText()
  if not inside or (kind ~= "party" and kind ~= "raid") or type(zone) ~= "string" or ns.isSecret(zone) or zone == "" then return end
  local w, n = store(), 0
  if w.inst[zone] or ns.INSTANCE_ZONES[zone] then return end
  for _ in pairs(w.inst) do n = n + 1 end
  if n < ns.WEEK1_INST_MAX then w.inst[zone] = true end
end

-- Online newcomers with no guild group seen yet, longest in the guild first, each with up to two guildmates near them.
-- all: every first-week newcomer online, grouped or not (the login line and /uw new count them all: UW_Guild sees
-- few groups, so "not seen grouped" isn't a count anyone should read; coordinator, 10 Nov). Without it, only those
-- not seen grouped (Lead.lua's suggested call).
function ns.WeekOneWaiting(all)
  local w, now, rows, me = store(), time(), {}, ns.shortName(ns.me() or "")
  for i = 1, GetNumGuildMembers() do
    local full, _, _, level, _, zone, _, _, online = GetGuildRosterInfo(i)
    if online and type(full) == "string" and not ns.isSecret(full) and level then
      if type(zone) ~= "string" or ns.isSecret(zone) then zone = nil end
      rows[#rows + 1] = { full = full, name = ns.shortName(full), level = level, zone = zone }
    end
  end
  local out, byName = {}, {}
  for _, r in ipairs(rows) do byName[r.name] = r end
  for _, r in ipairs(rows) do
    local m = members()[r.name]
    if r.name ~= me and newcomer(r.name, m, now) and (all or not groupedAt(w, r.name, m)) then
      local near = {}
      for _, o in ipairs(rows) do
        if o.name ~= r.name and o.name ~= me and math.abs(o.level - r.level) <= ns.WEEK1_NEAR then near[#near + 1] = o end
      end
      table.sort(near, function(a, b)
        local za, zb = a.zone == r.zone, b.zone == r.zone
        if za ~= zb then return za end
        local da, db = math.abs(a.level - r.level), math.abs(b.level - r.level)
        if da ~= db then return da < db end
        return a.name < b.name
      end)
      local pair = type(UW_GuildDB.buddies) == "table" and UW_GuildDB.buddies[r.name]
      local buddy = type(pair) == "table" and byName[pair.buddy] or nil
      out[#out + 1] = { row = r, day = math.floor((now - joined(r.name, m)) / DAY) + 1, buddy = buddy,
        near = { near[1], near[2] }, grouped = groupedAt(w, r.name, m) ~= nil }
    end
  end
  table.sort(out, function(a, b) -- not seen grouped first, then the longest in
    if a.grouped ~= b.grouped then return not a.grouped end
    if a.day ~= b.day then return a.day > b.day end
    return a.row.name < b.row.name
  end)
  return out
end

local function link(r) return ("|Hplayer:%s|h[%s]|h"):format(r.full, r.name) end

local function weekLine(w)
  local l = type(w.live) == "table" and w.live or nil
  if not l or not ns.finite(l.new) then return end
  say(("This week: %d joined, %d grouped with guildmates, %d quiet %d+ days with no group yet."):format(l.new,
    ns.finite(l.grouped) or 0, ns.finite(l.quiet) or 0, ns.WEEK1_QUIET_DAYS))
end

ns.commands.new = function(args)
  args = strtrim(args or ""):lower()
  if not ns.WeekOneHelper() then
    say("/uw new is for officers and welcome buddies. Want to help newcomers find a group? /uw jobs shows how.")
    return
  end
  local w = store()
  if args == "off" or args == "on" then
    w.off = args == "off" or nil
    say(w.off and "No login line about newcomers. /uw new still lists them; /uw new on brings the line back."
      or "At login you'll see how many newcomers in their first week are online.")
    return
  end
  local list = ns.WeekOneWaiting(true)
  if #list == 0 then
    say("No newcomers in their first week are online right now.")
  else
    say(("%d newcomer%s in their first week online. Up for a group? Click a name in chat to whisper or invite:")
      :format(#list, #list == 1 and "" or "s"))
    for i = 1, math.min(#list, ns.WEEK1_SHOW) do
      local e, r = list[i], list[i].row
      local near = {}
      for _, o in ipairs(e.near) do near[#near + 1] = ("%s %d"):format(link(o), o.level) end
      say(("%s %d, %s, day %d%s%s%s"):format(link(r), r.level, r.zone or "?", e.day,
        e.grouped and " · grouped with us" or "", e.buddy and (" · buddy " .. link(e.buddy)) or "",
        #near > 0 and (" · near: " .. table.concat(near, ", ")) or ""))
    end
    if #list > ns.WEEK1_SHOW then say(("...and %d more."):format(#list - ns.WEEK1_SHOW)) end
    -- For the helper to type when they group up, never sent by the addon (Louis, 8 Nov: no addon whispers).
    say(("Grouped with someone who lacks UW_Guild? Tell them: Our guild addon is free and takes 2 minutes: %s")
      :format(ns.ADDON_URL))
  end
  weekLine(w)
end

local told -- once a session
local function loginLine()
  if told or not ns.WeekOneHelper() or store().off then return end
  local n = #ns.WeekOneWaiting(true)
  if n == 0 then return end
  told = true
  -- "seen": only dungeons and the helper's own group count, so open-world questing together still reads as waiting.
  -- Officers get the one action that reaches them all (Lead.lua's suggested call); buddies get the list.
  -- No claim they haven't done a dungeon: UW_Guild sees only groups with a helper's or the member's own UW_Guild
  -- (coordinator, 10 Nov: "25 not yet seen in a dungeon" read as "25 never did one").
  say(("%d newcomer%s in their first week online. Up for a group? %s"):format(n, n == 1 and "" or "s",
    ns.isOfficer(ns.me()) and ns.Lead and "/uw lead call suggests a group for them." or "/uw new shows who's near them."))
end

-- Shared reads (v1 quality audit item 2, 10 Nov 2026): a join day's first-dungeon count is "measured" only after 56
-- helper reads in its 7-day window, and only the Guild Master's save reaches the bot. Other helpers' clients (officers,
-- Welcome buddies) read the roster too, so each sends the Guild Master's client what it saw, as counts, never a name:
--   W1C <day> <reads> <slots>: its reads that UTC day, and which of the day's 96 quarter-hours they were, as 24 hex
--     digits (4 quarter-hours each). The Guild Master's client keeps every helper's quarter-hours together, so two
--     helpers on at the same time count once (weekOne.coverAll = the day's distinct quarter-hours read by anyone).
--   W1D <day> <k=v,...>: a finished join day's counts (the same fields as weekOne.days). Kept in weekOne.peerDays,
--     the fuller row per day (more newcomers, then more first dungeons), never added to this client's own days: the bot
--     takes the fuller of the two (bot/uwbot/weekone.py), as it does across saves.
-- Sent only from helpers' clients that aren't the bot's PC (Schedule.lua gen > 0); kept only on the bot's PC, from
-- senders who are helpers by the same test. Today's reads go after each read; finished days at login and when one
-- finishes. Paced with the crafting directory's lane, a few short addon messages an hour.
local HEX = "0123456789abcdef"
local POP = { [0] = 0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4 }
local function nibbles(hex)
  if type(hex) ~= "string" or not hex:match("^[0-9a-f]+$") or #hex ~= 24 then hex = ("0"):rep(24) end
  local out = {}
  for i = 1, 24 do out[i] = HEX:find(hex:sub(i, i), 1, true) - 1 end
  return out
end
local function hexOf(t)
  local out = {}
  for i = 1, 24 do out[i] = HEX:sub(t[i] + 1, t[i] + 1) end
  return table.concat(out)
end
local function bor4(a, b) -- a OR b for 4-bit numbers, without the bit library (Lua 5.1 tests have none)
  local r, p = 0, 1
  for _ = 1, 4 do
    if a % 2 == 1 or b % 2 == 1 then r = r + p end
    a, b, p = math.floor(a / 2), math.floor(b / 2), p * 2
  end
  return r
end
function ns.WeekOneSlotSet(hex, i)
  local t = nibbles(hex)
  local c, b = math.floor(i / 4) + 1, i % 4
  if c >= 1 and c <= 24 then t[c] = bor4(t[c], 2 ^ b) end
  return hexOf(t)
end
local function slotsOr(a, b)
  local x, y = nibbles(a), nibbles(b)
  for i = 1, 24 do x[i] = bor4(x[i], y[i]) end
  return hexOf(x)
end
local function slotCount(hex)
  local n = 0
  for _, v in ipairs(nibbles(hex)) do n = n + POP[v] end
  return n
end
ns.WeekOneSlotCount = slotCount
local function botPC() return type(ns.SCHEDULE) == "table" and (tonumber(ns.SCHEDULE.gen) or 0) > 0 end
-- The day's reads by anyone: this client's and every helper's quarter-hours together, never below a count a helper
-- sent before slots existed.
function ns.WeekOneMerge(w, day)
  if not botPC() then return end
  local all = slotsOr(w.slots[day], w.peerSlots[day])
  w.coverAll[day] = math.max(slotCount(all), tonumber(w.peerCover[day]) or 0, tonumber(w.cover[day]) or 0)
  local oldest = date and date("!%Y%m%d", time() - ns.WEEK1_COVER_DAYS * DAY)
  for _, t in ipairs({ w.coverAll, w.peerDays }) do
    for k in pairs(t) do if type(k) ~= "string" or (oldest and k < oldest) then t[k] = nil end end
  end
end
local DAY_FIELDS = { "n", "g3", "g7", "s3", "s0", "q", "a", "a3", "ab3", "p3n", "v", "d7", "e", "ed7", "na", "da",
  "vl", "nl", "dl", "nx", "dx" }
local function dayLine(day, d)
  local parts = {}
  for _, k in ipairs(DAY_FIELDS) do
    local v = ns.finite(d[k])
    if v then parts[#parts + 1] = k .. "=" .. math.floor(v) end
  end
  return "W1D\t" .. day .. "\t" .. table.concat(parts, ",")
end
local function shareDays(w)
  local oldest = date("!%Y%m%d", time() - ns.WEEK1_FINAL_DAYS * DAY - 9 * DAY)
  local through = ns.finite(w.through)
  -- only days this client has finished (counting passed into a later UTC day): a half-counted day would look final
  local done = through and date("!%Y%m%d", through)
  for day, d in pairs(w.days) do
    if type(d) == "table" and type(day) == "string" and day >= oldest and done and day < done then
      ns.craftSend(dayLine(day, d), "GUILD")
    end
  end
end
local function shareCover(w, day)
  ns.craftSend(("W1C\t%s\t%d\t%s"):format(day, tonumber(w.cover[day]) or 0, hexOf(nibbles(w.slots[day]))), "GUILD")
end
-- After each read on a helper's client that isn't the bot's PC: today's reads, and finished days when one finished.
-- /uw share off (Louis's OK, 13 Nov 2026 17:14; off line cleared by the coordinator 10 Nov 03:14; status line, switch label and
-- tooltip cleared 13 Nov 17:33; reworded and cleared again 19:24: a helper keeps its first-week list by name on its own
-- PC, and only counts leave it): this helper stops sending its counts. On by default, like every UW_Guild helper; off
-- costs only the shared cover, never rank or progress.
function ns.WeekOneSharing() return not (UW_GuildDB and UW_GuildDB.weekOneShareOff) end
ns.SHARE_OFF_TEXT = "/uw share off: your addon stops sending the Guild Master's addon how often you see the roster "
  .. "and its week-one counts (counts only). First-dungeon numbers then count only when other helpers are online."
ns.commands.share = function(args)
  local w = strtrim(args or ""):lower()
  if w == "off" then
    if UW_GuildDB then UW_GuildDB.weekOneShareOff = true end
  elseif w == "on" then
    if UW_GuildDB then UW_GuildDB.weekOneShareOff = nil end
  elseif w ~= "" then
    say("/uw share on or /uw share off.") return
  end
  if ns.WeekOneSharing() then say("Week-one counts: shared (counts only; your first-week list stays on your PC). " .. ns.SHARE_OFF_TEXT) else say(ns.SHARE_OFF_TEXT) end
end
function ns.WeekOneShare(day, finished)
  if botPC() or not ns.WeekOneSharing() or not ns.WeekOneHelper() or not ns.tracksGuild() then return end
  local w = store()
  shareCover(w, day)
  if finished then shareDays(w) end
end
-- At login: the last 9 days' reads (a newcomer week plus a day) and every finished day still being read.
local function shareAtLogin()
  if botPC() or not ns.WeekOneSharing() or not ns.WeekOneHelper() or not ns.tracksGuild() or not date then return end
  local w, now = store(), time()
  for k = 0, 8 do
    local day = date("!%Y%m%d", now - k * DAY)
    if w.slots[day] or w.cover[day] then shareCover(w, day) end
  end
  shareDays(w)
end
local function helperSender(sender)
  return botPC() and ns.tracksGuild() and ns.inRoster(sender) and ns.WeekOneHelper(sender)
    and ns.shortName(sender) ~= ns.shortName(ns.me() or "")
end
-- A real UTC day from tomorrow back to the cover window ("20261131" isn't one), from a set made once a day.
local recent = { today = nil, days = {} }
local function recentDay(day)
  if type(day) ~= "string" or not date then return false end
  local now = time()
  local today = date("!%Y%m%d", now)
  if recent.today ~= today then
    recent.today, recent.days = today, {}
    for k = -1, ns.WEEK1_COVER_DAYS do recent.days[date("!%Y%m%d", now - k * DAY)] = true end
  end
  return recent.days[day] == true
end
ns.handlers.W1C = function(sender, channel, day, reads, slots)
  if channel ~= "GUILD" or not helperSender(sender) or not recentDay(day) then return end
  local n = tonumber(reads)
  if not n or n ~= n or n < 0 or n > 96 * 4 then return end -- a few helpers on one PC at most
  if type(slots) ~= "string" or not slots:match("^[0-9a-f]+$") or #slots ~= 24 then return end
  local w = store()
  w.peerCover[day] = math.max(tonumber(w.peerCover[day]) or 0, math.min(math.floor(n), 96))
  w.peerSlots[day] = slotsOr(w.peerSlots[day], slots)
  ns.WeekOneMerge(w, day)
end
-- Finished days only from officers (red team, #568: anyone who can edit public notes could name a buddy), and never
-- more newcomers than this roster first saw on or after that day.
ns.handlers.W1D = function(sender, channel, day, fields)
  if channel ~= "GUILD" or not helperSender(sender) or not ns.isOfficer(sender) or not recentDay(day)
    or type(fields) ~= "string" then
    return
  end
  local row, known = {}, {}
  for _, k in ipairs(DAY_FIELDS) do known[k] = true end
  for k, v in fields:gmatch("(%w+)=(%d+)") do
    if known[k] then row[k] = math.min(tonumber(v), 1000) end
  end
  -- weekone.py's checks before keeping it: every part within its whole, ed7 <= min(d7, e), da <= na, and the
  -- Discord split adding up only when vl = 1. A row that fails is refused, so one bad sender can't skew D7.
  local n = row.n
  if not n or n < 1 then return end
  local start = time() - time() % DAY -- the day's start (UTC): recentDay keeps it within 60 days of today
  while date("!%Y%m%d", start) > day do start = start - DAY end
  local since = 0
  for _, m in pairs(members()) do
    if type(m) == "table" and (ns.finite(m.first) or 0) >= start then since = since + 1 end
  end
  if n > since then return end
  for k, v in pairs(row) do if k ~= "v" and k ~= "vl" and v > n then return end end
  local z = function(k) return row[k] or 0 end
  if not (z("ab3") <= z("a3") and z("a3") <= z("a")) then return end
  if row.d7 and not (z("ed7") <= math.min(z("d7"), z("e")) and z("da") <= z("na")) then return end
  if row.vl == 1 and not (z("na") + z("nl") + z("nx") == n and z("da") + z("dl") + z("dx") == z("d7")
    and z("dl") <= z("nl") and z("dx") <= z("nx")) then return end
  local w = store()
  local old = w.peerDays[day]
  local on, od = type(old) == "table" and tonumber(old.n) or -1, type(old) == "table" and tonumber(old.d7) or -1
  if n > on or (n == on and (row.d7 or -1) > od) then w.peerDays[day] = row end
  ns.WeekOneMerge(w, day)
end

local f = CreateFrame("Frame")
ns.listen(f, { "GROUP_ROSTER_UPDATE", "PLAYER_ENTERING_WORLD" })
f:SetScript("OnEvent", ns.guard(function(_, event)
  if not (UW_GuildDB and ns.inOurGuild and ns.inOurGuild()) then return end
  if event == "GROUP_ROSTER_UPDATE" then
    ns.protect(noteGroup)
  else
    ns.protect(learnInstance)
  end
end))
ns.afterRoster(function()
  ns.after(30, function() ns.protect(loginLine) end)
  ns.after(45, function() ns.protect(shareAtLogin) end)
  -- The group finder may know nothing yet right after login: read it once at 20 s, and once more at 120 s if empty.
  ns.after(20, function()
    if ns.LearnGameDungeons() == 0 then ns.after(100, ns.LearnGameDungeons) end -- nil: no API, nothing to retry
  end)
end)
