-- Week one (Louis, 8 Nov 2026): help every new guildmate play with guildmates in their first week, and measure it.
-- Newcomers who never group drift off: playing alongside others isn't playing with them (Ducheneaut, Yee, Nickell &
-- Moore 2006), and early contact from existing members is what keeps newcomers (Kraut & Resnick 2012). Discord's LFG
-- went unused, and on 8 Nov 3 of 150 guildmates ran UW_Guild, so this reads the guild roster, which every client has.
--   * Measure, counts only. An officer's or welcome buddy's client reads the roster once per 15-minute slot. Two or
--     more guildmates online in one dungeon or raid count as grouped (an instance holds one group; two guild groups in
--     one dungeon at once are rare at our size, so it can overcount a little). The helper's own group counts too, and
--     so does a newcomer's own UW_Guild report (GRP, Onboarding.lua).
--   * Names stay on this PC only until the newcomer's day 8, to keep the grouped off /uw new. Then the newcomer is
--     added to their join day's counts and the name goes. The bot reads counts only (bot/uwbot/weekone.py).
--   * Act through people. /uw new lists newcomers online now with no guild group seen yet, each with their buddy and
--     up to two online guildmates near their level, so an officer or buddy can invite them. It never contacts the
--     newcomer. At login, helpers get one line saying how many are waiting (/uw new off stops it).
-- UW_GuildDB.weekOne = { slot, through, off, seen = { [name] = time }, inst = { [zone] = true },
--   days = { ["YYYYMMDD"] = { n, g3, g7, s3, s0, q, a, a3, ab3, p3n } },
--   live = { at, new, grouped, quiet, waiting, addon } }
local _, ns = ...
local say = ns.say

local DAY, SLOT = 86400, 900
ns.WEEK1_DAYS = 7         -- a newcomer's first week
ns.WEEK1_FINAL_DAYS = 8   -- counted once day 7 is over, so "still playing on day 7" can be read
ns.WEEK1_GROUP_DAYS = 3   -- the playbook goal: grouped with guildmates within 72 hours
ns.WEEK1_QUIET_DAYS = 2   -- not seen for this long with no group yet: going quiet
ns.WEEK1_NEAR = 3         -- levels either side for "near them"
ns.WEEK1_KEEP_DAYS = 120  -- join-day counts kept this long
ns.WEEK1_SHOW = 8         -- house style: lists of 8 lines at most
ns.WEEK1_INST_MAX = 80    -- learned instance names kept
-- Dungeons and raids as the roster names them. A zone a helper's own client enters as a party or raid instance is
-- learned too (weekOne.inst), so a dungeon Forever adds or renames counts without an update.
ns.INSTANCE_ZONES = {}
for _, z in ipairs({ "Ragefire Chasm", "Wailing Caverns", "The Deadmines", "Shadowfang Keep", "Blackfathom Deeps",
  "The Stockade", "Gnomeregan", "Razorfen Kraul", "Scarlet Monastery", "Razorfen Downs", "Uldaman", "Zul'Farrak",
  "Maraudon", "The Temple of Atal'Hakkar", "Sunken Temple", "Blackrock Depths", "Blackrock Spire", "Dire Maul",
  "Stratholme", "Scholomance", "Molten Core", "Onyxia's Lair", "Blackwing Lair", "Zul'Gurub", "Ruins of Ahn'Qiraj",
  "Ahn'Qiraj", "Temple of Ahn'Qiraj", "Naxxramas", "Hyjal Summit", "Barrow Deeps" }) do
  ns.INSTANCE_ZONES[z] = true
end

local function store()
  local w = UW_GuildDB.weekOne
  if type(w) ~= "table" then w = {}; UW_GuildDB.weekOne = w end
  for _, k in ipairs({ "seen", "days", "inst" }) do if type(w[k]) ~= "table" then w[k] = {} end end
  return w
end

local function members() return type(UW_GuildDB.members) == "table" and UW_GuildDB.members or {} end

-- Officers, and members whose public guild note names the Welcome buddy job (Onboarding.lua ns.JOBS).
function ns.WeekOneHelper()
  local full = ns.me()
  if not full then return false end
  if ns.isOfficer(full) then return true end
  local m = members()[ns.shortName(full)]
  if type(m) ~= "table" or not ns.NoteJobs then return false end
  for _, k in ipairs(ns.NoteJobs(m.note)) do if k == "buddy" then return true end end
  return false
end

-- A guildmate in their first `days` days who joined after this account's addon started (ns.isRecruit) or holds Trial.
-- A guildmate the addon hasn't recorded yet (a join a moment ago, grouped before the next roster read) is no newcomer
-- yet: m is nil (Louis's log, 8 Nov: "attempt to index local 'm'" when El Bonacho joined his group).
local function newcomer(name, m, now, days)
  local first = type(m) == "table" and ns.finite(m.first)
  if not first then return false end
  return not m.left and now - first < (days or ns.WEEK1_DAYS) * DAY and ns.isRecruit(name)
end

-- Earliest group with a guildmate seen for this member: their own UW_Guild's report or this client's.
local function groupedAt(w, name, m)
  local a, b = ns.finite(m.firstGroup), ns.finite(w.seen[name])
  if a and b then return math.min(a, b) end
  return a or b
end

local function mark(w, name, now)
  if not name or w.seen[name] then return end
  if newcomer(name, members()[name], now, ns.WEEK1_FINAL_DAYS) then w.seen[name] = now end
end

local function isInstance(w, zone) return zone ~= nil and (ns.INSTANCE_ZONES[zone] or w.inst[zone]) and true or false end

local function inc(d, k) d[k] = (tonumber(d[k]) or 0) + 1 end

-- Adds one newcomer to their join day's counts: n joined; g3/g7 grouped within 3/7 days; s3/s0 still playing on day 7
-- having grouped within 3 days or not; q gone by day 7 without ever grouping.
-- Calibration, so the guild-wide rate can be corrected as more members run UW_Guild: a runs it; a3 of those reported
-- their own group within 3 days (GRP: the truth for them); ab3 of a3 the roster also caught; p3n newcomers without
-- UW_Guild the roster caught within 3 days. The bot divides p3n by the roster's hit rate ab3/a3 (weekone.py).
local function count(w, name, m, first)
  local d = w.days[date("!%Y%m%d", first)]
  if type(d) ~= "table" then d = {}; w.days[date("!%Y%m%d", first)] = d end
  local g = groupedAt(w, name, m)
  local g3 = g ~= nil and g - first <= ns.WEEK1_GROUP_DAYS * DAY
  local g7 = g ~= nil and g - first <= ns.WEEK1_DAYS * DAY
  local left = ns.finite(m.left)
  local stayed = (ns.finite(m.seen) or 0) >= first + ns.WEEK1_DAYS * DAY
    and not (left and left < first + ns.WEEK1_DAYS * DAY)
  inc(d, "n")
  if g3 then inc(d, "g3") end
  if g7 then inc(d, "g7") end
  if stayed then inc(d, g3 and "s3" or "s0") end
  if not g7 and not stayed then inc(d, "q") end
  local own, seen = ns.finite(m.firstGroup), ns.finite(w.seen[name])
  local seen3 = seen ~= nil and seen - first <= ns.WEEK1_GROUP_DAYS * DAY
  if ns.finite(m.addon) then
    inc(d, "a")
    if own and own - first <= ns.WEEK1_GROUP_DAYS * DAY then
      inc(d, "a3")
      if seen3 then inc(d, "ab3") end
    end
  elseif seen3 then
    inc(d, "p3n")
  end
end

-- Newcomers whose day 8 has passed go into the counts once. Only joins after this client started measuring count
-- (w.through starts then): earlier ones were never watched, so they would look like nobody grouped.
local function finalize(w, now)
  local through = ns.finite(w.through)
  if not through then w.through = now return end
  local cutoff = now - ns.WEEK1_FINAL_DAYS * DAY
  if cutoff <= through then return end
  for name, m in pairs(members()) do
    local first = type(m) == "table" and ns.finite(m.first)
    if first and first > through and first <= cutoff and ns.isRecruit(name) then count(w, name, m, first) end
  end
  w.through = cutoff
  for name in pairs(w.seen) do
    local m = members()[name]
    local first = type(m) == "table" and ns.finite(m.first)
    if not first or first <= cutoff then w.seen[name] = nil end -- counted (or gone): the name isn't needed any more
  end
  local oldest = date("!%Y%m%d", now - ns.WEEK1_KEEP_DAYS * DAY)
  for k in pairs(w.days) do if type(k) ~= "string" or k < oldest then w.days[k] = nil end end
end

-- This week so far, counts only: newcomers, how many grouped, how many went quiet first, how many are online solo.
local function live(w, online, now)
  local out = { at = now, new = 0, grouped = 0, quiet = 0, waiting = 0, addon = 0 }
  for name, m in pairs(members()) do
    if newcomer(name, m, now) then
      out.new = out.new + 1
      if ns.finite(m.addon) then out.addon = out.addon + 1 end
      if groupedAt(w, name, m) then
        out.grouped = out.grouped + 1
      elseif online[name] then
        out.waiting = out.waiting + 1
      elseif now - (ns.finite(m.seen) or ns.finite(m.first) or now) >= ns.WEEK1_QUIET_DAYS * DAY then
        out.quiet = out.quiet + 1
      end
    end
  end
  return out
end

-- Core.lua calls this after each complete roster read (rows: name, level, online, zone).
local noDateTold
function ns.WeekOneSample(rows, now)
  if not ns.WeekOneHelper() then return end
  if not date then
    if not noDateTold then noDateTold = true ns.trace("week1", "sample", false, "no date() on this client") end
    return
  end
  local w = store()
  local slot = math.floor(now / SLOT)
  if w.slot == slot then return end -- one sample per slot, also across /reload
  w.slot = slot
  local byZone, online = {}, {}
  for _, r in ipairs(rows) do
    if r.online then
      online[r.name] = true
      if isInstance(w, r.zone) then
        byZone[r.zone] = byZone[r.zone] or {}
        table.insert(byZone[r.zone], r.name)
      end
    end
  end
  for _, list in pairs(byZone) do
    if #list >= 2 then for _, n in ipairs(list) do mark(w, n, now) end end
  end
  finalize(w, now)
  w.live = live(w, online, now)
  local seen = 0
  for _ in pairs(online) do seen = seen + 1 end
  ns.trace("week1", "sample", true, seen .. " online")
end

-- The helper's own group: every guildmate in it, and the helper too when there is one.
local function noteGroup()
  if not IsInGroup() or not ns.WeekOneHelper() then return end
  local w, now, raid, any = store(), time(), IsInRaid(), false
  for i = 1, raid and GetNumGroupMembers() or math.max(0, GetNumGroupMembers() - 1) do
    local unit = (raid and "raid" or "party") .. i
    local full = ns.unitFull(unit) -- first name and surname, as the members keys hold them (not UnitName's first part)
    if full and UnitIsInMyGuild(unit) and not UnitIsUnit(unit, "player") then
      mark(w, ns.shortName(full), now)
      any = true
    end
  end
  if any then mark(w, ns.shortName(ns.me() or ""), now) end
end

local function learnInstance()
  if not (IsInInstance and GetRealZoneText) or not ns.WeekOneHelper() then return end
  local inside, kind = IsInInstance()
  local zone = GetRealZoneText()
  if not inside or (kind ~= "party" and kind ~= "raid") or type(zone) ~= "string" or ns.isSecret(zone) or zone == "" then return end
  local w, n = store(), 0
  if w.inst[zone] or ns.INSTANCE_ZONES[zone] then return end
  for _ in pairs(w.inst) do n = n + 1 end
  if n < ns.WEEK1_INST_MAX then w.inst[zone] = true end
end

-- Online newcomers with no guild group seen yet, longest in the guild first, each with up to two guildmates near them.
function ns.WeekOneWaiting()
  local w, now, rows, me = store(), time(), {}, ns.shortName(ns.me() or "")
  for i = 1, GetNumGuildMembers() do
    local full, _, _, level, _, zone, _, _, online = GetGuildRosterInfo(i)
    if online and type(full) == "string" and not ns.isSecret(full) and level then
      if type(zone) ~= "string" or ns.isSecret(zone) then zone = nil end
      rows[#rows + 1] = { full = full, name = ns.shortName(full), level = level, zone = zone }
    end
  end
  local out, byName = {}, {}
  for _, r in ipairs(rows) do byName[r.name] = r end
  for _, r in ipairs(rows) do
    local m = members()[r.name]
    if r.name ~= me and newcomer(r.name, m, now) and not groupedAt(w, r.name, m) then
      local near = {}
      for _, o in ipairs(rows) do
        if o.name ~= r.name and o.name ~= me and math.abs(o.level - r.level) <= ns.WEEK1_NEAR then near[#near + 1] = o end
      end
      table.sort(near, function(a, b)
        local za, zb = a.zone == r.zone, b.zone == r.zone
        if za ~= zb then return za end
        local da, db = math.abs(a.level - r.level), math.abs(b.level - r.level)
        if da ~= db then return da < db end
        return a.name < b.name
      end)
      local pair = type(UW_GuildDB.buddies) == "table" and UW_GuildDB.buddies[r.name]
      local buddy = type(pair) == "table" and byName[pair.buddy] or nil
      out[#out + 1] = { row = r, day = math.floor((now - m.first) / DAY) + 1, buddy = buddy,
        near = { near[1], near[2] } }
    end
  end
  table.sort(out, function(a, b) if a.day ~= b.day then return a.day > b.day end return a.row.name < b.row.name end)
  return out
end

local function link(r) return ("|Hplayer:%s|h[%s]|h"):format(r.full, r.name) end

local function weekLine(w)
  local l = type(w.live) == "table" and w.live or nil
  if not l or not ns.finite(l.new) then return end
  say(("This week: %d joined, %d grouped with guildmates, %d quiet %d+ days with no group yet."):format(l.new,
    ns.finite(l.grouped) or 0, ns.finite(l.quiet) or 0, ns.WEEK1_QUIET_DAYS))
end

ns.commands.new = function(args)
  args = strtrim(args or ""):lower()
  if not ns.WeekOneHelper() then
    say("/uw new is for officers and welcome buddies. Want to help newcomers find a group? /uw jobs shows how.")
    return
  end
  local w = store()
  if args == "off" or args == "on" then
    w.off = args == "off" or nil
    say(w.off and "No login line about newcomers. /uw new still lists them; /uw new on brings the line back."
      or "At login you'll see how many newcomers online haven't grouped yet.")
    return
  end
  local list = ns.WeekOneWaiting()
  if #list == 0 then
    say("No newcomer online right now is still waiting for a group with the guild.")
  else
    say(("%d newcomer%s online with no guild group yet. Click a name to whisper or invite:"):format(#list,
      #list == 1 and "" or "s"))
    for i = 1, math.min(#list, ns.WEEK1_SHOW) do
      local e, r = list[i], list[i].row
      local near = {}
      for _, o in ipairs(e.near) do near[#near + 1] = ("%s %d"):format(link(o), o.level) end
      say(("%s %d, %s, day %d%s%s"):format(link(r), r.level, r.zone or "?", e.day,
        e.buddy and (" · buddy " .. link(e.buddy)) or "",
        #near > 0 and (" · near: " .. table.concat(near, ", ")) or ""))
    end
    if #list > ns.WEEK1_SHOW then say(("...and %d more."):format(#list - ns.WEEK1_SHOW)) end
    -- For the helper to type when they group up, never sent by the addon (Louis, 8 Nov: no addon whispers).
    say(("Grouped with someone who lacks UW_Guild? Tell them: Our guild addon is free and takes 2 minutes: %s")
      :format(ns.ADDON_URL))
  end
  weekLine(w)
end

local told -- once a session
local function loginLine()
  if told or not ns.WeekOneHelper() or store().off then return end
  local n = #ns.WeekOneWaiting()
  if n == 0 then return end
  told = true
  -- "seen": only dungeons and the helper's own group count, so open-world questing together still reads as waiting.
  say(("%d newcomer%s online with no guild group seen yet. /uw new shows who's near them."):format(n,
    n == 1 and "" or "s"))
end

local f = CreateFrame("Frame")
ns.listen(f, { "GROUP_ROSTER_UPDATE", "PLAYER_ENTERING_WORLD" })
f:SetScript("OnEvent", function(_, event)
  if not (UW_GuildDB and ns.inOurGuild and ns.inOurGuild()) then return end
  if event == "GROUP_ROSTER_UPDATE" then
    ns.protect(noteGroup)
  else
    ns.protect(learnInstance)
  end
end)
ns.afterRoster(function() C_Timer.After(30, function() ns.protect(loginLine) end) end)
