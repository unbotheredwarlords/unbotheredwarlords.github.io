-- Week one (Louis, 8 Nov 2026): help every new guildmate play with guildmates in their first week, and measure it.
-- Newcomers who never group drift off: playing alongside others isn't playing with them (Ducheneaut, Yee, Nickell &
-- Moore 2006), and early contact from existing members is what keeps newcomers (Kraut & Resnick 2012). Discord's LFG
-- went unused, and on 8 Nov 3 of 150 guildmates ran UW_Guild, so this reads the guild roster, which every client has.
--   * Measure, counts only. An officer's or welcome buddy's client reads the roster once per 15-minute slot. Two or
--     more guildmates online in one dungeon or raid count as grouped (an instance holds one group; two guild groups in
--     one dungeon at once are rare at our size, so it can overcount a little). The helper's own group counts too, and
--     so does a newcomer's own UW_Guild report (GRP, Onboarding.lua).
--   * Names stay on this PC only until the newcomer's day 8, to keep the grouped off /uw new. Then the newcomer is
--     added to their join day's counts and the name goes. The bot reads counts only (bot/uwbot/weekone.py).
--   * Act through people. /uw new lists newcomers online now with no guild group seen yet, each with their buddy and
--     up to two online guildmates near their level, so an officer or buddy can invite them. It never contacts the
--     newcomer. At login, helpers get one line saying how many are waiting, and officers one line when a newcomer with
--     no guild dungeon seen comes online later (/uw new off stops both).
--   * One helper's list per newcomer (people-shift audit, 13 Nov 2026: AFK newcomers listed as waiting, several
--     helpers approaching the same quiet one, and no way to say "no thanks"; low-level solo play is normal, Ducheneaut
--     et al. 2006). Each PC works out from its own roster which online helper (officer or buddy note, heard running
--     UW_Guild in the last WEEK1_HEARD_DAYS, not AFK or DND; always this character) has the highest hash of
--     helper and newcomer, and lists only its own (rendezvous hashing). Nothing about a newcomer is sent anywhere.
--     AFK and DND newcomers aren't waiting. A newcomer this character whispered or invited (weekOne.approached) is
--     marked on its /uw new and left off its suggested call for 24 hours; /uw new no marks one who'd rather not group
--     (weekOne.noThanks), off this PC's lists. Both stay on this PC and go at day 8, like seen; a join day this version
--     starts also counts ap (reached out to in week one), apq (of those, gone by day 7) and nt (no thanks). D7 counts
--     everyone as before.
--     Limits: a helper logging in takes over about 1 in k of the newcomers (k helpers on), so one already approached
--     can show on a new list; a no-thanks mark lives only on the PC that set it. A helper not heard running UW_Guild
--     is left out, so when PCs disagree a newcomer shows on two lists; on none only while a helper heard this week
--     plays without it.
-- UW_GuildDB.weekOne = { slot, through, off, seen = { [name] = time }, dungeon = { [name] = time },
--   inst = { [zone] = true }, cover = { ["YYYYMMDD"] = samples },
--   days = { ["YYYYMMDD"] = { n, g3, g7, s3, s0, q, a, a3, ab3, p3n, v, d7, e, ed7, na, da, vl, nl, dl, nx, dx } },
--   live = { at, new, grouped, quiet, waiting, addon, dungeon, eligible, edungeon },
--   together = { ["A|B"] = time } (Discord-linked pairs read in one instance; noteTogether) }
-- First dungeon (Louis, 8 Nov 23:22: priority 1; definition in project file journeys/first-dungeon-metric.md):
-- "dungeon" holds only instance-zone reads, plus the helper's own group while the helper is inside an instance.
-- "seen" stays any guild group. A join day made by this version carries v = 2 and starts its first-dungeon fields at 0,
-- so the bot reads an older day's missing fields as missing, never as 0; vl = 1 likewise when the Discord split
-- (ns.LINKED from the bot's Schedule.lua) was known.
local _, ns = ...
local say = ns.say

local DAY, SLOT = 86400, 900
ns.WEEK1_DAYS = 7         -- a newcomer's first week
ns.WEEK1_FINAL_DAYS = 8   -- counted once day 7 is over, so "still playing on day 7" can be read
ns.WEEK1_GROUP_DAYS = 3   -- the playbook goal: grouped with guildmates within 72 hours
ns.WEEK1_QUIET_DAYS = 2   -- not seen for this long with no group yet: going quiet
ns.WEEK1_NEAR = 3         -- levels either side for "near them"
ns.WEEK1_KEEP_DAYS = 120  -- join-day counts kept this long
ns.WEEK1_SHOW = 8         -- house style: lists of 8 lines at most
ns.WEEK1_INST_MAX = 80    -- learned instance names kept
ns.WEEK1_ZONE_MAX = 150   -- distinct roster zone strings tallied (weekOne.zones): every zone and instance fits
ns.WEEK1_DUNGEON_LEVEL = 13 -- Ragefire Chasm, the lowest dungeon: "eligible" for a first dungeon
ns.WEEK1_COVER_DAYS = 60  -- helper samples per day kept (coverage, so more helpers isn't read as more dungeons)
-- Dungeons and raids as the roster names them. A zone a helper's own client enters as a party or raid instance is
-- learned too (weekOne.inst), so a dungeon Forever adds or renames counts without an update.
ns.INSTANCE_ZONES = {}
for _, z in ipairs({ "Ragefire Chasm", "Wailing Caverns", "The Deadmines", "Shadowfang Keep", "Blackfathom Deeps",
  "The Stockade", "Gnomeregan", "Razorfen Kraul", "Scarlet Monastery", "Razorfen Downs", "Uldaman", "Zul'Farrak",
  "Maraudon", "The Temple of Atal'Hakkar", "Sunken Temple", "Blackrock Depths", "Blackrock Spire", "Dire Maul",
  "Stratholme", "Scholomance", "Molten Core", "Onyxia's Lair", "Blackwing Lair", "Zul'Gurub", "Ruins of Ahn'Qiraj",
  "Ahn'Qiraj", "Temple of Ahn'Qiraj", "Naxxramas", "Hyjal Summit", "Barrow Deeps",
  -- Forever's nine new dungeons (Blizzard, "Explore the New Dungeons of World of Warcraft: Forever"), with the other
  -- spellings guides use, since the roster's exact names were never read on our client. The game's own list below
  -- adds the names the client really uses.
  "Hall of Thanes", "The Hall of Thanes", "Ruins of Lordaeron", "Excavation Site", "Excavation Site: Wetlands",
  "City of Dalaran", "The Drowned City", "Drowned City", "Krol'dok Stronghold", "Alcaz Prison", "Alcaz Island Prison",
  "Blackmaw Hold", "Shaper's Terrace" }) do
  ns.INSTANCE_ZONES[z] = true
end

-- The game's own dungeon list (addon search, 13 Nov 2026: the nine above were missing everywhere, so a newcomer's
-- first dungeon in Ruins of Lordaeron counted only if a helper had happened to walk in first). Forever's group finder
-- lists every dungeon and raid with its instance map and suggested levels (C_LFGList; Blizzard's own finder builds
-- its list the same way). Once per session each instance's name as the roster shows it (GetRealZoneText(mapID)) joins
-- INSTANCE_ZONES, and a dungeon whose name matches a row of Lead.lua's ns.LEAD_DUNGEONS takes the game's suggested
-- levels, so a dungeon Forever adds, renames or retunes is counted and suggested right with no UW_Guild update.
-- Read only, every call protected; a client without the API, or one that answers nothing yet, keeps the lists above.
-- What it read is kept in UW_GuildDB.gameDungeons (names and levels, no player data) so a save shows it.
ns.GAME_DUNGEON_CATEGORIES = { 2, 114 } -- the group finder's Dungeons and Raids (LFGVanilla_Constants.lua)
ns.GAME_DUNGEONS_MAX = 80
local function plainKey(s) return (s:lower():gsub("['`]", ""):gsub("[%p%s]+", " "):gsub("^the ", ""):gsub("^ +", ""):gsub(" +$", "")) end
local function readable(v) return v ~= nil and not ns.isSecret(v) and v or nil end
local function call(fn, ...)
  if type(fn) ~= "function" then return nil end
  local ok, a = pcall(fn, ...)
  if ok then return readable(a) end
end
function ns.LearnGameDungeons()
  local L, zoneText = rawget(_G, "C_LFGList"), rawget(_G, "GetRealZoneText")
  if type(L) ~= "table" or type(L.GetAvailableActivities) ~= "function" or type(L.GetActivityInfoTable) ~= "function"
    or type(zoneText) ~= "function" then
    ns.trace("week1", "game dungeons", false, "no group finder API")
    return nil
  end
  local rows, byKey, seen, n, retuned = {}, {}, {}, 0, 0
  for _, d in ipairs(ns.LEAD_DUNGEONS or {}) do byKey[plainKey(d[1])] = d end
  for _, cat in ipairs(ns.GAME_DUNGEON_CATEGORIES) do
    local ids = call(L.GetAvailableActivities, cat)
    for _, id in ipairs(type(ids) == "table" and ids or {}) do
      local info = call(L.GetActivityInfoTable, id)
      local mapID = type(info) == "table" and readable(info.mapID)
      if type(mapID) == "number" and mapID > 0 and readable(info.isPvpActivity) ~= true and n < ns.GAME_DUNGEONS_MAX then
        local name = readable(info.fullName)
        local zone = call(zoneText, mapID)
        local lo = readable(info.minLevelSuggestion)
        local hi = readable(info.maxLevelSuggestion)
        if type(lo) ~= "number" or lo < 1 then lo = readable(info.minLevel) end
        local sane = type(lo) == "number" and type(hi) == "number" and lo >= 1 and lo <= hi and hi <= 60
        -- Only a zone whose name is part of the activity's ("Scarlet Monastery" of "Scarlet Monastery - Graveyard"),
        -- so a map the client doesn't know can never make a city or an outdoor zone count as a dungeon.
        local zk, nk = type(zone) == "string" and plainKey(zone) or "", type(name) == "string" and plainKey(name) or ""
        if zk ~= "" and nk ~= "" and (nk:find(zk, 1, true) or zk:find(nk, 1, true)) and not seen[zone] then
          seen[zone], n = true, n + 1
          ns.INSTANCE_ZONES[zone] = true
        end
        if type(name) == "string" and name ~= "" then
          rows[name:sub(1, 48)] = sane and ("%d-%d"):format(lo, hi) or "?"
          local d = byKey[plainKey(name)]
          if d and sane and (d[2] ~= lo or d[3] ~= hi) then d[2], d[3], retuned = lo, hi, retuned + 1 end
        end
      end
    end
  end
  if type(UW_GuildDB) == "table" then
    UW_GuildDB.gameDungeons = { at = time(), zones = n, retuned = retuned, list = rows }
  end
  ns.trace("week1", "game dungeons", n > 0, ("%d instances, %d levels from the game"):format(n, retuned))
  return n
end

local function store()
  local w = UW_GuildDB.weekOne
  if type(w) ~= "table" then w = {}; UW_GuildDB.weekOne = w end
  for _, k in ipairs({ "seen", "dungeon", "days", "inst", "nights", "cover", "on", "slots", "peerCover", "peerSlots",
    "peerDays", "coverAll", "zones", "together", "peerNights", "whoNight", "who7", "sit", "approached", "noThanks",
    "spoke", "withInviter" }) do
    if type(w[k]) ~= "table" then w[k] = {} end
  end
  return w
end

local function members() return type(UW_GuildDB.members) == "table" and UW_GuildDB.members or {} end

-- Officers, and members whose public guild note names the Welcome buddy job (Onboarding.lua ns.JOBS). name: anyone's
-- (a sender's full name, for the shared counts below); this character's own when nil.
function ns.WeekOneHelper(name)
  local full = name or ns.me()
  if not full then return false end
  if ns.isOfficer(full) then return true end
  local m = members()[ns.shortName(full)]
  if type(m) ~= "table" or not ns.NoteJobs then return false end
  for _, k in ipairs(ns.NoteJobs(m.note)) do if k == "buddy" then return true end end
  return false
end

-- When a newcomer joined, for week one. The roster first sees a joiner only while some UW_Guild client plays, so
-- m.first is the next login after the join: a joiner while nobody was on would get a later join day and a 7-day window
-- that starts after a first dungeon nobody saw (D7 readout check, 9 Nov). The guild event log's invite dates it
-- better (Onboarding.lua, UW_GuildDB.invites; recruiters.py credits the same one): the latest invite at or before the
-- roster's first sight, with an hour's slack as the log says "N hours ago", from up to WEEK1_JOIN_LOOKBACK days before.
-- Otherwise m.first. A rejoin keeps its old m.first and has no invite before it, so it stays out as before.
-- An invite at or before m.w1prior is never the one they joined on: m.w1prior is the last full helper read before the
-- roster first saw them (WeekOneSample stamps it once), and they weren't in the guild then. Such an invite is an older
-- one they declined; dated by it, they could fall before weekOne.through and never be counted (red team, #534 LOW).
-- The log's "N hours ago" only ever makes an invite look later than it was, so a real one is never refused this way.
ns.WEEK1_JOIN_LOOKBACK = 14
-- The invite they joined on, as above: its time and who sent it (the event log's name), or nil.
local function joinInvite(name, m, first)
  local list, best, by = type(UW_GuildDB.invites) == "table" and UW_GuildDB.invites[name], nil, nil
  local floor = math.max(ns.finite(m.w1prior) or 0, first - ns.WEEK1_JOIN_LOOKBACK * DAY)
  for _, e in ipairs(type(list) == "table" and list or {}) do
    local at = type(e) == "table" and ns.finite(e.at)
    if at and at <= first + 3600 and at > floor and (not best or at > best) then
      best, by = at, type(e.by) == "string" and e.by or nil
    end
  end
  return best, by
end
local function joined(name, m)
  local first = type(m) == "table" and ns.finite(m.first)
  if not first then return nil end
  local best = joinInvite(name, m, first)
  return best and math.min(best, first) or first
end
ns.WeekOneJoined = joined
-- Who invited them, when that invite is the one they joined on and it wasn't Louis's (harvest item 7, 13 Nov 2026:
-- the member who invited a newcomer is a person already standing behind them). nil otherwise.
local function inviterOf(name, m)
  local first = type(m) == "table" and ns.finite(m.first)
  if not first then return nil end
  local _, by = joinInvite(name, m, first)
  if not by or ns.isSecret(by) or ns.IsLouis(by) then return nil end
  return by
end

-- A guildmate in their first `days` days who joined after this account's addon started (ns.isRecruit) or holds Trial.
-- A guildmate the addon hasn't recorded yet (a join a moment ago, grouped before the next roster read) is no newcomer
-- yet: m is nil (Louis's log, 8 Nov: "attempt to index local 'm'" when El Bonacho joined his group).
local function newcomer(name, m, now, days)
  local first = joined(name, m)
  if not first then return false end
  return not m.left and now - first < (days or ns.WEEK1_DAYS) * DAY and ns.isRecruit(name)
end

-- Earliest group with a guildmate seen for this member: their own UW_Guild's report or this client's.
local function groupedAt(w, name, m)
  local a, b = ns.finite(m.firstGroup), ns.finite(w.seen[name])
  if a and b then return math.min(a, b) end
  return a or b
end

local function mark(w, name, now)
  if not name or w.seen[name] then return end
  if newcomer(name, members()[name], now, ns.WEEK1_FINAL_DAYS) then w.seen[name] = now end
end

-- A dungeon with a guildmate, for the first-dungeon count: instance-zone reads only.
local function markDungeon(w, name, now)
  if not name or w.dungeon[name] then return end
  if newcomer(name, members()[name], now, ns.WEEK1_FINAL_DAYS) then w.dungeon[name] = now end
end

-- Characters linked in Discord (the bot writes ns.LINKED into Schedule.lua on the Guild Master's PC; never shared).
-- nil when this client has no list: then the Discord split isn't counted at all.
local function linkedSet()
  if type(ns.LINKED) ~= "table" then return nil end
  local out = {}
  for _, n in ipairs(ns.LINKED) do
    if type(n) == "string" then out[(n:lower():gsub("[%s%-]+", " "))] = true end
  end
  return out
end

-- Two Discord-linked guildmates read in one dungeon or raid at once: "A|B" (sorted) -> when, kept TOGETHER_DAYS. The bot
-- reads it only to close its match introductions as grouped (bot/uwbot/profiles.py label_game_pairs): the guild groups
-- in game, and Discord's /lfg, which the bot used to count, goes unused (13 Nov). Linked characters only, on this PC.
ns.WEEK1_TOGETHER_DAYS = 15
local function noteTogether(w, byZone, now)
  local linked = linkedSet()
  if linked then
    for _, list in pairs(byZone) do
      local ln = {}
      for _, n in ipairs(list) do
        if linked[(n:lower():gsub("[%s%-]+", " "))] then table.insert(ln, n) end
      end
      table.sort(ln)
      for i = 1, #ln - 1 do
        for j = i + 1, #ln do w.together[ln[i] .. "|" .. ln[j]] = now end
      end
    end
  end
  for k, t in pairs(w.together) do
    if type(k) ~= "string" or not ns.finite(t) or t < now - ns.WEEK1_TOGETHER_DAYS * DAY then w.together[k] = nil end
  end
end

-- A first-week newcomer seen with the guildmate who invited them (harvest item 7), in one dungeon at once or in this
-- helper's group: weekOne.withInviter[name] = the first time, on this PC only, dropped at day 8 like w.seen. Counted
-- as ivg on their join day; the name never leaves the PC.
local function noteInviter(w, list, now)
  if #list < 2 then return end
  local here = {}
  for _, n in ipairs(list) do here[n] = true end
  for _, n in ipairs(list) do
    local m = members()[n]
    if w.withInviter[n] == nil and newcomer(n, m, now) then
      local by = inviterOf(n, m)
      if by and here[by] then w.withInviter[n] = now end
    end
  end
end

local function isInstance(w, zone) return zone ~= nil and (ns.INSTANCE_ZONES[zone] or w.inst[zone]) and true or false end
-- The same test for other files (Lead.lua's suggested call and helpers), learned zones included.
function ns.IsInstanceZone(zone)
  local w = type(UW_GuildDB) == "table" and type(UW_GuildDB.weekOne) == "table" and UW_GuildDB.weekOne or nil
  return type(zone) == "string" and (ns.INSTANCE_ZONES[zone] or (w and type(w.inst) == "table" and w.inst[zone]))
    and true or false
end

local function inc(d, k) d[k] = (tonumber(d[k]) or 0) + 1 end

-- Adds one newcomer to their join day's counts: n joined; g3/g7 grouped within 3/7 days; s3/s0 still playing on day 7
-- having grouped within 3 days or not; q gone by day 7 without ever grouping.
-- Calibration, so the guild-wide rate can be corrected as more members run UW_Guild: a runs it; a3 of those reported
-- their own group within 3 days (GRP: the truth for them); ab3 of a3 the roster also caught; p3n newcomers without
-- UW_Guild the roster caught within 3 days. The bot divides p3n by the roster's hit rate ab3/a3 (weekone.py).
-- First dungeon: d7 in a dungeon with a guildmate within 7 days; e level 13+ when counted (day 8, so a day late at
-- most); ed7 both. Exclusive segments: a (UW_Guild since joining), l (linked in Discord, not a), x (neither); n? joined
-- and d? of them with d7. Reaching out (only on a day that started with ap, so an older day's stay missing): ap this
-- character whispered or invited them in week one, apq of those not still playing on day 7, nt marked no thanks.
-- First words and inviters (only on a day that started with sp; harvest items 2 and 7, 13 Nov 2026): sp newcomers this
-- character heard in guild chat in week one, spr of those whose first heard line drew a line from someone else within
-- WEEK1_REPLY_SECS, spq and sprq of each not still playing on day 7; iv newcomers who joined on an invite from someone
-- other than Louis, ivg of those seen in a dungeon or a group with that inviter in week one.
-- Still here at 72h (only on a day that started with h3; audit finding 11, 14 Nov 2026): h3 newcomers seen on or after
-- hour 72 and not gone before it who grouped within 72h, h0 those who hadn't. Someone who leaves in the first hours
-- can't group, so s3/g3 against s0/(n - g3) flatters grouping; s3/h3 against s0/h0 compares only newcomers who were
-- still around when the 72h window closed (a landmark analysis: Anderson, Cain & Gelber 1983). Staying to day 7
-- implies being here at 72h, so s3 <= h3 <= g3 and s0 <= h0.
local function count(w, name, m, first, linked)
  local key = date("!%Y%m%d", first)
  local d = w.days[key]
  if type(d) ~= "table" then
    d = { v = 2, d7 = 0, e = 0, ed7 = 0, na = 0, da = 0, ap = 0, apq = 0, nt = 0, sp = 0, spr = 0, spq = 0, sprq = 0,
      iv = 0, ivg = 0, h3 = 0, h0 = 0 }
    if linked then d.vl, d.nl, d.dl, d.nx, d.dx = 1, 0, 0, 0, 0 end
    w.days[key] = d
  end
  local g = groupedAt(w, name, m)
  local g3 = g ~= nil and g - first <= ns.WEEK1_GROUP_DAYS * DAY
  local g7 = g ~= nil and g - first <= ns.WEEK1_DAYS * DAY
  local left = ns.finite(m.left)
  local stayed = (ns.finite(m.seen) or 0) >= first + ns.WEEK1_DAYS * DAY
    and not (left and left < first + ns.WEEK1_DAYS * DAY)
  inc(d, "n")
  if g3 then inc(d, "g3") end
  if g7 then inc(d, "g7") end
  if stayed then inc(d, g3 and "s3" or "s0") end
  if not g7 and not stayed then inc(d, "q") end
  if d.h3 ~= nil then -- a day an older version started: these stay missing, never 0
    local mark3 = first + ns.WEEK1_GROUP_DAYS * DAY
    if (ns.finite(m.seen) or 0) >= mark3 and not (left and left < mark3) then inc(d, g3 and "h3" or "h0") end
  end
  local own, seen = ns.finite(m.firstGroup), ns.finite(w.seen[name])
  local seen3 = seen ~= nil and seen - first <= ns.WEEK1_GROUP_DAYS * DAY
  if ns.finite(m.addon) then
    inc(d, "a")
    if own and own - first <= ns.WEEK1_GROUP_DAYS * DAY then
      inc(d, "a3")
      if seen3 then inc(d, "ab3") end
    end
  elseif seen3 then
    inc(d, "p3n")
  end
  if d.v ~= 2 then return end -- a day an older version started: its first-dungeon fields stay missing
  local dg = ns.finite(w.dungeon[name])
  local d7 = dg ~= nil and dg - first <= ns.WEEK1_DAYS * DAY
  local e = (ns.finite(m.lvl) or 0) >= ns.WEEK1_DUNGEON_LEVEL
  if d7 then inc(d, "d7") end
  if e then inc(d, "e") end
  if e and d7 then inc(d, "ed7") end
  local seg
  if (ns.finite(m.addon) or 0) >= first then seg = "a"
  elseif d.vl == 1 and linked then
    local k = (name:lower():gsub("[%s%-]+", " ")) -- as the bot's text.name_key; a bare first-name link counts too
    seg = (linked[k] or linked[k:match("^%S+") or k]) and "l" or "x"
  end
  if seg then
    inc(d, "n" .. seg)
    if d7 then inc(d, "d" .. seg) end
  end
  if d.ap == nil then return end
  local ap = ns.finite(w.approached[name])
  if ap and ap - first <= ns.WEEK1_DAYS * DAY then
    inc(d, "ap")
    if not stayed then inc(d, "apq") end
  end
  if w.noThanks[name] ~= nil then inc(d, "nt") end
  if d.sp == nil then return end
  local s = w.spoke[name]
  if type(s) == "table" and ns.finite(s.at) and s.at - first <= ns.WEEK1_DAYS * DAY then
    inc(d, "sp")
    if not stayed then inc(d, "spq") end
    if s.r then
      inc(d, "spr")
      if not stayed then inc(d, "sprq") end
    end
  end
  if inviterOf(name, m) then
    inc(d, "iv")
    local t = ns.finite(w.withInviter[name])
    if t and t - first <= ns.WEEK1_DAYS * DAY then inc(d, "ivg") end
  end
end

-- Newcomers whose day 8 has passed go into the counts once. Only joins after this client started measuring count
-- (w.through starts then): earlier ones were never watched, so they would look like nobody grouped.
local function finalize(w, now)
  local through = ns.finite(w.through)
  if not through then w.through = now return end
  local cutoff = now - ns.WEEK1_FINAL_DAYS * DAY
  if cutoff <= through then return end
  local linked = linkedSet()
  for name, m in pairs(members()) do
    local first = joined(name, m)
    if first and first > through and first <= cutoff and ns.isRecruit(name) then count(w, name, m, first, linked) end
  end
  w.through = cutoff
  for _, t in ipairs({ w.seen, w.dungeon, w.approached, w.noThanks, w.spoke, w.withInviter }) do
    for name in pairs(t) do
      local first = joined(name, members()[name])
      if not first or first <= cutoff then t[name] = nil end -- counted (or gone): the name isn't needed any more
    end
  end
  local oldest = date("!%Y%m%d", now - ns.WEEK1_KEEP_DAYS * DAY)
  for k in pairs(w.days) do if type(k) ~= "string" or k < oldest then w.days[k] = nil end end
end

-- This week so far, counts only: newcomers, how many grouped, how many went quiet first, how many are online solo,
-- and the first-dungeon count. Only joins after measuring began (w.through): earlier ones were never watched.
-- online[name]: true, or "away" (AFK or DND: not waiting; they fall through to the quiet test). No thanks: not waiting.
local function live(w, online, now)
  local out = { at = now, new = 0, grouped = 0, quiet = 0, waiting = 0, addon = 0, dungeon = 0, eligible = 0,
    edungeon = 0 }
  local through = ns.finite(w.through) or now
  for name, m in pairs(members()) do
    if newcomer(name, m, now) and joined(name, m) > through then
      out.new = out.new + 1
      if ns.finite(m.addon) then out.addon = out.addon + 1 end
      local dg, e = w.dungeon[name] ~= nil, (ns.finite(m.lvl) or 0) >= ns.WEEK1_DUNGEON_LEVEL
      if dg then out.dungeon = out.dungeon + 1 end
      if e then out.eligible = out.eligible + 1 end
      if dg and e then out.edungeon = out.edungeon + 1 end
      if groupedAt(w, name, m) then
        out.grouped = out.grouped + 1
      elseif online[name] == true and not w.noThanks[name] then
        out.waiting = out.waiting + 1
      elseif now - (ns.finite(m.seen) or ns.finite(m.first) or now) >= ns.WEEK1_QUIET_DAYS * DAY then
        out.quiet = out.quiet + 1
      end
    end
  end
  return out
end

-- Groups per night (Louis, 8 Nov: yes to a groups-per-night count), counts only, no names. A night runs 12:00 to 12:00
-- UTC, so an evening anywhere in the Americas or Europe stays in one night. Per night: f groups formed (a dungeon with
-- 2+ guildmates that wasn't one at the sample before; after a gap of more than 2 samples every group counts as new),
-- peak groups at once, q group quarter-hours (samples x groups), c calls this helper made or heard (typed or the Call
-- button, Lead.lua L.HeardCall), a answers to them.
-- Seen only while a helper plays, like the rest of this file: a floor, not a full count.
ns.WEEK1_NIGHT_KEEP = 60
local function nightKey(now) return date("!%Y%m%d", now - 12 * 3600) end
local function night(w, now)
  local k = nightKey(now)
  if type(w.nights[k]) ~= "table" then w.nights[k] = {} end
  return w.nights[k]
end

-- People counts (Louis approved the audit's section 8 on 13 Nov 2026: by 24 Nov, does anyone but Louis start or answer
-- groups, and do calls and asks draw answers?). Per night, counts only, on helpers' clients:
--   ca calls that drew at least one answer (once per call, at its first answer); g group asks heard (once per asker per
--   ask window), ga asks answered inside their window (Lead.lua L.CountAsk); cl calls by Louis; xo distinct people
--   other than Louis who called or answered this night, xm of them not officers; wo, wm the same over the 7 nights
--   ending this one; fn groups formed (f) with no call from Louis in the 90 minutes before.
ns.WEEK1_WHO_NIGHTS = 7
ns.WEEK1_LOUIS_BEFORE = 5400 -- fn: 90 minutes
local function onBotPC() return type(ns.SCHEDULE) == "table" and (tonumber(ns.SCHEDULE.gen) or 0) > 0 end
-- Who counts as Louis: the Guild Master's rank (index 0) on any client, and on the bot's PC this client's own character
-- (only Louis plays there, so everything typed on it is his). The limit: Louis's alts on lower ranks, heard on other
-- helpers' clients, count as other people.
function ns.IsLouis(name)
  local full = ns.fullName(name)
  if not full then return false end
  if ns.rankOf[full] == 0 then return true end
  return onBotPC() and ns.shortName(full) == ns.shortName(ns.me() or "")
end

-- Names of people who called or answered in guild chat (public lines) are kept on this PC for up to 7 nights, only so
-- each person counts once; only the counts are saved for the bot, which never reads these two tables.
-- whoNight = { key = night, [name] = true, or "o" for an officer }, emptied when the night changes;
-- who7 = { [name] = { n = the last night they called or answered, o = officer then } }, dropped after 7 nights.
local function pruneWho(w, now)
  local key = nightKey(now)
  if type(w.whoNight) ~= "table" or w.whoNight.key ~= key then w.whoNight = { key = key } end
  local oldest = nightKey(now - (ns.WEEK1_WHO_NIGHTS - 1) * DAY)
  for name, e in pairs(w.who7) do
    if type(e) ~= "table" or type(e.n) ~= "string" or e.n < oldest then w.who7[name] = nil end
  end
end
local function whoCounts(w, n)
  local xo, xm, wo, wm = 0, 0, 0, 0
  for name, v in pairs(w.whoNight) do
    if name ~= "key" then xo, xm = xo + 1, xm + (v == "o" and 0 or 1) end
  end
  for _, e in pairs(w.who7) do wo, wm = wo + 1, wm + (e.o and 0 or 1) end
  n.xo, n.xm, n.wo, n.wm = xo, xm, wo, wm
end

-- fn needs to know there was no Louis call in the 90 minutes before, so a helper's client counts it only once it has
-- heard guild chat that long this session (a group seen at login may follow a call made before it). On the bot's PC
-- every call of Louis's is made on this client and weekOne.louisCallAt is saved, so it counts from login.
local listenSince = time and time() or 0
local function noteNight(w, now, slot, byZone)
  local n, prev = night(w, now), (type(w.groupZones) == "table" and (tonumber(w.groupSlot) or 0) >= slot - 2)
    and w.groupZones or {}
  local knows = onBotPC() or now - listenSince >= ns.WEEK1_LOUIS_BEFORE
  local cur, groups = {}, 0
  for zone, list in pairs(byZone) do
    if #list >= 2 then
      cur[zone], groups = true, groups + 1
      if not prev[zone] then
        inc(n, "f")
        if knows and now - (tonumber(w.louisCallAt) or 0) > ns.WEEK1_LOUIS_BEFORE then inc(n, "fn") end
      end
    end
  end
  n.q = (tonumber(n.q) or 0) + groups
  n.p = math.max(tonumber(n.p) or 0, groups)
  w.groupZones, w.groupSlot = cur, slot
  local oldest = nightKey(now - ns.WEEK1_NIGHT_KEEP * DAY)
  for k in pairs(w.nights) do if type(k) ~= "string" or k < oldest then w.nights[k] = nil end end
  pruneWho(w, now) -- names don't outlive their night or 7 nights, even with no call since
end

-- Lead.lua, on a helper's client: a call made or heard in guild chat ("c") or an answer to one ("a"), with who: the
-- caller or answerer as the sender's name; a call's first answer ("ca"); an ask heard ("g") or answered ("ga"). ago:
-- for ca and ga, seconds since that call or ask was heard, so the answer counts on the call's or ask's night (one heard
-- before 12:00 UTC and answered after stays in its night: ca <= c and ga <= g on every night, which W1N checks).
-- mg (harvest item 4, 13 Nov 2026): a "maybe ask" heard, a line too long for an ask that names a group and a request
-- (Lead.lua ns.MaybeAsk), once per writer per ask window; counted only, never shown.
-- gs (auditor, 14 Nov 2026): a group a guildmate other than Louis started in guild chat without a call ("lf2m wc",
-- "starting wc, pst"; Lead.lua ReadAsk "fill" or "start"), once per writer per ask window, with who: the writer counts
-- among the people who start or fill a group (xo, wo; people-side thread, 14 Nov), never in cl.
-- gr (auditor C5, 14 Nov 2026): asks answered either way, a ga or the asker read in a dungeon with a guildmate
-- within an hour (Lead.lua ns.AsksGrouped), once per ask, on the ask's night. Not a floor: it can overstate (two
-- groups in one instance, a duo asking before going in together; red team, 14 Nov). A row gets gr = 0 at its first
-- ask on this build and counts gr only then, so gr <= g on every row (W1N checks it), and a row with asks from before
-- this build has no gr at all: those asks weren't watched, so its gr is "not counted", never 0.
-- gf (auditor C6, 14 Nov 2026): asks followed to the end, once per ask: answered (with gr), past their hour, or made
-- moot by the asker's own call. One still under an hour old at a logout or /reload was cut short (g minus gf). Like gr,
-- a row counts gf from its first ask on a build that has it, so gf <= g on every row.
local NIGHT_KINDS = { c = true, a = true, ca = true, g = true, ga = true, mg = true, gs = true, gr = true, gf = true }
function ns.WeekOneNight(kind, who, ago)
  if not NIGHT_KINDS[kind] or not date or not ns.WeekOneHelper() then return end
  local w, now = store(), time()
  ago = (kind == "ca" or kind == "ga" or kind == "gr" or kind == "gf") and math.max(0, math.min(tonumber(ago) or 0, DAY))
    or 0
  local n = night(w, now - ago)
  if kind == "g" and n.g == nil then n.gr, n.gf = n.gr or 0, n.gf or 0 end -- followed from the row's first ask
  if (kind == "gr" or kind == "gf") and n[kind] == nil then return end
  inc(n, kind)
  if kind ~= "c" and kind ~= "a" and kind ~= "gs" then return end -- gs: a starter is someone who starts a group
  pruneWho(w, now)
  if type(who) == "string" and who ~= "" and not ns.isSecret(who) then
    if ns.IsLouis(who) then
      if kind == "c" then inc(n, "cl") w.louisCallAt = now end
    else
      local name, o = ns.shortName(who), ns.isOfficer(who)
      w.whoNight[name], w.who7[name] = o and "o" or true, { n = nightKey(now), o = o }
    end
  end
  whoCounts(w, n)
end

-- A newcomer's first words in guild chat (harvest item 2, 13 Nov 2026). Joyce and Kraut (2006): a reply to a
-- newcomer's first post raised the chance they posted again from 44% to 56%, whatever its tone. On a helper's client:
-- the first guild chat line it hears from each first-week newcomer, and whether anyone else wrote in guild chat within
-- WEEK1_REPLY_SECS after it. Any line counts, as in the study, so it is an upper bound on replies (in a busy chat
-- every line is "answered"); the hourly guild chat line counts (Core.lua talk) give the chance level.
-- weekOne.spoke[name] = { at = when, r = 1 once another line followed }, on this PC only, dropped at day 8; only the
-- join day's counts (sp, spr, spq, sprq) leave it.
ns.WEEK1_REPLY_SECS = 120
function ns.WeekOneHeard(msg, sender)
  if type(msg) ~= "string" or ns.isSecret(msg) or type(sender) ~= "string" or ns.isSecret(sender) then return end
  if not date or type(UW_GuildDB) ~= "table" or not ns.WeekOneHelper() then return end
  local full = ns.fullName(sender)
  local name = full and ns.shortName(full)
  if not name then return end
  local w, now = store(), time()
  for who, e in pairs(w.spoke) do
    if who ~= name and type(e) == "table" and not e.r and now - (ns.finite(e.at) or 0) <= ns.WEEK1_REPLY_SECS then
      e.r = 1
    end
  end
  if w.spoke[name] == nil and newcomer(name, members()[name], now) then w.spoke[name] = { at = now } end
end
local heardFrame = CreateFrame("Frame")
ns.listen(heardFrame, { "CHAT_MSG_GUILD" })
heardFrame:SetScript("OnEvent", ns.guard(function(_, _, msg, sender) ns.WeekOneHeard(msg, sender) end))

-- Louis's one sitting with the officers (audit section 7, step 1): on the bot's PC, which of the six approved officer
-- chat openings Louis's own character sent in /o each UTC day. The approved lines live in the project file
-- leaders/officer-o-lines.md (Louis approved them 13 Nov 2026). Only which line and the day are saved, never the text:
-- weekOne.sit["YYYYMMDD"] = six characters, "1" where that opening was sent. Matched case-insensitively, with
-- apostrophes dropped and other punctuation and spacing read as one space, so a pasted or retyped line both count.
ns.SIT_OPENINGS = { "officers, thank you for being here", "kind and private first", "what you can count on",
  "keeping the rank is the same bar", "one ask: please keep uw_guild running", "and when you're on, a guild chat line" }
ns.WEEK1_SIT_KEEP = 60
local function plainLine(s)
  s = s:lower():gsub("\226\128[\152\153]", ""):gsub("['`]", "") -- ’ ‘ ' `
  return (s:gsub("[^%w]+", " "):gsub("^ ", ""):gsub(" $", ""))
end
local sitOpenings
-- Sent by this character: the event's sender GUID where the client gives one (no name format to get wrong), else the
-- sender's name as the roster spells it (hardening, 14 Nov 2026: no sitting was counted from Louis's 14 Nov one).
local function sentByMe(sender, guid)
  local mine = UnitGUID and UnitGUID("player")
  local ok = function(g) return type(g) == "string" and g ~= "" and not ns.isSecret(g) end
  if ok(guid) and ok(mine) then return guid == mine end
  return type(sender) == "string" and not ns.isSecret(sender) and ns.shortName(sender) == ns.shortName(ns.me() or "")
end
function ns.WeekOneSit(msg, sender, guid)
  if not onBotPC() or not date or type(UW_GuildDB) ~= "table" then return false end
  if type(msg) ~= "string" or ns.isSecret(msg) or not sentByMe(sender, guid) then return false end
  if not sitOpenings then
    sitOpenings = {}
    for i, o in ipairs(ns.SIT_OPENINGS) do sitOpenings[i] = plainLine(o) end
  end
  local text, which = plainLine(msg), nil
  for i, o in ipairs(sitOpenings) do if text:sub(1, #o) == o then which = i break end end
  if not which then return false end
  local w, now = store(), time()
  local day = date("!%Y%m%d", now)
  local was = type(w.sit[day]) == "string" and #w.sit[day] == #sitOpenings and w.sit[day] or ("0"):rep(#sitOpenings)
  w.sit[day] = was:sub(1, which - 1) .. "1" .. was:sub(which + 1)
  local oldest = date("!%Y%m%d", now - ns.WEEK1_SIT_KEEP * DAY)
  for k in pairs(w.sit) do if type(k) ~= "string" or k < oldest then w.sit[k] = nil end end
  ns.trace("week1", "officer line", true, ("line %d"):format(which))
  return true
end
local sitFrame = CreateFrame("Frame")
ns.listen(sitFrame, { "CHAT_MSG_OFFICER" })
sitFrame:SetScript("OnEvent", ns.guard(function(_, _, msg, sender, ...) -- the 12th payload value is the sender's GUID
  ns.WeekOneSit(msg, sender, (select(10, ...)))
end))

-- When newcomers are on (Louis 8 Nov 23:52, priority 1: plan a first dungeon for when most newcomers who haven't
-- grouped are online). w.on[name] = { lv = level, h = { [hour] = samples online } } by this PC's clock, for newcomers
-- not yet grouped; kept on this PC like w.seen, and dropped once they group, are marked no thanks or their first week
-- ends.
local function noteOn(w, rows, now)
  local hour = tonumber(date("%H", now))
  for _, r in ipairs(rows) do
    local m = members()[r.name]
    if r.online and ns.finite(r.level) and newcomer(r.name, m, now) and not groupedAt(w, r.name, m)
      and not w.noThanks[r.name] then
      local o = type(w.on[r.name]) == "table" and w.on[r.name] or {}
      if type(o.h) ~= "table" then o.h = {} end
      o.lv, o.h[hour] = r.level, (tonumber(o.h[hour]) or 0) + 1
      w.on[r.name] = o
    end
  end
  for name in pairs(w.on) do
    local m = members()[name]
    if not newcomer(name, m, now) or groupedAt(w, name, m) or w.noThanks[name] then w.on[name] = nil end
  end
end

-- The plan: the dungeon (Lead.lua's ns.LEAD_DUNGEONS, the same rule as the suggested call) and the hour of the day
-- (this PC's clock) when the most newcomers who haven't grouped have been online at its levels, at least 3 (with the
-- caller and a helper, a group of 5), online right now or not. Ties: more samples, then the range centred on their
-- levels. { name, dlo, dhi, hour, n, lo, hi } or nil; worked out once per 15-minute sample.
ns.WEEK1_PLAN_MIN = 3
local planCache
function ns.WeekOnePlan()
  local w = store()
  if planCache and planCache.slot == w.slot then return planCache.plan end
  local cand, now, best = {}, time(), nil
  for name, o in pairs(w.on) do
    local m = members()[name]
    if type(o) == "table" and type(o.h) == "table" and ns.finite(o.lv) and newcomer(name, m, now)
      and not groupedAt(w, name, m) and not w.noThanks[name] then
      cand[#cand + 1] = o
    end
  end
  for _, d in ipairs(ns.LEAD_DUNGEONS or {}) do
    for hour = 0, 23 do
      local n, total, sum, a, b = 0, 0, 0, nil, nil
      for _, o in ipairs(cand) do
        local k = tonumber(o.h[hour]) or 0
        if k > 0 and o.lv >= d[2] and o.lv <= d[3] then
          n, total, sum = n + 1, total + k, sum + o.lv
          a, b = math.min(a or o.lv, o.lv), math.max(b or o.lv, o.lv)
        end
      end
      if n >= ns.WEEK1_PLAN_MIN then
        local off = math.abs((d[2] + d[3]) / 2 - sum / n)
        if not best or n > best.n or (n == best.n and (total > best.total or (total == best.total and off < best.off)))
        then
          best = { name = d[1], dlo = d[2], dhi = d[3], hour = hour, n = n, total = total, off = off, lo = a, hi = b }
        end
      end
    end
  end
  planCache = { slot = w.slot, plan = best }
  return best
end

-- Core.lua calls this after each complete roster read (rows: name, level, online, zone).
local noDateTold
-- Which zone strings the roster really shows (red team Z1, 13 Nov): INSTANCE_ZONES matches them by name, and some
-- dungeon names are also outdoor places (Ruins of Lordaeron, The Deadmines). If the roster gives a subzone, someone
-- outdoors would count as in a dungeon. weekOne.zones = { [zone string] = online members seen there, summed over
-- reads }: zone names and counts only, never who. Never reset or aged out. At most WEEK1_ZONE_MAX strings, which
-- covers every Classic zone, city and instance with room to spare; past it a new string is dropped, never an old one.
local function tallyZone(w, zone)
  if type(zone) ~= "string" or zone == "" or ns.isSecret(zone) or #zone > 64 then return end
  local z = w.zones
  if z[zone] == nil then
    local n = 0
    for _ in pairs(z) do n = n + 1 end
    if n >= ns.WEEK1_ZONE_MAX then return end
  end
  z[zone] = (tonumber(z[zone]) or 0) + 1
end

function ns.WeekOneSample(rows, now)
  if not ns.WeekOneHelper() then return end
  if not date then
    if not noDateTold then noDateTold = true ns.trace("week1", "sample", false, "no date() on this client") end
    return
  end
  local w = store()
  local slot = math.floor(now / SLOT)
  if w.slot == slot then return end -- one sample per slot, also across /reload
  -- Once per member: the last full read before the roster first saw them (0 when already here then, or before any
  -- read). joined() refuses invites up to it. A new field only: members from before it read 0, as before.
  local prior = ns.finite(w.slot) and w.slot * SLOT or nil
  for _, m in pairs(members()) do
    local first = type(m) == "table" and ns.finite(m.first)
    if first and m.w1prior == nil then m.w1prior = (prior and first > prior) and prior or 0 end
  end
  w.slot = slot
  local byZone, online = {}, {}
  for _, r in ipairs(rows) do
    if r.online then
      online[r.name] = r.away and "away" or true
      tallyZone(w, r.zone)
      if isInstance(w, r.zone) then
        byZone[r.zone] = byZone[r.zone] or {}
        table.insert(byZone[r.zone], r.name)
      end
    end
  end
  for _, list in pairs(byZone) do
    if #list >= 2 then for _, n in ipairs(list) do mark(w, n, now) markDungeon(w, n, now) end end
    noteInviter(w, list, now)
  end
  noteTogether(w, byZone, now)
  local day = date("!%Y%m%d", now)
  w.cover[day] = (tonumber(w.cover[day]) or 0) + 1 -- a helper's 15-minute read: coverage, counts only
  w.slots[day] = ns.WeekOneSlotSet(w.slots[day], math.floor(now % DAY / SLOT))
  local oldest = date("!%Y%m%d", now - ns.WEEK1_COVER_DAYS * DAY)
  for _, t in ipairs({ w.cover, w.slots, w.peerCover, w.peerSlots }) do
    for k in pairs(t) do if type(k) ~= "string" or k < oldest then t[k] = nil end end
  end
  ns.WeekOneMerge(w, day)
  noteNight(w, now, slot, byZone)
  if ns.AsksGrouped then ns.AsksGrouped(byZone) end -- an asker now in a dungeon with a guildmate (Lead.lua, gr)
  noteOn(w, rows, now)
  local before = ns.finite(w.through)
  finalize(w, now)
  w.live = live(w, online, now)
  -- finished days go out when counting passes into a new UTC day (once a day), today's reads once per read
  local through = ns.finite(w.through)
  ns.WeekOneShare(day, before and through and date("!%Y%m%d", before) ~= date("!%Y%m%d", through))
  local seen = 0
  for _ in pairs(online) do seen = seen + 1 end
  ns.trace("week1", "sample", true, seen .. " online")
end

-- The helper's own group: every guildmate in it, and the helper too when there is one. It counts as a dungeon only
-- while the helper is inside a party or raid instance.
local function helperInInstance(w)
  if IsInInstance then
    local inside, kind = IsInInstance()
    if inside and (kind == "party" or kind == "raid") then return true end
  end
  local zone = GetRealZoneText and GetRealZoneText()
  return type(zone) == "string" and not ns.isSecret(zone) and isInstance(w, zone)
end

local function noteGroup()
  if not IsInGroup() or not ns.WeekOneHelper() then return end
  local w, now, raid, any = store(), time(), IsInRaid(), false
  local dungeon, list = helperInInstance(w), {}
  for i = 1, raid and GetNumGroupMembers() or math.max(0, GetNumGroupMembers() - 1) do
    local unit = (raid and "raid" or "party") .. i
    local full = ns.unitFull(unit) -- first name and surname, as the members keys hold them (not UnitName's first part)
    if full and UnitIsInMyGuild(unit) and not UnitIsUnit(unit, "player") then
      mark(w, ns.shortName(full), now)
      if dungeon then markDungeon(w, ns.shortName(full), now) end
      list[#list + 1] = ns.shortName(full)
      any = true
    end
  end
  if any then
    mark(w, ns.shortName(ns.me() or ""), now)
    if dungeon then markDungeon(w, ns.shortName(ns.me() or ""), now) end
    list[#list + 1] = ns.shortName(ns.me() or "")
    noteInviter(w, list, now)
  end
end

local function learnInstance()
  if not (IsInInstance and GetRealZoneText) or not ns.WeekOneHelper() then return end
  local inside, kind = IsInInstance()
  local zone = GetRealZoneText()
  if not inside or (kind ~= "party" and kind ~= "raid") or type(zone) ~= "string" or ns.isSecret(zone) or zone == "" then return end
  local w, n = store(), 0
  if w.inst[zone] or ns.INSTANCE_ZONES[zone] then return end
  for _ in pairs(w.inst) do n = n + 1 end
  if n < ns.WEEK1_INST_MAX then w.inst[zone] = true end
end

-- Reaching out, on a helper's client: a whisper this character sends a first-week newcomer, or a group invite (the
-- game's "You have invited X to join your group."). Kept as weekOne.approached[name] = when, the latest; never sent.
ns.WEEK1_REACHED_HOURS = 24
local function plainPattern(fmt) -- a GlobalStrings line with one %s (or %1$s) as a Lua pattern capturing the name
  if type(fmt) ~= "string" or not fmt:find("%%%d?%$?s") then return nil end
  local p = fmt:gsub("%%%d?%$?s", "\1", 1):gsub("[%%%(%)%.%+%-%*%?%[%]%^%$]", "%%%0"):gsub("\1", "(.+)", 1)
  return "^" .. p .. "$"
end
local INVITED = plainPattern(rawget(_G, "ERR_INVITE_PLAYER_S"))
  or plainPattern("You have invited %s to join your group.") -- the enUS text, if the client has no global
local function reached(who)
  if not ns.WeekOneHelper() then return end
  local full = ns.fullName((who:gsub("|Hplayer:[^|]*|h%[?([^%]|]*)%]?|h", "%1")))
  local name, now = full and ns.shortName(full), time()
  if name and newcomer(name, members()[name], now) then store().approached[name] = now end
end
local function reachedToday(w, name, now)
  local t = ns.finite(w.approached[name])
  return t ~= nil and now - t < ns.WEEK1_REACHED_HOURS * 3600
end
local reach = CreateFrame("Frame")
ns.listen(reach, { "CHAT_MSG_WHISPER_INFORM", "CHAT_MSG_SYSTEM" })
reach:SetScript("OnEvent", ns.guard(function(_, event, msg, target)
  if not (UW_GuildDB and ns.inOurGuild and ns.inOurGuild()) then return end
  local who = target
  if event == "CHAT_MSG_SYSTEM" then
    who = type(msg) == "string" and not ns.isSecret(msg) and INVITED and msg:match(INVITED) or nil
  end
  if type(who) == "string" and who ~= "" and not ns.isSecret(who) then ns.protect(reached, who) end
end))

-- Whose list a newcomer is on: every PC works it out the same way from its own roster, so nothing is sent. The online
-- helpers who can take one are those not AFK or DND and heard running UW_Guild lately (an officer without it would
-- hold newcomers nobody sees), plus this character. Each newcomer goes to the helper with the highest weight of
-- "helper<tab>newcomer" (full names; ties to the first name), so a helper logging in or out moves only the newcomers
-- it takes or held (rendezvous hashing, Thaler & Ravishankar 1998).
ns.WEEK1_HEARD_DAYS = 7
local P = 2147483647
-- A string hash every client computes alike (Lua 5.1, no bit library). Multiplying mod 2^31 - 1 alone is linear, and
-- names a letter apart then all went to one helper; folding at 65521 after each byte spreads them.
local function weight(s)
  local h = 5381
  for i = 1, #s do
    h = ((h + s:byte(i)) * 48271) % P
    h = (h % 65521) * 32749 + math.floor(h / 65521)
  end
  for _ = 1, 3 do
    h = (h * 48271) % P
    h = (h % 65521) * 32749 + math.floor(h / 65521)
  end
  return h
end
-- A helper inside a dungeon or raid by the roster's zone (theirs as every PC reads it, this character's too) is left
-- out while any helper outside one is on (red team, #597: on a raid night most newcomers would sit on lists nobody
-- can act on). With every helper inside one, they all count, so no newcomer is on nobody's list. Only the shared list
-- (ns.INSTANCE_ZONES), never the zones this PC learned (weekOne.inst): those differ from PC to PC, and every PC must
-- pick the same owners (integrator, #597).
local function insideZone(zone) return zone ~= nil and ns.INSTANCE_ZONES[zone] ~= nil end
local function helpersOn(rows, now, meFull)
  local out, inside, mine = {}, {}, nil
  for _, r in ipairs(rows) do
    local m = members()[r.name]
    if r.full == meFull then
      mine = r
    elseif not r.away and type(m) == "table" and ns.WeekOneHelper(r.full)
      and (ns.finite(m.addon) or 0) >= now - ns.WEEK1_HEARD_DAYS * DAY then
      table.insert(insideZone(r.zone) and inside or out, r.full)
    end
  end
  if meFull and ns.WeekOneHelper() then table.insert(mine and insideZone(mine.zone) and inside or out, meFull) end
  return #out > 0 and out or inside
end
local function ownerOf(helpers, full)
  local best, bw
  for _, h in ipairs(helpers) do
    local wt = weight(h .. "\t" .. full)
    if not bw or wt > bw or (wt == bw and h < best) then best, bw = h, wt end
  end
  return best
end
ns.WeekOneOwner = ownerOf -- for the tests

-- This character's online first-week newcomers, each with their buddy and up to two guildmates near them, and how many
-- other online ones are on other helpers' lists. Marked no thanks: never listed.
-- all: grouped or not, AFK or not (the login line and /uw new: UW_Guild sees few groups, so "not seen grouped" isn't a
-- count anyone should read; coordinator, 10 Nov). Free ones first, then those this character reached out to in the
-- last 24 hours, AFK last; then not seen grouped, then the longest in. Without it (Lead.lua's suggested call, the
-- "newcomer is online" line): only those not seen grouped, not AFK and not reached out to in the last 24 hours.
function ns.WeekOneWaiting(all)
  local w, now, rows, meFull = store(), time(), {}, ns.me()
  local me = ns.shortName(meFull or "")
  for i = 1, GetNumGuildMembers() do
    local full, _, _, level, _, zone, _, _, online, status = GetGuildRosterInfo(i)
    full = online and ns.fullName(full) -- nil when secret
    if full and level then
      if type(zone) ~= "string" or ns.isSecret(zone) then zone = nil end
      rows[#rows + 1] = { full = full, name = ns.shortName(full), level = level, zone = zone,
        away = ns.RosterBusy(status, nil) ~= nil }
    end
  end
  local helpers, out, byName, others = helpersOn(rows, now, meFull), {}, {}, 0
  for _, r in ipairs(rows) do byName[r.name] = r end
  for _, r in ipairs(rows) do
    local m = members()[r.name]
    if r.name ~= me and newcomer(r.name, m, now) and not w.noThanks[r.name] then
      local grouped, today = groupedAt(w, r.name, m) ~= nil, reachedToday(w, r.name, now)
      if not (meFull and ownerOf(helpers, r.full) == meFull) then
        others = others + 1
      elseif all or not (grouped or r.away or today) then
        local near = {}
        for _, o in ipairs(rows) do
          -- An AFK or DND guildmate can't answer an invite now (render pass 4, 14 Nov): not "near".
          if o.name ~= r.name and o.name ~= me and not o.away and math.abs(o.level - r.level) <= ns.WEEK1_NEAR then
            near[#near + 1] = o
          end
        end
        table.sort(near, function(a, b)
          local za, zb = a.zone == r.zone, b.zone == r.zone
          if za ~= zb then return za end
          local da, db = math.abs(a.level - r.level), math.abs(b.level - r.level)
          if da ~= db then return da < db end
          return a.name < b.name
        end)
        local pair = type(UW_GuildDB.buddies) == "table" and UW_GuildDB.buddies[r.name]
        local buddy = type(pair) == "table" and byName[pair.buddy] or nil
        out[#out + 1] = { row = r, day = math.floor((now - joined(r.name, m)) / DAY) + 1, buddy = buddy,
          near = { near[1], near[2] }, grouped = grouped, away = r.away or nil, reached = today or nil }
      end
    end
  end
  table.sort(out, function(a, b)
    local ta, tb = a.away and 2 or a.reached and 1 or 0, b.away and 2 or b.reached and 1 or 0
    if ta ~= tb then return ta < tb end
    if a.grouped ~= b.grouped then return not a.grouped end
    if a.day ~= b.day then return a.day > b.day end
    return a.row.name < b.row.name
  end)
  return out, others
end

-- No thanks (/uw new no): a newcomer who'd rather not group comes off this PC's lists for their first week.
-- text: a name or the start of one (any case, "First Last"); "" takes the newcomer this character last reached out to.
local function pickNewcomer(w, text, now)
  if text == "" then
    local best, at
    for name, t in pairs(w.approached) do
      if ns.finite(t) and (not at or t > at) and newcomer(name, members()[name], now) then best, at = name, t end
    end
    return best
  end
  local hits, exact = {}, nil
  for name, m in pairs(members()) do
    local low = type(name) == "string" and name:lower()
    if low and newcomer(name, m, now) then
      if low == text then exact = name end
      if low:sub(1, #text) == text then hits[#hits + 1] = name end
    end
  end
  return exact or (#hits == 1 and hits[1] or nil)
end
local function markNoThanks(w, verb, text, now)
  if verb == "undo" or (verb == "yes" and text == "") then
    local best, at
    for name, t in pairs(w.noThanks) do
      if not at or (ns.finite(t) or 0) > at then best, at = name, ns.finite(t) or 0 end
    end
    if not best then say("Nobody is marked no thanks.") ns.trace("week1", "no thanks", false, "nothing to undo") return end
    w.noThanks[best] = nil
    say(("%s is back on your first-week list."):format(best))
    return
  end
  local name = pickNewcomer(w, text, now)
  if not name then
    if text == "" then
      say("Whisper or invite a newcomer first, or type /uw new no and their name.")
    else
      say(("No single first-week newcomer matches %s. Type more of their name."):format(text))
    end
    ns.trace("week1", "no thanks", false, text == "" and "nobody reached out to" or "no single match")
    return
  end
  if verb == "yes" then
    w.noThanks[name] = nil
    say(("%s is back on your first-week list."):format(name))
  else
    w.noThanks[name] = now
    say(("%s is off your first-week list. /uw new undo puts them back."):format(name))
  end
  ns.trace("week1", "no thanks", true)
end

local function link(r) return ("|Hplayer:%s|h[%s]|h"):format(r.full, r.name) end

local function weekLine(w)
  local l = type(w.live) == "table" and w.live or nil
  if not l or not ns.finite(l.new) then return end
  say(("This week: %d joined, %d grouped with guildmates, %d quiet %d+ days with no group yet."):format(l.new,
    ns.finite(l.grouped) or 0, ns.finite(l.quiet) or 0, ns.WEEK1_QUIET_DAYS))
end

ns.commands.new = function(args)
  args = strtrim(args or ""):lower()
  if not ns.WeekOneHelper() then
    say("/uw new is for officers and welcome buddies. Want to help newcomers find a group? /uw jobs shows how.")
    return
  end
  local w = store()
  if args == "off" or args == "on" then
    w.off = args == "off" or nil
    if w.off then
      say("No newcomer lines at login or when one comes online. /uw new still lists them; /uw new on brings them back.")
    else
      say("At login you'll see how many newcomers in their first week are online.")
    end
    return
  end
  local verb, rest = args:match("^(%S+)%s*(.-)$")
  if verb == "no" or verb == "yes" or verb == "undo" then
    markNoThanks(w, verb, (rest:gsub("%s+", " ")):sub(1, 48), time())
    return
  end
  local list, others = ns.WeekOneWaiting(true)
  local pl, verbS = others == 1 and "" or "s", others == 1 and "s" or ""
  if #list == 0 and others > 0 then
    say(("Your list is empty. %d first-week newcomer%s online show%s on other helpers' lists."):format(others, pl, verbS))
  elseif #list == 0 then
    say("No newcomers in their first week are online right now.")
  else
    say(("%d newcomer%s in their first week online. Up for a group? Click a name in chat to whisper or invite:")
      :format(#list, #list == 1 and "" or "s"))
    for i = 1, math.min(#list, ns.WEEK1_SHOW) do
      local e, r = list[i], list[i].row
      local near = {}
      for _, o in ipairs(e.near) do near[#near + 1] = ("%s %d"):format(link(o), o.level) end
      say(("%s %d, %s, day %d%s%s%s%s%s"):format(link(r), r.level, r.zone or "?", e.day,
        e.grouped and " · grouped with us" or "", e.away and " · away" or "",
        e.reached and " · you reached out today" or "", e.buddy and (" · buddy " .. link(e.buddy)) or "",
        #near > 0 and (" · near: " .. table.concat(near, ", ")) or ""))
    end
    if #list > ns.WEEK1_SHOW then say(("...and %d more."):format(#list - ns.WEEK1_SHOW)) end
    if others > 0 then
      say(("%d more first-week newcomer%s show%s on other helpers' lists."):format(others, pl, verbS))
    end
    -- For the helper to type when they group up, never sent by the addon (Louis, 8 Nov: no addon whispers).
    say(("Grouped with someone who lacks UW_Guild? Tell them: Our guild addon is free and takes 2 minutes: %s")
      :format(ns.ADDON_URL))
  end
  weekLine(w)
end

local told -- once a session
local function loginLine()
  if told or not ns.WeekOneHelper() or store().off then return end
  local n = 0
  for _, e in ipairs((ns.WeekOneWaiting(true))) do if not (e.away or e.reached) then n = n + 1 end end
  if n == 0 then return end
  told = true
  -- "seen": only dungeons and the helper's own group count, so open-world questing together still reads as waiting.
  -- Officers get the one action that reaches them all (Lead.lua's suggested call); buddies get the list.
  -- No claim they haven't done a dungeon: UW_Guild sees only groups with a helper's or the member's own UW_Guild
  -- (coordinator, 10 Nov: "25 not yet seen in a dungeon" read as "25 never did one").
  say(("%d newcomer%s in their first week online. Up for a group? %s"):format(n, n == 1 and "" or "s",
    ns.isOfficer(ns.me()) and ns.Lead and "/uw lead call suggests a group for them." or "/uw new shows who's near them."))
end

-- A newcomer comes online later (addon search, 13 Nov 2026; coordinator cleared 13 Nov 17:56): the login line counts
-- who's on when an officer logs in, so a newcomer who logs in an hour later reached nobody. When a first-week newcomer
-- with no guild dungeon seen comes online, one line in this officer's own chat, once per newcomer per UTC day. Nothing
-- is sent to anyone. Not in combat or inside an instance (the officer can't help then), not for a newcomer who comes
-- online inside one; whoever came on meanwhile is told at the next read outside. /uw new off stops it with the login
-- line. A session's first roster read only notes who's on already: the login line covers them. The officer's now
-- button (Lead.lua) still offers the call.
ns.WEEK1_ONLINE_LINE = "%s (%d) is online: first week, no guild dungeon seen yet."
local onlineBefore
local function insideInstance()
  if not IsInInstance then return false end
  local inside, kind = IsInInstance()
  return inside and kind ~= "none"
end
function ns.WeekOneCameOnline()
  if not ns.isOfficer(ns.me()) or store().off then onlineBefore = nil return end
  local w, seen = store(), {}
  for _, x in ipairs(ns.WeekOneWaiting()) do
    local z = x.row.zone
    if not (z and (ns.INSTANCE_ZONES[z] or w.inst[z])) then seen[x.row.name] = x.row end
  end
  local before = onlineBefore
  -- In a fight or an instance: keep the last snapshot, so whoever came on meanwhile is told at the next read outside.
  if before and (InCombatLockdown() or insideInstance()) then return end
  onlineBefore = seen
  if not before or type(UW_GuildCharDB) ~= "table" then return end
  local day = date and date("!%Y%m%d", time()) or "?"
  local t = UW_GuildCharDB.onlineTold
  if type(t) ~= "table" or t.day ~= day or type(t.names) ~= "table" then t = { day = day, names = {} } end
  UW_GuildCharDB.onlineTold = t
  local new = {}
  for name in pairs(seen) do if not before[name] and not t.names[name] then new[#new + 1] = name end end
  table.sort(new)
  for _, name in ipairs(new) do
    t.names[name] = true
    say(ns.WEEK1_ONLINE_LINE:format(name:match("^(%S+)") or name, seen[name].level))
  end
end
table.insert(ns.onScan, function() ns.WeekOneCameOnline() end)

-- Shared reads (v1 quality audit item 2, 10 Nov 2026): a join day's first-dungeon count is "measured" only after 56
-- helper reads in its 7-day window, and only the Guild Master's save reaches the bot. Other helpers' clients (officers,
-- Welcome buddies) read the roster too, so each sends the Guild Master's client what it saw, as counts, never a name:
--   W1C <day> <reads> <slots>: its reads that UTC day, and which of the day's 96 quarter-hours they were, as 24 hex
--     digits (4 quarter-hours each). The Guild Master's client keeps every helper's quarter-hours together, so two
--     helpers on at the same time count once (weekOne.coverAll = the day's distinct quarter-hours read by anyone).
--   W1D <day> <k=v,...>: a finished join day's counts (the same fields as weekOne.days). Kept in weekOne.peerDays,
--     the fuller row per day (more newcomers, then more first dungeons), never added to this client's own days: the bot
--     takes the fuller of the two (bot/uwbot/weekone.py), as it does across saves.
--   W1N <night> <k=v,...> (independent audit, approved by Louis 13 Nov 2026): a night's group counts (weekOne.nights,
--     the NIGHT_SHARE fields it has), counts only. Calls officers heard while Louis was offline stayed on their own PCs
--     and were lost. Kept in weekOne.peerNights, each field the highest any officer sent, never the sum: every client
--     online hears the same guild chat, so a sum would count one call once per listener, and the highest is a floor.
--     From officers only, and only rows that add up (red team, #597): see the handler below.
--   W1H, no fields (same audit, 13 Nov 2026): the bot's PC, once its first roster read after login is in. A helper
--     sent its recent counts only at its own login, so an officer who never played while Louis did looked like one who
--     refused to share. Each helper online answers by resending what it sends at login, 10 to 90 s later (so they don't
--     all send at once), at most once per 30 minutes. Counts only, as above.
-- Sent only from helpers' clients that aren't the bot's PC (Schedule.lua gen > 0); kept only on the bot's PC, from
-- senders who are helpers by the same test (W1D and W1N: officers only). Today's reads and tonight's counts go after each read; the last 9 days'
-- reads, finished days and the last 9 nights at login and on W1H, and finished days when one finishes. Paced with the
-- crafting directory's lane, a few short addon messages an hour.
local HEX = "0123456789abcdef"
local POP = { [0] = 0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4 }
local function nibbles(hex)
  if type(hex) ~= "string" or not hex:match("^[0-9a-f]+$") or #hex ~= 24 then hex = ("0"):rep(24) end
  local out = {}
  for i = 1, 24 do out[i] = HEX:find(hex:sub(i, i), 1, true) - 1 end
  return out
end
local function hexOf(t)
  local out = {}
  for i = 1, 24 do out[i] = HEX:sub(t[i] + 1, t[i] + 1) end
  return table.concat(out)
end
local function bor4(a, b) -- a OR b for 4-bit numbers, without the bit library (Lua 5.1 tests have none)
  local r, p = 0, 1
  for _ = 1, 4 do
    if a % 2 == 1 or b % 2 == 1 then r = r + p end
    a, b, p = math.floor(a / 2), math.floor(b / 2), p * 2
  end
  return r
end
function ns.WeekOneSlotSet(hex, i)
  local t = nibbles(hex)
  local c, b = math.floor(i / 4) + 1, i % 4
  if c >= 1 and c <= 24 then t[c] = bor4(t[c], 2 ^ b) end
  return hexOf(t)
end
local function slotsOr(a, b)
  local x, y = nibbles(a), nibbles(b)
  for i = 1, 24 do x[i] = bor4(x[i], y[i]) end
  return hexOf(x)
end
local function slotCount(hex)
  local n = 0
  for _, v in ipairs(nibbles(hex)) do n = n + POP[v] end
  return n
end
ns.WeekOneSlotCount = slotCount
local function botPC() return type(ns.SCHEDULE) == "table" and (tonumber(ns.SCHEDULE.gen) or 0) > 0 end
-- Helpers' nights are kept as long as this client's own (WEEK1_NIGHT_KEEP).
local function pruneNights(t)
  if not date then return end
  local oldest = nightKey(time() - ns.WEEK1_NIGHT_KEEP * DAY)
  for k in pairs(t) do if type(k) ~= "string" or k < oldest then t[k] = nil end end
end
-- The day's reads by anyone: this client's and every helper's quarter-hours together, never below a count a helper
-- sent before slots existed.
function ns.WeekOneMerge(w, day)
  if not botPC() then return end
  local all = slotsOr(w.slots[day], w.peerSlots[day])
  w.coverAll[day] = math.max(slotCount(all), tonumber(w.peerCover[day]) or 0, tonumber(w.cover[day]) or 0)
  local oldest = date and date("!%Y%m%d", time() - ns.WEEK1_COVER_DAYS * DAY)
  for _, t in ipairs({ w.coverAll, w.peerDays }) do
    for k in pairs(t) do if type(k) ~= "string" or (oldest and k < oldest) then t[k] = nil end end
  end
  pruneNights(w.peerNights)
end
local DAY_FIELDS = { "n", "g3", "g7", "s3", "s0", "q", "a", "a3", "ab3", "p3n", "v", "d7", "e", "ed7", "na", "da",
  "vl", "nl", "dl", "nx", "dx", "ap", "apq", "nt", "sp", "spr", "spq", "sprq", "iv", "ivg", "h3", "h0" }
-- Each value at most DAY_CAP (a join day never has 1000 newcomers), so all 32 fields fit an addon message's 255 bytes.
local DAY_CAP = 999
local function dayLine(day, d)
  local parts = {}
  for _, k in ipairs(DAY_FIELDS) do
    local v = ns.finite(d[k])
    if v then parts[#parts + 1] = k .. "=" .. math.min(math.floor(v), DAY_CAP) end
  end
  return "W1D\t" .. day .. "\t" .. table.concat(parts, ",")
end
ns.WeekOneDayFields, ns.WeekOneDayLine, ns.WEEK1_DAY_CAP = DAY_FIELDS, dayLine, DAY_CAP -- tests: W1D's size
local function shareDays(w)
  local oldest = date("!%Y%m%d", time() - ns.WEEK1_FINAL_DAYS * DAY - 9 * DAY)
  local through = ns.finite(w.through)
  -- only days this client has finished (counting passed into a later UTC day): a half-counted day would look final
  local done = through and date("!%Y%m%d", through)
  for day, d in pairs(w.days) do
    if type(d) == "table" and type(day) == "string" and day >= oldest and done and day < done then
      ns.craftSend(dayLine(day, d), "GUILD")
    end
  end
end
local function shareCover(w, day)
  ns.craftSend(("W1C\t%s\t%d\t%s"):format(day, tonumber(w.cover[day]) or 0, hexOf(nibbles(w.slots[day]))), "GUILD")
end
-- A night's fields that go out (W1N), whichever the night has, as whole numbers up to NIGHT_CAP: at most 18 fields of
-- 8 bytes, so a line stays far under an addon message's 255.
local NIGHT_SHARE = { "f", "p", "q", "c", "a", "ca", "g", "ga", "cl", "xo", "xm", "wo", "wm", "fn", "mg", "gs", "gr",
  "gf" }
local NIGHT_CAP = 1000
local function nightLine(nk, n)
  local parts = {}
  for _, k in ipairs(NIGHT_SHARE) do
    local v = ns.finite(n[k])
    if v and v >= 0 then parts[#parts + 1] = k .. "=" .. math.min(math.floor(v), NIGHT_CAP) end
  end
  return #parts > 0 and ("W1N\t" .. nk .. "\t" .. table.concat(parts, ",")) or nil
end
local function shareNight(w, nk)
  local line = type(w.nights[nk]) == "table" and nightLine(nk, w.nights[nk])
  if line then ns.craftSend(line, "GUILD") end
end
-- After each read on a helper's client that isn't the bot's PC: today's reads, tonight's counts, and finished days
-- when one finished.
-- /uw share off (Louis's OK, 13 Nov 2026 17:14; off line cleared by the coordinator 10 Nov 03:14; status line, switch label and
-- tooltip cleared 13 Nov 17:33; reworded and cleared again 19:24: a helper keeps its first-week list by name on its own
-- PC, and only counts leave it): this helper stops sending its counts. On by default, like every UW_Guild helper; off
-- costs only the shared cover, never rank or progress.
function ns.WeekOneSharing() return not (UW_GuildDB and UW_GuildDB.weekOneShareOff) end
ns.SHARE_OFF_TEXT = "/uw share off: your addon stops sending the Guild Master's addon how often you see the roster "
  .. "and its week-one counts (counts only). First-dungeon numbers then count only when other helpers are online."
ns.commands.share = function(args)
  local w = strtrim(args or ""):lower()
  if w == "off" then
    if UW_GuildDB then UW_GuildDB.weekOneShareOff = true end
  elseif w == "on" then
    if UW_GuildDB then UW_GuildDB.weekOneShareOff = nil end
  elseif w ~= "" then
    say("/uw share on or /uw share off.") return
  end
  if ns.WeekOneSharing() then say("Week-one counts: shared (counts only; your first-week list stays on your PC). " .. ns.SHARE_OFF_TEXT) else say(ns.SHARE_OFF_TEXT) end
end
function ns.WeekOneShare(day, finished)
  if botPC() or not ns.WeekOneSharing() or not ns.WeekOneHelper() or not ns.tracksGuild() then return end
  local w = store()
  shareCover(w, day)
  if date then shareNight(w, nightKey(time())) end
  if finished then shareDays(w) end
end
-- At login, and when the bot's PC says hello (W1H): the last 9 days' reads (a newcomer week plus a day), every
-- finished day still being read, and the last 9 nights.
local function shareAtLogin()
  if botPC() or not ns.WeekOneSharing() or not ns.WeekOneHelper() or not ns.tracksGuild() or not date then return end
  local w, now = store(), time()
  for k = 0, 8 do
    local day = date("!%Y%m%d", now - k * DAY)
    if w.slots[day] or w.cover[day] then shareCover(w, day) end
  end
  shareDays(w)
  for k = 0, 8 do shareNight(w, nightKey(now - k * DAY)) end
end
local function helperSender(sender)
  return botPC() and ns.tracksGuild() and ns.inRoster(sender) and ns.WeekOneHelper(sender)
    and ns.shortName(sender) ~= ns.shortName(ns.me() or "")
end
-- A real UTC day from tomorrow back to the cover window ("20261131" isn't one), from a set made once a day.
local recent = { today = nil, days = {} }
local function recentDay(day)
  if type(day) ~= "string" or not date then return false end
  local now = time()
  local today = date("!%Y%m%d", now)
  if recent.today ~= today then
    recent.today, recent.days = today, {}
    for k = -1, ns.WEEK1_COVER_DAYS do recent.days[date("!%Y%m%d", now - k * DAY)] = true end
  end
  return recent.days[day] == true
end
ns.handlers.W1C = function(sender, channel, day, reads, slots)
  if channel ~= "GUILD" or not helperSender(sender) or not recentDay(day) then return end
  local n = tonumber(reads)
  if not n or n ~= n or n < 0 or n > 96 * 4 then return end -- a few helpers on one PC at most
  if type(slots) ~= "string" or not slots:match("^[0-9a-f]+$") or #slots ~= 24 then return end
  local w = store()
  w.peerCover[day] = math.max(tonumber(w.peerCover[day]) or 0, math.min(math.floor(n), 96))
  w.peerSlots[day] = slotsOr(w.peerSlots[day], slots)
  ns.WeekOneMerge(w, day)
end
-- A helper's night (W1N): from an officer only (red team, #597: as W1D since #568, anyone who can edit public notes
-- could name a buddy, and the highest value wins), a real night still kept, the NIGHT_SHARE fields only, whole
-- numbers up to NIGHT_CAP and no more than one client can see: it reads the roster once a quarter-hour (96 a night)
-- with at most p groups at once, and a group formed is one of that read's groups, so q <= 96 p and f <= q. A row
-- whose parts exceed their wholes is refused: ca and cl within c, ga, gr and gf within g, fn within f, xm within xo, wm
-- within wo, xo within wo (ns.WeekOneNightOK, as the bot's weekone.night_ok). Each field keeps the highest any officer sent,
-- never the sum (see W1N above); the highest of rows that each add up adds up too.
local NIGHT_KNOWN = {}
for _, k in ipairs(NIGHT_SHARE) do NIGHT_KNOWN[k] = true end
function ns.WeekOneNightOK(row)
  local z = function(k) return tonumber(row[k]) or 0 end
  return z("ca") <= z("c") and z("cl") <= z("c") and z("ga") <= z("g") and z("gr") <= z("g") and z("gf") <= z("g")
    and z("fn") <= z("f")
    and z("xm") <= z("xo") and z("wm") <= z("wo") and (row.wo == nil or z("xo") <= z("wo"))
end
ns.handlers.W1N = function(sender, channel, nk, fields)
  if channel ~= "GUILD" or not helperSender(sender) or not ns.isOfficer(sender) or not recentDay(nk)
    or type(fields) ~= "string" or nk < nightKey(time() - ns.WEEK1_NIGHT_KEEP * DAY) then
    return
  end
  local row = {}
  for k, v in fields:gmatch("(%w+)=(%d+)") do
    if NIGHT_KNOWN[k] then row[k] = math.min(tonumber(v), NIGHT_CAP) end
  end
  row.q = row.q and row.p and math.min(row.q, 96 * row.p) or nil
  row.f = row.f and row.q and math.min(row.f, row.q) or nil
  if next(row) == nil or not ns.WeekOneNightOK(row) then return end
  local w = store()
  local n = type(w.peerNights[nk]) == "table" and w.peerNights[nk] or {}
  for k, v in pairs(row) do n[k] = math.max(tonumber(n[k]) or 0, v) end
  w.peerNights[nk] = n
  pruneNights(w.peerNights)
end
-- The bot's PC is online (W1H): a helper resends what it sends at login, once, 10 to 90 s later. Anyone in the roster
-- could send a W1H, and that is harmless: a helper answers at most once per WEEK1_HELLO_GAP (this session), with the
-- same few counts its own login sends, never a name, and only the bot's PC keeps them (helperSender).
ns.WEEK1_HELLO_GAP = 30 * 60
local helloAt
ns.handlers.W1H = function(sender, channel)
  if channel ~= "GUILD" or botPC() or not ns.WeekOneSharing() or not ns.WeekOneHelper() or not ns.tracksGuild()
    or not ns.inRoster(sender) or ns.shortName(sender) == ns.shortName(ns.me() or "") then
    return
  end
  local now = time()
  if helloAt and now - helloAt < ns.WEEK1_HELLO_GAP then return end
  helloAt = now
  ns.after(10 + math.random() * 80, shareAtLogin)
end
-- Finished days only from officers (red team, #568: anyone who can edit public notes could name a buddy), and never
-- more newcomers than this roster first saw on or after that day.
ns.handlers.W1D = function(sender, channel, day, fields)
  if channel ~= "GUILD" or not helperSender(sender) or not ns.isOfficer(sender) or not recentDay(day)
    or type(fields) ~= "string" then
    return
  end
  local row, known = {}, {}
  for _, k in ipairs(DAY_FIELDS) do known[k] = true end
  for k, v in fields:gmatch("(%w+)=(%d+)") do
    if known[k] then row[k] = math.min(tonumber(v), 1000) end
  end
  -- weekone.py's checks before keeping it: every part within its whole, ed7 <= min(d7, e), da <= na, and the
  -- Discord split adding up only when vl = 1. A row that fails is refused, so one bad sender can't skew D7.
  local n = row.n
  if not n or n < 1 then return end
  local start = time() - time() % DAY -- the day's start (UTC): recentDay keeps it within 60 days of today
  while date("!%Y%m%d", start) > day do start = start - DAY end
  local since = 0
  for _, m in pairs(members()) do
    if type(m) == "table" and (ns.finite(m.first) or 0) >= start then since = since + 1 end
  end
  if n > since then return end
  for k, v in pairs(row) do if k ~= "v" and k ~= "vl" and v > n then return end end
  local z = function(k) return row[k] or 0 end
  if not (z("ab3") <= z("a3") and z("a3") <= z("a")) then return end
  if z("apq") > z("ap") then return end -- ap and nt are within n like every field above
  if not (z("spr") <= z("sp") and z("spq") <= z("sp") and z("sprq") <= math.min(z("spr"), z("spq"))
    and z("ivg") <= z("iv")) then return end
  if (row.h3 or row.h0) and not (z("s3") <= z("h3") and z("h3") <= z("g3") and z("s0") <= z("h0")
    and z("h3") + z("h0") <= n) then return end
  if row.d7 and not (z("ed7") <= math.min(z("d7"), z("e")) and z("da") <= z("na")) then return end
  if row.vl == 1 and not (z("na") + z("nl") + z("nx") == n and z("da") + z("dl") + z("dx") == z("d7")
    and z("dl") <= z("nl") and z("dx") <= z("nx")) then return end
  local w = store()
  local old = w.peerDays[day]
  local on, od = type(old) == "table" and tonumber(old.n) or -1, type(old) == "table" and tonumber(old.d7) or -1
  if n > on or (n == on and (row.d7 or -1) > od) then w.peerDays[day] = row end
  ns.WeekOneMerge(w, day)
end

-- A dungeon opens (addon search, 13 Nov 2026; coordinator cleared 13 Nov 17:56): at a level where a dungeon's suggested
-- range starts (Lead.lua ns.LEAD_DUNGEONS, the game's own levels once learned), one line on this member's own screen
-- names it and points at guild chat, where a group comes from with no addon on anyone's side. Once per level per
-- character, nothing sent. An automatic helper, so on by default with a switch (/uw dungeons off, the Options page).
ns.DUNGEON_OPEN_LINE = "Level %d: %s %s in range now. Ask guild chat for a group."
function ns.DungeonsOpening(level)
  local out = {}
  for _, d in ipairs(ns.LEAD_DUNGEONS or {}) do if d[2] == level then out[#out + 1] = d[1] end end
  return out
end
local function andList(names) -- "A", "A and B", "A, B and C"
  if #names < 2 then return names[1] end
  return table.concat(names, ", ", 1, #names - 1) .. " and " .. names[#names]
end
function ns.DungeonLine(level)
  level = tonumber(level)
  local c = UW_GuildCharDB
  if not level or type(c) ~= "table" or UW_GuildDB.dungeonLineOff then return end
  if (tonumber(c.dungeonLineAt) or 0) >= level then return end
  local names = ns.DungeonsOpening(level)
  if #names == 0 then return end
  c.dungeonLineAt = level
  say(ns.DUNGEON_OPEN_LINE:format(level, andList(names), #names == 1 and "is" or "are"))
end
ns.commands.dungeons = function(args)
  args = strtrim(args or ""):lower()
  -- Switching it says the same as asking, so "on" also says how to turn it off (render pass 4, 14 Nov 2026).
  if args == "off" or args == "on" then UW_GuildDB.dungeonLineOff = args == "off" or nil end
  if UW_GuildDB.dungeonLineOff then
    say("Off: no line when you reach a dungeon's level. /uw dungeons on brings it back.")
  else
    say("On: when you reach a dungeon's level, one line names it. /uw dungeons off stops it.")
  end
end

local f = CreateFrame("Frame")
ns.listen(f, { "GROUP_ROSTER_UPDATE", "PLAYER_ENTERING_WORLD", "PLAYER_LEVEL_UP" })
f:SetScript("OnEvent", ns.guard(function(_, event, arg)
  if not (UW_GuildDB and ns.inOurGuild and ns.inOurGuild()) then return end
  if event == "PLAYER_LEVEL_UP" then ns.protect(ns.DungeonLine, arg) return end
  if event == "GROUP_ROSTER_UPDATE" then
    ns.protect(noteGroup)
  else
    ns.protect(learnInstance)
  end
end))
ns.afterRoster(function()
  -- The bot's PC: helpers online resend their recent counts (W1H, Shared reads above). Once a session.
  -- The decision log's "hello sent" (trace.done, kept in the save) is how a deploy check sees it went out.
  if botPC() and ns.tracksGuild() then
    ns.craftSend("W1H", "GUILD")
    ns.trace("week1", "hello sent", true)
  end
  ns.after(30, function() ns.protect(loginLine) end)
  ns.after(45, function() ns.protect(shareAtLogin) end)
  -- The group finder may know nothing yet right after login: read it once at 20 s, and once more at 120 s if empty.
  ns.after(20, function()
    if ns.LearnGameDungeons() == 0 then ns.after(100, ns.LearnGameDungeons) end -- nil: no API, nothing to retry
  end)
end)
