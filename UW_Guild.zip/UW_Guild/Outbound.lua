-- UW_Guild: every chat line the addon sends, in one list, and one switch that stops the automatic ones.
--
-- Why (9 Nov 2026): the GM's client whispered all 31 Raiders, one every 3 minutes, about raid sign-ups the guild can't
-- do yet. Louis: "it's really embarrassing to make those mistakes; please prevent". So:
--   * This is the only file that calls the game's SendChatMessage. Every other file sends with
--     ns.chat(key, msg, chatType, target), and key must be in ns.SENDERS below, with an explicit on flag.
--     tests/outbound_test.lua fails when a file calls SendChatMessage itself, when a key isn't registered, or when a
--     raid line or an unasked whisper to players without the addon is on.
--   * kind: "auto" (nobody asked: a join, a promotion, a timer), "reply" (answers a whisper or reply someone sent),
--     "pressed" (the player typed a command or clicked a button just now).
--   * /uw quiet stops every "auto" and "reply" line at once, on this account, across /reload and logout (saved in
--     UW_GuildDB.hush). On the Guild Master's client it also tells officers' clients, and the Discord bot reads it from
--     the next save (/reload), so its automatic posts and DMs stop too. /uw quiet off undoes it. What you press
--     yourself still goes: you're choosing it then.
--   * A line that is off isn't sent; it's counted in UW_GuildDB.outboundHeld and the decision log, so hardening can
--     verify on Louis's PC what was held, without anyone hearing it. Every automatic line or answer that does go is
--     kept in UW_GuildDB.outboundSent (the last OUTBOUND_LOG: key, time, channel, short name), so what went out can be
--     read from the save instead of asking members.
--   * On the Guild Master's account a line also needs Louis's own OK the first time its text is new (a popup, one
--     click; /uw approve list). See "Louis's own OK" below.
-- Turning a line on is a reviewed change to its on flag here (raids: once Louis's guild runs them), never a setting.
local _, ns = ...
local say = ns.say

-- {key, kind, on, raid, noAddon, file, what}. raid: raid-framed. noAddon: reaches players who may not run UW_Guild.
-- approved: an unasked no-addon line is on only with Louis's own word, named here (who and when).
-- The audit with triggers, rates and exact texts: /mnt/project-files/ops/member-messages.md (and docs/pings.md).
ns.SENDERS = {
  -- Louis, 9 Nov 2026 02:39: no automatic whispers from the addon, ever ("auto-whispering is a bit too...robotic").
  -- Every "auto" and "reply" line below is off for good; the code stays, dormant, for possible later use. Only what a
  -- person types or clicks sends. (This replaces his 00:18 yes to the join welcome.)
  { key = "discord.join", kind = "auto", on = false, noAddon = true,
    file = "Onboarding.lua",
    what = "Join whisper: a minute after someone new joins, one officer's client whispers our Discord invite and /link" },
  { key = "prof.join", kind = "auto", on = false, noAddon = true, file = "Crafts.lua",
    what = "Professions ask: 15 minutes after the join whisper, asks a new member's professions for their note" },
  { key = "note.added", kind = "reply", on = false, noAddon = true, file = "Crafts.lua",
    what = "'Added X to your guild note', once the note they asked for is set (when they're next online)" },
  { key = "whisper.reply", kind = "reply", on = false, noAddon = true, file = "Onboarding.lua",
    what = "Answers to a whisper of help, a dungeon (wc), stop, start or idea" },
  { key = "prof.reply", kind = "reply", on = false, noAddon = true, file = "Crafts.lua",
    what = "Answers to a professions reply or 'clear note'" },
  { key = "raiders.what", kind = "reply", on = false, raid = true, noAddon = true, file = "Charter.lua",
    what = "Answer to a 'raider?' whisper (what the rank means)" },
  { key = "raid.signup", kind = "reply", on = false, raid = true, noAddon = true, file = "Charter.lua",
    what = "Answer to a 'raid' sign-up whisper" },
  { key = "charter.ask", kind = "pressed", on = true, noAddon = true, needsOK = true, file = "Charter.lua",
    what = "/uw charter: the Guild Master whispers the charter ask" },
  { key = "recruit.whisper", kind = "pressed", on = true, noAddon = true, needsOK = true, file = "Charter.lua",
    what = "/uw recruit <name>: an officer's recruit whisper" },
  { key = "recruit.trade", kind = "pressed", on = true, noAddon = true, needsOK = true, file = "Charter.lua",
    what = "/uw trade: the Guild Master's own trade ad in the Trade channel, one post per press" },
  { key = "raiders.ask", kind = "pressed", on = false, raid = true, file = "Charter.lua",
    what = "/uw raiders: 'Anyone keen to raid down the road?' in guild chat" },
  { key = "jobs.ask", kind = "pressed", on = true, file = "Onboarding.lua",
    what = "/uw jobs ask: the guild jobs ask in guild chat" },
  -- needsOK: pressed, but many whispers of our text in the officer's name: Louis OKs the text once for every client.
  -- Retired (Louis, 9 Nov 02:39: "sure, retire, but keep for potential future use"): off for everyone, the GM too.
  { key = "discord.ask", kind = "pressed", on = false, noAddon = true, needsOK = true, file = "Onboarding.lua",
    what = "/uw discord ask: whispers online guildmates about Discord, once each" },
  -- One click, one person, once ever (16 Nov 2026): not the retired bulk ask above. His client only (Lead window).
  { key = "discord.one", kind = "pressed", on = true, noAddon = true, needsOK = true, file = "Onboarding.lua",
    what = "Lead window, Discord tab: the Guild Master whispers one guildmate the Discord invite, once ever" },
  { key = "officer.addon", kind = "pressed", on = true, noAddon = true, needsOK = true, file = "Onboarding.lua",
    what = "Lead window, Discord tab: the Guild Master whispers one officer without UW_Guild the addon page, once ever" },
  { key = "prof.nudge", kind = "pressed", on = true, noAddon = true, needsOK = true, file = "Crafts.lua",
    what = "/uw nudge notes: whispers online guildmates with an empty note" },
  { key = "lead.call", kind = "pressed", on = true, slot = "dungeon", file = "Lead.lua",
    what = "/uw lead Call and Dungeons: 'Getting a group going for X, who's in?' or '..., need a healer.' in guild chat" },
  { key = "lead.line", kind = "pressed", on = true, file = "Lead.lua",
    what = "/uw lead lines: the ready-made guild, group and whisper lines" },
  { key = "lead.bench", kind = "pressed", on = false, raid = true, keepDigits = true, file = "Lead.lua",
    what = "/uw lead: the raid bench whisper" },
  { key = "lead.raidopen", kind = "pressed", on = false, raid = true, keepDigits = true, file = "Lead.lua",
    what = "/uw lead: 'sign-ups are open' raid line in guild chat" },
  { key = "loot.announce", kind = "pressed", file = "Loot.lua", on = true,
    what = "Loot roll results in party or raid chat, for a roll the leader started" },
  { key = "dungeon.here", kind = "pressed", on = true, file = "QuestChain.lua",
    what = "Inside a dungeon, the button above chat: 'Quests for this run: ...' in party chat, one post per click" },
  -- Louis, 22 Nov 2026 19:29: ask a guild enchanter from the character panel. One whisper per click, in the
  -- member's own words, to a guildmate whose UW_Guild shared the recipe.
  { key = "enchant.ask", kind = "pressed", on = true, file = "Enchants.lua",
    what = "Character panel enchant button or the nearby notice above chat: whispers one online guild enchanter for one enchant on one piece" },
  -- Louis, 23 Nov 2026 03:42 (bank thanks): a whisper citing the exact amount of each gold gift over 5g, one per
  -- click, his client only; the tab-1 lines of 22 Nov are retired.
  { key = "bank.thanks", kind = "pressed", on = true, noAddon = true, needsOK = true, file = "Bank.lua",
    what = "Guild bank notice above chat: the Guild Master thanks one guildmate for the gold they gave, with the amounts" },
}
ns.SENDER = {}
for _, s in ipairs(ns.SENDERS) do ns.SENDER[s.key] = s end

local function hush()
  local h = UW_GuildDB and UW_GuildDB.hush
  return type(h) == "table" and h or nil
end
-- True while /uw quiet is on for this account.
function ns.Hushed()
  local h = hush()
  return h ~= nil and h.on == true
end

-- Would ns.chat(key, ...) send now? For code that marks something done before it sends (a once-ever whisper): ask
-- first, so a line that is off or held marks nobody, and they still get it once it's on again.
-- With the line's text (and who gets it), it also asks whether Louis has OK'd that text for this client (LineOKHere).
function ns.ChatOn(key, msg, target)
  local s = ns.SENDER[key]
  return s ~= nil and s.on == true and not (s.kind ~= "pressed" and ns.Hushed())
    and (msg == nil or ns.LineOKHere(key, msg, target))
end

ns.OUTBOUND_LOG = 200
local function logSent(s, key, chatType, target)
  if not UW_GuildDB or s.kind == "pressed" then return end -- what you press is yours; the log is for the automatic
  local t = type(UW_GuildDB.outboundSent) == "table" and UW_GuildDB.outboundSent or {}
  UW_GuildDB.outboundSent = t
  while #t >= ns.OUTBOUND_LOG do table.remove(t, 1) end
  t[#t + 1] = { k = key, kind = s.kind, at = time(), ch = chatType, to = target and ns.shortName(target) or nil,
    ver = ns.VERSION } -- kind: the bot counts "auto" for the officers' note (outbound.py officer_note)
end

local warned = {}
local function hold(s, key, why, target)
  if UW_GuildDB then
    local t = type(UW_GuildDB.outboundHeld) == "table" and UW_GuildDB.outboundHeld or {}
    UW_GuildDB.outboundHeld = t
    local row = type(t[key]) == "table" and t[key] or {}
    row.n, row.last, row.why = (tonumber(row.n) or 0) + 1, time(), why
    t[key] = row
  end
  if ns.trace then ns.protect(ns.trace, "outbound", key, false, why, target) end
  if s and s.kind == "pressed" and not warned[key] then -- you pressed it, so you hear why nothing went, once
    warned[key] = true
    say(("Not sent: %s is off (%s)."):format(s.what, why))
  end
  return false, why
end

-- What the game sends, once the line's own checks pass (they're checked again here: quiet may have come on while a
-- line waited for its OK).
local function send(s, key, msg, chatType, target)
  if not s.on then return hold(s, key, s.raid and "raids aren't running yet" or "off for now", target) end
  if s.kind ~= "pressed" and ns.Hushed() then return hold(s, key, "quiet is on (/uw quiet off)", target) end
  local fn = (C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage
  if type(fn) ~= "function" or type(msg) ~= "string" then return false, "no chat" end
  local ok = pcall(fn, msg, chatType, nil, target)
  if ok then
    logSent(s, key, chatType, target)
    local after = ns.OnSent[key]
    if type(after) == "function" then ns.protect(after, target, msg) end
  end
  return ok, not ok and "the game didn't send it" or nil
end

-- Louis's own OK (9 Nov 2026 01:21): "I need to personally approve what messages go out with a single click every
-- time they do at first sends ... Nothing goes out from my character voice unless I say so." On the Guild Master's
-- account (any of its characters) every line, automatic or pressed, waits the first time its text is new: a popup shows
-- the exact line and who gets it, and one click sends it. The OK is kept per line and text (UW_GuildDB.approvedLines),
-- so the same text later goes without asking, and a changed text (an update, another wording) asks again. The
-- recipient's name, this character's name, item links and numbers don't count as a change; nor, for the call a group
-- line alone, does the name of a dungeon we ship (15 Nov 2026), and the popup for such a line says so before he
-- clicks: "Your OK covers this wording for any dungeon." "Don't send" sends
-- nothing, and whoever it was for isn't marked as asked (ns.OnUnsent[key], set by the file that marked them), so they
-- can still get it after an OK. Waiting lines are saved (UW_GuildDB.outboundWaiting), so a /reload neither loses one
-- nor leaves its mark behind: it asks again after the reload, or is undone once it waited too long.
ns.APPROVE_WAIT = 15 * 60 -- a line waiting longer than this isn't sent (a welcome an hour late reads wrong)
ns.APPROVE_GAP = 0.3      -- seconds between the lines one OK sends (25 whispers at once look like spam)
local function approvals()
  local t = type(UW_GuildDB.approvedLines) == "table" and UW_GuildDB.approvedLines or {}
  UW_GuildDB.approvedLines = t
  return t
end
local function isGMName(name)
  local full = name and ns.fullName(name)
  return full ~= nil and ns.rankOf[full] == 0
end
-- True on the Guild Master's account, and on any character whose rank isn't known yet (before the first roster
-- scan): a line nobody can place waits for an OK rather than going out unseen.
function ns.VoiceGated()
  if not UW_GuildDB then return true end
  if UW_GuildDB.gmAccount then return true end
  local me = ns.me and ns.me()
  local full = me and ns.fullName(me)
  if full and ns.rankOf[full] == 0 then UW_GuildDB.gmAccount = true return true end
  -- An alt logging in before the Guild Master's character has run this build: the account's character list (Mail.lua,
  -- UW_GuildDB.alts) names him, so it's his voice too (hardening, 9 Nov: 8 alts run UW_Guild on his PC).
  for name in pairs(type(UW_GuildDB.alts) == "table" and UW_GuildDB.alts or {}) do
    local alt = type(name) == "string" and ns.fullName(name)
    if alt and ns.rankOf[alt] == 0 then UW_GuildDB.gmAccount = true return true end
  end
  return not (full and ns.rankOf[full] ~= nil)
end
local function plain(s) return (s:gsub("[%^%$%(%)%%%.%[%]%*%+%-%?]", "%%%0")) end
-- The line as approved: names, item links and numbers stand in as <name>, <me>, <item>, #. Names are the target's,
-- yours, the guild roster's and, from 13 Nov 2026, everyone in your group: a player from outside the guild who wins
-- a /uw loot roll no longer makes a new line for Louis to OK (coordinator: "Louis approves wording, not names").
-- A sender marked keepDigits (a line that carries a time or date: raid sign-ups, the bench) keeps its digits, so
-- "8pm" changed to "11pm" is a new line that asks for a new OK (red team V3, Louis 9 Nov 01:21: he approves the exact
-- text).
-- A sender marked slot = "dungeon" (the call a group line; coordinator, 15 Nov 2026: "a dungeon name is a slot, just
-- like a player name") has the dungeons we ship stand in as <dungeon>, so Louis OKs the call's wordings once, not once
-- a dungeon. Only names from Lead.lua's own list, read when the line is shaped (no list: no slot, so the popup asks),
-- and only ones that look like a name (letters, spaces, apostrophes, a colon; 40 bytes at most), which keeps a link,
-- a number or punctuation out. It does not keep words out: any short phrase of letters put in that list would be
-- pre-approved in his voice (red team, 15 Nov), so the list is the guard, and tests/outbound_test.lua pins its names:
-- adding a dungeon shows in review as a new word he has OK'd. Longest first, on a copy: "Scarlet Monastery: Library"
-- before a shorter name inside it. Dungeons go before people: a guildmate called Scarlet Moon would otherwise turn the wing into
-- "<name> Monastery: Library" and the slot would depend on who's in the roster (guardrails, 15 Nov).
ns.SLOT_NAME = "^[%a ':]+$"
local function dungeonSlot(s)
  local list = ns.LEAD_DUNGEONS
  if type(list) ~= "table" then return s end
  local names = {}
  for _, d in ipairs(list) do
    local n = type(d) == "table" and d[1]
    if type(n) == "string" and #n >= 3 and #n <= 40 and n:find(ns.SLOT_NAME) then names[#names + 1] = n end
  end
  table.sort(names, function(a, b) if #a ~= #b then return #a > #b end return a < b end)
  for _, n in ipairs(names) do
    s = s:gsub("%f[%w\128-\255]" .. plain(n) .. "%f[^%w\128-\255]", "<dungeon>")
  end
  return s
end
function ns.LineShape(msg, target, key)
  local s = tostring(msg):gsub("|c%x+|H.-|h.-|h|r", "<item>")
  local sender = key and ns.SENDER and ns.SENDER[key]
  if sender and sender.slot == "dungeon" then s = dungeonSlot(s) end
  local function swap(name, as)
    if type(name) ~= "string" or name == "" then return end
    local full, short = ns.fullName(name) or name, ns.shortName(name) or name
    for _, n in ipairs({ full, short, short:match("^(%S+)") }) do
      -- whole words only; a byte over 127 counts as a letter, so "Zoë" or "Élan" is a whole word too (red team V2)
      if n and #n >= 3 then s = s:gsub("%f[%w\128-\255]" .. plain(n) .. "%f[^%w\128-\255]", as) end
    end
  end
  swap(target, "<name>")
  swap(ns.me and ns.me(), "<me>")
  for full in pairs(ns.rankOf or {}) do
    local short = ns.shortName(full)
    if short and #short >= 3 and s:find(short, 1, true) then swap(full, "<name>") end
  end
  if IsInGroup and IsInGroup() and ns.unitFull then
    local unit = IsInRaid and IsInRaid() and "raid" or "party"
    for i = 1, (GetNumGroupMembers and GetNumGroupMembers() or 0) do
      -- Forever's UnitName gives first name and surname apart; ns.unitFull joins them (red team, 13 Nov: "Zel Tor").
      local full = ns.unitFull(unit .. i)
      local short = full and ns.shortName(full)
      if short and #short >= 3 and s:find(short, 1, true) then swap(full, "<name>") end
    end
  end
  if sender and sender.keepDigits then return s end
  return (s:gsub("%d+", "#"))
end
function ns.LineApproved(key, msg, target)
  local mine = approvals()[key]
  return type(mine) == "table" and mine[ns.LineShape(msg, target, key)] ~= nil
end

-- ns.OnUnsent[key] = function(target, msg): put back what the sending file marked (asked, told) for a line that
-- never went. Keyed by sender, not a closure, so it still runs after a /reload.
ns.OnUnsent = {}
-- ns.OnSent[key] = function(target, msg): the game took the line, now or after the Guild Master's OK (Loot.lua starts
-- a roll's 20 seconds only then: journey sim, 13 Nov 2026). Its twin OnUnsent runs for a "Don't send", an OK that
-- came too late, or a send that failed. A waiting line outlives a /reload, so either can run for something gone.
ns.OnSent = {}
-- Every other client (an officer's, a member's): an automatic line or whisper answer goes only once Louis has OK'd
-- that exact text on his own client (coordinator, 9 Nov 02:02: Tass's client would otherwise welcome joiners in his
-- name). His client shares each OK as UWA <key> <tag> (a hash of the key and text), officers' clients ask for the
-- list at login (UWAQ), and only the Guild Master's word counts. What a player types or clicks still goes.
local function tagOf(key, shape)
  local h, s = 5381, key .. "\t" .. shape
  for i = 1, #s do h = (h * 33 + s:byte(i)) % 4294967296 end
  return ("%08x"):format(h)
end
local function sharedOK()
  local t = type(UW_GuildDB.approvedShared) == "table" and UW_GuildDB.approvedShared or {}
  UW_GuildDB.approvedShared = t
  return t
end
function ns.LineOKHere(key, msg, target)
  local s = ns.SENDER[key]
  if not s or (s.kind == "pressed" and not s.needsOK) or ns.VoiceGated() then return true end -- his: the popup asks
  if type(msg) ~= "string" then return false end
  local mine = sharedOK()[key]
  return type(mine) == "table" and mine[tagOf(key, ns.LineShape(msg, target, key))] ~= nil
end
local function shareOK(key, shape, target)
  if ns.officerSend then
    ns.officerSend(("UWA\t%s\t%s"):format(key, tagOf(key, shape)), target and "WHISPER" or "GUILD", target)
  end
end

local waiting, showing = {}, nil -- groups { key, shape, at, items = { {msg, chatType, target, at} } }
local function saveWaiting()
  if not UW_GuildDB then return end
  local out = {}
  for _, g in ipairs(waiting) do
    for _, item in ipairs(g.items) do
      out[#out + 1] = { k = g.key, msg = item.msg, ch = item.chatType, to = item.target, at = item.at, cn = item.ch }
    end
  end
  UW_GuildDB.outboundWaiting = out[1] and out or nil
end
-- A channel's name as the game gives it now ("Trade - City"), or nil.
local function channelName(id)
  if type(GetChannelName) ~= "function" then return nil end
  local name = select(2, GetChannelName(id or 0))
  return type(name) == "string" and not ns.isSecret(name) and name or nil
end
local function where(item)
  if item.chatType == "WHISPER" then return "whisper to " .. (ns.shortName(item.target or "") or item.target or "?") end
  if item.chatType == "CHANNEL" then
    local name = item.ch or channelName(item.target)
    name = name and (name:match("^(.-)%s+%-") or name) -- "Trade - City": Trade
    return (type(name) == "string" and name ~= "" and name or "a chat channel") .. " chat"
  end
  return ({ GUILD = "guild chat", OFFICER = "officer chat", PARTY = "party chat", RAID = "raid chat",
    INSTANCE_CHAT = "instance chat", SAY = "say" })[item.chatType] or tostring(item.chatType)
end
local function drop(group, why)
  for _, item in ipairs(group.items) do
    local fn = ns.OnUnsent[group.key]
    if type(fn) == "function" then ns.protect(fn, item.target, item.msg) end
    hold(nil, group.key, why, item.target)
  end
end
local showNext
-- direct: called straight from a click or a typed command (the popup's Send it, /uw approve), so the first line goes
-- inside that press. The game sends to a chat channel (Trade) only from a key or mouse press (warcraft.wiki.gg,
-- C_ChatInfo.SendChatMessage: CHANNEL needs a hardware event indoors and out), and a timer, even of 0 s, is not one.
-- The rest of a group still waits APPROVE_GAP apiece (16 Nov 2026, the trade ad).
local function resolve(yes, direct)
  local group = showing or waiting[1] -- /uw approve right away, before the popup's frame
  showing = nil
  if not group then return false end
  for i, g in ipairs(waiting) do if g == group then table.remove(waiting, i) break end end
  saveWaiting()
  if yes then
    local mine = approvals()[group.key] or {}
    approvals()[group.key] = mine
    mine[group.shape] = { at = time(), by = ns.shortName(ns.me() or "") or "?", text = group.items[1].msg }
    shareOK(group.key, group.shape)
    local s, n = ns.SENDER[group.key], 0
    for _, item in ipairs(group.items) do
      if time() - item.at > ns.APPROVE_WAIT then
        drop({ key = group.key, items = { item } }, "waited too long for an OK")
      elseif item.chatType == "CHANNEL" and (n > 0 or not direct) then
        -- A channel line goes only inside a press, one per OK (red team, 16 Nov 2026).
        drop({ key = group.key, items = { item } }, "one channel line per click")
      elseif item.chatType == "CHANNEL" and (not item.ch or channelName(item.target) ~= item.ch) then
        -- The channel's number now names another channel (he left the city, or a reload): never post there.
        drop({ key = group.key, items = { item } }, "the channel changed while it waited")
        say(("Not sent: you're no longer in %s."):format(item.ch and (item.ch:match("^(.-)%s+%-") or item.ch) or "that channel"))
      else
        n = n + 1
        local function go()
          -- Held after all (quiet came on while it waited, or the game refused it): put back what was marked.
          if not send(s, group.key, item.msg, item.chatType, item.target) then
            local fn = ns.OnUnsent[group.key]
            if type(fn) == "function" then ns.protect(fn, item.target, item.msg) end
          end
        end
        if direct and n == 1 then ns.protect(go) else ns.after(ns.APPROVE_GAP * (n - 1), go) end
      end
    end
    say(("OK'd: that line goes without asking from now on (%s). /uw approve list shows them."):format(group.key))
  else
    drop(group, "the Guild Master said don't send")
    say("Not sent. It asks again the next time that line would go.")
  end
  ns.after(0, showNext)
  return true
end
ns.ResolveLine = resolve
-- What the OK reaches beyond the line shown (integrator and coordinator, 15 Nov 2026: he OKs the exact text, so a
-- wider OK is said before the click). Only when a shipped dungeon's name really stood in this line; a typed call that
-- names none keeps the plain popup, and its OK covers that text alone.
ns.APPROVE_ANY_DUNGEON = "Your OK covers this wording for any dungeon."
local function covers(group)
  local sender = ns.SENDER[group.key]
  if not (sender and sender.slot == "dungeon") then return end
  for _, item in ipairs(group.items) do -- one key and one shape a group, so one line with a name speaks for all
    local msg = tostring(item.msg)
    if dungeonSlot(msg) ~= msg then return ns.APPROVE_ANY_DUNGEON end
  end
end
local function popupText(group)
  local item, more, wider = group.items[1], #group.items - 1, covers(group)
  return ("UW_Guild wants to send this as you, for the first time:\n\n%s\n\n%s%s%s"):format(item.msg, where(item),
    more > 0 and (" (and %d more like it)"):format(more) or "", wider and ("\n" .. wider) or "")
end
showNext = function()
  if showing then return end
  while waiting[1] and time() - waiting[1].at > ns.APPROVE_WAIT do
    drop(table.remove(waiting, 1), "waited too long for an OK")
    saveWaiting()
  end
  local group = waiting[1]
  if not group then return end
  showing = group
  local dialogs = rawget(_G, "StaticPopupDialogs")
  if type(dialogs) == "table" and StaticPopup_Show then
    dialogs.UW_GUILD_SEND = dialogs.UW_GUILD_SEND or { text = "%s", button1 = "Send it", button2 = "Don't send",
      OnAccept = function() resolve(true, true) end,
      -- Only the button is a no. Hidden any other way (another popup, a loading screen): asked again shortly.
      OnCancel = function(_, _, reason)
        if reason == "clicked" then resolve(false, true) else showing = nil ns.after(5, showNext) end
      end,
      noCancelOnReuse = true, timeout = 0, whileDead = true, hideOnEscape = false, preferredIndex = 3 }
    if StaticPopup_Show("UW_GUILD_SEND", popupText(group)) then return end
  end
  say("UW_Guild wants to send this as you, for the first time (" .. where(group.items[1]) .. "):")
  say(group.items[1].msg)
  if covers(group) then say(covers(group)) end
  say("Type /uw approve to send it, or /uw approve no.")
end
-- True while a line of this sender waits for the Guild Master's OK (the trade ad refuses a second press then: red team,
-- 16 Nov 2026, two presses before the OK would post twice).
function ns.LineWaiting(key)
  for _, g in ipairs(waiting) do if g.key == key then return true end end
  return false
end
local function queue(key, msg, chatType, target, at, cn)
  local shape = ns.LineShape(msg, target, key)
  local item = { msg = msg, chatType = chatType, target = target, at = at or time(),
    ch = chatType == "CHANNEL" and (cn or channelName(target)) or nil } -- cn: the name saved before a /reload
  for _, g in ipairs(waiting) do
    if g.key == key and g.shape == shape then g.items[#g.items + 1] = item return end
  end
  waiting[#waiting + 1] = { key = key, shape = shape, at = item.at, items = { item } }
end
local function askFirst(key, msg, chatType, target)
  queue(key, msg, chatType, target)
  saveWaiting()
  if ns.trace then ns.protect(ns.trace, "outbound", key, false, "waiting for the Guild Master's OK", target) end
  ns.after(0, showNext)
  return true, "waiting for your OK"
end
-- After a /reload or login: the lines that were waiting ask again (or, waited too long, are undone).
table.insert(ns.onLoad, function()
  local saved = UW_GuildDB.outboundWaiting
  UW_GuildDB.outboundWaiting = nil
  if type(saved) ~= "table" then return end
  for _, r in ipairs(saved) do
    if type(r) == "table" and ns.SENDER[r.k] and type(r.msg) == "string" and type(r.ch) == "string" then
      queue(r.k, r.msg, r.ch, (type(r.to) == "string" or type(r.to) == "number") and r.to or nil, tonumber(r.at),
        type(r.cn) == "string" and r.cn or nil)
    end
  end
  saveWaiting()
  ns.after(5, showNext)
end)

-- The one send. Returns true when the game took the line, or when it waits for the Guild Master's OK (a popup);
-- false and why when it was held or refused. A waiting line that never goes runs ns.OnUnsent[key].
-- Character limits (Louis, 22 Nov 2026: "always respect all character limits in perpetuity and programmatically check
-- for them"). The server refuses a chat line over 255 bytes, so a longer one is never sent and never cut short: it is
-- held, and reported as one of our errors (UW_GuildDB.errors and the game's error handler), which fails the addon tests
-- and marks the build in the release ring. The tests measure every line with each name in it as long as a Forever name
-- can be (tests/stubs.lua), so a line that fits "Bob" but not a 25-letter "First Last" fails there first. The table of every limit: bot/uwbot/limits.py.
ns.CHAT_BYTES = 255
function ns.ChatBytes(msg) return #msg end
local function tooLong(key, msg, target)
  local n = ns.ChatBytes(msg, target)
  if n <= ns.CHAT_BYTES then return false end
  local err = ("UW_Guild: chat line %s is %d bytes, over %d"):format(tostring(key), n, ns.CHAT_BYTES)
  if ns.onError then ns.onError(err) -- UW_GuildDB.errors, so the release ring sees it (Core.lua)
  else
    local handler = geterrorhandler and geterrorhandler()
    if handler then pcall(handler, err) end
  end
  return true
end

function ns.chat(key, msg, chatType, target)
  local s = ns.SENDER[key]
  if not s then return hold(nil, tostring(key), "not in ns.SENDERS", target) end
  if not s.on then return hold(s, key, s.raid and "raids aren't running yet" or "off for now", target) end
  if s.kind ~= "pressed" and ns.Hushed() then return hold(s, key, "quiet is on (/uw quiet off)", target) end
  if type(msg) ~= "string" then return false, "no chat" end
  if tooLong(key, msg, target) then
    if s.kind == "pressed" and not warned[key] then -- you pressed it, so you hear that nothing went, once
      warned[key] = true
      say("Not sent: that line is too long for chat.")
    end
    return hold(nil, key, "over 255 bytes", target)
  end
  if ns.VoiceGated() and not ns.LineApproved(key, msg, target) then
    return askFirst(key, msg, chatType, target)
  end
  if not ns.LineOKHere(key, msg, target) then
    local fn = ns.OnUnsent[key]
    if type(fn) == "function" then ns.protect(fn, target, msg) end
    return hold(s, key, "Louis hasn't OK'd this text yet", target)
  end
  return send(s, key, msg, chatType, target)
end

local isGM = isGMName
local function setHush(on, at, by)
  UW_GuildDB.hush = { on = on and true or false, at = at, by = by }
end
local function share(target)
  local h = hush()
  if h and ns.officerSend then
    ns.officerSend(("UWQ\t%d\t%d"):format(h.on and 1 or 0, tonumber(h.at) or 0), target and "WHISPER" or "GUILD", target)
  end
end
-- The Guild Master's /uw quiet reaches officers' clients (their join whispers and replies stop too). Newer wins.
ns.handlers.UWQ = function(sender, _, on, at)
  at = tonumber(at)
  if not (UW_GuildDB and at and isGM(sender)) or ns.fullName(sender) == ns.me() then return end
  local h = hush()
  if h and (tonumber(h.at) or 0) >= at then return end
  setHush(on == "1", at, ns.shortName(sender) or sender)
  if on == "1" then
    say("The Guild Master turned quiet on: UW_Guild's automatic whispers and lines are off here too.")
  else
    say("The Guild Master turned quiet off: UW_Guild's automatic whispers and lines are back on.")
  end
end
-- An officer logging in asks; the Guild Master's client answers with its state, and with every text he OK'd.
ns.handlers.UWQQ = function(sender, channel)
  if channel == "GUILD" and ns.isOfficer(sender) and isGM(ns.me()) then share(ns.fullName(sender) or sender) end
end
local answeredAQ = {} -- sender -> time: one answer per 5 minutes each, so a loop of asks can't flood his client
ns.handlers.UWAQ = function(sender, channel)
  if channel ~= "GUILD" or not isGM(ns.me()) then return end
  local to = ns.fullName(sender) or sender
  if answeredAQ[to] and GetTime() - answeredAQ[to] < 300 then return end
  answeredAQ[to] = GetTime()
  if ns.officerSend then ns.officerSend("UWAF", "WHISPER", to) end -- the full list replaces theirs (forgets included)
  for key, shapes in pairs(approvals()) do
    if ns.SENDER[key] and type(shapes) == "table" then
      for shape in pairs(shapes) do shareOK(key, shape, to) end
    end
  end
end
-- The Guild Master's OK of a text, on any other client; UWAF: he forgot them all.
ns.handlers.UWA = function(sender, _, key, tag)
  if not (UW_GuildDB and isGM(sender)) or ns.fullName(sender) == ns.me() then return end
  if not (ns.SENDER[key] and type(tag) == "string" and tag:match("^%x%x%x%x%x%x%x%x$")) then return end
  local t = sharedOK()
  t[key] = type(t[key]) == "table" and t[key] or {}
  t[key][tag] = time()
end
ns.handlers.UWAF = function(sender)
  if UW_GuildDB and isGM(sender) and ns.fullName(sender) ~= ns.me() then UW_GuildDB.approvedShared = {} end
end
table.insert(ns.onGuildJoin, function()
  ns.afterRoster(function()
    if not (ns.tracksGuild() and not isGM(ns.me()) and ns.send) then return end
    if ns.isOfficer(ns.me()) then ns.send("UWQQ", "GUILD") end
    ns.send("UWAQ", "GUILD") -- every client: a member's answers to whispers wait for the same OKs
  end)
end)

local function list()
  say(("Quiet is %s. Lines UW_Guild can send (/uw quiet on or off):"):format(ns.Hushed() and "ON" or "off"))
  for _, s in ipairs(ns.SENDERS) do
    local state = not s.on and (s.raid and "off (raids)" or "off")
      or (s.kind ~= "pressed" and ns.Hushed() and "held (quiet)") or "on"
    say(("  %s [%s, %s]: %s"):format(s.key, s.kind, state, s.what))
  end
end
local function listApproved()
  local n = 0
  for _, s in ipairs(ns.SENDERS) do
    for _, row in pairs(type(approvals()[s.key]) == "table" and approvals()[s.key] or {}) do
      n = n + 1
      say(("  %s, OK'd by %s: %s"):format(s.key, tostring(row.by), tostring(row.text)))
    end
  end
  say(n == 0 and "No lines OK'd yet: each one asks with a popup the first time." or
    ("%d lines OK'd. /uw approve forget makes every line ask again."):format(n))
end
ns.commands.approve = function(args)
  local w = strtrim(args or ""):lower()
  if w == "list" then listApproved() return end
  if w == "forget" then
    UW_GuildDB.approvedLines = {}
    if isGM(ns.me()) and ns.officerSend then ns.officerSend("UWAF", "GUILD") end
    say("Forgot every OK: each line asks again the first time it would go.")
    return
  end
  if w ~= "" and w ~= "yes" and w ~= "no" then say("/uw approve, /uw approve no, /uw approve list, or /uw approve forget.") return end
  if not resolve(w ~= "no", true) then say("Nothing is waiting for your OK.") end
end
ns.commands.quiet = function(args)
  local w = strtrim(args or ""):lower()
  if w == "list" or w == "status" then list() return end
  if w ~= "" and w ~= "on" and w ~= "off" then say("/uw quiet, /uw quiet off, or /uw quiet list.") return end
  local on, me = w ~= "off", ns.me()
  setHush(on, time(), ns.shortName(me or "") or "?")
  if isGM(me) then share() end
  if on then
    say("Quiet ON: no automatic whispers, guild lines or whisper answers from UW_Guild on this account.")
    say("It stays on after /reload and logout, until /uw quiet off. What you press yourself still goes.")
    say("Type /reload now so the Discord bot goes quiet too (it reads this at the next save).")
  else
    say("Quiet off: UW_Guild's automatic lines are back. Type /reload so the Discord bot hears it too.")
  end
end
