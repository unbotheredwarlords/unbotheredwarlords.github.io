-- /uw fish (Louis, 8 Nov 2026: fish while watching or playing something else). A sound preset that makes the bobber's
-- splash easy to hear with WoW in the background: music and ambience off, sound effects full, sound kept on when the
-- game isn't the focused window. /uw fish again (or /uw fish off) puts the four settings back as they were, and so
-- does logging out. The game gives addons no "bite" event, so this only changes what you hear; nothing is clicked
-- or cast for you. The saved settings live in UW_GuildDB.fishSound (account-wide, like these sound settings), so a
-- crash or a /reload with the preset on still gets them back.
-- Other players' splashes sound the same as yours, and no addon can tell them apart. The game does play other
-- players' sounds through their own channels (ally and enemy players), each with a high-pass filter. Raised to the
-- top, it muffles them while your own splash stays clear (Louis's ear test, 8 Nov 2026). A client without those two
-- settings skips them.
local _, ns = ...
local say = ns.say

ns.FISH_SOUND = { -- setting = value while fishing
  Sound_MusicVolume = "0",
  Sound_AmbienceVolume = "0",
  Sound_SFXVolume = "1",
  Sound_EnableSoundWhenGameIsInBG = "1",
  Sound_AllyPlayerHighpassDSPCutoff = "20000", -- other players' sounds (game default 80 Hz) ...
  Sound_EnemyPlayerHighpassDSPCutoff = "20000", -- ... muffled, so their splashes stop sounding like yours
}
-- These two read "" until someone sets them. Putting back the stated game default (80 Hz, the value Louis's undo
-- used) is surer than writing "" back.
local EMPTY_MEANS = { Sound_AllyPlayerHighpassDSPCutoff = "80", Sound_EnemyPlayerHighpassDSPCutoff = "80" }

local function db() return type(UW_GuildDB) == "table" and UW_GuildDB or nil end

function ns.FishOn()
  local d = db()
  if not d then return false end
  if d.fishSound then return true end
  local saved = {}
  for k in pairs(ns.FISH_SOUND) do
    local v = GetCVar(k)
    saved[k] = (v == "" and EMPTY_MEANS[k]) or v
  end
  d.fishSound = saved
  for k, v in pairs(ns.FISH_SOUND) do if saved[k] ~= nil then SetCVar(k, v) end end
  return true
end

function ns.FishOff()
  local d = db()
  if not d or type(d.fishSound) ~= "table" then return false end
  for k, v in pairs(d.fishSound) do if ns.FISH_SOUND[k] and v ~= nil then SetCVar(k, v) end end
  d.fishSound = nil
  return true
end

ns.commands.fish = function(args)
  local arg = strtrim(args or ""):lower()
  local d = db()
  if arg == "off" or (arg == "" and d and d.fishSound) then
    if ns.FishOff() then say("Fishing sound off: your sound settings are back.") else say("Fishing sound is already off.") end
  else
    ns.FishOn()
    say("Fishing sound on: music and ambience off, effects full, other players muffled, sound on in the background. /uw fish again to undo.")
  end
end

-- Logging out (or quitting) undoes the preset, so the next session starts with your own sound.
-- A fresh login that finds the preset still saved (the game crashed or was closed mid-fish, and these settings live
-- on in Config.wtf) puts your sound back too. A /reload keeps it on, so a reload while fishing doesn't undo it.
local f = CreateFrame("Frame")
ns.listen(f, { "PLAYER_LOGOUT", "PLAYER_ENTERING_WORLD" })
f:SetScript("OnEvent", ns.guard(function(_, event, isInitialLogin, isReloadingUi)
  if event == "PLAYER_LOGOUT" then ns.protect(ns.FishOff) return end
  if isInitialLogin and not isReloadingUi and ns.FishOff() then say("Fishing sound was still on from last time: your sound settings are back.") end
end))
