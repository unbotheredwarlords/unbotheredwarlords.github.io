-- "Send guild news" (Louis, 8 Nov 2026: "can't we build better live pipelines of data flow and sync?").
-- Addons can't reach the network or write files, and WoW writes SavedVariables only on /reload or logout, so a join,
-- kill or loot award reached Discord at session end. Measured on Louis's PC (8 Nov): the chat log stays empty while
-- playing, even for whispers and after closing the file, and the combat log flushes about a minute late and can't
-- carry addon data. So no live file route exists; a reload is the one way to hand the bot news now.
--   * A small button appears when guild news is waiting, only on the PC that runs the bot: the bot writes
--     Schedule.lua there with a gen stamp (bot/uwbot/gamesched.py); every other copy ships gen = 0.
--   * One click reloads the UI (a secure /reload macro: Forever may block ReloadUI from addons); the bot reads the save
--     within about 10 s and posts as usual (a burst stays one post).
--   * Never in combat or inside an instance, and nothing pops up: it waits where it is until clicked.
--   * /uw sync says to type /reload; /uw sync off hides the button, /uw sync on brings it back.
-- Quest log snapshot (Louis, 8 Nov 2026, yes): on the bot PC each reload or logout also saves this character's quest
-- log in UW_GuildCharDB.questLog (ids, titles, levels, objectives, the game's next waypoint, Questie's name and
-- tracked flag, the guide's skips, where you stood), so the
-- quest guide can be checked against the quests actually held. Only there: members' saves stay as they were.
local _, ns = ...
local say = ns.say

-- Outbox kinds the bot stores without posting: nothing in Discord waits on them.
local QUIET = { thanks = true, lead = true, upkeep = true, vibe = true }

local waiting = 0 -- news lines queued since this load; the save written by the next reload carries them
local button

local function botPC()
  local s = ns.SCHEDULE
  return type(s) == "table" and (tonumber(s.gen) or 0) > 0
end
ns.SyncBotPC = botPC

local function off() return type(UW_GuildDB) == "table" and UW_GuildDB.syncOff end

local function inInstance()
  local fn = rawget(_G, "IsInInstance")
  return fn and (fn()) and true or false
end

local function canShow()
  return botPC() and not off() and waiting > 0 and not InCombatLockdown() and not inInstance()
end

-- Forever may refuse an addon's ReloadUI() even from a click (ForeverWowCraft reports it, 13 Nov 2026; unverified on
-- Louis's client either way), while a click on a secure macro button may always run /reload. A
-- secure button can't be shown, hidden, moved or changed in combat, and neither can a frame holding it, so it leaves
-- the bar above chat as combat starts (that event comes just before the lock) and goes back after: the bar's other
-- buttons keep working in a fight.
local home   -- the bar above chat, where the button lives out of combat
local traced -- the press and the release both reach PreClick; one line in the decision log
local function build()
  if button or InCombatLockdown() then return button end -- made and put on the bar only out of combat
  button = CreateFrame("Button", "UW_GuildSyncButton", UIParent, "SecureActionButtonTemplate,UIPanelButtonTemplate")
  button.uwSecure = true -- the bar never moves it in combat (Skin.lua ns.ChatBarLayout)
  button:RegisterForClicks("AnyUp", "AnyDown")
  button:SetAttribute("type", "macro")
  button:SetAttribute("macrotext", "/reload")
  button:SetScript("PreClick", function()
    if traced then return end
    traced = true
    ns.protect(ns.trace, "sync", "send", true, waiting .. " waiting")
  end)
  ns.useButton(button, "send guild news")
  -- On the bar above chat with the other buttons (Skin.lua ns.ChatBar; Louis, 10 Nov: one style, nothing past it).
  ns.ChatBarAdd("guild news", button, 30, "Reloads your UI (a few seconds) so the bot posts it to Discord now. "
    .. "/uw sync off hides this.")
  home = button:GetParent()
  return button
end

local function leaveBar()
  if not button or InCombatLockdown() then return end
  button:Hide()
  button:SetParent(UIParent)
  button:ClearAllPoints()
end

local function refresh()
  if InCombatLockdown() then return end -- off the bar since combat began; PLAYER_REGEN_ENABLED brings it back
  if canShow() then
    local b = build()
    if not b then return end
    if home and b:GetParent() ~= home then b:SetParent(home) end
    b:Show()
    ns.ChatBarText(b, ("Send guild news (%d)"):format(waiting))
  elseif button then
    button:Hide()
  end
end
ns.SyncRefresh = refresh
function ns.SyncWaiting() return waiting end

ns.onQueue[#ns.onQueue + 1] = function(kind)
  if QUIET[kind] then return end
  waiting = waiting + 1
  refresh()
end

ns.commands.sync = function(args)
  local arg = strtrim(args or ""):lower()
  if arg == "off" then
    UW_GuildDB.syncOff = true
    refresh()
    say("Send-to-Discord button off. Guild news still goes at your next reload or logout. /uw sync on brings it back.")
  elseif arg == "on" then
    UW_GuildDB.syncOff = nil
    refresh()
    -- With the buttons above chat hidden (/uw hide) it wouldn't show: say what brings it back (red team, #576).
    say(ns.ChatBarHidden and ns.ChatBarHidden()
      and "Send-to-Discord button on. Your buttons above chat are hidden: /uw show brings them back."
      or "Send-to-Discord button on: it shows when guild news is waiting.")
  elseif not botPC() then
    say("/uw sync works on the PC that runs the UW bot. Here, guild news goes at your next reload or logout.")
  else
    say("Type /reload and the bot posts waiting guild news within about 10 seconds.")
  end
end

local MAX_QUESTS, MAX_OBJ, TEXT_MAX = 35, 8, 120
local function plain(v, kind)
  local secret = rawget(_G, "issecretvalue")
  if type(v) ~= kind or (secret and secret(v)) then return nil end
  if kind ~= "string" then return v end
  return (v:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("[%c|]", " "):sub(1, TEXT_MAX))
end
local function call(fn, ...) if type(fn) == "function" then local ok, a, b, c = pcall(fn, ...) if ok then return a, b, c end end end

-- This character's quest log as plain data (nothing secret, no links or escapes), or nil without the quest API.
function ns.QuestLogSnapshot()
  local log = rawget(_G, "C_QuestLog")
  if type(log) ~= "table" then return nil end
  local out = { at = time(), quests = {} }
  local mapApi, sup = rawget(_G, "C_Map"), rawget(_G, "C_SuperTrack")
  out.map = plain(call(mapApi and mapApi.GetBestMapForUnit, "player"), "number")
  local pos = out.map and call(mapApi.GetPlayerMapPosition, out.map, "player")
  if type(pos) == "table" then out.x, out.y = plain(pos.x, "number"), plain(pos.y, "number") end
  out.focus = plain(call(sup and sup.GetSuperTrackedQuestID), "number")
  -- Questie's view, for the guide owner: its name for each ID (Forever reuses some IDs for other quests) and whether
  -- it tracks the quest, read as Guide.lua reads it.
  local loader, Qs = rawget(_G, "QuestieLoader"), rawget(_G, "Questie")
  local qdb = type(loader) == "table" and call(loader.ImportModule, loader, "QuestieDB") or nil
  local qchar = type(Qs) == "table" and type(Qs.db) == "table" and type(Qs.db.char) == "table" and Qs.db.char or nil
  local qprof = type(Qs) == "table" and type(Qs.db) == "table" and type(Qs.db.profile) == "table" and Qs.db.profile or nil
  if type(UW_GuildCharDB) == "table" and type(UW_GuildCharDB.guideSkip) == "table" then
    out.guideSkip = {}
    for k, v in pairs(UW_GuildCharDB.guideSkip) do out.guideSkip[k] = v end
  end
  for i = 1, plain(call(log.GetNumQuestLogEntries), "number") or 0 do
    if #out.quests >= MAX_QUESTS then break end
    local info = call(log.GetInfo, i)
    local id = type(info) == "table" and not info.isHeader and plain(info.questID, "number")
    if id then
      local q = { id = id, title = plain(info.title, "string"), level = plain(info.level, "number"),
        done = call(log.IsComplete, id) and true or nil, obj = {} }
      for _, o in ipairs(type(call(log.GetQuestObjectives, id)) == "table" and call(log.GetQuestObjectives, id) or {}) do
        if #q.obj >= MAX_OBJ then break end
        if type(o) == "table" then
          q.obj[#q.obj + 1] = { plain(o.text, "string"), o.finished == true or nil,
            plain(o.numFulfilled, "number"), plain(o.numRequired, "number") }
        end
      end
      local m, x, y = call(log.GetNextWaypoint, id)
      m, x, y = plain(m, "number"), plain(x, "number"), plain(y, "number")
      if m and x and y then q.way = { m, x, y, plain(call(log.GetNextWaypointText, id), "string") } end
      local qq = type(qdb) == "table" and call(qdb.GetQuest, id) or nil
      q.questie = type(qq) == "table" and plain(qq.name, "string") or nil
      if qchar then
        if qprof and qprof.autoTrackQuests then q.tracked = not (type(qchar.AutoUntrackedQuests) == "table"
            and qchar.AutoUntrackedQuests[id]) or nil
        else q.tracked = type(qchar.TrackedQuests) == "table" and qchar.TrackedQuests[id] and true or nil end
      end
      out.quests[#out.quests + 1] = q
    end
  end
  return out
end

local function saveQuestLog()
  if not (botPC() and type(UW_GuildCharDB) == "table") then return end
  UW_GuildCharDB.questLog = ns.QuestLogSnapshot()
end

local f = CreateFrame("Frame")
ns.listen(f, { "PLAYER_ENTERING_WORLD", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "ZONE_CHANGED_NEW_AREA",
  "PLAYER_LOGOUT" })
f:SetScript("OnEvent", ns.guard(function(_, event)
  if event == "PLAYER_LOGOUT" then          -- fires on /reload too, just before WoW writes the save
    ns.protect(saveQuestLog)
  elseif event == "PLAYER_REGEN_DISABLED" then
    ns.protect(leaveBar)
  else
    ns.protect(refresh)
  end
end))
