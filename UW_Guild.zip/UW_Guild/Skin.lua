local _, ns = ...

-- UW_Guild's windows in EllesmereUI's look (Louis, 5 Nov 2026: "ensure all uw addons sense and align with e.ui's
-- current style"). EllesmereUI publishes a skinning interface for other addons (EllesmereUI\SKINNING_API.md,
-- apiVersion 4 on 13 Nov 2026; it only ever grows, so what we call keeps its signature): we hand it our frames and
-- it paints them in the player's current theme, and repaints them live when the theme or accent colour changes. We
-- never read its settings or textures ourselves.
--   * EllesmereUI missing, or the player turned skins off for UW Guild: the callback never runs, so every frame keeps
--     the game's own templates, the clean default the windows were built with.
--   * Each primitive is idempotent and runs protected here as well as on EllesmereUI's side, so a changed primitive
--     can cost a frame its skin but never a window.
-- The game's own popups (StaticPopup, used for UW_Guild's confirm and reload questions) are skinned by EllesmereUI's
-- Blizzard Skin module already, so nothing here touches them.

local skin -- EllesmereUI's skin facade, once it has called us back
local pending = {} -- frames made before that: { kind, frame, option }

local function apply(kind, frame, opt)
  local fn = skin and skin[kind]
  if type(fn) ~= "function" or type(frame) ~= "table" then return end
  pcall(fn, frame, opt)
end

-- ns.Skin("Button", b), ns.Skin("EditBox", box, { padInput = true }) ... returns the frame, so it can wrap a
-- CreateFrame call. Kinds are EllesmereUI's primitive names (Shell, Panel, Button, Checkbox, EditBox, CloseButton,
-- PageButton, ScrollBar, Tab, Font, Inset); an unknown one is skipped.
function ns.Skin(kind, frame, opt)
  if frame == nil then return frame end
  if skin then apply(kind, frame, opt) else pending[#pending + 1] = { kind, frame, opt } end
  return frame
end

-- A window from BasicFrameTemplateWithInset (or the plain backdrop fallback): the shell, its inset and close button.
function ns.SkinWindow(f)
  ns.Skin("Shell", f)
  if type(f) == "table" then
    if f.Inset then ns.Skin("Inset", f.Inset) end
    if f.CloseButton then ns.Skin("CloseButton", f.CloseButton) end
  end
  return f
end

function ns.Skinned() return skin ~= nil end

local edged = setmetatable({}, { __mode = "k" }) -- the red buttons (UI.Button), for their edge under the skin
local function edge(b)
  local e = rawget(b, "uwEdge")
  if e then e:SetShown(skin ~= nil and b:IsEnabled() and true or false) end
end
local function onSkin(S)
  skin = S
  local list = pending
  pending = {}
  for _, p in ipairs(list) do apply(p[1], p[2], p[3]) end
  for b in pairs(edged) do pcall(edge, b) end
end

-- At load: EllesmereUI is an optional dependency (.toc), so it has loaded first when it's installed. RegisterSkin
-- queues us and calls back at login, or at once when called later.
local eui = rawget(_G, "EllesmereUI")
if type(eui) == "table" and type(eui.RegisterSkin) == "function" then
  pcall(eui.RegisterSkin, "UW_Guild", onSkin)
end

-- One window layout (Louis, 10 Nov 2026, on five screenshots: "Lots of beautification before I put this in front of
-- others"). The UW Guild window (Handbook.lua) and Lead a group (Lead.lua) were each laid out on their own numbers:
-- fixed-height slots that left holes between a text and its buttons, a selected tab that looked switched off, a pager
-- under the tabs, answers wherever there was room. Both are now built from the pieces below:
--   title bar | rail (pages or tabs, yours lit) | heading row with the pager | content | answer line
--   * every gap is a step of 4 (4, 8, 12, 16), so edges and rows line up, in one window and across the two;
--   * same size, both centred: stepping from the guide into Lead a group reads as one window turning a page;
--   * where you are is lit (bar, white label). Grey only ever means "can't right now";
--   * flat colour, the game's fonts and button templates: EllesmereUI's skin and the game's own look both hold,
--     and nothing is built until a window first opens.
-- Our own lines and fills sit on frames EllesmereUI is never handed (it fades the textures of a frame it skins).
--
-- One look across the game, Discord and the site (design pass, 13 Nov 2026; the tokens and rules are in the project's
-- ops/design-system.md). What it asks of every UW_Guild window, and the piece here that does it:
--   * one red button per card and one in a window's foot (UI.Button); every other action is quiet (UI.Quiet), so a
--     page reads as text with one thing to do, not a wall of equal red buttons;
--   * one body text: the small white font with 2 px between lines (UI.Body), in the welcome as in the guide;
--   * an answer shows next to the click that caused it, from its first line; what doesn't fit is counted
--     ("3 more in chat"), never the start cut off (UI.AnswerSet);
--   * a button that's off has the template's own off look only, its reason in words beside it;
--   * numbers from here: PAD 16, GAP 8, HALF 4, GROUP 12 between groups, BTN 22, SMALL 20 for a list row's button,
--     CHECK 24 for a tick box, ROW 30 from one row of them to the next.
ns.UI = { W = 680, H = 520, EDGE = 8, TOP = 34, RAIL = 156, PAD = 16, GAP = 8, BTN = 22, NAV = 24, LINE = 12,
  HALF = 4, GROUP = 12, SMALL = 20, CHECK = 24, ROW = 30, SPACING = 2 }
local UI = ns.UI
UI.X = UI.EDGE + UI.RAIL + UI.PAD -- the content's left edge
UI.CW = UI.W - UI.X - UI.PAD      -- and its width
UI.BODY = UI.TOP + 36             -- where the content starts, under the heading's rule
UI.GOLD = { 1, 0.82, 0 }          -- the game's title gold (NORMAL_FONT_COLOR)
UI.LINK = { 0.45, 0.78, 1 }       -- text that goes somewhere
UI.EMBER = { 0.90, 0.49, 0.13 }   -- the thing to do, where the game's red button isn't drawn (E67E22, as in Discord)
UI.ONLINE = { 0.21, 0.82, 0.29 }  -- someone's there: the dot by a count of who's online
UI.GREY_DOT = { 0.45, 0.45, 0.45 } -- the same dot when nobody is
UI.MORE = "|cff808080%d more in chat|r" -- under an answer that was cut: the lines left out are in chat, whole

-- A game font by name: the font object where the client has it (every client takes the object; not all take a name).
function UI.Font(name) return rawget(_G, name) or name end
-- A number the client gave us, or nil: a value it keeps secret (issecretvalue, in a fight) is never compared.
local function num(v)
  local secret = rawget(_G, "issecretvalue")
  if v == nil or (secret and secret(v)) then return nil end
  return tonumber(v)
end
function UI.Fill(parent, layer, r, g, b, a)
  local t = parent:CreateTexture(nil, layer or "BACKGROUND")
  t:SetColorTexture(r, g, b, a)
  return t
end
-- Thin lines on whole screen pixels. A UI unit is rarely one pixel (1.8 px at Louis's 4K scale), so a plain 1-unit
-- line draws 1 px thick in one place and 2 px in the next. PixelUtil is the game's own answer; a client without it
-- keeps the plain size. Resnap sizes them again when a window shows, for a UI scale or screen changed since.
local thin = setmetatable({}, { __mode = "k" })
local function snap(t, w, h)
  local px = rawget(_G, "PixelUtil")
  px = type(px) == "table" and px or nil
  if w and not (px and px.SetWidth and pcall(px.SetWidth, t, w, 1)) then t:SetWidth(w) end
  if h and not (px and px.SetHeight and pcall(px.SetHeight, t, h, 1)) then t:SetHeight(h) end
end
function UI.Thin(t, w, h)
  thin[t] = { w or false, h or false }
  snap(t, w, h)
  return t
end
function UI.Resnap() for t, s in pairs(thin) do snap(t, s[1] or nil, s[2] or nil) end end
-- A hairline across the content.
function UI.Rule(parent, w)
  local t = UI.Fill(parent, "ARTWORK", 1, 1, 1, 0.09)
  t:SetWidth(w or UI.CW)
  return UI.Thin(t, nil, 1)
end
-- A sunken panel (the rail, a list). The game's look: a dark fill and a hairline edge. EllesmereUI swaps them for
-- its own inset panel, so the theme's colours carry.
function UI.Well(parent)
  local w = CreateFrame("Frame", nil, parent)
  UI.Fill(w, "BACKGROUND", 0, 0, 0, 0.3):SetAllPoints()
  for _, e in ipairs({ { "TOPLEFT", "TOPRIGHT", true }, { "BOTTOMLEFT", "BOTTOMRIGHT", true },
    { "TOPLEFT", "BOTTOMLEFT" }, { "TOPRIGHT", "BOTTOMRIGHT" } }) do
    local t = UI.Fill(w, "BORDER", 1, 1, 1, 0.09)
    t:SetPoint(e[1])
    t:SetPoint(e[2])
    if e[3] then UI.Thin(t, nil, 1) else UI.Thin(t, 1) end
  end
  return ns.Skin("Panel", w, { inset = true })
end

-- A window's title in its bar: one font and one place in every UW_Guild window (EllesmereUI's font under its skin).
function UI.Title(f, text)
  local t = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  t:SetPoint("TOP", 0, -6)
  t:SetText(text)
  ns.Skin("Font", t)
  return t
end
-- How far right of a text an edit box under it starts, to sit flush with it: the game's box art runs 6 px left of
-- the box, EllesmereUI's doesn't.
function UI.BoxInset() return ns.Skinned() and 0 or 6 end

-- Body text: the one size every window reads in, left-aligned, 2 px between its lines.
function UI.Body(parent, w, tmpl)
  local fs = parent:CreateFontString(nil, "OVERLAY", tmpl or "GameFontHighlightSmall")
  fs:SetJustifyH("LEFT")
  if fs.SetJustifyV then fs:SetJustifyV("TOP") end
  if w then fs:SetWidth(w) end
  if fs.SetSpacing then fs:SetSpacing(UI.SPACING) end
  return fs
end

-- The one thing a card or a window's foot asks you to do: the game's own red button. Under EllesmereUI's skin every
-- button is flat with a grey edge, so the red is gone and the one button looked like the quiet ones beside it: there
-- it wears an ember edge, on a frame of its own (EllesmereUI fades the art of a frame it skins), while it's on.
local EDGES = { { "TOPLEFT", "TOPRIGHT", true }, { "BOTTOMLEFT", "BOTTOMRIGHT", true }, { "TOPLEFT", "BOTTOMLEFT" },
  { "TOPRIGHT", "BOTTOMRIGHT" } }
local function edges(frame, layer, r, g, b, a)
  for _, e in ipairs(EDGES) do
    local t = UI.Fill(frame, layer, r, g, b, a)
    t:SetPoint(e[1])
    t:SetPoint(e[2])
    if e[3] then UI.Thin(t, nil, 1) else UI.Thin(t, 1) end
  end
end
function UI.Button(parent, w, label)
  local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  b:SetSize(w or 120, UI.BTN)
  if label then b:SetText(label) end
  b.uwEdge = CreateFrame("Frame", nil, b)
  b.uwEdge:SetAllPoints(b)
  edges(b.uwEdge, "OVERLAY", UI.EMBER[1], UI.EMBER[2], UI.EMBER[3], 0.9)
  edged[b] = true
  edge(b)
  return ns.Skin("Button", b)
end
-- A button on or off: off is the template's own look and nothing more, and the red button's ember edge goes with it.
function UI.Enable(b, on)
  b:SetEnabled(on and true or false)
  edge(b)
end
-- A game icon (design critique, 14 Nov 2026: "no icons anywhere", so every entry looked the same until read). The
-- picture is the client's own for a spell or an item: no art is shipped. row: kind ("spell", "item", or "class" for
-- the player's own class, with a spell to fall back on), ID, and the game's English name for that ID. Nothing comes
-- back when the client has no such lookup or no such ID, or when an English client knows the ID by another name: a
-- wrong ID then shows nothing, never a stranger's picture. A name the client hasn't loaded yet is trusted.
-- Returns the picture (and, for a class, its cell on the sheet; third value true when the client gave no name to
-- compare), or nil and why: "missing", or the name this client knows the ID by (for the client check, Handbook.lua).
UI.ICON, UI.NAV_ICON = 32, 20 -- an entry's icon, a page's icon
local ENGLISH = { enUS = true, enGB = true }
local function ask(space, name, id)
  local fn = type(space) == "table" and rawget(space, name) or nil
  if type(fn) ~= "function" then return nil end
  local ok, v = pcall(fn, id)
  if ok and v ~= nil and not ns.isSecret(v) then return v end
end
-- A class's picture: the game's own class sheet and that class's cell on it, where the client has both.
function UI.ClassIcon(class)
  local cells = rawget(_G, "CLASS_ICON_TCOORDS")
  local cell = type(class) == "string" and type(cells) == "table" and cells[class]
  if type(cell) == "table" then return "Interface\\GLUES\\CHARACTERCREATE\\UI-CHARACTERCREATE-CLASSES", cell end
end
function UI.GameIcon(row)
  local kind, id, name = row[1], row[2], row[3]
  if kind == "class" then
    local ok, _, class = pcall(UnitClass, "player")
    local sheet, cell = UI.ClassIcon(ok and class or nil)
    if sheet then return sheet, cell end
    kind = "spell"
  end
  local spells, items, locale = rawget(_G, "C_Spell"), rawget(_G, "C_Item"), ask(_G, "GetLocale")
  local tex, known
  if kind == "spell" then
    local info = ask(spells, "GetSpellInfo", id)
    info = type(info) == "table" and info or {}
    tex = ask(spells, "GetSpellTexture", id) or info.iconID or ask(_G, "GetSpellTexture", id)
    known = ask(spells, "GetSpellName", id) or info.name or ask(_G, "GetSpellInfo", id)
  else
    tex = ask(items, "GetItemIconByID", id) or ask(_G, "GetItemIcon", id)
    known = ask(items, "GetItemNameByID", id) or ask(_G, "GetItemInfo", id)
  end
  if not tex or tex == 0 or tex == "" then return nil, "missing" end
  if type(known) == "string" and known ~= name and ENGLISH[locale or ""] then return nil, known end
  return tex, nil, type(known) ~= "string"
end
-- Whether this client's names can be held against the English ones in the icon table.
function UI.English() return ENGLISH[ask(_G, "GetLocale") or ""] or false end
-- The frame for one: the picture in a 1 px black edge, as the game frames its own, with the art's baked edge
-- cropped off. Hidden until IconSet finds a picture, so a missing one is never an empty square. EllesmereUI is
-- never handed it.
function UI.Icon(parent, size)
  local f = CreateFrame("Frame", nil, parent)
  f:SetSize(size, size)
  f.tex = f:CreateTexture(nil, "ARTWORK")
  f.tex:SetAllPoints()
  edges(f, "OVERLAY", 0, 0, 0, 1)
  f:Hide()
  return f
end
-- Shows a row's picture, grey for a thing that's off; hides the frame when there's none. Returns: is it showing.
function UI.IconSet(icon, row, grey)
  local tex, cell
  if row then tex, cell = UI.GameIcon(row) end
  if tex then
    icon.tex:SetTexture(tex)
    if cell then icon.tex:SetTexCoord(cell[1], cell[2], cell[3], cell[4])
    else icon.tex:SetTexCoord(0.07, 0.93, 0.07, 0.93) end
    if icon.tex.SetDesaturated then icon.tex:SetDesaturated(grey and true or false) end
  end
  icon:SetShown(tex ~= nil)
  return tex ~= nil
end

-- Every other action: quiet. A flat fill, a hairline edge and the small gold label, lighter under the pointer; off,
-- its label is the game's grey. Drawn here in either look (EllesmereUI is never handed it), so the red button, or
-- EllesmereUI's, stays the one that stands out. h: UI.BTN beside other buttons (the default), UI.SMALL in a list row.
-- body: its label in the body's white, at the body's size, on a fill and an edge a little stronger (design spec,
-- 14 Nov 2026: gold is for titles and the red button, everything else is white on dark). The guide's rows have it;
-- each other window takes it as it's rebuilt to the spec. Under EllesmereUI its edge is the shell's own dim line, so
-- the button sits back in a flat window (design director, #628).
function UI.Quiet(parent, w, label, h, body)
  local b = CreateFrame("Button", nil, parent)
  b:SetSize(w or 90, h or UI.BTN)
  b.body = body and true or false
  b.fill = UI.Fill(b, "BACKGROUND", 1, 1, 1, body and 0.10 or 0.07)
  b.fill:SetAllPoints()
  edges(b, "BORDER", 1, 1, 1, body and (ns.Skinned() and 0.09 or 0.25) or 0.14)
  UI.Fill(b, "HIGHLIGHT", 1, 1, 1, 0.09):SetAllPoints()
  -- Lit while it's the choice that's on (a filter): the bar and white label the rail gives the page you're on.
  b.bar = UI.Fill(b, "ARTWORK", UI.GOLD[1], UI.GOLD[2], UI.GOLD[3], 1)
  b.bar:SetPoint("BOTTOMLEFT")
  b.bar:SetPoint("BOTTOMRIGHT")
  UI.Thin(b.bar, nil, 2)
  b.bar:Hide()
  b.label = b:CreateFontString(nil, "OVERLAY", body and "GameFontHighlight" or "GameFontNormalSmall")
  b.label:SetPoint("CENTER")
  if b.SetFontString then b:SetFontString(b.label) end
  b:SetNormalFontObject(UI.Font(body and "GameFontHighlight" or "GameFontNormalSmall"))
  b:SetHighlightFontObject(UI.Font(body and "GameFontHighlight" or "GameFontHighlightSmall"))
  b:SetDisabledFontObject(UI.Font(body and "GameFontDisable" or "GameFontDisableSmall"))
  if b.SetPushedTextOffset then b:SetPushedTextOffset(1, -1) end
  if label then b:SetText(label) end
  return b
end
function UI.QuietOn(b, on)
  on = on and true or false
  b.bar:SetShown(on)
  -- The body's look is white already: the one that's on has the bar and a lighter fill.
  if b.body then
    b.fill:SetColorTexture(1, 1, 1, on and 0.18 or 0.10)
  else
    b:SetNormalFontObject(UI.Font(on and "GameFontHighlightSmall" or "GameFontNormalSmall"))
  end
end
-- A button as wide as its label and the room each side of it, between least and most.
function UI.FitButton(b, label, pad, least, most)
  local tw = num(b.GetTextWidth and b:GetTextWidth())
  if not tw or tw <= 0 then tw = #label * 6 end
  local w = math.max(least, math.min(most, math.ceil(tw) + pad))
  b:SetWidth(w)
  return w
end

-- The game's one tooltip, for a control of ours. Hidden only while it's still that control's: a unit or an item
-- under the pointer, or another addon, may have taken it since, and theirs is not ours to hide (red team, #628).
-- The game's tooltip lets what's under it show through: how much is the client's choice, or a skin's. Ours can sit
-- over the window's own rows (a small screen has no room beside the window), where a line showing through a line
-- reads as neither. So while the tooltip is one of ours, a dark sheet lies right behind it: our own frame, in the
-- strata just under the tooltip's, following the tooltip's edges from inside its border. Nothing of the tooltip's
-- is changed or hooked. The sheet goes with the tooltip, and looks while it shows: a tooltip the game hid, or that
-- something else took, is not ours to back.
local function tipIs(owner)
  local t = rawget(_G, "GameTooltip")
  if not (t and t.IsShown and t:IsShown() == true) then return false end
  if not t.GetOwner then return true end
  local ok, whose = pcall(t.GetOwner, t)
  return ok and whose == owner
end
function UI.TipBack(owner)
  local t = rawget(_G, "GameTooltip")
  if not t then return end
  local sheet = UI.sheet
  if not sheet then
    sheet = CreateFrame("Frame", nil, rawget(_G, "UIParent"))
    sheet:SetFrameStrata("FULLSCREEN_DIALOG")
    UI.Fill(sheet, "BACKGROUND", 0.03, 0.03, 0.04, 1):SetAllPoints()
    sheet:SetScript("OnUpdate", function(self) if not tipIs(self.owner) then self:Hide() end end)
    UI.sheet = sheet
  end
  local inset = ns.Skinned() and 2 or 4 -- inside the border's rounded corners; a skin's border is a hairline
  sheet.owner = owner
  sheet:ClearAllPoints()
  sheet:SetPoint("TOPLEFT", t, "TOPLEFT", inset, -inset)
  sheet:SetPoint("BOTTOMRIGHT", t, "BOTTOMRIGHT", -inset, inset)
  sheet:Show()
end
function UI.TipBackOff(owner)
  if UI.sheet and UI.sheet.owner == owner then UI.sheet:Hide() end
end
-- A plain tooltip beside owner: a title in white, and a line under it.
function UI.Tip(owner, title, text)
  local t = rawget(_G, "GameTooltip")
  if not t then return end
  t:SetOwner(owner, "ANCHOR_RIGHT")
  t:SetText(title, 1, 1, 1, 1, true)
  if text then t:AddLine(text, nil, nil, nil, true) end
  t:Show()
  UI.TipBack(owner)
end
-- The same tooltip beside the window, level with what it's for (a row's whole text; a button inside a row), so it
-- lies on no row still to be read and on none of the pointed-at row's buttons (the guide's own rows do the same;
-- design director, 14 Nov 2026): to the window's right where the screen has room for it, else to its left, else
-- over its owner from the owner's right end, where the game keeps it on the screen (a small screen: 1440x900 at UI
-- scale 1.15 has room on neither side).
UI.TIP_GAP = 2 -- from the window's edge to the tooltip
local function letters(s) return #((s or ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")) end
-- look: { title = { r, g, b }, text = { r, g, b } }; the title is white and the line the tooltip's own gold without.
function UI.TipBeside(owner, win, title, text, look)
  local t = rawget(_G, "GameTooltip")
  if not t then return end
  local tc, lc = look and look.title or { 1, 1, 1 }, look and look.text or {}
  t:SetOwner(owner, "ANCHOR_NONE")
  -- It has a place before it shows (over its owner, the place it keeps when no side has room), and is moved once
  -- the game has said how wide it made it: a tooltip shown with no point at all has nowhere to draw.
  t:ClearAllPoints()
  t:SetPoint("BOTTOMLEFT", owner, "TOPRIGHT", 0, 0)
  t:SetText(title, tc[1], tc[2], tc[3], 1, true)
  if text then t:AddLine(text, lc[1], lc[2], lc[3], true) end
  t:Show()
  -- As wide as the game made it; before it can say, by its letters (7 a letter, and its two margins).
  local w = num(t.GetWidth and t:GetWidth())
  if not w or w <= 0 then w = math.max(letters(title), letters(text)) * 7 + 24 end
  local ui = rawget(_G, "UIParent")
  local screen = num(ui and ui.GetWidth and ui:GetWidth())
  local right, left = num(win.GetRight and win:GetRight()), num(win.GetLeft and win:GetLeft())
  local mine, from = num(owner.GetRight and owner:GetRight()), num(owner.GetLeft and owner:GetLeft())
  if screen and right and mine and right + UI.TIP_GAP + w <= screen then
    t:ClearAllPoints()
    t:SetPoint("TOPLEFT", owner, "TOPRIGHT", right - mine + UI.TIP_GAP, 0)
  elseif left and from and left - UI.TIP_GAP - w >= 0 then
    t:ClearAllPoints()
    t:SetPoint("TOPRIGHT", owner, "TOPLEFT", left - from - UI.TIP_GAP, 0)
  end
  UI.TipBack(owner)
end
-- Hidden only while it's still owner's: the game has one tooltip, and what took it since is not ours to hide.
function UI.TipHide(owner)
  UI.TipBackOff(owner)
  local t = rawget(_G, "GameTooltip")
  if not t then return end
  if t.GetOwner then
    local ok, whose = pcall(t.GetOwner, t)
    if not ok or whose ~= owner then return end
  end
  t:Hide()
end

-- People as a table (design director's spec, section 4, 14 Nov 2026; Louis the same day: "Build the addon!"). A list
-- of guildmates was a list of sentences ("Name  22  Thunder Bluff  could help"), each with its two buttons: Leads
-- showed 24 of them. A person is a row of columns now: class icon, name in the class's colour, level right-aligned,
-- then the list's last column (a zone, a buddy), the only one that shortens. A short grey word at the right end
-- says what they're doing (away, said inv). Their buttons show on the row under the pointer only, and push the last
-- column aside, never cover it. Sizes, in UI units:
--   h, head, group, tall: a person's row, the header row (the columns' names in small grey capitals), a label over
--     a group of rows, a sentence's row (two lines);
--   icon, pad, gap: the class icon, the row's left margin, from the icon to the name;
--   lvl, after: the level's box, and from it to the last column;
--   cut: the last column is hidden under this width (two letters and three dots say nothing; the pointer then
--     shows the row whole);
--   least, most: the name column is as wide as the widest name shown, between these;
--   act, before, right: between two buttons, from the last column to the first of them, the row's right margin.
UI.PERSON = { h = 24, head = 20, group = 22, tall = 38, icon = 16, pad = 8, gap = 7, lvl = 22, after = 12, cut = 36,
  least = 120, most = 200, act = 5, before = 8, right = 4 }
local P = UI.PERSON
local SOFT, FAINT = { 0.81, 0.81, 0.81 }, { 0.5, 0.5, 0.5 } -- the last column; a busy guildmate's row, and the word
local function bare(s) return (s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")) end
-- A class's colour, from the game's own table; white for a class it doesn't hold.
function UI.ClassColor(class)
  local all = rawget(_G, "RAID_CLASS_COLORS")
  local c = type(class) == "string" and type(all) == "table" and all[class]
  if type(c) ~= "table" then return 1, 1, 1 end
  if type(c.r) == "number" and type(c.g) == "number" and type(c.b) == "number" then return c.r, c.g, c.b end
  if type(c.colorStr) == "string" then
    local r, g, b = c.colorStr:match("^%x%x(%x%x)(%x%x)(%x%x)$")
    if r then return tonumber(r, 16) / 255, tonumber(g, 16) / 255, tonumber(b, 16) / 255 end
  end
  return 1, 1, 1
end
-- How wide a text is on one line. ruler: a font string in the rows' font, kept empty. A text the client can't
-- measure yet counts per px a letter (7; a button's label 6, as UI.FitButton counts it).
function UI.TextWidth(ruler, text, per)
  ruler:SetText(text)
  local w = num(ruler:GetStringWidth())
  ruler:SetText("")
  if not w or w <= 0 then w = #bare(text) * (per or 7) end
  return math.ceil(w)
end
-- The name column for these names: as wide as the widest, between least and most.
function UI.NameWidth(ruler, names)
  local w = 0
  for _, name in ipairs(names) do w = math.max(w, UI.TextWidth(ruler, name)) end
  return math.max(P.least, math.min(P.most, w))
end
-- A row's buttons, at its right end: quiet, in the body's white, as wide as their words. On a person's row they
-- show under the pointer only; a row marked always (a sentence with its Send) keeps them.
function UI.RowActs(row, n)
  row.acts, row.over, row.always, row.taken = {}, false, false, P.right
  -- The row's wash (PersonLay): lights says whether the pointer lights it, sel that it's the one picked.
  row.glow = UI.Fill(row, "BACKGROUND", 1, 1, 1, 0.06)
  row.glow:SetAllPoints()
  row.glow:Hide()
  row.lights, row.sel = false, false
  for i = 1, n do
    local b = UI.Quiet(row, 60, nil, UI.SMALL, true)
    b.fn, b.wide = false, 0 -- fn: false, never nil, while the button has nothing to do
    b:Hide()
    -- Off a button, onto the row's bare part or away from it: the row decides.
    b:SetScript("OnLeave", function() UI.RowLeave(row) end)
    row.acts[i] = b
  end
  return row.acts
end
function UI.ActSet(b, label, fn)
  b.fn = fn or false
  if fn then
    b:SetText(label)
    b.wide = UI.FitButton(b, label, 18, 40, 120)
  end
end
-- The parts of a person's row, on a row that has its buttons (RowActs): PersonSet fills them, PersonLay places
-- what moves, PersonOff hides them for a row that holds something else.
function UI.Person(row)
  row.icon = UI.Icon(row, P.icon)
  row.icon:SetPoint("LEFT", P.pad, 0)
  local function cell(just)
    local fs = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    fs:SetJustifyH(just or "LEFT")
    if fs.SetWordWrap then fs:SetWordWrap(false) end
    fs:Hide()
    return fs
  end
  row.name = cell()
  row.name:SetPoint("LEFT", P.pad + P.icon + P.gap, 0)
  row.lvl = cell("RIGHT")
  row.lvl:SetWidth(P.lvl)
  row.mate = UI.Icon(row, P.icon)
  row.last = cell()
  row.tag = cell("RIGHT")
  row.tag:SetTextColor(FAINT[1], FAINT[2], FAINT[3])
  row.person = false
  return row
end
function UI.PersonOff(row)
  row.person = false
  for _, k in ipairs({ "icon", "name", "lvl", "mate", "last", "tag" }) do row[k]:Hide() end
end
-- Where the row's buttons are, and so how much is left for the last column and the word at the right. The word
-- keeps its whole width while it can; the last column takes what's left and is hidden under P.cut. Under the
-- pointer, with the buttons up, the last column comes first: the word is hidden where both don't fit.
function UI.PersonLay(row)
  -- The row's wash: under the pointer (and under the pointer on one of its buttons, which a HIGHLIGHT layer
  -- drops), or in the title's colour while it's the one picked.
  local lit = row.sel or (row.over and row.lights) or false
  row.glow:SetShown(lit and true or false)
  if row.sel then
    local c = ns.Skinned() and UI.EMBER or UI.GOLD
    row.glow:SetColorTexture(c[1], c[2], c[3], 0.14)
  elseif lit then
    row.glow:SetColorTexture(1, 1, 1, 0.06)
  end
  local right, n = P.right, 0
  for i = #row.acts, 1, -1 do
    local b = row.acts[i]
    local on = b.fn and (row.always or row.over) and true or false
    b:SetShown(on)
    if on then
      b:ClearAllPoints()
      b:SetPoint("RIGHT", row, "RIGHT", -right, 0)
      right, n = right + b.wide + P.act, n + 1
    end
  end
  if n > 0 then right = right - P.act + P.before end
  row.taken = right
  local p = row.person
  if not p then return end
  local room, tagW = row.wide - row.lastX - right, 0
  if (p.tag or "") ~= "" then
    tagW = num(row.tag:GetStringWidth())
    if not tagW or tagW <= 0 then tagW = #bare(p.tag) * 7 end
    tagW = math.min(math.ceil(tagW), math.max(0, room))
    -- With the buttons up there may be room for one of the two: the column the list is about stays and the word
    -- waits (the pointer shows the row whole).
    if n > 0 and (p.last or "") ~= "" and room >= P.cut and room - tagW - P.before < P.cut then tagW = 0 end
  end
  local wordOff = (p.tag or "") ~= "" and tagW == 0
  row.tag:SetShown(tagW > 0)
  if tagW > 0 then
    row.tag:SetWidth(tagW)
    if row.tagAt ~= right then -- hung again only when the buttons beside it come or go
      row.tag:ClearAllPoints()
      row.tag:SetPoint("RIGHT", row, "RIGHT", -right, 0)
      row.tagAt = right
    end
    room = room - tagW - P.before
  end
  row.last:SetShown(room >= P.cut)
  if room >= P.cut then row.last:SetWidth(room) end
  -- No room for the last column, or for the word: the pointer shows the row whole.
  row.cut = (room < P.cut and (p.last or "") ~= "") or wordOff
end
-- One person: p = { name, cls, level, last (the last column's text), mate ({ name, cls }: the last column is a
-- guildmate, drawn with their class icon and colour), tag (the word at the right), grey (busy or away: the whole
-- row in grey) }. nameW: the list's name column; wide: the row's width.
function UI.PersonSet(row, p, nameW, wide)
  row.person, row.wide = p, wide
  local grey = p.grey and true or false
  local function paint(fs, r, g, b)
    if grey then fs:SetTextColor(FAINT[1], FAINT[2], FAINT[3]) else fs:SetTextColor(r, g, b) end
  end
  local function class(icon, cls)
    local sheet, cell = UI.ClassIcon(cls)
    if sheet then
      icon.tex:SetTexture(sheet)
      icon.tex:SetTexCoord(cell[1], cell[2], cell[3], cell[4])
      if icon.tex.SetDesaturated then icon.tex:SetDesaturated(grey) end
    end
    icon:SetShown(sheet ~= nil)
    return sheet ~= nil
  end
  class(row.icon, p.cls)
  row.name:SetText(p.name or "")
  row.name:SetWidth(nameW)
  paint(row.name, UI.ClassColor(p.cls))
  row.name:Show()
  row.lvl:SetText(p.level and tostring(p.level) or "")
  paint(row.lvl, 1, 1, 1)
  row.lvl:Show()
  -- The level and what follows it move with the name column only: a text hung again can measure 0 for a frame.
  local x = P.pad + P.icon + P.gap + nameW
  if row.lvlAt ~= x then
    row.lvl:ClearAllPoints()
    row.lvl:SetPoint("LEFT", row, "LEFT", x, 0)
    row.mate:ClearAllPoints()
    row.mate:SetPoint("LEFT", row, "LEFT", x + P.lvl + P.after, 0)
    row.lvlAt = x
  end
  local mate = type(p.mate) == "table" and p.mate or nil
  local pictured = mate ~= nil and class(row.mate, mate.cls)
  if not mate then row.mate:Hide() end
  local lastX = x + P.lvl + P.after + (pictured and P.icon + P.gap or 0)
  if row.lastAt ~= lastX then
    row.last:ClearAllPoints()
    row.last:SetPoint("LEFT", row, "LEFT", lastX, 0)
    row.lastAt = lastX
  end
  row.lastX = lastX
  row.last:SetText(p.last or "")
  if mate then paint(row.last, UI.ClassColor(mate.cls)) else paint(row.last, SOFT[1], SOFT[2], SOFT[3]) end
  row.tag:SetText(p.tag or "")
  UI.PersonLay(row)
end
-- The pointer came onto the row, or left it or one of its buttons. A button is inside the row, so the client is
-- asked whether the pointer is still over the row before its buttons go.
-- A person's row whole, for a row whose last column or word is cut: the name as the tooltip's title, in the class's
-- colour, and under it the level, the last column and the word as the row holds them. Two short lines, not the row
-- as one long one: a 30-letter name with a long zone is then narrow enough to stand beside the window on a 1080p
-- screen (342 units a side), where one line of it was not.
function UI.PersonTip(row, win)
  local p = row.person
  if type(p) ~= "table" then return end
  local rest = {}
  if p.level then rest[#rest + 1] = tostring(p.level) end
  if (p.last or "") ~= "" then rest[#rest + 1] = bare(p.last) end
  if (p.tag or "") ~= "" then rest[#rest + 1] = ("|cff808080%s|r"):format(bare(p.tag)) end
  UI.TipBeside(row, win, p.name or "", #rest > 0 and table.concat(rest, "  ") or nil,
    { title = { UI.ClassColor(p.cls) }, text = { 1, 1, 1 } })
end
function UI.RowEnter(row)
  if not row.over then
    row.over = true
    UI.PersonLay(row)
  end
end
function UI.RowLeave(row)
  local still = row.IsMouseOver and row:IsMouseOver() == true or false
  if not still then
    UI.TipHide(row)
    if row.over then
      row.over = false
      UI.PersonLay(row)
    end
  end
  return still
end
-- The header over a table: up to three column names in small grey capitals, over the name, the level and the last
-- column, with a hairline under them.
function UI.Cols(parent, wide)
  local h = CreateFrame("Frame", nil, parent)
  h:SetSize(wide, P.head)
  h.c = {}
  for i = 1, 3 do
    h.c[i] = h:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    h.c[i]:SetJustifyH(i == 2 and "RIGHT" or "LEFT")
  end
  h.c[1]:SetPoint("LEFT", P.pad, 0)
  h.c[2]:SetWidth(P.lvl + P.icon)
  h.rule = UI.Rule(h, wide)
  h.rule:SetPoint("BOTTOMLEFT")
  h:Hide()
  return h
end
function UI.ColsSet(h, cols, nameW)
  h:SetShown(cols ~= nil)
  if not cols then return end
  for i = 1, 3 do h.c[i]:SetText((cols[i] or ""):upper()) end
  local x = P.pad + P.icon + P.gap + nameW
  if h.at ~= x then
    h.c[2]:ClearAllPoints()
    h.c[2]:SetPoint("RIGHT", h, "LEFT", x + P.lvl, 0)
    h.c[3]:ClearAllPoints()
    h.c[3]:SetPoint("LEFT", h, "LEFT", x + P.lvl + P.after, 0)
    h.at = x
  end
end

-- The window: movable, Esc closes it, title in the bar, the rail down the left. body holds our own lines and fills.
function UI.Window(name, title, strata)
  local ok, f = pcall(CreateFrame, "Frame", name, UIParent, "BasicFrameTemplateWithInset")
  if not ok or not f then f = CreateFrame("Frame", name, UIParent, "BackdropTemplate") end
  f:SetSize(UI.W, UI.H)
  f:SetPoint("CENTER")
  f:SetFrameStrata(strata)
  f:SetMovable(true)
  if f.SetClampedToScreen then f:SetClampedToScreen(true) end
  f:EnableMouse(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  tinsert(UISpecialFrames, name)
  ns.SkinWindow(f)
  UI.Title(f, title)
  f.body = CreateFrame("Frame", nil, f)
  f.body:SetAllPoints()
  f.body:SetScript("OnShow", UI.Resnap) -- our own child: shown with the window, whatever script the window sets
  f.rail = UI.Well(f)
  f.rail:SetPoint("TOPLEFT", UI.EDGE, -UI.TOP)
  f.rail:SetPoint("BOTTOMLEFT", UI.EDGE, UI.EDGE)
  f.rail:SetWidth(UI.RAIL)
  f.heading = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  f.heading:SetPoint("TOPLEFT", UI.X, -UI.TOP)
  f.heading:SetJustifyH("LEFT")
  UI.Rule(f.body):SetPoint("TOPLEFT", UI.X, -UI.TOP - 24)
  return f
end
-- A smaller line on the heading's baseline: what the page is showing, or a state the whole window is in.
function UI.Sub(f, tmpl)
  local fs = f:CreateFontString(nil, "OVERLAY", tmpl or "GameFontHighlightSmall")
  fs:SetPoint("BOTTOMLEFT", f.heading, "BOTTOMRIGHT", UI.LINE, 1)
  fs:SetJustifyH("LEFT")
  return fs
end

-- A page or tab on the rail: a text row. Lit when it's the one showing, a faint fill under the pointer.
function UI.Nav(f, text)
  local b = CreateFrame("Button", nil, f.rail)
  b:SetSize(UI.RAIL - 2, UI.NAV)
  b.lit = UI.Fill(b, "BACKGROUND", 1, 1, 1, 0.09)
  b.lit:SetAllPoints()
  b.bar = UI.Fill(b, "ARTWORK", UI.GOLD[1], UI.GOLD[2], UI.GOLD[3], 1)
  b.bar:SetPoint("TOPLEFT")
  b.bar:SetPoint("BOTTOMLEFT")
  UI.Thin(b.bar, 2)
  UI.Fill(b, "HIGHLIGHT", 1, 1, 1, 0.06):SetAllPoints()
  b.label = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  b.label:SetPoint("LEFT", 12, 0)
  b.label:SetPoint("RIGHT", -6, 0)
  b.label:SetJustifyH("LEFT")
  if b.label.SetWordWrap then b.label:SetWordWrap(false) end
  b.label:SetText(text)
  return b
end
-- Marks the one showing and stacks the rest under each other, top down. list: the rail's buttons, each with shown
-- (does this player get it) set by its window; one they don't get leaves no hole.
function UI.NavSet(f, list, isOn)
  local y = -4
  for _, b in ipairs(list) do
    local on = isOn(b) and true or false
    b.lit:SetShown(on)
    b.bar:SetShown(on)
    b.label:SetFontObject(UI.Font(on and "GameFontHighlight" or "GameFontNormal"))
    b:SetShown(b.shown and true or false)
    if b.shown then
      b:ClearAllPoints()
      b:SetPoint("TOPLEFT", f.rail, "TOPLEFT", 1, y)
      y = y - UI.NAV - 4
    end
  end
end

-- "Page 2 of 3" and its two arrows, right of the heading. Both arrows stay put; the one with nowhere to go is off.
-- step(-1 or 1) turns the page. The game's own page arrows, or EllesmereUI's.
function UI.Pager(f, step, place)
  local p = {}
  local function arrow(dir, way, ch)
    local b = CreateFrame("Button", nil, f)
    b:SetSize(UI.BTN, UI.BTN)
    b:SetNormalTexture("Interface\\Buttons\\UI-SpellbookIcon-" .. dir .. "Page-Up")
    b:SetPushedTexture("Interface\\Buttons\\UI-SpellbookIcon-" .. dir .. "Page-Down")
    b:SetDisabledTexture("Interface\\Buttons\\UI-SpellbookIcon-" .. dir .. "Page-Disabled")
    b:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
    b.uwPage = ch
    b:SetScript("OnClick", function() step(way) end)
    return ns.Skin("PageButton", b, ch)
  end
  p.next = arrow("Next", 1, ">")
  -- In the heading row; a window without one (the welcome) says where its right-hand arrow goes.
  if place then place(p.next) else p.next:SetPoint("TOPRIGHT", f, "TOPRIGHT", -UI.PAD, -UI.TOP + 3) end
  p.prev = arrow("Prev", -1, "<")
  p.prev:SetPoint("RIGHT", p.next, "LEFT", -4, 0)
  p.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  p.text:SetPoint("RIGHT", p.prev, "LEFT", -UI.GAP, 0)
  -- The mouse wheel turns the page anywhere over the window, as it does in the game's spellbook: up is back. Only
  -- where the arrow that way could be clicked.
  if f.EnableMouseWheel then
    f:EnableMouseWheel(true)
    f:SetScript("OnMouseWheel", function(_, delta)
      delta = num(delta)
      if not delta or delta == 0 then return end
      local b = delta > 0 and p.prev or p.next
      if b:IsShown() and b:IsEnabled() then step(delta > 0 and -1 or 1) end
    end)
  end
  return p
end
function UI.PagerSet(p, page, pages)
  local many = pages > 1
  p.text:SetShown(many)
  p.prev:SetShown(many)
  p.next:SetShown(many)
  p.text:SetText(("Page %d of %d"):format(page, pages))
  p.prev:SetEnabled(page > 1)
  p.next:SetEnabled(page < pages)
end

-- A text the client can't measure where it is (a window's first show) is measured on a ruler: a font string of the
-- same font and width on the always-shown UIParent, one per font, never seen (alpha 0, and empty between uses).
local rulers = {}
local function onRuler(fs)
  local parent = rawget(_G, "UIParent")
  if not (type(parent) == "table" and parent.CreateFontString and fs.GetFont and fs.GetText and fs.GetWidth) then return nil end
  local file, size, flags = fs:GetFont()
  local text, w = fs:GetText(), num(fs:GetWidth())
  size = num(size)
  if type(file) ~= "string" or not size or type(text) ~= "string" or text == "" or not w or w < 1 then return nil end
  local key = ("%s %s %s"):format(file, size, type(flags) == "string" and flags or "")
  local r = rulers[key]
  if r == nil then
    r = parent:CreateFontString(nil, "BACKGROUND")
    r:SetFont(file, size, type(flags) == "string" and flags or "")
    if type((r:GetFont())) ~= "string" then rulers[key] = false return nil end -- the font didn't take: no ruler
    r:SetJustifyH("LEFT")
    r:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, 0)
    if r.SetAlpha then r:SetAlpha(0) end
    rulers[key] = r
  end
  if not r then return nil end
  r:SetWidth(w)
  if r.SetSpacing then r:SetSpacing(fs.GetSpacing and num(fs:GetSpacing()) or 0) end
  r:SetText(text)
  local h = num(r:GetStringHeight())
  r:SetText("")
  return h and h > 0 and h or nil
end
-- A wrapped text's height: where it is, else on the ruler, else a guess (and never a value the client keeps secret).
function UI.TextHeight(fs, guess)
  local h = num(fs:GetStringHeight())
  if h and h > 0 then return h end
  local ok, measured = pcall(onRuler, fs)
  return ok and measured or guess
end
-- The lines a text wraps to at the content's width, for when the client can't measure it: about 6 px a letter in the
-- small font. Colour codes and links aren't letters, a typed "||" is one, an icon is about two, and a text with its
-- own line breaks is counted run by run (red team, #572).
local function wraps(s, per)
  local plain = s:gsub("||", "\1"):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|H.-|h", ""):gsub("|h", "")
    :gsub("|T.-|t", "  "):gsub("|A.-|a", "  ")
  local n = 0
  for run in (plain .. "\n"):gmatch("(.-)\n") do n = n + math.max(1, math.ceil(#run / per)) end
  return n
end
-- The lines a list of texts takes, one under the other, from its from-th. per: letters a line holds, for a text in
-- another font or width than the content's small one.
function UI.Lines(lines, from, per)
  local n = 0
  for i = from or 1, #lines do n = n + wraps(lines[i], per or UI.CW / 6) end
  return n
end
-- What a click just said, shown beside it. Head first: its lines from the first one, as many as fit in room (px);
-- the ones left out are counted in a grey last line ("3 more in chat"), since each was printed in chat too. An
-- answer used to keep its last lines only, so Check my kit showed its tips and hid what was missing (design pass,
-- 13 Nov 2026, finding 1). log: a running list instead (Lead a group's notes, one per click): the newest stay and
-- the oldest go. A text the client hasn't drawn yet can measure 0 (a window's first show): it goes to the ruler,
-- then its lines are counted, long ones as the lines they wrap to (red team, #571). per: the letters a line of
-- this text holds, where it isn't the content's width (the Options page's answer is wider). step: from one of its
-- lines to the next, where it isn't the small font's (the guide's rows answer in the body's 12 font). Returns the
-- height it takes.
function UI.AnswerSet(fs, lines, room, log, per, step)
  local n = #lines
  if n == 0 then fs:SetText("") return 0 end
  step = step or UI.LINE
  local function tall(text, shown)
    fs:SetText(text)
    return UI.TextHeight(fs, UI.Lines(shown, 1, per) * step - UI.SPACING)
  end
  if log then
    local from, h = 1
    repeat
      h = tall(table.concat(lines, "\n", from), { table.concat(lines, "\n", from) })
      from = from + 1
    until from > n or h <= room
    return h
  end
  -- Never more lines than the room could hold at one line each, so a long answer costs a few looks, not one a line.
  local k = math.min(n, math.max(1, math.floor((room + UI.SPACING) / step)))
  while true do
    local text = table.concat(lines, "\n", 1, k)
    if k < n then text = text .. "\n" .. UI.MORE:format(n - k) end
    local h = tall(text, { text })
    if h <= room or k == 1 then return h end
    k = k - 1
  end
end

-- Minimap shape for other addons (kit audit, 5 Nov 2026). Map pins (HereBeDragons-Pins: Questie, GatherLite) and
-- minimap buttons (LibDBIcon) ask the global GetMinimapShape() and assume a round map when nobody defines it.
-- EllesmereUI's minimap is square by default but defines none, so pins in the corners were hidden and GatherLite's
-- routes clipped to a circle. When no other addon has defined it, answer from EllesmereUI's minimap, read live.
local function minimapShape()
  local m = type(eui) == "table" and type(eui._ModuleNS) == "table" and eui._ModuleNS.EllesmereUIMinimap
  if type(m) ~= "table" or type(m.MinimapShape) ~= "function" then return "ROUND" end
  local ok, shape = pcall(m.MinimapShape)
  if ok and (shape == "square" or shape == "rectangular") then return "SQUARE" end
  return "ROUND"
end
ns.MinimapShape = minimapShape
-- Safe as a global (red team, #567): GetMinimapShape is a convention between addons, which the game's own code never
-- calls, so nothing protected ever runs it; it only reads, and it is set only where nobody else has defined one.
if type(eui) == "table" and rawget(_G, "GetMinimapShape") == nil then
  rawset(_G, "GetMinimapShape", minimapShape)
end

-- The bar above chat (Louis, 10 Nov 2026: "finally fix the buttons above chat? Wrong style AND overflow"). The notes
-- button, the officer's Now button and Send guild news each placed itself: fixed widths that long labels ran past,
-- fixed offsets over ChatFrame1 that a taller tab row (EllesmereUIChat) covered, the game's red buttons without the
-- skin, and Send guild news at the top of the screen. Now they share one bar:
--   * on top of what the chat shows (its tabs, the dock, a container an addon put it in), as wide as the chat,
--     and moved with it (size, scale and screen changes, a dragged chat window);
--   * each button as wide as its label (ns.CHATBAR_MIN to the bar's width; a longer label ends in "..." and the
--     tooltip shows it whole), left to right, wrapping to a new row above when the next one doesn't fit;
--   * skinned like the rest of UW_Guild (ns.Skin), so it follows EllesmereUI's theme, and the game's look without it.
-- Taint-safe (Louis's party-chat error, 10 Nov: secret-number math in the edit box header, tainted by a chat addon):
-- nothing here hooks, writes or calls into ChatFrame1, its tabs or its edit box. The bar only reads their geometry
-- and is anchored to the chat by both top corners, so its width follows the chat on its own and only the bar's own
-- scripts run our code. A secret geometry value is treated as unknown, never used in arithmetic.
-- Red team, #560 and #567: a chat scaled on its own is measured in the bar's units; a button has a place and a size on
-- the bar from the moment it joins, whatever happens to a layout; and what no event reports (another docked tab
-- picked, a chat addon moving its header after login) is seen by reading the chat's top once a second while the bar
-- shows, with a new layout only when it moved.
ns.CHATBAR_H, ns.CHATBAR_GAP, ns.CHATBAR_PAD, ns.CHATBAR_MIN = 22, 4, 24, 90

-- Pure layout: label widths and the bar width -> { x, row, w } per button (row 0 sits on the chat). Any count, any
-- width: a label wider than the bar gets the whole row.
function ns.ChatBarPlan(widths, barW)
  barW = math.max(ns.CHATBAR_MIN, tonumber(barW) or 0)
  local out, x, row = {}, 0, 0
  for i, tw in ipairs(widths) do
    local w = math.min(barW, math.max(ns.CHATBAR_MIN, math.ceil((tonumber(tw) or 0) + ns.CHATBAR_PAD)))
    if x > 0 and x + w > barW then x, row = 0, row + 1 end
    out[i] = { x = x, row = row, w = w }
    x = x + w + ns.CHATBAR_GAP
  end
  return out
end

local bar, members = nil, {} -- members: { key, button, order }
local function shown(fr) return type(fr) == "table" and fr.IsShown and fr:IsShown() and true or false end
-- A frame's scale on screen: its own units times this are the screen's. 1 where the client can't say.
local function scaleOf(fr)
  local s = type(fr) == "table" and fr.GetEffectiveScale and num(fr:GetEffectiveScale())
  return s and s > 0 and s or 1
end

-- The chat's visible top over its own top, in the bar's units: tabs, the dock manager, a taller container an addon
-- wrapped it in. Each frame's top is in its own units, so each is taken to the screen's first.
local function chatLift(chat)
  local top = num(chat:GetTop())
  if not top then return 26 end
  local cs = scaleOf(chat)
  top = top * cs
  local high = top
  local parent = chat.GetParent and chat:GetParent()
  -- pairs, not ipairs: any of the three can be missing (EllesmereUIChat drops the dock), and ipairs stops at a hole
  for _, fr in pairs({ rawget(_G, "ChatFrame1Tab") or false, rawget(_G, "GeneralDockManager") or false,
    parent ~= rawget(_G, "UIParent") and parent or false }) do
    local t = shown(fr) and num(fr:GetTop())
    t = t and t * scaleOf(fr)
    if t and t > high and t - top < 120 * cs then high = t end
  end
  return (high - top) / scaleOf(bar) + ns.CHATBAR_GAP
end
-- The chat's width in the bar's units.
local function chatWidth(chat)
  local w = num(chat:GetWidth())
  return w and w * scaleOf(chat) / scaleOf(bar)
end

local function tip(self)
  local t = rawget(_G, "GameTooltip")
  if not t or not self.uwFull then return end
  local fs = self.GetFontString and self:GetFontString()
  local cut = fs and fs.IsTruncated and fs:IsTruncated()
  if not cut and not self.uwTip then return end
  t:SetOwner(self, "ANCHOR_TOP")
  t:SetText(self.uwFull, 1, 1, 1, 1, true)
  if self.uwTip then t:AddLine(self.uwTip, 0.8, 0.8, 0.8, true) end
  t:Show()
end

-- /uw hide and /uw show (Louis typed /uw hide on 10 Nov after switching four helpers off: too much on screen). Hidden
-- on every character until /uw show; whatever waits on a button still waits, and its own /uw command still works.
function ns.ChatBarHidden() return type(UW_GuildDB) == "table" and UW_GuildDB.chatBarOff == true end
-- Where a chat line points for its button: the bar, or /uw show while the bar is hidden.
function ns.ChatBarWhere()
  return ns.ChatBarHidden() and "/uw show brings its button back" or "click the button above chat"
end

-- A secure button on the bar (b.uwSecure: Sync.lua's reload button, 13 Nov 2026) can't be moved, sized or shown by
-- addon code in a fight, and while it is the bar's child the bar can't be either. Its own file takes it off the bar
-- as a fight starts and puts it back after. Here: in a fight the layout leaves a secure button alone, and touches
-- nothing at all if one is still the bar's child.
local function barLocked()
  local fight = rawget(_G, "InCombatLockdown")
  if not (fight and fight()) then return false, false end
  for _, m in ipairs(members) do
    if m.button.uwSecure and m.button.GetParent and m.button:GetParent() == bar then return true, true end
  end
  return false, true
end

function ns.ChatBarLayout()
  if not bar then return end
  local locked, fight = barLocked()
  if locked then return end
  if ns.ChatBarHidden() then bar:Hide() return end
  local chat = rawget(_G, "ChatFrame1")
  local barW
  if chat then
    local ok, lift = pcall(chatLift, chat) -- read before the bar lets go of its place: a failed read keeps it seen
    lift = ok and lift or 26
    bar:ClearAllPoints()
    bar:SetPoint("BOTTOMLEFT", chat, "TOPLEFT", 0, lift)
    bar:SetPoint("BOTTOMRIGHT", chat, "TOPRIGHT", 0, lift) -- the width follows the chat without a hook on it
    bar.uwLift = lift
    -- The width the anchors gave the bar, in its own units. A client that hasn't placed it yet says 0: the chat's.
    barW = bar.GetWidth and num(bar:GetWidth())
    if not barW or barW < 1 then barW = chatWidth(chat) end
  else
    bar:ClearAllPoints()
    bar:SetPoint("BOTTOMLEFT", 20, 240)
    bar.uwLift = nil
  end
  barW = barW or 400
  bar.uwLaidW = barW
  table.sort(members, function(a, b) return a.order < b.order end)
  local list, widths = {}, {}
  for _, m in ipairs(members) do
    if shown(m.button) and not (fight and m.button.uwSecure) then
      local fs = m.button.GetFontString and m.button:GetFontString()
      if fs and fs.SetWidth then fs:SetWidth(0) end -- measure the whole label
      list[#list + 1] = m.button
      local whole = fs and (fs.GetUnboundedStringWidth or fs.GetStringWidth)
      widths[#widths + 1] = whole and num(whole(fs)) or 120
    end
  end
  local plan = ns.ChatBarPlan(widths, barW)
  local rows = 0
  for i, b in ipairs(list) do
    local p = plan[i]
    b:ClearAllPoints()
    b:SetPoint("BOTTOMLEFT", bar, "BOTTOMLEFT", p.x, p.row * (ns.CHATBAR_H + ns.CHATBAR_GAP))
    b:SetSize(p.w, ns.CHATBAR_H)
    local fs = b.GetFontString and b:GetFontString()
    if fs and fs.SetWidth then -- one line: a label wider than its button ends in "..." (the tooltip has it whole)
      if fs.SetWordWrap then fs:SetWordWrap(false) end
      if fs.SetMaxLines then fs:SetMaxLines(1) end
      fs:SetWidth(p.w - 12)
    end
    rows = math.max(rows, p.row + 1)
  end
  if not chat then bar:SetWidth(math.max(ns.CHATBAR_MIN, barW)) end
  bar:SetHeight(math.max(1, rows * (ns.CHATBAR_H + ns.CHATBAR_GAP)))
  bar:SetShown(#list > 0)
end

local function build()
  bar = CreateFrame("Frame", "UW_GuildChatBar", rawget(_G, "UIParent"))
  bar:SetFrameStrata("MEDIUM")
  if bar.SetClampedToScreen then bar:SetClampedToScreen(true) end
  bar:SetSize(400, ns.CHATBAR_H + ns.CHATBAR_GAP) -- a place of its own until the first layout gives it the chat's
  bar:SetPoint("BOTTOMLEFT", 20, 240)
  local again = function() ns.protect(ns.ChatBarLayout) end
  -- The chat was resized (the bar is anchored to it): our own frame's script, outside Blizzard's chat code. Only a
  -- new width re-lays out, so the height the layout sets doesn't call it again.
  bar:SetScript("OnSizeChanged", function(_, w)
    w = num(w)
    if w and bar.uwLaidW and math.abs(w - bar.uwLaidW) >= 1 then again() end
  end)
  -- Once a second while the bar shows (a hidden frame gets no OnUpdate): has the chat's top moved under it?
  local wait = 0
  bar:SetScript("OnUpdate", function(_, dt)
    wait = wait + (num(dt) or 0)
    if wait < 1 then return end
    wait = 0
    local chat = rawget(_G, "ChatFrame1")
    if not (chat and bar.uwLift) then return end
    local ok, lift = pcall(chatLift, chat)
    if ok and math.abs(lift - bar.uwLift) >= 1 then again() end
  end)
  local ev = CreateFrame("Frame")
  -- PLAYER_REGEN_ENABLED: whatever a fight held back (a secure button's place, /uw hide) is done as it ends.
  ns.listen(ev, { "UI_SCALE_CHANGED", "DISPLAY_SIZE_CHANGED", "PLAYER_ENTERING_WORLD", "UPDATE_CHAT_WINDOWS",
    "PLAYER_REGEN_ENABLED" })
  ev:SetScript("OnEvent", ns.guard(again))
end

-- A button joins the bar (made by its own file, which keeps its click and when it shows). order: left to right.
-- tipText: a line under the label in the tooltip. Returns the button.
function ns.ChatBarAdd(key, b, order, tipText)
  if type(b) ~= "table" then return b end
  if not bar then build() end
  for _, m in ipairs(members) do if m.key == key then return b end end
  members[#members + 1] = { key = key, button = b, order = order or 50 }
  b:SetParent(bar)
  -- Seen and clickable from here on, even if no layout ever runs for it: its own file gives it no place or size.
  if b.ClearAllPoints then b:ClearAllPoints() end
  b:SetPoint("BOTTOMLEFT", bar, "BOTTOMLEFT", 0, 0)
  b:SetSize(ns.CHATBAR_MIN, ns.CHATBAR_H)
  b.uwTip = tipText
  ns.Skin("Button", b)
  if b.HookScript then
    b:HookScript("OnShow", function() ns.protect(ns.ChatBarLayout) end)
    b:HookScript("OnHide", function() ns.protect(ns.ChatBarLayout) end)
    b:HookScript("OnEnter", tip)
    b:HookScript("OnLeave", function() local t = rawget(_G, "GameTooltip") if t then t:Hide() end end)
  end
  return b
end

-- Relabel a bar button: the full label kept for the tooltip, then the bar re-measured.
function ns.ChatBarText(b, text)
  if type(b) ~= "table" then return end
  b.uwFull = text
  b:SetText(text)
  ns.protect(ns.ChatBarLayout)
end

ns.commands.hide = function()
  if type(UW_GuildDB) == "table" then UW_GuildDB.chatBarOff = true end
  if bar and not barLocked() then bar:Hide() end -- locked: hidden by the first layout after the fight
  local win = ns.Handbook and ns.Handbook()
  if win and win.Hide then win:Hide() end
  ns.say("Buttons above chat hidden on all your characters. /uw show brings them back.")
end
ns.commands.show = function()
  if type(UW_GuildDB) == "table" then UW_GuildDB.chatBarOff = nil end
  ns.protect(ns.ChatBarLayout)
  ns.say("Buttons above chat are back. They show only while something waits for a click.")
end
