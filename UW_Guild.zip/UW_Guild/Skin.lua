local _, ns = ...

-- UW_Guild's windows in EllesmereUI's look (Louis, 5 Nov 2026: "ensure all uw addons sense and align with e.ui's
-- current style"). EllesmereUI publishes a skinning interface for other addons (EllesmereUI\SKINNING_API.md,
-- apiVersion 3): we hand it our frames and it paints them in the player's current theme, and repaints them live
-- when the theme or accent colour changes. We never read its settings or textures ourselves.
--   * EllesmereUI missing, or the player turned skins off for UW Guild: the callback never runs, so every frame keeps
--     the game's own templates, the clean default the windows were built with.
--   * Each primitive is idempotent and runs protected here as well as on EllesmereUI's side, so a changed primitive
--     can cost a frame its skin but never a window.
-- The game's own popups (StaticPopup, used for UW_Guild's confirm and reload questions) are skinned by EllesmereUI's
-- Blizzard Skin module already, so nothing here touches them.

local skin -- EllesmereUI's skin facade, once it has called us back
local pending = {} -- frames made before that: { kind, frame, option }

local function apply(kind, frame, opt)
  local fn = skin and skin[kind]
  if type(fn) ~= "function" or type(frame) ~= "table" then return end
  pcall(fn, frame, opt)
end

-- ns.Skin("Button", b), ns.Skin("EditBox", box, { padInput = true }) ... returns the frame, so it can wrap a
-- CreateFrame call. Kinds are EllesmereUI's primitive names (Shell, Panel, Button, Checkbox, EditBox, CloseButton,
-- PageButton, ScrollBar, Tab, Font, Inset); an unknown one is skipped.
function ns.Skin(kind, frame, opt)
  if frame == nil then return frame end
  if skin then apply(kind, frame, opt) else pending[#pending + 1] = { kind, frame, opt } end
  return frame
end

-- A window from BasicFrameTemplateWithInset (or the plain backdrop fallback): the shell, its inset and close button.
function ns.SkinWindow(f)
  ns.Skin("Shell", f)
  if type(f) == "table" then
    if f.Inset then ns.Skin("Inset", f.Inset) end
    if f.CloseButton then ns.Skin("CloseButton", f.CloseButton) end
  end
  return f
end

function ns.Skinned() return skin ~= nil end

local function onSkin(S)
  skin = S
  local list = pending
  pending = {}
  for _, p in ipairs(list) do apply(p[1], p[2], p[3]) end
end

-- At load: EllesmereUI is an optional dependency (.toc), so it has loaded first when it's installed. RegisterSkin
-- queues us and calls back at login, or at once when called later.
local eui = rawget(_G, "EllesmereUI")
if type(eui) == "table" and type(eui.RegisterSkin) == "function" then
  pcall(eui.RegisterSkin, "UW_Guild", onSkin)
end

-- One window layout (Louis, 10 Nov 2026, on five screenshots: "Lots of beautification before I put this in front of
-- others"). The UW Guild window (Handbook.lua) and Lead a group (Lead.lua) were each laid out on their own numbers:
-- fixed-height slots that left holes between a text and its buttons, a selected tab that looked switched off, a pager
-- under the tabs, answers wherever there was room. Both are now built from the pieces below:
--   title bar | rail (pages or tabs, yours lit) | heading row with the pager | content | answer line
--   * every gap is a step of 4 (4, 8, 12, 16), so edges and rows line up, in one window and across the two;
--   * same size, both centred: stepping from the guide into Lead a group reads as one window turning a page;
--   * where you are is lit (bar, white label). Grey only ever means "can't right now";
--   * flat colour, the game's fonts and button templates: EllesmereUI's skin and the game's own look both hold,
--     and nothing is built until a window first opens.
-- Our own lines and fills sit on frames EllesmereUI is never handed (it fades the textures of a frame it skins).
ns.UI = { W = 680, H = 520, EDGE = 8, TOP = 34, RAIL = 156, PAD = 16, GAP = 8, BTN = 22, NAV = 24, LINE = 12 }
local UI = ns.UI
UI.X = UI.EDGE + UI.RAIL + UI.PAD -- the content's left edge
UI.CW = UI.W - UI.X - UI.PAD      -- and its width
UI.BODY = UI.TOP + 36             -- where the content starts, under the heading's rule
UI.GOLD = { 1, 0.82, 0 }          -- the game's title gold (NORMAL_FONT_COLOR)
UI.LINK = { 0.45, 0.78, 1 }       -- text that goes somewhere

-- A game font by name: the font object where the client has it (every client takes the object; not all take a name).
function UI.Font(name) return rawget(_G, name) or name end
function UI.Fill(parent, layer, r, g, b, a)
  local t = parent:CreateTexture(nil, layer or "BACKGROUND")
  t:SetColorTexture(r, g, b, a)
  return t
end
-- A hairline across the content.
function UI.Rule(parent, w)
  local t = UI.Fill(parent, "ARTWORK", 1, 1, 1, 0.09)
  t:SetSize(w or UI.CW, 1)
  return t
end
-- A sunken panel (the rail, a list). The game's look: a dark fill and a hairline edge. EllesmereUI swaps them for
-- its own inset panel, so the theme's colours carry.
function UI.Well(parent)
  local w = CreateFrame("Frame", nil, parent)
  UI.Fill(w, "BACKGROUND", 0, 0, 0, 0.3):SetAllPoints()
  for _, e in ipairs({ { "TOPLEFT", "TOPRIGHT", true }, { "BOTTOMLEFT", "BOTTOMRIGHT", true },
    { "TOPLEFT", "BOTTOMLEFT" }, { "TOPRIGHT", "BOTTOMRIGHT" } }) do
    local t = UI.Fill(w, "BORDER", 1, 1, 1, 0.09)
    t:SetPoint(e[1])
    t:SetPoint(e[2])
    if e[3] then t:SetHeight(1) else t:SetWidth(1) end
  end
  return ns.Skin("Panel", w, { inset = true })
end

-- The window: movable, Esc closes it, title in the bar, the rail down the left. body holds our own lines and fills.
function UI.Window(name, title, strata)
  local ok, f = pcall(CreateFrame, "Frame", name, UIParent, "BasicFrameTemplateWithInset")
  if not ok or not f then f = CreateFrame("Frame", name, UIParent, "BackdropTemplate") end
  f:SetSize(UI.W, UI.H)
  f:SetPoint("CENTER")
  f:SetFrameStrata(strata)
  f:SetMovable(true)
  if f.SetClampedToScreen then f:SetClampedToScreen(true) end
  f:EnableMouse(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  tinsert(UISpecialFrames, name)
  ns.SkinWindow(f)
  local t = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  t:SetPoint("TOP", 0, -6)
  t:SetText(title)
  ns.Skin("Font", t)
  f.body = CreateFrame("Frame", nil, f)
  f.body:SetAllPoints()
  f.rail = UI.Well(f)
  f.rail:SetPoint("TOPLEFT", UI.EDGE, -UI.TOP)
  f.rail:SetPoint("BOTTOMLEFT", UI.EDGE, UI.EDGE)
  f.rail:SetWidth(UI.RAIL)
  f.heading = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  f.heading:SetPoint("TOPLEFT", UI.X, -UI.TOP)
  f.heading:SetJustifyH("LEFT")
  UI.Rule(f.body):SetPoint("TOPLEFT", UI.X, -UI.TOP - 24)
  return f
end
-- A smaller line on the heading's baseline: what the page is showing, or a state the whole window is in.
function UI.Sub(f, tmpl)
  local fs = f:CreateFontString(nil, "OVERLAY", tmpl or "GameFontHighlightSmall")
  fs:SetPoint("BOTTOMLEFT", f.heading, "BOTTOMRIGHT", UI.LINE, 1)
  fs:SetJustifyH("LEFT")
  return fs
end

-- A page or tab on the rail: a text row. Lit when it's the one showing, a faint fill under the pointer.
function UI.Nav(f, text)
  local b = CreateFrame("Button", nil, f.rail)
  b:SetSize(UI.RAIL - 2, UI.NAV)
  b.lit = UI.Fill(b, "BACKGROUND", 1, 1, 1, 0.09)
  b.lit:SetAllPoints()
  b.bar = UI.Fill(b, "ARTWORK", UI.GOLD[1], UI.GOLD[2], UI.GOLD[3], 1)
  b.bar:SetPoint("TOPLEFT")
  b.bar:SetPoint("BOTTOMLEFT")
  b.bar:SetWidth(2)
  UI.Fill(b, "HIGHLIGHT", 1, 1, 1, 0.06):SetAllPoints()
  b.label = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  b.label:SetPoint("LEFT", 12, 0)
  b.label:SetPoint("RIGHT", -6, 0)
  b.label:SetJustifyH("LEFT")
  if b.label.SetWordWrap then b.label:SetWordWrap(false) end
  b.label:SetText(text)
  return b
end
-- Marks the one showing and stacks the rest under each other, top down. list: the rail's buttons, each with shown
-- (does this player get it) set by its window; one they don't get leaves no hole.
function UI.NavSet(f, list, isOn)
  local y = -4
  for _, b in ipairs(list) do
    local on = isOn(b) and true or false
    b.lit:SetShown(on)
    b.bar:SetShown(on)
    b.label:SetFontObject(UI.Font(on and "GameFontHighlight" or "GameFontNormal"))
    b:SetShown(b.shown and true or false)
    if b.shown then
      b:ClearAllPoints()
      b:SetPoint("TOPLEFT", f.rail, "TOPLEFT", 1, y)
      y = y - UI.NAV - 4
    end
  end
end

-- "Page 2 of 3" and its two arrows, right of the heading. Both arrows stay put; the one with nowhere to go is off.
-- step(-1 or 1) turns the page. The game's own page arrows, or EllesmereUI's.
function UI.Pager(f, step)
  local p = {}
  local function arrow(dir, way, ch)
    local b = CreateFrame("Button", nil, f)
    b:SetSize(UI.BTN, UI.BTN)
    b:SetNormalTexture("Interface\\Buttons\\UI-SpellbookIcon-" .. dir .. "Page-Up")
    b:SetPushedTexture("Interface\\Buttons\\UI-SpellbookIcon-" .. dir .. "Page-Down")
    b:SetDisabledTexture("Interface\\Buttons\\UI-SpellbookIcon-" .. dir .. "Page-Disabled")
    b:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
    b.uwPage = ch
    b:SetScript("OnClick", function() step(way) end)
    return ns.Skin("PageButton", b, ch)
  end
  p.next = arrow("Next", 1, ">")
  p.next:SetPoint("TOPRIGHT", f, "TOPRIGHT", -UI.PAD, -UI.TOP + 3)
  p.prev = arrow("Prev", -1, "<")
  p.prev:SetPoint("RIGHT", p.next, "LEFT", -4, 0)
  p.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  p.text:SetPoint("RIGHT", p.prev, "LEFT", -UI.GAP, 0)
  return p
end
function UI.PagerSet(p, page, pages)
  local many = pages > 1
  p.text:SetShown(many)
  p.prev:SetShown(many)
  p.next:SetShown(many)
  p.text:SetText(("Page %d of %d"):format(page, pages))
  p.prev:SetEnabled(page > 1)
  p.next:SetEnabled(page < pages)
end

-- Answers under the content: what a click just said, newest last. Shows as many of the last lines as fit in room
-- (px), always the newest; the rest are in chat, where each was printed.
function UI.AnswerSet(fs, lines, room)
  local from = 1
  repeat
    fs:SetText(table.concat(lines, "\n", from))
    from = from + 1
    local h = tonumber((fs:GetStringHeight()))
  until from > #lines or not h or h <= room
end
-- A wrapped text's height, or a guess where the client can't say yet.
function UI.TextHeight(fs, guess)
  local h = tonumber((fs:GetStringHeight()))
  return h and h > 0 and h or guess
end

-- Minimap shape for other addons (kit audit, 5 Nov 2026). Map pins (HereBeDragons-Pins: Questie, GatherLite) and
-- minimap buttons (LibDBIcon) ask the global GetMinimapShape() and assume a round map when nobody defines it.
-- EllesmereUI's minimap is square by default but defines none, so pins in the corners were hidden and GatherLite's
-- routes clipped to a circle. When no other addon has defined it, answer from EllesmereUI's minimap, read live.
local function minimapShape()
  local m = type(eui) == "table" and type(eui._ModuleNS) == "table" and eui._ModuleNS.EllesmereUIMinimap
  if type(m) ~= "table" or type(m.MinimapShape) ~= "function" then return "ROUND" end
  local ok, shape = pcall(m.MinimapShape)
  if ok and (shape == "square" or shape == "rectangular") then return "SQUARE" end
  return "ROUND"
end
ns.MinimapShape = minimapShape
if type(eui) == "table" and rawget(_G, "GetMinimapShape") == nil then
  rawset(_G, "GetMinimapShape", minimapShape)
end

-- The bar above chat (Louis, 10 Nov 2026: "finally fix the buttons above chat? Wrong style AND overflow"). The notes
-- button, the officer's Now button and Send guild news each placed itself: fixed widths that long labels ran past,
-- fixed offsets over ChatFrame1 that a taller tab row (EllesmereUIChat) covered, the game's red buttons without the
-- skin, and Send guild news at the top of the screen. Now they share one bar:
--   * on top of what the chat shows (its tabs, the dock, a container an addon put it in), as wide as the chat,
--     and moved with it (size, scale and screen changes, a dragged chat window);
--   * each button as wide as its label (ns.CHATBAR_MIN to the bar's width; a longer label ends in "..." and the
--     tooltip shows it whole), left to right, wrapping to a new row above when the next one doesn't fit;
--   * skinned like the rest of UW_Guild (ns.Skin), so it follows EllesmereUI's theme, and the game's look without it.
-- Taint-safe (Louis's party-chat error, 10 Nov: secret-number math in the edit box header, tainted by a chat addon):
-- nothing here hooks, writes or calls into ChatFrame1, its tabs or its edit box. The bar only reads their geometry
-- and is anchored to the chat by both top corners, so its width follows the chat on its own and only the bar's own
-- OnSizeChanged runs our code. A secret geometry value is treated as unknown, never used in arithmetic.
ns.CHATBAR_H, ns.CHATBAR_GAP, ns.CHATBAR_PAD, ns.CHATBAR_MIN = 22, 4, 24, 90

-- Pure layout: label widths and the bar width -> { x, row, w } per button (row 0 sits on the chat). Any count, any
-- width: a label wider than the bar gets the whole row.
function ns.ChatBarPlan(widths, barW)
  barW = math.max(ns.CHATBAR_MIN, tonumber(barW) or 0)
  local out, x, row = {}, 0, 0
  for i, tw in ipairs(widths) do
    local w = math.min(barW, math.max(ns.CHATBAR_MIN, math.ceil((tonumber(tw) or 0) + ns.CHATBAR_PAD)))
    if x > 0 and x + w > barW then x, row = 0, row + 1 end
    out[i] = { x = x, row = row, w = w }
    x = x + w + ns.CHATBAR_GAP
  end
  return out
end

local bar, members = nil, {} -- members: { key, button, order }
local function num(v)
  local secret = rawget(_G, "issecretvalue")
  if v == nil or (secret and secret(v)) then return nil end
  return tonumber(v)
end
local function shown(fr) return type(fr) == "table" and fr.IsShown and fr:IsShown() and true or false end

-- The chat's visible top over its own top: tabs, the dock manager, a taller container an addon wrapped it in.
local function chatLift(chat)
  local top = num(chat:GetTop())
  if not top then return 26 end
  local high = top
  local parent = chat.GetParent and chat:GetParent()
  -- pairs, not ipairs: any of the three can be missing (EllesmereUIChat drops the dock), and ipairs stops at a hole
  for _, fr in pairs({ rawget(_G, "ChatFrame1Tab") or false, rawget(_G, "GeneralDockManager") or false,
    parent ~= rawget(_G, "UIParent") and parent or false }) do
    local t = shown(fr) and num(fr:GetTop())
    if t and t > high and t - top < 120 then high = t end
  end
  return high - top + ns.CHATBAR_GAP
end

local function tip(self)
  local t = rawget(_G, "GameTooltip")
  if not t or not self.uwFull then return end
  local fs = self.GetFontString and self:GetFontString()
  local cut = fs and fs.IsTruncated and fs:IsTruncated()
  if not cut and not self.uwTip then return end
  t:SetOwner(self, "ANCHOR_TOP")
  t:SetText(self.uwFull, 1, 1, 1, 1, true)
  if self.uwTip then t:AddLine(self.uwTip, 0.8, 0.8, 0.8, true) end
  t:Show()
end

function ns.ChatBarLayout()
  if not bar then return end
  local chat = rawget(_G, "ChatFrame1")
  local barW = chat and num(chat:GetWidth()) or 400
  bar:ClearAllPoints()
  if chat then
    local lift = chatLift(chat)
    bar:SetPoint("BOTTOMLEFT", chat, "TOPLEFT", 0, lift)
    bar:SetPoint("BOTTOMRIGHT", chat, "TOPRIGHT", 0, lift) -- the width follows the chat without a hook on it
  else
    bar:SetPoint("BOTTOMLEFT", 20, 240)
  end
  bar.uwLaidW = barW
  table.sort(members, function(a, b) return a.order < b.order end)
  local list, widths = {}, {}
  for _, m in ipairs(members) do
    if shown(m.button) then
      local fs = m.button.GetFontString and m.button:GetFontString()
      if fs and fs.SetWidth then fs:SetWidth(0) end -- measure the whole label
      list[#list + 1] = m.button
      local whole = fs and (fs.GetUnboundedStringWidth or fs.GetStringWidth)
      widths[#widths + 1] = whole and num(whole(fs)) or 120
    end
  end
  local plan = ns.ChatBarPlan(widths, barW)
  local rows = 0
  for i, b in ipairs(list) do
    local p = plan[i]
    b:ClearAllPoints()
    b:SetPoint("BOTTOMLEFT", bar, "BOTTOMLEFT", p.x, p.row * (ns.CHATBAR_H + ns.CHATBAR_GAP))
    b:SetSize(p.w, ns.CHATBAR_H)
    local fs = b.GetFontString and b:GetFontString()
    if fs and fs.SetWidth then -- one line: a label wider than its button ends in "..." (the tooltip has it whole)
      if fs.SetWordWrap then fs:SetWordWrap(false) end
      if fs.SetMaxLines then fs:SetMaxLines(1) end
      fs:SetWidth(p.w - 12)
    end
    rows = math.max(rows, p.row + 1)
  end
  if not chat then bar:SetWidth(math.max(ns.CHATBAR_MIN, barW)) end
  bar:SetHeight(math.max(1, rows * (ns.CHATBAR_H + ns.CHATBAR_GAP)))
  bar:SetShown(#list > 0)
end

local function build()
  bar = CreateFrame("Frame", "UW_GuildChatBar", rawget(_G, "UIParent"))
  bar:SetFrameStrata("MEDIUM")
  if bar.SetClampedToScreen then bar:SetClampedToScreen(true) end
  local again = function() ns.protect(ns.ChatBarLayout) end
  -- The chat was resized (the bar is anchored to it): our own frame's script, outside Blizzard's chat code. Only a
  -- new width re-lays out, so the height the layout sets doesn't call it again.
  bar:SetScript("OnSizeChanged", function(_, w)
    w = num(w)
    if w and bar.uwLaidW and math.abs(w - bar.uwLaidW) >= 1 then again() end
  end)
  local ev = CreateFrame("Frame")
  ns.listen(ev, { "UI_SCALE_CHANGED", "DISPLAY_SIZE_CHANGED", "PLAYER_ENTERING_WORLD", "UPDATE_CHAT_WINDOWS" })
  ev:SetScript("OnEvent", ns.guard(again))
end

-- A button joins the bar (made by its own file, which keeps its click and when it shows). order: left to right.
-- tipText: a line under the label in the tooltip. Returns the button.
function ns.ChatBarAdd(key, b, order, tipText)
  if type(b) ~= "table" then return b end
  if not bar then build() end
  for _, m in ipairs(members) do if m.key == key then return b end end
  members[#members + 1] = { key = key, button = b, order = order or 50 }
  b:SetParent(bar)
  b.uwTip = tipText
  ns.Skin("Button", b)
  if b.HookScript then
    b:HookScript("OnShow", function() ns.protect(ns.ChatBarLayout) end)
    b:HookScript("OnHide", function() ns.protect(ns.ChatBarLayout) end)
    b:HookScript("OnEnter", tip)
    b:HookScript("OnLeave", function() local t = rawget(_G, "GameTooltip") if t then t:Hide() end end)
  end
  return b
end

-- Relabel a bar button: the full label kept for the tooltip, then the bar re-measured.
function ns.ChatBarText(b, text)
  if type(b) ~= "table" then return end
  b.uwFull = text
  b:SetText(text)
  ns.protect(ns.ChatBarLayout)
end
