local _, ns = ...

-- UW_Guild's windows in EllesmereUI's look (Louis, 5 Nov 2026: "ensure all uw addons sense and align with e.ui's
-- current style"). EllesmereUI publishes a skinning interface for other addons (EllesmereUI\SKINNING_API.md,
-- apiVersion 3): we hand it our frames and it paints them in the player's current theme, and repaints them live
-- when the theme or accent colour changes. We never read its settings or textures ourselves.
--   * EllesmereUI missing, or the player turned skins off for UW Guild: the callback never runs, so every frame keeps
--     the game's own templates, the clean default the windows were built with.
--   * Each primitive is idempotent and runs protected here as well as on EllesmereUI's side, so a changed primitive
--     can cost a frame its skin but never a window.
-- The game's own popups (StaticPopup, used for UW_Guild's confirm and reload questions) are skinned by EllesmereUI's
-- Blizzard Skin module already, so nothing here touches them.

local skin -- EllesmereUI's skin facade, once it has called us back
local pending = {} -- frames made before that: { kind, frame, option }

local function apply(kind, frame, opt)
  local fn = skin and skin[kind]
  if type(fn) ~= "function" or type(frame) ~= "table" then return end
  pcall(fn, frame, opt)
end

-- ns.Skin("Button", b), ns.Skin("EditBox", box, { padInput = true }) ... returns the frame, so it can wrap a
-- CreateFrame call. Kinds are EllesmereUI's primitive names (Shell, Panel, Button, Checkbox, EditBox, CloseButton,
-- ScrollBar, Tab, Font, Inset); an unknown one is skipped.
function ns.Skin(kind, frame, opt)
  if frame == nil then return frame end
  if skin then apply(kind, frame, opt) else pending[#pending + 1] = { kind, frame, opt } end
  return frame
end

-- A window from BasicFrameTemplateWithInset (or the plain backdrop fallback): the shell, its inset and close button.
function ns.SkinWindow(f)
  ns.Skin("Shell", f)
  if type(f) == "table" then
    if f.Inset then ns.Skin("Inset", f.Inset) end
    if f.CloseButton then ns.Skin("CloseButton", f.CloseButton) end
  end
  return f
end

function ns.Skinned() return skin ~= nil end

local function onSkin(S)
  skin = S
  local list = pending
  pending = {}
  for _, p in ipairs(list) do apply(p[1], p[2], p[3]) end
end

-- At load: EllesmereUI is an optional dependency (.toc), so it has loaded first when it's installed. RegisterSkin
-- queues us and calls back at login, or at once when called later.
local eui = rawget(_G, "EllesmereUI")
if type(eui) == "table" and type(eui.RegisterSkin) == "function" then
  pcall(eui.RegisterSkin, "UW_Guild", onSkin)
end

-- Minimap shape for other addons (kit audit, 5 Nov 2026). Map pins (HereBeDragons-Pins: Questie, GatherLite) and
-- minimap buttons (LibDBIcon) ask the global GetMinimapShape() and assume a round map when nobody defines it.
-- EllesmereUI's minimap is square by default but defines none, so pins in the corners were hidden and GatherLite's
-- routes clipped to a circle. When no other addon has defined it, answer from EllesmereUI's minimap, read live.
local function minimapShape()
  local m = type(eui) == "table" and type(eui._ModuleNS) == "table" and eui._ModuleNS.EllesmereUIMinimap
  if type(m) ~= "table" or type(m.MinimapShape) ~= "function" then return "ROUND" end
  local ok, shape = pcall(m.MinimapShape)
  if ok and (shape == "square" or shape == "rectangular") then return "SQUARE" end
  return "ROUND"
end
ns.MinimapShape = minimapShape
if type(eui) == "table" and rawget(_G, "GetMinimapShape") == nil then
  rawset(_G, "GetMinimapShape", minimapShape)
end
