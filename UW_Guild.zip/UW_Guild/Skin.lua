local _, ns = ...

-- UW_Guild's windows in EllesmereUI's look (Louis, 5 Nov 2026: "ensure all uw addons sense and align with e.ui's
-- current style"). EllesmereUI publishes a skinning interface for other addons (EllesmereUI\SKINNING_API.md,
-- apiVersion 3): we hand it our frames and it paints them in the player's current theme, and repaints them live
-- when the theme or accent colour changes. We never read its settings or textures ourselves.
--   * EllesmereUI missing, or the player turned skins off for UW Guild: the callback never runs, so every frame keeps
--     the game's own templates, the clean default the windows were built with.
--   * Each primitive is idempotent and runs protected here as well as on EllesmereUI's side, so a changed primitive
--     can cost a frame its skin but never a window.
-- The game's own popups (StaticPopup, used for UW_Guild's confirm and reload questions) are skinned by EllesmereUI's
-- Blizzard Skin module already, so nothing here touches them.

local skin -- EllesmereUI's skin facade, once it has called us back
local pending = {} -- frames made before that: { kind, frame, option }

local function apply(kind, frame, opt)
  local fn = skin and skin[kind]
  if type(fn) ~= "function" or type(frame) ~= "table" then return end
  pcall(fn, frame, opt)
end

-- ns.Skin("Button", b), ns.Skin("EditBox", box, { padInput = true }) ... returns the frame, so it can wrap a
-- CreateFrame call. Kinds are EllesmereUI's primitive names (Shell, Panel, Button, Checkbox, EditBox, CloseButton,
-- ScrollBar, Tab, Font, Inset); an unknown one is skipped.
function ns.Skin(kind, frame, opt)
  if frame == nil then return frame end
  if skin then apply(kind, frame, opt) else pending[#pending + 1] = { kind, frame, opt } end
  return frame
end

-- A window from BasicFrameTemplateWithInset (or the plain backdrop fallback): the shell, its inset and close button.
function ns.SkinWindow(f)
  ns.Skin("Shell", f)
  if type(f) == "table" then
    if f.Inset then ns.Skin("Inset", f.Inset) end
    if f.CloseButton then ns.Skin("CloseButton", f.CloseButton) end
  end
  return f
end

function ns.Skinned() return skin ~= nil end

local function onSkin(S)
  skin = S
  local list = pending
  pending = {}
  for _, p in ipairs(list) do apply(p[1], p[2], p[3]) end
end

-- At load: EllesmereUI is an optional dependency (.toc), so it has loaded first when it's installed. RegisterSkin
-- queues us and calls back at login, or at once when called later.
local eui = rawget(_G, "EllesmereUI")
if type(eui) == "table" and type(eui.RegisterSkin) == "function" then
  pcall(eui.RegisterSkin, "UW_Guild", onSkin)
end

-- Minimap shape for other addons (kit audit, 5 Nov 2026). Map pins (HereBeDragons-Pins: Questie, GatherLite) and
-- minimap buttons (LibDBIcon) ask the global GetMinimapShape() and assume a round map when nobody defines it.
-- EllesmereUI's minimap is square by default but defines none, so pins in the corners were hidden and GatherLite's
-- routes clipped to a circle. When no other addon has defined it, answer from EllesmereUI's minimap, read live.
local function minimapShape()
  local m = type(eui) == "table" and type(eui._ModuleNS) == "table" and eui._ModuleNS.EllesmereUIMinimap
  if type(m) ~= "table" or type(m.MinimapShape) ~= "function" then return "ROUND" end
  local ok, shape = pcall(m.MinimapShape)
  if ok and (shape == "square" or shape == "rectangular") then return "SQUARE" end
  return "ROUND"
end
ns.MinimapShape = minimapShape
if type(eui) == "table" and rawget(_G, "GetMinimapShape") == nil then
  rawset(_G, "GetMinimapShape", minimapShape)
end

-- The bar above chat (Louis, 10 Nov 2026: "finally fix the buttons above chat? Wrong style AND overflow"). The notes
-- button, the officer's Now button and Send guild news each placed itself: fixed widths that long labels ran past,
-- fixed offsets over ChatFrame1 that a taller tab row (EllesmereUIChat) covered, the game's red buttons without the
-- skin, and Send guild news at the top of the screen. Now they share one bar:
--   * on top of what the chat shows (its tabs, the dock, a container an addon put it in), as wide as the chat,
--     and moved with it (size, scale and screen changes, a dragged chat window);
--   * each button as wide as its label (ns.CHATBAR_MIN to the bar's width; a longer label ends in "..." and the
--     tooltip shows it whole), left to right, wrapping to a new row above when the next one doesn't fit;
--   * skinned like the rest of UW_Guild (ns.Skin), so it follows EllesmereUI's theme, and the game's look without it.
ns.CHATBAR_H, ns.CHATBAR_GAP, ns.CHATBAR_PAD, ns.CHATBAR_MIN = 22, 4, 24, 90

-- Pure layout: label widths and the bar width -> { x, row, w } per button (row 0 sits on the chat). Any count, any
-- width: a label wider than the bar gets the whole row.
function ns.ChatBarPlan(widths, barW)
  barW = math.max(ns.CHATBAR_MIN, tonumber(barW) or 0)
  local out, x, row = {}, 0, 0
  for i, tw in ipairs(widths) do
    local w = math.min(barW, math.max(ns.CHATBAR_MIN, math.ceil((tonumber(tw) or 0) + ns.CHATBAR_PAD)))
    if x > 0 and x + w > barW then x, row = 0, row + 1 end
    out[i] = { x = x, row = row, w = w }
    x = x + w + ns.CHATBAR_GAP
  end
  return out
end

local bar, members = nil, {} -- members: { key, button, order }
local function num(v) v = tonumber(v) return v end
local function shown(fr) return type(fr) == "table" and fr.IsShown and fr:IsShown() and true or false end

-- The chat's visible top over its own top: tabs, the dock manager, a taller container an addon wrapped it in.
local function chatLift(chat)
  local top = num(chat:GetTop())
  if not top then return 26 end
  local high = top
  local parent = chat.GetParent and chat:GetParent()
  -- pairs, not ipairs: any of the three can be missing (EllesmereUIChat drops the dock), and ipairs stops at a hole
  for _, fr in pairs({ rawget(_G, "ChatFrame1Tab") or false, rawget(_G, "GeneralDockManager") or false,
    parent ~= rawget(_G, "UIParent") and parent or false }) do
    local t = shown(fr) and num(fr:GetTop())
    if t and t > high and t - top < 120 then high = t end
  end
  return high - top + ns.CHATBAR_GAP
end

local function tip(self)
  local t = rawget(_G, "GameTooltip")
  if not t or not self.uwFull then return end
  local fs = self.GetFontString and self:GetFontString()
  local cut = fs and fs.IsTruncated and fs:IsTruncated()
  if not cut and not self.uwTip then return end
  t:SetOwner(self, "ANCHOR_TOP")
  t:SetText(self.uwFull, 1, 1, 1, 1, true)
  if self.uwTip then t:AddLine(self.uwTip, 0.8, 0.8, 0.8, true) end
  t:Show()
end

function ns.ChatBarLayout()
  if not bar then return end
  local chat = rawget(_G, "ChatFrame1")
  local barW = chat and num(chat:GetWidth()) or 400
  bar:ClearAllPoints()
  if chat then bar:SetPoint("BOTTOMLEFT", chat, "TOPLEFT", 0, chatLift(chat)) else bar:SetPoint("BOTTOMLEFT", 20, 240) end
  table.sort(members, function(a, b) return a.order < b.order end)
  local list, widths = {}, {}
  for _, m in ipairs(members) do
    if shown(m.button) then
      local fs = m.button.GetFontString and m.button:GetFontString()
      if fs and fs.SetWidth then fs:SetWidth(0) end -- measure the whole label
      list[#list + 1] = m.button
      local whole = fs and (fs.GetUnboundedStringWidth or fs.GetStringWidth)
      widths[#widths + 1] = whole and num(whole(fs)) or 120
    end
  end
  local plan = ns.ChatBarPlan(widths, barW)
  local rows = 0
  for i, b in ipairs(list) do
    local p = plan[i]
    b:ClearAllPoints()
    b:SetPoint("BOTTOMLEFT", bar, "BOTTOMLEFT", p.x, p.row * (ns.CHATBAR_H + ns.CHATBAR_GAP))
    b:SetSize(p.w, ns.CHATBAR_H)
    local fs = b.GetFontString and b:GetFontString()
    if fs and fs.SetWidth then -- one line: a label wider than its button ends in "..." (the tooltip has it whole)
      if fs.SetWordWrap then fs:SetWordWrap(false) end
      if fs.SetMaxLines then fs:SetMaxLines(1) end
      fs:SetWidth(p.w - 12)
    end
    rows = math.max(rows, p.row + 1)
  end
  bar:SetSize(math.max(ns.CHATBAR_MIN, barW), math.max(1, rows * (ns.CHATBAR_H + ns.CHATBAR_GAP)))
  bar:SetShown(#list > 0)
end

local function build()
  bar = CreateFrame("Frame", "UW_GuildChatBar", rawget(_G, "UIParent"))
  bar:SetFrameStrata("MEDIUM")
  if bar.SetClampedToScreen then bar:SetClampedToScreen(true) end
  local again = function() ns.protect(ns.ChatBarLayout) end
  local chat = rawget(_G, "ChatFrame1")
  if chat and chat.HookScript then
    chat:HookScript("OnSizeChanged", again)
    chat:HookScript("OnShow", again)
  end
  local ev = CreateFrame("Frame")
  ns.listen(ev, { "UI_SCALE_CHANGED", "DISPLAY_SIZE_CHANGED", "PLAYER_ENTERING_WORLD", "UPDATE_CHAT_WINDOWS" })
  ev:SetScript("OnEvent", ns.guard(again))
end

-- A button joins the bar (made by its own file, which keeps its click and when it shows). order: left to right.
-- tipText: a line under the label in the tooltip. Returns the button.
function ns.ChatBarAdd(key, b, order, tipText)
  if type(b) ~= "table" then return b end
  if not bar then build() end
  for _, m in ipairs(members) do if m.key == key then return b end end
  members[#members + 1] = { key = key, button = b, order = order or 50 }
  b:SetParent(bar)
  b.uwTip = tipText
  ns.Skin("Button", b)
  if b.HookScript then
    b:HookScript("OnShow", function() ns.protect(ns.ChatBarLayout) end)
    b:HookScript("OnHide", function() ns.protect(ns.ChatBarLayout) end)
    b:HookScript("OnEnter", tip)
    b:HookScript("OnLeave", function() local t = rawget(_G, "GameTooltip") if t then t:Hide() end end)
  end
  return b
end

-- Relabel a bar button: the full label kept for the tooltip, then the bar re-measured.
function ns.ChatBarText(b, text)
  if type(b) ~= "table" then return end
  b.uwFull = text
  b:SetText(text)
  ns.protect(ns.ChatBarLayout)
end
