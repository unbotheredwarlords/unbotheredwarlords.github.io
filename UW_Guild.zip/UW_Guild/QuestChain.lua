-- Quest chains (Louis, 5 Nov 2026: "if not, make it a part of the uw suite!", and "any way we can help that show in
-- the questie tracker?").
--
-- Questie's tracker shows each quest on its own. Here a quest that belongs to a chain gets a grey "3/7" at the end of
-- its title in that tracker; hovering the title lists every step (done, this one, still to come, with levels).
-- /uw chain lists the chains in your quest log in chat.
--   * Data: QuestieDB's public reader (LibQuestieDB, contract 4; installed with Questie). Its Forever data has each
--     quest's prerequisites but no "next quest" field, so the forward links are built once per session, in small
--     batches a few seconds after login, from every quest's prerequisite. Only steps your race and class can take.
--   * The tag goes into the title text through Questie's own LineBuilder.AddTitle (wrapped), so Questie sizes the line
--     for it. Not a public interface: our part is protected, and if Questie changes it the tags just stop.
--   * Without Questie nothing shows, and /uw chain says why. /uw chain off hides the tracker tags.
local _, ns = ...
local say = ns.say

ns.CHAIN_MAX = 40       -- steps walked either way (a guard against loops in the data)
ns.CHAIN_BATCH = 250    -- quests read per frame while building the forward links

local function call(fn, ...)
  if not fn then return nil end
  local ok, a, b, c = pcall(fn, ...)
  if ok then return a, b, c end
end
local function g(name) return rawget(_G, name) end
local function tagsOn() return UW_GuildDB and UW_GuildDB.chainTags ~= false end

-- QuestieDB's quest reader, or nil.
local function db()
  local lib = g("LibQuestieDB")
  if type(lib) ~= "table" or type(lib.Quest) ~= "table" then return nil end
  if lib.RequireContract and not call(lib.RequireContract, 4) then return nil end
  return lib
end

local nextOf      -- quest ID -> { later quest IDs } (built from prerequisites)
local building = false

-- What it last saw (UW_GuildDB.chainProbe): read from the saved file when a tag doesn't show in game.
local function probe(k, v)
  if not UW_GuildDB then return end
  local p = UW_GuildDB.chainProbe or {}
  UW_GuildDB.chainProbe = p
  p[k] = v
  p.at = time()
end

local function list(v) return type(v) == "table" and v or nil end
local function prev(lib, id)
  local single = list(call(lib.Quest.preQuestSingle, id))
  if single and single[1] then return single[1] end
  local group = list(call(lib.Quest.preQuestGroup, id))
  return group and group[1] or nil
end

-- A step the player can take: race and class masks (0 or none = everyone), and not a breadcrumb.
local function forMe(lib, id)
  if call(lib.Quest.breadcrumbForQuestId, id) then return false end
  local enum = type(lib.Enum) == "table" and lib.Enum or {}
  local races = call(lib.Quest.requiredRaces, id)
  if type(races) == "number" and races > 0 and type(enum.raceMaskById) == "table" then
    local _, _, raceID = call(g("UnitRace"), "player")
    local mine = raceID and enum.raceMaskById[raceID]
    if mine and math.floor(races / mine) % 2 == 0 then return false end
  end
  local classes = call(lib.Quest.requiredClasses, id)
  if type(classes) == "number" and classes > 0 and type(enum.classKeys) == "table" then
    local _, file = call(g("UnitClass"), "player")
    local mine = file and enum.classKeys[file]
    if mine and math.floor(classes / mine) % 2 == 0 then return false end
  end
  return true
end

-- The forward links, read a batch per frame so login never stalls. done() runs once they're ready.
function ns.BuildQuestChains(done)
  if nextOf then if done then done() end return end
  local lib = db()
  probe("lib", lib ~= nil)
  if not lib or building then return end
  local ids = list(call(lib.Quest.GetAllIds))
  probe("ids", ids and #ids or -1)
  if not ids then return end
  building = true
  local links, i = {}, 1
  local function step()
    local stop = math.min(i + ns.CHAIN_BATCH - 1, #ids)
    for k = i, stop do
      local id = ids[k]
      local before = list(call(lib.Quest.preQuestSingle, id)) or list(call(lib.Quest.preQuestGroup, id)) or {}
      for _, p in ipairs(before) do
        links[p] = links[p] or {}
        links[p][#links[p] + 1] = id
      end
    end
    i = stop + 1
    if i <= #ids then C_Timer.After(0, function() ns.protect(step) end) return end
    nextOf, building = links, false
    local n = 0
    for _ in pairs(links) do n = n + 1 end
    probe("linked", n)
    if done then done() end
  end
  step()
end

-- The chain a quest is part of: { ids = {...}, at = position, more = true when it branches after the last step }.
-- nil when it's a single quest or the data isn't ready.
function ns.QuestChain(id)
  local lib = db()
  if not lib or not nextOf or not id then return nil end
  local ids, seen = { id }, { [id] = true }
  local cur = id
  for _ = 1, ns.CHAIN_MAX do
    local p = prev(lib, cur)
    if not p or seen[p] then break end
    table.insert(ids, 1, p); seen[p] = true; cur = p
  end
  local at = #ids
  cur = id
  local more = false
  for _ = 1, ns.CHAIN_MAX do
    local options = {}
    for _, n in ipairs(nextOf[cur] or {}) do
      if not seen[n] and forMe(lib, n) then options[#options + 1] = n end
    end
    if #options ~= 1 then more = #options > 1 break end
    cur = options[1]
    ids[#ids + 1] = cur; seen[cur] = true
  end
  if #ids < 2 then return nil end
  return { ids = ids, at = at, more = more }
end

local function done(id)
  local ql = g("C_QuestLog")
  return ql and call(ql.IsQuestFlaggedCompleted, id) == true
end
local function label(lib, id)
  local name = call(lib.Quest.name, id) or ("Quest " .. id)
  local lvl = call(lib.Quest.questLevel, id)
  return type(lvl) == "number" and lvl > 0 and ("%s (%d)"):format(name, lvl) or name
end

-- The tooltip for a tracker tag: every step, coloured by state.
local function showSteps(owner, chain)
  local lib, tip = db(), g("GameTooltip")
  if not (lib and tip and chain) then return end
  tip:SetOwner(owner, "ANCHOR_RIGHT")
  tip:SetText(("Quest chain: step %d of %d%s"):format(chain.at, #chain.ids, chain.more and "+" or ""))
  for i, id in ipairs(chain.ids) do
    local color = i == chain.at and "|cffffd100" or done(id) and "|cff808080" or "|cffffffff"
    tip:AddLine(("%s%d. %s|r"):format(color, i, label(lib, id)))
  end
  if chain.more then tip:AddLine("|cff808080Then it branches.|r") end
  tip:Show()
end

-- Questie's tracker: " 3/7" added to a chained quest's title text before Questie sizes the line, so the tracker makes
-- room for it (a tag laid over the line overlapped long titles; Louis, 5 Nov). Hovering the title lists every step.
local function titleText(options)
  if not tagsOn() or type(options) ~= "table" or options.clickMode ~= "quest" then return nil end
  local quest = type(options.target) == "table" and options.target
  local chain = quest and type(options.text) == "string" and ns.QuestChain(quest.Id)
  probe("lastQuest", quest and quest.Id or -1)
  if not chain then return nil end
  probe("tagged", ((UW_GuildDB.chainProbe or {}).tagged or 0) + 1)
  return ("%s |cff808080%d/%d|r"):format(options.text, chain.at, #chain.ids)
end

local function lineChain(line)
  if not tagsOn() or rawget(line, "mode") ~= "quest" then return nil end
  local quest = rawget(line, "Quest")
  return type(quest) == "table" and ns.QuestChain(quest.Id) or nil
end

local function hookLine(line)
  if rawget(line, "uwChainHooked") or type(line.HookScript) ~= "function" then return end
  line.uwChainHooked = true
  line:HookScript("OnEnter", function(self) ns.protect(function() showSteps(self, lineChain(self)) end) end)
  line:HookScript("OnLeave", function(self)
    local tip = g("GameTooltip")
    if tip and call(tip.GetOwner, tip) == self then tip:Hide() end
  end)
end

local wrapped = false
local function hookQuestie()
  if wrapped then return end
  local loader = g("QuestieLoader")
  local builder = loader and call(loader.ImportModule, loader, "LineBuilder")
  if type(builder) ~= "table" or type(builder.AddTitle) ~= "function" then probe("hooked", false) return end
  local addTitle = builder.AddTitle
  builder.AddTitle = function(options, ...)
    local ok, text = pcall(titleText, options)
    if ok and text then options.text = text end
    local line, collapsed = addTitle(options, ...)
    if type(line) == "table" then pcall(hookLine, line) end
    return line, collapsed
  end
  wrapped = true
  probe("hooked", true)
end

-- Redraws Questie's tracker, which re-adds or drops the tags.
function ns.TagQuestieTracker()
  local loader = g("QuestieLoader")
  local tracker = loader and call(loader.ImportModule, loader, "QuestieTracker")
  if type(tracker) == "table" and type(tracker.Update) == "function" then call(tracker.Update, tracker) end
end

-- The quest log's chains, in chat.
local function chainLines()
  local lib, ql = db(), g("C_QuestLog")
  local out = {}
  for i = 1, (ql and tonumber((call(ql.GetNumQuestLogEntries))) or 0) do
    local info = call(ql.GetInfo, i)
    if type(info) == "table" and not info.isHeader and info.questID then
      local c = ns.QuestChain(info.questID)
      if c then
        local after = c.ids[c.at + 1]
        out[#out + 1] = ("%s: step %d of %d%s.%s"):format(info.title or label(lib, info.questID), c.at, #c.ids,
          c.more and "+" or "", after and (" Next: " .. label(lib, after) .. ".") or "")
      end
    end
  end
  return out
end

ns.commands.chain = function(args)
  local sub = strtrim(args or ""):lower()
  if sub == "off" then
    UW_GuildDB.chainTags = false
    ns.protect(ns.TagQuestieTracker)
    say("Chain tags in Questie's tracker are off. /uw chain on brings them back.")
    return
  elseif sub == "on" then
    UW_GuildDB.chainTags = nil
    ns.protect(ns.TagQuestieTracker)
    say("Chain tags in Questie's tracker are on. Hover a quest title to see every step.")
    return
  end
  if not db() then say("Quest chains need Questie (with QuestieDB): /uw kit shows where to get it.") return end
  if not nextOf then
    ns.BuildQuestChains()
    say("Reading Questie's quest data. Try again in a few seconds.")
    return
  end
  local lines = chainLines()
  if #lines == 0 then say("No quest in your log is part of a chain.") return end
  for i = 1, math.min(#lines, 8) do say(lines[i]) end
  if #lines > 8 then say(("And %d more. Hover their titles in Questie's tracker."):format(#lines - 8)) end
end

local f = CreateFrame("Frame")
ns.listen(f, { "PLAYER_ENTERING_WORLD" })
f:SetScript("OnEvent", function(self)
  self:UnregisterEvent("PLAYER_ENTERING_WORLD")
  ns.protect(hookQuestie)
  -- After login settles: the links, then one redraw of Questie's tracker with the tags.
  C_Timer.After(5, function()
    ns.protect(hookQuestie)
    ns.protect(ns.BuildQuestChains, function() ns.protect(ns.TagQuestieTracker) end)
  end)
end)
