-- Ask a guild enchanter from the character panel (Louis, 22 Nov 2026: "a button to ask a guildie enchanter from the
-- character interface for an enchant on gear from a dropdown"; 19:33: "intelligent, sensing both character and item
-- level and gold amount ... efficient power optimization").
--
-- Wire before build: what guildmates can enchant is the crafting directory's (Crafts.lua, UW_GuildDB.crafts, keys
-- e<spell id> as the enchanting window names them), the mats are its recipeInfo, the class and talent weights are
-- GearScore.lua's (ns.GearSpec: Pawn Forever, MythicSim at 60), and prices are the player's own Auctionator scan. The
-- game's own spell text says what each enchant gives; the recipe name's tier word stands in until that text loads.
--
-- Per equipped slot, the menu lists the enchants an online guild enchanter knows, best value first:
--   * power: what the enchant adds, weighed for this character's class and talents;
--   * how long it lasts: the levels until this piece is likely replaced (required level, quality; 60 keeps it);
--   * price: the mats at this player's Auctionator prices.
-- An enchant no stronger than the one already on the piece is left out, and so is one another enchant beats on both
-- power and price (Pareto). One that costs more than a share of the gold on hand, or a pricey one on a piece about to
-- be replaced, goes to the foot of the list in grey. Unpriced and unrated enchants follow the rated ones.
--
-- A click whispers that one enchanter, in the member's own words, with the item link: one whisper per click, nothing
-- automatic (Outbound.lua "enchant.ask"). Nothing is saved or shared about who asked whom. The guild's own Guild
-- Master, this player's own characters and anyone who left are never offered. /uw enchant off hides the button.
local _, ns = ...
local say = ns.say

local function g(name) return rawget(_G, name) end
local function pass(ok, ...) if ok then return ... end end
local function call(fn, ...)
  if type(fn) ~= "function" then return nil end
  return pass(pcall(fn, ...))
end
local function plain(v) return v ~= nil and not ns.isSecret(v) and v or nil end
local function on() return not (UW_GuildDB and UW_GuildDB.enchantButton == false) end

-- The member's own settings (Louis, 22 Nov 2026 21:08: "customization rich"), in UW_GuildDB.enchant; a setting at
-- its default is not saved, so a later default reaches everyone who never chose. The menu's Settings and /uw enchant
-- <setting> <choice> change them.
--   order: value (most power for the gold), power, or price (cheapest first).
--   greyed: show or hide the enchants that are pricey for the gold, on gear replaced soon, or with no one online.
--   spend: the share of the gold on hand one enchant may take before it is greyed: auto (a fifth, half at 60), or
--     10, 20, 35 or 50 percent.
--   mats: say or skip "I have the mats." / "I can bring the mats." at the end of the whisper.
--   nearby: a notice above chat when a free guild enchanter is in the same city as you (once a day at most).
--   asks: an enchanter's own: whether guildmates' addons offer them for asks (off tells the guild once).
ns.ENCHANT_DEFAULTS = { order = "value", greyed = "show", spend = "auto", mats = "say", nearby = "on", asks = "on" }
ns.ENCHANT_CHOICES = {
  order = { { "value", "Best value for the gold" }, { "power", "Most power" }, { "price", "Lowest price" } },
  spend = { { "auto", "Auto: a fifth of my gold, half at 60" }, { "10", "10% of my gold" }, { "20", "20% of my gold" },
    { "35", "35% of my gold" }, { "50", "Half my gold" } },
  greyed = { { "show", "Show greyed-out enchants" }, { "hide", "Hide greyed-out enchants" } },
  mats = { { "say", "Mention the mats in my whisper" }, { "skip", "Leave the mats out" } },
  nearby = { { "on", "Tell me when an enchanter is nearby" }, { "off", "No nearby notices" } },
  asks = { { "on", "Take enchant asks" }, { "off", "Not taking enchant asks" } },
}
ns.ENCHANT_SETTINGS = { "order", "spend", "greyed", "mats", "nearby", "asks" }
-- Stored through the shared settings (Core.lua ns.SettingsDefine, with the terrain view's): the same UW_GuildDB.enchant
-- as before, so nothing a member chose moves. The Options page under UW Guild shows them (SettingsPage.lua, below).
local TIPS = {
  order = "Which enchant leads each piece's list.",
  spend = "Above this share of the gold you carry, an enchant is greyed as pricey.",
  greyed = "Greyed: pricey for your gold, on gear you'll replace soon, or no free enchanter online.",
  mats = "The whisper's last sentence: I have the mats, or I can bring the mats.",
  nearby = "A notice above chat when a free guild enchanter is near you, at most once a day.",
  asks = "For enchanters: off, and guildmates' addons show you as not taking asks.",
}
local LABELS = { order = "Order", spend = "Spend up to", greyed = "Greyed-out enchants", mats = "Mats in the whisper",
  nearby = "Nearby notice", asks = "Enchant asks to me" }
do
  local rows = {}
  for _, key in ipairs(ns.ENCHANT_SETTINGS) do
    local choices, names = {}, {}
    for _, c in ipairs(ns.ENCHANT_CHOICES[key]) do choices[#choices + 1], names[c[1]] = c[1], c[2] end
    rows[#rows + 1] = { key, ns.ENCHANT_DEFAULTS[key], choices = choices, names = names, label = LABELS[key],
      tip = TIPS[key] }
  end
  ns.SettingsDefine("enchant", rows)
end
function ns.EnchantSetting(key) return ns.Setting("enchant", key) end
function ns.EnchantSet(key, value)
  return ns.SetSetting("enchant", key, value) ~= nil
end
ns.OnSetting("enchant", function(key, value)
  if key == "asks" and ns.send then ns.send("ENA\t" .. (value == "off" and "0" or "1"), "GUILD") end
  if key == "nearby" and ns.EnchantNearbyNotice then ns.EnchantNearbyNotice() end
end)
-- The Guild Master's own account (UW_GuildDB.gmAccount): its characters start "not taking asks", once, so his
-- enchanter alts drop out of members' lists without his character list going anywhere (coordinator, 23 Nov 2026:
-- point members to each other, not to Louis). He can turn asks on again; this runs only the first time.
function ns.EnchantGmDefault()
  if type(UW_GuildDB) ~= "table" or UW_GuildDB.enchantGmDefaulted then return false end
  if not (UW_GuildDB.gmAccount == true or ns.VoiceGated and ns.inOurGuild and ns.inOurGuild()
    and call(ns.VoiceGated) and UW_GuildDB.gmAccount == true) then return false end
  UW_GuildDB.enchantGmDefaulted = true
  ns.SetSetting("enchant", "asks", "off")
  return true
end
-- Do I enchant? (my own entry in the crafting directory)
function ns.EnchantIsEnchanter()
  local me = ns.me and ns.me()
  local e = me and type(UW_GuildDB) == "table" and type(UW_GuildDB.crafts) == "table" and UW_GuildDB.crafts[ns.shortName(me)]
  return type(e) == "table" and type(e.profs) == "table" and e.profs.Enchanting ~= nil
end
local function choiceLabel(key, value)
  for _, c in ipairs(ns.ENCHANT_CHOICES[key] or {}) do if c[1] == value then return c[2] end end
end

ns.ENCHANT_MAX_LEVEL = 60
ns.ENCHANT_LIFE_MAX = 20        -- levels: what a piece worn at 60 counts as
ns.ENCHANT_KEEP = { [2] = 6, [3] = 10, [4] = 16 } -- levels past its required level a piece is worn, by quality
ns.ENCHANT_KEEP_PLAIN = 4       -- grey and white pieces
ns.ENCHANT_BUDGET = 0.2         -- share of the gold on hand one enchant may take while leveling
ns.ENCHANT_BUDGET_MAX = 0.5     -- ...and at 60
ns.ENCHANT_SHORT = 2            -- levels left at which a piece counts as about to be replaced
ns.ENCHANT_SHORT_SHARE = 0.05   -- ...and a pricey enchant on it is one over this share of the gold on hand
ns.ENCHANT_FLOOR = 0.1          -- an enchant under this share of the slot's strongest adds next to nothing: left out
ns.ENCHANT_ROWS = 8             -- rows per slot in the menu
ns.ENCHANT_RESEND = 30          -- seconds before the same ask to the same enchanter goes again
ns.ENCHANT_CAP, ns.ENCHANT_CAP_WINDOW = 3, 600 -- asks to one enchanter in ten minutes, whatever the enchant
ns.ENCHANT_TRADE_WINDOW = 3600  -- an ask is matched to a trade for an hour

-- The slot words in enchanting recipe names, and the equipped slots each fits. "Weapon" fits any melee weapon, a
-- two-hander too; "2H Weapon" only a two-hander; "Shield" only a shield.
local WEAPON = { INVTYPE_WEAPON = true, INVTYPE_WEAPONMAINHAND = true, INVTYPE_WEAPONOFFHAND = true,
  INVTYPE_2HWEAPON = true }
ns.ENCHANT_SLOTS = {
  { id = 5, name = "Chest", piece = "chest", words = { Chest = true } },
  { id = 8, name = "Feet", piece = "boots", words = { Boots = true } },
  { id = 9, name = "Wrist", piece = "bracers", words = { Bracer = true, Bracers = true } },
  { id = 10, name = "Hands", piece = "gloves", words = { Gloves = true } },
  { id = 15, name = "Back", piece = "cloak", words = { Cloak = true } },
  { id = 16, name = "Main Hand", piece = "weapon", words = { Weapon = true, ["2H Weapon"] = true } },
  { id = 17, name = "Off Hand", piece = "off hand", words = { Weapon = true, Shield = true } },
}
function ns.EnchantFits(word, slotID, loc)
  if slotID == 16 or slotID == 17 then
    if word == "Shield" then return slotID == 17 and loc == "INVTYPE_SHIELD" end
    if word == "2H Weapon" then return slotID == 16 and loc == "INVTYPE_2HWEAPON" end
    if word == "Weapon" then return WEAPON[loc or ""] == true end
    return false
  end
  for _, s in ipairs(ns.ENCHANT_SLOTS) do
    if s.id == slotID then return s.words[word] == true end
  end
  return false
end

-- "Enchant Bracer - Lesser Stamina" -> "Bracer", "Lesser Stamina".
function ns.EnchantParts(name)
  if type(name) ~= "string" then return nil end
  local word, effect = name:match("^Enchant (.-) %- (.+)$")
  return word, effect
end

-- What an enchant gives, in GearScore.lua's stat names: stats, kind ("stat", "utility" or "proc"). From the spell's
-- own text when it has loaded ("Permanently enchant bracers to increase Stamina by 3."), else from the recipe name.
local STATS = { "Stamina", "Strength", "Agility", "Intellect", "Spirit" }
local SCHOOL = { fire = "FireResist", frost = "FrostResist", nature = "NatureResist", shadow = "ShadowResist",
  arcane = "ArcaneResist" }
local UTILITY = { "fishing", "herbalism", "mining", "skinning", "speed" }
local function fromText(t, n, speed)
  local out = {}
  if t:find("all stats", 1, true) or t:find("all attributes", 1, true) then
    for _, s in ipairs(STATS) do out[s] = n end
    return out
  end
  if t:find("all resist", 1, true) or t:find("all schools", 1, true) or t:find("all spell resist", 1, true) then
    out.AllResist = n
    return out
  end
  local school = t:match("(%a+) resistance")
  if school and SCHOOL[school] then out[SCHOOL[school]] = n return out end
  if t:find("mana every 5", 1, true) or t:find("mana per 5", 1, true) then out.Mp5 = n return out end
  if t:find("healing", 1, true) then out.Healing = n return out end
  if t:find("spell damage", 1, true) or t:find("spell power", 1, true) then
    out.SpellDamage, out.Healing = n, n
    return out
  end
  for _, s in ipairs(STATS) do
    if t:find(s:lower(), 1, true) then out[s] = n return out end
  end
  if t:find("health", 1, true) then out.Health = n return out end
  if t:find("mana", 1, true) then out.Mana = n return out end
  if t:find("armor", 1, true) then out.Armor = n return out end
  if t:find("defense", 1, true) or t:find("deflect", 1, true) then out.DefenseRating = n return out end
  if t:find("damage", 1, true) or t:find("striking", 1, true) or t:find("impact", 1, true) then
    out.MeleeDps = n / ((tonumber(speed) or 0) > 0 and speed or 2.6) -- a point of weapon damage, per swing
    return out
  end
  return nil
end

-- The recipe name's tier word, for an enchant whose spell text hasn't loaded: the usual Classic amounts by kind.
local TIERS = { Minor = 1, Inferior = 2, Lesser = 3, [""] = 4, Greater = 5, Superior = 6, Major = 7 }
local PER_TIER = { -- the amount at each step of TIERS
  stat = { 1, 2, 3, 5, 7, 9, 11 }, health = { 5, 10, 15, 25, 35, 50, 100 }, mana = { 5, 10, 20, 30, 50, 65, 100 },
  armor = { 10, 15, 20, 30, 50, 70, 90 }, striking = { 1, 1, 2, 3, 4, 5, 6 }, impact = { 2, 2, 3, 5, 7, 9, 11 },
  allstats = { 1, 1, 2, 3, 4, 5, 6 }, resist = { 1, 3, 5, 7, 9, 11, 13 }, allresist = { 1, 1, 2, 3, 5, 7, 9 },
  defense = { 1, 1, 2, 3, 4, 5, 6 },
}
local function tierOf(effect)
  local first, rest = effect:match("^(%a+) (.+)$")
  if first and TIERS[first] then return TIERS[first], rest end
  return TIERS[""], effect
end

function ns.EnchantEffect(name, desc, speed)
  local word, effect = ns.EnchantParts(name)
  if not word then return nil end
  local low = (effect or ""):lower()
  for _, u in ipairs(UTILITY) do
    if low:find(u, 1, true) then return {}, "utility" end
  end
  local t = type(desc) == "string" and not ns.isSecret(desc) and desc:lower() or ""
  if t ~= "" then
    if t:find("chance", 1, true) or t:find("often", 1, true) or t:find("occasionally", 1, true)
      or t:find("sometimes", 1, true) then
      return {}, "proc"
    end
    local n = tonumber(t:match("(%d+)"))
    local st = n and fromText(t, n, speed)
    if st then return st, "stat" end
  end
  -- From the name alone.
  local step, rest = tierOf(effect)
  local r = rest:lower()
  local kind = (r == "stats") and "allstats" or (r == "health") and "health" or (r == "mana") and "mana"
    or (r == "protection" or r == "defense") and "armor" or (r == "striking") and "striking"
    or (r == "impact") and "impact" or (r == "resistance") and "allresist" or r:find("resistance", 1, true) and "resist"
    or (r == "deflect" or r == "deflection") and "defense" or "stat"
  local n = PER_TIER[kind][step]
  local st
  if kind == "allstats" then st = fromText("all stats", n)
  elseif kind == "allresist" then st = { AllResist = n }
  elseif kind == "resist" then st = fromText(r, n)
  elseif kind == "armor" then st = { Armor = n }
  elseif kind == "defense" then st = { DefenseRating = n }
  elseif kind == "striking" or kind == "impact" then st = fromText("damage", n, speed)
  else st = fromText(r, n, speed) end
  if not st or not next(st) then return nil end
  return st, "stat", true -- true: from the name, an estimate
end

-- The spell's text, once the client has it. Asked for ahead (the panel's OnShow), so the first open usually has it.
local descs = {}
local function spellDesc(id)
  if descs[id] then return descs[id] end
  local sp = g("C_Spell")
  local d = call(sp and sp.GetSpellDescription or g("GetSpellDescription"), id)
  if type(d) == "string" and not ns.isSecret(d) and d ~= "" then descs[id] = d return d end
  call(sp and sp.RequestLoadSpellData, id)
end
ns.EnchantSpellDesc = spellDesc

-- Who is never offered: this player's own characters (UW_GuildDB.alts and this one) and the Guild Master's (point
-- members to each other, not to Louis). Short names.
local function notOffered()
  local out = {}
  local me = ns.me and ns.me()
  if me then out[ns.shortName(me)] = true end
  for n in pairs(type(UW_GuildDB) == "table" and type(UW_GuildDB.alts) == "table" and UW_GuildDB.alts or {}) do
    if type(n) == "string" then out[ns.shortName(n)] = true end
  end
  -- This player's other guild characters, also those without professions (Identity.lua, member signals lane, once it
  -- ships; until then this adds nothing).
  for _, n in ipairs(ns.IdentityList and call(ns.IdentityList) or {}) do
    if type(n) == "string" then out[ns.shortName(n)] = true end
  end
  for full, rank in pairs(ns.rankOf or {}) do
    if rank == 0 and type(full) == "string" then out[ns.shortName(full)] = true end
  end
  -- The Guild Master's other characters, where this client knows them (WeekOne.lua: on officers' clients once his
  -- character list is shared; a member's client knows only the rank's holder).
  local his = ns.WeekOneIsHis or ns.IsLouis
  return setmetatable(out, { __index = function(_, name)
    return type(his) == "function" and type(name) == "string" and (call(his, name) and true) or nil
  end })
end

-- Every enchant the guild's directory knows: { [key] = { name, word, effect, who = { name, rank } } }.
function ns.EnchantDirectory()
  local out, skip = {}, notOffered()
  local db = UW_GuildDB or {}
  for who, e in pairs(type(db.crafts) == "table" and db.crafts or {}) do
    local m = type(db.members) == "table" and db.members[who]
    local p = type(e) == "table" and type(e.profs) == "table" and e.profs.Enchanting
    if p and type(p.rec) == "table" and not (type(m) == "table" and m.left) and not skip[who] then
      for k, name in pairs(p.rec) do
        local word, effect = ns.EnchantParts(name)
        if word and type(k) == "string" then
          local d = out[k] or { key = k, name = name, word = word, effect = effect, who = {} }
          out[k] = d
          d.who[#d.who + 1] = { name = who, rank = tonumber(p.r) or 0 }
        end
      end
    end
  end
  return out
end

-- Enchanters who said they aren't taking asks (their own "asks off", ENA below): short name -> true. Kept in the
-- save so it holds across sessions; their "on" clears it.
local function asksOff() return type(UW_GuildDB) == "table" and type(UW_GuildDB.enchantAsksOff) == "table"
  and UW_GuildDB.enchantAsksOff or {} end

-- Online guildmates who could be asked now, short name -> full name (never one notOffered names); then the ones
-- online but not free: short name -> "away", "busy" (Do Not Disturb, or in a dungeon or raid: the game's own guild
-- list, so an enchanter without the addon counts too) or "not taking asks"; and everyone's zone, for "nearby".
local function askable()
  local out, held, zones, mine, off = {}, {}, {}, notOffered(), asksOff()
  for i = 1, (call(g("GetNumGuildMembers")) or 0) do
    local full, _, rank, _, _, zone, _, _, online, status = call(g("GetGuildRosterInfo"), i)
    full = plain(full) and ns.fullName(full)
    local short = full and ns.shortName(full)
    if full and online and rank ~= 0 and not mine[short] then
      local busy = off[short] and "not taking asks" or ns.RosterBusy and ns.RosterBusy(status, zone) or nil
      if busy then held[short] = busy else out[short] = full end
      zones[short] = plain(zone)
    end
  end
  return out, held, zones
end
ns.EnchantAskable = askable

-- Mats in "id:count:name,..." (Crafts.lua recipeInfo): their price at this player's Auctionator, and whether the bags
-- hold them all. Price nil when any mat has none.
local function priceOf(id)
  local auc = g("Auctionator")
  local api = type(auc) == "table" and type(auc.API) == "table" and auc.API.v1
  local v = api and call(api.GetAuctionPriceByItemID, "UW_Guild", id)
  if type(v) == "number" and not ns.isSecret(v) and v > 0 then return v end
  v = ns.GoldPrice and call(ns.GoldPrice, id)
  if type(v) == "number" and v > 0 then return v end
end
function ns.EnchantMats(key)
  local info = type(UW_GuildDB) == "table" and type(UW_GuildDB.recipeInfo) == "table" and UW_GuildDB.recipeInfo[key]
  local reag = type(info) == "table" and info.reag
  if type(reag) ~= "string" or reag == "" then return nil end
  local items = g("C_Item")
  local count = items and items.GetItemCount or g("GetItemCount")
  local mats, cost, have = {}, 0, true
  for id, n, name in reag:gmatch("(%d+):(%d+):([^,]*)") do
    id, n = tonumber(id), tonumber(n)
    local p = priceOf(id)
    cost = cost and p and cost + p * n or nil
    if (tonumber((call(count, id))) or 0) < n then have = false end
    mats[#mats + 1] = { id = id, n = n, name = name }
  end
  if #mats == 0 then return nil end
  return mats, cost, have
end

-- Levels until a piece is likely replaced: its required level plus a few by quality; at 60, ENCHANT_LIFE_MAX.
function ns.EnchantLife(level, req, quality)
  level = tonumber(level) or 1
  if level >= ns.ENCHANT_MAX_LEVEL then return ns.ENCHANT_LIFE_MAX end
  local keep = ns.ENCHANT_KEEP[tonumber(quality) or 2] or (tonumber(quality) or 2) > 4 and 16 or ns.ENCHANT_KEEP_PLAIN
  local left = (tonumber(req) and req > 0 and req or level) + keep - level
  return math.max(1, math.min(ns.ENCHANT_LIFE_MAX, left))
end

-- The enchant already on a piece, as power, when the tooltip names it (nil: none, or not readable).
local function current(slotID, link, weights, speed)
  local ench = type(link) == "string" and tonumber(link:match("item:%d+:(%d*)")) or 0
  if ench == 0 then return nil, false end
  local tip, enum = g("C_TooltipInfo"), g("Enum")
  local kind = enum and enum.TooltipDataLineType and enum.TooltipDataLineType.ItemEnchantmentPermanent
  local data = kind and tip and call(tip.GetInventoryItem, "player", slotID)
  for _, l in ipairs(type(data) == "table" and type(data.lines) == "table" and data.lines or {}) do
    local text = plain(l.leftText)
    if l.type == kind and type(text) == "string" then
      local t = text:lower():gsub("^enchanted: ", "")
      local n = tonumber(t:match("(%d+)"))
      local st = n and fromText(t, n, speed)
      if st then return ns.GearValue(st, weights), true end
    end
  end
  return nil, true
end

-- One equipped slot's list: { slot, link, item, life, enchanted, rows = { row... } }, row = { key, name, effect,
-- power, cost, have, mats, who (full names online), offline (short names), note, best, low (demoted), estimate }.
-- ctx (tests): { level, gold, weights, speed = { [16] = n, [17] = n }, online, dir }.
local function equipped(slotID)
  local link = call(g("GetInventoryItemLink"), "player", slotID)
  if type(link) ~= "string" or ns.isSecret(link) then return nil end
  local items = g("C_Item")
  local name, _, quality, ilvl, req, _, _, _, loc = call(items and items.GetItemInfo or g("GetItemInfo"), link)
  return link, name, quality, ilvl, req, loc
end

-- The slots with an upgrade waiting in the bags (AutoEquip.lua's own find: a clear one, or one it would ask about):
-- an enchant there is on a piece about to come off.
local function bagUpgrades()
  local out = {}
  if not ns.FindGearUpgrade then return out end
  local best, cue = pass(pcall(ns.FindGearUpgrade))
  for _, u in ipairs({ best or false, cue or false }) do
    if type(u) == "table" and tonumber(u.target) then out[tonumber(u.target)] = true end
  end
  return out
end

function ns.EnchantContext()
  local spec = ns.GearSpec and call(ns.GearSpec)
  local mh, oh = call(g("UnitAttackSpeed"), "player")
  -- The player's own Pawn scale when Pawn Forever answers for these talents (GearScore.lua), else Pawn Forever's
  -- weights (MythicSim's at 60).
  local pawn = spec and ns.GearPawnWeights and call(ns.GearPawnWeights, spec)
  local online, held, zones = askable()
  return {
    level = tonumber(plain(call(g("UnitLevel"), "player"))) or 1,
    gold = tonumber(plain(call(g("GetMoney")))) or 0,
    weights = pawn or spec and spec.weights or { Stamina = 1, Strength = 1, Agility = 1, Intellect = 1, Spirit = 1 },
    speed = { [16] = tonumber(mh), [17] = tonumber(oh) },
    online = online, held = held, zones = zones,
    dir = ns.EnchantDirectory(),
    upgrade = bagUpgrades(),
    order = ns.EnchantSetting("order"), greyed = ns.EnchantSetting("greyed"), spend = ns.EnchantSetting("spend"),
  }
end

-- Free enchanters first (full names), then the rest (short names): online but not free first, with why.
local function rankWho(list, online, held)
  local up, away, why = {}, {}, nil
  table.sort(list, function(a, b) return a.rank > b.rank or a.rank == b.rank and a.name < b.name end)
  for _, w in ipairs(list) do
    if online[w.name] then up[#up + 1] = online[w.name]
    elseif held and held[w.name] then table.insert(away, 1, w.name) why = why or held[w.name]
    else away[#away + 1] = w.name end
  end
  return up, away, why
end

function ns.EnchantSlot(slotID, ctx)
  local link, item, quality, _, req, loc = equipped(slotID)
  if not link then return nil end
  local life = ns.EnchantLife(ctx.level, req, quality)
  local upgrade = ctx.upgrade and ctx.upgrade[slotID] or false
  if upgrade then life = math.min(life, ns.ENCHANT_SHORT) end
  local speed = ctx.speed and ctx.speed[slotID]
  local have, enchanted = current(slotID, link, ctx.weights, speed)
  local share = tonumber(ctx.spend) and tonumber(ctx.spend) / 100
    or ctx.level >= ns.ENCHANT_MAX_LEVEL and ns.ENCHANT_BUDGET_MAX or ns.ENCHANT_BUDGET
  local budget = (ctx.gold or 0) * share
  local rated, unrated = {}, {}
  for key, d in pairs(ctx.dir) do
    if ns.EnchantFits(d.word, slotID, loc) then
      local id = tonumber(key:match("^e(%d+)$"))
      local st, kind, estimate = ns.EnchantEffect(d.name, id and spellDesc(id), speed)
      local power = st and kind == "stat" and ns.GearValue(st, ctx.weights) or nil
      local mats, cost, gotMats = ns.EnchantMats(key)
      local who, offline, held = rankWho(d.who, ctx.online or {}, ctx.held)
      local row = { key = key, name = d.name, effect = d.effect, power = power, cost = cost, have = gotMats, mats = mats,
        who = who, offline = offline, held = held, estimate = estimate, kind = kind }
      if power and power > 0 then
        if not (have and power <= have + 1e-9) then rated[#rated + 1] = row end
      elseif kind == "utility" or kind == "proc" or not st then
        unrated[#unrated + 1] = row
      end
    end
  end
  -- Next to nothing for this character (defense for a caster): left out. Then Pareto: drop a priced enchant another
  -- beats on power and price.
  local top = 0
  for _, a in ipairs(rated) do top = math.max(top, a.power) end
  local keep = {}
  for _, a in ipairs(rated) do
    local beaten = a.power < top * ns.ENCHANT_FLOOR
    if a.cost and not beaten then
      for _, b in ipairs(rated) do
        if b ~= a and b.cost and b.power >= a.power and b.cost <= a.cost and (b.power > a.power or b.cost < a.cost) then
          beaten = true
          break
        end
      end
    end
    if not beaten then keep[#keep + 1] = a end
  end
  for _, r in ipairs(keep) do
    r.value = r.cost and r.power * life / math.max(r.cost, 1) or nil
    if r.cost and budget > 0 and r.cost > budget then r.low, r.note = true, "pricey for your gold"
    elseif r.cost and (ctx.gold or 0) <= 0 then r.low, r.note = true, "pricey for your gold"
    elseif r.cost and life <= ns.ENCHANT_SHORT and r.cost > (ctx.gold or 0) * ns.ENCHANT_SHORT_SHARE then
      r.low, r.note = true, upgrade and "upgrade in your bags" or "gear replaced soon"
    elseif not r.cost and life <= ns.ENCHANT_SHORT then
      r.low, r.note = true, upgrade and "upgrade in your bags" or "gear replaced soon"
    elseif not r.cost then r.note = "no price yet" end
  end
  -- Order: online first; then affordable priced, unpriced, demoted; within each, the member's order (value: by
  -- value, unpriced by power; power: by power; price: cheapest first).
  local function group(r)
    if #r.who == 0 then return 4 end
    if r.low then return 3 end
    if not r.cost then return 2 end
    return 1
  end
  local order = ctx.order or ns.ENCHANT_DEFAULTS.order
  table.sort(keep, function(a, b)
    local ga, gb = group(a), group(b)
    if ga ~= gb then return ga < gb end
    if order == "price" and a.cost and b.cost and a.cost ~= b.cost then return a.cost < b.cost end
    if order ~= "power" and a.value and b.value and a.value ~= b.value then return a.value > b.value end
    if a.power ~= b.power then return a.power > b.power end
    return a.name < b.name
  end)
  -- Best: the most power for the gold among the affordable, whatever the order.
  local best
  for _, r in ipairs(keep) do
    if group(r) == 1 and r.value and (not best or r.value > best.value) then best = r end
  end
  if best then best.best = true end
  table.sort(unrated, function(a, b) return a.name < b.name end)
  for _, r in ipairs(unrated) do keep[#keep + 1] = r end
  if ctx.greyed == "hide" then
    local shown = {}
    for _, r in ipairs(keep) do if not r.low and #r.who > 0 then shown[#shown + 1] = r end end
    keep = shown
  end
  return { slot = slotID, link = link, item = item, life = life, enchanted = enchanted, upgrade = upgrade, rows = keep }
end

-- Every slot with at least one enchant the guild knows.
function ns.EnchantPlan(ctx)
  ctx = ctx or ns.EnchantContext()
  local out = {}
  for _, s in ipairs(ns.ENCHANT_SLOTS) do
    local p = ns.EnchantSlot(s.id, ctx)
    if p and #p.rows > 0 then p.label = s.name out[#out + 1] = p end
  end
  return out, ctx
end

-- The ask -----------------------------------------------------------------------------------------------------------
-- The whisper is written for the member (Louis, 22 Nov 2026 21:45: "a prefilled whisper"); their click sends it as it
-- stands (Outbound.lua "enchant.ask"). Not typed into the chat box for them: addon code there taints every later send
-- (chat_bar_test, 10 Nov 2026). One enchanter hears at most ENCHANT_CAP asks from one member in ten minutes, and never
-- the same one twice within ENCHANT_RESEND seconds.
local sentAt, asksTo = {}, {}
-- Who, for matching an ask to a trade: the name without its realm, in lower case (a trade partner's UnitName has no
-- realm; a whisper's sender has one).
local function who(name) return type(name) == "string" and (name:gsub("%-.*$", "")):lower() or nil end
ns.EnchantWho = who
ns.EnchantAsked = {} -- [lower short name of the enchanter] = { key, name, link, at }: matched to a trade with them
-- A chat line holds 255 bytes (Louis, 22 Nov 2026 22:21: "always respect all character limits"): with a long item
-- link the mats sentence goes first, then the link gives way to the item's plain name.
ns.ENCHANT_LINE_MAX = 255
function ns.EnchantAskText(row, link)
  local function ask(l) return ("Hi! Could you put %s on my %s?"):format(row.name, l) end
  local text = ask(link)
  if #text > ns.ENCHANT_LINE_MAX then text = ask(link:match("|h%[(.-)%]|h") or "gear") end
  if ns.EnchantSetting("mats") == "skip" then return text end
  local full = text .. (row.have and " I have the mats." or " I can bring the mats.")
  return #full <= ns.ENCHANT_LINE_MAX and full or text
end
local function now() return GetTime and GetTime() or 0 end
function ns.EnchantCapped(to)
  local list, t, n = asksTo[to] or {}, now(), 0
  for _, at in ipairs(list) do if t - at < ns.ENCHANT_CAP_WINDOW then n = n + 1 end end
  return n >= ns.ENCHANT_CAP
end
function ns.EnchantAsk(row, link, to)
  if not (row and link and to) then return false end
  local k, t = to .. "\t" .. row.key, now()
  if sentAt[k] and t - sentAt[k] < ns.ENCHANT_RESEND then return false end
  if ns.EnchantCapped(to) then
    say(("You asked %s a few times just now: give them a moment."):format(ns.shortName(to)))
    return false
  end
  local text = ns.EnchantAskText(row, link)
  local ok = ns.chat("enchant.ask", text, "WHISPER", to)
  if ok then
    sentAt[k] = t
    asksTo[to] = asksTo[to] or {}
    table.insert(asksTo[to], t)
    if #asksTo[to] > ns.ENCHANT_CAP then table.remove(asksTo[to], 1) end
    ns.EnchantAsked[who(to)] = { key = row.key, name = row.name, link = link, at = t }
  end
  return ok
end

-- The menu ----------------------------------------------------------------------------------------------------------
local function money(c)
  local cur = g("C_CurrencyInfo")
  return call(g("GetCoinTextureString") or (cur and cur.GetCoinTextureString), c) or (tostring(c) .. "c")
end
-- one: the enchanter every row of this slot would whisper, named once in the slot's title instead of on each row.
function ns.EnchantRowText(r, one)
  local parts = { r.effect }
  if r.cost then parts[#parts + 1] = money(r.cost) end
  if #r.who > 0 then
    if r.who[1] ~= one then parts[#parts + 1] = ns.shortName(r.who[1]) end
  elseif r.offline[1] then parts[#parts + 1] = r.offline[1] .. " " .. (r.held or "offline") end
  if r.note then parts[#parts + 1] = r.note end
  local text = table.concat(parts, " · ")
  if r.best then text = "Best: " .. text end
  if r.low or #r.who == 0 then text = "|cff808080" .. text .. "|r" end
  return text
end
local function rowTip(tooltip, r)
  tooltip:SetText(r.name, 1, 1, 1)
  if r.mats then
    local names = {}
    for _, m in ipairs(r.mats) do names[#names + 1] = m.n > 1 and ("%s x%d"):format(m.name, m.n) or m.name end
    tooltip:AddLine("Mats: " .. table.concat(names, ", ") .. (r.have and " (in your bags)" or ""), 1, 0.82, 0, true)
  end
  if r.best then tooltip:AddLine("Most power for the gold on this piece.", 0.25, 1, 0.25, true) end
  if #r.who > 1 then
    local also = {}
    for i = 2, math.min(#r.who, 4) do also[#also + 1] = ns.shortName(r.who[i]) end
    tooltip:AddLine("Also online: " .. table.concat(also, ", "), 0.8, 0.8, 0.8, true)
  end
  tooltip:AddLine(#r.who > 0 and ("Click to whisper %s."):format(ns.shortName(r.who[1]))
    or r.held and ("%s is %s."):format(r.offline[1], r.held) or "No one who knows it is online.", 0.6, 0.6, 0.6, true)
end

-- Settings, last in the menu: a radio a choice, as the game's own menus do. A pick keeps the menu open on it (the
-- game's MenuResponse.Refresh) so a second pick needs no reopen; the list itself follows on the next open.
local function settingsMenu(root)
  local set = root:CreateButton("Settings")
  for _, key in ipairs(ns.ENCHANT_SETTINGS) do
    if key == "asks" and not ns.EnchantIsEnchanter() then break end
    if key ~= ns.ENCHANT_SETTINGS[1] then set:CreateDivider() end
    for _, c in ipairs(ns.ENCHANT_CHOICES[key]) do
      local pick = function() ns.EnchantSet(key, c[1]) local r = g("MenuResponse") return r and r.Refresh end
      if set.CreateRadio then
        set:CreateRadio(c[2], function() return ns.EnchantSetting(key) == c[1] end, pick)
      else
        set:CreateButton((ns.EnchantSetting(key) == c[1] and "* " or "") .. c[2], pick)
      end
    end
  end
  set:CreateDivider()
  if ns.OpenSettingsPage then set:CreateButton("All settings", function() ns.OpenSettingsPage("enchant") end) end
  set:CreateButton("Hide this button", function() ns.commands.enchant("off") end)
end

function ns.EnchantMenu(owner)
  local menu = g("MenuUtil")
  if not (menu and menu.CreateContextMenu) then ns.commands.enchant("") return end
  local plan = ns.EnchantPlan()
  menu.CreateContextMenu(owner, function(_, root)
    root:CreateTitle("Ask a guild enchanter")
    if #plan == 0 then
      local none = root:CreateButton("No guild enchanter knows an enchant for your gear yet.", function() end)
      none:SetEnabled(false)
      if root.CreateDivider then root:CreateDivider() end
      settingsMenu(root)
      return
    end
    for _, p in ipairs(plan) do
      local slot = root:CreateButton(("%s: %s%s"):format(p.label, p.item or "?",
        p.upgrade and " (upgrade in your bags)" or p.enchanted and " (enchanted)" or ""))
      local one
      for i = 1, math.min(#p.rows, ns.ENCHANT_ROWS) do
        local w = p.rows[i].who[1]
        if w and (one == nil or one == w) then one = w elseif w then one = false break end
      end
      if one then slot:CreateTitle(("Asks go to %s"):format(ns.shortName(one))) end
      for i = 1, math.min(#p.rows, ns.ENCHANT_ROWS) do
        local r = p.rows[i]
        local b = slot:CreateButton(ns.EnchantRowText(r, one or nil), function()
          ns.protect(ns.EnchantAsk, r, p.link, r.who[1])
        end)
        if #r.who == 0 then b:SetEnabled(false) end
        if b.SetTooltip then b:SetTooltip(function(tooltip) rowTip(tooltip, r) end) end
      end
    end
    if root.CreateDivider then root:CreateDivider() end
    settingsMenu(root)
  end)
end

-- /uw enchant: the best ask per slot in chat; on and off for the button; /uw enchant <setting> [choice].
local function settingsLine()
  local parts = {}
  for _, key in ipairs(ns.ENCHANT_SETTINGS) do parts[#parts + 1] = key .. " " .. ns.EnchantSetting(key) end
  return "Enchant settings: " .. table.concat(parts, ", ") .. "."
end
ns.commands.enchant = function(args)
  local w = strtrim(args or ""):lower()
  local key, value = w:match("^(%a+)%s*(%w*)$")
  if key and ns.ENCHANT_CHOICES[key] then
    if value == "" then
      local list = {}
      for _, c in ipairs(ns.ENCHANT_CHOICES[key]) do list[#list + 1] = c[1] end
      say(("Enchant %s: %s. Choices: %s."):format(key, ns.EnchantSetting(key), table.concat(list, ", ")))
    elseif ns.EnchantSet(key, value) then
      say(("Enchant %s: %s."):format(key, choiceLabel(key, value)))
    else
      local list = {}
      for _, c in ipairs(ns.ENCHANT_CHOICES[key]) do list[#list + 1] = c[1] end
      say(("Enchant %s takes %s."):format(key, table.concat(list, ", ")))
    end
    return
  end
  if w == "settings" then say(settingsLine()) return end
  if w == "off" or w == "on" then
    if w == "on" then UW_GuildDB.enchantButton = nil else UW_GuildDB.enchantButton = false end
    if ns.EnchantButtonRefresh then ns.EnchantButtonRefresh() end
    say(w == "off" and "Enchant button off. /uw enchant on brings it back."
      or "Enchant button on: bottom left of your character panel.")
    return
  end
  local plan = ns.EnchantPlan()
  if #plan == 0 then say("No guild enchanter knows an enchant for your gear yet.") return end
  for _, p in ipairs(plan) do
    local r = p.rows[1]
    say(("%s: %s"):format(p.label, (ns.EnchantRowText(r):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))))
  end
  say("Click the enchant button on your character panel to ask.")
end

-- Nearby ------------------------------------------------------------------------------------------------------------
-- (Louis, 22 Nov 2026 21:45: "a suggestion that pops up when a guildie is nearby that can enchant your gear with a
-- prefilled whisper"; 22:00: "I wouldn't mind it appearing in the wild while questing if out of combat".) One notice
-- on the bar above chat, never a window: out of a fight and out of dungeons, in town or out questing, when a free guild
-- enchanter is in the same zone (the guild list's own zone) and knows the
-- best-value enchant for a piece you'll keep (a row marked Best). At most once a day per character; its tooltip shows
-- the whisper word for word, its click sends it, its close mark sets it aside. Nothing about anyone is saved.
-- A day key (UTC days): "once a day" needs no time zone.
local function today() return math.floor((tonumber(time()) or 0) / 86400) end
local function pieceOf(slot)
  for _, s in ipairs(ns.ENCHANT_SLOTS) do if s.id == slot then return s.piece end end
end
function ns.EnchantNearby(ctx)
  if ns.EnchantSetting("nearby") ~= "on" or not on() then return nil end
  if call(g("InCombatLockdown")) or call(g("IsInInstance")) or call(g("UnitAffectingCombat"), "player") then
    return nil
  end
  local here = plain(call(g("GetRealZoneText")))
  if not here then return nil end
  ctx = ctx or ns.EnchantContext()
  local pick
  for _, p in ipairs((ns.EnchantPlan(ctx))) do
    for _, r in ipairs(p.rows) do
      if r.best then
        for _, full in ipairs(r.who) do
          if ctx.zones[ns.shortName(full)] == here and not ns.EnchantCapped(full) then
            if not pick or (r.value or 0) > (pick.row.value or 0) then
              pick = { plan = p, row = r, to = full, zone = here, town = call(g("IsResting")) and true or false }
            end
            break
          end
        end
      end
    end
  end
  return pick
end

local nearby, showing, checkedAt = nil, nil, -math.huge
function ns.EnchantNearbyButton() return nearby end
local function hideNearby() showing = nil if nearby then nearby:Hide() end end
function ns.EnchantNearbyClick()
  local c = showing
  if c then ns.protect(ns.EnchantAsk, c.row, c.plan.link, c.to) end
  hideNearby()
end
function ns.EnchantNearbyNotice()
  if ns.Restricted and ns.Restricted() or not ns.ChatBarAdd or (ns.ChatBarHidden and ns.ChatBarHidden())
    or not ns.tracksGuild() then hideNearby() return nil end
  local pick = ns.EnchantNearby()
  if showing then -- the one on show stays while it still holds; the day is spent either way
    if not (pick and pick.to == showing.to and pick.row.key == showing.row.key) then hideNearby() end
    return showing
  end
  if not pick or not UW_GuildCharDB or UW_GuildCharDB.enchantNearbyDay == today() then return nil end
  if not nearby then
    nearby = CreateFrame("Button", "UWGuildEnchantNearby", UIParent)
    nearby:SetScript("OnClick", function() ns.EnchantNearbyClick() end)
    ns.useButton(nearby, "enchant nearby")
    nearby.uwClose = hideNearby
    ns.ChatBarAdd("enchant nearby", nearby, 30, "")
  end
  showing = pick
  UW_GuildCharDB.enchantNearbyDay = today()
  nearby:Show()
  nearby.uwTip = ("Click to whisper: %s\nClose: not again today."):format(ns.EnchantAskText(pick.row, pick.plan.link))
  -- In town "nearby" is true; out in a zone the size of the Barrens, the zone says it.
  ns.ChatBarText(nearby, ("Enchant your %s: %s is %s"):format(pieceOf(pick.plan.slot) or "gear",
    ns.shortName(pick.to), pick.town and "nearby" or ("in %s too"):format(pick.zone)))
  return pick
end
local function checkSoon(force)
  local t = now()
  if not force and not showing and t - checkedAt < 30 then return end
  checkedAt = t
  ns.after(2, ns.EnchantNearbyNotice)
end

-- Enchanters: "not taking asks" (ENA, GUILD: 0 off, 1 on again) -------------------------------------------------------
ns.handlers.ENA = function(sender, channel, flag)
  if channel ~= "GUILD" or not ns.inRoster(sender) or type(UW_GuildDB) ~= "table" then return end
  local short = ns.shortName(sender)
  if flag == "0" then
    UW_GuildDB.enchantAsksOff = UW_GuildDB.enchantAsksOff or {}
    UW_GuildDB.enchantAsksOff[short] = true
  elseif flag == "1" and type(UW_GuildDB.enchantAsksOff) == "table" then
    UW_GuildDB.enchantAsksOff[short] = nil
    if next(UW_GuildDB.enchantAsksOff) == nil then UW_GuildDB.enchantAsksOff = nil end
  end
end

-- The trade window --------------------------------------------------------------------------------------------------
-- Asker: trading with the enchanter they asked in the last hour, one line under the window says how the handoff goes
-- (the enchanter casts from their own bags, so the mats go over first). Enchanter: trading with someone whose ask
-- they got in the last hour, a button under the window casts that enchant; then they click the item in the bottom
-- slot. The asks are matched from the whisper's own words and kept in memory for the hour only.
local incoming = {} -- [lower short name of the asker] = { name = enchant, at }
function ns.EnchantHeard(sender, msg)
  if type(msg) ~= "string" or type(sender) ~= "string" or ns.isSecret(msg) then return nil end
  if not ns.inRoster(sender) then return nil end -- guildmates' asks only (red team, #928): a stranger gets no Cast button
  local name = msg:match("Could you put (Enchant .- %- .-) on my ")
  if not name then return nil end
  incoming[who(sender)] = { name = name, at = now() }
  return name
end
local function fresh(t) return t and now() - t.at < ns.ENCHANT_TRADE_WINDOW and t or nil end
local tradeLine, castButton
function ns.EnchantTradeShow()
  local frame = g("TradeFrame")
  local partner = plain(call(g("UnitName"), "NPC"))
  if not (frame and partner) then return nil end
  local key = who(partner)
  local asked, heard = fresh(ns.EnchantAsked[key]), fresh(incoming[key])
  if asked then
    if not tradeLine then
      tradeLine = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
      tradeLine:SetPoint("TOP", frame, "BOTTOM", 0, -6)
      tradeLine:SetWidth(320)
    end
    tradeLine:SetText(("Trade the mats first, then put %s in the bottom slot."):format(asked.link))
    tradeLine:Show()
    return "asker"
  end
  if heard and not call(g("InCombatLockdown")) and call(g("C_Spell") and g("C_Spell").GetSpellInfo or g("GetSpellInfo"),
    heard.name) then
    if not castButton then
      castButton = CreateFrame("Button", "UW_GuildEnchantCast", frame, "SecureActionButtonTemplate,UIPanelButtonTemplate")
      castButton:SetSize(260, 24)
      castButton:SetPoint("TOP", frame, "BOTTOM", 0, -6)
      castButton:RegisterForClicks("AnyUp", "AnyDown")
      castButton:SetAttribute("type", "spell")
      ns.useButton(castButton, "enchant cast")
      castButton:SetScript("OnEnter", function(self)
        local tip = g("GameTooltip")
        if not tip then return end
        tip:SetOwner(self, "ANCHOR_BOTTOM")
        tip:SetText("Then click their item in the bottom slot.", 1, 1, 1, true)
        tip:Show()
      end)
      castButton:SetScript("OnLeave", function() local tip = g("GameTooltip"); if tip then tip:Hide() end end)
    end
    castButton:SetAttribute("spell", heard.name)
    castButton:SetText("Cast " .. (select(2, ns.EnchantParts(heard.name)) or heard.name))
    castButton:Show()
    return "enchanter"
  end
end
function ns.EnchantCastButton() return castButton end
function ns.EnchantTradeClosed()
  if tradeLine then tradeLine:Hide() end
  if castButton and not call(g("InCombatLockdown")) then castButton:Hide() end
end

-- The settings page: Options > AddOns > UW Guild > Ask a guild enchanter, the button's own switch on top.
ns.SettingsPage("enchant", "Ask a guild enchanter", {
  { title = "Ask a guild enchanter", feature = "enchant",
    part = { label = "Show the enchant button", on = on, cmd = "enchant",
      tip = "The icon under your wrist slot: enchants guildmates can make for your gear, best value first." } },
})

-- The button: bottom left of the character panel, under the wrist slot (Blizzard's sheet and EllesmereUI's skin of
-- it alike), on the slots' own frame so it goes with the paper doll tab.
local button
local function refresh()
  if not button then return end
  button:SetShown(on() and ns.tracksGuild() and true or false)
end
ns.EnchantButtonRefresh = refresh

local function warm() -- ask for the spell texts ahead, so the first open has them
  for key in pairs(ns.EnchantDirectory()) do
    local id = tonumber(key:match("^e(%d+)$"))
    if id then spellDesc(id) end
  end
end

function ns.EnchantButton()
  if button then return button end
  local parent, wrist = g("PaperDollItemsFrame"), g("CharacterWristSlot")
  if not (parent and wrist) then return nil end
  button = CreateFrame("Button", "UW_GuildEnchantButton", parent)
  button:SetSize(22, 22)
  button:SetPoint("TOP", wrist, "BOTTOM", 0, -6)
  button:SetFrameLevel((call(parent.GetFrameLevel, parent) or 1) + 6)
  local edge = button:CreateTexture(nil, "BACKGROUND") -- the grey edge EllesmereUI gives an empty slot
  edge:SetPoint("TOPLEFT", -1, 1)
  edge:SetPoint("BOTTOMRIGHT", 1, -1)
  edge:SetColorTexture(0.25, 0.25, 0.25, 1)
  local icon = button:CreateTexture(nil, "ARTWORK")
  icon:SetAllPoints()
  icon:SetTexture("Interface\\Icons\\Trade_Engraving")
  icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  button:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
  button:SetScript("OnClick", function(self) ns.protect(ns.EnchantMenu, self) end)
  ns.useButton(button, "enchant ask")
  button:SetScript("OnEnter", function(self)
    ns.protect(warm)
    local tip = g("GameTooltip")
    if not tip then return end
    tip:SetOwner(self, "ANCHOR_RIGHT")
    tip:SetText("Ask a guild enchanter")
    tip:AddLine("Best value for your level, gear and gold.", 1, 1, 1, true)
    tip:AddLine("/uw enchant off hides this.", 0.6, 0.6, 0.6, true)
    tip:Show()
  end)
  button:SetScript("OnLeave", function() local tip = g("GameTooltip"); if tip then tip:Hide() end end)
  refresh()
  return button
end

local f = CreateFrame("Frame")
ns.listen(f, { "PLAYER_LOGIN", "PLAYER_GUILD_UPDATE", "PLAYER_UPDATE_RESTING", "ZONE_CHANGED_NEW_AREA",
  "GUILD_ROSTER_UPDATE", "PLAYER_REGEN_ENABLED", "TRADE_SHOW", "TRADE_CLOSED", "CHAT_MSG_WHISPER" })
f:SetScript("OnEvent", ns.guard(function(_, event, a1, a2)
  if event == "TRADE_SHOW" then ns.EnchantTradeShow() return end
  if event == "TRADE_CLOSED" then ns.EnchantTradeClosed() return end
  if event == "CHAT_MSG_WHISPER" then ns.EnchantHeard(a2, a1) return end
  if event ~= "PLAYER_LOGIN" and event ~= "PLAYER_GUILD_UPDATE" then
    checkSoon(event ~= "GUILD_ROSTER_UPDATE")
    return
  end
  if event == "PLAYER_LOGIN" and ns.afterRoster then
    ns.afterRoster(function()
      ns.protect(ns.EnchantGmDefault)
      local off = type(UW_GuildDB) == "table" and UW_GuildDB.enchantAsksOff
      if type(off) == "table" then -- left the guild: forget their "not taking asks"
        for n in pairs(off) do if not ns.inRoster(n) then off[n] = nil end end
        if next(off) == nil then UW_GuildDB.enchantAsksOff = nil end
      end
    end)
  end
  if event == "PLAYER_LOGIN" and ns.EnchantSetting("asks") == "off" then
    ns.after(20, function() ns.send("ENA\t0", "GUILD") end) -- members who logged in since hear it again
  end
  if not ns.EnchantButton() then return end
  refresh()
  local frame = g("CharacterFrame")
  if frame and frame.HookScript and not f.hooked then
    f.hooked = true
    frame:HookScript("OnShow", function() ns.protect(refresh); ns.protect(warm) end)
  end
end))
