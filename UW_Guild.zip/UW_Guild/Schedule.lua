-- The next Rallies and raid nights. The UW bot rewrites this file on the Guild Master's PC (bot/uwbot/gamesched.py);
-- this empty copy is what ships. Members get the schedule from an officer's client (WhatsOn.lua). Data only.
local _, ns = ...
ns.SCHEDULE = { gen = 0, ev = {
} }
