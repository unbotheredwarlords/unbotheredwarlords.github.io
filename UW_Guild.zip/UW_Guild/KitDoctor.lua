-- Kit troubleshooting (Louis, 4 Nov 2026): help a member who has never used addons find what's wrong, and give
-- officers the same picture. No new command: /uw kit shows a one-line summary, /uw kit report a copyable line for
-- /ask-officers in Discord, and each /uw audit reply carries the counts.
--
-- What it reads (this session only, except the two small saved tables named at the end):
--   * errors: from BugGrabber when it's installed (the kit's Troubleshooting extra), grouped by the addon whose file
--     the error names. We install no error handler of our own (two would fight): Core.lua's ns.protect only keeps
--     UW_Guild's own errors and passes each one on to the game's handler, so BugGrabber still gets it.
--   * blocked: ADDON_ACTION_BLOCKED / ADDON_ACTION_FORBIDDEN, which name the addon the game stopped (a common cause
--     of "my action bar stopped working" on the modern client).
--   * outdated: turned on but not loading because it has no file for this client (no Forever file).
--   * deps: turned on but not loading because an addon it needs is missing or turned off.
--   (Load-on-demand addons are skipped in both: they never load here and harm nothing.)
--   * client: the game functions UW_Guild needs that this client lacks, and UW_Guild's own errors (Core.lua keeps
--     the last few in UW_GuildDB.errors; that and UW_GuildDB.client are the two things saved here).
local _, ns = ...

local blocked = {}      -- addon -> times blocked this session
local blockedFn = {}    -- addon -> the last function the game stopped

local function sortedCounts(t)
  local out = {}
  for name, n in pairs(t) do out[#out + 1] = { name = name, n = n } end
  table.sort(out, function(a, b) if a.n ~= b.n then return a.n > b.n end return a.name < b.name end)
  return out
end

-- The addon folder an error message or stack names: ".../AddOns/OpenMap/Map/Core.lua:12: ...".
local function addonOf(text)
  if type(text) ~= "string" then return nil end
  return text:match("[Aa]dd[Oo]ns[/\\]([^/\\]+)[/\\]")
end
ns.KitAddonOf = addonOf

-- BugGrabber's errors from this session, per addon. Every call is guarded: an older or newer BugGrabber with
-- another shape just gives no counts.
local function errorCounts()
  local bg = rawget(_G, "BugGrabber")
  if type(bg) ~= "table" or type(bg.GetDB) ~= "function" then return nil end
  local okDB, db = pcall(bg.GetDB, bg)
  if not okDB or type(db) ~= "table" then return nil end
  local session = type(bg.GetSessionId) == "function" and select(2, pcall(bg.GetSessionId, bg)) or nil
  local out = {}
  for _, err in ipairs(db) do
    if type(err) == "table" and (session == nil or err.session == session) then
      local name = addonOf(err.message) or addonOf(err.stack) or "unknown"
      out[name] = (out[name] or 0) + (tonumber(err.counter) or 1)
    end
  end
  return out
end

-- Addons turned on for this character that can't load, by reason. Load-on-demand ones are left out: the retail
-- raid modules a boss mod download brings, or BigWigs' parts once BigWigs is off, never load here and harm nothing,
-- and listing a dozen of them would bury the one addon that really is broken.
local function lazy(name)
  local ok, lod = pcall(C_AddOns.IsAddOnLoadOnDemand or function() return false end, name)
  return ok and lod and true or false
end
local function notLoading()
  local outdated, deps = {}, {}
  local num = C_AddOns.GetNumAddOns and C_AddOns.GetNumAddOns() or 0
  local me = UnitName("player")
  for i = 1, num do
    local name, _, _, _, reason = C_AddOns.GetAddOnInfo(i)
    -- Turned on for this character (0 = off; modern order: name, then character). Guarded: a client with another
    -- signature just reports nothing here.
    local ok, state = false, 0
    if name and C_AddOns.GetAddOnEnableState then ok, state = pcall(C_AddOns.GetAddOnEnableState, name, me) end
    if ok and (tonumber(state) or 0) > 0 and not C_AddOns.IsAddOnLoaded(name) and not lazy(name) then
      if reason == "INTERFACE_VERSION" then outdated[#outdated + 1] = name
      elseif reason == "DEP_MISSING" or reason == "DEP_DISABLED" or reason == "DEP_INTERFACE_VERSION"
        or reason == "DEP_DEMAND_LOADED" or reason == "DEP_NOT_DEMAND_LOADED" then deps[#deps + 1] = name end
    end
  end
  table.sort(outdated)
  table.sort(deps)
  return outdated, deps
end

local function sum(t) local n = 0 for _, v in pairs(t or {}) do n = n + v end return n end

-- The game functions UW_Guild needs, checked on the real client (the tests only model it). An entry with "/" counts
-- when either one is there. What breaks without each: messages between guildmates; the roster (joins, levels,
-- ranks, last online); the weekly reset and realm time; the kit check and /uw kit fix; their dialogs; raid
-- attendance and shout-outs; the guild bank count. The profession and weapon readers have their own (/uw craft check).
ns.CLIENT_NEEDS = {
  "C_ChatInfo.SendAddonMessage", "C_ChatInfo.RegisterAddonMessagePrefix",
  "C_GuildInfo.GuildRoster", "GetGuildRosterInfo", "GetGuildRosterLastOnline", "GetGuildInfo",
  "GuildControlGetNumRanks", "GuildControlGetRankName",
  "C_DateAndTime.GetSecondsUntilWeeklyReset", "GetServerTime", "GetNormalizedRealmName",
  "C_AddOns.GetAddOnInfo", "C_AddOns.GetNumAddOns", "C_AddOns.GetAddOnEnableState", "C_AddOns.EnableAddOn",
  "C_AddOns.DisableAddOn", "C_AddOns.IsAddOnLoadOnDemand", "C_EventUtils.IsEventValid",
  "StaticPopup_Show", "UnitGUID", "ReloadUI",
  "GetRaidRosterInfo", "UnitIsInMyGuild", "C_DamageMeter.GetCombatSessionFromType",
  "C_Container.GetContainerItemInfo/GetContainerItemInfo",
}
local function resolve(path)
  local v = _G
  for part in path:gmatch("[^%.]+") do
    if type(v) ~= "table" then return nil end
    v = rawget(v, part)
  end
  return v
end
-- The needed functions this client lacks, in list order.
function ns.ClientMissing()
  local out = {}
  for _, need in ipairs(ns.CLIENT_NEEDS) do
    local have = false
    for alt in need:gmatch("[^/]+") do if type(resolve(alt)) == "function" then have = true end end
    if not have then out[#out + 1] = need end
  end
  return out
end
local function apis(t)
  local keys, out = {}, {}
  for k in pairs(t or {}) do keys[#keys + 1] = k end
  table.sort(keys)
  for _, k in ipairs(keys) do out[#out + 1] = k .. "=" .. tostring(t[k]) end
  return table.concat(out, ",")
end
-- Saved once per login: the first real login tells us what this client has, read from SavedVariables by the launch
-- check and the bot (an #officer-chat note when something is missing), so nobody has to type /uw craft check.
-- Two live checks that only normal play can make (audit F-B14) ride along: `reset` is how far away the client says
-- the weekly reset is (the bot flags anything outside 0 to 7 days), and `roll` is when a /roll result last matched
-- the pattern the loot rolls read (`rollFormat`, the client's own wording); kept from login to login. `iface` is the
-- client's interface number (GetBuildInfo's 4th value): on patch day it moves past UW_Guild.toc's, and the bot says to
-- bump the .toc while UW_Guild still loads (pre-mortem, 5 Nov 2026; CONTRIBUTING.md, Patch day).
local function clean(s, n) return (tostring(s or ""):gsub("[%c|]", " "):sub(1, n)) end
function ns.RecordClient()
  local build = GetBuildInfo and select(1, GetBuildInfo()) or "?"
  local okB, _, _, _, iface = pcall(GetBuildInfo)
  local old = type(UW_GuildDB.client) == "table" and UW_GuildDB.client or {}
  local untilReset = C_DateAndTime and C_DateAndTime.GetSecondsUntilWeeklyReset
    and C_DateAndTime.GetSecondsUntilWeeklyReset()
  UW_GuildDB.client = { at = time(), ver = ns.VERSION, build = clean(build, 32),
    iface = okB and not ns.isSecret(iface) and tonumber(iface) or nil,
    missing = table.concat(ns.ClientMissing(), ","),
    craft = ns.CraftApis and apis(ns.CraftApis()) or "", gear = ns.GearApis and apis(ns.GearApis()) or "",
    reset = (type(untilReset) == "number" and not ns.isSecret(untilReset)) and math.floor(untilReset) or nil,
    rollFormat = clean(RANDOM_ROLL_RESULT or "(none: English fallback)", 60),
    roll = tonumber(old.roll), names = type(old.names) == "table" and old.names or nil,
    journal = type(old.journal) == "table" and old.journal or nil, spells = type(old.spells) == "table" and old.spells or nil }
end
table.insert(ns.onLoad, function() ns.RecordClient() end)

-- Whether this client's own Encounter Journal has our raids, with Blizzard's boss and ability text: the most reliable
-- source a strategy guide could quote (strategy-guide thread, 4 Nov 2026). ForeverDungeonJournal says Forever adds its
-- dungeons in a separate journal tier, so every tier is read. Read only: the journal's selected tier is put back
-- after. { tiers, raids = { [name] = { tier, enc, text } }, other = "raid names not ours" }, or nil without the API.
ns.JOURNAL_RAIDS = { "Hyjal Summit", "Barrow Deeps" }
local function pass(ok, ...) if ok then return ... end end
local function call(fn, ...) return pass(pcall(fn, ...)) end -- every value, nils between them too
local function plain(v) return type(v) == "string" and not ns.isSecret(v) and v ~= "" and v or nil end
function ns.ProbeJournal()
  for _, fn in ipairs({ EJ_GetNumTiers, EJ_SelectTier, EJ_GetInstanceByIndex, EJ_SelectInstance,
    EJ_GetEncounterInfoByIndex }) do
    if type(fn) ~= "function" then return nil end
  end
  local tiers = call(EJ_GetNumTiers)
  if type(tiers) ~= "number" or ns.isSecret(tiers) then return nil end
  local wanted, other = {}, {}
  for _, n in ipairs(ns.JOURNAL_RAIDS) do wanted[n:lower()] = n end
  local before = type(EJ_GetCurrentTier) == "function" and call(EJ_GetCurrentTier) or nil
  local sections = C_EncounterJournal and C_EncounterJournal.GetSectionInfo
  local out = { tiers = tiers, raids = {} }
  for tier = 1, math.min(tiers, 40) do
    call(EJ_SelectTier, tier)
    for i = 1, 60 do
      local id, name = call(EJ_GetInstanceByIndex, i, true)
      if not id then break end
      name = plain(name)
      local want = name and wanted[name:lower()]
      if want and not out.raids[want] then
        call(EJ_SelectInstance, id)
        local r = { tier = tier, enc = 0 }
        for e = 1, 30 do
          local eName, _, _, root = call(EJ_GetEncounterInfoByIndex, e, id)
          if not plain(eName) then eName, _, _, root = call(EJ_GetEncounterInfoByIndex, e) end
          if not plain(eName) then break end
          r.enc = e
          local info = not r.text and root and type(sections) == "function" and call(sections, root)
          if type(info) == "table" and plain(info.description) then r.text = true end
        end
        out.raids[want] = r
      elseif name and not want and #other < 12 then
        other[#other + 1] = clean(name, 40)
      end
    end
  end
  if type(before) == "number" then call(EJ_SelectTier, before) end
  out.other = #other > 0 and table.concat(other, ",") or nil
  return out
end
local journalRead = false
local function noteJournal()
  if journalRead or InCombatLockdown() or type(UW_GuildDB.client) ~= "table" then return end
  journalRead = true
  UW_GuildDB.client.journal = ns.ProbeJournal() or { none = true }
end
ns.NoteJournal = noteJournal

-- Blizzard's own boss and ability text for our raids, for the raid guides (v1.1 roadmap 13; shape agreed with the
-- guides thread 4 Nov 2026, read by bot/uwbot/encounters.py): UW_GuildDB.encounters = { build, at, diff, truncated,
-- raids = { [raid] = { { name, ej, enc, text, s = { "id\tparent\tspell\ttitle\ttext", ... } } } } }. Sections come
-- depth-first in the journal's order (parent 0 at the top, spell 0 for none), as plain text cut to 300 bytes. Only
-- the raids the probe above found with text. Officers' clients only (the bot reads the Guild Master's save), once per
-- client build, out of combat, never while the journal window is open; the selected tier is put back.
ns.EJ_CAPS = { sections = 80, depth = 6, text = 300, total = 120000 }
-- Cut to n bytes without splitting a UTF-8 character.
local function utf8cut(s, n)
  if #s <= n then return s end
  local cut = n
  while cut > 0 and (s:byte(cut + 1) or 0) >= 0x80 and (s:byte(cut + 1) or 0) < 0xC0 do cut = cut - 1 end
  return s:sub(1, cut)
end
-- Journal text as plain words: no colour, texture, atlas or link codes, no line breaks or tabs.
function ns.EJPlain(s, n)
  if type(s) ~= "string" or ns.isSecret(s) then return "" end
  s = s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", ""):gsub("|A.-|a", "")
    :gsub("|H.-|h(.-)|h", "%1"):gsub("|n", " "):gsub("%$bullet;", "-"):gsub("%c", " "):gsub("|", "/")
    :gsub("%s+", " "):gsub("^ ", ""):gsub(" $", "")
  return utf8cut(s, n or ns.EJ_CAPS.text)
end
local function whole(v) return type(v) == "number" and not ns.isSecret(v) and v == math.floor(v) and v or nil end
local function sectionsOf(root, budget)
  local caps, out, seen = ns.EJ_CAPS, {}, {}
  local function walk(id, parent, depth)
    while whole(id) and id > 0 and not seen[id] do
      if #out >= caps.sections then budget.truncated = true return end
      seen[id] = true
      local info = call(C_EncounterJournal.GetSectionInfo, id)
      if type(info) ~= "table" then return end
      if not info.filteredByDifficulty then -- the journal hides it at this difficulty: so do we, with its children
        local line = ("%d\t%d\t%d\t%s\t%s"):format(id, parent, whole(info.spellID) or 0, ns.EJPlain(info.title, 80),
          ns.EJPlain(info.description))
        if #line > budget.left then budget.truncated = true return end
        budget.left = budget.left - #line
        out[#out + 1] = line
        if depth < caps.depth then walk(info.firstChildSectionID, id, depth + 1) end
      end
      id = info.siblingSectionID
    end
  end
  walk(root, 0, 1)
  return out
end
function ns.ReadEncounters()
  local probe = type(UW_GuildDB.client) == "table" and UW_GuildDB.client.journal
  local sections = C_EncounterJournal and C_EncounterJournal.GetSectionInfo
  if type(probe) ~= "table" or type(probe.raids) ~= "table" or type(sections) ~= "function" then return nil end
  for _, fn in ipairs({ EJ_SelectTier, EJ_GetInstanceByIndex, EJ_SelectInstance, EJ_GetEncounterInfoByIndex }) do
    if type(fn) ~= "function" then return nil end
  end
  local version, build = call(GetBuildInfo)
  local before = type(EJ_GetCurrentTier) == "function" and call(EJ_GetCurrentTier) or nil
  local out = { build = clean(tostring(version or "?") .. "." .. tostring(build or "?"), 40),
    at = GetServerTime and GetServerTime() or time(),
    diff = type(EJ_GetDifficulty) == "function" and whole(call(EJ_GetDifficulty)) or nil, raids = {} }
  local budget = { left = ns.EJ_CAPS.total }
  for _, raid in ipairs(ns.JOURNAL_RAIDS) do
    local r = probe.raids[raid]
    if type(r) == "table" and r.text and whole(r.tier) then
      call(EJ_SelectTier, r.tier)
      local inst
      for i = 1, 60 do
        local id, name = call(EJ_GetInstanceByIndex, i, true)
        if not id then break end
        if plain(name) and name:lower() == raid:lower() then inst = id break end
      end
      if inst then
        call(EJ_SelectInstance, inst)
        local bosses = {}
        for e = 1, 30 do
          local name, desc, ej, root, _, _, enc = call(EJ_GetEncounterInfoByIndex, e, inst)
          if not plain(name) then name, desc, ej, root, _, _, enc = call(EJ_GetEncounterInfoByIndex, e) end
          if not plain(name) then break end
          if whole(ej) then
            bosses[#bosses + 1] = { name = ns.EJPlain(name, 60), ej = ej, enc = whole(enc), text = ns.EJPlain(desc, 400),
              s = sectionsOf(root, budget) }
          end
        end
        if #bosses > 0 then out.raids[raid] = bosses end
      end
    end
  end
  if type(before) == "number" then call(EJ_SelectTier, before) end
  out.truncated = budget.truncated or nil
  return next(out.raids) and out or nil
end
local encountersRead = false
local function noteEncounters()
  if encountersRead or InCombatLockdown() or not ns.isOfficer(ns.me() or "") then return end
  if EncounterJournal and EncounterJournal.IsShown and EncounterJournal:IsShown() then return end -- next login
  encountersRead = true
  local version, build = call(GetBuildInfo)
  local have = UW_GuildDB.encounters
  if type(have) == "table" and have.build == clean(tostring(version or "?") .. "." .. tostring(build or "?"), 40) then
    return -- this build's journal is saved already
  end
  local got = ns.ReadEncounters()
  if got then UW_GuildDB.encounters = got end
end
ns.NoteEncounters = noteEncounters

-- Again once the guild roster is in: by then the world has loaded, so the reset reading is the server's, not an
-- early-login guess (a guildless character keeps the start-up record). The journal is read a little later, out of
-- combat, once a session.
table.insert(ns.onGuildJoin, function()
  ns.afterRoster(function()
    ns.RecordClient()
    C_Timer.After(20, function() ns.protect(noteJournal) end)
    C_Timer.After(30, function() ns.protect(noteEncounters) end) -- after the probe: it reads the raids the probe found
  end)
end)

-- How this client spells this character (Forever names have two parts): UnitName's two values, the roster row with
-- this character's GUID as the roster spells it, and whether UW_Guild found itself in the roster by that row ("guid"),
-- by name only ("name") or not at all ("none": officer tools and the rank check can't work). Every roster read.
function ns.NoteNames(rosterRaw)
  if type(UW_GuildDB) ~= "table" or type(UW_GuildDB.client) ~= "table" then return end
  local n, s = UnitName("player")
  local key = ns.me()
  local match = rosterRaw and "guid" or (key and ns.rankOf[key] ~= nil and "name") or "none"
  local names = { unit = clean((ns.isSecret(n) and "(secret)" or tostring(n)) .. " + " .. (ns.isSecret(s) and "(secret)"
    or tostring(s)), 80), roster = rosterRaw and clean(ns.isSecret(rosterRaw) and "(secret)" or rosterRaw, 64) or nil,
    key = key and clean(key, 64) or nil, match = match, regional = ns.REGIONAL or nil }
  UW_GuildDB.client.names = names
end

-- A system message that reads as a /roll result: the loot rolls' pattern works on this client.
local rollNoted = false
function ns.NoteRollText(msg)
  if rollNoted or type(msg) ~= "string" or ns.isSecret(msg) or type(UW_GuildDB) ~= "table" then return end
  if type(UW_GuildDB.client) ~= "table" or not msg:match(ns.RollPattern()) then return end
  rollNoted = true
  UW_GuildDB.client.roll = time()
end

-- errors, blocked, outdated, deps, and UW_Guild's own errors this session: the counts /uw audit replies carry (an
-- older reader ignores the fifth). Missing game functions aren't in it: every member runs the same client, so the
-- officer's own /uw kit shows those.
function ns.KitTroubleCounts()
  local outdated, deps = notLoading()
  return sum(errorCounts()), sum(blocked), #outdated, #deps, ns.ownErrors or 0
end

-- "3,1,0,2" from an audit reply -> "  issues: 3 errors, 1 blocked, 2 deps" (empty when there are none or it's old).
function ns.TroubleText(field)
  if type(field) ~= "string" or field == "" then return "" end
  local e, b, o, d, u = strsplit(",", field)
  local parts = {}
  for _, p in ipairs({ { e, "errors" }, { b, "blocked" }, { o, "outdated" }, { d, "deps" }, { u, "UW_Guild errors" } }) do
    local n = ns.finite(p[1])
    if n and n > 0 then parts[#parts + 1] = ("%d %s"):format(n, p[2]) end
  end
  return #parts > 0 and ("  |cffff8000issues:|r " .. table.concat(parts, ", ")) or ""
end

local function top(t, max)
  local out = {}
  for i, r in ipairs(sortedCounts(t or {})) do
    if i > (max or 3) then break end
    out[#out + 1] = ("%s %d"):format(r.name, r.n)
  end
  return table.concat(out, ", ")
end

-- The /uw kit lines: nothing when all is well.
function ns.KitTrouble()
  local errs = errorCounts()
  local outdated, deps = notLoading()
  if errs and sum(errs) > 0 then
    ns.say(("|cffff8000Errors this session:|r %d (%s). BugSack shows them."):format(sum(errs), top(errs)))
  elseif not errs then
    ns.say("|cff808080No error catcher:|r install BugSack (it brings BugGrabber) so /uw kit can count errors.")
  end
  if sum(blocked) > 0 then
    ns.say(("|cffff8000Blocked by the game:|r %s. Turn that addon off if buttons stop working."):format(top(blocked)))
  end
  if #outdated > 0 then
    ns.say(("|cffff8000Not loading (no Forever file):|r %s. Get its Forever version, or turn it off."):format(table.concat(outdated, ", ")))
  end
  if #deps > 0 then
    ns.say(("|cffff8000Not loading (needs another addon):|r %s."):format(table.concat(deps, ", ")))
  end
  local own, missing = ns.OwnErrorText(), ns.ClientMissing()
  if own then ns.say("|cffff8000UW_Guild's own errors:|r " .. own .. ". Please send /uw kit report to an officer.") end
  if #missing > 0 then
    local shown = { unpack(missing, 1, math.min(3, #missing)) }
    ns.say(("|cffff8000This client lacks %d game function%s|r (%s%s), so some UW_Guild parts can't work. "
      .. "/uw kit report lists them."):format(#missing, #missing == 1 and "" or "s", table.concat(shown, ", "),
      #missing > 3 and ", …" or ""))
  end
end

-- "2 (Core.lua:120: attempt to index nil; +1 more)": UW_Guild's own errors kept in UW_GuildDB.errors, or nil.
function ns.OwnErrorText()
  local errs = type(UW_GuildDB) == "table" and type(UW_GuildDB.errors) == "table" and UW_GuildDB.errors or {}
  if #errs == 0 then return nil end
  local n, last = 0, errs[#errs]
  for _, e in ipairs(errs) do n = n + (tonumber(e.n) or 1) end
  local msg = tostring(last.msg or "?"):gsub("^.-[Aa]dd[Oo]ns[/\\]UW_Guild[/\\]", ""):sub(1, 90)
  return ("%d (%s%s)"):format(n, msg, #errs > 1 and ("; +%d more"):format(#errs - 1) or "")
end

-- "AutoEquip.lua:118": where UW_Guild's latest own error happened, for the /uw audit reply, so officers see which
-- part fails on members' clients without asking for a report. File and line only (no message, no names), at most 32.
function ns.ErrorSig()
  local errs = type(UW_GuildDB) == "table" and type(UW_GuildDB.errors) == "table" and UW_GuildDB.errors or {}
  local last = errs[#errs]
  if type(last) ~= "table" then return "" end
  local msg = tostring(last.msg or "")
  local at = msg:match("([%w_]+%.lua:%d+)")
  return at and at:sub(1, 32) or "?"
end

-- "OpenMap 2 (last: CastSpellByName)": the addons the game stopped, and what the most-stopped one last tried.
local function blockedText()
  if sum(blocked) == 0 then return "none" end
  local first = sortedCounts(blocked)[1].name
  return top(blocked, 5) .. (blockedFn[first] and (" (last: " .. blockedFn[first] .. ")") or "")
end

-- One line to paste: everything an officer needs to help. It names addons only, never a player.
function ns.KitReportText()
  local missReq, _, conflicts, missRaid = ns.CheckKit()
  local errs = errorCounts()
  local outdated, deps = notLoading()
  local build = GetBuildInfo and select(1, GetBuildInfo()) or "?"
  local fields = {
    ("UW kit report v%s, client %s"):format(ns.VERSION, tostring(build)),
    "missing: " .. (#missReq > 0 and table.concat(missReq, ", ") or "none"),
    "raid: " .. (#missRaid > 0 and table.concat(missRaid, ", ") or "ok"),
    "duplicates: " .. (#conflicts > 0 and table.concat(conflicts, ", ") or "none"),
    "errors: " .. (errs and (sum(errs) > 0 and top(errs, 5) or "none") or "no BugGrabber"),
    "blocked: " .. blockedText(),
    "no Forever file: " .. (#outdated > 0 and table.concat(outdated, ", ") or "none"),
    "needs another addon: " .. (#deps > 0 and table.concat(deps, ", ") or "none"),
    "UW_Guild errors: " .. (ns.OwnErrorText() or "none"),
    "client lacks: " .. (#ns.ClientMissing() > 0 and table.concat(ns.ClientMissing(), ", ") or "nothing"),
  }
  return table.concat(fields, " | ")
end

-- One small box for text that can't go through chat: WoW can't copy chat, but it can copy from an edit box, and chat
-- can't take a line over 255 bytes. Copy mode (no onEnter): the text selected, typing can't change it (the kit report).
-- Paste mode: empty, and Enter hands the text to onEnter (a raid plan code, Plan.lua).
local box
function ns.TextBox(title, hint, text, onEnter)
  if not box then
    local ok, f = pcall(CreateFrame, "Frame", "UW_GuildKitReport", UIParent, "BasicFrameTemplateWithInset")
    if not ok or not f then f = CreateFrame("Frame", "UW_GuildKitReport", UIParent, "BackdropTemplate") end
    f:SetSize(460, 96)
    f:SetPoint("CENTER")
    f:SetFrameStrata("DIALOG")
    tinsert(UISpecialFrames, "UW_GuildKitReport") -- Esc closes it
    ns.SkinWindow(f)
    f.uwTitle = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    f.uwTitle:SetPoint("TOP", 0, -6)
    f.uwHint = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.uwHint:SetPoint("TOPLEFT", 16, -32)
    f.edit = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
    f.edit:SetSize(420, 20)
    f.edit:SetPoint("TOPLEFT", 22, -54)
    f.edit:SetAutoFocus(true)
    f.edit:SetMaxLetters(0) -- no limit: a plan code runs to 4000 bytes
    f.edit:SetScript("OnEditFocusGained", function(self) if not f.onEnter then self:HighlightText() end end)
    f.edit:SetScript("OnTextChanged", function(self, user)
      if user and not f.onEnter then self:SetText(f.text) self:HighlightText() end
    end)
    f.edit:SetScript("OnEnterPressed", function(self)
      local fn = f.onEnter
      if not fn then return end
      local got = self:GetText()
      f:Hide()
      ns.protect(fn, type(got) == "string" and got or "")
    end)
    f.edit:SetScript("OnEscapePressed", function() f:Hide() end)
    ns.Skin("EditBox", f.edit)
    box = f
  end
  box.uwTitle:SetText(title)
  box.uwHint:SetText(hint)
  box.text, box.onEnter = text or "", onEnter
  box.edit:SetText(box.text)
  box:Show()
  box.edit:SetFocus()
  if not onEnter then box.edit:HighlightText() end
  return box
end

function ns.KitReport()
  ns.TextBox("UW addon kit report", "Press Ctrl+C, then paste it into /ask-officers in Discord.", ns.KitReportText())
  ns.say("Report ready: press Ctrl+C, then paste it into /ask-officers in Discord. Not on Discord? Whisper an officer: /uw audit shows them your kit.")
end

local f = CreateFrame("Frame")
-- Only events this client has: on the modern client an unknown event throws and would stop the whole file.
for _, e in ipairs({ "ADDON_ACTION_BLOCKED", "ADDON_ACTION_FORBIDDEN" }) do
  local valid = C_EventUtils and C_EventUtils.IsEventValid
  if not valid or valid(e) then pcall(f.RegisterEvent, f, e) end
end
f:SetScript("OnEvent", function(_, _, addon, fn)
  if type(addon) ~= "string" or addon == "" or ns.isSecret(addon) then return end
  blocked[addon] = (blocked[addon] or 0) + 1
  if type(fn) == "string" and not ns.isSecret(fn) then blockedFn[addon] = fn end
end)
