-- Raid shout-outs: after a guild kill, who healed, shielded, interrupted, dispelled and dealt the most, read from
-- Blizzard's own meter (C_DamageMeter; Forever closes the combat log to addons). The meter is secret during combat,
-- so it is read once combat ends. Anything missing, secret or erroring is left out; nothing readable, no post.
-- Specific, positive recognition of team play, one name per category: not a ranking of the whole raid.
local _, ns = ...

-- Enum.DamageMeterType members (warcraft.wiki.gg), with their numbers in case the enum table isn't exposed.
ns.CHEER_TYPES = {
  { key = "healing", enum = "HealingDone", id = 2 },
  { key = "shields", enum = "Absorbs", id = 4 },
  { key = "interrupts", enum = "Interrupts", id = 5 },
  { key = "dispels", enum = "Dispels", id = 6 },
  { key = "damage", enum = "DamageDone", id = 0 },
}
local CURRENT = 1   -- Enum.DamageMeterSessionType.Current: the fight that just ended, until the next pull
local READ_DELAY = 2 -- seconds after combat ends, so the meter has the last hits

local function meterType(t)
  local e = Enum and Enum.DamageMeterType
  local v = e and e[t.enum]
  if v == nil then v = t.id end
  return v
end

local function session(kind)
  local ok, s = pcall(C_DamageMeter.GetCombatSessionFromType, CURRENT, kind)
  if not ok or type(s) ~= "table" or ns.isSecret(s) then return nil end
  local src = s.combatSources
  if type(src) ~= "table" or ns.isSecret(src) then return nil end
  return src
end

-- The name with the largest amount, skipping anything secret (comparing a secret value is an error).
local function top(kind)
  local best, most
  for _, s in ipairs(session(kind) or {}) do
    local amount, name = s.totalAmount, s.name
    if not ns.isSecret(amount) and not ns.isSecret(name) and type(amount) == "number" and amount > 0
        and type(name) == "string" and name ~= "" and (not most or amount > most) then
      best, most = name, amount
    end
  end
  return best
end

local function display(name)
  local full = ns.fullName(name)
  return ((full and ns.shortName(full) or name):gsub("[\t;=\"\\]", ""))
end

function ns.ReadCheers(boss)
  if not (C_DamageMeter and C_DamageMeter.GetCombatSessionFromType) then return end
  local parts = {}
  for _, t in ipairs(ns.CHEER_TYPES) do
    local name = top(meterType(t))
    if name then parts[#parts + 1] = t.key .. "=" .. display(name) end
  end
  if #parts == 0 then return end
  local deaths = Enum and Enum.DamageMeterType and Enum.DamageMeterType.Deaths
  local dead = deaths and session(deaths)
  if dead and #dead == 0 then parts[#parts + 1] = "nodeaths" end
  ns.queue("cheers", boss, table.concat(parts, ";"))
end

-- Pull notes for the morning-after debrief (v1.1 roadmap 12): after every guild raid pull, kill or wipe, which spells
-- killed people and which avoidable spells hit how many. Group counts per spell only: no names, no per-person numbers
-- (Louis, 4 Nov 20:44). A debrief that looks at what happened lifts team results about 25% (Tannenbaum & Cerasoli
-- 2013). One line per pull in UW_GuildDB.pulls, read by the bot (bot/uwbot/pulls.py):
-- time<TAB>encounterID<TAB>boss<TAB>difficultyID<TAB>size<TAB>kill 1|0<TAB>deaths<TAB>killers<TAB>avoidable
-- killers and avoidable: "spellID:players:Name,..." with the most first, at most PULL_SPELLS each.
ns.MAX_PULLS = 300           -- about 10 raid nights of 30 pulls
local PULL_SPELLS = 6
local DEATHS, AVOIDABLE = 9, 8   -- Enum.DamageMeterType.Deaths and .AvoidableDamageTaken (12.0.1)

local function num(v) if type(v) == "number" and not ns.isSecret(v) then return v end end

local function sourceSpells(kind, guid)
  local ok, s = pcall(C_DamageMeter.GetCombatSessionSourceFromType, CURRENT, kind, guid)
  if not ok or type(s) ~= "table" or ns.isSecret(s) or type(s.combatSpells) ~= "table" or ns.isSecret(s.combatSpells) then
    return {}
  end
  return s.combatSpells
end

local function spellName(id)
  local get = C_Spell and C_Spell.GetSpellName
  local ok, name = get ~= nil, nil
  if get then ok, name = pcall(get, id) end
  if not ok or type(name) ~= "string" or ns.isSecret(name) then return "" end
  return (name:gsub("[%c,:;=|\\\"]", "")):sub(1, 40)
end

-- The killing blow: the spell the meter marks deadly, else the one that hit hardest.
local function killer(spells)
  local best, most
  for _, sp in ipairs(spells) do
    local id, amount, deadly = num(sp.spellID), num(sp.totalAmount), sp.isDeadly
    if id and id > 0 then
      if not ns.isSecret(deadly) and deadly == true then return { [id] = true } end
      if amount and (not most or amount > most) then best, most = id, amount end
    end
  end
  return best and { [best] = true } or {}
end
local function avoidable(spells)
  local out = {}
  for _, sp in ipairs(spells) do
    local id, amount = num(sp.spellID), num(sp.totalAmount)
    if id and id > 0 and amount and amount > 0 then out[id] = true end
  end
  return out
end

-- Per spell, how many players it touched (each player once per spell).
local function tally(kind, pick)
  local count, ids = {}, {}
  for _, src in ipairs(session(kind) or {}) do
    local guid = src.sourceGUID
    if type(guid) == "string" and not ns.isSecret(guid) then
      for id in pairs(pick(sourceSpells(kind, guid))) do
        if not count[id] then ids[#ids + 1] = id end
        count[id] = (count[id] or 0) + 1
      end
    end
  end
  table.sort(ids, function(a, b) if count[a] ~= count[b] then return count[a] > count[b] end return a < b end)
  local out = {}
  for i = 1, math.min(#ids, PULL_SPELLS) do out[i] = ("%d:%d:%s"):format(ids[i], count[ids[i]], spellName(ids[i])) end
  return table.concat(out, ",")
end

function ns.ReadPull(p)
  if not (C_DamageMeter and C_DamageMeter.GetCombatSessionFromType and C_DamageMeter.GetCombatSessionSourceFromType) then
    return
  end
  local dead = session(DEATHS)
  if not dead then return end    -- nothing readable: no note (an empty list is a clean pull)
  local killers, avoid = tally(DEATHS, killer), tally(AVOIDABLE, avoidable)
  local pulls = UW_GuildDB.pulls or {}
  UW_GuildDB.pulls = pulls
  pulls[#pulls + 1] = table.concat({ p.at, p.enc, (p.boss:gsub("[%c\t\"\\]", "")), p.diff, p.size, p.kill and 1 or 0,
    #dead, killers, avoid }, "\t")
  while #pulls > ns.MAX_PULLS do table.remove(pulls, 1) end
end

-- Read once combat ends: the meter is secret in combat. A kill's shout-outs and its pull note read the same session.
local pending, pull
local function flush()
  local boss, p = pending, pull
  pending, pull = nil, nil
  if boss then
    local ok, err = pcall(ns.ReadCheers, boss)
    if not ok then ns.say("Couldn't read the meter for shout-outs (" .. tostring(err) .. ").") end
  end
  if p then ns.protect(ns.ReadPull, p) end
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_REGEN_ENABLED")
f:RegisterEvent("ENCOUNTER_END")
f:SetScript("OnEvent", ns.guard(function(_, event, encounterID, boss, difficultyID, groupSize, success)
  if event == "ENCOUNTER_END" then
    if ns.isSecret(boss) or type(boss) ~= "string" or ns.isSecret(success) or not IsInRaid()
        or not ns.tracksGuild() or ns.guildRaidShare() < 0.5 then return end
    pull = { at = (GetServerTime and GetServerTime()) or time(), enc = num(encounterID) or 0, boss = boss,
      diff = num(difficultyID) or 0, size = num(groupSize) or GetNumGroupMembers(), kill = success == 1 }
    if not InCombatLockdown() then ns.after(READ_DELAY, flush) end
  elseif pending or pull then
    ns.after(READ_DELAY, flush)
  end
end))

ns.onGuildKill[#ns.onGuildKill + 1] = function(boss)
  pending = boss
  if not InCombatLockdown() then ns.after(READ_DELAY, flush) end
end
