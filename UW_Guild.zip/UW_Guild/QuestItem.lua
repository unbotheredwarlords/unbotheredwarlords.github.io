-- Space uses a quest item on the quest target (Louis, 5 Nov 2026: "a popup for space to use quest item on the target
-- right in front of you, like the lazy peon quest in Durotar, and all similar quests").
--
-- When the target (or the soft target the game picks in front of you) is part of a quest you carry an item for, and
-- the item is in range, a small button shows the item and Space uses it on that unit. Otherwise Space jumps as always.
--   * Item and unit must belong together: the unit's tooltip names the item's quest. An item the game links to no
--     quest (Forever's older quests, like the Blackjack) counts only for a living quest unit its own tooltip names
--     ("hit a lazy peon" -> Lazy Peon), so a Vile Familiar never gets it. A finished quest's item is left alone.
--   * Out of combat only. Using an item takes a secure button, and the game freezes key bindings in combat, so one key
--     can't switch between "use" and "jump" mid-fight; a secure state driver clears ours the moment combat starts.
--   * Shift+Space (Louis, 5 Nov: "maybe shift space for addon then?") works in a fight too: it always holds one quest
--     item (your target's, else the first in your quest log), bound while you carry one. Its item is picked out of
--     combat and stays fixed during a fight. Shift+Space normally jumps like Space; with no quest item it still does.
--   * Only while standing on the ground, so running up to a quest NPC or spamming jump still jumps. After a press
--     Space jumps for 2 seconds; a unit the item worked on (the game's cast succeeded) is skipped for a minute (a woken
--     peon stays a quest NPC), and a failed use just comes back.
--   * Other addons come first: any override already on Space (DialogueUI's buttons, EllesmereUI's quest item hotkey)
--     wins, ours is non-priority, and nothing arms while a quest or gossip window is open.
-- /uw space off turns it off for the account (UW_GuildDB.spaceItem = false).
local _, ns = ...
local say = ns.say

ns.SPACE_KEY = "SPACE"
ns.SHIFT_SPACE_KEY = "SHIFT-SPACE"
ns.SPACE_USED_SECONDS = 60
ns.SPACE_PAUSE_SECONDS = 2
local UNITS = { "target", "softinteract", "softfriend", "softenemy" } -- explicit target first
local QUEST_TITLE, QUEST_OBJECTIVE = 17, 8 -- Enum.TooltipDataLineType

local function call(fn, ...)
  if not fn then return nil end
  local ok, a, b, c, d = pcall(fn, ...)
  if ok then return a, b, c, d end
end
local function g(name) return rawget(_G, name) end
local function idOf(link) return type(link) == "string" and tonumber(link:match("item:(%d+)")) or nil end
local function enabled() return UW_GuildDB and UW_GuildDB.spaceItem ~= false end

local talking = false -- a quest or gossip window is open: Space belongs to it (DialogueUI's Confirm key)
local used = {}       -- unit GUID -> time used
local armed           -- { id, unit, guid } while Space is ours
local items           -- cached quest items: { id, quest (title or nil), name, spell }
local pausedUntil = 0 -- after a press, Space jumps for a moment
local MINE = "UW_GuildQuestItemButton"

-- Quest items the player carries: the quest log's item buttons, and bag items the game ties to an active quest.
local function questItems()
  if items then return items end
  items = {}
  local seen = {}
  local ql = g("C_QuestLog")
  local function add(id, title)
    if id and not seen[id] then
      seen[id] = true
      local name = call(C_Item and C_Item.GetItemNameByID, id) or ("item " .. id)
      local _, spell = call(C_Item and C_Item.GetItemSpell, id)
      items[#items + 1] = { id = id, quest = title, name = name, spell = spell }
    end
  end
  local n = ql and call(ql.GetNumQuestLogEntries) or 0
  for i = 1, tonumber(n) or 0 do
    local info = call(ql.GetInfo, i)
    if type(info) == "table" and not info.isHeader then
      local link, _, _, showWhenComplete = call(g("GetQuestLogSpecialItemInfo"), i)
      local done = info.questID and call(ql.IsComplete, info.questID)
      if link and (not done or showWhenComplete) then add(idOf(link), info.title) end
    end
  end
  local c = g("C_Container")
  for bag = 0, (g("NUM_BAG_SLOTS") or 4) do
    for slot = 1, (c and call(c.GetContainerNumSlots, bag) or 0) do
      local q = call(c.GetContainerItemQuestInfo, bag, slot)
      local info = call(c.GetContainerItemInfo, bag, slot)
      local id = type(info) == "table" and info.itemID
      -- The game's quest flag, or the Quest item class (12) for items it doesn't flag.
      local quest = type(q) == "table" and q.isQuestItem
      if not quest and id then quest = select(6, call(C_Item and C_Item.GetItemInfoInstant, id)) == 12 end
      q = type(q) == "table" and q or {}
      if quest and (q.questID == nil or q.isActive) then
        local usable = id and call(C_Item and C_Item.GetItemSpell, id)
        local done = q.questID and ql and call(ql.IsComplete, q.questID)
        if usable and not done then
          add(id, q.questID and ql and call(ql.GetTitleForQuestID, q.questID) or nil)
        end
      end
    end
  end
  return items
end

-- The quest titles and objectives on a unit's tooltip; nil when it shows none (not a quest unit).
local function questLines(unit)
  local tip = g("C_TooltipInfo")
  local data = tip and call(tip.GetUnit, unit)
  if type(data) ~= "table" or type(data.lines) ~= "table" then return nil end
  local titles, any = {}, false
  for _, l in ipairs(data.lines) do
    local t = l.leftText
    if (l.type == QUEST_TITLE or l.type == QUEST_OBJECTIVE) and type(t) == "string" and not ns.isSecret(t) then
      any = true
      if l.type == QUEST_TITLE then titles[t] = true end
    end
  end
  return any and titles or nil
end

-- An unlinked item's own text ("Use: Hit a lazy peon ...") names its target: a word of the unit's name of 4+ letters.
local function itemNames(it, unit)
  if it.text == nil then
    local tip = g("C_TooltipInfo")
    local data = tip and call(tip.GetItemByID, it.id)
    local out = {}
    for i, l in ipairs(type(data) == "table" and type(data.lines) == "table" and data.lines or {}) do
      if i > 1 and type(l.leftText) == "string" and not ns.isSecret(l.leftText) then out[#out + 1] = l.leftText end
    end
    local spell = call(C_Item and C_Item.GetItemSpell, it.id)
    if type(spell) == "string" and not ns.isSecret(spell) then out[#out + 1] = spell end
    it.text = table.concat(out, " "):lower()
  end
  local name = call(g("UnitName"), unit)
  if type(name) ~= "string" or ns.isSecret(name) or it.text == "" then return false end
  for word in name:lower():gmatch("%a+") do
    -- "peon" also finds "peons"; a plural unit name ("Lazy Peons") finds "peon" by its stem.
    if #word >= 4 and (it.text:find(word, 1, true) or it.text:find(word:gsub("s$", ""), 1, true)) then return true end
  end
  return false
end
ns.QuestItemNames = itemNames

local function inRange(id, unit)
  local r = call(C_Item and C_Item.IsItemInRange, id, unit)
  if r == nil then r = call(g("CheckInteractDistance"), unit, 3) end -- items with no range data: within 10 yards
  return r == true or r == 1
end

-- In dungeons the game hides some numbers and unit IDs as secret values; comparing or indexing one throws (Louis's client,
-- 7 Nov 2026: 1,138 errors from a dungeon). An unreadable value counts as "not now", so Space keeps jumping there.
local function plain(v) return type(v) == "number" and not ns.isSecret(v) and v or nil end
local function ready(id)
  local start, duration = call(C_Container and C_Container.GetItemCooldown, id)
  if ns.isSecret(duration) then return false end      -- no ~= or == on a secret: issecretvalue() is the safe test
  start, duration = plain(start) or 0, plain(duration)
  return not (duration and duration > 1.5 and start + duration > GetTime())
end

local function moving()
  local speed = call(g("GetUnitSpeed"), "player")
  if ns.isSecret(speed) then return true end
  return (speed or 0) > 0 or call(g("IsFalling")) == true
end

-- What a key does with overrides: ours, someone else's ("taken"), or nothing extra.
local SHIFT_MINE = "UW_GuildQuestItemShiftButton"
local function keyOverride(key, mine)
  local get = g("GetBindingAction")
  if not get then return nil end
  local over, base = call(get, key, true) or "", call(get, key) or ""
  if over:find(mine, 1, true) then return "mine" end
  if over ~= base then return "taken" end                 -- another addon's override
  if base == "" or base == "JUMP" then return nil end     -- free: unbound, or the usual jump
  return "taken"                                          -- the player bound it to something in Key Bindings
end
-- The player's own Key Bindings use the key for something other than jumping: never override that.
local function playerBound(key)
  local base = call(g("GetBindingAction"), key) or ""
  return base ~= "" and base ~= "JUMP"
end
local function spaceOverride() return keyOverride(ns.SPACE_KEY, MINE) end
local function spaceTaken() return spaceOverride() == "taken" end

-- The item to use and the unit to use it on, or nil.
function ns.FindQuestItemUse()
  local list = questItems()
  if #list == 0 then return nil end
  if moving() or GetTime() < pausedUntil then return nil end
  for _, unit in ipairs(UNITS) do
    if call(g("UnitExists"), unit) and not call(g("UnitIsDead"), unit) then
      local guid = call(g("UnitGUID"), unit)
      local when = guid and not ns.isSecret(guid) and used[guid]
      local titles = not ns.isSecret(guid) and not (when and GetTime() - when < ns.SPACE_USED_SECONDS) and questLines(unit)
      if titles then
        for _, it in ipairs(list) do
          local belongs = (it.quest and titles[it.quest]) or (not it.quest and itemNames(it, unit))
          if belongs and inRange(it.id, unit) and ready(it.id) then return it, unit, guid end
        end
      end
    end
  end
end

-- The popup: a secure item button under a secure header that owns the binding. The header's state driver clears the
-- binding and hides both when combat starts, inside the game's own secure code.
local header, button, label
local function build()
  if header then return true end
  if not (g("SetOverrideBindingClick") and g("ClearOverrideBindings")) then return false end
  header = CreateFrame("Frame", nil, UIParent, "SecureHandlerStateTemplate")
  header:SetSize(1, 1)
  header:SetPoint("CENTER", UIParent, "CENTER", 0, -160)
  header:SetAttribute("_onstate-uwcombat", [[ if newstate == "on" then self:ClearBindings() self:Hide() end ]])
  local driver = g("RegisterStateDriver")
  if driver then pcall(driver, header, "uwcombat", "[combat] on; off") end
  button = CreateFrame("Button", MINE, header, "SecureActionButtonTemplate")
  button:SetSize(40, 40)
  button:SetPoint("CENTER", header, "CENTER", -70, 0)
  button:RegisterForClicks("AnyUp", "AnyDown")
  button:SetAttribute("type", "item")
  button.icon = button:CreateTexture(nil, "ARTWORK")
  button.icon:SetAllPoints()
  label = button:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  label:SetPoint("LEFT", button, "RIGHT", 8, 0)
  ns.Skin("Font", label)
  button:HookScript("PostClick", function() ns.protect(ns.QuestItemPressed) end)
  header:Hide()
  return true
end

-- Clears ours when armed, or when a binding of ours outlived its state (cleared in combat by the driver, say).
-- Not on every tick otherwise: each clear fires UPDATE_BINDINGS for every addon.
local function disarm()
  local was = armed
  armed = nil
  if header and not InCombatLockdown() and (was or spaceOverride() == "mine") then
    pcall(ClearOverrideBindings, header)
    pcall(header.Hide, header)
  end
end

local function tellFirst()
  if UW_GuildDB.spaceTold then return end
  if ns.TellNew("Space uses your quest item on a quest target in range; Shift+Space works in fights too. "
    .. "/uw space off stops it.", true) then UW_GuildDB.spaceTold = time() end
end

local function arm(it, unit, guid)
  local held = spaceOverride()
  if held == "taken" or playerBound(ns.SPACE_KEY) then
    if held == "mine" then disarm() end
    return
  end
  -- Already set (and not let go by the combat driver in the meantime).
  if armed and armed.id == it.id and armed.unit == unit and armed.guid == guid and held == "mine" then return end
  if not build() then return end
  button:SetAttribute("item", "item:" .. it.id)
  button:SetAttribute("unit", unit)
  button.icon:SetTexture(call(C_Item and C_Item.GetItemIconByID, it.id))
  label:SetText(("|cffffd100Space|r  %s"):format(it.name))
  pcall(ClearOverrideBindings, header)
  pcall(SetOverrideBindingClick, header, false, ns.SPACE_KEY, MINE, "LeftButton")
  header:Show()
  armed = { id = it.id, unit = unit, guid = guid }
  tellFirst()
end

-- Shift+Space: a hidden secure item button, bound while there is a quest item to hold. Out of combat only, like any
-- binding or secure attribute; whatever it holds when a fight starts is what it uses in that fight.
local shiftOwner, shiftButton, shiftHeld
local function shiftOn() return enabled() and UW_GuildDB.spaceShift ~= false end
local function shiftPick(list)
  if call(g("UnitExists"), "target") and not call(g("UnitIsDead"), "target") then
    local titles = questLines("target")
    for _, it in ipairs(titles and list or {}) do
      if (it.quest and titles[it.quest]) or (not it.quest and itemNames(it, "target")) then return it end
    end
  end
  return list[1]
end
local function updateShift()
  local it = shiftOn() and shiftPick(questItems()) or nil
  local held = keyOverride(ns.SHIFT_SPACE_KEY, SHIFT_MINE)
  if not it or held == "taken" or playerBound(ns.SHIFT_SPACE_KEY) then
    if shiftOwner and (shiftHeld or held == "mine") then pcall(ClearOverrideBindings, shiftOwner) end
    shiftHeld = nil
    return
  end
  if not (g("SetOverrideBindingClick") and g("ClearOverrideBindings")) then return end
  if not shiftOwner then
    shiftOwner = CreateFrame("Frame")
    shiftButton = CreateFrame("Button", SHIFT_MINE, UIParent, "SecureActionButtonTemplate")
    shiftButton:RegisterForClicks("AnyUp", "AnyDown")
    shiftButton:SetAttribute("type", "item")
    shiftButton:Hide()
  end
  if shiftHeld ~= it.id then shiftButton:SetAttribute("item", "item:" .. it.id) end
  if held ~= "mine" then
    pcall(SetOverrideBindingClick, shiftOwner, false, ns.SHIFT_SPACE_KEY, SHIFT_MINE, "LeftButton")
  end
  shiftHeld = it.id
end
function ns.QuestItemShift() return shiftHeld end

local ticker
function ns.QuestItemCheck()
  if InCombatLockdown() then return end
  ns.protect(updateShift)
  local npc = g("C_PlayerInteractionManager")
  if npc and npc.IsInteractingWithNpc then talking = call(npc.IsInteractingWithNpc) == true end
  if not enabled() or talking then disarm() return end
  local it, unit, guid = ns.FindQuestItemUse()
  if it then arm(it, unit, guid) else disarm() end
  -- Range and movement change without an event: look again four times a second while a quest unit is around.
  local watch = #questItems() > 0 and call(g("UnitExists"), "target") or call(g("UnitExists"), "softinteract")
  if watch and not ticker then
    ticker = C_Timer.NewTicker(0.25, function() ns.protect(ns.QuestItemCheck) end)
  elseif not watch and ticker then
    ticker:Cancel()
    ticker = nil
  end
end

-- After a press Space jumps for a moment (spamming jump stays jumping); the unit is skipped once the use worked.
local last -- { guid, spell } of the latest press
function ns.QuestItemPressed()
  if armed then last = { guid = armed.guid, spell = nil } end
  for _, it in ipairs(items or {}) do if armed and it.id == armed.id then last.spell = it.spell end end
  pausedUntil = GetTime() + ns.SPACE_PAUSE_SECONDS
  disarm()
  ns.after(ns.SPACE_PAUSE_SECONDS + 0.1, function() ns.protect(ns.QuestItemCheck) end)
end
function ns.QuestItemCast(spellID)
  if last and last.guid and (last.spell == nil or last.spell == spellID) then used[last.guid] = GetTime(); last = nil end
end

function ns.QuestItemArmed() return armed end

-- /uw space why: what it sees right now, for testing on a real quest.
local function why()
  items = nil
  local list = questItems()
  local names = {}
  for _, it in ipairs(list) do names[#names + 1] = it.name .. (it.quest and (" (" .. it.quest .. ")") or "") end
  say("Quest items: " .. (#names > 0 and table.concat(names, ", ") or "none"))
  for _, unit in ipairs(UNITS) do
    if call(g("UnitExists"), unit) then
      local titles = questLines(unit)
      local t = {}
      for k in pairs(titles or {}) do t[#t + 1] = k end
      local range = {}
      for _, it in ipairs(list) do
        range[#range + 1] = ("%s=%s%s"):format(it.name, tostring(call(C_Item and C_Item.IsItemInRange, it.id, unit)),
          (not it.quest and not itemNames(it, unit)) and " (not named)" or "")
      end
      say(("%s %s: quest %s%s; range %s"):format(unit, tostring(call(g("UnitName"), unit)),
        titles and "yes" or "no", #t > 0 and (" [" .. table.concat(t, ", ") .. "]") or "", table.concat(range, ", ")))
    end
  end
  for _, it in ipairs(list) do
    if not it.quest and it.text then say(("%s text: %s"):format(it.name, it.text:sub(1, 120))) end
  end
  say(("Armed: %s. Shift+Space: %s. Moving: %s. Talking: %s. Space taken: %s. Shift+Space taken: %s."):format(
    armed and armed.unit or "no", tostring(shiftHeld or "none"), tostring(moving()), tostring(talking),
    tostring(spaceTaken() or playerBound(ns.SPACE_KEY)),
    tostring(keyOverride(ns.SHIFT_SPACE_KEY, SHIFT_MINE) == "taken" or playerBound(ns.SHIFT_SPACE_KEY))))
end

ns.commands.space = function(args)
  local sub = strtrim(args or ""):lower()
  if sub == "off" then
    UW_GuildDB.spaceItem = false
    disarm()
    ns.protect(ns.QuestItemCheck)
    say("Space for quest items is off. /uw space on turns it back on.")
  elseif sub == "on" then
    UW_GuildDB.spaceItem = nil
    say("Space for quest items is on: Space next to a quest target, Shift+Space in fights too.")
    ns.protect(ns.QuestItemCheck)
  elseif sub == "shift off" or sub == "shift on" then
    if sub == "shift off" then UW_GuildDB.spaceShift = false else UW_GuildDB.spaceShift = nil end
    ns.protect(ns.QuestItemCheck)
    say(sub == "shift off" and "Shift+Space jumps again. /uw space shift on brings the quest item back."
      or "Shift+Space uses your quest item, in fights too.")
  elseif sub == "why" then
    why()
  else
    say(("Space for quest items is %s. /uw space on, off, shift off, or why."):format(enabled() and "on" or "off"))
  end
end

local f = CreateFrame("Frame")
local TALK = { GOSSIP_SHOW = true, QUEST_GREETING = true, QUEST_DETAIL = true, QUEST_PROGRESS = true,
  QUEST_COMPLETE = true }
local DONE_TALKING = { GOSSIP_CLOSED = true, QUEST_FINISHED = true }
ns.listen(f, { "PLAYER_TARGET_CHANGED", "PLAYER_SOFT_INTERACT_CHANGED", "PLAYER_SOFT_FRIEND_CHANGED",
  "PLAYER_SOFT_ENEMY_CHANGED", "PLAYER_STARTED_MOVING", "PLAYER_STOPPED_MOVING", "BAG_UPDATE_DELAYED",
  "QUEST_LOG_UPDATE", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "GOSSIP_SHOW", "GOSSIP_CLOSED",
  "QUEST_GREETING", "QUEST_DETAIL", "QUEST_PROGRESS", "QUEST_COMPLETE", "QUEST_FINISHED", "UNIT_SPELLCAST_SUCCEEDED" })
f:SetScript("OnEvent", ns.guard(function(_, event, a, _, c)
  if not UW_GuildDB then return end
  if event == "UNIT_SPELLCAST_SUCCEEDED" then
    if a == "player" then ns.protect(ns.QuestItemCast, c) end
    return
  end
  -- Bindings can still change while this event runs; the state driver covers the rest.
  if event == "PLAYER_REGEN_DISABLED" then disarm() return end
  if event == "BAG_UPDATE_DELAYED" or event == "QUEST_LOG_UPDATE" then items = nil end
  if TALK[event] then talking = true end
  if DONE_TALKING[event] then talking = false end
  ns.protect(ns.QuestItemCheck)
end))
