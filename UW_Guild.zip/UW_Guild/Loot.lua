-- Main spec before off spec, with rolls only (no points, no gold: GDKP is banned on Forever).
--
-- Whoever hands out an item (a Raider or officer leading or assisting, or anyone outside a group to try it) types
-- /uw loot <shift-click the item>. Everyone rolls: /roll (1-100) for main spec, /roll 99 for off spec.
-- After LOOT_SECONDS: main-spec rolls beat off-spec rolls. Among main-spec rolls, regular raiders go first, then
-- whoever has won fewer main-spec items since the weekly reset (the "+1" rule, so upgrades spread out), then the
-- highest roll.
-- A tie rolls again among the tied players. Every award is announced with its reason, mirrored to the other
-- UW_Guild clients in the group, shared with the rest of the guild (Raid.lua), queued for #loot-log, and can be
-- undone (/uw loot undo).
--
-- Why this shape: loot fights are a leading cause of guild breakups (Williams et al. 2006), points systems carry
-- bookkeeping a small guild doesn't need (Castronova & Fairfield 2006; Malone 2009), and people accept outcomes
-- they didn't want when the rule is consistent, public, explained and correctable (Leventhal 1980). Forever's own
-- round-robin for quest drops follows the same "spread it out" idea.
local _, ns = ...

ns.LOOT_SECONDS = 20
ns.MS_MAX, ns.OS_MAX = 100, 99
local TIER_LABEL = { ms = "main spec", os = "off spec" }

-- "%s rolls %d (%d-%d)" -> a Lua pattern capturing name, roll, low, high.
function ns.RollPattern(fmt)
  fmt = fmt or RANDOM_ROLL_RESULT or "%s rolls %d (%d-%d)"
  local p = fmt:gsub("([%(%)%.%+%-%*%?%[%]%^%$])", "%%%1")
  p = p:gsub("%%s", "(.+)"):gsub("%%d", "(%%d+)")
  return "^" .. p .. "$"
end

local function serverNow() return (GetServerTime and GetServerTime()) or time() end

-- Weekly ledger of main-spec wins: plus counts this week's, cleared when the weekly reset passes. Awards (undone
-- ones stay too, with `undone` = when) are kept LOOT_KEEP_DAYS, so a guildmate who logs in after the reset still
-- hears last week's raid (Raid.lua); only wins since the reset count toward the +1 rule.
ns.LOOT_KEEP_DAYS = 8
local function ledger()
  local db = UW_GuildDB.loot
  if type(db) ~= "table" then db = {}; UW_GuildDB.loot = db end
  db.plus, db.awards = db.plus or {}, db.awards or {}
  local now = time()
  local reset = ns.lastWeeklyReset and ns.lastWeeklyReset(now)
  if reset and (not db.week or reset - db.week > 3600) then -- the reset drifts by seconds between logins
    db.week, db.plus = reset, {}
    local keep, cutoff = {}, serverNow() - ns.LOOT_KEEP_DAYS * 86400
    for _, a in ipairs(db.awards) do
      if (a.at or 0) >= cutoff then a.plus = nil; keep[#keep + 1] = a end -- last week's wins no longer count
    end
    db.awards = keep
  end
  return db
end
ns.lootLedger = ledger
-- An award made after the reset (a few minutes' slack for clocks). Awards heard in the group are happening now
-- and always count; one heard later from the guild counts only if it was made this week.
local function thisWeek(db, at) return not db.week or at >= db.week - 300 end

-- Regular raiders: came to at least half of the guild raid nights in the last 4 weeks (the ones this client saw,
-- plus the ones Raiders and officers shared with the guild, Raid.lua), counting
-- only nights since they joined (a new member isn't measured against raids from before they arrived). A night
-- starts at 12:00 UTC, as in the bot. Fewer than 2 nights since they joined (or no data) counts as regular, so one
-- missed night never marks a newcomer down: attendance gives priority, never a lockout.
ns.REGULAR_DAYS = 28
function ns.RegularRaiders(names, now)
  local nights, seen = {}, {}
  for _, line in ipairs(UW_GuildDB.attendance or {}) do
    local t, _, _, _, _, who = strsplit("\t", line)
    t = tonumber(t)
    if t and t >= now - ns.REGULAR_DAYS * 86400 then
      local night = math.floor((t - 12 * 3600) / 86400)
      nights[night] = true
      for n in (who or ""):gmatch("[^,]+") do seen[n .. "@" .. night] = true end
    end
  end
  local out = {}
  for _, name in ipairs(names) do
    local m = UW_GuildDB.members and UW_GuildDB.members[name]
    local since = math.floor((((m and m.first) or 0) - 12 * 3600) / 86400)
    local total, came = 0, 0
    for night in pairs(nights) do
      if night >= since then
        total = total + 1
        if seen[name .. "@" .. night] then came = came + 1 end
      end
    end
    out[name] = total < 2 or came * 2 >= total
  end
  return out
end

-- Pure decision, so it is unit-tested. rolls[name] = { tier = "ms"|"os", roll = n }; plus[name] = wins this week;
-- regular[name] = false for members below the attendance bar (nil table or entry: regular).
-- Main spec always beats off spec. Among main-spec rolls: regular attendance first, then fewer wins this week, then
-- the roll. Returns winner, tier, roll, plusBefore, tied (names sharing the top spot; > 1 means roll again), and
-- whether attendance decided it (a regular beat a higher-ranked non-regular on the other keys).
function ns.LootWinner(rolls, plus, regular)
  regular = regular or {}
  for _, tier in ipairs({ "ms", "os" }) do
    local c = {}
    for name, r in pairs(rolls) do
      if r.tier == tier then
        c[#c + 1] = { name = name, roll = r.roll, plus = tier == "ms" and (plus[name] or 0) or 0,
          reg = tier == "os" or regular[name] ~= false }
      end
    end
    if #c > 0 then
      table.sort(c, function(a, b)
        if a.reg ~= b.reg then return a.reg end
        if a.plus ~= b.plus then return a.plus < b.plus end
        if a.roll ~= b.roll then return a.roll > b.roll end
        return a.name < b.name
      end)
      local top, tied, byAttendance = c[1], {}, false
      for _, x in ipairs(c) do
        if x.reg == top.reg and x.plus == top.plus and x.roll == top.roll then tied[#tied + 1] = x.name end
        if not x.reg and (x.plus < top.plus or (x.plus == top.plus and x.roll > top.roll)) then byAttendance = true end
      end
      return top.name, tier, top.roll, top.plus, tied, byAttendance
    end
  end
end

local function groupChannel()
  if IsInRaid() then return "RAID" end
  if IsInGroup() then return "PARTY" end
end

-- Say it to the group when allowed, otherwise only to yourself (and say so once).
local function announce(msg)
  local ch = groupChannel()
  local blocked = InCombatLockdown() or (C_ChatInfo.InChatMessagingLockdown and C_ChatInfo.InChatMessagingLockdown())
  local sendChat = (C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage
  if ch and not blocked and sendChat and pcall(sendChat, msg, ch) then return end
  ns.say(msg)
end

-- Item names are capped so a LOOT message stays under the 255-byte addon-message limit (a long free-text
-- "/uw loot <anything>" was silently never mirrored); a cut never leaves half a UTF-8 character.
ns.ITEM_MAX = 80
local function itemName(link)
  local name = (link:match("%[(.-)%]") or link):gsub("[\t;\"\\]", "")
  if #name > ns.ITEM_MAX then name = name:sub(1, ns.ITEM_MAX):gsub("[\192-\255][\128-\191]*$", "") end
  return name
end

local function canLead()
  if not IsInGroup() then return true end -- solo: a dry run that only prints
  return UnitIsGroupLeader("player") or UnitIsGroupAssistant("player")
end

local session -- { link, rolls, only, token }
local lastToken = 0 -- never reused, so a finished roll's timer can't end the next roll early
local last    -- the last award: { link, rolls, at, winner }, so the leader can still make the call (/uw loot give)
ns.GIVE_WINDOW = 120
-- Awards are keyed by their realm time and winner on every client, so this client never stamps two in one second.
local lastAwardAt = 0
local function awardTime()
  lastAwardAt = math.max(serverNow(), lastAwardAt + 1)
  return lastAwardAt
end

-- An award this client hands out: for the guild when this character may share raid records (Raider and up).
local function handOut(link, winner, tier, roll, at, reason)
  local a = ns.RecordAward(link, winner, tier, roll, at, reason, nil, not ns.canShareRaid(ns.me()))
  if a then a.own = true end -- handed out here: /uw loot undo may take it back
  return a
end

local function finish(token)
  local s = session
  if not s or s.token ~= token then return end
  session = nil
  local db = ledger()
  local names = {}
  for n in pairs(s.rolls) do names[#names + 1] = n end
  local winner, tier, roll, plusBefore, tied, byAttendance = ns.LootWinner(s.rolls, db.plus, ns.RegularRaiders(names, time()))
  if not winner then announce(("UW loot: no rolls for %s. It goes to whoever the leader picks."):format(s.link)) return end
  if #tied > 1 then
    announce(("UW loot: tie on %s (%s). %s, roll again."):format(s.link, TIER_LABEL[tier], table.concat(tied, ", ")))
    ns.StartLoot(s.link, tied)
    return
  end
  local why = tier == "ms" and (plusBefore == 0 and "first main-spec item this week"
    or ("main-spec item no. %d this week; nobody with fewer rolled"):format(plusBefore + 1)) or "nobody rolled main spec"
  if byAttendance then why = "regular raider; " .. why end
  announce(("UW loot: %s goes to %s (%s, rolled %d; %s)."):format(s.link, winner, TIER_LABEL[tier], roll, why))
  local ch = groupChannel()
  if not ch then ns.say("Dry run outside a group: nothing recorded.") return end
  local at = awardTime()
  local a = handOut(s.link, winner, tier, roll, at)
  ns.send(("LOOT\t%s\t%s\t%s\t%d\t%d"):format(itemName(s.link), winner, tier, roll, at), ch)
  if a then ns.ShareAward(a, 0) end
  last = { link = s.link, rolls = s.rolls, at = at, winner = winner }
end

-- A roller of the running roll, or of the last award, by name as typed (any case): two-word names work too.
function ns.rollerName(typed)
  local rolls = (session and session.rolls) or (last and last.rolls) or {}
  for n in pairs(rolls) do if n:lower() == typed:lower() then return n end end
end

-- The leader's call: give the item to another roller (a much bigger upgrade), during the roll or within
-- GIVE_WINDOW seconds of the award. Main spec still comes first. The reason is announced and goes to #loot-log.
function ns.GiveLoot(target, reason)
  reason = (reason ~= "" and reason or "bigger upgrade"):gsub("[\t;\"\\]", "")
  if #reason > 80 then reason = reason:sub(1, 80):gsub("[\192-\255][\128-\191]*$", "") end -- never half a character
  local rolls, link
  if session then
    rolls, link = session.rolls, session.link
  elseif last and serverNow() - last.at <= ns.GIVE_WINDOW then
    rolls, link = last.rolls, last.link
  else
    return false, ("No roll running, and the last award was over %d seconds ago."):format(ns.GIVE_WINDOW)
  end
  local key
  for n in pairs(rolls) do if n:lower() == target:lower() then key = n end end
  if not key then return false, target .. " didn't roll on this item." end
  local r = rolls[key]
  if r.tier == "os" then
    for _, x in pairs(rolls) do
      if x.tier == "ms" then return false, "Main spec comes first: someone rolled main spec, so off spec can't get it." end
    end
  end
  local ch = groupChannel()
  if session then
    session = nil
  elseif last then
    if last.winner == key then return false, key .. " already has it." end
    if ch then
      local undone = ns.UndoAward(last.at, last.winner)
      ns.send(("LOOTUNDO\t%d"):format(last.at), ch) -- every client takes the first winner's +1 back, not just ours
      if undone then ns.ShareUndo(undone, 0) end
    end
  end
  announce(("UW loot: %s goes to %s (%s, rolled %d; leader's call: %s)."):format(link, key, TIER_LABEL[r.tier], r.roll, reason))
  last = nil
  if not ch then ns.say("Dry run outside a group: nothing recorded.") return true end
  local at = awardTime()
  local a = handOut(link, key, r.tier, r.roll, at, reason)
  ns.send(("LOOT\t%s\t%s\t%s\t%d\t%d\t%s"):format(itemName(link), key, r.tier, r.roll, at, reason), ch)
  if a then ns.ShareAward(a, 0) end
  return true
end

-- Shared by the leader's client, the clients that hear its LOOT message in the group, and guildmates' clients
-- that hear it shared over the guild (Raid.lua). An award is keyed by its time and winner, so hearing it twice
-- (RAID and GUILD, or a later catch-up) counts it once, and an undone award never comes back. shared: heard from the
-- guild, not in this client's group, so /uw loot undo here can't take it back. Returns the award, or nil when it
-- was already known. private: handed out here by a leader below Raider. It counts on this client only ("stays on
-- your client"), so it never goes to the outbox either, where a guild master's own alt could post it to #loot-log
-- (audit G4).
function ns.RecordAward(link, winner, tier, roll, at, reason, shared, private)
  local db = ledger()
  for _, a in ipairs(db.awards) do
    if a.at == at and a.name == winner then
      if not shared then a.shared = nil end -- heard in our own group after all
      return nil
    end
  end
  local name = itemName(link)
  local counts = tier == "ms" and (not shared or thisWeek(db, at))
  if counts then db.plus[winner] = (db.plus[winner] or 0) + 1 end
  local a = { at = at, item = name, name = winner, tier = tier, roll = roll, call = reason, shared = shared or nil,
    plus = counts or nil, private = private or nil }
  db.awards[#db.awards + 1] = a
  if not private then
    local call = reason and (";call;" .. reason:gsub("[\t;\"\\]", "")) or ""
    ns.queue("loot", name, ("%s;%s;%d;%d%s"):format(winner, tier, roll, at, call))
  end
  return a
end

-- Takes an award back: the one with this time (and winner, when known), or with no time the latest this week that
-- this client handed out itself (not one it mirrored from another group's leader). groupOnly (a leader's LOOTUNDO in the group): never an award heard from the guild.
-- It stays in the ledger marked undone, so a late copy of the award can't count again; an undo heard before its
-- award leaves just that mark. Returns the award, or nil.
function ns.UndoAward(at, winner, groupOnly)
  local db = ledger()
  for i = #db.awards, 1, -1 do
    local a = db.awards[i]
    if not a.undone and (at and a.at == at and (not winner or a.name == winner) and not (groupOnly and a.shared)
        or not at and a.own and thisWeek(db, a.at)) then
      a.undone = serverNow()
      if a.plus and (db.plus[a.name] or 0) > 0 then db.plus[a.name] = db.plus[a.name] - 1 end
      a.plus = nil
      if not a.private then ns.queue("lootundo", a.item, ("%s;%d"):format(a.name, a.at)) end
      return a
    end
  end
  if at and winner then
    for _, a in ipairs(db.awards) do if a.at == at and a.name == winner then return nil end end
    db.awards[#db.awards + 1] = { at = at, name = winner, item = "", tier = "", roll = 0, undone = serverNow() }
  end
end

function ns.StartLoot(link, only)
  lastToken = lastToken + 1
  local token = lastToken
  session = { link = link, rolls = {}, only = only and {}, token = token }
  for _, n in ipairs(only or {}) do session.only[n] = true end
  if not only then
    announce(("UW loot: %s. /roll for main spec, /roll 99 for off spec. %d seconds."):format(link, ns.LOOT_SECONDS))
  end
  C_Timer.After(ns.LOOT_SECONDS, function() finish(token) end)
end

-- True while a /uw loot roll this client started is still open (AutoEquip.lua waits for it).
function ns.LootOpen() return session ~= nil end

-- A roll counts once per player per item (a reroll is ignored), and only 1-100 or 1-99.
function ns.OnRollText(msg)
  if not session or type(msg) ~= "string" or ns.isSecret(msg) then return end
  local name, roll, low, high = msg:match(ns.RollPattern())
  roll, low, high = tonumber(roll), tonumber(low), tonumber(high)
  if not name or low ~= 1 or (high ~= ns.MS_MAX and high ~= ns.OS_MAX) then return end
  name = ns.shortName(ns.fullName(name) or name)
  -- In a group, only its members' rolls count (a stranger rolling nearby doesn't).
  if IsInGroup() and not (UnitInRaid(name) or UnitInParty(name)) then return end
  if session.only and not session.only[name] then return end
  if session.rolls[name] then return end
  session.rolls[name] = { tier = high == ns.MS_MAX and "ms" or "os", roll = roll }
end

-- Mirror the leader's award, so every client's +1 count agrees and the bot PC hears about it even when the
-- guild master isn't the one handing out loot. Only a guildmate who leads or assists the group AND holds a rank
-- that hands out loot (Guild Master, Officer or Raider: the rank rule raid shares use, Raid.lua) is believed. Leading
-- alone isn't enough: anyone can lead a party, or be an assistant when "everyone is assistant" is on, and a trusted
-- client passes what it mirrors on to the whole guild (Raid.lua), so a Trial leading a party could otherwise write
-- the guild's #loot-log and +1 counts. Only on a guild character of this client (an alt in another guild records
-- nothing).
local function trustedLeader(sender, channel)
  return (channel == "RAID" or channel == "PARTY") and ns.trustedLeader(sender)
end
-- An award heard from another client (LOOT in the group, RL from the guild): checked, then recorded once. Its time
-- must be recent (at most 10 minutes ahead and 8 days back, as for every raid record), so an award dated years
-- ahead can't count as "this week" forever. Returns the award when it is new here.
function ns.MirrorAward(item, winner, tier, roll, at, reason, shared)
  if (tier ~= "ms" and tier ~= "os") or type(winner) ~= "string" or winner == "" or not ns.inRoster(winner) then return end
  roll, at = ns.finite(roll), ns.RecentAt(at)
  if not roll or not at or roll < 1 or roll > ns.MS_MAX then return end
  reason = type(reason) == "string" and reason:gsub("[\t;\"\\]", "") or ""
  if #reason > 80 then reason = reason:sub(1, 80):gsub("[\192-\255][\128-\191]*$", "") end
  return ns.RecordAward(itemName(item or "?"), winner, tier, math.floor(roll), math.floor(at),
    reason ~= "" and reason or nil, shared)
end
-- The winner must be in the group: loot handed out in this group goes to someone in it.
ns.handlers.LOOT = function(sender, channel, item, winner, tier, roll, at, reason)
  if not trustedLeader(sender, channel) then return end
  if type(winner) ~= "string" or winner == "" or not (UnitInRaid(winner) or UnitInParty(winner)) then return end
  local a = ns.MirrorAward(item, winner, tier, roll, at, reason)
  if a then ns.ShareAward(a) end
end
-- Takes back only an award made in this group: one heard from the guild (shared) belongs to another raid.
ns.handlers.LOOTUNDO = function(sender, channel, at)
  if not trustedLeader(sender, channel) then return end
  at = ns.finite(at)
  local a = at and ns.UndoAward(math.floor(at), nil, true)
  if a then ns.ShareUndo(a) end
end

local function plusText()
  local db, rows = ledger(), {}
  for name, n in pairs(db.plus) do rows[#rows + 1] = ("%s %d"):format(name, n) end
  table.sort(rows)
  return #rows > 0 and table.concat(rows, ", ") or "nobody yet"
end

ns.commands.loot = function(args)
  args = strtrim(args or "")
  local word = args:lower()
  if word == "" or word == "help" then
    ns.say("/uw loot <shift-click item> starts a roll (Raiders or officers who lead or assist). Then: give <name> "
      .. "[reason] · end · cancel · undo · plus")
    ns.say("Everyone: /roll for main spec, /roll 99 for off spec.")
    ns.say("Order: main spec, regular raiders, fewer main-spec wins this week, then the highest roll. A leader may "
      .. "give a much bigger upgrade, and says why.")
  elseif word == "plus" then
    ns.say("Main-spec wins since the weekly reset: " .. plusText())
  elseif word == "end" then
    if session then finish(session.token) else ns.say("No loot roll running.") end
  elseif word == "cancel" then
    if session then announce(("UW loot: roll for %s cancelled."):format(session.link)); session = nil end
  elseif word == "give" or word:match("^give%s") then -- never a roll for an item called "give" (audit G5)
    if not canLead() then ns.say("Only the group leader or an assistant can give loot.") return end
    local target, reason = ns.splitName(args:sub(6), ns.rollerName)
    if not target then ns.say("/uw loot give <name> [reason]: who gets it instead, and why.") return end
    local ok, err = ns.GiveLoot(target or "", reason or "")
    if not ok then ns.say(err) end
  elseif word == "undo" then
    if not canLead() then ns.say("Only the group leader or an assistant can undo an award.") return end
    local a = ns.UndoAward()
    if not a then ns.say("No award to undo: you haven't handed one out this week.") return end
    announce(("UW loot: undid %s to %s. Their main-spec count is back where it was."):format(a.item, a.name))
    if groupChannel() then
      ns.send(("LOOTUNDO\t%d"):format(a.at), groupChannel())
      ns.ShareUndo(a, 0)
    end
  else
    if not canLead() then ns.say("Only the group leader or an assistant can start a loot roll.") return end
    if session then ns.say(("Still rolling for %s. /uw loot end to finish it first."):format(session.link)) return end
    if IsInGroup() and not ns.canShareRaid(ns.me()) then
      ns.say("Only a Raider's or officer's awards count for the guild, so this one stays on your client. Ask one to hand out loot.")
    end
    ns.StartLoot(args)
  end
end

-- Blizzard's own Need/Greed rolls: one quiet reminder per session, in groups with guildmates (a pug while leveling
-- isn't told about the guild's rule).
local reminded = false
local function guildmateInGroup()
  local raid = IsInRaid()
  for i = 1, GetNumGroupMembers() do
    local unit = (raid and "raid" or "party") .. i
    if UnitIsInMyGuild(unit) and not UnitIsUnit(unit, "player") then return true end
  end
  return false
end
local f = CreateFrame("Frame")
f:RegisterEvent("CHAT_MSG_SYSTEM")
f:RegisterEvent("START_LOOT_ROLL")
f:SetScript("OnEvent", function(_, event, msg)
  if event == "CHAT_MSG_SYSTEM" then
    ns.OnRollText(msg)
    if ns.NoteRollText then ns.NoteRollText(msg) end
  elseif not reminded and IsInGroup() and ns.inOurGuild() and guildmateInGroup() then
    reminded = true
    ns.say("Guild loot rule: Need only for your main spec. Greed for off spec, alts and selling.")
  end
end)
