-- Who welcomes and who gets groups going, by character (Louis, 22 Nov 2026, on a card: promotion looks may count,
-- per character, welcomes to first-week newcomers and group calls that got answers, heard by officers' addons; no
-- text, 28 days, officer-only). Most members have neither Discord nor UW_Guild, and in guild chat is where they lead,
-- so without this the promotion look could only see the few who do (bot/uwbot/signals.py, docs/member-signals.md).
--
-- What counts, on an officer's client or the bot's PC, each a clear signal only (nothing else does anything):
--   w  a guild line with the whole word "welcome" from someone who is not the newcomer, within WEEK1_REPLY_SECS of
--      the game's "<name> has joined the guild." line for a new member, or of a first-week newcomer's first guild
--      line (WeekOne.lua weekOne.spoke). Only the welcomer is kept, never the newcomer (week one's promise).
--   c  the caller of a group call in guild chat that drew an answer (Lead.lua, the call's first answer).
--   a  someone who answered a group call (Lead.lua).
-- Per UTC day a SET of names, never a count, a line or a time: saying "welcome" ten times is one welcome day. The
-- Guild Master's characters are never kept. An officer's client keeps CREDIT_SEND_DAYS days and passes them to the
-- Guild Master's character by hidden addon message (never a chat whisper) when the bot PC says hello (W1H), like
-- member reports; the bot's PC holds CREDIT_KEEP_DAYS days in UW_GuildDB.credits for the bot to copy, and the bot
-- drops hidden members.
-- /uw share off stops it and deletes what this PC held.
--   WCR <day> <w|c|a> <name;name;...>
local _, ns = ...

local DAY = 86400
ns.CREDIT_SEND_DAYS = 3        -- days an officer's client holds and resends (a resend is a union: never more)
ns.CREDIT_KEEP_DAYS = 7        -- days the bot's PC holds for the bot to copy (red team: a transport buffer only; the bot
                               -- keeps 28 days and honours /uw-privacy and /uw-hide, which can't reach this save)
ns.CREDIT_MAX_NAMES = 150      -- names a day and kind, on any client
ns.CREDIT_GAP = 30 * 60        -- one send a session per gap
ns.CREDIT_MSG = 240
local KINDS = { w = true, c = true, a = true }

local function fmt(f, t) local d = date or (os and os.date) return d and d(f, t) end
local function dayOf(t) return fmt("!%Y%m%d", t) end
local function botPC() return type(ns.SCHEDULE) == "table" and (tonumber(ns.SCHEDULE.gen) or 0) > 0 end
local function secret(v) return ns.isSecret and ns.isSecret(v) end
local function his(name)
  if type(name) ~= "string" or secret(name) then return true end
  if ns.WeekOneGmOwn and ns.WeekOneGmOwn(ns.shortName(name)) then return true end
  return ns.IsLouis and ns.IsLouis(name) == true or false
end
local function sharing() return not ns.WeekOneSharing or ns.WeekOneSharing() end
-- Officers' clients and the bot's PC, while they measure week one (never in the sister guild) and share.
local function counts()
  if not sharing() or not (ns.WeekOneMeasures and ns.WeekOneMeasures()) then return false end
  return botPC() or ns.isOfficer(ns.me() or "")
end
ns.CreditCounts = counts

-- UW_GuildDB.credit (officer clients: what this PC heard) or UW_GuildDB.credits (the bot's PC: everyone's):
-- { [day] = { w = { [name] = true }, c = {...}, a = {...} } }
local function book(key, keep)
  local db = UW_GuildDB
  local t = type(db[key]) == "table" and db[key] or {}
  db[key] = t
  local oldest = dayOf(time() - (keep - 1) * DAY)
  for day in pairs(t) do if type(day) ~= "string" or day < oldest then t[day] = nil end end
  return t
end
local function put(t, day, kind, name)
  local d = type(t[day]) == "table" and t[day] or {}
  t[day] = d
  local s = type(d[kind]) == "table" and d[kind] or {}
  d[kind] = s
  if s[name] then return end
  local n = 0
  for _ in pairs(s) do n = n + 1 end
  if n < ns.CREDIT_MAX_NAMES then s[name] = true end
end
function ns.CreditNote(kind, who)
  if not KINDS[kind] or not counts() or type(who) ~= "string" or who == "" or his(who) then return end
  local full = ns.fullName(who)
  if not full or not ns.inRoster(full) then return end
  local name = ns.shortName(full)
  if botPC() then put(book("credits", ns.CREDIT_KEEP_DAYS), dayOf(time()), kind, name)
  else put(book("credit", ns.CREDIT_SEND_DAYS), dayOf(time()), kind, name) end
end

-- Calls and answers: Lead.lua tells week one (ns.WeekOneNight); "a" carries the answerer, "ca" the caller.
local night = ns.WeekOneNight
assert(night, "Credit.lua loads after WeekOne.lua")
function ns.WeekOneNight(kind, who, ago)
  if kind == "a" then ns.protect(ns.CreditNote, "a", who)
  elseif kind == "ca" then ns.protect(ns.CreditNote, "c", who) end
  return night(kind, who, ago)
end

-- Welcomes: a window opens at a new member's join line or a first-week newcomer's first guild line.
local open = {}             -- newcomer short name -> when the window opened; memory only
local WELCOME = "%f[%a]welcome%f[%A]"
-- "you're welcome" answers a thank-you; it isn't a welcome (red team).
local NOT_WELCOME = { "you'?r?e?%s+welcome", "%f[%a]ur%s+welcome", "%f[%a]are%s+welcome" }
function ns.CreditIsWelcome(msg)
  local m = msg:lower():gsub("\226\128\153", "'")    -- a typographic apostrophe (you’re) reads as '
  if not m:find(WELCOME) then return false end
  for _, p in ipairs(NOT_WELCOME) do if m:find(p) then return false end end
  return true
end
local function openFor(name, now)
  open[name] = now
  for k, at in pairs(open) do if now - at > ns.WEEK1_REPLY_SECS then open[k] = nil end end
end
local heard = ns.WeekOneHeard
assert(heard, "Credit.lua loads after WeekOne.lua")
function ns.WeekOneHeard(msg, sender)
  ns.protect(function()
    if type(msg) ~= "string" or secret(msg) or type(sender) ~= "string" or not counts() then return end
    local full = ns.fullName(sender)
    local name = full and ns.shortName(full)
    if not name or open[name] then return end
    local now = time()
    for _, at in pairs(open) do
      if now - at <= ns.WEEK1_REPLY_SECS and ns.CreditIsWelcome(msg) then
        ns.CreditNote("w", full)
        break
      end
    end
  end)
  heard(msg, sender)
  ns.protect(function()                      -- week one just heard a first-week newcomer's first line
    local full = type(sender) == "string" and ns.fullName(sender)
    local name = full and ns.shortName(full)
    local w = type(UW_GuildDB) == "table" and UW_GuildDB.weekOne
    local s = name and type(w) == "table" and type(w.spoke) == "table" and w.spoke[name]
    if type(s) == "table" and s.at == time() and counts() then openFor(name, s.at) end
  end)
end

local JOINED = ERR_GUILD_JOIN_S
  and "^" .. ERR_GUILD_JOIN_S:gsub("[%%%(%)%.%+%-%*%?%[%]%^%$]", "%%%0"):gsub("%%%%s", "(.+)") .. "$"
ns.CREDIT_RETURN_GAP = 600     -- as Onboarding.lua: known to the roster this long before the join line = returning
function ns.CreditJoinLine(msg)
  if not JOINED or type(msg) ~= "string" or secret(msg) or not counts() then return end
  local who = msg:match(JOINED)
  local full = who and ns.fullName(who)
  if not full or his(full) then return end
  local name, now = ns.shortName(full), time()
  local m = type(UW_GuildDB.members) == "table" and UW_GuildDB.members[name]
  if type(m) == "table" and type(m.first) == "number" and m.first < now - ns.CREDIT_RETURN_GAP then return end
  openFor(name, now)
end
local sys = CreateFrame("Frame")
ns.listen(sys, { "CHAT_MSG_SYSTEM" })
sys:SetScript("OnEvent", ns.guard(function(_, _, msg) ns.CreditJoinLine(msg) end))

-- Officer client -> the Guild Master's character ---------------------------------------------------------------
function ns.CreditMessages()
  local out = {}
  local t = book("credit", ns.CREDIT_SEND_DAYS)
  local days = {}
  for day in pairs(t) do days[#days + 1] = day end
  table.sort(days)
  for _, day in ipairs(days) do
    for _, kind in ipairs({ "w", "c", "a" }) do
      local s = type(t[day][kind]) == "table" and t[day][kind] or {}
      local names = {}
      for n in pairs(s) do if type(n) == "string" and not n:find("[;\t]") then names[#names + 1] = n end end
      table.sort(names)
      local head = ("WCR\t%s\t%s\t"):format(day, kind)
      local cur = {}
      for _, n in ipairs(names) do
        if #head + #table.concat(cur, ";") + #n + 1 > ns.CREDIT_MSG and #cur > 0 then
          out[#out + 1] = head .. table.concat(cur, ";")
          cur = {}
        end
        cur[#cur + 1] = n
      end
      if #cur > 0 then out[#out + 1] = head .. table.concat(cur, ";") end
    end
  end
  return out
end
local sentAt
local function sendTo(to)
  if botPC() or not counts() or not to or not ns.inRoster(to) then return end
  local now = time()
  if sentAt and now - sentAt < ns.CREDIT_GAP then return end
  sentAt = now
  for _, m in ipairs(ns.CreditMessages()) do
    ns.craftSend(m, "WHISPER", to, nil, function() return not counts() end)
  end
end
-- The bot's PC said hello (W1H) from the Guild Master's character on the guild channel: what came before first.
local hello = ns.handlers.W1H
assert(hello, "Credit.lua loads after WeekOne.lua")
ns.handlers.W1H = function(sender, channel, ...)
  ns.protect(hello, sender, channel, ...)
  if channel ~= "GUILD" or botPC() or not counts() or not ns.inRoster(sender) or not (ns.WeekOneIsHis or ns.IsLouis)(sender)
    or ns.shortName(sender) == ns.shortName(ns.me() or "") or #ns.CreditMessages() == 0 then
    return
  end
  if sentAt and time() - sentAt < ns.CREDIT_GAP then return end
  ns.after(20 + math.random() * 120, function() sendTo(sender) end)
end

-- The bot's PC: officers' sets, each name checked against the roster, joined into its own. Never from a member.
ns.handlers.WCR = function(sender, channel, day, kind, names)
  if channel ~= "WHISPER" or not botPC() or not counts() then return end
  if not ns.inRoster(sender) or not ns.isOfficer(sender) or his(sender) then return end
  if type(day) ~= "string" or not day:match("^%d%d%d%d%d%d%d%d$") or not KINDS[kind] or type(names) ~= "string" then
    return
  end
  local now = time()
  if day > dayOf(now + DAY) or day < dayOf(now - ns.CREDIT_SEND_DAYS * DAY) then return end
  local t = book("credits", ns.CREDIT_KEEP_DAYS)
  for n in names:gmatch("[^;]+") do
    local full = #n <= 60 and ns.fullName(n)
    if full and ns.inRoster(full) and not his(full) then put(t, day, kind, ns.shortName(full)) end
  end
end

-- /uw share off: stop, and delete what this PC held.
local shareCmd = ns.commands.share
ns.commands.share = function(args)
  shareCmd(args)
  if UW_GuildDB and not sharing() then UW_GuildDB.credit, UW_GuildDB.credits = nil, nil end
end
