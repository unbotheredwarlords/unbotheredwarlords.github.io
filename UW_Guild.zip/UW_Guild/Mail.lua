-- Mats to your alts (Louis, 5 Nov 2026, addon item 3: "mailbox mats-to-alt router with auto-detected professions").
--
-- At a mailbox, one button mails crafting materials to whichever of your own characters crafts with them. Nothing to
-- set up: each character on this account notes its professions at login, and which reagents its recipes use whenever
-- one of its profession windows is open. UW_GuildDB is shared by every character on the account, so they all see it.
--
-- Who gets an item (best first; ties go to the higher rank, then the name):
--   1. an alt with a recipe that uses it and still gives skill-ups (not grey), so the mats turn into progress;
--   2. an alt with any recipe that uses it;
--   3. an alt with the profession that uses this kind of trade good (herbs to Alchemy, cloth to Tailoring, then First
--      Aid, and so on), on clients that sort trade goods by kind; one whose recipes aren't read yet first.
-- What stays in the bags: anything this character uses itself (its recipes, or a profession for that kind of good),
-- anything a quest in its log asks for, bound, quest, locked or wearable items, and anything no alt can use.
-- Who never gets mail: a character the game doesn't list as on this account (deleted or renamed: forgotten at once),
-- another faction, another realm, and this character. A character unseen for 90 days is forgotten too.
-- Sending: one click attaches up to 12 stacks for one alt and shows the real postage. The first mail to each alt each
-- session asks first, with the full list; it never sends without enough money, in combat, or over a mail you started.
-- Nothing leaves this account and nothing is shared with the guild. /uw mail lists what would go where, and which
-- alts still need a profession window opened; /uw mail off hides the button.
local _, ns = ...
local say = ns.say

local function g(name) return rawget(_G, name) end
local function call(fn, ...)
  if type(fn) ~= "function" then return nil end
  local ok, a, b, c, d, e, f, h, i, j, k, l, m, n, o = pcall(fn, ...)
  if ok then return a, b, c, d, e, f, h, i, j, k, l, m, n, o end
end
local function cnt() return g("C_Container") or {} end
local function items() return g("C_Item") or {} end
local function on() return UW_GuildDB and UW_GuildDB.mailMats ~= false end
local function db()
  UW_GuildDB.alts = type(UW_GuildDB.alts) == "table" and UW_GuildDB.alts or {}
  return UW_GuildDB.alts
end
local function me() return ns.me() or UnitName("player") end
local function realmOf(name) return name:match("%-([^%-]+)$") end

ns.MAIL_ATTACH_MAX = 12
ns.MAIL_ALT_DAYS = 90    -- a character not seen for this long is forgotten (deleted or moved)
ns.MAIL_USES_MAX = 600   -- reagents remembered per character
local TRADE_GOODS, TRIVIAL = 7, 3
-- Trade goods kinds on the modern item API (GetItemInfoInstant's subclass) and the professions that use each, most
-- likely first. A client that files every trade good as kind 0 leaves this to the recipes.
ns.MAIL_KIND_PROF = { [1] = { "Engineering" }, [5] = { "Tailoring", "First Aid" }, [6] = { "Leatherworking" },
  [7] = { "Blacksmithing", "Engineering" }, [8] = { "Cooking" }, [9] = { "Alchemy" }, [12] = { "Enchanting" } }
local CRAFTS = { Alchemy = true, Blacksmithing = true, Enchanting = true, Engineering = true, Leatherworking = true,
  Tailoring = true, Cooking = true, ["First Aid"] = true }

-- This character ------------------------------------------------------------------------------------------------------
local function entry()
  local all, name = db(), me()
  if type(name) ~= "string" or ns.isSecret(name) then return nil end
  all[name] = type(all[name]) == "table" and all[name] or {}
  local e = all[name]
  e.at, e.faction = time(), call(g("UnitFactionGroup"), "player") or e.faction
  e.profs, e.uses, e.useful, e.read = e.profs or {}, e.uses or {}, e.useful or {}, e.read or {}
  return e
end

-- Professions from the skill list. A profession the character dropped takes its reagents with it.
function ns.MailNoteProfessions()
  local ranks = ns.ReadProfessions and ns.ReadProfessions()
  local e = ranks and entry()
  if not e then return end
  e.profs = {}
  for prof, r in pairs(ranks) do e.profs[prof] = r.r or 0 end
  for id, prof in pairs(e.uses) do if not e.profs[prof] then e.uses[id], e.useful[id] = nil, nil end end
  for prof in pairs(e.read) do if not e.profs[prof] then e.read[prof] = nil end end
end

-- What the open profession window's recipes use: prof, { [itemID] = true when a recipe using it still gives
-- skill-ups }. The window is read again each time it opens, so a reagent whose recipes all went grey stops counting
-- as useful.
function ns.MailNoteRecipes(prof, reagents)
  local e = type(prof) == "string" and type(reagents) == "table" and entry()
  if not e then return end
  local n = 0
  for id, p in pairs(e.uses) do
    if p == prof then e.uses[id], e.useful[id] = nil, nil else n = n + 1 end
  end
  for id, useful in pairs(reagents) do
    if n < ns.MAIL_USES_MAX then
      e.uses[id], e.useful[id], n = prof, useful or nil, n + 1
    end
  end
  e.read[prof] = time()
end

local function idOf(link) return tonumber(tostring(link or ""):match("item:(%d+)")) end
local function add(out, id, useful) if id then out[id] = out[id] or useful end end

-- The open window's reagents, on whichever API this client has (the same three Crafts.lua reads).
function ns.MailReadWindow(craft)
  local out = {}
  if craft then
    local prof = call(g("GetCraftDisplaySkillLine"))
    if type(prof) ~= "string" or ns.isSecret(prof) then return nil end
    for i = 1, (call(g("GetNumCrafts")) or 0) do
      local name, _, kind = call(g("GetCraftInfo"), i)
      if name and kind ~= "header" then
        for r = 1, (call(g("GetCraftNumReagents"), i) or 0) do
          add(out, idOf(call(g("GetCraftReagentItemLink"), i, r)), kind ~= "trivial")
        end
      end
    end
    return prof, out
  end
  if g("GetTradeSkillLine") and g("GetNumTradeSkills") then
    local prof = call(g("GetTradeSkillLine"))
    if type(prof) ~= "string" or ns.isSecret(prof) or prof == "UNKNOWN" then return nil end
    for i = 1, (call(g("GetNumTradeSkills")) or 0) do
      local name, kind = call(g("GetTradeSkillInfo"), i)
      if name and kind ~= "header" and kind ~= "subheader" then
        for r = 1, (call(g("GetTradeSkillNumReagents"), i) or 0) do
          add(out, idOf(call(g("GetTradeSkillReagentItemLink"), i, r)), kind ~= "trivial")
        end
      end
    end
    return prof, out
  end
  local ts = g("C_TradeSkillUI")
  if type(ts) ~= "table" then return nil end
  local info = call(ts.GetBaseProfessionInfo)
  local prof = type(info) == "table" and info.professionName
  if type(prof) ~= "string" or ns.isSecret(prof) or prof == "" then return nil end
  -- The list can still hold the last profession's recipes while a new window fills (Louis, 5 Nov: Peacebloom read as
  -- First Aid): keep only recipes the game puts in this profession, when it can say.
  local line = info.professionID
  local function inThis(rid)
    if line and ts.IsRecipeInSkillLine then return call(ts.IsRecipeInSkillLine, rid, line) ~= false end
    local p = ts.GetProfessionInfoByRecipeID and call(ts.GetProfessionInfoByRecipeID, rid)
    local name = type(p) == "table" and (p.parentProfessionName or p.professionName)
    return type(name) ~= "string" or name == "" or name == prof
  end
  for _, rid in ipairs(call(ts.GetAllRecipeIDs) or {}) do
    local r = call(ts.GetRecipeInfo, rid)
    if type(r) == "table" and r.learned and inThis(rid) then
      local s = call(ts.GetRecipeSchematic, rid, false)
      for _, slot in ipairs(type(s) == "table" and s.reagentSlotSchematics or {}) do
        local first = slot.reagents and slot.reagents[1]
        add(out, first and first.itemID, r.relativeDifficulty ~= TRIVIAL)
      end
    end
  end
  return prof, out
end

local function forgetOld()
  local cutoff = time() - ns.MAIL_ALT_DAYS * 86400
  for name, e in pairs(db()) do
    if type(e) ~= "table" or (tonumber(e.at) or 0) < cutoff then db()[name] = nil end
  end
end

-- Is this name one of the account's characters? The game's own list (the mail To: box offers it), which holds bare
-- same-realm names ("Veda") while our keys may carry the realm ("Veda-Forever"): searched by the bare name, and a hit
-- counts only when its realm is none or ours. nil: can't tell.
local function split(name)
  local base, realm = name:match("^(.-)%-([^%-]+)$")
  return base or name, realm
end
function ns.MailIsAccountCharacter(name)
  local get, flag = g("GetAutoCompleteResults"), g("AUTOCOMPLETE_FLAG_ACCOUNT_CHARACTER")
  if type(get) ~= "function" or type(flag) ~= "number" or type(name) ~= "string" then return nil end
  local base, realm = split(name)
  local home = call(g("GetNormalizedRealmName"))
  if realm and home and realm ~= home then return false end
  local res = { pcall(get, base, 50, #base, true, flag, 0) }
  if not table.remove(res, 1) then return nil end
  if type(res[1]) == "table" then res = res[1] end
  for _, r in ipairs(res) do
    local n = type(r) == "table" and r.name or r
    if type(n) == "string" then
      local nb, nr = split(n)
      if nb:lower() == base:lower() and (nr == nil or nr == home or nr == realm) then return true end
    end
  end
  return false
end

-- Routing ------------------------------------------------------------------------------------------------------------
-- Item names a quest in this character's log asks for (lowercase objective text), so quest mats stay.
local function questNeeds()
  local texts, ql = {}, g("C_QuestLog")
  if type(ql) == "table" and ql.GetNumQuestLogEntries and ql.GetQuestObjectives then
    for i = 1, (call(ql.GetNumQuestLogEntries) or 0) do
      local q = call(ql.GetInfo, i)
      if type(q) == "table" and not q.isHeader and q.questID then
        for _, o in ipairs(call(ql.GetQuestObjectives, q.questID) or {}) do
          if o.type == "item" and type(o.text) == "string" then texts[#texts + 1] = o.text:lower() end
        end
      end
    end
  elseif g("GetNumQuestLogEntries") and g("GetQuestLogLeaderBoard") then
    for i = 1, (call(g("GetNumQuestLogEntries")) or 0) do
      for j = 1, (call(g("GetNumQuestLeaderBoards"), i) or 0) do
        local text, kind = call(g("GetQuestLogLeaderBoard"), j, i)
        if kind == "item" and type(text) == "string" then texts[#texts + 1] = text:lower() end
      end
    end
  end
  return texts
end
local function askedFor(texts, link)
  local name = tostring(link or ""):match("%[(.-)%]")
  if not name or name == "" then return false end
  name = name:lower()
  for _, t in ipairs(texts) do if t:find(name, 1, true) then return true end end
  return false
end

local function kindOf(id)
  local instant = items().GetItemInfoInstant or g("GetItemInfoInstant")
  local _, _, _, equipLoc, _, classID, subID = call(instant, id)
  return classID, subID, equipLoc
end

local function canReceive(name, e, self)
  if name == me() or type(e) ~= "table" or type(e.profs) ~= "table" then return false end
  if self and self.faction and e.faction and e.faction ~= self.faction then return false end
  return realmOf(name) == realmOf(me()) -- Forever has no realms: both nil
end

-- The best alt for this item: { to, prof, rank, why }, or nil (also when this character uses it itself).
local function route(id, self)
  local classID, subID, equipLoc = kindOf(id)
  if equipLoc and equipLoc ~= "" then return nil end -- gear (BoE pieces too) is never a mat
  local kinds = classID == TRADE_GOODS and ns.MAIL_KIND_PROF[subID] or {}
  if self and self.uses and self.uses[id] then return nil end
  for _, p in ipairs(kinds) do if self and self.profs and self.profs[p] then return nil end end
  local best
  local function consider(name, prof, tier, why)
    local rank = tonumber(db()[name].profs[prof])
    if not rank then return end
    if not best or tier > best.tier or (tier == best.tier and (rank > best.rank or (rank == best.rank and name < best.to)))
    then best = { to = name, prof = prof, rank = rank, tier = tier, why = why } end
  end
  for name, e in pairs(db()) do
    if canReceive(name, e, self) then
      local prof = type(e.uses) == "table" and e.uses[id]
      if prof then
        consider(name, prof, (type(e.useful) == "table" and e.useful[id]) and 3 or 2,
          (type(e.useful) == "table" and e.useful[id]) and "skill-ups" or "recipes")
      else
        for k, p in ipairs(kinds) do
          -- An alt whose window was read and uses none of it yet ranks below one whose recipes are still unknown.
          local read = type(e.read) == "table" and e.read[p]
          consider(name, p, (read and 0.5 or 1) - k * 0.1, "profession")
        end
      end
    end
  end
  return best
end

-- What would go where: { { to, prof, why, items = { { bag, slot, id, link, count, why } ... } } ... }, the biggest first.
-- Each list is one mail at most; the next click finds the rest.
function ns.MailPlan()
  local self, byAlt, out, quests = db()[me()], {}, {}, questNeeds()
  for bag = 0, NUM_BAG_SLOTS or 4 do
    for slot = 1, (call(cnt().GetContainerNumSlots, bag) or 0) do
      local c = call(cnt().GetContainerItemInfo, bag, slot)
      local id = c and c.itemID
      if id and not c.isBound and not c.isLocked and c.hyperlink and not askedFor(quests, c.hyperlink) then
        local quest = call(cnt().GetContainerItemQuestInfo, bag, slot)
        local r = not (quest and (quest.isQuestItem or quest.questID)) and route(id, self)
        if r then
          local key = r.to .. "\t" .. r.prof
          local p = byAlt[key]
          if not p then p = { to = r.to, prof = r.prof, items = {}, tier = -1 }; byAlt[key] = p; out[#out + 1] = p end
          if #p.items < ns.MAIL_ATTACH_MAX then
            p.items[#p.items + 1] = { bag = bag, slot = slot, id = id, link = c.hyperlink, count = c.stackCount or 1,
              why = r.why }
            if r.tier > p.tier then p.tier, p.why = r.tier, r.why end -- the mail says its best reason
          end
        end
      end
    end
  end
  table.sort(out, function(a, b) return #a.items > #b.items or (#a.items == #b.items and a.to < b.to) end)
  return out
end

-- Alts with a crafting profession whose window hasn't been read yet: their mats can only go by kind.
function ns.MailUnread()
  local out, self = {}, db()[me()]
  for name, e in pairs(db()) do
    if canReceive(name, e, self) then
      for prof in pairs(e.profs) do
        if CRAFTS[prof] and not (type(e.read) == "table" and e.read[prof]) then
          out[#out + 1] = ("%s (%s)"):format(ns.shortName(name), prof)
        end
      end
    end
  end
  table.sort(out)
  return out
end

-- Sending ------------------------------------------------------------------------------------------------------------
local button, shown, mailOpen, sending
local askedTo = {} -- alts already confirmed this session

local function money(c)
  local fmt = g("GetCoinTextureString") or (g("C_CurrencyInfo") and g("C_CurrencyInfo").GetCoinTextureString)
  return call(fmt, c) or (c .. "c")
end
local function attachedCount()
  local n = 0
  for i = 1, ns.MAIL_ATTACH_MAX do if call(g("GetSendMailItem"), i) then n = n + 1 end end
  return n
end
local function unattach() call(g("ClearSendMail")) end

local function post(p)
  sending = p
  call(g("SendMail"), (split(p.to)), ("Mats for %s"):format(p.prof), "") -- same realm: the bare name
end

-- Attaches exactly the items planned (each re-checked in its slot), then sends, or asks first with the real postage.
-- Only from the button's click.
local function send(p)
  if InCombatLockdown() or call(g("GetCursorInfo")) ~= nil then return false end
  if attachedCount() > 0 then say("Your mail has items in it already. Send or clear it first.") return false end
  local mine = ns.MailIsAccountCharacter(p.to)
  if mine == false then
    db()[p.to] = nil
    say(("%s isn't on this account any more, so UW forgot it. Nothing was sent."):format(p.to))
    return false
  end
  local sendFrame = g("SendMailFrame")
  if sendFrame and not call(sendFrame.IsShown, sendFrame) then call(g("MailFrameTab_OnClick"), nil, 2) end
  local n = 0
  for _, it in ipairs(p.items) do
    local c = call(cnt().GetContainerItemInfo, it.bag, it.slot)
    if c and c.itemID == it.id and not c.isLocked and not c.isBound then
      call(cnt().PickupContainerItem, it.bag, it.slot)
      local kind, id = call(g("GetCursorInfo"))
      if kind == "item" and id == it.id then
        n = n + 1
        call(g("ClickSendMailItemButton"), n)
      end
      if call(g("CursorHasItem")) then call(g("ClearCursor")) end
    end
  end
  if n == 0 then return false end
  local price = tonumber(call(g("GetSendMailPrice"))) or 0
  local have = tonumber(call(g("GetMoney")))
  if have and price > have then
    unattach()
    say(("Postage is %s and you have %s. Nothing was sent."):format(money(price), money(have)))
    return false
  end
  if askedTo[p.to] and mine then post(p) return true end
  local list = {}
  for i, it in ipairs(p.items) do
    if i > 8 then list[#list + 1] = ("+%d more"):format(#p.items - 8) break end
    list[#list + 1] = it.count > 1 and ("%s x%d"):format(it.link, it.count) or it.link
  end
  ns.KitConfirm(("Mail to %s (%s, %s)?\n%s\nPostage %s.%s"):format(p.to, p.prof, p.why, table.concat(list, "\n"),
    money(price), mine == nil and "\nUW can't confirm this name is your character." or ""),
    function() askedTo[p.to] = true; post(p) end, unattach, "UW_GUILD_MAIL")
  return true
end

local function refresh()
  if not button then return end
  shown = mailOpen and on() and not sending and not InCombatLockdown() and ns.MailPlan()[1] or nil
  if not shown then button:Hide() return end
  button:SetText(("Send mats to %s (%d)"):format(ns.shortName(shown.to), #shown.items))
  button:Show()
end
ns.MailRefresh = refresh

function ns.MailClick()
  local p = shown
  if not p or sending then return end
  if not send(p) then refresh() end
end

local function build()
  if button then return button end
  local parent = g("MailFrame")
  if not parent then return nil end
  button = CreateFrame("Button", "UW_GuildMailMatsButton", parent, "UIPanelButtonTemplate")
  button:SetSize(230, 24)
  button:SetPoint("TOP", parent, "BOTTOM", 0, -4)
  button:SetScript("OnClick", function() ns.protect(ns.MailClick) end)
  button:SetScript("OnEnter", function(self)
    local tip = g("GameTooltip")
    if not (tip and shown) then return end
    tip:SetOwner(self, "ANCHOR_RIGHT")
    tip:SetText(("Mats for %s's %s (%s)"):format(ns.shortName(shown.to), shown.prof, shown.why))
    for _, it in ipairs(shown.items) do tip:AddLine(("%s x%d"):format(it.link, it.count), 1, 1, 1) end
    tip:AddLine("Your alts' recipes pick who gets what. /uw mail off hides this.", 0.6, 0.6, 0.6, true)
    tip:Show()
  end)
  button:SetScript("OnLeave", function() local tip = g("GameTooltip"); if tip then tip:Hide() end end)
  ns.Skin("Button", button)
  return button
end

ns.commands.mail = function(args)
  local sub = strtrim(args or ""):lower()
  if sub == "off" then
    UW_GuildDB.mailMats = false
    refresh()
    say("Mail button off. /uw mail on brings it back.")
    return
  elseif sub == "on" then
    UW_GuildDB.mailMats = nil
    refresh()
  end
  local plan, others = ns.MailPlan(), 0
  for name in pairs(db()) do if name ~= me() then others = others + 1 end end
  if others == 0 then say("No alts known yet. Log in to each alt once with UW_Guild on.") return end
  if #plan == 0 then say("Nothing in these bags for your alts.") end
  for i = 1, math.min(#plan, 6) do
    local p, names = plan[i], {}
    for j = 1, math.min(#p.items, 3) do names[j] = p.items[j].link end
    say(("%s (%s, %s): %s%s"):format(ns.shortName(p.to), p.prof, p.why, table.concat(names, ", "),
      #p.items > 3 and ", ..." or ""))
  end
  local unread = ns.MailUnread()
  if #unread > 0 then
    say(("Open these profession windows once for better picks: %s."):format(table.concat(unread, ", ", 1,
      math.min(#unread, 5))))
  end
end

-- Wiring ---------------------------------------------------------------------------------------------------------------
local f = CreateFrame("Frame")
ns.listen(f, { "PLAYER_ENTERING_WORLD", "SKILL_LINES_CHANGED", "TRADE_SKILL_SHOW", "TRADE_SKILL_LIST_UPDATE",
  "CRAFT_SHOW", "MAIL_SHOW", "MAIL_CLOSED", "MAIL_SEND_SUCCESS", "MAIL_FAILED", "BAG_UPDATE_DELAYED",
  "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED" })
local readPending = false
f:SetScript("OnEvent", function(_, event)
  if not UW_GuildDB then return end
  if event == "PLAYER_ENTERING_WORLD" then
    C_Timer.After(4, function() ns.protect(forgetOld); ns.protect(ns.MailNoteProfessions) end)
  elseif event == "SKILL_LINES_CHANGED" then
    ns.protect(ns.MailNoteProfessions)
  elseif event == "TRADE_SKILL_SHOW" or event == "TRADE_SKILL_LIST_UPDATE" or event == "CRAFT_SHOW" then
    if readPending then return end
    readPending = true
    local craft = event == "CRAFT_SHOW"
    C_Timer.After(2, function() -- the window fires many updates while it fills; read once it settles
      readPending = false
      ns.protect(function() ns.MailNoteRecipes(ns.MailReadWindow(craft)) end)
    end)
  elseif event == "MAIL_SHOW" then
    mailOpen, sending = true, nil
    build()
    refresh()
  elseif event == "MAIL_CLOSED" then
    mailOpen, sending = false, nil
    refresh()
  elseif event == "MAIL_SEND_SUCCESS" then
    if sending then say(("Mailed %d stack(s) to %s."):format(#sending.items, ns.shortName(sending.to))) end
    sending = nil
    C_Timer.After(0.5, function() ns.protect(refresh) end) -- once the bags show the gap
  elseif event == "MAIL_FAILED" then
    if sending then say("That mail didn't go. Check the Send Mail tab.") end
    sending = nil
    refresh()
  else
    if not sending then refresh() end
  end
end)

-- Stuck mailbox (Louis, 5 Nov 2026, on Griselda): a known WoW Forever server bug. The cursor turns into an envelope,
-- but clicks do nothing until the player changes layer or relogs (forum reports since beta, forever-bugs #327).
-- No addon can open it: the click goes straight to the server. So when a right-click on a mailbox hasn't opened it
-- within a few seconds, and the game gave no reason of its own (too far away, in combat), one line names the bug and
-- the fixes. At most once every few minutes.
ns.MAILBOX_WAIT, ns.MAILBOX_HINT_GAP = 3, 300
local MAILBOX_HINT = "That mailbox isn't answering: a known WoW Forever server bug. Try another mailbox, or leave the "
  .. "area and come back. Relogging works too."
local clickedAt, hintedAt
local function mailboxName() return g("MINIMAP_TRACKING_MAILBOX") or "Mailbox" end
local function overMailbox()
  local tip, line = g("GameTooltip"), g("GameTooltipTextLeft1")
  if not (tip and tip:IsShown() and line) then return false end
  local text = line:GetText()
  return type(text) == "string" and not ns.isSecret(text) and text == mailboxName()
end
function ns.MailboxClicked()
  if mailOpen or InCombatLockdown() or not overMailbox() then return end
  local at = GetTime()
  clickedAt = at
  C_Timer.After(ns.MAILBOX_WAIT, function()
    if clickedAt ~= at or mailOpen then return end
    clickedAt = nil
    if hintedAt and GetTime() - hintedAt < ns.MAILBOX_HINT_GAP then return end
    hintedAt = GetTime()
    say(MAILBOX_HINT)
  end)
end
local worldFrame = g("WorldFrame")
if worldFrame and worldFrame.HookScript then
  worldFrame:HookScript("OnMouseUp", function(_, btn) if btn == "RightButton" then ns.protect(ns.MailboxClicked) end end)
end
local stuck = CreateFrame("Frame")
ns.listen(stuck, { "MAIL_SHOW", "UI_ERROR_MESSAGE" })
stuck:SetScript("OnEvent", function() clickedAt = nil end) -- it opened, or the game said why not
