-- One person, every character (Louis, 22 Nov 2026, "yes": the addon tells the bot which characters on this account
-- are yours, so your alts count as you; bot/uwbot/identity.py). Without it an unlinked member's alts read as separate
-- people wherever the bot counts a person.
--
-- Each client names the guild characters that logged in on this game account with UW_Guild (UW_GuildDB.idMine,
-- account-wide) and that the game's own account list doesn't refuse (ns.MailIsAccountCharacter), and passes them to
-- the Guild Master's character by hidden addon message (never a chat whisper) at login when he is online, or when the
-- bot's PC says hello (W1H), at most once a day per character. The bot joins two characters only when each one's own client named the other.
-- The first send says so in this player's own chat (a say, never a whisper); /uw alts off stops it and withdraws what
-- was sent, and it is a switch in Options and the guide. /uw battletag adds this account's BattleTag (optional).
--   ACC <name;name;...>  or  ACC -      (withdraw)
--   BTG <Name#1234>      or  BTG -
local _, ns = ...
local say = ns.say

local DAY = 86400
ns.ID_MAX = 10              -- characters one client names
ns.ID_SEEN_DAYS = 90        -- a character not logged in here for this long is left out (deleted or moved)
ns.ID_KEEP_DAYS = 30        -- the bot's PC forgets a name not heard again in this long
ns.ID_MSG = 240

local function fmt(f, t) local d = date or (os and os.date) return d and d(f, t) end
local function today() return fmt("!%Y%m%d", time()) end
local function botPC() return type(ns.SCHEDULE) == "table" and (tonumber(ns.SCHEDULE.gen) or 0) > 0 end
local function secret(v) return ns.isSecret and ns.isSecret(v) end
local function his(name)
  if type(name) ~= "string" or secret(name) then return true end
  if ns.WeekOneGmOwn and ns.WeekOneGmOwn(ns.shortName(name)) then return true end
  return ns.IsLouis and ns.IsLouis(name) == true or false
end
local function on() return type(UW_GuildDB) == "table" and UW_GuildDB.idOff ~= true end
ns.IdentityOn = on

local function mine()
  local t = type(UW_GuildDB.idMine) == "table" and UW_GuildDB.idMine or {}
  UW_GuildDB.idMine = t
  return t
end
function ns.IdentityNoteMe()
  local me = ns.me()
  if not me or not ns.inRoster(me) or his(me) then return end
  mine()[ns.shortName(me)] = time()
end

-- This client's claim: itself first, then its account's other guild characters.
function ns.IdentityList()
  local me = ns.me() and ns.shortName(ns.me())
  if not me or not ns.inRoster(me) or his(me) then return {} end
  local others, cutoff = {}, time() - ns.ID_SEEN_DAYS * DAY
  for n, at in pairs(mine()) do
    if type(n) == "string" and n ~= me and (tonumber(at) or 0) >= cutoff and not n:find("[;\t]") and ns.inRoster(n)
      and not his(n) and (not ns.MailIsAccountCharacter or ns.MailIsAccountCharacter(n) ~= false) then
      others[#others + 1] = n
    end
  end
  table.sort(others)
  local out = { me }
  for i = 1, math.min(#others, ns.ID_MAX - 1) do out[#out + 1] = others[i] end
  return out
end

local TAG = "^[^%d%s#][^%s#]+#%d%d%d%d?%d?%d?%d?%d?$"
local function ownTag()
  local get = rawget(_G, "BNGetInfo")
  if type(get) ~= "function" then return nil end
  local ok, _, tag = pcall(get)
  if ok and type(tag) == "string" and not secret(tag) and tag:match(TAG) then return tag end
end

-- Messages for the bot: the claim (split to fit), and the BattleTag when there is one or it was just removed.
function ns.IdentityMessages()
  local out = {}
  if not on() then
    if UW_GuildDB.idWithdraw then out[1] = "ACC\t-" end
  else
    local list = ns.IdentityList()
    if #list > 1 then
      local head, cur = "ACC\t", { list[1] }
      for i = 2, #list do
        if #head + #table.concat(cur, ";") + #list[i] + 1 > ns.ID_MSG then
          out[#out + 1] = head .. table.concat(cur, ";")
          cur = { list[1] }
        end
        cur[#cur + 1] = list[i]
      end
      out[#out + 1] = head .. table.concat(cur, ";")
    end
  end
  if UW_GuildDB.idTag then out[#out + 1] = "BTG\t" .. UW_GuildDB.idTag
  elseif UW_GuildDB.idTagClear then out[#out + 1] = "BTG\t-" end
  return out
end

local function sendTo(to)
  if botPC() or not to or not ns.inRoster(to) then return end
  local msgs = ns.IdentityMessages()
  if #msgs == 0 then return end
  if on() and not UW_GuildDB.idTold then                  -- said once per account, before the first send
    UW_GuildDB.idTold = true
    say(ns.ALTS_FIRST_TEXT)
  end
  UW_GuildCharDB.idSent = today()
  for _, m in ipairs(msgs) do ns.craftSend(m, "WHISPER", to) end
  UW_GuildDB.idWithdraw, UW_GuildDB.idTagClear = nil, nil
end
-- The bot's PC said hello (W1H) from the Guild Master's character on the guild channel.
local hello = ns.handlers.W1H
assert(hello, "Identity.lua loads after WeekOne.lua")
ns.handlers.W1H = function(sender, channel, ...)
  ns.protect(hello, sender, channel, ...)
  if channel ~= "GUILD" or botPC() or not ns.inRoster(sender) or not (ns.WeekOneIsHis or ns.IsLouis)(sender)
    or ns.shortName(sender) == ns.shortName(ns.me() or "") then
    return
  end
  local urgent = UW_GuildDB.idWithdraw or UW_GuildDB.idTagClear
  if UW_GuildCharDB.idSent == today() and not urgent then return end
  ns.protect(ns.IdentityNoteMe)
  if #ns.IdentityMessages() == 0 then return end
  ns.after(30 + math.random() * 150, function() ns.protect(sendTo, sender) end)
end

-- The bot's PC: each claim kept by its sender (whose name the game gives), names checked against the roster.
local function names(t, sender)
  local d = type(t[sender]) == "table" and t[sender] or {}
  t[sender] = d
  return d
end
local function book(key)
  local t = type(UW_GuildDB[key]) == "table" and UW_GuildDB[key] or {}
  UW_GuildDB[key] = t
  local cutoff = time() - ns.ID_KEEP_DAYS * DAY
  for who, d in pairs(t) do
    if type(d) ~= "table" then t[who] = nil
    elseif key == "idTags" then if (tonumber(d.at) or 0) < cutoff then t[who] = nil end
    else
      for n, at in pairs(d) do if (tonumber(at) or 0) < cutoff then d[n] = nil end end
      if next(d) == nil then t[who] = nil end
    end
  end
  return t
end
local function from(sender, channel)
  if channel ~= "WHISPER" or not botPC() or not ns.inRoster(sender) or his(sender) then return nil end
  return ns.shortName(ns.fullName(sender) or sender)
end
ns.handlers.ACC = function(sender, channel, list)
  local who = from(sender, channel)
  if not who or type(list) ~= "string" then return end
  local t = book("idAccounts")
  if list == "-" then t[who] = nil return end
  local d, now, n = names(t, who), time(), 0
  for _ in pairs(d) do n = n + 1 end
  for name in list:gmatch("[^;]+") do
    local full = #name <= 60 and ns.fullName(name)
    local short = full and ns.inRoster(full) and not his(full) and ns.shortName(full)
    if short and (d[short] or n < 2 * ns.ID_MAX) then
      if not d[short] then n = n + 1 end
      d[short] = now
    end
  end
  d[who] = now
end
ns.handlers.BTG = function(sender, channel, tag)
  local who = from(sender, channel)
  if not who or type(tag) ~= "string" then return end
  local t = book("idTags")
  if tag == "-" then t[who] = nil return end
  if #tag <= 30 and tag:match(TAG) then t[who] = { tag = tag, at = time() } end
end

-- /uw alts on|off -------------------------------------------------------------------------------------------------
ns.ALTS_ON_TEXT = "UW_Guild tells the guild bot which characters on this account are yours, so alts count as you. "
  .. "Never shown. /uw alts off stops it."
ns.ALTS_FIRST_TEXT = "UW_Guild now counts your characters on this account as you. /uw alts off stops it."
ns.ALTS_OFF_TEXT = "Off: your characters count as separate people. /uw alts on turns it back on."
ns.commands.alts = function(args)
  local w = strtrim(args or ""):lower()
  if w == "off" then
    if UW_GuildDB.idOff ~= true then UW_GuildDB.idOff, UW_GuildDB.idWithdraw = true, true end
  elseif w == "on" then
    UW_GuildDB.idOff, UW_GuildDB.idWithdraw = nil, nil
    UW_GuildCharDB.idSent = nil
  elseif w ~= "" then
    say("/uw alts on or /uw alts off.") return
  end
  say(on() and ns.ALTS_ON_TEXT or ns.ALTS_OFF_TEXT)
end

-- Its switch, "Count my alts as me": Esc > Options > AddOns > UW Guild > Your characters (the main page's column of
-- helpers is full, options_page_test), and the guide's Play together page (Handbook.lua "alts"), one switch in both.
ns.ALTS_TIP = "UW_Guild tells the guild bot which characters on this account are yours, so alts count as you. "
  .. "The list is never shown to anyone. Off: your characters count as separate people."
ns.SettingsPage("you", "Your characters", {
  { title = "Alts", feature = "alts",
    part = { label = "Count my alts as me", on = on, cmd = "alts", tip = ns.ALTS_TIP } },
})

-- /uw battletag [clear]: the game's own BattleTag for this account (BNGetInfo) ---------------------------------------------------------------------------------------------
ns.commands.battletag = function(args)
  local w = strtrim(args or "")
  if w:lower() == "clear" or w:lower() == "off" then
    UW_GuildDB.idTag, UW_GuildDB.idTagClear = nil, true
    say("BattleTag removed.")
    return
  end
  local tag = ownTag()
  -- Only the game's own BattleTag for this account, never a typed one (red team: a typed tag could claim someone
  -- else's and pull their characters into yours).
  if not tag then say("The game gave no BattleTag here, so nothing was saved.") return end
  UW_GuildDB.idTag, UW_GuildDB.idTagClear = tag, nil
  UW_GuildCharDB.idSent = nil
  say("BattleTag saved: all your accounts' characters count as you. Kept on the guild bot's PC, never shown. "
    .. "/uw battletag clear removes it.")
end

-- At login: note this character, and when one of the Guild Master's characters is online, send to it then (the bot's
-- PC drops it unless that is the bot's client; a W1H later covers the rest).
ns.afterRoster(function()
  ns.after(60 + math.random() * 120, function()
    ns.protect(function()
      ns.IdentityNoteMe()
      local urgent = UW_GuildDB.idWithdraw or UW_GuildDB.idTagClear
      if botPC() or (UW_GuildCharDB.idSent == today() and not urgent) then return end
      for _, n in ipairs(ns.silentOnline({})) do
        if ns.inRoster(n) and (ns.WeekOneIsHis or ns.IsLouis)(n) then sendTo(n) return end
      end
    end)
  end)
end)

-- Louis's friends list, on the bot's PC only (Louis, 23 Nov 2026: "can it look at my friends list and help validate
-- mappings?"). A Battle.net friend the game shows on two guild characters in one session is one player. Only that
-- pair of characters is kept (never the friend, the BattleTag or anyone outside the guild), and the bot only checks
-- its own groups against it (identity.friend_check, the GM console): nothing is joined from it.
ns.ID_FRIEND_DAYS = 90      -- a pair not seen again in this long goes
ns.ID_FRIEND_MAX = 200      -- friends looked at
local seenOn = {}           -- this session only: the game's Battle.net account id -> {character = true}
local function friendPairs()
  local t = type(UW_GuildDB.idFriends) == "table" and UW_GuildDB.idFriends or {}
  UW_GuildDB.idFriends = t
  return t
end
local function noteFriend(id, g)
  if id == nil or secret(id) or type(g) ~= "table" or not g.isOnline or g.clientProgram ~= "WoW" then return end
  local project = rawget(_G, "WOW_PROJECT_ID")
  if project and g.wowProjectID and g.wowProjectID ~= project then return end
  local name = g.characterName
  if type(name) ~= "string" or name == "" or secret(name) then return end
  if not ns.REGIONAL and type(g.realmName) == "string" and g.realmName ~= "" and not secret(g.realmName)
    and not name:find("-", 1, true) then
    name = name .. "-" .. g.realmName:gsub("%s", "")
  end
  local full = ns.fullName(name)
  if not full or not ns.inRoster(full) or his(full) then return end
  local short = ns.shortName(full)
  local set = seenOn[id] or {}
  seenOn[id] = set
  if set[short] then return end
  local book_ = friendPairs()
  for other in pairs(set) do
    local a, b = short, other
    if b < a then a, b = b, a end
    book_[a .. ";" .. b] = time()
  end
  set[short] = true
end
function ns.IdentityFriendScan()
  local bn, count = rawget(_G, "C_BattleNet"), rawget(_G, "BNGetNumFriends")
  if not botPC() or type(bn) ~= "table" or type(count) ~= "function" or type(bn.GetFriendAccountInfo) ~= "function" then
    return
  end
  local ok, n = pcall(count)
  n = ok and tonumber(n) or 0
  for i = 1, math.min(n, ns.ID_FRIEND_MAX) do
    local okA, acc = pcall(bn.GetFriendAccountInfo, i)
    if okA and type(acc) == "table" then
      local id = acc.bnetAccountID
      local okN, games = false, 0
      if type(bn.GetFriendNumGameAccounts) == "function" then okN, games = pcall(bn.GetFriendNumGameAccounts, i) end
      if okN and (tonumber(games) or 0) > 0 and type(bn.GetFriendGameAccountInfo) == "function" then
        for j = 1, math.min(tonumber(games), 5) do
          local okG, g = pcall(bn.GetFriendGameAccountInfo, i, j)
          if okG then noteFriend(id, g) end
        end
      else
        noteFriend(id, acc.gameAccountInfo)
      end
    end
  end
  local cutoff, t = time() - ns.ID_FRIEND_DAYS * DAY, friendPairs()
  for k, at in pairs(t) do if type(k) ~= "string" or (tonumber(at) or 0) < cutoff then t[k] = nil end end
end
local friends = CreateFrame("Frame")
ns.listen(friends, { "BN_FRIEND_INFO_CHANGED", "BN_FRIEND_ACCOUNT_ONLINE" })
local scanDue = false
friends:SetScript("OnEvent", ns.guard(function()
  if scanDue or not botPC() then return end
  scanDue = true
  ns.after(10, function() scanDue = false ns.protect(ns.IdentityFriendScan) end)
end))
ns.afterRoster(function() ns.after(30, function() ns.protect(ns.IdentityFriendScan) end) end)
