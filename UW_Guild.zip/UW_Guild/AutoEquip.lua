-- Auto-equip obvious upgrades (Louis, 5 Nov 2026: "can we make the uw addon auto-equip obvious bop upgrades").
-- When a soulbound piece of gear lands in the bags and is plainly better than what the character wears in that slot,
-- UW_Guild puts it on and says so in one line, with /uw gear undo. "Plainly better" is strict dominance, so no stat
-- weights are guessed: same slot, usable now, an armour type the class wears, no main stat the class can't use, a
-- higher item level, and at least every stat the old piece had. Close calls stay the player's.
--
-- Never: in combat or a boss fight, while a loot roll is open (Blizzard's or /uw loot), a Bind on Equip piece (only
-- soulbound or unbindable white and grey items, so nothing new is ever bound), group loot still tradeable to the group
-- (equipping ends its 2-hour trade window, and with it a fair trade: docs/loot.md), trinkets, shirts, tabards, a Use
-- item, replacing a piece with an effect, a weapon of another type or hand, or a slot a saved equipment set holds. A
-- piece the player swaps back is never put on again (UW_GuildCharDB.gearKeep). /uw gear off stops it for the account.
-- A likely upgrade it won't put on by itself (Bind on Equip, a worn effect, a close call) gets one Yes/No question.
--
-- DialogueUI's upgrade popup offers one click by item level alone; this runs before the player sees it, and only
-- for the cases that need no judgement. C_Item.EquipItemByName carries no hardware-event restriction on Forever's
-- client (Blizzard_APIDocumentationGenerated/ItemDocumentation.lua, wow-ui-source branch forever).
local _, ns = ...
local say = ns.say

ns.GEAR_UNDO_SECONDS = 600   -- /uw gear undo works this long after a swap
ns.GEAR_WATCH_SECONDS = 1800 -- a swapped-in piece the player takes off within this long is never put on again

-- equipLoc -> the slots it can go in. Missing = never auto-equipped (trinkets, shirts, tabards, bags, ammo).
local SLOTS = {
  INVTYPE_HEAD = { 1 }, INVTYPE_NECK = { 2 }, INVTYPE_SHOULDER = { 3 }, INVTYPE_CHEST = { 5 }, INVTYPE_ROBE = { 5 },
  INVTYPE_WAIST = { 6 }, INVTYPE_LEGS = { 7 }, INVTYPE_FEET = { 8 }, INVTYPE_WRIST = { 9 }, INVTYPE_HAND = { 10 },
  INVTYPE_FINGER = { 11, 12 }, INVTYPE_CLOAK = { 15 },
  INVTYPE_WEAPON = { 16 }, INVTYPE_2HWEAPON = { 16 }, INVTYPE_WEAPONMAINHAND = { 16 },
  INVTYPE_WEAPONOFFHAND = { 17 }, INVTYPE_SHIELD = { 17 }, INVTYPE_HOLDABLE = { 17 },
  INVTYPE_RANGED = { 18 }, INVTYPE_RANGEDRIGHT = { 18 }, INVTYPE_THROWN = { 18 },
}
local WEAPON, ARMOR = 2, 4
local CLOTH, LEATHER, MAIL, PLATE, SHIELD = 1, 2, 3, 4, 6
local SHIELDS = { WARRIOR = true, PALADIN = true, SHAMAN = true }
-- Armour a class wears for its own sake, for a slot that is empty now (otherwise the worn piece's type decides).
local WEARS = {
  MAGE = { [CLOTH] = true }, PRIEST = { [CLOTH] = true }, WARLOCK = { [CLOTH] = true },
  ROGUE = { [LEATHER] = true }, DRUID = { [LEATHER] = true },
  HUNTER = { [LEATHER] = true, [MAIL] = true }, SHAMAN = { [LEATHER] = true, [MAIL] = true },
  WARRIOR = { [MAIL] = true, [PLATE] = true }, PALADIN = { [MAIL] = true, [PLATE] = true },
}
-- Main stats each class can use; a piece carrying any other main stat is never "obvious" (an Intellect robe for a
-- warrior). Stamina and armour suit everyone.
local MAIN = { "ITEM_MOD_STRENGTH_SHORT", "ITEM_MOD_AGILITY_SHORT", "ITEM_MOD_INTELLECT_SHORT", "ITEM_MOD_SPIRIT_SHORT" }
local USES = {
  WARRIOR = { STRENGTH = true, AGILITY = true }, ROGUE = { AGILITY = true, STRENGTH = true },
  HUNTER = { AGILITY = true, INTELLECT = true }, PALADIN = { STRENGTH = true, INTELLECT = true, SPIRIT = true },
  SHAMAN = { STRENGTH = true, AGILITY = true, INTELLECT = true, SPIRIT = true },
  DRUID = { STRENGTH = true, AGILITY = true, INTELLECT = true, SPIRIT = true },
  MAGE = { INTELLECT = true, SPIRIT = true }, PRIEST = { INTELLECT = true, SPIRIT = true },
  WARLOCK = { INTELLECT = true, SPIRIT = true },
}

local function api(t, k, legacy) return (t and t[k]) or legacy end
-- fn(...) protected, its first result; nil when fn is missing or fails.
local function call(fn, ...)
  if not fn then return nil end
  local ok, v = pcall(fn, ...)
  if ok then return v end
end
local function itemInfo(link)
  local fn = api(C_Item, "GetItemInfo", GetItemInfo)
  if not fn then return nil end
  local r = { pcall(fn, link) }
  if not r[1] or r[2] == nil then return nil end
  return { name = r[2], quality = r[4], ilvl = r[5], req = r[6], loc = r[10], classID = r[13], sub = r[14] }
end
local function itemLevel(link, base)
  local lvl = call(api(C_Item, "GetDetailedItemLevelInfo", rawget(_G, "GetDetailedItemLevelInfo")), link)
  return type(lvl) == "number" and lvl or base
end
local function stats(link)
  local t = call(api(C_Item, "GetItemStats", GetItemStats), link)
  return type(t) == "table" and t or nil
end
local function hasUse(link)
  return call(api(C_Item, "GetItemSpell", rawget(_G, "GetItemSpell")), link) ~= nil
end

-- The tooltip's lines for a bag slot or a worn slot, as text. nil when the client can't say (then nothing is
-- equipped: tradeability and hidden effects are only visible there).
local function tipLines(kind, a, b)
  local tip = rawget(_G, "C_TooltipInfo")
  local fn = tip and tip[kind]
  if not fn then return nil end
  local ok, data = pcall(fn, a, b)
  if not ok or type(data) ~= "table" or type(data.lines) ~= "table" then return nil end
  local out, red = {}, false
  for _, l in ipairs(data.lines) do
    local t = l.leftText
    if type(t) == "string" and not ns.isSecret(t) then out[#out + 1] = t end
    -- Red text is the game saying "you can't use this" (armour type, weapon skill, class, level).
    for _, c in ipairs({ l.leftColor, l.rightColor }) do
      if type(c) == "table" and (c.r or 0) > 0.9 and (c.g or 1) < 0.2 and (c.b or 1) < 0.2 then red = true end
    end
  end
  return out, red
end
local function prefix(global, fallback)
  local s = rawget(_G, global)
  s = type(s) == "string" and s or fallback
  return (s:match("^(.-)%%") or s)
end
-- "You may trade this item with players that were also eligible to loot this item for the next %s." and the
-- effect lines "Equip:", "Use:", "Chance on hit:".
local function flags(lines)
  local trade = prefix("BIND_TRADE_TIME_REMAINING", "You may trade this item with players that were also eligible")
  local triggers = { prefix("ITEM_SPELL_TRIGGER_ONEQUIP", "Equip:"), prefix("ITEM_SPELL_TRIGGER_ONUSE", "Use:"),
    prefix("ITEM_SPELL_TRIGGER_ONPROC", "Chance on hit:") }
  local tradeable, effect = false, false
  for _, t in ipairs(lines) do
    if trade ~= "" and t:find(trade, 1, true) == 1 then tradeable = true end
    for _, p in ipairs(triggers) do if p ~= "" and t:find(p, 1, true) == 1 then effect = true end end
  end
  return tradeable, effect
end

-- "Binds when equipped": equipping it would bind it, which a white or grey piece with no binding never is.
local function bindsOnEquip(lines)
  local boe = prefix("ITEM_BIND_ON_EQUIP", "Binds when equipped")
  for _, t in ipairs(lines) do if boe ~= "" and t:find(boe, 1, true) == 1 then return true end end
  return false
end

-- Armour as the tooltip shows it ("16 Armor"). GetItemStats leaves base armour out on some clients, and then a
-- leather piece with three times the armour of worn cloth looked like no gain at all (Louis, 5 Nov: 16-armour leather
-- boots over 5-armour cloth ones). Adds it to a copy of the stats when missing.
local function withArmor(st, lines)
  if type(lines) ~= "table" then return st end
  local tmpl = rawget(_G, "ARMOR_TEMPLATE")
  local pat = "^" .. (type(tmpl) == "string" and tmpl or "%s Armor"):gsub("%%s", "([%%d,]+)") .. "$"
  for _, t in ipairs(lines) do
    local m = t:match(pat)
    local n = m and tonumber((m:gsub(",", "")))
    if n then
      if st and (st.RESISTANCE0_NAME or 0) > 0 then return st end
      local out = {}
      for k, v in pairs(st or {}) do out[k] = v end
      out.RESISTANCE0_NAME = n
      return out
    end
  end
  return st
end
ns.WithArmor = withArmor

local function classFile()
  local ok, _, file = pcall(UnitClass, "player")
  return ok and type(file) == "string" and file or nil
end

-- Item IDs any saved equipment set holds, in any slot: those slots are the player's to manage.
local function setItems()
  local out = {}
  local es = rawget(_G, "C_EquipmentSet")
  if not (es and es.GetEquipmentSetIDs and es.GetItemIDs) then return out end
  local ok, ids = pcall(es.GetEquipmentSetIDs)
  for _, id in ipairs(ok and type(ids) == "table" and ids or {}) do
    local ok2, items = pcall(es.GetItemIDs, id)
    for slot, item in pairs(ok2 and type(items) == "table" and items or {}) do
      if type(item) == "number" and item > 0 then out[slot] = true; out["i" .. item] = true end
    end
  end
  return out
end

local function idOf(link) return type(link) == "string" and tonumber(link:match("item:(%d+)")) or nil end

-- Can this class wear `new` in place of `old` at all (armour type, main stats, shield, weapon kind)? old may be nil.
function ns.GearFits(class, new, newStats, old)
  if new.quality == nil or (new.quality < 1 and old) then return false end -- grey only ever fills an empty slot
  if new.classID ~= WEAPON and new.classID ~= ARMOR then return false end
  local uses = USES[class]
  if not uses then return false end
  for _, key in ipairs(MAIN) do
    if (newStats[key] or 0) > 0 and not uses[key:match("^ITEM_MOD_(%u+)_SHORT$")] then return false end
  end
  if new.classID == ARMOR and new.sub >= CLOTH and new.sub <= PLATE then
    if old and old.classID == ARMOR and old.sub >= CLOTH and old.sub <= PLATE then
      -- Same armour type as worn, or a step up to the class's own (Louis, 5 Nov: a druid in cloth looted leather);
      -- never down, never past what the class wears.
      if new.sub ~= old.sub and not (new.sub > old.sub and WEARS[class] and WEARS[class][new.sub]) then return false end
    elseif new.loc ~= "INVTYPE_CLOAK" and not (WEARS[class] and WEARS[class][new.sub]) then
      return false
    end
  end
  if new.classID == ARMOR and new.sub == SHIELD and not SHIELDS[class] then return false end
  if new.classID == WEAPON and old then -- an empty hand takes any weapon the class can use (red text is checked first)
    if old.classID ~= WEAPON or old.sub ~= new.sub or old.loc ~= new.loc then return false end
  end
  return true
end

-- Is `new` (item info, stats) plainly better than `old` for this class? old may be nil (empty slot). oldStats nil:
-- by item level alone (for a question, never automatic).
function ns.GearDominates(class, new, newStats, old, oldStats)
  if not ns.GearFits(class, new, newStats, old) then return false end
  if not old then return true end
  -- At least every stat the old piece had and more of something, or the same with a higher item level. A lower item
  -- level only counts when the stats are known (armour included): a druid's leather boots over cloth.
  if (new.ilvl or 0) < (old.ilvl or 0) and not (oldStats and next(oldStats)) then return false end
  local better = (new.ilvl or 0) > (old.ilvl or 0)
  for k, v in pairs(oldStats or {}) do
    if type(v) == "number" and v > 0 and (newStats[k] or 0) < v then return false end
  end
  if oldStats then
    for k, v in pairs(newStats) do
      if type(v) == "number" and v > (oldStats[k] or 0) then better = true end
    end
  end
  return better
end

-- Could this piece be an upgrade? Any slot it fits that's empty, or a worn piece it can replace with an item level no
-- higher (loot: generous, for "never leave it behind"); `strict` (a piece already in the bags, for Delete): a higher
-- item level only, so the piece auto-equip just took off can still go.
function ns.MightUpgrade(link, strict)
  local class = classFile()
  local new = class and itemInfo(link)
  local targets = new and SLOTS[new.loc]
  if not targets or (new.req or 0) > (UnitLevel("player") or 0) then return false end
  new.ilvl = itemLevel(link, new.ilvl)
  local newStats = stats(link) or {}
  for _, target in ipairs(targets) do
    local oldLink = GetInventoryItemLink("player", target)
    local old = oldLink and itemInfo(oldLink)
    if not oldLink then
      if ns.GearFits(class, new, newStats, nil) then return true end
    elseif old then
      old.ilvl = itemLevel(oldLink, old.ilvl)
      local higher = strict and (new.ilvl or 0) > (old.ilvl or 0) or (not strict and (new.ilvl or 0) >= (old.ilvl or 0))
      if ns.GearFits(class, new, newStats, old) and higher then return true end
    end
  end
  return false
end

-- State --------------------------------------------------------------------------------------------------------
local fightDepth, rollsUntil = false, 0 -- a Blizzard loot roll is open until rollsUntil (GetTime())
local lastSwap -- { id, oldLink, slot, at, newLink }
local tried = {} -- item ID -> GetTime() of our last equip attempt, so a refused one isn't retried every bag update
local watched = {} -- slot -> { id, until } for pieces we put on

local function enabled() return UW_GuildDB and UW_GuildDB.gearAuto ~= false end
local function busy()
  if InCombatLockdown() then return "combat" end
  if UnitAffectingCombat and UnitAffectingCombat("player") then return "combat" end
  if fightDepth then return "boss" end
  if GetTime() < rollsUntil or (ns.LootOpen and ns.LootOpen()) then return "roll" end
end

-- Not while a profession window is open (Louis, 13 Nov 2026: ForeverWowCraft in the kit, nothing may interfere). Its
-- Make button, or Create All, crafts piece after piece, and a crafted piece is often an upgrade: a swap or a Yes/No in
-- the middle of that gets in the way of the crafting. The look runs once the window closes (TRADE_SKILL_CLOSE below).
ns.GEAR_CRAFT_FRAMES = { "ProfessionsFrame", "TradeSkillFrame", "CraftFrame" }
local function crafting()
  for _, name in ipairs(ns.GEAR_CRAFT_FRAMES) do
    local fr = rawget(_G, name)
    if type(fr) == "table" and type(fr.IsShown) == "function" then
      local ok, shown = pcall(fr.IsShown, fr)
      if ok and shown == true then return true end
    end
  end
  return false
end
ns.GearCrafting = crafting

-- The best obvious upgrade in the bags: { bag, slot, link, target, oldLink, new, old }, or nil; then the best likely
-- upgrade to ask about (Louis, 5 Nov: "upgrades looted aren't offering equip cues"): a higher item level for a slot
-- the class can use, same armour type, no unusable main stat, but Bind on Equip, with an effect, or not plainly better.
function ns.FindGearUpgrade()
  local class = classFile()
  if not class or not C_Container or not C_Container.GetContainerItemInfo then return nil end
  local myLevel = UnitLevel("player") or 0
  local keep, sets = UW_GuildCharDB.gearKeep or {}, setItems()
  local best, cue
  for bag = 0, NUM_BAG_SLOTS or 4 do
    for slot = 1, C_Container.GetContainerNumSlots(bag) or 0 do
      local ok, c = pcall(C_Container.GetContainerItemInfo, bag, slot)
      local link = ok and type(c) == "table" and c.hyperlink
      local id = link and idOf(link)
      -- Soulbound, or (Louis, 5 Nov: "auto equip bop white grey items in empty slots") a plain white or grey piece
      -- with no binding at all, for an empty slot only.
      local loose = id and not c.isBound and (c.quality or 9) <= 1
      local auto = c and (c.isBound or loose)
      if id and not c.isLocked and not keep[id] then
        local new = itemInfo(link)
        local targets = new and SLOTS[new.loc]
        if targets and (new.req or 0) <= myLevel and not hasUse(link) then
          new.ilvl = itemLevel(link, new.ilvl)
          local lines, red = tipLines("GetBagItem", bag, slot)
          local tradeable = lines and (flags(lines)) or false
          -- Never by itself: an unreadable tooltip, red text (unusable), a refused try, or Bind on Equip (Louis, 5 Nov:
          -- "obvious upgrades shouldn't need space to equip - just do it but not if boe"). An Equip: or Chance on hit:
          -- line on the new piece is a bonus, not a reason to ask.
          local hold = not lines or red or (tried[id] and GetTime() - tried[id] < 60) or bindsOnEquip(lines)
          local newStats = withArmor(stats(link) or (loose and {}) or nil, lines)
          local autoOk = auto and newStats and not tradeable and not hold
          -- A cue (asked, never automatic): Bind on Equip, losing a worn effect, or a close call. Not red, not group loot.
          local cueOk = lines and not tradeable and not red and not (tried[id] and GetTime() - tried[id] < 60)
          if autoOk or cueOk then
            for _, target in ipairs(targets) do
              local oldLink = GetInventoryItemLink("player", target)
              local oldId = idOf(oldLink)
              local old, oldStats, oldOk = nil, nil, true
              if oldLink then
                old = itemInfo(oldLink)
                oldStats = stats(oldLink) or ((old and (old.quality or 9) <= 1) and {} or nil) -- a white has none
                local oldLines = tipLines("GetInventoryItem", "player", target)
                oldStats = withArmor(oldStats, oldLines)
                local _, oldEffect = false, true
                if oldLines then _, oldEffect = flags(oldLines) end
                oldOk = old and oldStats and not oldEffect and not hasUse(oldLink)
                if old then old.ilvl = itemLevel(oldLink, old.ilvl) end
              end
              local inSet = sets[target] or (oldId and sets["i" .. oldId])
              local otherRing = target == 11 and idOf(GetInventoryItemLink("player", 12))
                or target == 12 and idOf(GetInventoryItemLink("player", 11))
              -- Hands: a two-hander never pushes off a held off-hand, and nothing goes into the off-hand of a two-hander.
              local mainLoc = target == 17 and (itemInfo(GetInventoryItemLink("player", 16) or "") or {}).loc
              -- An off-hand weapon needs Dual Wield (warriors and hunters from 20, rogues from 10), or equipping fails.
              local dualWield = rawget(_G, "CanDualWield")
              local blocked = (new.loc == "INVTYPE_2HWEAPON" and GetInventoryItemLink("player", 17) ~= nil)
                or mainLoc == "INVTYPE_2HWEAPON"
                or (target == 17 and new.classID == WEAPON and dualWield ~= nil and not call(dualWield))
              local free = not inSet and not blocked and otherRing ~= id and oldId ~= id
              local gain = (new.ilvl or 0) - (old and old.ilvl or 0)
              local found = { bag = bag, slot = slot, link = link, id = id, target = target, oldLink = oldLink,
                new = new, old = old, gain = gain, binds = not c.isBound and lines and bindsOnEquip(lines) }
              if free and autoOk and oldOk
                and ns.GearDominates(class, new, newStats, old, oldStats) then
                if not best or gain > best.gain then best = found end
              elseif free and cueOk
                and (ns.GearDominates(class, new, newStats or {}, old, nil)
                  or ns.GearDominates(class, new, newStats or {}, old, oldStats)
                  or (old and ns.GearFits(class, new, newStats or {}, old)
                    and ((newStats or {}).RESISTANCE0_NAME or 0) > ((oldStats or {}).RESISTANCE0_NAME or 0) * 1.5)) then
                if not cue or gain > cue.gain then cue = found end
              end
            end
          end
        end
      end
    end
  end
  return best, cue
end

local function equip(link, slot)
  local fn = api(C_Item, "EquipItemByName", rawget(_G, "EquipItemByName"))
  if not fn then return false end
  return (pcall(fn, link, slot))
end

-- Also on screen, in the game's own centre text (Louis, 5 Nov: a cloak went on "without a notification"; the chat
-- line is easy to miss while playing).
local function notice(msg)
  say(msg)
  local frame = rawget(_G, "UIErrorsFrame")
  if type(frame) == "table" and type(frame.AddMessage) == "function" then
    pcall(frame.AddMessage, frame, "UW: " .. msg, 1, 0.82, 0)
  end
end

local function tellFirst()
  if UW_GuildDB.gearAutoTold then return end
  if ns.TellNew("clear gear upgrades go on by themselves. Never in combat, in a loot roll, or with tradeable loot. "
    .. "/uw gear off turns it off.", true) then UW_GuildDB.gearAutoTold = time() end
end

local asked = {} -- item ID -> true: asked about once this session

local function putOn(up)
  tried[up.id] = GetTime()
  if not equip(up.link, up.target) then return false end
  lastSwap = { id = up.id, oldLink = up.oldLink, slot = up.target, at = GetTime(), newLink = up.link }
  watched[up.target] = { id = up.id, ["until"] = GetTime() + ns.GEAR_WATCH_SECONDS }
  return true
end

-- A likely upgrade it won't put on by itself: one question. Yes puts it on (the game asks once more if it binds);
-- No never asks about that item again on this character.
local function askCue(up)
  if not up or asked[up.id] or (UW_GuildCharDB.gearNoCue or {})[up.id] or not ns.KitConfirm then return end
  asked[up.id] = true
  -- Only the No button means "never": a question replaced by the next one, or closed with Esc, just asks again
  -- next session (the game's popup would otherwise run OnCancel for both).
  local dialogs = rawget(_G, "StaticPopupDialogs")
  if type(dialogs) == "table" then
    dialogs.UW_GUILD_GEAR = dialogs.UW_GUILD_GEAR or { text = "%s", button1 = YES or "Yes", button2 = NO or "No",
      OnAccept = function(_, data) if data and data.yes then data.yes() end end,
      OnCancel = function(_, data, reason) if reason == "clicked" and data and data.no then data.no() end end,
      noCancelOnReuse = true, noCancelOnEscape = true,
      timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3 }
  end
  local was = up.old and ("you wear %s (%d)"):format(up.oldLink, up.old.ilvl or 0) or "the slot is empty"
  ns.KitConfirm(("Upgrade? %s, item level %d; %s.%s Put it on?"):format(up.link, up.new.ilvl or 0, was,
    up.binds and " It binds to you." or ""), function()
    if busy() then say("After combat, please: open your bags and put it on.") return end
    if putOn(up) then notice(("Put on %s. /uw gear undo swaps back."):format(up.link)) end
  end, function()
    UW_GuildCharDB.gearNoCue = UW_GuildCharDB.gearNoCue or {}
    UW_GuildCharDB.gearNoCue[up.id] = true
  end, "UW_GUILD_GEAR")
end

-- An upgrade waiting for an answer is never auto-sold (Louis, 5 Nov: EnhanceQoL's Vendor sold leather boots that
-- were an upgrade). EnhanceQoL skips anything on its own exclude list; we add the waiting piece there and take off
-- again only what we added, once it's worn, declined or gone. EnhanceQoL.db is its active profile, a plain table
-- (EnhanceQoLDB.profiles[name]), and vendorExcludeSellList holds id -> item name (EnhanceQoLVendor/Settings_Vendor.lua).
local function inBags(id)
  for bag = 0, NUM_BAG_SLOTS or 4 do
    for slot = 1, C_Container.GetContainerNumSlots(bag) or 0 do
      local ok, c = pcall(C_Container.GetContainerItemInfo, bag, slot)
      if ok and type(c) == "table" and c.hyperlink and idOf(c.hyperlink) == id then return true end
    end
  end
  return false
end
local function guardVendor(waiting)
  local eq = rawget(_G, "EnhanceQoL")
  local list = type(eq) == "table" and type(eq.db) == "table" and eq.db.vendorExcludeSellList
  if type(list) ~= "table" then return end
  local held = UW_GuildCharDB.vendorHeld or {}
  UW_GuildCharDB.vendorHeld = held
  local no = UW_GuildCharDB.gearNoCue or {}
  for _, up in ipairs(waiting) do
    -- EnhanceQoL stores id -> item name and prints the name in its options list (a non-string breaks its format).
    if not list[up.id] and not no[up.id] then
      list[up.id] = (up.new and up.new.name) or ("Item #" .. up.id); held[up.id] = true
    end
  end
  for id in pairs(held) do
    if list[id] == true then list[id] = "Item #" .. id end -- written by the first version (#287): a name, as EnhanceQoL keeps
    local still = false
    for _, up in ipairs(waiting) do if up.id == id then still = true end end
    if no[id] or (not still and not inBags(id)) then list[id] = nil; held[id] = nil end
  end
end
ns.GuardVendor = guardVendor

function ns.TryGearUpgrade()
  if not enabled() or busy() or crafting() then return end
  local up, cue = ns.FindGearUpgrade()
  local waiting = {}
  if up then waiting[#waiting + 1] = up end
  if cue then waiting[#waiting + 1] = cue end
  pcall(guardVendor, waiting)
  if not up then askCue(cue) return end
  if not putOn(up) then return end
  tellFirst()
  if up.old then
    notice(("Put on %s (ilvl %d), was %s (%d). /uw gear undo swaps back.")
      :format(up.link, up.new.ilvl or 0, up.oldLink, up.old.ilvl or 0))
  else
    notice(("Put on %s in an empty slot. /uw gear undo takes it off."):format(up.link))
  end
end

-- The piece /uw gear undo would put back, while undo still works: nothing may delete it.
function ns.GearUndoId()
  if not lastSwap or GetTime() - lastSwap.at > ns.GEAR_UNDO_SECONDS then return nil end
  return idOf(lastSwap.oldLink)
end

local function keepOff(id)
  UW_GuildCharDB.gearKeep = UW_GuildCharDB.gearKeep or {}
  UW_GuildCharDB.gearKeep[id] = true
end

ns.commands.gear = function(args)
  local sub = strtrim(args or ""):lower()
  if sub == "off" then
    UW_GuildDB.gearAuto = false
    say("Auto-equip is off on this account. /uw gear on turns it back on.")
  elseif sub == "on" then
    UW_GuildDB.gearAuto = nil
    say("Auto-equip is on. Clear upgrades go on by themselves, with a line here each time.")
    ns.protect(ns.TryGearUpgrade)
  elseif sub == "undo" then
    if not lastSwap or GetTime() - lastSwap.at > ns.GEAR_UNDO_SECONDS then
      say("Nothing to undo in the last 10 minutes.") return
    end
    if InCombatLockdown() then say("After combat, please: /uw gear undo") return end
    keepOff(lastSwap.id)
    watched[lastSwap.slot] = nil
    if lastSwap.oldLink then
      equip(lastSwap.oldLink, lastSwap.slot)
      say(("Swapped back to %s. %s won't go on by itself again."):format(lastSwap.oldLink, lastSwap.newLink))
    else
      local unequip = rawget(_G, "PickupInventoryItem") and rawget(_G, "PutItemInBackpack")
      if unequip then pcall(PickupInventoryItem, lastSwap.slot); pcall(PutItemInBackpack) end
      say(("Took off %s. It won't go on by itself again."):format(lastSwap.newLink))
    end
    lastSwap = nil
  else
    say(("Auto-equip is %s. /uw gear on, off, or undo (within 10 minutes).")
      :format(enabled() and "on" or "off"))
  end
end

-- A piece we put on that the player takes off soon after is theirs to decide: never again.
local function onEquipmentChanged(slot)
  local w = watched[slot]
  if not w then return end
  if GetTime() > w["until"] then watched[slot] = nil return end
  if idOf(GetInventoryItemLink("player", slot)) ~= w.id then keepOff(w.id); watched[slot] = nil end
end

table.insert(ns.onLoad, function()
  UW_GuildCharDB.gearKeep = UW_GuildCharDB.gearKeep or {}
end)

-- DialogueUI's "Valuable Reward Popup" offers Space to equip any looted piece with a higher item level (Louis, 5 Nov:
-- "the addon still pops up with the 'hit space to equip' cue but isn't that irrelevant because it's automated now?").
-- With auto-equip on, gear is ours: obvious upgrades go on, Bind on Equip and close calls get one Yes/No (Louis: "boes
-- need a confirmation because that'd be an expensive mistake"), so its equip button is closed as it shows. Chests,
-- mounts and cosmetics keep it. Its button has no name (DialogueUI Code/Widget/Widget_QuickSlot.lua), so it's found
-- by its methods once DialogueUI has made it.
local duiButton, duiLastScan, duiScans = nil, -60, 0
local duiPending -- a button that showed in a fight: closed when it ends (DialogueUI's own secure calls wait for that too)
local function closeDialogueGear(btn)
  if not (enabled() and btn.type == "equip" and btn.hasData) then return end
  if InCombatLockdown() then duiPending = btn return end
  pcall(btn.ClearButton, btn)
end
ns.CloseDialogueGearPending = function()
  local btn = duiPending
  duiPending = nil
  if btn then closeDialogueGear(btn) end
end
local function hushDialogueGear()
  -- At most 20 looks a session: with its popup turned off, DialogueUI never makes the button.
  if duiButton or duiScans >= 20 or not rawget(_G, "DUIQuestFrame") or GetTime() - duiLastScan < 5 then return end
  duiLastScan, duiScans = GetTime(), duiScans + 1
  local enum = rawget(_G, "EnumerateFrames")
  if type(enum) ~= "function" then return end
  local fr = enum()
  while fr do
    if type(fr) == "table" and type(fr.SetEquipItem) == "function" and type(fr.OnItemEquipped) == "function"
      and type(fr.ClearButton) == "function" and type(fr.HookScript) == "function" then
      duiButton = fr
      fr:HookScript("OnShow", function(self) ns.after(0, function() closeDialogueGear(self) end) end)
      return
    end
    fr = enum(fr)
  end
end
ns.HushDialogueGear = hushDialogueGear

local f = CreateFrame("Frame")
ns.listen(f, { "CHAT_MSG_LOOT", "QUEST_TURNED_IN", "BAG_UPDATE_DELAYED", "PLAYER_REGEN_ENABLED", "ENCOUNTER_START", "ENCOUNTER_END", "START_LOOT_ROLL",
  "CANCEL_ALL_LOOT_ROLLS", "PLAYER_EQUIPMENT_CHANGED", "PLAYER_LEVEL_UP", "PLAYER_ENTERING_WORLD",
  "TRADE_SKILL_CLOSE", "CRAFT_CLOSE" })
local soon = false
f:SetScript("OnEvent", ns.guard(function(_, event, a, b)
  if event == "CHAT_MSG_LOOT" or event == "QUEST_TURNED_IN" then -- DialogueUI makes its button on the first one
    ns.after(0.2, function() ns.protect(hushDialogueGear) end)
    return
  end
  if event == "ENCOUNTER_START" then fightDepth = true return end
  if event == "ENCOUNTER_END" then fightDepth = false end
  if event == "START_LOOT_ROLL" then -- rollID, rollTime in ms: a roll window can't outlast its own timer
    local ms = tonumber(b) or 0
    rollsUntil = math.max(rollsUntil, GetTime() + math.min(math.max(ms / 1000, 0), 300) + 5)
    return
  end
  if event == "CANCEL_ALL_LOOT_ROLLS" then rollsUntil = 0 end
  if event == "PLAYER_EQUIPMENT_CHANGED" then ns.protect(onEquipmentChanged, a) return end
  if event == "PLAYER_REGEN_ENABLED" then ns.protect(ns.CloseDialogueGearPending) end
  if soon or not UW_GuildDB or not UW_GuildCharDB then return end
  soon = true
  -- At login or /reload the whole bags are checked, not only what changes (item data may still be loading: 3 s).
  ns.after(event == "PLAYER_ENTERING_WORLD" and 3 or 1, function()
    soon = false
    ns.protect(ns.TryGearUpgrade)
  end)
end))
