-- The guild look (Louis, 5 Nov 2026: "help newbies get their UI like mine"). EllesmereUI travels as a shared layout
-- (KitShare.lua, /uw kit layout); DialogueUI has no import string, so its settings ship here, as Louis set them on his
-- character Veda Skyseer: the dark theme and his tweaks, each one a key of DialogueUI's own saved table
-- (DialogueUI_DB, read from DialogueUI 1.0.7's Initialization.lua and Settings.lua). /uw kit look sets them after a
-- yes, and the addon reads them at the next reload. Never on its own: a member who says no keeps their own settings
-- and isn't asked again. Only listed keys change; nothing is deleted. docs/addon-pack.md lists the same settings.
-- Questie (Louis, 5 Nov: DialogKey out, Questie's own Auto on): accept quests and hand in finished ones, read from
-- Questie 12.6.0's QuestieOptionsDefaults.lua (autocomplete, autoAccept.enabled; holding Shift pauses both). A look
-- names its saved table by global (db) or by a function (tbl) for an AceDB profile; "a.b" keys reach nested tables.
-- Manners (Louis, 5 Nov: its default Glass prompt clashes with EllesmereUI's flat look): the Luxe panel and calm
-- effects (no animations), keys prompt.style and prompt.effects of Manners 1.11.1's AceDB profile (Core.lua).
local _, ns = ...
local say = ns.say

ns.KIT_LOOKS = {
  {
    addon = "DialogueUI", db = "DialogueUI_DB",
    what = "dark theme, small window, no camera moves, clearer quest types and rewards",
    set = {
      Theme = 2,                    -- Theme: 1 Brown, 2 Dark
      FrameSize = 1,                -- Frame Size: 0 Extra Small, 1 Small, 2 Medium, 3 Large
      CameraMovement = 0,           -- Camera Movement: 0 Off, 1 Zoom In, 2 Horizontal
      DisableUIMotion = true,       -- Reduce UI Movements
      ShowChatWindow = false,       -- NPC Chat Window
      QuestTypeText = true,         -- Show Quest Type Text
      QuestDifficultyStyle = 2,     -- Quest Difficulty: 1 Level, 2 Name
      SimplifyCurrencyReward = true,
      MarkHighestSellPrice = true,
      QuickSlotQuestReward = true,  -- Valuable Reward Popup
      QuestItemDisplay = true,      -- Quest Item Display
      AutoSelectGossip = true,      -- Auto Select Option
      AutoCompleteQuest = true,     -- Auto Complete Quest
      BookShowLocation = true,      -- books: show where it was found
      BookDarkenScreen = false,     -- books: don't darken the screen
    },
  },
  {
    addon = "Questie",
    tbl = function()
      local q = rawget(_G, "Questie")
      return type(q) == "table" and type(q.db) == "table" and q.db.profile or nil
    end,
    what = "auto accept and hand-in (hold Shift to skip), a short clean tracker in EllesmereUI's font, no nameplate icons",
    set = {
      autocomplete = true,            -- Auto complete (hand in)
      ["autoAccept.enabled"] = true,  -- Auto accept
      nameplateEnabled = false,       -- no sword/objective icon beside nameplates (Louis, 5 Nov); map areas stay
      nameplateTargetFrameEnabled = false, -- nor on the target frame
      -- The clean tracker (Louis, 8 Nov), keys from Questie 12.6's QuestieOptionsDefaults.lua. "Expressway" is the
      -- font EllesmereUI registers with LibSharedMedia (EllesmereUI_Fonts.lua), so it matches the rest of the UI.
      trackerFontHeader = "Expressway", trackerFontZone = "Expressway",
      trackerFontQuest = "Expressway", trackerFontObjective = "Expressway",
      trackerFontSizeHeader = 12, trackerFontSizeZone = 11, trackerFontSizeQuest = 11, trackerFontSizeObjective = 10,
      trackerHeaderEnabled = false,   -- no "Questie Tracker: n/40" line
      trackerShowQuestFocusButtons = false, trackerShowPlayButtons = false,
      trackerFadeMinMaxButtons = true,
      trackerSortObjectives = "byZonePlayerProximity", -- nearest zone first
      trackerHeightRatio = 0.3,       -- at most 30% of the screen (default 50%)
      collapseCompletedQuests = true, hideCompletedQuestObjectives = true,
      globalMiniMapScale = 0.6,       -- smaller minimap icons (default 0.7)
      alwaysGlowMinimap = false,      -- no glow behind minimap icons
    },
  },
  {
    addon = "Manners",
    tbl = function()
      local stub = rawget(_G, "LibStub")
      local ace = stub and stub("AceAddon-3.0", true)
      local m = ace and ace:GetAddon("Manners", true)
      return type(m) == "table" and type(m.db) == "table" and m.db.profile or nil
    end,
    what = "the plain Luxe panel with calm effects, to match EllesmereUI",
    set = {
      ["prompt.style"] = "luxe",      -- Panel style (default Glass)
      ["prompt.effects"] = "calm",    -- Calm: less movement (default Full)
    },
  },
}

local function lookDb(look)
  local db
  if look.tbl then
    local ok, t = pcall(look.tbl)
    db = ok and t or nil
  else
    db = rawget(_G, look.db)
  end
  return type(db) == "table" and db or nil
end

-- "a.b" reads db.a.b; set makes db.a when it's missing.
local function getKey(db, key)
  local t = db
  for part in key:gmatch("[^.]+") do
    if type(t) ~= "table" then return nil end
    t = t[part]
  end
  return t
end
local function setKey(db, key, v)
  local t, last = db, nil
  for part in key:gmatch("[^.]+") do
    if last then
      if type(t[last]) ~= "table" then t[last] = {} end
      t = t[last]
    end
    last = part
  end
  t[last] = v
end

-- The keys this character's copy doesn't have yet, sorted; nil when the addon isn't loaded or has no settings yet.
function ns.KitLookDiff(look)
  if not ns.isLoaded(look.addon) then return nil end
  local db = lookDb(look)
  if not db then return nil end
  local diff = {}
  for k, v in pairs(look.set) do if getKey(db, k) ~= v then diff[#diff + 1] = k end end
  table.sort(diff)
  return diff
end

local function declined()
  if type(UW_GuildDB) ~= "table" then return {} end
  UW_GuildDB.lookDeclined = type(UW_GuildDB.lookDeclined) == "table" and UW_GuildDB.lookDeclined or {}
  return UW_GuildDB.lookDeclined
end

local function offer(list, i)
  local look = list[i]
  if not look then return end
  local diff = ns.KitLookDiff(look)
  if not diff or #diff == 0 then return offer(list, i + 1) end
  ns.KitConfirm(("Use the guild's look for %s (%s)? It changes %d of its settings; everything else stays yours.")
    :format(look.addon, look.what, #diff), function()
      local db = lookDb(look)
      if not db then return end
      for _, k in ipairs(diff) do setKey(db, k, look.set[k]) end
      declined()[look.addon] = nil
      ns.KitConfirm(look.addon .. " now uses the guild look. Reload now so it takes effect?", function() ReloadUI() end,
        function() say("It takes effect at your next /reload or login.") end, "UW_GUILD_RELOAD")
    end, function()
      declined()[look.addon] = true
      say(("Kept your own %s settings. /uw kit look asks again whenever you like."):format(look.addon))
      offer(list, i + 1)
    end)
end

ns.kitCommands.look = function()
  if InCombatLockdown() then say("After combat, please: /uw kit look") return end
  local any, due = false, false
  for _, look in ipairs(ns.KIT_LOOKS) do
    local diff = ns.KitLookDiff(look)
    if diff then
      any = true
      if #diff > 0 then due = true
      else say(("%s already uses the guild look."):format(look.addon)) end
    end
  end
  if not any then
    local names = {}
    for _, look in ipairs(ns.KIT_LOOKS) do names[#names + 1] = look.addon end
    say(("The guild look is for %s, which isn't on here. /uw kit list shows the kit."):format(table.concat(names, ", ")))
    return
  end
  if due then offer(ns.KIT_LOOKS, 1) end
end

-- One line in /uw kit (not at login) while a look is due and the member hasn't said no to it.
local hints = ns.KitHints
ns.KitHints = function(quiet)
  if hints then hints(quiet) end
  if quiet then return end
  local due = {}
  for _, look in ipairs(ns.KIT_LOOKS) do
    local diff = ns.KitLookDiff(look)
    if diff and #diff > 0 and not declined()[look.addon] then due[#due + 1] = look.addon end
  end
  if #due > 0 then say(("|cffffd100Guild look|r for %s: /uw kit look"):format(table.concat(due, " and "))) end
end
