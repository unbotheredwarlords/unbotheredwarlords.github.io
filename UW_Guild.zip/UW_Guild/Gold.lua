-- /uw gold (Louis, 16 Nov 2026: "What else can you do within TOS to automate and inform gold making?"; built for his
-- own characters only, the bot's PC, never for members). Advice only: it reads, prints to this client's chat, and never
-- buys, posts, sells or mails. Every action at the auction house stays his own click, in Auctionator.
--
-- What it says, for the character he is on, with his other characters on one line after:
--   * each gathering profession at its skill: the three mats that skill gathers worth most at today's prices, and
--     the next mat above it when that one is worth more (how far to level before farming pays better);
--   * the market: how far asking prices across his whole scan moved since the first day Auctionator kept, so he knows
--     whether to sell what he gathers soon or hold it.
-- Where the numbers come from: Auctionator's own price history on this client (Auctionator.Database, the realm it
-- keeps; read-only and protected: a missing or changed shape is "no data", never an error). These are asks, not
-- sales, and the lines say so. A mat's price is the median of the lowest asks on the last three days it was seen. Skills come from UW_GuildDB.crafts (Crafts.lua).
--
-- What was left out, from his scan of 16 Nov 00:00 UTC (6,798 items over 11 days), so nothing here repeats his pack:
--   * craft or sell: Auctionator already shows each recipe's cost and profit on the profession window (its
--     crafting info is on in his settings), and none of his alchemy or cooking recipes beat selling the mats by
--     more than a few silver that day;
--   * a post-ready bag: Auctionator's Selling tab lists the bags with its undercut price, one key a post;
--   * a buy-under-vendor list: 207 items were listed under vendor price, worth 12 silver together;
--   * the guild bank's keep-or-sell list: the guild bank thread's (Bank.lua), which calls ns.ItemWorth.
local _, ns = ...
local say = ns.say

local function g(name) return rawget(_G, name) end
local function call(fn, ...)
  if type(fn) ~= "function" then return nil end
  local ok, a, b = pcall(fn, ...)
  if ok then return a, b end
end

-- What a skill gathers, lowest first: { item id, the skill it needs, its English name for a client that has not
-- loaded the item yet }. Herb and ore skills are the game's own (warcraft.wiki.gg, "Herbalism" and "Mining": the
-- node's required skill). Skinning has no node: a beast of level L needs skill 5 x L from level 20 (10 x (L - 10)
-- below), so a leather is listed at the skill of the lowest beasts that drop it. Forever's own herbs (Marefoil,
-- Demonsage, Stranglevine) are left out until their skill is known. Fishing is left out: the fish he can catch sell
-- for a copper or two.
ns.GOLD_GATHER = {
  Herbalism = {
    { 2447, 1, "Peacebloom" }, { 765, 1, "Silverleaf" }, { 2449, 15, "Earthroot" }, { 785, 50, "Mageroyal" },
    { 2450, 70, "Briarthorn" }, { 3820, 85, "Stranglekelp" }, { 2453, 100, "Bruiseweed" },
    { 3355, 115, "Wild Steelbloom" }, { 3369, 120, "Grave Moss" }, { 3356, 125, "Kingsblood" },
    { 3357, 150, "Liferoot" }, { 3818, 160, "Fadeleaf" }, { 3821, 170, "Goldthorn" },
    { 3358, 185, "Khadgar's Whisker" }, { 3819, 195, "Wintersbite" }, { 4625, 205, "Firebloom" },
    { 8831, 210, "Purple Lotus" }, { 8836, 220, "Arthas' Tears" }, { 8838, 230, "Sungrass" },
    { 8839, 235, "Blindweed" }, { 8845, 245, "Ghost Mushroom" }, { 8846, 250, "Gromsblood" },
    { 13464, 260, "Golden Sansam" }, { 13463, 270, "Dreamfoil" }, { 13465, 280, "Mountain Silversage" },
    { 13466, 285, "Plaguebloom" }, { 13467, 290, "Icecap" }, { 13468, 300, "Black Lotus" },
  },
  Mining = {
    { 2770, 1, "Copper Ore" }, { 2835, 1, "Rough Stone" }, { 2771, 65, "Tin Ore" }, { 2836, 65, "Coarse Stone" },
    { 2775, 75, "Silver Ore" }, { 2772, 125, "Iron Ore" }, { 2838, 125, "Heavy Stone" }, { 2776, 155, "Gold Ore" },
    { 3858, 175, "Mithril Ore" }, { 7912, 175, "Solid Stone" }, { 7911, 230, "Truesilver Ore" },
    { 11370, 230, "Dark Iron Ore" }, { 10620, 245, "Thorium Ore" }, { 12365, 245, "Dense Stone" },
  },
  Skinning = {
    { 2934, 1, "Ruined Leather Scraps" }, { 2318, 1, "Light Leather" }, { 783, 1, "Light Hide" },
    { 2319, 100, "Medium Leather" }, { 4232, 100, "Medium Hide" }, { 4234, 150, "Heavy Leather" },
    { 4235, 150, "Heavy Hide" }, { 4304, 200, "Thick Leather" }, { 8169, 200, "Thick Hide" },
    { 8170, 250, "Rugged Leather" }, { 8171, 250, "Rugged Hide" },
  },
}
ns.GOLD_ORDER = { "Herbalism", "Mining", "Skinning" }
ns.GOLD_TOP, ns.GOLD_DAYS, ns.GOLD_TREND_MIN_DAYS = 3, 3, 6

-- Only on the bot's PC: Louis plays all his characters there and members never get it.
function ns.GoldHere() return ns.SyncBotPC ~= nil and ns.SyncBotPC() == true end

-- A price we can act on: a finite, positive copper amount under the bad-row cap Items.lua uses.
local function price(v)
  return type(v) == "number" and not ns.isSecret(v) and v == v and v > 0 and v <= ns.DE_PRICE_MAX and v or nil
end

-- Auctionator's history table for this realm, or nil.
local function history()
  local auc = g("Auctionator")
  local d = type(auc) == "table" and auc.Database
  return type(d) == "table" and type(d.db) == "table" and d.db or nil
end

-- { [day number] = the lowest ask that day } for one item's history row, from Auctionator's l (lowest) and h (the
-- day's highest lowest, which stands alone when the day had one price).
local function dailyLows(row)
  local out, n = {}, 0
  if type(row) ~= "table" or type(row.h) ~= "table" then return out, 0 end
  local l = type(row.l) == "table" and row.l or {}
  for day, high in pairs(row.h) do
    local d, v = tonumber(day), price(l[day]) or price(high)
    if d and v then out[d], n = v, n + 1 end
  end
  return out, n
end

local function median(t)
  if #t == 0 then return nil end
  table.sort(t)
  local m = math.floor((#t + 1) / 2)
  return #t % 2 == 1 and t[m] or math.floor((t[m] + t[m + 1]) / 2)
end

-- An item's price today: the median of its lowest asks on the last GOLD_DAYS days it was seen, or nil.
function ns.GoldPrice(id, db)
  db = db or history()
  if not db then return nil end
  local lows = dailyLows(db[tostring(id)])
  local days = {}
  for d in pairs(lows) do days[#days + 1] = d end
  table.sort(days, function(a, b) return a > b end)
  local last = {}
  for i = 1, math.min(ns.GOLD_DAYS, #days) do last[#last + 1] = lows[days[i]] end
  return median(last)
end

-- The market: the median across items seen on at least GOLD_TREND_MIN_DAYS days of (lowest ask on the newest day
-- seen) / (median of the first three days seen). Returns that ratio, the items counted and the span in days.
function ns.GoldTrend(db)
  db = db or history()
  if not db then return nil end
  local ratios, first, last = {}, nil, nil
  for _, row in pairs(db) do
    local lows, n = dailyLows(row)
    if n >= ns.GOLD_TREND_MIN_DAYS then
      local days = {}
      for d in pairs(lows) do days[#days + 1] = d end
      table.sort(days)
      local base = median({ lows[days[1]], lows[days[2]], lows[days[3]] })
      if base then
        ratios[#ratios + 1] = lows[days[#days]] / base
        first = math.min(first or days[1], days[1])
        last = math.max(last or days[#days], days[#days])
      end
    end
  end
  if #ratios == 0 then return nil end
  table.sort(ratios)
  return ratios[math.floor((#ratios + 1) / 2)], #ratios, last - first
end

local function money(c)
  local currency = g("C_CurrencyInfo")
  local fmt = g("GetCoinTextureString") or (currency and currency.GetCoinTextureString)
  return call(fmt, c) or (c .. "c")
end

local function itemName(id, fallback)
  local items = g("C_Item")
  local name = call(items and items.GetItemInfo or g("GetItemInfo"), id)
  return type(name) == "string" and not ns.isSecret(name) and name or fallback
end

-- One profession at one skill: { top = { {name, copper}, ... up to GOLD_TOP }, next = {name, copper, skill} or nil }.
function ns.GoldFarm(prof, skill, db)
  local list = ns.GOLD_GATHER[prof]
  db = db or history()
  if not list or not db or type(skill) ~= "number" then return nil end
  local have, best = {}, 0
  for _, m in ipairs(list) do
    local p = m[2] <= skill and ns.GoldPrice(m[1], db)
    if p then have[#have + 1] = { itemName(m[1], m[3]), p } end
  end
  table.sort(have, function(a, b) return a[2] > b[2] end)
  local top = {}
  for i = 1, math.min(ns.GOLD_TOP, #have) do top[i] = have[i]; best = math.max(best, have[i][2]) end
  local nxt
  for _, m in ipairs(list) do
    if m[2] > skill then
      local p = ns.GoldPrice(m[1], db)
      if p and p > best then nxt = { itemName(m[1], m[3]), p, m[2] }; break end
    end
  end
  return { top = top, next = nxt }
end

-- This character's gathering skills, from what Crafts.lua keeps: { {prof, rank}, ... } in GOLD_ORDER.
-- Crafts.lua keys them by the short name; ns.me() and UW_GuildDB.alts carry the realm on a regional client.
local function short(name) return ns.shortName and ns.shortName(name) or name end
local function skillsOf(name)
  local all = type(UW_GuildDB) == "table" and type(UW_GuildDB.crafts) == "table" and UW_GuildDB.crafts or {}
  local crafts = all[short(name)] or all[name]
  local profs = type(crafts) == "table" and type(crafts.profs) == "table" and crafts.profs or {}
  local out = {}
  for _, prof in ipairs(ns.GOLD_ORDER) do
    local p = profs[prof]
    local r = type(p) == "table" and tonumber(p.r)
    if r then out[#out + 1] = { prof, r } end
  end
  return out
end

local function farmLine(prof, rank, db)
  local f = ns.GoldFarm(prof, rank, db)
  if not f or #f.top == 0 then return nil end
  local parts = {}
  for _, m in ipairs(f.top) do parts[#parts + 1] = m[1] .. " " .. money(m[2]) end
  local line = ("%s %d: %s, lowest ask each."):format(prof, rank, table.concat(parts, ", "))
  if f.next then line = line .. (" At skill %d: %s, %s."):format(f.next[3], f.next[1], money(f.next[2])) end
  return line, f.top[1][2]
end

function ns.GoldLines()
  local db = history()
  if not db then return { "No Auctionator price history here yet: open the auction house and scan once." } end
  local lines, me = {}, ns.me()
  for _, s in ipairs(me and skillsOf(me) or {}) do
    local line = farmLine(s[1], s[2], db)
    if line then lines[#lines + 1] = line end
  end
  if #lines == 0 then lines[1] = "No gathering profession on this character." end
  -- His other characters: each one's best mat, the same mat on several characters said once, best first (who to
  -- farm on). UW_GuildDB.alts names his own characters only.
  local best = {}
  local alts = type(UW_GuildDB) == "table" and type(UW_GuildDB.alts) == "table" and UW_GuildDB.alts or {}
  for name in pairs(alts) do
    if type(name) == "string" and short(name) ~= short(me or "") then
      for _, s in ipairs(skillsOf(name)) do
        local f = ns.GoldFarm(s[1], s[2], db)
        local top = f and f.top[1]
        local who = short(name)
        if top and (not best[who] or top[2] > best[who][2]) then best[who] = { top[1], top[2] } end
      end
    end
  end
  local groups, byMat = {}, {}
  for name, b in pairs(best) do
    local grp = byMat[b[1]]
    if not grp then grp = { mat = b[1], copper = b[2], names = {} }; byMat[b[1]] = grp; groups[#groups + 1] = grp end
    grp.names[#grp.names + 1] = name
  end
  table.sort(groups, function(a, b) return a.copper > b.copper or a.copper == b.copper and a.mat < b.mat end)
  if #groups > 0 then
    local parts = {}
    for i = 1, math.min(3, #groups) do
      local grp = groups[i]
      table.sort(grp.names)
      parts[#parts + 1] = ("%s %s (%s)"):format(grp.mat, money(grp.copper), table.concat(grp.names, ", "))
    end
    lines[#lines + 1] = "Best on your other characters: " .. table.concat(parts, "; ") .. "."
  end
  local ratio, _, span = ns.GoldTrend(db)
  if ratio and span and span > 0 then
    local pct = math.floor(math.abs(ratio - 1) * 100 + 0.5)
    if ratio <= 0.95 then
      lines[#lines + 1] = ("Asking prices across your scan are down %d%% over %d days: sell what you gather soon."):format(pct, span)
    elseif ratio >= 1.05 then
      lines[#lines + 1] = ("Asking prices across your scan are up %d%% over %d days."):format(pct, span)
    else
      lines[#lines + 1] = ("Asking prices across your scan held steady over %d days."):format(span)
    end
  end
  return lines
end

ns.commands.gold = function()
  if not ns.GoldHere() then return ns.HelpList() end
  if call(g("InCombatLockdown")) then return say("After the fight: /uw gold reads the whole price history.") end
  for _, line in ipairs(ns.GoldLines()) do say(line) end
end

-- The members' weekly line (Louis, 16 Nov 2026 03:42: "Yes, build it first"; the weekly recap's "Worth a look"
-- block, bot/uwbot/market.py; coordinator 04:00: name the top-asking finds). His scan says found recipes, blueprints
-- and bags are the gold at members' levels (herbs and ore ask under 5s). So on the bot's PC, after a visit to the
-- auction house, the save carries a small brief for the bot:
--   UW_GuildDB.goldBrief = { at, recipes = { n, median, p75 }, trend, span,
--                            finds = { { n = name, c = copper, il = item level }, ... } }
-- finds: the GOLD_FINDS_BAND top asks in each ten item levels, recipes and bags seen on GOLD_FINDS_DAYS days or more
-- (one odd listing is not a market), named only when the client has the item loaded. The bot picks the three that
-- fit members' levels. Asks, not sales: the bot words them as asks. Prices and item names only, nothing about any
-- player. Built at logout (addon lead, 16 Nov: one pass over ~6,800 rows is a hitch at the auctioneer, unseen at
-- logout), and only after a visit, so most logouts do nothing.
ns.GOLD_RECIPE_CLASS, ns.GOLD_BAG_CLASS, ns.GOLD_BRIEF_MIN = 9, 1, 20
ns.GOLD_FINDS_BAND, ns.GOLD_FINDS_DAYS = 4, 3
local function quantile(t, q) return t[math.max(1, math.floor(q * (#t - 1) + 0.5) + 1)] end
function ns.GoldBrief(db, now)
  db = db or history()
  local items = g("C_Item")
  local instant = items and items.GetItemInfoInstant or g("GetItemInfoInstant")
  local info = items and items.GetItemInfo or g("GetItemInfo")
  if not db or type(instant) ~= "function" then return nil end
  local asks, bands = {}, {}
  for key, row in pairs(db) do
    local id = type(key) == "string" and key:match("^%d+$") and tonumber(key) or type(key) == "number" and key
    if id then
      local ok, _, _, _, _, _, classID = pcall(instant, id)
      if not ok then classID = nil end
      if classID == ns.GOLD_RECIPE_CLASS or classID == ns.GOLD_BAG_CLASS then
        local p = ns.GoldPrice(id, db)
        if p and classID == ns.GOLD_RECIPE_CLASS then asks[#asks + 1] = p end
        local _, days = dailyLows(row)
        if p and days >= ns.GOLD_FINDS_DAYS and type(info) == "function" then
          local got, name, _, _, il = pcall(info, id)
          if got and type(name) == "string" and not ns.isSecret(name) and type(il) == "number" and not ns.isSecret(il) then
            local band = math.floor(il / 10)
            bands[band] = bands[band] or {}
            local b = bands[band]
            b[#b + 1] = { n = name, c = p, il = il }
          end
        end
      end
    end
  end
  if #asks < ns.GOLD_BRIEF_MIN then return nil end
  table.sort(asks)
  local finds = {}
  for _, b in pairs(bands) do
    table.sort(b, function(x, y) return x.c > y.c or x.c == y.c and x.n < y.n end)
    for i = 1, math.min(ns.GOLD_FINDS_BAND, #b) do finds[#finds + 1] = b[i] end
  end
  table.sort(finds, function(x, y) return x.il < y.il or x.il == y.il and x.c > y.c end)
  local ratio, _, span = ns.GoldTrend(db)
  return { at = now or time(), recipes = { n = #asks, median = quantile(asks, 0.5), p75 = quantile(asks, 0.75) },
    trend = ratio and math.floor(ratio * 100 + 0.5) or nil, span = span, finds = finds }
end
local visited = false
local function keepBrief()
  if not visited or not ns.GoldHere() or type(UW_GuildDB) ~= "table" then return end
  visited = false
  local b = ns.GoldBrief()
  if b then UW_GuildDB.goldBrief = b end
end
ns.GoldKeepBrief = keepBrief
function ns.GoldVisited() visited = true end
-- Auctionator writes its scan into its history while the house is open; the brief follows at the next logout or
-- /reload, when the save is written anyway.
local f = CreateFrame("Frame")
ns.listen(f, { "AUCTION_HOUSE_CLOSED", "PLAYER_LOGOUT" })
f:SetScript("OnEvent", ns.guard(function(_, event)
  if event == "AUCTION_HOUSE_CLOSED" then visited = true else keepBrief() end
end))
