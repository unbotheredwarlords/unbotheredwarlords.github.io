-- The UW Guild window: every feature in one place, each with what it does, its state and buttons that do what its /uw
-- command does (Louis, 10 Nov 2026: "kind of like a wiki of all functions with buttons that do everything functions
-- can, all with high levels of automation, synergy, and sense"). Fresh-member audit, same day: the doors into UW_Guild
-- (/uw, /uw help, the Options page) were built for officers, and nothing told a newcomer what the addon did for them.
--   * Start here, the front page, picks up to four entries for this player now: level, rank, group, kit, Questie.
--   * Every other page is one topic (Play together, Levelling helpers, Guild, Your addons, Raids, Officers). Each entry
--     names related ones; a click goes to that entry's page.
--   * Officer entries and the Officers page show to officers only; a button a rank can't use yet says who can.
--   * A helper that needs another addon shows that as its state ("Needs Questie"), never as a switch that does nothing.
--   * Light: built on first open, refreshed only while shown and only on a click. No OnUpdate, no events, no saved data.
-- Help grouped by goal works better for new users than help grouped by feature (Carroll 1990, minimalist instruction);
-- long menus slow people with no preference yet (Chernev, Bockenholt & Goodman 2015), so Start here shows four things.
local _, ns = ...

ns.HANDBOOK_NAME = "UW Guild"
ns.HANDBOOK_START = 4       -- entries on Start here
ns.HANDBOOK_PER_PAGE = 4    -- entries on one page of a topic
ns.HANDBOOK_ECHO = 3        -- answer lines kept under the page
ns.HANDBOOK_W, ns.HANDBOOK_H = 680, 520

-- Dungeons by the level they usually open (Forever's classic ranges), for the Dungeon quests buttons. word: /uw prep's.
ns.DUNGEON_LEVELS = {
  { "rfc", "RFC", 13 }, { "wc", "WC", 17 }, { "sfk", "SFK", 22 }, { "bfd", "BFD", 24 }, { "rfk", "RFK", 29 },
  { "gnomer", "Gnomer", 29 }, { "sm", "SM", 30 }, { "rfd", "RFD", 37 }, { "ulda", "Ulda", 41 }, { "zf", "ZF", 44 },
  { "mara", "Mara", 46 }, { "atalhakkar", "Sunken Temple", 50 }, { "brd", "BRD", 52 }, { "lbrs", "LBRS", 55 },
  { "diremaul", "Dire Maul", 56 }, { "strat", "Strat", 58 }, { "scholo", "Scholo", 58 },
}
-- The three dungeons nearest this level, lowest first.
function ns.DungeonsNear(level)
  level = tonumber(level) or 1
  local list = {}
  for _, d in ipairs(ns.DUNGEON_LEVELS) do list[#list + 1] = d end
  table.sort(list, function(a, b)
    local da, db = math.abs(a[3] - level), math.abs(b[3] - level)
    if da ~= db then return da < db end
    return a[3] < b[3]
  end)
  local out = { list[1], list[2], list[3] }
  table.sort(out, function(a, b) return a[3] < b[3] end)
  return out
end

-- What the page needs to know about the player now; read once per refresh.
local function context()
  local me = ns.me()
  local officer = ns.isOfficer(me)
  local missReq = (ns.CheckKit and select(1, ns.CheckKit())) or {}
  return {
    level = tonumber((UnitLevel("player"))) or 1,
    officer = officer,
    raider = officer or (ns.canShareRaid and ns.canShareRaid(me)) or false,
    mayCall = ns.MayCall and ns.MayCall() or false,
    group = IsInGroup and IsInGroup() or false,
    raid = IsInRaid and IsInRaid() or false,
    kitMissing = missReq,
    fresh = ns.FreshInstall and ns.FreshInstall() or false,
  }
end

local function switch(key)
  for _, sw in ipairs(ns.OPTION_SWITCHES or {}) do if sw.key == key then return sw end end
end
local function isOn(sw)
  local ok, v = pcall(sw.on)
  return ok and v and true or false
end
-- A switch's state and its one button: on, off, or waiting for the addon it needs.
local function switchState(sw)
  if ns.NeedsMissing(sw) then return ("Needs %s"):format(sw.needs), false end
  return isOn(sw) and "On" or "Off", true
end
local function toggle(sw)
  local on = not isOn(sw)
  if sw.set then ns.OptionsRun({ "", sw.key, set = sw.set, on = on })
  else ns.OptionsRun({ "", sw.cmd .. (on and " on" or " off") }) end
end
local function switchAction(key)
  return { label = function() local sw = switch(key) return sw and isOn(sw) and "Turn off" or "Turn on" end,
    fn = function() local sw = switch(key) if sw then toggle(sw) end end,
    ok = function() local sw = switch(key) return sw ~= nil and not ns.NeedsMissing(sw) end }
end
local function cmd(label, c, ok) return { label = label, cmd = c, ok = ok } end
-- A button whose command opens its own window or a confirm dialog: the guide steps aside first, so that window is never
-- under it (v1 quality audit #1, 10 Nov 2026). /uw opens the guide again.
local function opens(label, c, ok) return { label = label, cmd = c, ok = ok, opens = true } end

-- Thank my target: the thanks command with the target's name, only for a guildmate in sight.
local function targetName()
  if not UnitExists or not UnitExists("target") or not UnitIsPlayer("target") then return nil end
  local n, realm = UnitName("target")
  if type(n) ~= "string" or ns.isSecret(n) then return nil end
  return (realm and realm ~= "") and (n .. "-" .. realm) or n
end

-- Pages, in the order on the left. officer: officers only.
ns.HANDBOOK_PAGES = {
  { "start", "Start here" },
  { "play", "Play together" },
  { "level", "Levelling helpers" },
  { "guild", "Guild" },
  { "addons", "Your addons" },
  { "raids", "Raids" },
  { "officers", "Officers", officer = true },
}

-- Entries. page; title; text (what it does, for someone who has never seen it); actions (buttons: cmd runs that /uw
-- command, fn does it here); related (entry keys); switch (an automatic helper's key in ns.OPTION_SWITCHES);
-- state(ctx) (a short word or two after the title); show(ctx) (false hides it); start(ctx) (a score for Start here).
ns.HANDBOOK = {
  -- Play together
  { key = "near", page = "play", title = "Guildmates near my level",
    text = "Who's online within a few levels of you, free ones first. Click a name in chat to whisper or invite.",
    actions = { cmd("Find guildmates", "near") }, related = { "call", "prep", "meet" },
    start = function(c) return c.raid and 30 or c.level < 60 and 90 or 40 end },
  { key = "call", page = "play", title = "Call a group",
    text = "Writes a line in guild chat for the dungeon at your level, then you invite whoever types inv. Anyone can also "
      .. "just ask in guild chat.",
    actions = { opens("Call a group", "lead call", function(c) return c.mayCall end) },
    state = function(c) return not c.mayCall and "Members and up" or nil end,
    related = { "near", "prep", "thanks" }, start = function(c) return c.mayCall and c.level >= 13 and 60 or 0 end },
  { key = "prep", page = "play", title = "Dungeon quests",
    text = "Before a dungeon, an arrow walks you to each of its quests you can take now, then to the entrance. Pick one "
      .. "near your level.",
    needs = "Questie",
    actions = function(c)
      local out = {}
      for _, d in ipairs(ns.DungeonsNear(c.level)) do out[#out + 1] = cmd(d[2], "prep " .. d[1]) end
      return out
    end,
    related = { "call", "guide", "near" },
    start = function(c) return not c.raid and c.level >= 10 and c.level < 60 and 80 or 0 end },
  { key = "meet", page = "play", title = "Meet point",
    text = "In a group, your spot becomes the group's meet point: their markers point at you until you clear it.",
    actions = { cmd("Share my spot", "meet", function(c) return c.group end), cmd("Clear it", "meet off") },
    state = function(c) return not c.group and "In a group" or nil end,
    related = { "near", "guide" }, start = function(c) return c.group and not c.raid and 70 or 0 end },
  { key = "thanks", page = "play", title = "Thank a guildmate",
    text = "Thank someone you grouped with in the last 3 hours. It counts toward their Officer path. Once a day each.",
    actions = { { label = "Thank my target", ok = function() return targetName() ~= nil end,
      fn = function() SlashCmdList.UWGUILD("thanks " .. (targetName() or "")) end } },
    state = function() return not targetName() and "Target them first" or nil end,
    related = { "call", "rate" }, start = function(c) return c.group and 65 or 0 end },

  -- Levelling helpers (each one an automatic helper with its switch)
  { key = "gear", page = "level", title = "Wear clear gear upgrades", switch = "gear",
    actions = { switchAction("gear"), cmd("Undo last swap", "gear undo") }, related = { "bags", "bars" } },
  { key = "bars", page = "level", title = "New spells onto my bars", switch = "bars",
    actions = { switchAction("bars") }, related = { "gear", "macros" } },
  { key = "space", page = "level", title = "Space uses quest items", switch = "space",
    actions = { switchAction("space") }, related = { "guide", "chain" } },
  { key = "bags", page = "level", title = "Delete and Make room in bags", switch = "bags",
    actions = { switchAction("bags") }, related = { "gear", "mail" } },
  { key = "guide", page = "level", title = "Quest guide marker", switch = "guide",
    actions = { switchAction("guide") }, related = { "prep", "chain", "space" } },
  { key = "chain", page = "level", title = "Quest chain tags", switch = "chain",
    actions = { switchAction("chain"), cmd("List my chains", "chain") }, related = { "guide", "prep" } },
  { key = "hold", page = "level", title = "Keep the quest window open", switch = "hold",
    actions = { switchAction("hold") }, related = { "guide", "layout" } },
  { key = "mail", page = "level", title = "Send mats to my alts", switch = "mail",
    actions = { switchAction("mail"), cmd("What would go", "mail") }, related = { "craft", "bags" } },

  -- Guild
  { key = "welcome", page = "guild", title = "Welcome window",
    text = "Our norms, how to get a buddy, the Guild Master's BattleTag and the optional Discord invite.",
    actions = { opens("Open it", "welcome"), cmd("Discord invite", "invite") }, related = { "jobs", "contact" } },
  { key = "craft", page = "guild", title = "Crafting", switch = "craft",
    text = "Guildmates see what you can craft, and you see theirs. Open each profession window once to add recipes.",
    actions = { cmd("Who crafts what", "craft"), switchAction("craft") }, related = { "mail", "jobs" } },
  { key = "events", page = "guild", title = "Rallies and group nights", switch = "events",
    actions = { cmd("What's on", "events"), switchAction("events") }, related = { "call", "near" } },
  { key = "loot", page = "guild", title = "Loot rules",
    text = "Main spec before off spec, with rolls only. /roll for main spec, /roll 99 for off spec.",
    actions = { cmd("How rolls work", "loot") }, related = { "plan", "rate" },
    start = function(c) return c.group and 50 or 0 end },
  { key = "jobs", page = "guild", title = "Guild jobs",
    text = "Who holds each guild job, read from guild notes, and how to take one on.",
    actions = { cmd("Show jobs", "jobs") }, related = { "contact", "welcome" } },
  { key = "likes", page = "guild", title = "What you like",
    text = "Pick what you enjoy: levelling, dungeons, raids, PvP, professions, social, exploring, RP. Linked on Discord, "
      .. "these show as your roles there.",
    actions = { opens("Pick", "likes") }, related = { "near", "jobs" } },
  { key = "rate", page = "guild", title = "Rate a leader", switch = "rate",
    actions = { cmd("Rate", "rate"), switchAction("rate") }, related = { "thanks", "loot" } },
  { key = "contact", page = "guild", title = "Contact the Guild Master",
    text = "The Guild Master's BattleTag and Steam, for anything you'd rather not post in guild chat.",
    actions = { cmd("Show", "contact") }, related = { "welcome", "jobs" } },

  -- Your addons
  { key = "kit", page = "addons", title = "Addon kit",
    text = "The few addons the guild plays with. Shows what's missing or doubled up; Fix turns duplicates off and kit "
      .. "addons on.",
    actions = { cmd("Check my kit", "kit"), opens("Fix my kit", "kit fix"), cmd("Optional extras", "kit extras") },
    state = function(c) return #c.kitMissing > 0 and ("%d to add"):format(#c.kitMissing) or "Ready" end,
    related = { "layout", "report" },
    start = function(c) return #c.kitMissing > 0 and (c.fresh and 55 or 75) or 0 end },
  { key = "layout", page = "addons", title = "Guild layout",
    text = "Imports the raid frames, bars and meter the officers shared, through each addon's own import.",
    needs = "EllesmereUI", actions = { opens("Use it", "kit layout"), opens("DialogueUI look", "kit look") },
    related = { "kit", "macros" } },
  { key = "macros", page = "addons", title = "Class macros",
    text = "The guild's tested macros for your class, added in one click. Your own macro slots are left free.",
    actions = { cmd("Show mine", "kit macros") }, related = { "bars", "layout" } },
  { key = "report", page = "addons", title = "Something broken?",
    text = "A short report for the officers, a self-test of UW_Guild, and your version against the newest.",
    actions = { opens("Report", "kit report"), cmd("Self-test", "selftest"), cmd("Version", "version") },
    related = { "kit", "contact" } },
  { key = "fish", page = "addons", title = "Fishing sound",
    text = "Music and ambience off, effects up, sound on in the background, so you hear the splash. Again to undo.",
    actions = { cmd("Fishing sound", "fish") }, related = { "mail" } },
  { key = "settings", page = "addons", title = "All switches",
    text = "Every automatic helper with its on and off, in the game's own Settings window. Turning one off never "
      .. "changes your rank or progress.",
    actions = { opens("Open settings", "options") }, related = { "gear", "guide" } },

  -- Raids
  { key = "plan", page = "raids", title = "Raid plan",
    text = "Your own job in each step of the raid leader's plan. The leader pastes the plan code; you see your lines.",
    actions = { opens("Show my plan", "plan") }, related = { "loot", "kit" },
    start = function(c) return c.raid and 97 or 0 end },
  { key = "raidrec", page = "raids", title = "Raid records",
    text = "Guild kills, attendance and loot awards are shared live by the raid's own UW_Guild clients, so your raid "
      .. "nights count toward Raider. Nothing to do.",
    related = { "plan", "loot" } },

  -- Officers
  { key = "lead", page = "officers", title = "Lead a group", officer = true,
    text = "Who's on, calling a group, sign-ups and bench, and lines written ahead. Rehearse first if you like.",
    actions = { opens("Open", "lead"), opens("Rehearse", "lead rehearse") }, related = { "new", "notes" },
    start = function(c) return c.officer and 95 or 0 end },
  { key = "new", page = "officers", title = "Newcomers this week", officer = true,
    text = "Newcomers online with no guild group yet, each with guildmates near their level to invite them.",
    actions = { cmd("Show", "new") }, related = { "lead", "near" },
    start = function(c) return c.officer and 92 or 0 end },
  { key = "audit", page = "officers", title = "Members' kits", officer = true,
    text = "Asks every online member's UW_Guild what their kit has; results in 6 seconds. Nudge reminds only those "
      .. "with something to fix.",
    actions = { cmd("Check kits", "audit"), cmd("Nudge", "kit nudge") }, related = { "kit", "lead" } },
  { key = "notes", page = "officers", title = "Guild notes", officer = true,
    text = "Notes members asked for, ready to copy into the roster by hand (no addon can set them on Forever).",
    actions = { opens("Notes tab", "lead notes") }, related = { "jobs", "lead" } },
  { key = "more", page = "officers", title = "More officer commands", officer = true,
    text = "Typed with a name or word: /uw recruit, buddy, raiders, invite <link>, leavers, discord, bank, note. Guild "
      .. "Master: /uw ranks, charter. Kit: /uw kit edit.",
    related = { "lead", "audit" } },
}

local byKey = {}
for _, e in ipairs(ns.HANDBOOK) do byKey[e.key] = e end
ns.HandbookEntry = function(key) return byKey[key] end

-- An entry's text: its own, or the switch's tooltip (which already ends with what turning it off loses).
local function entryText(e)
  if e.text then return e.text end
  local sw = e.switch and switch(e.switch)
  return sw and sw.tip or ""
end
local function entryState(e, c)
  local sw = e.switch and switch(e.switch)
  if sw then return (switchState(sw)) end
  if e.needs then
    local ok, loaded = pcall(C_AddOns.IsAddOnLoaded, e.needs)
    if not (ok and loaded) then return ("Needs %s"):format(e.needs) end
  end
  return e.state and e.state(c) or nil
end
local function visible(e, c)
  if e.officer and not c.officer then return false end
  if e.show and not e.show(c) then return false end
  return true
end
local function pageVisible(p, c) return not p.officer or c.officer end

-- What a page lists now: Start here's top entries by score, or a topic's entries in order.
function ns.HandbookList(page, c)
  c = c or context()
  local out = {}
  if page == "start" then
    for _, e in ipairs(ns.HANDBOOK) do
      local score = visible(e, c) and e.start and e.start(c) or 0
      if score > 0 then out[#out + 1] = { e = e, s = score } end
    end
    table.sort(out, function(a, b) return a.s > b.s end)
    local list = {}
    for i = 1, math.min(#out, ns.HANDBOOK_START) do list[i] = out[i].e end
    -- Always one door to the helpers already at work: a newcomer never heard of them (fresh-member audit).
    if #list < ns.HANDBOOK_START then list[#list + 1] = byKey.gear end
    return list
  end
  for _, e in ipairs(ns.HANDBOOK) do
    if e.page == page and visible(e, c) then out[#out + 1] = e end
  end
  return out
end
function ns.HandbookActions(e, c)
  local a = e.actions
  if type(a) == "function" then a = a(c or context()) end
  return a or {}
end
function ns.HandbookPageOf(key)
  local e = byKey[key]
  return e and e.page
end

-- The window -------------------------------------------------------------------------------------------------------
local win
local view = { page = "start", index = 1, focus = nil }
local echo, echoUntil = {}, 0

-- Runs one button: its /uw command or its function, counted as a click (usage counts), answer shown under the page.
local function run(a)
  if a.opens and win then win:Hide() end -- its window, or its confirm dialog, shows on its own (opens above)
  wipe(echo)
  echoUntil = GetTime() + (ns.ECHO_SECONDS or 8)
  ns.useFrom = "guide"
  if a.fn then ns.protect(a.fn) else ns.protect(SlashCmdList.UWGUILD, a.cmd) end
  ns.useFrom = nil
  if win and win:IsShown() then ns.HandbookRefresh() end
end
ns.HandbookRun = run
function ns.HandbookEcho(msg)
  if GetTime() > echoUntil then return end
  echo[#echo + 1] = msg
  while #echo > ns.HANDBOOK_ECHO do table.remove(echo, 1) end
  if win and win:IsShown() then win.answer:SetText(table.concat(echo, "\n")) end
end

local function font(parent, tmpl, w)
  local fs = parent:CreateFontString(nil, "OVERLAY", tmpl)
  fs:SetJustifyH("LEFT")
  if w then fs:SetWidth(w) end
  return fs
end
local function button(parent, w)
  local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  b:SetSize(w or 120, 22)
  ns.Skin("Button", b)
  return b
end
-- A link: plain text that goes somewhere.
local function link(parent)
  local b = CreateFrame("Button", nil, parent)
  b:SetSize(120, 16)
  b.text = font(b, "GameFontHighlightSmall")
  b.text:SetPoint("LEFT")
  return b
end

local CARD_H = 92
local function buildCard(parent, i)
  local card = CreateFrame("Frame", nil, parent)
  card:SetSize(ns.HANDBOOK_W - 200, CARD_H)
  card:SetPoint("TOPLEFT", parent, "TOPLEFT", 186, -64 - (i - 1) * (CARD_H + 4))
  card.title = font(card, "GameFontNormal")
  card.title:SetPoint("TOPLEFT", 0, 0)
  card.state = font(card, "GameFontHighlightSmall")
  card.state:SetPoint("LEFT", card.title, "RIGHT", 8, 0)
  card.text = font(card, "GameFontHighlightSmall", ns.HANDBOOK_W - 206)
  card.text:SetPoint("TOPLEFT", card.title, "BOTTOMLEFT", 0, -4)
  card.text:SetJustifyV("TOP")
  card.buttons = {}
  for j = 1, 3 do
    local b = button(card, 118)
    if j == 1 then b:SetPoint("BOTTOMLEFT", 0, 4) else b:SetPoint("LEFT", card.buttons[j - 1], "RIGHT", 6, 0) end
    b:SetScript("OnClick", function(self) if self.action then run(self.action) end end)
    card.buttons[j] = b
  end
  card.see = font(card, "GameFontDisableSmall")
  card.see:SetText("See also:")
  card.links = {}
  for j = 1, 3 do
    local l = link(card)
    card.links[j] = l
    l:SetScript("OnClick", function(self)
      if self.key then view.page, view.index, view.focus = ns.HandbookPageOf(self.key), 1, self.key ns.HandbookRefresh() end
    end)
  end
  return card
end

local function fillCard(card, e, c)
  card.entry = e
  card.title:SetText(e.title)
  local st = entryState(e, c)
  card.state:SetText(st and ("|cff808080" .. st .. "|r") or "")
  card.text:SetText(entryText(e))
  local acts = ns.HandbookActions(e, c)
  local w = 0
  for j, b in ipairs(card.buttons) do
    local a = acts[j]
    b.action = a
    if a then
      local label = type(a.label) == "function" and a.label() or a.label
      b:SetText(label)
      local tw = tonumber((b:GetTextWidth())) or (#label * 7)
      local bw = math.max(90, math.min(150, tw + 28))
      b:SetWidth(bw)
      w = w + bw + 6
      b:SetEnabled(not a.ok or a.ok(c) and true or false)
      b:Show()
    else
      b:Hide()
    end
  end
  -- See also, on the button row's right, as many as fit.
  local x, shown, cw = w + 8, 0, ns.HANDBOOK_W - 200
  card.see:ClearAllPoints()
  card.see:SetPoint("BOTTOMLEFT", card, "BOTTOMLEFT", x, 8)
  x = x + 52
  for j, l in ipairs(card.links) do
    local key = e.related and e.related[j]
    local r = key and byKey[key]
    if r and visible(r, c) and x + 110 <= cw then
      l.key = key
      l.text:SetText(r.title)
      local tw = tonumber((l.text:GetStringWidth())) or 100
      local lw = math.min(tw + 4, cw - x)
      l:SetWidth(lw)
      l:ClearAllPoints()
      l:SetPoint("BOTTOMLEFT", card, "BOTTOMLEFT", x, 7)
      x = x + lw + 10
      shown = shown + 1
      l:Show()
    else
      l.key = nil
      l:Hide()
    end
  end
  card.see:SetShown(shown > 0)
  card:Show()
end

local function build()
  local ok, f = pcall(CreateFrame, "Frame", "UW_GuildHandbook", UIParent, "BasicFrameTemplateWithInset")
  if not ok or not f then f = CreateFrame("Frame", "UW_GuildHandbook", UIParent, "BackdropTemplate") end
  f:SetSize(ns.HANDBOOK_W, ns.HANDBOOK_H)
  f:SetPoint("CENTER")
  f:SetFrameStrata("DIALOG")
  f:SetMovable(true)
  if f.SetClampedToScreen then f:SetClampedToScreen(true) end
  f:EnableMouse(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  tinsert(UISpecialFrames, "UW_GuildHandbook") -- Esc closes it
  ns.SkinWindow(f)
  local title = font(f, "GameFontHighlight")
  title:SetPoint("TOP", 0, -6)
  title:SetText(ns.HANDBOOK_NAME)
  ns.Skin("Font", title)

  -- Pages on the left.
  f.tabs = {}
  for i, p in ipairs(ns.HANDBOOK_PAGES) do
    local b = button(f, 150)
    b:SetPoint("TOPLEFT", 16, -34 - (i - 1) * 28)
    b:SetText(p[2])
    b.page = p[1]
    b:SetScript("OnClick", function(self)
      echoUntil = 0 -- a new page starts without the last page's answer
      view.page, view.index, view.focus = self.page, 1, nil
      ns.HandbookRefresh()
    end)
    ns.useButton(b, "guide page " .. p[1])
    f.tabs[i] = b
  end
  f.heading = font(f, "GameFontNormalLarge")
  f.heading:SetPoint("TOPLEFT", 186, -30)
  f.sub = font(f, "GameFontHighlightSmall", ns.HANDBOOK_W - 380)
  f.sub:SetPoint("LEFT", f.heading, "RIGHT", 10, 0)

  f.cards = {}
  for i = 1, ns.HANDBOOK_PER_PAGE do f.cards[i] = buildCard(f, i) end

  f.prev = button(f, 70)
  f.prev:SetText("< Back")
  f.prev:SetPoint("BOTTOMLEFT", 16, 96)
  f.prev:SetScript("OnClick", function() view.index, view.focus = math.max(1, view.index - 1), nil ns.HandbookRefresh() end)
  f.next = button(f, 70)
  f.next:SetText("More >")
  f.next:SetPoint("BOTTOMLEFT", 96, 96)
  f.next:SetScript("OnClick", function() view.index, view.focus = view.index + 1, nil ns.HandbookRefresh() end)

  f.answer = font(f, "GameFontHighlightSmall", ns.HANDBOOK_W - 200)
  f.answer:SetPoint("BOTTOMLEFT", 186, 12)
  f.answer:SetJustifyV("BOTTOM")
  f.footer = font(f, "GameFontDisableSmall", 150)
  f.footer:SetPoint("BOTTOMLEFT", 16, 14)
  f.footer:SetText("Every button does what its /uw command does. Esc closes.")
  return f
end

function ns.HandbookRefresh()
  if not win then return end
  local c = context()
  local pages = {}
  for i, p in ipairs(ns.HANDBOOK_PAGES) do
    local b = win.tabs[i]
    b:SetShown(pageVisible(p, c))
    if b.LockHighlight then if p[1] == view.page then b:LockHighlight() else b:UnlockHighlight() end end
    pages[p[1]] = p
  end
  local page = pages[view.page] and pageVisible(pages[view.page], c) and view.page or "start"
  view.page = page
  local list = ns.HandbookList(page, c)
  local per = page == "start" and ns.HANDBOOK_START or ns.HANDBOOK_PER_PAGE
  local last = math.max(1, math.ceil(#list / per))
  if view.focus then -- a See also link: the page that holds that entry
    for i, e in ipairs(list) do if e.key == view.focus then view.index = math.ceil(i / per) end end
  end
  view.index = math.min(math.max(1, view.index), last)
  win.heading:SetText(pages[page][2])
  win.sub:SetText(page == "start" and ("Picked for you now. Level %d, %s."):format(c.level,
    c.officer and "officer" or (c.raider and "raider") or (c.mayCall and "member") or "new here") or
    (last > 1 and ("Page %d of %d"):format(view.index, last) or ""))
  for i, card in ipairs(win.cards) do
    local e = list[(view.index - 1) * per + i]
    if e then fillCard(card, e, c) else card:Hide() end
    if card.SetAlpha then card:SetAlpha((view.focus and e and e.key ~= view.focus) and 0.55 or 1) end
  end
  win.prev:SetShown(view.index > 1)
  win.next:SetShown(view.index < last)
  win.answer:SetText(GetTime() <= echoUntil and table.concat(echo, "\n") or "")
end

-- Opens the window, on a page or on the page holding an entry. Asked for, so it opens in a fight too (nothing in it is
-- protected); every button's command keeps its own combat check.
function ns.OpenHandbook(page, focus)
  win = win or build()
  view.page, view.index, view.focus = page or "start", 1, focus
  win:Show()
  ns.HandbookRefresh()
  return win
end
function ns.Handbook() return win, view end

-- /uw window [page]: /uw alone, help and ? come here too (Core.lua). A page's word, or an entry's key, opens there.
ns.commands.window = function(args)
  local w = strtrim(args or ""):lower()
  for _, p in ipairs(ns.HANDBOOK_PAGES) do if p[1] == w then return ns.OpenHandbook(w) end end
  if byKey[w] then return ns.OpenHandbook(byKey[w].page, w) end
  ns.OpenHandbook()
end
