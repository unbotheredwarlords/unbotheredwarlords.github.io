-- The UW Guild window: every feature in one place, each with what it does, its state and buttons that do what its /uw
-- command does (Louis, 10 Nov 2026: "kind of like a wiki of all functions with buttons that do everything functions
-- can, all with high levels of automation, synergy, and sense"). Fresh-member audit, same day: the doors into UW_Guild
-- (/uw, /uw help, the Options page) were built for officers, and nothing told a newcomer what the addon did for them.
--   * Start here, the front page, picks up to four entries for this player now: level, rank, group, kit, Questie.
--   * Every other page is one topic (Play together, Leveling helpers, Guild, Your addons, Raids, Officers). Each entry
--     names related ones; a click goes to that entry's page.
--   * Officer entries and the Officers page show to officers only; a button a rank can't use yet says who can.
--   * A helper that needs another addon shows that as its state ("Needs Questie"), never as a switch that does nothing.
--   * Light: built on first open, refreshed only while shown and only on a click. No OnUpdate, no events, no saved data
--     (the icon table's client check, once a session, is the one line kept: UW_GuildDB.client.icons).
-- Help grouped by goal works better for new users than help grouped by feature (Carroll 1990, minimalist instruction);
-- long menus slow people with no preference yet (Chernev, Bockenholt & Goodman 2015), so Start here shows four things.
local _, ns = ...

ns.HANDBOOK_NAME = "UW Guild"
ns.HANDBOOK_START = 4       -- entries on Start here
ns.HANDBOOK_PER_PAGE = 4    -- entries on one page of a topic, at most

-- Dungeons by the level they usually open (Forever's classic ranges), for the Dungeon quests buttons. word: /uw prep's.
ns.DUNGEON_LEVELS = {
  { "rfc", "RFC", 13 }, { "wc", "WC", 17 }, { "sfk", "SFK", 22 }, { "bfd", "BFD", 24 }, { "rfk", "RFK", 29 },
  { "gnomer", "Gnomer", 29 }, { "sm", "SM", 30 }, { "rfd", "RFD", 37 }, { "ulda", "Ulda", 41 }, { "zf", "ZF", 44 },
  { "mara", "Mara", 46 }, { "atalhakkar", "Sunken Temple", 50 }, { "brd", "BRD", 52 }, { "lbrs", "LBRS", 55 },
  { "diremaul", "Dire Maul", 56 }, { "strat", "Strat", 58 }, { "scholo", "Scholo", 58 },
}
-- The three dungeons nearest this level, lowest first.
function ns.DungeonsNear(level)
  level = tonumber(level) or 1
  local list = {}
  for _, d in ipairs(ns.DUNGEON_LEVELS) do list[#list + 1] = d end
  table.sort(list, function(a, b)
    local da, db = math.abs(a[3] - level), math.abs(b[3] - level)
    if da ~= db then return da < db end
    return a[3] < b[3]
  end)
  local out = { list[1], list[2], list[3] }
  table.sort(out, function(a, b) return a[3] < b[3] end)
  return out
end

-- What the page needs to know about the player now; read once per refresh.
local function context()
  local me = ns.me()
  local officer = ns.isOfficer(me)
  local missReq = (ns.CheckKit and select(1, ns.CheckKit())) or {}
  return {
    level = tonumber((UnitLevel("player"))) or 1,
    officer = officer,
    raider = officer or (ns.canShareRaid and ns.canShareRaid(me)) or false,
    mayCall = ns.MayCall and ns.MayCall() or false,
    group = IsInGroup and IsInGroup() or false,
    raid = IsInRaid and IsInRaid() or false,
    kitMissing = missReq,
    fresh = ns.FreshInstall and ns.FreshInstall() or false,
  }
end

local function switch(key)
  for _, sw in ipairs(ns.OPTION_SWITCHES or {}) do if sw.key == key then return sw end end
end
local function isOn(sw)
  local ok, v = pcall(sw.on)
  return ok and v and true or false
end
-- A switch's state and its one button: on, off, or waiting for the addon it needs.
local function switchState(sw)
  if ns.NeedsMissing(sw) then return ("Needs %s"):format(sw.needs), false end
  return isOn(sw) and "On" or "Off", true
end
local function toggle(sw)
  local on = not isOn(sw)
  if sw.set then ns.OptionsRun({ "", sw.key, set = sw.set, on = on })
  else ns.OptionsRun({ "", sw.cmd .. (on and " on" or " off") }) end
end
-- toggle: the window draws this one as a tick box with On or Off beside it, on the entry's title row.
local function switchAction(key)
  return { label = function() local sw = switch(key) return sw and isOn(sw) and "Turn off" or "Turn on" end,
    fn = function() local sw = switch(key) if sw then toggle(sw) end end,
    ok = function() local sw = switch(key) return sw ~= nil and not ns.NeedsMissing(sw) end, toggle = key }
end
local function cmd(label, c, ok) return { label = label, cmd = c, ok = ok } end
-- One of several equal choices (a dungeon to prepare for): none of them is the entry's one red button.
local function choice(label, c) return { label = label, cmd = c, choice = true } end
-- A button whose command is there to open its own window or a confirm dialog. The guide steps aside for any window
-- a click brings up (run, below); this mark adds the case where that window was open already, under the guide.
local function opens(label, c, ok) return { label = label, cmd = c, ok = ok, opens = true } end

-- Thank my target: the thanks command with the target's name, only for a guildmate in sight.
local function targetName()
  if not UnitExists or not UnitExists("target") or not UnitIsPlayer("target") then return nil end
  local n, realm = UnitName("target")
  if type(n) ~= "string" or ns.isSecret(n) then return nil end
  return (realm and realm ~= "") and (n .. "-" .. realm) or n
end

-- Pages, in the order on the left. officer: officers only.
ns.HANDBOOK_PAGES = {
  { "start", "Start here" },
  { "play", "Play together" },
  { "level", "Leveling helpers" },
  { "guild", "Guild" },
  { "addons", "Your addons" },
  { "raids", "Raids" },
  { "officers", "Officers", officer = true },
}
-- One game icon a page and an entry (design critique, 14 Nov 2026: with none, every entry looked the same until it
-- was read). The picture shows the thing the feature touches. Each row: kind, ID, and the game's English name for
-- that ID, which the client checks before it shows the picture (UI.GameIcon). Every page and entry has one and no two
-- share one (window_layout_test): a new entry needs a row here.
ns.HANDBOOK_ICONS = {
  page = {
    start = { "spell", 818, "Basic Campfire" }, play = { "spell", 6673, "Battle Shout" },
    level = { "spell", 5118, "Aspect of the Cheetah" }, guild = { "item", 5976, "Guild Tabard" },
    addons = { "spell", 4036, "Engineering" }, raids = { "item", 18423, "Head of Onyxia" },
    officers = { "spell", 20217, "Blessing of Kings" },
  },
  entry = {
    near = { "spell", 19883, "Track Humanoids" }, call = { "spell", 698, "Ritual of Summoning" },
    prep = { "item", 7146, "The Scarlet Key" }, meet = { "spell", 1543, "Flare" },
    thanks = { "item", 5042, "Red Ribboned Wrapping Paper" },
    gear = { "spell", 8737, "Mail" }, bars = { "item", 16072, "Expert Cookbook" },
    space = { "item", 9240, "Mallet of Zul'Farrak" }, bags = { "item", 4496, "Small Brown Pouch" },
    guide = { "spell", 1130, "Hunter's Mark" }, chain = { "spell", 9484, "Shackle Undead" },
    hold = { "item", 4389, "Gyrochronatom" }, mail = { "item", 8383, "Plain Letter" },
    dungeons = { "item", 6182, "Dim Torch" },
    welcome = { "item", 6948, "Hearthstone" }, craft = { "spell", 2018, "Blacksmithing" },
    events = { "spell", 16609, "Warchief's Blessing" }, loot = { "item", 4632, "Ornate Bronze Lockbox" },
    jobs = { "item", 2901, "Mining Pick" }, likes = { "item", 3419, "Red Rose" },
    rate = { "spell", 2912, "Starfire" }, contact = { "item", 5863, "Guild Charter" },
    kit = { "item", 2304, "Light Armor Kit" }, layout = { "item", 4408, "Schematic: Mechanical Squirrel" },
    macros = { "class", 78, "Heroic Strike" }, -- the player's own class; an ability where the client has no class art
    report = { "item", 6219, "Arclight Spanner" }, fish = { "spell", 7620, "Fishing" },
    settings = { "item", 4359, "Handful of Copper Bolts" },
    plan = { "item", 18401, "Foror's Compendium of Dragon Slaying" },
    raidrec = { "item", 19019, "Thunderfury, Blessed Blade of the Windseeker" },
    lead = { "item", 18607, "Horde Battle Standard" }, new = { "item", 765, "Silverleaf" },
    share = { "item", 19182, "Darkmoon Faire Prize Ticket" }, audit = { "item", 5507, "Ornate Spyglass" },
    notes = { "item", 955, "Scroll of Intellect" }, more = { "spell", 1160, "Demoralizing Shout" },
  },
}

-- The client check, for the PC read (coordinator, 14 Nov 2026: the IDs above are from memory of the 1.12 data, so a
-- live client is what says which hold). Kept once a session in UW_GuildDB.client.icons, as the macro library's spell
-- check is (Macros.lua): { checked = rows looked up, missing = "item:4496,spell:8737" (no picture on this client;
-- "all" where it has none), renamed = "spell:1130=Mark of the Hunter" (an English client knows the ID by that name,
-- so the row shows nothing; "?" in another language, where names aren't compared), unsure = "item:4389" (shown, but
-- the client hadn't loaded the item's name to compare) }. Game data only: no character, no member, and nothing the
-- window reads back. Class macros shows the class sheet where there is one, so its fallback spell is what's checked.
function ns.ProbeIcons()
  local missing, renamed, unsure, n = {}, {}, {}, 0
  for _, rows in pairs(ns.HANDBOOK_ICONS) do
    for _, row in pairs(rows) do
      local kind = row[1] == "class" and "spell" or row[1]
      local tag = kind .. ":" .. row[2]
      local tex, why, unnamed = ns.UI.GameIcon({ kind, row[2], row[3] })
      n = n + 1
      if tex then
        if unnamed then unsure[#unsure + 1] = tag end
      elseif why == "missing" or why == "" then
        missing[#missing + 1] = tag
      else
        renamed[#renamed + 1] = tag .. "=" .. tostring(why):gsub("[%c|,=]", " "):sub(1, 40)
      end
    end
  end
  table.sort(missing)
  table.sort(renamed)
  table.sort(unsure)
  return { checked = n, missing = #missing == n and "all" or table.concat(missing, ","),
    renamed = ns.UI.English() and table.concat(renamed, ",") or "?", unsure = table.concat(unsure, ",") }
end
-- Out of combat, where a lookup can come back as a secret: a fight at that moment is tried again a minute later,
-- three times. A session that ends first leaves no check in the save (the client record is rebuilt at each login).
local iconsRead = false
function ns.NoteIcons(tries)
  if iconsRead or type(UW_GuildDB) ~= "table" or type(UW_GuildDB.client) ~= "table" then return end
  if InCombatLockdown() then
    if (tries or 0) > 0 then ns.after(60, function() ns.NoteIcons(tries - 1) end) end
    return
  end
  iconsRead = true
  UW_GuildDB.client.icons = ns.ProbeIcons()
end
-- After the roster is in, as the spell check is: the client record is rebuilt then (KitDoctor.lua). Twice: the first
-- look makes the client load the items' names, the second, a little later, is the one kept.
table.insert(ns.onGuildJoin, function()
  ns.afterRoster(function()
    ns.after(30, function() if not InCombatLockdown() then ns.ProbeIcons() end end)
    ns.after(45, function() ns.NoteIcons(3) end)
  end)
end)

-- Entries. page; title; text (what it does, for someone who has never seen it); actions (buttons: cmd runs that /uw
-- command, fn does it here); related (entry keys); switch (an automatic helper's key in ns.OPTION_SWITCHES);
-- state(ctx) (a short word or two after the title); show(ctx) (false hides it); start(ctx) (a score for Start here).
-- The first action is the entry's one red button; the rest are quiet. An entry that leads with its switch, or offers
-- equal choices, has no red button. At most one switch and three other actions an entry.
ns.HANDBOOK = {
  -- Play together
  { key = "near", page = "play", title = "Guildmates near my level",
    text = "Who's online within a few levels of you, free ones first. Click a name in chat to whisper or invite.",
    actions = { cmd("Find guildmates", "near") }, related = { "call", "prep", "meet" },
    start = function(c) return c.raid and 30 or c.level < 60 and 90 or 40 end },
  { key = "call", page = "play", title = "Call a group",
    text = "Writes a line in guild chat for the dungeon at your level, then you invite whoever types inv. Anyone can also "
      .. "just ask in guild chat.",
    actions = { opens("Call a group", "lead call", function(c) return c.mayCall end) },
    state = function(c) return not c.mayCall and "Members and up" or nil end,
    related = { "near", "prep", "thanks" }, start = function(c) return c.mayCall and c.level >= 13 and 60 or 0 end },
  { key = "prep", page = "play", title = "Dungeon quests",
    text = "Before a dungeon, an arrow walks you to each of its quests you can take now, then to the entrance. Pick one "
      .. "near your level.",
    needs = "Questie",
    actions = function(c)
      local out = {}
      for _, d in ipairs(ns.DungeonsNear(c.level)) do out[#out + 1] = choice(d[2], "prep " .. d[1]) end
      return out
    end,
    related = { "call", "guide", "near" },
    start = function(c) return not c.raid and c.level >= 10 and c.level < 60 and 80 or 0 end },
  { key = "meet", page = "play", title = "Meet point",
    text = "In a group, your spot becomes the group's meet point: their markers point at you until you clear it.",
    actions = { cmd("Share my spot", "meet", function(c) return c.group end), cmd("Clear it", "meet off") },
    state = function(c) return not c.group and "Needs a group" or nil end,
    related = { "near", "guide" }, start = function(c) return c.group and not c.raid and 70 or 0 end },
  { key = "thanks", page = "play", title = "Thank a guildmate",
    text = "Thank someone you grouped with in the last 3 hours. It counts toward their Officer path. Once a day each.",
    actions = { { label = "Thank my target", ok = function() return targetName() ~= nil end,
      fn = function() SlashCmdList.UWGUILD("thanks " .. (targetName() or "")) end } },
    state = function() return not targetName() and "Target them first" or nil end,
    related = { "call", "rate" }, start = function(c) return c.group and 65 or 0 end },

  -- Leveling helpers (each one an automatic helper with its switch)
  { key = "gear", page = "level", title = "Wear clear gear upgrades", switch = "gear",
    actions = { switchAction("gear"), cmd("Undo last swap", "gear undo") }, related = { "bags", "bars" } },
  { key = "bars", page = "level", title = "New spells onto my bars", switch = "bars",
    actions = { switchAction("bars") }, related = { "gear", "macros" } },
  { key = "space", page = "level", title = "Space uses quest items", switch = "space",
    actions = { switchAction("space") }, related = { "guide", "chain" } },
  { key = "bags", page = "level", title = "Delete and Make room in bags", switch = "bags",
    actions = { switchAction("bags") }, related = { "gear", "mail" } },
  { key = "guide", page = "level", title = "Quest guide marker", switch = "guide",
    actions = { switchAction("guide") }, related = { "prep", "chain", "space" } },
  { key = "chain", page = "level", title = "Quest chain tags", switch = "chain",
    actions = { switchAction("chain"), cmd("List my chains", "chain") }, related = { "guide", "prep" } },
  { key = "hold", page = "level", title = "Keep the quest window open", switch = "hold",
    actions = { switchAction("hold") }, related = { "guide", "layout" } },
  { key = "mail", page = "level", title = "Send mats to my alts", switch = "mail",
    actions = { switchAction("mail"), cmd("What would go", "mail") }, related = { "craft", "bags" } },
  { key = "dungeons", page = "level", title = "Name dungeons as I level", switch = "dungeons",
    actions = { switchAction("dungeons") }, related = { "prep", "call" } },

  -- Guild
  { key = "welcome", page = "guild", title = "Welcome window",
    text = "Our norms, how to get a buddy, the Guild Master's BattleTag and the optional Discord invite.",
    actions = { opens("Open it", "welcome"), cmd("Discord invite", "invite") }, related = { "jobs", "contact" } },
  { key = "craft", page = "guild", title = "Crafting", switch = "craft",
    text = "Guildmates see what you can craft, and you see theirs. Open each profession window once to add recipes. "
      .. "Off: nothing is shared, and online guildmates forget what they had.",
    actions = { cmd("Who crafts what", "craft"), switchAction("craft") }, related = { "mail", "jobs" } },
  { key = "events", page = "guild", title = "Rallies and group nights", switch = "events",
    actions = { cmd("What's on", "events"), switchAction("events") }, related = { "call", "near" } },
  { key = "loot", page = "guild", title = "Loot rules",
    text = "Main spec before off spec, with rolls only. /roll for main spec, /roll 99 for off spec.",
    actions = { cmd("How rolls work", "loot") }, related = { "plan", "rate" },
    start = function(c) return c.group and 50 or 0 end },
  { key = "jobs", page = "guild", title = "Guild jobs",
    text = "Who holds each guild job, read from guild notes, and how to take one on.",
    actions = { cmd("Show jobs", "jobs") }, related = { "contact", "welcome" } },
  { key = "likes", page = "guild", title = "What you like",
    text = "Pick what you enjoy: leveling, dungeons, raids, PvP, professions, social, exploring, RP. Linked on Discord, "
      .. "these show as your roles there.",
    actions = { opens("Pick", "likes") }, related = { "near", "jobs" } },
  { key = "rate", page = "guild", title = "Rate a leader", switch = "rate",
    actions = { cmd("Rate", "rate"), switchAction("rate") }, related = { "thanks", "loot" } },
  { key = "contact", page = "guild", title = "Contact the Guild Master",
    text = "The Guild Master's BattleTag, for anything you'd rather not post in guild chat.",
    actions = { cmd("Show", "contact") }, related = { "welcome", "jobs" } },

  -- Your addons
  { key = "kit", page = "addons", title = "Addon kit",
    text = "The few addons the guild plays with. Shows what's missing or doubled up; Fix turns duplicates off and kit "
      .. "addons on.",
    actions = { cmd("Check my kit", "kit"), opens("Fix my kit", "kit fix"), cmd("Optional extras", "kit extras") },
    state = function(c) return #c.kitMissing > 0 and ("%d to add"):format(#c.kitMissing) or "Ready" end,
    related = { "layout", "report" },
    start = function(c) return #c.kitMissing > 0 and (c.fresh and 55 or 75) or 0 end },
  { key = "layout", page = "addons", title = "Guild layout",
    text = "Imports the raid frames, bars and meter the officers shared, through each addon's own import.",
    needs = "EllesmereUI", actions = { opens("Use it", "kit layout"), opens("DialogueUI look", "kit look") },
    related = { "kit", "macros" } },
  { key = "macros", page = "addons", title = "Class macros",
    text = "The guild's tested macros for your class, added in one click. Your own macro slots are left free.",
    actions = { cmd("Show mine", "kit macros") }, related = { "bars", "layout" } },
  { key = "report", page = "addons", title = "Something broken?",
    text = "A short report for the officers, a self-test of UW_Guild, and your version against the newest.",
    actions = { opens("Report", "kit report"), cmd("Self-test", "selftest"), cmd("Version", "version") },
    related = { "kit", "contact" } },
  { key = "fish", page = "addons", title = "Fishing sound",
    text = "Music and ambience off, effects up, sound on in the background, so you hear the splash. Again to undo.",
    actions = { cmd("Fishing sound", "fish") }, related = { "mail" } },
  { key = "settings", page = "addons", title = "All switches",
    text = "Every automatic helper with its on and off, in the game's own Settings window. Turning one off never "
      .. "changes your rank or progress.",
    actions = { opens("Open settings", "options") }, related = { "gear", "guide" } },

  -- Raids
  { key = "plan", page = "raids", title = "Raid plan",
    text = "Your own job in each step of the raid leader's plan. The leader pastes the plan code; you see your lines.",
    actions = { opens("Show my plan", "plan") }, related = { "loot", "kit" },
    start = function(c) return c.raid and 97 or 0 end },
  { key = "raidrec", page = "raids", title = "Raid records",
    text = "Guild kills, attendance and loot awards are shared live by the raid's own UW_Guild clients, so your raid "
      .. "nights count toward Raider. Nothing to do.",
    related = { "plan", "loot" } },

  -- Officers
  { key = "lead", page = "officers", title = "Lead a group", officer = true,
    text = "Who's on, calling a group, sign-ups and bench, and lines written ahead. Rehearse first if you like.",
    actions = { opens("Open", "lead"), opens("Rehearse", "lead rehearse") }, related = { "new", "notes" },
    start = function(c) return c.officer and 95 or 0 end },
  { key = "new", page = "officers", title = "Newcomers this week", officer = true,
    text = "Newcomers online with no guild group yet, each with guildmates near their level to invite them.",
    actions = { cmd("Show", "new") }, related = { "lead", "near" },
    start = function(c) return c.officer and 92 or 0 end },
  { key = "share", page = "officers", title = "Share my week-one counts", officer = true, switch = "share",
    actions = { switchAction("share") }, related = { "new", "lead" } },
  { key = "audit", page = "officers", title = "Members' kits", officer = true,
    text = "Asks every online member's UW_Guild what their kit has; results in 6 seconds. Nudge reminds only those "
      .. "with something to fix.",
    actions = { cmd("Check kits", "audit"), cmd("Nudge", "kit nudge") }, related = { "kit", "lead" } },
  { key = "notes", page = "officers", title = "Guild notes", officer = true,
    text = "Notes members asked for, ready to copy into the roster by hand (no addon can set them on Forever).",
    actions = { opens("Notes tab", "lead notes") }, related = { "jobs", "lead" } },
  { key = "more", page = "officers", title = "More officer commands", officer = true,
    text = "Typed with a name or word: /uw recruit, buddy, raiders, invite <link>, leavers, discord, bank, note. Guild "
      .. "Master: /uw ranks, charter. Kit: /uw kit edit.",
    related = { "lead", "audit" } },
}

local byKey = {}
for _, e in ipairs(ns.HANDBOOK) do byKey[e.key] = e end
ns.HandbookEntry = function(key) return byKey[key] end

-- An entry's text: its own, or the switch's tooltip (which already ends with what turning it off loses).
local function entryText(e)
  if e.text then return e.text end
  local sw = e.switch and switch(e.switch)
  return sw and sw.tip or ""
end
local function entryState(e, c)
  local sw = e.switch and switch(e.switch)
  if sw then return (switchState(sw)) end
  if e.needs then
    local ok, loaded = pcall(C_AddOns.IsAddOnLoaded, e.needs)
    if not (ok and loaded) then return ("Needs %s"):format(e.needs) end
  end
  return e.state and e.state(c) or nil
end
local function visible(e, c)
  if e.officer and not c.officer then return false end
  if e.show and not e.show(c) then return false end
  return true
end
local function pageVisible(p, c) return not p.officer or c.officer end

-- What a page lists now: Start here's top entries by score, or a topic's entries in order.
function ns.HandbookList(page, c)
  c = c or context()
  local out = {}
  if page == "start" then
    for _, e in ipairs(ns.HANDBOOK) do
      local score = visible(e, c) and e.start and e.start(c) or 0
      if score > 0 then out[#out + 1] = { e = e, s = score } end
    end
    table.sort(out, function(a, b) return a.s > b.s end)
    local list = {}
    for i = 1, math.min(#out, ns.HANDBOOK_START) do list[i] = out[i].e end
    -- Always one door to the helpers already at work: a newcomer never heard of them (fresh-member audit).
    if #list < ns.HANDBOOK_START then list[#list + 1] = byKey.gear end
    return list
  end
  for _, e in ipairs(ns.HANDBOOK) do
    if e.page == page and visible(e, c) then out[#out + 1] = e end
  end
  return out
end
function ns.HandbookActions(e, c)
  local a = e.actions
  if type(a) == "function" then a = a(c or context()) end
  return a or {}
end
function ns.HandbookPageOf(key)
  local e = byKey[key]
  return e and e.page
end
-- A page of a list of n entries: where it starts, how many it holds, and how many pages there are. As few pages as
-- most a page allows (four), filled evenly with the fuller ones first: five entries read as three and two, never as
-- four and one left alone on a page of its own.
function ns.HandbookSpan(n, index, most)
  most = most or ns.HANDBOOK_PER_PAGE
  local pages = math.max(1, math.ceil(n / most))
  index = math.min(math.max(1, index or 1), pages)
  local base, extra = math.floor(n / pages), n % pages
  return (index - 1) * base + math.min(index - 1, extra) + 1, base + (index <= extra and 1 or 0), pages
end

-- The window -------------------------------------------------------------------------------------------------------
local win
local view = { page = "start", index = 1, focus = nil }
local echo, echoUntil, echoKey = {}, 0, nil -- what the last click said, until when it's taken down, and its entry
local layout -- places the entries and the answer (with the window, below)

-- The other windows a button here can bring up, by name, as showing now: every UW_Guild window (each is on the game's
-- Esc list), the game's confirm dialogs, and its Settings.
local function others()
  local out = {}
  local function look(name)
    local f = rawget(_G, name)
    if f ~= win and type(f) == "table" and f.IsShown and f:IsShown() then out[name] = true end
  end
  for _, name in ipairs(type(UISpecialFrames) == "table" and UISpecialFrames or {}) do
    if type(name) == "string" and name:find("^UW_Guild") then look(name) end
  end
  for i = 1, 4 do look("StaticPopup" .. i) end
  look("SettingsPanel")
  look("InterfaceOptionsFrame")
  return out
end
-- The guide steps aside when a click brought a window or a dialog up, so that one is never under it (v1 quality audit
-- #1, 10 Nov 2026); /uw opens the guide again. It looks at what shows, not at what the button was meant to do: a
-- command that only answered in words (nothing to fix, no plan yet, "After combat, please") leaves the guide open
-- with that answer in it, where it used to close for a window that never came (red team #566; render crawl of 112,
-- 13 Nov). A dialog can show a moment after its command returns, so it looks once more then.
local clicks = 0 -- the second look belongs to the latest click only
local function stepAside(a, before, click, again)
  if click ~= clicks or not (win and win:IsShown()) then return end
  local new, any = false, false
  for name in pairs(others()) do
    any = true
    if not before[name] then new = true end
  end
  -- Its own window was open already and the command said nothing: it's there, under the guide.
  if new or (a.opens and any and #echo == 0) then win:Hide() return end
  if not again then ns.after(0.1, function() stepAside(a, before, click, true) end) end
end

-- Runs one button: its /uw command or its function, counted as a click (usage counts). What it says shows under the
-- entry it was clicked on (key), or under the page's last entry when the caller names none.
local function run(a, key)
  local before = others()
  clicks = clicks + 1
  wipe(echo)
  echoUntil, echoKey = GetTime() + (ns.ECHO_SECONDS or 8), key
  ns.useFrom = "guide"
  if a.fn then ns.protect(a.fn) else ns.protect(SlashCmdList.UWGUILD, a.cmd) end
  ns.useFrom = nil
  stepAside(a, before, clicks)
  if win and win:IsShown() then layout(win.n or 0, echo) end -- placed without a refresh: only the answer changed
end
ns.HandbookRun = run
-- Every line the click printed, in order: the window shows them from the first and counts what doesn't fit.
function ns.HandbookEcho(msg)
  if GetTime() > echoUntil then return end
  echo[#echo + 1] = msg
  if win and win:IsShown() then ns.HandbookRefresh() end
end

local UI = ns.UI
local function font(parent, tmpl, w)
  local fs = parent:CreateFontString(nil, "OVERLAY", tmpl)
  fs:SetJustifyH("LEFT")
  if w then fs:SetWidth(w) end
  return fs
end
-- A link: text that goes somewhere, in the link colour; white and underlined under the pointer.
local function link(parent)
  local b = CreateFrame("Button", nil, parent)
  b:SetSize(120, 16)
  b.text = font(b, "GameFontHighlightSmall")
  b.text:SetPoint("LEFT")
  b.text:SetTextColor(UI.LINK[1], UI.LINK[2], UI.LINK[3])
  local line = UI.Thin(UI.Fill(b, "HIGHLIGHT", 1, 1, 1, 0.7), nil, 1)
  line:SetPoint("TOPLEFT", b.text, "BOTTOMLEFT", 0, -1)
  line:SetPoint("TOPRIGHT", b.text, "BOTTOMRIGHT", 0, -1)
  b:SetScript("OnEnter", function(self) self.text:SetTextColor(1, 1, 1) end)
  b:SetScript("OnLeave", function(self) self.text:SetTextColor(UI.LINK[1], UI.LINK[2], UI.LINK[3]) end)
  return b
end

-- One entry: title and state, what it does, then its buttons with See also on the right. Nothing has a fixed slot:
-- the text hangs under the title, the buttons under the text, the next entry under the buttons, so a two-line text
-- and a three-line one keep the same gaps (items that sit close read as one group: Wertheimer 1923, proximity).
ns.HANDBOOK_GAPS = { title = 4, buttons = 8, between = 12, answer = 8 } -- title to text, text to buttons, entry to
local GAPS = ns.HANDBOOK_GAPS                                             -- the rule, buttons to their answer
local ANSWER_IN = 12 -- an answer starts this far in from the entry's left edge, behind its bar
local STATE = { On = "40ff40", Ready = "40ff40", Off = "808080" } -- other states say what's missing
local function isReason(st) return st ~= nil and (st:find("^Needs ") or st:find(" to add$")) ~= nil end
local function stateText(st)
  if not st then return "" end
  return ("|cff%s%s|r"):format(STATE[st] or (isReason(st) and "ff8000") or "808080", st)
end
-- A greyed button says why under the pointer too: the reason by the title, in its colour. A disabled button gets
-- no pointer, so a frame of its own lies over it while it's off (the same in the game's look and EllesmereUI's).
local function whyShow(self)
  local t = rawget(_G, "GameTooltip")
  if not (t and self.text) then return end
  t:SetOwner(self, "ANCHOR_RIGHT")
  t:SetText(self.text, 1, 0.5, 0, 1, true)
  t:Show()
end
local function whyHide()
  local t = rawget(_G, "GameTooltip")
  if t then t:Hide() end
end
-- An action's widget: the entry's red button, a quiet one, or the tick box. Each runs its action for its entry, and
-- each has the frame that says why while it's off.
local function wire(b, card)
  b:SetScript("OnClick", function(self)
    if not self.action then return end
    run(self.action, card.entry and card.entry.key)
    -- A tick box shows what the click asked for; the helper's real state is read again once the command has run.
    if self.action.toggle then ns.HandbookRefresh() end
  end)
  b.why = CreateFrame("Frame", nil, b)
  b.why:SetAllPoints(b)
  b.why:EnableMouse(true)
  b.why:SetScript("OnEnter", whyShow)
  b.why:SetScript("OnLeave", whyHide)
  b.why:Hide()
  return b
end
-- indent: how far in the entry's words and buttons start, to the right of its icon (0 on a client with no pictures).
local function buildCard(parent, i, indent)
  local card = CreateFrame("Frame", nil, parent)
  card:SetSize(UI.CW, 1) -- only a corner to hang the entry from; what's in it sets how far down it runs
  card.icon = UI.Icon(card, UI.ICON)
  card.icon:SetPoint("TOPLEFT", 0, 0)
  card.title = font(card, "GameFontNormal")
  card.title:SetPoint("TOPLEFT", indent, 0)
  card.state = font(card, "GameFontHighlightSmall")
  card.state:SetPoint("BOTTOMLEFT", card.title, "BOTTOMRIGHT", 8, 1)
  -- A helper's switch: a tick box at the right end of the title row, On or Off in words beside it. A click on the
  -- word ticks it too.
  card.toggle = wire(CreateFrame("CheckButton", nil, card, "UICheckButtonTemplate"), card)
  card.toggle:SetSize(UI.CHECK, UI.CHECK)
  card.toggle:SetPoint("RIGHT", card, "TOPRIGHT", 0, -6) -- centred on the title's line
  ns.Skin("Checkbox", card.toggle)
  card.onoff = font(card, "GameFontHighlightSmall")
  card.onoff:SetPoint("RIGHT", card.toggle, "LEFT", -UI.HALF, 0)
  card.text = UI.Body(card, UI.CW - indent)
  card.text:SetPoint("TOPLEFT", card.title, "BOTTOMLEFT", 0, -GAPS.title)
  -- The buttons and See also keep the entry's full width, back at its left edge under the icon: in the words'
  -- column, 40 px narrower, two entries lost a See also link (render, 14 Nov 2026).
  card.row = CreateFrame("Frame", nil, card)
  card.row:SetSize(UI.CW, UI.BTN)
  card.row:SetPoint("TOPLEFT", card.text, "BOTTOMLEFT", -indent, -GAPS.buttons)
  card.under = 0 -- how much further down the buttons sit, to clear the icon beside short words (layout)
  card.primary = wire(UI.Button(card.row, 118), card)
  card.quiet = {}
  for j = 1, 3 do card.quiet[j] = wire(UI.Quiet(card.row, 90), card) end
  card.buttons = {} -- the ones showing now, left to right
  card.see = font(card.row, "GameFontDisableSmall")
  card.see:SetText("See also:")
  card.links = {}
  for j = 1, 3 do
    local l = link(card.row)
    card.links[j] = l
    l:SetScript("OnClick", function(self)
      if self.key then view.page, view.index, view.focus = ns.HandbookPageOf(self.key), 1, self.key ns.HandbookRefresh() end
    end)
  end
  -- The entry a See also link or /uw window <entry> asked for: lit like the page on the rail.
  card.lit = UI.Fill(card, "BACKGROUND", 1, 1, 1, 0.06)
  card.lit:SetPoint("TOPLEFT", -UI.GAP, GAPS.between / 2)
  card.indent = indent
  card.lit:SetPoint("BOTTOMRIGHT", card.row, "BOTTOMRIGHT", UI.GAP, -GAPS.between / 2)
  card.bar = UI.Fill(card, "ARTWORK", UI.GOLD[1], UI.GOLD[2], UI.GOLD[3], 1)
  card.bar:SetPoint("TOPLEFT", card.lit, "TOPLEFT")
  card.bar:SetPoint("BOTTOMLEFT", card.lit, "BOTTOMLEFT")
  UI.Thin(card.bar, 2)
  if i > 1 then card.rule = UI.Rule(card) end
  return card
end

-- A control this player can't use now: off in the template's own look (never faded as well: the label was down to
-- 2:1 against the window), its reason by the title and under the pointer.
local function usable(b, a, c, st)
  local can = not a.ok or a.ok(c) and true or false
  b.action = a
  UI.Enable(b, can)
  b.why.text = not can and isReason(st) and st or false
  b.why:SetShown(b.why.text ~= false)
  b:Show()
  return can
end
local function fillCard(card, e, c)
  card.entry = e
  card.title:SetText(e.title)
  local st = entryState(e, c)
  -- Its picture, grey while the entry can't do its job: switched off, or waiting for another addon or a group. Not
  -- for "2 to add": that entry is asking for something. None at all on a client without pictures.
  card.pictured = UI.IconSet(card.icon, card.indent > 0 and ns.HANDBOOK_ICONS.entry[e.key] or nil,
    st == "Off" or (st ~= nil and st:find("^Needs ") ~= nil))
  card.text:SetText(entryText(e))
  local acts = ns.HandbookActions(e, c)
  -- The switch, if the entry has one: its state sits by the tick box, not by the title.
  local tog
  for _, a in ipairs(acts) do if a.toggle and not tog then tog = a end end
  card.state:SetText(tog and "" or stateText(st))
  card.onoff:SetText(tog and stateText(st) or "")
  if tog then
    local sw = switch(tog.toggle)
    local can = usable(card.toggle, tog, c, st)
    card.toggle:SetChecked(can and sw ~= nil and isOn(sw))
    local sw_w = tonumber((card.onoff:GetStringWidth())) or 0
    if sw_w <= 0 then sw_w = #(st or "") * 6 end
    if card.toggle.SetHitRectInsets then card.toggle:SetHitRectInsets(-(sw_w + UI.HALF), 0, 0, 0) end
  else
    card.toggle.action = nil
    card.toggle:Hide()
  end
  -- The buttons, left to right: the first action in red unless it's the switch or one of several equal choices.
  local lead = acts[1] and not acts[1].toggle and not acts[1].choice and acts[1] or nil
  local w, q = 0, 0
  wipe(card.buttons)
  card.primary.action = nil
  card.primary:Hide()
  for _, b in ipairs(card.quiet) do b.action = nil b:Hide() end
  for _, a in ipairs(acts) do
    local b
    if a == lead then b = card.primary elseif not a.toggle then q = q + 1 b = card.quiet[q] end
    if b then
      local label = type(a.label) == "function" and a.label() or a.label
      b:SetText(label)
      local bw = a == lead and UI.FitButton(b, label, 28, 90, 150) or UI.FitButton(b, label, 20, 60, 150)
      b:ClearAllPoints()
      b:SetPoint("LEFT", card.row, "LEFT", w, 0)
      w = w + bw + UI.GAP
      usable(b, a, c, st)
      card.buttons[#card.buttons + 1] = b
    end
  end
  -- See also, against the right edge of the button row, as many as fit beside the buttons.
  local fit, total = {}, tonumber((card.see:GetStringWidth())) or 46
  for j, l in ipairs(card.links) do
    local key = e.related and e.related[j]
    local r = key and byKey[key]
    l.key = nil
    l:Hide()
    if r and visible(r, c) then
      l.text:SetText(r.title)
      local lw = tonumber((l.text:GetStringWidth())) or 100
      if w + 4 + total + 12 + lw <= UI.CW then
        l.key, l.w = key, lw
        l:SetWidth(lw)
        fit[#fit + 1] = l
        total = total + 12 + lw
      end
    end
  end
  local x = UI.CW - total
  card.see:ClearAllPoints()
  card.see:SetPoint("LEFT", card.row, "LEFT", x, 0)
  x = x + total
  for j = #fit, 1, -1 do
    local l = fit[j]
    x = x - l.w
    l:ClearAllPoints()
    l:SetPoint("LEFT", card.row, "LEFT", x, 0)
    l:Show()
    x = x - 12
  end
  card.see:SetShown(#fit > 0)
  card:Show()
end

local function build()
  local f = UI.Window("UW_GuildHandbook", ns.HANDBOOK_NAME, "DIALOG")
  -- Closed, however: the next time it opens it starts without the last answer (render crawl of #589, 13 Nov 2026:
  -- reopened within the answer's 8 seconds, it showed "Nothing to undo" again).
  f:SetScript("OnHide", function() echoUntil = 0 end)

  -- Does this client have the pictures at all? One that shows means its lookups work: then every page name and
  -- entry starts in by the same amount, so they stay in a line even where one picture is missing. None (a client
  -- without the lookups) means no indent anywhere: the window as it was before it had icons.
  f.indent = 0
  for _, rows in pairs(ns.HANDBOOK_ICONS) do
    for _, row in pairs(rows) do if row[1] ~= "class" and UI.GameIcon(row) then f.indent = UI.ICON_IN end end
  end

  -- Pages on the rail, each with its icon.
  f.tabs = {}
  for i, p in ipairs(ns.HANDBOOK_PAGES) do
    local b = UI.Nav(f, p[2])
    b.page = p[1]
    b.icon = UI.Icon(b, UI.NAV_ICON)
    b.icon:SetPoint("LEFT", UI.GAP, 0)
    if f.indent > 0 then
      UI.IconSet(b.icon, ns.HANDBOOK_ICONS.page[p[1]])
      b.label:SetPoint("LEFT", UI.GAP + UI.NAV_ICON + 6, 0)
    end
    b:SetScript("OnClick", function(self)
      echoUntil = 0 -- a new page starts without the last page's answer
      view.page, view.index, view.focus = self.page, 1, nil
      ns.HandbookRefresh()
    end)
    ns.useButton(b, "guide page " .. p[1])
    f.tabs[i] = b
  end
  -- The guild's emblem at the foot of the rail (the art the chat lines already carry), on its own frame over the
  -- rail so the rail's fill never covers it.
  local art = CreateFrame("Frame", nil, f.rail)
  art:SetSize(96, 96)
  art:SetPoint("BOTTOM", 0, UI.LINE)
  f.emblem = art:CreateTexture(nil, "ARTWORK")
  f.emblem:SetTexture("Interface\\AddOns\\UW_Guild\\Media\\emblem")
  f.emblem:SetAllPoints()

  f.sub = UI.Sub(f)
  f.pager = UI.Pager(f, function(way) view.index, view.focus = math.max(1, view.index + way), nil ns.HandbookRefresh() end)

  f.cards = {}
  for i = 1, ns.HANDBOOK_PER_PAGE do f.cards[i] = buildCard(f, i, f.indent) end

  -- What the last button said: body text behind a thin bar, hung under the entry it was clicked on (layout).
  f.answer = UI.Body(f, UI.CW - ANSWER_IN)
  f.answer:Hide()
  f.answerBar = UI.Thin(UI.Fill(f.body, "ARTWORK", 1, 1, 1, 0.25), 2)
  f.answerBar:SetPoint("TOPLEFT", f.answer, "TOPLEFT", -ANSWER_IN, 0)
  f.answerBar:Hide()
  -- The one-line hint at the window's foot, under its rule: always there, so nothing at the foot ever moves.
  f.footer = font(f, "GameFontDisableSmall", UI.CW)
  f.footer:SetPoint("BOTTOMLEFT", UI.X, UI.LINE)
  f.footer:SetText("Esc closes.")
  f.footRule = UI.Rule(f.body)
  f.footRule:SetPoint("BOTTOMLEFT", f.footer, "TOPLEFT", 0, UI.GAP)
  return f
end

-- Places the shown entries under each other, and the answer under the entry whose button was clicked: the entries
-- below it move down by its height, the ones above and the clicked button stay where they are (an answer used to
-- sit at the window's foot, up to 500 px from its button; design pass, 13 Nov 2026, finding 10). It gets the room
-- the page has free, and counts the lines that don't fit. A page of long texts (a wider font) closes the gaps
-- between entries first, answer or not, so an answer coming in never moves the entry it belongs to.
function layout(n, answer)
  win.n = n
  local used = 0
  for i = 1, n do
    local card = win.cards[i]
    local words = UI.TextHeight(card.title, 12) + GAPS.title + UI.TextHeight(card.text, 34)
    -- Words shorter than the icon beside them: the buttons still start their gap under the icon, not against it.
    local under = card.pictured and math.max(0, UI.ICON - words) or 0
    if card.under ~= under then
      card.under = under
      card.row:ClearAllPoints()
      card.row:SetPoint("TOPLEFT", card.text, "BOTTOMLEFT", -card.indent, -(GAPS.buttons + under))
    end
    used = used + words + under + GAPS.buttons + UI.BTN
  end
  local foot = UI.GAP + 1 + UI.GAP + UI.LINE -- gap, rule, gap, bottom margin
  local space = UI.H - UI.BODY - foot - used
  local gap = GAPS.between
  while gap > 4 and space - (n - 1) * (2 * gap + 1) < 3 * UI.LINE do gap = gap - 2 end
  -- The answer's entry: the one clicked while it's on this page; the last one for a caller that named none.
  local at
  if #answer > 0 and n > 0 then
    if not echoKey then at = n end
    for i = 1, n do if win.cards[i].entry.key == echoKey then at = i end end
  end
  local drop = 0
  if at then
    local h = UI.AnswerSet(win.answer, answer, math.max(UI.LINE, space - (n - 1) * (2 * gap + 1) - GAPS.answer))
    drop = GAPS.answer + h
    win.answerBar:SetHeight(h)
    if win.answerAt ~= at then -- hung again only when it moved to another entry (a text let go of can measure 0)
      win.answer:ClearAllPoints()
      win.answer:SetPoint("TOPLEFT", win.cards[at].row, "BOTTOMLEFT", ANSWER_IN, -GAPS.answer)
      win.answerAt = at
    end
  end
  win.answer:SetShown(at ~= nil)
  win.answerBar:SetShown(at ~= nil)
  for i = 1, n do
    local card = win.cards[i]
    card:ClearAllPoints()
    if i == 1 then
      card:SetPoint("TOPLEFT", win, "TOPLEFT", UI.X, -UI.BODY)
    else
      card:SetPoint("TOPLEFT", win.cards[i - 1].row, "BOTTOMLEFT", 0, -((at == i - 1 and drop or 0) + 2 * gap + 1))
      card.rule:ClearAllPoints()
      card.rule:SetPoint("TOPLEFT", card, "TOPLEFT", 0, gap + 1)
    end
  end
end

function ns.HandbookRefresh()
  if not win then return end
  local c = context()
  local pages = {}
  for i, p in ipairs(ns.HANDBOOK_PAGES) do
    win.tabs[i].shown = pageVisible(p, c)
    pages[p[1]] = p
  end
  local page = pages[view.page] and pageVisible(pages[view.page], c) and view.page or "start"
  view.page = page
  UI.NavSet(win, win.tabs, function(b) return b.page == page end)
  local list = ns.HandbookList(page, c)
  local most = page == "start" and ns.HANDBOOK_START or ns.HANDBOOK_PER_PAGE
  local _, _, last = ns.HandbookSpan(#list, 1, most)
  if view.focus then -- a See also link: the page that holds that entry
    for index = 1, last do
      local from, count = ns.HandbookSpan(#list, index, most)
      for i = from, from + count - 1 do if list[i].key == view.focus then view.index = index end end
    end
  end
  view.index = math.min(math.max(1, view.index), last)
  local first, count = ns.HandbookSpan(#list, view.index, most)
  win.heading:SetText(pages[page][2])
  win.sub:SetText(page == "start" and ("Picked for you now. Level %d, %s."):format(c.level,
    c.officer and "officer" or (c.raider and "raider") or (c.mayCall and "member") or "new here") or "")
  UI.PagerSet(win.pager, view.index, last)
  local n = 0
  for i, card in ipairs(win.cards) do
    local e = i <= count and list[first + i - 1] or nil
    if e then fillCard(card, e, c) n = i else card:Hide() end
    local lit = e ~= nil and e.key == view.focus
    card.lit:SetShown(lit)
    card.bar:SetShown(lit)
  end
  layout(n, GetTime() <= echoUntil and echo or {})
end

-- Opens the window, on a page or on the page holding an entry. Asked for, so it opens in a fight too (nothing in it is
-- protected); every button's command keeps its own combat check.
function ns.OpenHandbook(page, focus)
  win = win or build()
  view.page, view.index, view.focus = page or "start", 1, focus
  win:Show()
  ns.HandbookRefresh()
  return win
end
function ns.Handbook() return win, view end

-- /uw window [page]: /uw alone, help and ? come here too (Core.lua). A page's word, or an entry's key, opens there.
ns.commands.window = function(args)
  local w = strtrim(args or ""):lower()
  for _, p in ipairs(ns.HANDBOOK_PAGES) do if p[1] == w then return ns.OpenHandbook(w) end end
  if byKey[w] then return ns.OpenHandbook(byKey[w].page, w) end
  ns.OpenHandbook()
end
