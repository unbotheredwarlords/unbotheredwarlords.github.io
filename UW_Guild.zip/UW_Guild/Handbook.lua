-- The UW Guild window: every feature in one place, each with what it does, its state and buttons that do what its /uw
-- command does (Louis, 10 Nov 2026: "kind of like a wiki of all functions with buttons that do everything functions
-- can, all with high levels of automation, synergy, and sense"). Fresh-member audit, same day: the doors into UW_Guild
-- (/uw, /uw help, the Options page) were built for officers, and nothing told a newcomer what the addon did for them.
--   * Start here, the front page, picks up to four entries for this player now: level, rank, group, kit, Questie.
--   * Every other page is one topic (Play together, Leveling helpers, Guild, Your addons, Raids, Officers). Each entry
--     is one row: its icon, its title, one line and at most one button and one tick. Its full text is a hover away,
--     and a click opens the row for the text, its other buttons and the entries related to it (the window, below).
--   * Officer entries and the Officers page show to officers only; a row a rank can't use yet says who can.
--   * A helper that needs another addon shows that by its title ("Needs Questie"), never as a switch that does nothing.
--   * Light: built on first open, refreshed only while shown and only on a click. No OnUpdate, no events, no saved data
--     (the icon table's client check, once a session, is the one line kept: UW_GuildDB.client.icons).
-- Help grouped by goal works better for new users than help grouped by feature (Carroll 1990, minimalist instruction);
-- long menus slow people with no preference yet (Chernev, Bockenholt & Goodman 2015), so Start here shows four things.
local _, ns = ...

ns.HANDBOOK_NAME = "UW Guild"
ns.HANDBOOK_START = 4       -- entries on Start here
ns.HANDBOOK_PER_PAGE = 9    -- rows on one page, at most: what the window holds with one of them open

-- Dungeons by the level they usually open (Forever's classic ranges), for the Dungeon quests buttons. word: /uw prep's.
ns.DUNGEON_LEVELS = {
  { "rfc", "RFC", 13 }, { "wc", "WC", 17 }, { "sfk", "SFK", 22 }, { "bfd", "BFD", 24 }, { "rfk", "RFK", 29 },
  { "gnomer", "Gnomer", 29 }, { "sm", "SM", 30 }, { "rfd", "RFD", 37 }, { "ulda", "Ulda", 41 }, { "zf", "ZF", 44 },
  { "mara", "Mara", 46 }, { "atalhakkar", "Sunken Temple", 50 }, { "brd", "BRD", 52 }, { "lbrs", "LBRS", 55 },
  { "diremaul", "Dire Maul", 56 }, { "strat", "Strat", 58 }, { "scholo", "Scholo", 58 },
}
-- The three dungeons nearest this level, lowest first; and the nearest of the three. Two that open at the same
-- level keep the table's order, so the answer is the same every time.
function ns.DungeonsNear(level)
  level = tonumber(level) or 1
  local list, order = {}, {}
  for i, d in ipairs(ns.DUNGEON_LEVELS) do list[i], order[d] = d, i end
  local function lower(a, b)
    if a[3] ~= b[3] then return a[3] < b[3] end
    return order[a] < order[b]
  end
  table.sort(list, function(a, b)
    local da, db = math.abs(a[3] - level), math.abs(b[3] - level)
    if da ~= db then return da < db end
    return lower(a, b)
  end)
  local out, nearest = { list[1], list[2], list[3] }, list[1]
  table.sort(out, lower)
  return out, nearest
end

-- What the page needs to know about the player now; read once per refresh.
local function context()
  local me = ns.me()
  local officer = ns.isOfficer(me)
  local missReq = (ns.CheckKit and select(1, ns.CheckKit())) or {}
  return {
    level = tonumber((UnitLevel("player"))) or 1,
    officer = officer,
    raider = officer or (ns.canShareRaid and ns.canShareRaid(me)) or false,
    mayCall = ns.MayCall and ns.MayCall() or false,
    group = IsInGroup and IsInGroup() or false,
    raid = IsInRaid and IsInRaid() or false,
    kitMissing = missReq,
    fresh = ns.FreshInstall and ns.FreshInstall() or false,
  }
end

local function switch(key)
  for _, sw in ipairs(ns.OPTION_SWITCHES or {}) do if sw.key == key then return sw end end
end
local function isOn(sw)
  local ok, v = pcall(sw.on)
  return ok and v and true or false
end
-- A switch's state and its one button: on, off, or waiting for the addon it needs.
local function switchState(sw)
  if ns.NeedsMissing(sw) then return ("Needs %s"):format(sw.needs), false end
  return isOn(sw) and "On" or "Off", true
end
local function toggle(sw)
  local on = not isOn(sw)
  if sw.set then ns.OptionsRun({ "", sw.key, set = sw.set, on = on })
  else ns.OptionsRun({ "", sw.cmd .. (on and " on" or " off") }) end
end
-- toggle: the window draws this one as a tick box at the row's right end; the tick is the state.
local function switchAction(key)
  return { label = function() local sw = switch(key) return sw and isOn(sw) and "Turn off" or "Turn on" end,
    fn = function() local sw = switch(key) if sw then toggle(sw) end end,
    ok = function() local sw = switch(key) return sw ~= nil and not ns.NeedsMissing(sw) end, toggle = key }
end
local function cmd(label, c, ok) return { label = label, cmd = c, ok = ok } end
-- One of several equal choices (a dungeon to prepare for): none of them is ever the page's red button.
local function choice(label, c) return { label = label, cmd = c, choice = true } end
-- A button whose command is there to open its own window or a confirm dialog. The guide steps aside for any window
-- a click brings up (run, below); this mark adds the case where that window was open already, under the guide.
local function opens(label, c, ok) return { label = label, cmd = c, ok = ok, opens = true } end

-- Thank my target: the thanks command with the target's name, only for a guildmate in sight.
local function targetName()
  if not UnitExists or not UnitExists("target") or not UnitIsPlayer("target") then return nil end
  local n, realm = UnitName("target")
  if type(n) ~= "string" or ns.isSecret(n) then return nil end
  return (realm and realm ~= "") and (n .. "-" .. realm) or n
end

-- Pages, in the order on the left. officer: officers only.
ns.HANDBOOK_PAGES = {
  { "start", "Start here" },
  { "play", "Play together" },
  { "level", "Leveling helpers" },
  { "guild", "Guild" },
  { "addons", "Your addons" },
  { "raids", "Raids" },
  { "officers", "Officers", officer = true },
}
-- One game icon a page and an entry (design critique, 14 Nov 2026: with none, every entry looked the same until it
-- was read). The picture shows the thing the feature touches. Each row: kind, ID, and the game's English name for
-- that ID, which the client checks before it shows the picture (UI.GameIcon). Every page and entry has one and no two
-- share one (window_layout_test): a new entry needs a row here.
ns.HANDBOOK_ICONS = {
  page = {
    start = { "spell", 818, "Basic Campfire" }, play = { "spell", 6673, "Battle Shout" },
    level = { "spell", 5118, "Aspect of the Cheetah" }, guild = { "item", 5976, "Guild Tabard" },
    addons = { "spell", 4036, "Engineering" }, raids = { "item", 18423, "Head of Onyxia" },
    officers = { "spell", 20217, "Blessing of Kings" },
  },
  entry = {
    near = { "spell", 19883, "Track Humanoids" }, call = { "spell", 698, "Ritual of Summoning" },
    prep = { "item", 7146, "The Scarlet Key" }, meet = { "spell", 1543, "Flare" },
    thanks = { "item", 5042, "Red Ribboned Wrapping Paper" },
    gear = { "spell", 8737, "Mail" }, bars = { "item", 16072, "Expert Cookbook" },
    space = { "item", 9240, "Mallet of Zul'Farrak" }, bags = { "item", 4496, "Small Brown Pouch" },
    guide = { "spell", 1130, "Hunter's Mark" }, chain = { "spell", 9484, "Shackle Undead" },
    hold = { "item", 4389, "Gyrochronatom" }, mail = { "item", 8383, "Plain Letter" },
    dungeons = { "item", 6182, "Dim Torch" },
    welcome = { "item", 6948, "Hearthstone" }, craft = { "spell", 2018, "Blacksmithing" },
    events = { "spell", 16609, "Warchief's Blessing" }, loot = { "item", 4632, "Ornate Bronze Lockbox" },
    jobs = { "item", 2901, "Mining Pick" }, likes = { "item", 3419, "Red Rose" },
    rate = { "spell", 2912, "Starfire" }, contact = { "item", 5863, "Guild Charter" },
    kit = { "item", 2304, "Light Armor Kit" }, layout = { "item", 4408, "Schematic: Mechanical Squirrel" },
    macros = { "class", 78, "Heroic Strike" }, -- the player's own class; an ability where the client has no class art
    report = { "item", 6219, "Arclight Spanner" }, fish = { "spell", 7620, "Fishing" },
    settings = { "item", 4359, "Handful of Copper Bolts" },
    plan = { "item", 18401, "Nostro's Compendium of Dragon Slaying" }, -- Forever's name for it (PC read, 14 Nov)
    raidrec = { "item", 19019, "Thunderfury, Blessed Blade of the Windseeker" },
    lead = { "item", 18607, "Horde Battle Standard" }, new = { "item", 765, "Silverleaf" },
    share = { "item", 19182, "Darkmoon Faire Prize Ticket" }, audit = { "item", 5507, "Ornate Spyglass" },
    notes = { "item", 955, "Scroll of Intellect" }, more = { "spell", 1160, "Demoralizing Shout" },
  },
}

-- The client check, for the PC read (coordinator, 14 Nov 2026: the IDs above are from memory of the 1.12 data, so a
-- live client is what says which hold). Kept once a session in UW_GuildDB.client.icons, as the macro library's spell
-- check is (Macros.lua): { checked = rows looked up, missing = "item:4496,spell:8737" (no picture on this client;
-- "all" where it has none), renamed = "spell:1130=Mark of the Hunter" (an English client knows the ID by that name,
-- so the row shows nothing; "?" in another language, where names aren't compared), unsure = "item:4389" (shown, but
-- the client hadn't loaded the item's name to compare) }. Game data only: no character, no member, and nothing the
-- window reads back. Class macros shows the class sheet where there is one, so its fallback spell is what's checked.
function ns.ProbeIcons()
  local missing, renamed, unsure, n = {}, {}, {}, 0
  for _, rows in pairs(ns.HANDBOOK_ICONS) do
    for _, row in pairs(rows) do
      local kind = row[1] == "class" and "spell" or row[1]
      local tag = kind .. ":" .. row[2]
      local tex, why, unnamed = ns.UI.GameIcon({ kind, row[2], row[3] })
      n = n + 1
      if tex then
        if unnamed then unsure[#unsure + 1] = tag end
      elseif why == "missing" or why == "" then
        missing[#missing + 1] = tag
      else
        renamed[#renamed + 1] = tag .. "=" .. tostring(why):gsub("[%c|,=]", " "):sub(1, 40)
      end
    end
  end
  table.sort(missing)
  table.sort(renamed)
  table.sort(unsure)
  return { checked = n, missing = #missing == n and "all" or table.concat(missing, ","),
    renamed = ns.UI.English() and table.concat(renamed, ",") or "?", unsure = table.concat(unsure, ",") }
end
-- Out of combat, where a lookup can come back as a secret: a fight at that moment is tried again a minute later,
-- three times. A session that ends first leaves no check in the save (the client record is rebuilt at each login).
local iconsRead = false
function ns.NoteIcons(tries)
  if iconsRead or type(UW_GuildDB) ~= "table" or type(UW_GuildDB.client) ~= "table" then return end
  if InCombatLockdown() then
    if (tries or 0) > 0 then ns.after(60, function() ns.NoteIcons(tries - 1) end) end
    return
  end
  iconsRead = true
  UW_GuildDB.client.icons = ns.ProbeIcons()
end
-- After the roster is in, as the spell check is: the client record is rebuilt then (KitDoctor.lua). Twice: the first
-- look makes the client load the items' names, the second, a little later, is the one kept.
table.insert(ns.onGuildJoin, function()
  ns.afterRoster(function()
    ns.after(30, function() if not InCombatLockdown() then ns.ProbeIcons() end end)
    ns.after(45, function() ns.NoteIcons(3) end)
  end)
end)

-- Entries. page; title; line (the one line on the row's face: what it does, in a breath); text (the full text, for
-- someone who has never seen it: the tooltip and the open row; a switch's is its tip in ns.OPTION_SWITCHES);
-- actions (buttons: cmd runs that /uw command, fn does it here); related (entry keys); switch (an automatic helper's
-- key in ns.OPTION_SWITCHES); state(ctx) (a short word or two after the title); show(ctx) (false hides it);
-- start(ctx) (a score for Start here). The row's face holds one button: the first action that isn't the switch
-- (face = true marks another: the dungeon at your level). The rest sit in the open row. At most one switch and
-- four other actions an entry. The lines were cleared one by one (design/critique/one-liners.md, 14 Nov 2026).
ns.HANDBOOK = {
  -- Play together
  { key = "near", page = "play", title = "Guildmates near my level",
    line = "Who's on near your level, free ones first.",
    text = "Who's online within a few levels of you, free ones first. Click a name in chat to whisper or invite.",
    actions = { cmd("Find guildmates", "near") }, related = { "call", "prep", "meet" },
    start = function(c) return c.raid and 30 or c.level < 60 and 90 or 40 end },
  { key = "call", page = "play", title = "Call a group",
    line = "Calls a group for your level in guild chat.",
    text = "Writes a line in guild chat for the dungeon at your level, then you invite whoever types inv. Anyone can also "
      .. "just ask in guild chat.",
    actions = { opens("Call a group", "lead call", function(c) return c.mayCall end) },
    state = function(c) return not c.mayCall and "Members and up" or nil end,
    related = { "near", "prep", "thanks" }, start = function(c) return c.mayCall and c.level >= 13 and 60 or 0 end },
  { key = "prep", page = "play", title = "Dungeon quests",
    line = "Leads you to a dungeon's quests and its door.",
    text = "Before a dungeon, an arrow walks you to each of its quests you can take now, then to the entrance. Pick one "
      .. "near your level.",
    needs = "Questie",
    actions = function(c)
      local out = {}
      local near, nearest = ns.DungeonsNear(c.level)
      for _, d in ipairs(near) do
        -- The dungeon's full name, as /uw prep knows it: a newcomer doesn't know "SFK" (design critique, E18).
        local known = ns.DungeonWord and ns.DungeonWord(d[1])
        out[#out + 1] = choice(known and known[1] or d[2], "prep " .. d[1])
        out[#out].face = d == nearest -- the dungeon at your level is the one on the row's face
      end
      return out
    end,
    related = { "call", "guide", "near" },
    start = function(c) return not c.raid and c.level >= 10 and c.level < 60 and 80 or 0 end },
  { key = "meet", page = "play", title = "Meet point",
    line = "Your group's markers point at you to meet up.",
    text = "In a group, your spot becomes the group's meet point: their markers point at you until you clear it.",
    actions = { cmd("Share my spot", "meet", function(c) return c.group end), cmd("Clear it", "meet off") },
    state = function(c) return not c.group and "Needs a group" or nil end,
    related = { "near", "guide" }, start = function(c) return c.group and not c.raid and 70 or 0 end },
  { key = "thanks", page = "play", title = "Thank a guildmate",
    line = "Thank someone you just grouped with.",
    text = "Thank someone you grouped with in the last 3 hours. It counts toward their Officer path. Once a day each.",
    actions = { { label = "Thank my target", ok = function() return targetName() ~= nil end,
      fn = function() SlashCmdList.UWGUILD("thanks " .. (targetName() or "")) end } },
    state = function() return not targetName() and "Target them first" or nil end,
    related = { "call", "rate" }, start = function(c) return c.group and 65 or 0 end },

  -- Leveling helpers (each one an automatic helper with its switch)
  { key = "gear", page = "level", title = "Wear clear gear upgrades", switch = "gear",
    line = "Puts on clear upgrades; asks on close calls.",
    actions = { switchAction("gear"), cmd("Undo last swap", "gear undo") }, related = { "bags", "bars" } },
  { key = "bars", page = "level", title = "New spells onto my bars", switch = "bars",
    line = "New spells and ranks go onto your bars.",
    actions = { switchAction("bars") }, related = { "gear", "macros" } },
  { key = "space", page = "level", title = "Space uses quest items", switch = "space",
    line = "Space uses the quest item your target needs.",
    actions = { switchAction("space") }, related = { "guide", "chain" } },
  { key = "bags", page = "level", title = "Delete and Make room in bags", switch = "bags",
    line = "Delete drops your cheapest junk; Make room swaps it for loot.",
    actions = { switchAction("bags") }, related = { "gear", "mail" } },
  { key = "guide", page = "level", title = "Quest guide marker", switch = "guide",
    line = "A pin and marker at your quest's next step.",
    actions = { switchAction("guide") }, related = { "prep", "chain", "space" } },
  { key = "chain", page = "level", title = "Quest chain tags", switch = "chain",
    line = "Shows each quest's step in its chain (3/7).",
    actions = { switchAction("chain"), cmd("List my chains", "chain") }, related = { "guide", "prep" } },
  { key = "hold", page = "level", title = "Keep the quest window open", switch = "hold",
    line = "Waits a moment for the next quest after a turn-in.",
    actions = { switchAction("hold") }, related = { "guide", "layout" } },
  { key = "mail", page = "level", title = "Send mats to my alts", switch = "mail",
    line = "One click mails crafting mats to your alts.",
    actions = { switchAction("mail"), cmd("What would go", "mail") }, related = { "craft", "bags" } },
  { key = "dungeons", page = "level", title = "Name dungeons as I level", switch = "dungeons",
    line = "One line in chat when a dungeon opens at your level.",
    actions = { switchAction("dungeons") }, related = { "prep", "call" } },

  -- Guild
  { key = "welcome", page = "guild", title = "Welcome window",
    line = "Our norms and how to get started.",
    text = "Our norms, how to get a buddy, the Guild Master's BattleTag and the optional Discord invite.",
    actions = { opens("Open it", "welcome"), cmd("Discord invite", "invite") }, related = { "jobs", "contact" } },
  { key = "craft", page = "guild", title = "Crafting", switch = "craft",
    line = "Share your recipes and see guildmates' too.",
    text = "Guildmates see what you can craft, and you see theirs. Open each profession window once to add recipes. "
      .. "Off: nothing is shared, and online guildmates forget what they had.",
    actions = { cmd("Who crafts what", "craft"), switchAction("craft") }, related = { "mail", "jobs" } },
  { key = "events", page = "guild", title = "Rallies and group nights", switch = "events",
    line = "A heads-up before each Rally and group night.",
    actions = { cmd("What's on", "events"), switchAction("events") }, related = { "call", "near" } },
  { key = "loot", page = "guild", title = "Loot rules",
    line = "Main spec before off spec, rolls only.",
    text = "Main spec before off spec, with rolls only. /roll for main spec, /roll 99 for off spec.",
    actions = { cmd("How rolls work", "loot") }, related = { "plan", "rate" },
    start = function(c) return c.group and 50 or 0 end },
  { key = "jobs", page = "guild", title = "Guild jobs",
    line = "Who holds each guild job; how to take one.",
    text = "Who holds each guild job, read from guild notes, and how to take one on.",
    actions = { cmd("Show jobs", "jobs") }, related = { "contact", "welcome" } },
  { key = "likes", page = "guild", title = "What you like",
    line = "Pick what you enjoy, to find your people.",
    text = "Pick what you enjoy: leveling, dungeons, raids, PvP, professions, social, exploring, RP. Linked on Discord, "
      .. "these show as your roles there.",
    actions = { opens("Pick", "likes") }, related = { "near", "jobs" } },
  { key = "rate", page = "guild", title = "Rate a leader", switch = "rate",
    line = "Rate a guild group's leader, in private.",
    actions = { cmd("Rate", "rate"), switchAction("rate") }, related = { "thanks", "loot" } },
  { key = "contact", page = "guild", title = "Contact the Guild Master",
    line = "The Guild Master's BattleTag.",
    text = "The Guild Master's BattleTag, for anything you'd rather not post in guild chat.",
    actions = { cmd("Show", "contact") }, related = { "welcome", "jobs" } },

  -- Your addons
  { key = "kit", page = "addons", title = "Addon kit",
    line = "The few addons the guild plays with.",
    text = "The few addons the guild plays with. Shows what's missing or doubled up; Fix turns duplicates off and kit "
      .. "addons on.",
    actions = { cmd("Check my kit", "kit"), opens("Fix my kit", "kit fix"), cmd("Optional extras", "kit extras") },
    state = function(c) return #c.kitMissing > 0 and ("%d to add"):format(#c.kitMissing) or "Ready" end,
    related = { "layout", "report" },
    start = function(c) return #c.kitMissing > 0 and (c.fresh and 55 or 75) or 0 end },
  { key = "layout", page = "addons", title = "Guild layout",
    line = "The officers' raid frames, bars and meter.",
    text = "Imports the raid frames, bars and meter the officers shared, through each addon's own import.",
    needs = "EllesmereUI", actions = { opens("Use it", "kit layout"), opens("DialogueUI look", "kit look") },
    related = { "kit", "macros" } },
  { key = "macros", page = "addons", title = "Class macros",
    line = "Tested macros for your class, in one click.",
    text = "The guild's tested macros for your class, added in one click. Your own macro slots are left free.",
    actions = { cmd("Show mine", "kit macros") }, related = { "bars", "layout" } },
  { key = "report", page = "addons", title = "Something broken?",
    line = "Report a problem, or test UW_Guild.",
    text = "A short report for the officers, a self-test of UW_Guild, and your version against the newest.",
    actions = { opens("Report", "kit report"), cmd("Self-test", "selftest"), cmd("Version", "version") },
    related = { "kit", "contact" } },
  { key = "fish", page = "addons", title = "Fishing sound",
    line = "Hear the splash: music off, effects up.",
    text = "Music and ambience off, effects up, sound on in the background, so you hear the splash. Again to undo.",
    actions = { cmd("Fishing sound", "fish") }, related = { "mail" } },
  { key = "settings", page = "addons", title = "All switches",
    line = "All the switches, in the game's Settings.",
    text = "Every automatic helper with its on and off, in the game's own Settings window. Turning one off never "
      .. "changes your rank or progress.",
    actions = { opens("Open settings", "options") }, related = { "gear", "guide" } },

  -- Raids
  { key = "plan", page = "raids", title = "Raid plan",
    line = "Your own job in each step of the raid plan.",
    text = "Your own job in each step of the raid leader's plan. The leader pastes the plan code; you see your lines.",
    actions = { opens("Show my plan", "plan") }, related = { "loot", "kit" },
    start = function(c) return c.raid and 97 or 0 end },
  { key = "raidrec", page = "raids", title = "Raid records",
    line = "Your raid nights count toward Raider.",
    text = "Guild kills, attendance and loot awards are shared live by the raid's own UW_Guild clients, so your raid "
      .. "nights count toward Raider.",
    related = { "plan", "loot" } },

  -- Officers
  { key = "lead", page = "officers", title = "Lead a group", officer = true,
    line = "Who's on, calls, sign-ups and bench.",
    text = "Who's on, calling a group, sign-ups and bench, and lines written ahead. Rehearse first if you like.",
    actions = { opens("Open", "lead"), opens("Rehearse", "lead rehearse") }, related = { "new", "notes" },
    start = function(c) return c.officer and 95 or 0 end },
  { key = "new", page = "officers", title = "Newcomers this week", officer = true,
    line = "Each shown with guildmates near their level.",
    text = "Newcomers online with no guild group yet, each with guildmates near their level to invite them.",
    actions = { cmd("Show", "new") }, related = { "lead", "near" },
    start = function(c) return c.officer and 92 or 0 end },
  { key = "share", page = "officers", title = "Share my week-one counts", officer = true, switch = "share",
    line = "Shares week-one counts; your list stays on your PC.",
    actions = { switchAction("share") }, related = { "new", "lead" } },
  { key = "audit", page = "officers", title = "Members' kits", officer = true,
    line = "What each online member's kit is missing.",
    text = "Asks every online member's UW_Guild what their kit has; results in 6 seconds. Nudge reminds only those "
      .. "with something to fix.",
    actions = { cmd("Check kits", "audit"), cmd("Nudge", "kit nudge") }, related = { "kit", "lead" } },
  { key = "notes", page = "officers", title = "Guild notes", officer = true,
    line = "Notes members asked for, ready to copy in.",
    text = "Notes members asked for, ready to copy into the roster by hand (no addon can set them on Forever).",
    actions = { opens("Notes tab", "lead notes") }, related = { "jobs", "lead" } },
  { key = "more", page = "officers", title = "More officer commands", officer = true,
    line = "Officer commands typed with a name or word.",
    text = "Typed with a name or word: /uw recruit, buddy, raiders, invite <link>, leavers, discord, bank, note. Guild "
      .. "Master: /uw ranks, charter. Kit: /uw kit edit.",
    related = { "lead", "audit" } },
}

local byKey = {}
for _, e in ipairs(ns.HANDBOOK) do byKey[e.key] = e end
ns.HandbookEntry = function(key) return byKey[key] end

-- An entry's text: its own, or the switch's tooltip (which already ends with what turning it off loses).
local function entryText(e)
  if e.text then return e.text end
  local sw = e.switch and switch(e.switch)
  return sw and sw.tip or ""
end
local function entryState(e, c)
  local sw = e.switch and switch(e.switch)
  if sw then return (switchState(sw)) end
  if e.needs then
    local ok, loaded = pcall(C_AddOns.IsAddOnLoaded, e.needs)
    if not (ok and loaded) then return ("Needs %s"):format(e.needs) end
  end
  return e.state and e.state(c) or nil
end
local function visible(e, c)
  if e.officer and not c.officer then return false end
  if e.show and not e.show(c) then return false end
  return true
end
local function pageVisible(p, c) return not p.officer or c.officer end

-- What a page lists now: Start here's top entries by score, or a topic's entries in order.
function ns.HandbookList(page, c)
  c = c or context()
  local out = {}
  if page == "start" then
    for _, e in ipairs(ns.HANDBOOK) do
      local score = visible(e, c) and e.start and e.start(c) or 0
      if score > 0 then out[#out + 1] = { e = e, s = score } end
    end
    table.sort(out, function(a, b) return a.s > b.s end)
    local list = {}
    for i = 1, math.min(#out, ns.HANDBOOK_START) do list[i] = out[i].e end
    -- Always one door to the helpers already at work: a newcomer never heard of them (fresh-member audit).
    if #list < ns.HANDBOOK_START then list[#list + 1] = byKey.gear end
    return list
  end
  for _, e in ipairs(ns.HANDBOOK) do
    if e.page == page and visible(e, c) then out[#out + 1] = e end
  end
  return out
end
function ns.HandbookActions(e, c)
  local a = e.actions
  if type(a) == "function" then a = a(c or context()) end
  return a or {}
end
function ns.HandbookPageOf(key)
  local e = byKey[key]
  return e and e.page
end
-- A page of a list of n entries: where it starts, how many it holds, and how many pages there are. As few pages as
-- most a page allows (four), filled evenly with the fuller ones first: five entries read as three and two, never as
-- four and one left alone on a page of its own.
function ns.HandbookSpan(n, index, most)
  most = most or ns.HANDBOOK_PER_PAGE
  local pages = math.max(1, math.ceil(n / most))
  index = math.min(math.max(1, index or 1), pages)
  local base, extra = math.floor(n / pages), n % pages
  return (index - 1) * base + math.min(index - 1, extra) + 1, base + (index <= extra and 1 or 0), pages
end

-- The window -------------------------------------------------------------------------------------------------------
local win
local view = { page = "start", index = 1, open = nil } -- open: the key of the row that's open, when one is
local echo, echoUntil, echoKey = {}, 0, nil -- what the last click said, until when it's taken down, and its entry
local running = false -- inside a click's command: what it says is placed once, when it has run

-- The other windows a button here can bring up, by name, as showing now: every UW_Guild window (each is on the game's
-- Esc list), the game's confirm dialogs, and its Settings.
local function others()
  local out = {}
  local function look(name)
    local f = rawget(_G, name)
    if f ~= win and type(f) == "table" and f.IsShown and f:IsShown() then out[name] = true end
  end
  for _, name in ipairs(type(UISpecialFrames) == "table" and UISpecialFrames or {}) do
    if type(name) == "string" and name:find("^UW_Guild") then look(name) end
  end
  for i = 1, 4 do look("StaticPopup" .. i) end
  look("SettingsPanel")
  look("InterfaceOptionsFrame")
  return out
end
-- The guide steps aside when a click brought a window or a dialog up, so that one is never under it (v1 quality audit
-- #1, 10 Nov 2026); /uw opens the guide again. It looks at what shows, not at what the button was meant to do: a
-- command that only answered in words (nothing to fix, no plan yet, "After combat, please") leaves the guide open
-- with that answer in it, where it used to close for a window that never came (red team #566; render crawl of 112,
-- 13 Nov). A dialog can show a moment after its command returns, so it looks once more then.
local clicks = 0 -- the second look belongs to the latest click only
local function stepAside(a, before, click, again)
  if click ~= clicks or not (win and win:IsShown()) then return end
  local new, any = false, false
  for name in pairs(others()) do
    any = true
    if not before[name] then new = true end
  end
  -- Its own window was open already and the command said nothing: it's there, under the guide.
  if new or (a.opens and any and #echo == 0) then win:Hide() return end
  if not again then ns.after(0.1, function() stepAside(a, before, click, true) end) end
end

-- Runs one button: its /uw command or its function, counted as a click (usage counts). What it says shows under the
-- row it was clicked on (key), or under the page's last row when the caller names none. One row at a time has
-- something under it, so a click on another row closes the open one.
local function run(a, key)
  local before = others()
  clicks = clicks + 1
  wipe(echo)
  echoUntil, echoKey = GetTime() + (ns.ECHO_SECONDS or 8), key
  if key and view.open ~= key then view.open = nil end
  ns.useFrom = "guide"
  running = true
  if a.fn then ns.protect(a.fn) else ns.protect(SlashCmdList.UWGUILD, a.cmd) end
  running = false
  ns.useFrom = nil
  stepAside(a, before, clicks)
  -- Read again once the command has run: a tick box shows its helper's real state, and the answer is placed.
  if win and win:IsShown() then ns.HandbookRefresh() end
end
ns.HandbookRun = run
-- Every line the click printed, in order: the window shows them from the first and counts what doesn't fit.
function ns.HandbookEcho(msg)
  if GetTime() > echoUntil then return end
  echo[#echo + 1] = msg
  if not running and win and win:IsShown() then ns.HandbookRefresh() end
end

local UI = ns.UI
local function num(v)
  if v == nil or ns.isSecret(v) then return nil end
  return tonumber(v)
end
-- A text's width as the client measures it, or a guess where it can't yet (0 on a window's first show).
local function wide(fs, guess)
  local w = num(fs:GetStringWidth())
  return w and w > 0 and w or guess
end
local function font(parent, tmpl, w)
  local fs = parent:CreateFontString(nil, "OVERLAY", tmpl)
  fs:SetJustifyH("LEFT")
  if w then fs:SetWidth(w) end
  return fs
end
-- A link: text that goes somewhere, in the link colour; white and underlined under the pointer.
local function link(parent)
  local b = CreateFrame("Button", nil, parent)
  b:SetSize(120, 16)
  b.text = font(b, "GameFontHighlightSmall")
  b.text:SetPoint("LEFT")
  b.text:SetTextColor(UI.LINK[1], UI.LINK[2], UI.LINK[3])
  local line = UI.Thin(UI.Fill(b, "HIGHLIGHT", 1, 1, 1, 0.7), nil, 1)
  line:SetPoint("TOPLEFT", b.text, "BOTTOMLEFT", 0, -1)
  line:SetPoint("TOPRIGHT", b.text, "BOTTOMRIGHT", 0, -1)
  b:SetScript("OnEnter", function(self) self.text:SetTextColor(1, 1, 1) end)
  b:SetScript("OnLeave", function(self) self.text:SetTextColor(UI.LINK[1], UI.LINK[2], UI.LINK[3]) end)
  return b
end

-- One row an entry (design director's spec, section 3, 14 Nov 2026; Louis the same day: "Build the addon!"). The
-- window used to show four cards a page, each a paragraph, an On word, a tick and two links: a manual on its face.
-- A row is read like a line of the spellbook: the icon, the title, one line of what it does, and at most one button
-- and one tick. The manual is one hover or one click away, and nothing was cut from it:
--   * under the pointer, the game's tooltip holds the entry's full text and, in grey, what turning it off loses;
--   * a click opens the row in place: the text, the loss line, the entry's other buttons and its related entries
--     (a tooltip can't hold a link). One row at a time is open, and what a button says shows there too.
-- A tick is the switch's state, so there is no On or Off word. A row that can't do its job now (switched off, or
-- waiting for another addon, a group, a rank or a target) is drawn grey with its reason in orange by the title,
-- and has no dead button. Sizes are the spec's, in UI units:
--   h, least: a row's height, and the least it closes up to so an open row and its answer still fit the window;
--   top, foot: where the rows start, under the heading's rule, and the margin kept at the window's foot;
--   icon, words: how far in the icon and the words start;  ctl, gap: the controls' right margin, the gap between two;
--   pad, over, under: the open row's right, top and bottom padding;  step: a line of its text, to the next line;
--   tip: the tooltip's width.
ns.HANDBOOK_ROW = { h = 38, least = 34, top = UI.TOP + 28, foot = 12, icon = 4, words = 46, ctl = 4, gap = 6,
  pad = 10, over = 6, under = 7, step = 14, tip = 290 }
local ROW = ns.HANDBOOK_ROW
local GREY, DIM = { 0.6, 0.6, 0.6 }, { 0.72, 0.62, 0.23 } -- an off row's line, and its title: the gold, dimmed
-- The word by a title: green when all is well, orange for what's in the way. A switch has no word: its tick says it.
local function stateText(st)
  if not st or st == "On" or st == "Off" then return "" end
  return ("|cff%s%s|r"):format(st == "Ready" and "40ff40" or "ff8000", st)
end
-- Grey: the row can't do its job now. Not "2 to add": that row is asking for something.
local function isOff(st) return st ~= nil and st ~= "On" and st ~= "Ready" and not st:find(" to add$") end
-- An entry's full text in two: what it does, and what turning it off loses (a switch's text ends with "Off: ...").
local function parts(e)
  local text = entryText(e)
  local what, loss = text:match("^(.-)%s*(Off: .*)$")
  if what and what ~= "" then return what, loss end
  return text, nil
end
ns.HandbookText = parts
-- An entry's controls for this player now: its switch (the tick), the one button on the row's face, and the buttons
-- the open row holds. The face button is the entry's main action: the first that isn't the switch, or the one
-- marked face. It is there only while it can be used, and never on a row that waits for another addon. The rest:
-- every other action that can be used now.
function ns.HandbookControls(e, c)
  c = c or context()
  local st = entryState(e, c)
  local tog, main, rest = nil, nil, {}
  local acts = ns.HandbookActions(e, c)
  for _, a in ipairs(acts) do
    if a.toggle then tog = tog or a elseif a.face then main = a end
  end
  for _, a in ipairs(acts) do if not a.toggle and not main then main = a end end
  local function can(a) return not a.ok or (a.ok(c) and true or false) end
  local face = main and can(main) and not (st and st:find("^Needs ")) and main or nil
  for _, a in ipairs(acts) do
    if not a.toggle and a ~= face and can(a) then rest[#rest + 1] = a end
  end
  -- Red: the main action of an entry that leads with it. Not a switch's side button, not one of equal choices,
  -- and not beside "Ready": red says "do this", and a ready kit asks for nothing (as on the Options page).
  return tog, face, rest, face ~= nil and face == acts[1] and not face.choice and st ~= "Ready", st
end

-- The game's tooltip for the row under the pointer: the title in white, what the entry does in gold, what turning
-- it off loses in grey. It sits beside the window, level with its row, so it never covers the rows still to be
-- read; on the other side when the window is against the screen's right edge. On a screen with room on neither
-- side (1440x900 at UI scale 1.15 leaves 194 units each way) it sits under its row, or over it for a row in the
-- window's lower half: never on its own row, the rail or the ticks. Not for the open row: its text is on the page.
local tipOn = false -- the row whose tooltip is up
local function tipHide()
  local card = tipOn
  if not card then return end
  tipOn = false
  local t = rawget(_G, "GameTooltip")
  if not t then return end
  -- Only while it's still this row's. The game has one tooltip: a unit or an item under the pointer, or another
  -- addon, may have taken it since, and theirs is not ours to hide or to narrow (red team, #628).
  if t.GetOwner then
    local ok, owner = pcall(t.GetOwner, t)
    if not ok or owner ~= card then return end
  end
  if t.SetMinimumWidth then pcall(t.SetMinimumWidth, t, 0) end
  t:Hide()
end
local function tipShow(card)
  local t, e = rawget(_G, "GameTooltip"), card.entry
  if not (t and e) or view.open == e.key then return end
  local what, loss = parts(e)
  t:SetOwner(card, "ANCHOR_NONE")
  t:ClearAllPoints()
  local right, left, screen = num(win:GetRight()), num(win:GetLeft()), num(UIParent:GetWidth())
  local need = ROW.tip + 2 * UI.PAD
  if not (right and screen) or right + need <= screen then
    t:SetPoint("TOPLEFT", card, "TOPRIGHT", UI.PAD + 2, 0)
  elseif left and left >= need then
    t:SetPoint("TOPRIGHT", card, "TOPLEFT", -(UI.X + 2), 0)
  elseif card.low then
    t:SetPoint("BOTTOMLEFT", card, "TOPLEFT", win.indent, 2)
  else
    t:SetPoint("TOPLEFT", card, "BOTTOMLEFT", win.indent, -2)
  end
  t:SetText(e.title, 1, 1, 1)
  t:AddLine(what, UI.GOLD[1], UI.GOLD[2], UI.GOLD[3], true)
  if loss then t:AddLine(loss, GREY[1], GREY[2], GREY[3], true) end
  if t.SetMinimumWidth then pcall(t.SetMinimumWidth, t, ROW.tip) end
  t:Show()
  tipOn = card
end
-- The mark that a row opens: a small grey arrow after its title, pointing right under the pointer and down while
-- the row is open. Four flat strips, each inside the next: no art file to be missing, no gaps at any UI scale.
local function arrow(parent)
  local a = CreateFrame("Frame", nil, parent)
  a:SetSize(8, 8)
  a.right, a.down = {}, {}
  for i = 0, 3 do
    local r = UI.Fill(a, "ARTWORK", GREY[1], GREY[2], GREY[3], 1)
    r:SetPoint("TOPLEFT", 0, -i)
    r:SetPoint("BOTTOMRIGHT", a, "TOPLEFT", i + 1, i - 8)
    a.right[i + 1] = r
    local d = UI.Fill(a, "ARTWORK", GREY[1], GREY[2], GREY[3], 1)
    d:SetPoint("TOPLEFT", i, -2)
    d:SetPoint("BOTTOMRIGHT", a, "TOPLEFT", 8 - i, -(3 + i))
    a.down[i + 1] = d
  end
  return a
end
local function setArrow(card)
  local open = card.entry and view.open == card.entry.key or false
  for _, t in ipairs(card.arrow.right) do t:SetShown(card.over and not open) end
  for _, t in ipairs(card.arrow.down) do t:SetShown(open) end
end
local function rowEnter(card)
  card.over = true
  setArrow(card)
  tipShow(card)
end
local function rowLeave(card)
  card.over = false
  setArrow(card)
  tipHide()
end
-- A click on a row opens it, or closes it again. Opening one takes down an answer under another row.
local function rowClick(card)
  local key = card.entry and card.entry.key
  if not key then return end
  if view.open == key then
    view.open = nil
  else
    view.open = key
    if echoKey ~= key then echoUntil = 0 end
  end
  tipHide()
  ns.HandbookRefresh()
end
-- An action's control: the red button, a quiet one, or the tick box. It runs its action for its holder's entry.
local function wire(b, holder)
  b:SetScript("OnClick", function(self)
    if self.action then run(self.action, holder.entry and holder.entry.key) end
  end)
  return b
end
-- indent: how far in the row's words start, to the right of its icon (a margin only on a client with no pictures).
local function buildCard(parent, i, indent)
  local card = CreateFrame("Button", nil, parent)
  card:SetSize(UI.CW, ROW.h)
  UI.Fill(card, "HIGHLIGHT", 1, 1, 1, 0.06):SetAllPoints()
  card.rule = UI.Rule(card)
  card.rule:SetPoint("BOTTOMLEFT", 0, 0)
  card.icon = UI.Icon(card, UI.ICON)
  card.icon:SetPoint("LEFT", ROW.icon, 0)
  -- Title over the one line, the pair centred on the row: hung from its middle, so a row that closes up keeps them.
  card.title = font(card, "GameFontNormal")
  card.title:SetPoint("BOTTOMLEFT", card, "LEFT", indent, 2)
  card.state = font(card, "GameFontHighlightSmall")
  card.state:SetPoint("BOTTOMLEFT", card.title, "BOTTOMRIGHT", 8, 1)
  card.arrow = arrow(card)
  card.line = font(card, "GameFontHighlight")
  card.line:SetPoint("TOPLEFT", card, "LEFT", indent, -1)
  if card.line.SetWordWrap then card.line:SetWordWrap(false) end
  card.indent = indent
  -- The switch: a tick box at the row's right end. While its helper waits for another addon it's faded and off,
  -- under a frame that passes the pointer and the click on to the row.
  card.toggle = wire(CreateFrame("CheckButton", nil, card, "UICheckButtonTemplate"), card)
  card.toggle:SetSize(UI.CHECK, UI.CHECK)
  card.toggle:SetPoint("RIGHT", -ROW.ctl, 0)
  ns.Skin("Checkbox", card.toggle)
  local why = CreateFrame("Button", nil, card.toggle)
  why:SetAllPoints(card.toggle)
  why:SetScript("OnEnter", function() rowEnter(card) end)
  why:SetScript("OnLeave", function() rowLeave(card) end)
  why:SetScript("OnClick", function() rowClick(card) end)
  why:Hide()
  card.toggle.why = why
  -- The one button on its face: quiet, or the page's one red button on its first row.
  card.red = i == 1 and wire(UI.Button(card, 118), card) or false
  card.face = wire(UI.Quiet(card, 90, nil, UI.SMALL, true), card)
  card.entry, card.over, card.button = false, false, false
  card:SetScript("OnEnter", rowEnter)
  card:SetScript("OnLeave", rowLeave)
  card:SetScript("OnClick", rowClick)
  return card
end
local function label(a) return type(a.label) == "function" and a.label() or a.label end
local function fillCard(card, e, c)
  card.entry = e
  local tog, face, rest, red, st = ns.HandbookControls(e, c)
  local off = isOff(st)
  card.rest = rest
  card.title:SetText(e.title)
  card.title:SetTextColor((off and DIM or UI.GOLD)[1], (off and DIM or UI.GOLD)[2], (off and DIM or UI.GOLD)[3])
  card.state:SetText(stateText(st))
  -- The arrow follows the title, or the word by it.
  card.arrow:ClearAllPoints()
  card.arrow:SetPoint("LEFT", st and stateText(st) ~= "" and card.state or card.title, "RIGHT", 8, 0)
  setArrow(card)
  -- Its picture, grey with the row. None at all on a client without pictures.
  card.pictured = UI.IconSet(card.icon, card.indent == ROW.words and ns.HANDBOOK_ICONS.entry[e.key] or nil, off)
  if tog then
    local sw = switch(tog.toggle)
    local can = not tog.ok or (tog.ok(c) and true or false)
    card.toggle.action = tog
    card.toggle:SetEnabled(can)
    card.toggle:SetAlpha(can and 1 or 0.45)
    card.toggle:SetChecked(can and sw ~= nil and isOn(sw))
    card.toggle.why:SetShown(not can)
    card.toggle:Show()
  else
    card.toggle.action = nil
    card.toggle:Hide()
  end
  local b, bw
  if card.red then card.red.action = nil card.red:Hide() end
  card.face.action = nil
  card.face:Hide()
  if face then
    b = red and card.red or card.face
    local text = label(face)
    b:SetText(text)
    bw = b == card.red and UI.FitButton(b, text, 28, 74, 150) or UI.FitButton(b, text, 20, 44, 150)
    b:ClearAllPoints()
    if tog then b:SetPoint("RIGHT", card.toggle, "LEFT", -ROW.gap, 0) else b:SetPoint("RIGHT", -ROW.ctl, 0) end
    b.action = face
    b:Show()
  end
  card.button = b or false
  -- The one line, up to the controls, in the body's white or an off row's grey.
  local taken = ROW.ctl + (tog and UI.CHECK or 0) + (b and bw + (tog and ROW.gap or 0) or 0)
  card.line:SetWidth(UI.CW - card.indent - taken - UI.GAP)
  card.line:SetText(e.line or "")
  card.line:SetTextColor(off and GREY[1] or 1, off and GREY[2] or 1, off and GREY[3] or 1)
  card:Show()
end

-- What's under a row: the open row's manual, and what the last click said. One frame, hung under whichever row
-- has it (layout). Its texts sit on frames of their own and are never hung again: a text let go of can measure 0.
local function buildUnder(f, indent)
  local u = CreateFrame("Frame", nil, f)
  u:SetSize(UI.CW, 1)
  u.indent, u.wide = indent, UI.CW - indent - ROW.pad
  u.fill = UI.Fill(u, "BACKGROUND", 0, 0, 0, 0.36)
  u.fill:SetAllPoints()
  u.bar = UI.Thin(UI.Fill(u, "ARTWORK", UI.GOLD[1], UI.GOLD[2], UI.GOLD[3], 1), 2)
  u.bar:SetPoint("TOPLEFT")
  u.bar:SetPoint("BOTTOMLEFT")
  -- The manual: what the entry does, then what turning it off loses, in grey.
  u.manual = UI.Body(u, u.wide, "GameFontHighlight")
  u.manual:SetPoint("TOPLEFT", indent, -ROW.over)
  u.loss = UI.Body(u, u.wide, "GameFontHighlight")
  u.loss:SetPoint("TOPLEFT", u.manual, "BOTTOMLEFT", 0, -UI.HALF)
  u.loss:SetTextColor(GREY[1], GREY[2], GREY[3])
  -- Its foot: the entry's other buttons from the left, its related entries against the right.
  u.foot = CreateFrame("Frame", nil, u)
  u.foot:SetSize(u.wide, UI.SMALL)
  u.buttons = {}
  for j = 1, 4 do u.buttons[j] = wire(UI.Quiet(u.foot, 90, nil, UI.SMALL, true), u) end
  u.see = font(u.foot, "GameFontDisableSmall")
  u.see:SetText("Related:")
  u.links = {}
  for j = 1, 3 do
    local l = link(u.foot)
    u.links[j] = l
    l:SetScript("OnClick", function(self)
      if not self.key then return end
      echoUntil = 0 -- its page starts without this row's answer
      view.page, view.index, view.open = ns.HandbookPageOf(self.key), 1, self.key
      ns.HandbookRefresh()
    end)
  end
  -- What the last click said, under a hairline when the manual is over it.
  u.said = CreateFrame("Frame", nil, u)
  u.said:SetSize(u.wide, 1)
  u.rule = UI.Rule(u.said, u.wide)
  u.rule:SetPoint("BOTTOMLEFT", u.said, "TOPLEFT", 0, ROW.gap)
  u.answer = UI.Body(u.said, u.wide, "GameFontHighlight")
  u.answer:SetPoint("TOPLEFT")
  u:Hide()
  return u
end
-- Fills the open row's manual for its entry. Returns the heights of its text, its loss line and its foot.
local function fillUnder(u, e, c, rest)
  u.entry = e
  local what, loss = parts(e)
  local per = u.wide / 7 -- about 7 px a letter in the body font, for a text the client can't measure yet
  if u.manual.SetMaxLines then u.manual:SetMaxLines(0) end -- measured whole; layout cuts it if it must
  u.manual:SetText(what)
  u.loss:SetText(loss or "")
  local hText = UI.TextHeight(u.manual, UI.Lines({ what }, 1, per) * ROW.step - UI.SPACING)
  local hLoss = loss and UI.TextHeight(u.loss, UI.Lines({ loss }, 1, per) * ROW.step - UI.SPACING) or 0
  -- The other buttons, left to right.
  local x = 0
  for j, b in ipairs(u.buttons) do
    local a = rest[j]
    b.action = a
    if a then
      local text = label(a)
      b:SetText(text)
      local bw = UI.FitButton(b, text, 20, 44, 150)
      b:ClearAllPoints()
      b:SetPoint("TOPLEFT", u.foot, "TOPLEFT", x, 0)
      x = x + bw + ROW.gap
    end
    b:SetShown(a ~= nil)
  end
  -- Related entries, against the right edge: on the buttons' line where there's room beside them, else on a line
  -- of their own under them.
  local fit, total = {}, wide(u.see, 46)
  for j, l in ipairs(u.links) do
    local key = e.related and e.related[j]
    local r = key and byKey[key]
    l.key = nil
    l:Hide()
    if r and visible(r, c) then
      l.text:SetText(r.title)
      local lw = wide(l.text, #r.title * 6)
      if total + 10 + lw <= u.wide then
        l.key, l.wide = key, lw
        l:SetWidth(lw)
        fit[#fit + 1] = l
        total = total + 10 + lw
      end
    end
  end
  local own = x > 0 and #fit > 0 and x + total > u.wide -- a line of its own
  local lineH = (x > 0 and not own) and UI.SMALL or 16
  local y = -((own and UI.SMALL + UI.HALF or 0) + lineH / 2)
  local at = u.wide
  for j = #fit, 1, -1 do
    local l = fit[j]
    at = at - l.wide
    l:ClearAllPoints()
    l:SetPoint("LEFT", u.foot, "TOPLEFT", at, y)
    l:Show()
    at = at - 10
  end
  u.see:ClearAllPoints()
  u.see:SetPoint("RIGHT", u.foot, "TOPLEFT", at, y)
  u.see:SetShown(#fit > 0)
  local hFoot = (x > 0 and UI.SMALL or 0) + (#fit > 0 and (x == 0 and 16 or own and UI.HALF + 16 or 0) or 0)
  return hText, hLoss, hFoot
end

local function build()
  local f = UI.Window("UW_GuildHandbook", ns.HANDBOOK_NAME, "DIALOG")
  -- Closed, however: the next time it opens it starts without the last answer (render crawl of #589, 13 Nov 2026:
  -- reopened within the answer's 8 seconds, it showed "Nothing to undo" again), and its tooltip goes with it.
  f:SetScript("OnHide", function() echoUntil = 0 tipHide() end)

  -- Does this client have the pictures at all? One that shows means its lookups work: then every page name and
  -- row starts in by the same amount, so they stay in a line even where one picture is missing. None (a client
  -- without the lookups) means no room kept for them anywhere.
  f.pictures = false
  for _, rows in pairs(ns.HANDBOOK_ICONS) do
    for _, row in pairs(rows) do if row[1] ~= "class" and UI.GameIcon(row) then f.pictures = true end end
  end
  f.indent = f.pictures and ROW.words or UI.GAP

  -- Pages on the rail, each with its icon.
  f.tabs = {}
  for i, p in ipairs(ns.HANDBOOK_PAGES) do
    local b = UI.Nav(f, p[2])
    b.page = p[1]
    b.icon = UI.Icon(b, UI.NAV_ICON)
    b.icon:SetPoint("LEFT", UI.GAP, 0)
    if f.pictures then
      UI.IconSet(b.icon, ns.HANDBOOK_ICONS.page[p[1]])
      b.label:SetPoint("LEFT", UI.GAP + UI.NAV_ICON + 6, 0)
    end
    b:SetScript("OnClick", function(self)
      echoUntil = 0 -- a new page starts without the last page's answer, and with no row open
      view.page, view.index, view.open = self.page, 1, nil
      ns.HandbookRefresh()
    end)
    ns.useButton(b, "guide page " .. p[1])
    f.tabs[i] = b
  end
  -- The guild's emblem at the foot of the rail (the art the chat lines already carry), on its own frame over the
  -- rail so the rail's fill never covers it.
  local art = CreateFrame("Frame", nil, f.rail)
  art:SetSize(96, 96)
  art:SetPoint("BOTTOM", 0, UI.LINE)
  f.emblem = art:CreateTexture(nil, "ARTWORK")
  f.emblem:SetTexture("Interface\\AddOns\\UW_Guild\\Media\\emblem")
  f.emblem:SetAllPoints()

  f.sub = UI.Sub(f, "GameFontHighlight") -- 12, like every other line of the window (the spec's two sizes)
  f.pager = UI.Pager(f, function(way) view.index, view.open = math.max(1, view.index + way), nil ns.HandbookRefresh() end)

  f.cards = {}
  for i = 1, ns.HANDBOOK_PER_PAGE do f.cards[i] = buildCard(f, i, f.indent) end
  f.under = buildUnder(f, f.indent)
  return f
end

-- Places the rows under each other from the heading's rule, and under one of them what it has to show: the open
-- row's manual, and the answer to the last click (under the row clicked; in the open row when it's that row's; under
-- the page's last row for a caller that named none). The rows above it stay where they are and the rows below move
-- down by its height. It has the room the page leaves free: a full page closes its rows up a little first (38 to 34
-- units each), then an answer keeps its first lines and counts the rest ("3 more in chat"), and only a manual that
-- still can't fit (a much wider font) is cut to the lines there's room for, its full text a hover away.
local function layout(n, answer)
  local u = win.under
  win.n = n
  local openAt, saidAt
  for i = 1, n do
    local key = win.cards[i].entry.key
    if key == view.open then openAt = i end
    if key == echoKey then saidAt = i end
  end
  local at, said = openAt, #answer > 0 and n > 0
  if said then
    if not at then at = saidAt or (not echoKey and n) or nil end
    said = at ~= nil and (saidAt == at or not echoKey)
  end
  local hText, hLoss, hFoot, fixed = 0, 0, 0, 0
  if openAt then
    hText, hLoss, hFoot = fillUnder(u, win.cards[openAt].entry, win.context, win.cards[openAt].rest)
    fixed = ROW.over + (hLoss > 0 and UI.HALF + hLoss or 0) + (hFoot > 0 and ROW.gap + hFoot or 0) + ROW.under
  end
  -- Around an answer: a gap, a hairline and a gap under the manual; alone, the open row's own padding.
  local chrome = said and (openAt and 2 * ROW.gap + 1 or ROW.over + ROW.under) or 0
  local line = ROW.step - UI.SPACING -- one line of the body font
  local function free(h) return UI.H - ROW.top - ROW.foot - n * h end
  local function linesIn(room) return math.max(1, math.floor((room + UI.SPACING) / ROW.step)) end
  local rowH, hSaid, tall = ROW.h, 0, 0
  if u.answer.SetMaxLines then u.answer:SetMaxLines(0) end
  local function measure() -- the answer in the room that's left, and whether it all fits under rows this high
    local room = free(rowH) - fixed - hText - chrome
    hSaid = said and UI.AnswerSet(u.answer, answer, math.max(line, room), nil, u.wide / 7, ROW.step) or 0
    tall = fixed + hText + chrome + hSaid
    return tall <= free(rowH)
  end
  while not measure() and rowH > ROW.least do rowH = rowH - 2 end
  local cutText, cutSaid = 0, 0
  if tall > free(rowH) and openAt then
    cutText = linesIn(hText - (tall - free(rowH)))
    hText = cutText * ROW.step - UI.SPACING
    measure()
  end
  if tall > free(rowH) and said then -- a first line that wraps and wraps: it keeps to the window too
    cutSaid = linesIn(hSaid - (tall - free(rowH)))
    hSaid = cutSaid * ROW.step - UI.SPACING
    tall = fixed + hText + chrome + hSaid
  end
  if u.manual.SetMaxLines then u.manual:SetMaxLines(cutText) end
  if u.answer.SetMaxLines then u.answer:SetMaxLines(cutSaid) end
  if openAt then
    u.foot:ClearAllPoints()
    u.foot:SetPoint("TOPLEFT", u, "TOPLEFT", u.indent,
      -(ROW.over + hText + (hLoss > 0 and UI.HALF + hLoss or 0) + ROW.gap))
  end
  u.manual:SetShown(openAt ~= nil)
  u.loss:SetShown(openAt ~= nil and hLoss > 0)
  u.foot:SetShown(openAt ~= nil and hFoot > 0)
  u.said:SetShown(said)
  u.rule:SetShown(said and openAt ~= nil)
  if said then
    u.said:ClearAllPoints()
    u.said:SetPoint("TOPLEFT", u, "TOPLEFT", u.indent, -(tall - ROW.under - hSaid))
    u.said:SetHeight(hSaid)
  end
  -- Its bar in the look's own colour: the game's gold, EllesmereUI's ember.
  local skinned = ns.Skinned()
  u.bar:SetColorTexture((skinned and UI.EMBER or UI.GOLD)[1], (skinned and UI.EMBER or UI.GOLD)[2],
    (skinned and UI.EMBER or UI.GOLD)[3], 1)
  local y = ROW.top
  for i = 1, n do
    local card = win.cards[i]
    card:SetHeight(rowH)
    card:ClearAllPoints()
    card:SetPoint("TOPLEFT", win, "TOPLEFT", UI.X, -y)
    card.low = y + rowH / 2 > UI.H / 2 -- for its tooltip on a small screen: over the row, not under it
    card.rule:SetShown(i < n or i == at) -- between rows, and between a row and what's under it
    y = y + rowH
    if i == at then
      u:ClearAllPoints()
      u:SetPoint("TOPLEFT", win, "TOPLEFT", UI.X, -y)
      u:SetHeight(tall)
      y = y + tall
    end
  end
  u:SetShown(at ~= nil)
  win.rowH, win.underAt = rowH, at
end

function ns.HandbookRefresh()
  if not win then return end
  local c = context()
  win.context = c
  local pages = {}
  for i, p in ipairs(ns.HANDBOOK_PAGES) do
    win.tabs[i].shown = pageVisible(p, c)
    pages[p[1]] = p
  end
  local page = pages[view.page] and pageVisible(pages[view.page], c) and view.page or "start"
  view.page = page
  UI.NavSet(win, win.tabs, function(b) return b.page == page end)
  local list = ns.HandbookList(page, c)
  local most = ns.HANDBOOK_PER_PAGE
  local _, _, last = ns.HandbookSpan(#list, 1, most)
  if view.open then -- a Related link, /uw window <entry>: the page that holds that row; a row not there is closed
    local found = false
    for index = 1, last do
      local from, count = ns.HandbookSpan(#list, index, most)
      for i = from, from + count - 1 do if list[i].key == view.open then view.index, found = index, true end end
    end
    if not found then view.open = nil end
  end
  view.index = math.min(math.max(1, view.index), last)
  local first, count = ns.HandbookSpan(#list, view.index, most)
  win.heading:SetText(pages[page][2])
  win.sub:SetText(page == "start" and ("Picked for you now. Level %d, %s."):format(c.level,
    c.officer and "officer" or (c.raider and "raider") or (c.mayCall and "member") or "new here") or "")
  UI.PagerSet(win.pager, view.index, last)
  local n = 0
  for i, card in ipairs(win.cards) do
    local e = i <= count and list[first + i - 1] or nil
    if e then fillCard(card, e, c) n = i else card.entry = false card:Hide() end
  end
  if tipOn then tipHide() end -- the row under the pointer may hold another entry now
  layout(n, GetTime() <= echoUntil and echo or {})
end

-- Opens the window, on a page or on the page holding an entry, with that entry's row open. Asked for, so it opens in
-- a fight too (nothing in it is protected); every button's command keeps its own combat check.
function ns.OpenHandbook(page, open)
  win = win or build()
  view.page, view.index, view.open = page or "start", 1, open
  win:Show()
  ns.HandbookRefresh()
  return win
end
function ns.Handbook() return win, view end

-- /uw window [page]: /uw alone, help and ? come here too (Core.lua). A page's word, or an entry's key, opens there.
ns.commands.window = function(args)
  local w = strtrim(args or ""):lower()
  for _, p in ipairs(ns.HANDBOOK_PAGES) do if p[1] == w then return ns.OpenHandbook(w) end end
  if byKey[w] then return ns.OpenHandbook(byKey[w].page, w) end
  ns.OpenHandbook()
end
