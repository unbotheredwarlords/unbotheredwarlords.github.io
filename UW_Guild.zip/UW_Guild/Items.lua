-- One set of item rules for everything UW_Guild does to the bags (Louis, 5 Nov 2026: "are you sure that's really the
-- absolute very best you can do", on the loot filter). Make room, Delete, Left behind (BagRoom.lua), auto-equip
-- (AutoEquip.lua) and EnhanceQoL's auto-sell guard all ask the same questions here, so one never undoes another:
--   * What is it worth? The higher of the vendor price and Auctionator's last scan, per item (ns.ItemWorth).
--   * Is it junk at all? Only greys, and plain white weapons and armour (ns.IsJunkKind). Mats, food, containers,
--     recipes, keys, hearthstones and everything else are never junk.
--   * Must it stay? ns.KeepReason names why: a quest item or one that starts a quest, a profession tool, a shirt,
--     tabard, bag, quiver or ammo, a piece in an equipment set, a piece auto-equip is asking about or could undo to,
--     a piece that would be an upgrade, anything on EnhanceQoL's "never sell" list (the player's own entries), and
--     anything the player kept with Shift-click on Delete (UW_GuildCharDB.keepItems; /uw bags forget clears it).
-- This mirrors what Scrap, Peddler and Dejunk do for selling (a never-list, quest and tool guards, a value threshold
-- that asks first), applied to deleting and leaving loot, which can't be bought back.
local _, ns = ...

local function g(name) return rawget(_G, name) end
local function call(fn, ...)
  if type(fn) ~= "function" then return nil end
  local ok, a, b, c, d, e, f, h, i, j, k, l, m, n, o = pcall(fn, ...)
  if ok then return a, b, c, d, e, f, h, i, j, k, l, m, n, o end
end

ns.ITEM_WEAPON, ns.ITEM_ARMOR, ns.ITEM_TRADE_GOODS = 2, 4, 7
ns.DELETE_ASK_COPPER = 10000 -- Delete asks first when the junk is worth this much or more (1 gold)

-- Profession tools. Most are white weapons (pick, hammer, knife, poles), so they'd look like junk.
ns.ITEM_TOOLS = {
  [2901] = true,  -- Mining Pick
  [5956] = true,  -- Blacksmith Hammer
  [7005] = true,  -- Skinning Knife
  [6219] = true,  -- Arclight Spanner
  [10498] = true, -- Gyromatic Micro-Adjustor
  [6256] = true, [6365] = true, [6366] = true, [6367] = true, [12225] = true, [19022] = true, [19970] = true, -- poles
  [6218] = true, [6339] = true, [11130] = true, [11145] = true, [16207] = true, -- enchanting rods
}
local KEEP_LOC = { INVTYPE_BODY = "a shirt", INVTYPE_TABARD = "a tabard", INVTYPE_BAG = "a bag",
  INVTYPE_QUIVER = "a quiver", INVTYPE_AMMO = "ammo" }

function ns.ItemInfo(link)
  local items = g("C_Item") or {}
  local name, _, quality, ilvl, minLevel, _, _, stackMax, loc, _, price, classID, subID, bindType =
    call(items.GetItemInfo or g("GetItemInfo"), link)
  if not name then return nil end
  return { name = name, quality = quality, ilvl = ilvl, minLevel = minLevel, stackMax = stackMax or 1, loc = loc,
    price = price or 0, classID = classID, sub = subID, bindType = bindType }
end

-- Worth per item: the higher of vendor and Auctionator, and whether Auctionator's was the higher.
function ns.ItemWorth(link, it)
  local vendor = it and it.price or 0
  local auc = g("Auctionator")
  local api = type(auc) == "table" and type(auc.API) == "table" and auc.API.v1
  local ah = api and call(api.GetAuctionPriceByItemLink, "UW_Guild", link)
  ah = type(ah) == "number" and ah or 0
  return math.max(vendor, ah), ah > vendor
end

-- Postage (Louis, 15 Nov 2026: "I need mail cost to be calculated in" what gets mailed; "if it disenchants for 1g but
-- also vendors for 1g, it's better to vendor because of the postage"). Advice given away from the Send Mail tab has
-- to count the same postage the send will, so the game's own price is remembered each time a mail is put together
-- (GetSendMailPrice once the attachments settle, Mail.lua): UW_GuildDB.postage[stacks attached] = copper, for the
-- whole account. ns.Postage(n) is what n stacks in one mail cost: the price seen for n, else a straight line through
-- the two nearest counts seen. One count seen can't tell a price per stack from a flat price, so it takes the dearer
-- reading (never under Classic's rate when that is the lower of the two): a tie goes to not mailing. Nothing seen
-- yet: Classic's 30 copper a stack.
-- A price above POSTAGE_MOST a stack is no postage (a damaged or hand-edited save): never remembered, never used, so
-- it can't keep every priced stack at home.
ns.POSTAGE_CLASSIC, ns.POSTAGE_STACKS, ns.POSTAGE_MOST = 30, 12, 10000
function ns.PostageSeen(n, price)
  if not UW_GuildDB or type(n) ~= "number" or type(price) ~= "number" or ns.isSecret(n) or ns.isSecret(price) then
    return
  end
  if n < 1 or n > ns.POSTAGE_STACKS or n % 1 ~= 0 or price < 0 or price > ns.POSTAGE_MOST * n then return end
  UW_GuildDB.postage = type(UW_GuildDB.postage) == "table" and UW_GuildDB.postage or {}
  UW_GuildDB.postage[n] = price
end
function ns.Postage(n)
  n = n or 1
  local seen, pts = UW_GuildDB and UW_GuildDB.postage, {}
  for k, v in pairs(type(seen) == "table" and seen or {}) do
    if type(k) == "number" and type(v) == "number" and k >= 1 and v >= 0 and v <= ns.POSTAGE_MOST * k then
      pts[#pts + 1] = { k, v }
    end
  end
  if #pts == 0 then return ns.POSTAGE_CLASSIC * n end
  table.sort(pts, function(a, b)
    local da, db = math.abs(a[1] - n), math.abs(b[1] - n)
    return da < db or (da == db and a[1] < b[1])
  end)
  local a, b = pts[1], pts[2]
  if a[1] == n then return a[2] end
  if not b then return math.floor(math.max(a[2] * n / a[1], math.min(a[2], ns.POSTAGE_CLASSIC * n)) + 0.5) end
  return math.max(0, math.floor(a[2] + (b[2] - a[2]) / (b[1] - a[1]) * (n - a[1]) + 0.5))
end

-- Sell it or disenchant it? (Louis, 15 Nov 2026: "if it disenchants for 1g but also vendors for 1g, it's better to
-- vendor because of the postage".) For a green or blue weapon or piece of armour in the bags that nobody here will
-- wear, ns.BestUse answers "vendor", "disenchant" or "auction", the copper that use brings, and for a disenchant by
-- mail the alt to send it to. The vendor's Sell button (BagRoom.lua) and the mailbox's button (Mail.lua) both ask
-- here, so one never offers what the other would.
--   * The disenchant value is Auctionator's own number from the player's last scan (its API; no table of ours). No
--     number, no advice at all: nothing is compared against a guess.
--   * A character with Enchanting disenchants at home, for nothing. Any other needs an enchanter alt on the same
--     account and faction, and the piece must be unbound: the value then loses the postage for one stack
--     (ns.Postage). No enchanter to reach: the vendor is the only use.
--   * The vendor wins a tie. A piece Auctionator prices above both is "auction": left alone by both buttons. So is
--     an unbound piece the scan never priced, when the vendor would otherwise be the answer: no price is not a low
--     price (red team, 15 Nov).
--   * "Nobody here will wear it" means every one of these holds: ns.KeepReason finds no reason to keep it (a quest
--     item, a tool, a shirt or tabard, in an equipment set, kept by the player, on a ForeverWowCraft route, on
--     EnhanceQoL's never-sell list, a piece auto-equip is asking about or could undo to, a higher item level than
--     the worn piece it can replace); ns.MightWear (AutoEquip.lua) says it plainly couldn't be worn to any gain:
--     armour heavier than the class wears, or every slot it could go in holds a readable piece of a higher item
--     level, whatever its type (a trinket, a relic, an empty slot or an unread worn piece all mean keep); and this
--     character is already high enough to wear it, so auto-equip has had its chance at it (a piece for later levels
--     is never judged). A piece with a resistance on it is always kept. Any other lower-level piece kept for a
--     purpose (off-spec) is only safe in an equipment set or kept with Shift-click on Delete; the hover names it
--     before the click. Before this reaches any member the Sell hover needs its own way to keep one piece
--     (coordinator, 15 Nov; ops/open-work.md).
-- For now only on the PC whose save the bot reads (ns.GearAdviceHere), with the bag buttons' own switch.
ns.ADVICE_QUALITY = { [2] = true, [3] = true }
ns.GEAR_ADVICE_EVERYONE = false
function ns.GearAdviceHere()
  if UW_GuildDB and UW_GuildDB.bagRoom == false then return false end
  return ns.GEAR_ADVICE_EVERYONE or (ns.SyncBotPC ~= nil and ns.SyncBotPC() == true)
end
-- Whether Auctionator has a number at all on this client is not known from its files (its Classic disenchant tables
-- load by game type; hardening's read of 15 Nov 2026 suggests Forever gets the modern ones). So the first answer of
-- each kind in a session leaves one trace row on the bot's PC, and the next save says which it is. (ns.DisenchantProbe
-- below counts over the whole bags, since these rows only see the pieces the keep rule lets through.)
-- Both answers go on the "done" list, the reason saying which: a miss is something the addon was asked to do and
-- didn't, and the bot counts misses into an #officer-inbox note (gametrace.py). Nobody asked for anything here, and
-- "no number" is an answer, not a failure (integrator, 15 Nov 2026).
local deSaid = {}
local function deTrace(ok, why)
  if deSaid[ok] or not (ns.SyncBotPC ~= nil and ns.SyncBotPC() == true) then return end
  deSaid[ok] = true
  ns.trace("advice", "disenchant value", true, why)
end
-- Our own estimate, for when Auctionator has no number (Louis's save, 15 Nov 2026 23:40 UTC: its disenchant code on
-- Forever is the modern one, "0 of 7 priced, ilvl 13 to 23"; that one has no table before Warlords of Draenor). The
-- public pre-4.0 rates (warcraft.wiki.gg, "Disenchanting tables"; nothing taken from Auctionator), priced from the
-- player's own scan through Auctionator's price API: the expected copper from one disenchant, after the auction
-- house's 5% cut. Forever's own guide keys the same tiers to required level, five below these item levels, and lets
-- skill 1 disenchant anything (wow-professions.com, Forever disenchanting guide). An estimate: the tooltip says so,
-- and the advice needs it to beat the vendor clearly (ns.DE_ESTIMATE_MARGIN), so the vendor wins anything close
-- (Louis: "it's better to vendor because of the postage"; coordinator, 13:59 UTC). No price for a likely result (15%
-- or more): no estimate at all. A rare result with no price counts as nothing, which only lowers it.
local STRANGE, SOUL, VISION, DREAM, ILLUSION = 10940, 11083, 11137, 11176, 16204
local LME, GME, LAE, GAE, LMY, GMY, LNE, GNE, LEE, GEE = 10938, 10939, 10998, 11082, 11134, 11135, 11174, 11175, 16202,
  16203
local SGLIM, LGLIM, SGLOW, LGLOW, SRAD, LRAD, SBRIL, LBRIL, NEXUS = 10978, 11084, 11138, 11139, 11177, 11178, 14343,
  14344, 20725
-- { lowest item level, highest, { item, chance, average count } ... }. Averages: 1-2 is 1.5, 2-3 is 2.5, 2-5 is 3.5,
-- 4-6 is 5 (counts are equally likely).
ns.DE_ARMOR = {
  { 5, 15, { STRANGE, 0.80, 1.5 }, { LME, 0.20, 1.5 } },
  { 16, 20, { STRANGE, 0.75, 2.5 }, { GME, 0.20, 1.5 }, { SGLIM, 0.05, 1 } },
  { 21, 25, { STRANGE, 0.75, 5 }, { LAE, 0.15, 1.5 }, { SGLIM, 0.10, 1 } },
  { 26, 30, { SOUL, 0.75, 1.5 }, { GAE, 0.20, 1.5 }, { LGLIM, 0.05, 1 } },
  { 31, 35, { SOUL, 0.75, 3.5 }, { LMY, 0.20, 1.5 }, { SGLOW, 0.05, 1 } },
  { 36, 40, { VISION, 0.75, 1.5 }, { GMY, 0.20, 1.5 }, { LGLOW, 0.05, 1 } },
  { 41, 45, { VISION, 0.75, 3.5 }, { LNE, 0.20, 1.5 }, { SRAD, 0.05, 1 } },
  { 46, 50, { DREAM, 0.75, 1.5 }, { GNE, 0.20, 1.5 }, { LRAD, 0.05, 1 } },
  { 51, 55, { DREAM, 0.75, 3.5 }, { LEE, 0.20, 1.5 }, { SBRIL, 0.05, 1 } },
  { 56, 60, { ILLUSION, 0.75, 1.5 }, { GEE, 0.20, 1.5 }, { LBRIL, 0.05, 1 } },
  { 61, 65, { ILLUSION, 0.75, 3.5 }, { GEE, 0.20, 2.5 }, { LBRIL, 0.05, 1 } },
}
ns.DE_WEAPON = {
  { 6, 15, { STRANGE, 0.20, 1.5 }, { LME, 0.80, 1.5 } },
  { 16, 20, { STRANGE, 0.20, 2.5 }, { GME, 0.75, 1.5 }, { SGLIM, 0.05, 1 } },
  { 21, 25, { STRANGE, 0.15, 5 }, { LAE, 0.75, 1.5 }, { SGLIM, 0.10, 1 } },
  { 26, 30, { SOUL, 0.20, 1.5 }, { GAE, 0.75, 1.5 }, { LGLIM, 0.05, 1 } },
  { 31, 35, { SOUL, 0.20, 3.5 }, { LMY, 0.75, 1.5 }, { SGLOW, 0.05, 1 } },
  { 36, 40, { VISION, 0.20, 1.5 }, { GMY, 0.75, 1.5 }, { LGLOW, 0.05, 1 } },
  { 41, 45, { VISION, 0.20, 3.5 }, { LNE, 0.75, 1.5 }, { SRAD, 0.05, 1 } },
  { 46, 50, { DREAM, 0.20, 1.5 }, { GNE, 0.75, 1.5 }, { LRAD, 0.05, 1 } },
  { 51, 55, { DREAM, 0.22, 3.5 }, { LEE, 0.75, 1.5 }, { SBRIL, 0.03, 1 } },
  { 56, 60, { ILLUSION, 0.22, 1.5 }, { GEE, 0.75, 1.5 }, { LBRIL, 0.03, 1 } },
  { 61, 65, { ILLUSION, 0.22, 3.5 }, { GEE, 0.75, 2.5 }, { LBRIL, 0.03, 1 } },
}
ns.DE_RARE = {
  { 1, 25, { SGLIM, 1, 1 } }, { 26, 30, { LGLIM, 1, 1 } }, { 31, 35, { SGLOW, 1, 1 } }, { 36, 40, { LGLOW, 1, 1 } },
  { 41, 45, { SRAD, 1, 1 } }, { 46, 50, { LRAD, 1, 1 } }, { 51, 55, { SBRIL, 1, 1 } },
  { 56, 65, { LBRIL, 0.995, 1 }, { NEXUS, 0.005, 1 } },
}
ns.DE_LIKELY, ns.AH_KEEP, ns.DE_ESTIMATE_MARGIN = 0.15, 0.95, 1.1
function ns.DisenchantEstimate(link, it)
  it = it or (link and ns.ItemInfo(link))
  if not it or ns.isSecret(it.quality) or ns.isSecret(it.classID) or ns.isSecret(it.ilvl) then return nil end
  if not ns.ADVICE_QUALITY[it.quality] or (it.classID ~= ns.ITEM_WEAPON and it.classID ~= ns.ITEM_ARMOR) then
    return nil
  end
  local ilvl = it.ilvl
  if type(ilvl) ~= "number" or ilvl ~= ilvl then return nil end
  local rows = it.quality == 3 and ns.DE_RARE or it.classID == ns.ITEM_WEAPON and ns.DE_WEAPON or ns.DE_ARMOR
  local auc = g("Auctionator")
  local api = type(auc) == "table" and type(auc.API) == "table" and auc.API.v1
  local price = type(api) == "table" and api.GetAuctionPriceByItemID
  if type(price) ~= "function" then return nil end
  for _, row in ipairs(rows) do
    if ilvl >= row[1] and ilvl <= row[2] then
      local sum = 0
      for i = 3, #row do
        local id, chance, count = row[i][1], row[i][2], row[i][3]
        local v = call(price, "UW_Guild", id)
        if type(v) ~= "number" or ns.isSecret(v) or v ~= v or v <= 0 then
          if chance >= ns.DE_LIKELY then return nil end
        else
          sum = sum + chance * count * v
        end
      end
      local est = math.floor(sum * ns.AH_KEEP)
      return est > 0 and est or nil
    end
  end
end
-- Copper a disenchant brings, and true when it is our estimate rather than Auctionator's own number.
function ns.DisenchantWorth(link)
  local auc = g("Auctionator")
  local api = type(auc) == "table" and type(auc.API) == "table" and auc.API.v1
  local v = api and call(api.GetDisenchantPriceByItemLink, "UW_Guild", link)
  if type(v) == "number" and not ns.isSecret(v) and v > 0 then
    deTrace(true, "Auctionator gave a number")
    return v, false
  end
  local enchant = type(auc) == "table" and auc.Enchant
  deTrace(false, not api and "no Auctionator" or type(api.GetDisenchantPriceByItemLink) ~= "function" and "no API call"
    or (type(enchant) == "table" and type(enchant.GetDisenchantAuctionPrice) == "function")
      and "Auctionator has no number for this piece"
    or "Auctionator's disenchant code is not loaded")
  local est = ns.DisenchantEstimate(link)
  if est then return est, true end
end
-- Louis's first save with it (15 Nov 2026, 17:37 UTC) held one miss: "Auctionator has no number for this piece". So
-- its disenchant code is loaded on Forever, but one piece can't say whether it prices Forever's gear at all: the
-- retail tables answer nothing for Classic items, and the Classic ones skip a piece whose mats the scan lacks. Once a
-- session, at the first vendor or mailbox with a green or blue weapon or piece of armour in the bags, the bot's PC
-- counts how many of them get a number: every such piece, kept or not, since this asks about Auctionator and not
-- about what to sell. One trace row: the two counts, the item levels, and the function names in Auctionator.Enchant
-- (which say whose tables are loaded). Nothing is shown and nothing leaves the save.
local probed = false
function ns.DisenchantProbe()
  if probed or not (ns.SyncBotPC ~= nil and ns.SyncBotPC() == true) then return end
  local auc = g("Auctionator")
  local api = type(auc) == "table" and type(auc.API) == "table" and auc.API.v1
  local ask = type(api) == "table" and api.GetDisenchantPriceByItemLink
  if type(ask) ~= "function" then return end
  local c = g("C_Container") or {}
  local n, priced, low, high = 0, 0, nil, nil
  for bag = 0, g("NUM_BAG_SLOTS") or 4 do
    for slot = 1, (call(c.GetContainerNumSlots, bag) or 0) do
      local item = call(c.GetContainerItemInfo, bag, slot)
      local link = type(item) == "table" and item.hyperlink
      local it = link and ns.ItemInfo(link)
      if it and not ns.isSecret(it.quality) and not ns.isSecret(it.classID) and ns.ADVICE_QUALITY[it.quality]
        and (it.classID == ns.ITEM_WEAPON or it.classID == ns.ITEM_ARMOR) then
        n = n + 1
        local v = call(ask, "UW_Guild", link)
        if type(v) == "number" and not ns.isSecret(v) and v > 0 then priced = priced + 1 end
        if type(it.ilvl) == "number" and not ns.isSecret(it.ilvl) and it.ilvl == it.ilvl then -- not a NaN
          low, high = math.min(low or it.ilvl, it.ilvl), math.max(high or it.ilvl, it.ilvl)
        end
      end
    end
  end
  if n == 0 then return end -- nothing to ask about yet: the next vendor or mailbox tries again
  probed = true
  local names = {}
  if type(auc.Enchant) == "table" then
    for k, v in pairs(auc.Enchant) do
      if #names >= 40 then break end -- the row holds 80 characters; a huge table is not worth walking
      if type(k) == "string" and type(v) == "function" then
        names[#names + 1] = (k:gsub("Disenchant", "de"):gsub("^Get", ""):gsub("[^%w_]", ""):lower())
      end
    end
    table.sort(names)
  end
  -- All of it in the reason, numbers and lower-case labels only: hardening's save read prints a reason of a known
  -- shape and never the "who" field (it can hold a name). Always a "done" row, none priced included (see deTrace).
  ns.trace("advice", "disenchant probe", true, ("%d of %d priced, ilvl %s to %s, %d fns: %s"):format(priced, n,
    tostring(low or "?"), tostring(high or "?"), #names, table.concat(names, " ")))
end
-- `item` = { id, link, bag, slot, bound }; `it` from ItemInfo; `sets` as for KeepReason.
function ns.BestUse(item, it, sets)
  if not it or not ns.ADVICE_QUALITY[it.quality] then return nil end
  if it.classID ~= ns.ITEM_WEAPON and it.classID ~= ns.ITEM_ARMOR then return nil end
  if ns.KeepReason(item, it, false, sets) then return nil end
  if not ns.MightWear or ns.MightWear(item.link) then return nil end
  local level = call(g("UnitLevel"), "player")
  if type(level) ~= "number" or ns.isSecret(level) or (it.minLevel or 0) > level then return nil end
  local de, estimated = ns.DisenchantWorth(item.link)
  if not de then return nil end
  local vendor = it.price or 0
  local home, alt = false, nil
  if ns.Disenchanter then home, alt = ns.Disenchanter() end
  if item.bound then alt = nil end
  local net = home and de or (alt and de - ns.Postage(1)) or nil
  local worth, fromAH = ns.ItemWorth(item.link, it)
  if fromAH and not item.bound and worth > math.max(vendor, net or 0) then return "auction", worth end
  if net and net > vendor * (estimated and ns.DE_ESTIMATE_MARGIN or 1) then
    return "disenchant", net, not home and alt or nil
  end
  if not item.bound and not ns.AuctionPriced(item.link) then return nil end
  if vendor > 0 then return "vendor", vendor end
  return nil
end

-- Has the player's last scan a price for it at all?
function ns.AuctionPriced(link)
  local auc = g("Auctionator")
  local api = type(auc) == "table" and type(auc.API) == "table" and auc.API.v1
  local ah = api and call(api.GetAuctionPriceByItemLink, "UW_Guild", link)
  return type(ah) == "number" and not ns.isSecret(ah) and ah > 0
end

function ns.IsJunkKind(it)
  return it ~= nil and (it.quality == 0
    or (it.quality == 1 and (it.classID == ns.ITEM_WEAPON or it.classID == ns.ITEM_ARMOR)))
end

local function setItems()
  local out, sets = {}, g("C_EquipmentSet")
  for _, id in ipairs((sets and call(sets.GetEquipmentSetIDs)) or {}) do
    for _, item in pairs((call(sets.GetItemIDs, id)) or {}) do out[item] = true end
  end
  return out
end

-- The player's own "never sell" entries in EnhanceQoL (not the ones auto-equip adds while it asks).
local function eqolNeverSell(id)
  local e = g("EnhanceQoL")
  local list = type(e) == "table" and type(e.db) == "table" and e.db.vendorExcludeSellList
  if type(list) ~= "table" or not list[id] then return false end
  local held = UW_GuildCharDB and UW_GuildCharDB.vendorHeld
  return not (type(held) == "table" and held[id])
end

-- ForeverWowCraft (kit extra, profession leveling routes; Louis, 13 Nov 2026: "no elements can EVER interfere"). Its
-- helper writes each auction house's routes into the game (FWCS_PLANS, format fwc-plans/1: its fwchelper/plans.py),
-- and the addon keeps each character's skills (FWCS_DB.__chars). What this character's routes still use, and what
-- they made (pieces kept to sell), must stay in the bags: Mats to your alts (Mail.lua) and Delete / Make room
-- (BagRoom.lua) leave them alone. Read only, every field checked: if ForeverWowCraft isn't there or changes its format,
-- this finds nothing and UW_Guild does what it did before. Worked out again at most every FWC_EVERY seconds.
ns.FWC_EVERY = 30
local fwcCache, fwcAt = nil, -math.huge

local function addId(set, v)
  local id = tonumber(v)
  if id and id > 0 then set[id] = true end
end
local function addList(set, rows)
  if type(rows) ~= "table" then return end
  for _, v in ipairs(rows) do addId(set, v) end
end
local function addPairs(set, rows) -- { { item, units }, ... }
  if type(rows) ~= "table" then return end
  for _, r in ipairs(rows) do if type(r) == "table" then addId(set, r[1]) end end
end

-- One route from `rank` on: each step's product (even a step already done: what's left to sell), and what the steps
-- still ahead use, buy, make on the way (and what that takes), learn from, and the camp tools they need.
local function addRoute(set, plan, rank)
  local made = type(plan.made) == "table" and plan.made or {}
  for _, s in ipairs(plan.steps) do
    if type(s) == "table" then
      if type(s.makes) == "table" then addId(set, s.makes[1]) end
      if (tonumber(s.to) or 0) > rank then
        addPairs(set, s.uses)
        addList(set, s.buy)
        addList(set, s.craft)
        if type(s.learn) == "table" then addId(set, s.learn[1]) end
        for _, item in ipairs(type(s.craft) == "table" and s.craft or {}) do
          local m = made[item] or made[tostring(item)]
          if type(m) == "table" then addPairs(set, m[2]) end
        end
      end
    end
  end
  if (tonumber(plan.target) or 300) > rank and type(plan.camp) == "table" then
    for _, c in ipairs(plan.camp) do if type(c) == "table" then addId(set, c[1]) end end
  end
end

local function fwcItems()
  local docs, db = g("FWCS_PLANS"), g("FWCS_DB")
  local chars = type(db) == "table" and db.__chars
  if type(docs) ~= "table" or type(chars) ~= "table" then return false end
  local name, realm = (call(g("UnitName"), "player")), (call(g("GetRealmName")))
  local me
  for _, c in pairs(chars) do
    if type(c) == "table" and c.name == name and (realm == nil or c.realm == realm) then me = c break end
  end
  if not me or type(me.skills) ~= "table" then return false end
  local set, any = {}, false
  for _, doc in pairs(docs) do
    if type(doc) == "table" and (doc.faction == nil or doc.faction == "" or doc.faction == me.faction) then
      for _, group in ipairs({ doc.plans or false, doc.also or false }) do
        for _, plan in pairs(type(group) == "table" and group or {}) do
          local rank = type(plan) == "table" and type(plan.steps) == "table" and tonumber(me.skills[plan.skill_line])
          if rank and rank > 0 then -- a profession this character has (the window shows the others' routes too)
            addRoute(set, plan, rank)
            any = true
          end
        end
      end
    end
  end
  return any and set or false
end

-- { [itemID] = true } for this character's ForeverWowCraft routes, or nil without any.
function ns.FwcRouteItems()
  local now = (g("GetTime") or time)()
  if fwcCache == nil or now - fwcAt >= ns.FWC_EVERY then
    local ok, set = pcall(fwcItems)
    fwcCache, fwcAt = ok and set or false, now
  end
  return fwcCache or nil
end
function ns.OnFwcRoute(id)
  local set = id and ns.FwcRouteItems()
  return set ~= nil and set[id] == true
end
-- Worked out again at the next look (a test, or the skills a route reads just changed).
function ns.FwcForget() fwcCache = nil end

-- Why an item must stay, or nil. `item` = { id, link, bag, slot } (bag and slot nil for loot); `it` from ItemInfo;
-- `isQuest` for loot (the loot window says so). One equipment-set lookup per call: pass `sets` to reuse one.
function ns.KeepReason(item, it, isQuest, sets)
  local id = item.id
  if isQuest then return "a quest item" end
  if item.bag then
    local q = call((g("C_Container") or {}).GetContainerItemQuestInfo, item.bag, item.slot)
    if q and (q.isQuestItem or q.questID) then return "a quest item" end
  end
  if it and it.bindType == 4 then return "a quest item" end
  if ns.ITEM_TOOLS[id] then return "a profession tool" end
  if it and KEEP_LOC[it.loc or ""] then return KEEP_LOC[it.loc] end
  if (sets or setItems())[id] then return "in an equipment set" end
  local keep = UW_GuildCharDB and UW_GuildCharDB.keepItems
  if type(keep) == "table" and keep[id] then return "kept by you" end
  if ns.OnFwcRoute(id) then return "on your ForeverWowCraft route" end
  if eqolNeverSell(id) then return "on EnhanceQoL's never-sell list" end
  local held = UW_GuildCharDB and UW_GuildCharDB.vendorHeld
  if type(held) == "table" and held[id] then return "auto-equip is asking about it" end
  if ns.GearUndoId and ns.GearUndoId() == id then return "/uw gear undo needs it" end
  if ns.MightUpgrade and item.link and ns.MightUpgrade(item.link, item.bag ~= nil) then return "a possible upgrade" end
  return nil
end
ns.EquipmentSetItems = setItems

-- One tooltip line on a green or blue weapon or piece of armour: "Disenchant (estimate): 1g 20s" (coordinator, 15 Nov
-- 2026, 13:59 UTC: his PC only, labelled an estimate until real disenchants on Forever have been compared with it).
-- Only where Auctionator has no number of its own (its own line, when he ticks it, says the rest), only with the bag
-- buttons on (/uw bags off), never in combat, and only on the game's own item tooltip and a clicked item link.
local TIPS = { GameTooltip = true, ItemRefTooltip = true }
function ns.DisenchantTipText(link)
  if not (ns.GearAdviceHere and ns.GearAdviceHere()) or call(g("InCombatLockdown")) then return nil end
  if type(link) ~= "string" or ns.isSecret(link) then return nil end
  local auc = g("Auctionator")
  local api = type(auc) == "table" and type(auc.API) == "table" and auc.API.v1
  local own = api and call(api.GetDisenchantPriceByItemLink, "UW_Guild", link)
  if type(own) == "number" and not ns.isSecret(own) and own > 0 then return nil end
  local est = ns.DisenchantEstimate(link)
  if not est then return nil end
  local currency = g("C_CurrencyInfo")
  local fmt = g("GetCoinTextureString") or (currency and currency.GetCoinTextureString)
  return "Disenchant (estimate): " .. (call(fmt, est) or (est .. "c"))
end
function ns.DisenchantTip(tooltip)
  if type(tooltip) ~= "table" or type(tooltip.GetItem) ~= "function" or type(tooltip.AddLine) ~= "function" then return end
  local name = type(tooltip.GetName) == "function" and call(tooltip.GetName, tooltip)
  if not TIPS[name] then return end
  local _, link = call(tooltip.GetItem, tooltip)
  local text = ns.DisenchantTipText(link)
  if text then tooltip:AddLine(text, 1, 1, 1) end
end
do
  local tdp, enum = g("TooltipDataProcessor"), g("Enum")
  local kind = type(enum) == "table" and type(enum.TooltipDataType) == "table" and enum.TooltipDataType.Item
  if type(tdp) == "table" and type(tdp.AddTooltipPostCall) == "function" and kind ~= nil then
    tdp.AddTooltipPostCall(kind, function(tooltip) ns.protect(function() ns.DisenchantTip(tooltip) end) end)
  else
    for name in pairs(TIPS) do
      local tip = g(name)
      if type(tip) == "table" and type(tip.HookScript) == "function" then
        pcall(tip.HookScript, tip, "OnTooltipSetItem", function(self) ns.protect(function() ns.DisenchantTip(self) end) end)
      end
    end
  end
end
