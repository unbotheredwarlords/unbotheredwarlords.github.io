-- One set of item rules for everything UW_Guild does to the bags (Louis, 5 Nov 2026: "are you sure that's really the
-- absolute very best you can do", on the loot filter). Make room, Delete, Left behind (BagRoom.lua), auto-equip
-- (AutoEquip.lua) and EnhanceQoL's auto-sell guard all ask the same questions here, so one never undoes another:
--   * What is it worth? The higher of the vendor price and Auctionator's last scan, per item (ns.ItemWorth).
--   * Is it junk at all? Only greys, and plain white weapons and armour (ns.IsJunkKind). Mats, food, containers,
--     recipes, keys, hearthstones and everything else are never junk.
--   * Must it stay? ns.KeepReason names why: a quest item or one that starts a quest, a profession tool, a shirt,
--     tabard, bag, quiver or ammo, a piece in an equipment set, a piece auto-equip is asking about or could undo to,
--     a piece that would be an upgrade, anything on EnhanceQoL's "never sell" list (the player's own entries), and
--     anything the player kept with Shift-click on Delete (UW_GuildCharDB.keepItems; /uw bags forget clears it).
-- This mirrors what Scrap, Peddler and Dejunk do for selling (a never-list, quest and tool guards, a value threshold
-- that asks first), applied to deleting and leaving loot, which can't be bought back.
local _, ns = ...

local function g(name) return rawget(_G, name) end
local function call(fn, ...)
  if type(fn) ~= "function" then return nil end
  local ok, a, b, c, d, e, f, h, i, j, k, l, m, n, o = pcall(fn, ...)
  if ok then return a, b, c, d, e, f, h, i, j, k, l, m, n, o end
end

ns.ITEM_WEAPON, ns.ITEM_ARMOR, ns.ITEM_TRADE_GOODS = 2, 4, 7
ns.DELETE_ASK_COPPER = 10000 -- Delete asks first when the junk is worth this much or more (1 gold)

-- Profession tools. Most are white weapons (pick, hammer, knife, poles), so they'd look like junk.
ns.ITEM_TOOLS = {
  [2901] = true,  -- Mining Pick
  [5956] = true,  -- Blacksmith Hammer
  [7005] = true,  -- Skinning Knife
  [6219] = true,  -- Arclight Spanner
  [10498] = true, -- Gyromatic Micro-Adjustor
  [6256] = true, [6365] = true, [6366] = true, [6367] = true, [12225] = true, [19022] = true, [19970] = true, -- poles
  [6218] = true, [6339] = true, [11130] = true, [11145] = true, [16207] = true, -- enchanting rods
}
local KEEP_LOC = { INVTYPE_BODY = "a shirt", INVTYPE_TABARD = "a tabard", INVTYPE_BAG = "a bag",
  INVTYPE_QUIVER = "a quiver", INVTYPE_AMMO = "ammo" }

function ns.ItemInfo(link)
  local items = g("C_Item") or {}
  local name, _, quality, ilvl, _, _, _, stackMax, loc, _, price, classID, subID, bindType =
    call(items.GetItemInfo or g("GetItemInfo"), link)
  if not name then return nil end
  return { name = name, quality = quality, ilvl = ilvl, stackMax = stackMax or 1, loc = loc, price = price or 0,
    classID = classID, sub = subID, bindType = bindType }
end

-- Worth per item: the higher of vendor and Auctionator, and whether Auctionator's was the higher.
function ns.ItemWorth(link, it)
  local vendor = it and it.price or 0
  local auc = g("Auctionator")
  local api = type(auc) == "table" and type(auc.API) == "table" and auc.API.v1
  local ah = api and call(api.GetAuctionPriceByItemLink, "UW_Guild", link)
  ah = type(ah) == "number" and ah or 0
  return math.max(vendor, ah), ah > vendor
end

function ns.IsJunkKind(it)
  return it ~= nil and (it.quality == 0
    or (it.quality == 1 and (it.classID == ns.ITEM_WEAPON or it.classID == ns.ITEM_ARMOR)))
end

local function setItems()
  local out, sets = {}, g("C_EquipmentSet")
  for _, id in ipairs((sets and call(sets.GetEquipmentSetIDs)) or {}) do
    for _, item in pairs((call(sets.GetItemIDs, id)) or {}) do out[item] = true end
  end
  return out
end

-- The player's own "never sell" entries in EnhanceQoL (not the ones auto-equip adds while it asks).
local function eqolNeverSell(id)
  local e = g("EnhanceQoL")
  local list = type(e) == "table" and type(e.db) == "table" and e.db.vendorExcludeSellList
  if type(list) ~= "table" or not list[id] then return false end
  local held = UW_GuildCharDB and UW_GuildCharDB.vendorHeld
  return not (type(held) == "table" and held[id])
end

-- ForeverWowCraft (kit extra, profession leveling routes; Louis, 13 Nov 2026: "no elements can EVER interfere"). Its
-- helper writes each auction house's routes into the game (FWCS_PLANS, format fwc-plans/1: its fwchelper/plans.py),
-- and the addon keeps each character's skills (FWCS_DB.__chars). What this character's routes still use, and what
-- they made (pieces kept to sell), must stay in the bags: Mats to your alts (Mail.lua) and Delete / Make room
-- (BagRoom.lua) leave them alone. Read only, every field checked: if ForeverWowCraft isn't there or changes its format,
-- this finds nothing and UW_Guild does what it did before. Worked out again at most every FWC_EVERY seconds.
ns.FWC_EVERY = 30
local fwcCache, fwcAt = nil, -math.huge

local function addId(set, v)
  local id = tonumber(v)
  if id and id > 0 then set[id] = true end
end
local function addList(set, rows)
  if type(rows) ~= "table" then return end
  for _, v in ipairs(rows) do addId(set, v) end
end
local function addPairs(set, rows) -- { { item, units }, ... }
  if type(rows) ~= "table" then return end
  for _, r in ipairs(rows) do if type(r) == "table" then addId(set, r[1]) end end
end

-- One route from `rank` on: each step's product (even a step already done: what's left to sell), and what the steps
-- still ahead use, buy, make on the way (and what that takes), learn from, and the camp tools they need.
local function addRoute(set, plan, rank)
  local made = type(plan.made) == "table" and plan.made or {}
  for _, s in ipairs(plan.steps) do
    if type(s) == "table" then
      if type(s.makes) == "table" then addId(set, s.makes[1]) end
      if (tonumber(s.to) or 0) > rank then
        addPairs(set, s.uses)
        addList(set, s.buy)
        addList(set, s.craft)
        if type(s.learn) == "table" then addId(set, s.learn[1]) end
        for _, item in ipairs(type(s.craft) == "table" and s.craft or {}) do
          local m = made[item] or made[tostring(item)]
          if type(m) == "table" then addPairs(set, m[2]) end
        end
      end
    end
  end
  if (tonumber(plan.target) or 300) > rank and type(plan.camp) == "table" then
    for _, c in ipairs(plan.camp) do if type(c) == "table" then addId(set, c[1]) end end
  end
end

local function fwcItems()
  local docs, db = g("FWCS_PLANS"), g("FWCS_DB")
  local chars = type(db) == "table" and db.__chars
  if type(docs) ~= "table" or type(chars) ~= "table" then return false end
  local name, realm = (call(g("UnitName"), "player")), (call(g("GetRealmName")))
  local me
  for _, c in pairs(chars) do
    if type(c) == "table" and c.name == name and (realm == nil or c.realm == realm) then me = c break end
  end
  if not me or type(me.skills) ~= "table" then return false end
  local set, any = {}, false
  for _, doc in pairs(docs) do
    if type(doc) == "table" and (doc.faction == nil or doc.faction == "" or doc.faction == me.faction) then
      for _, group in ipairs({ doc.plans or false, doc.also or false }) do
        for _, plan in pairs(type(group) == "table" and group or {}) do
          local rank = type(plan) == "table" and type(plan.steps) == "table" and tonumber(me.skills[plan.skill_line])
          if rank and rank > 0 then -- a profession this character has (the window shows the others' routes too)
            addRoute(set, plan, rank)
            any = true
          end
        end
      end
    end
  end
  return any and set or false
end

-- { [itemID] = true } for this character's ForeverWowCraft routes, or nil without any.
function ns.FwcRouteItems()
  local now = (g("GetTime") or time)()
  if fwcCache == nil or now - fwcAt >= ns.FWC_EVERY then
    local ok, set = pcall(fwcItems)
    fwcCache, fwcAt = ok and set or false, now
  end
  return fwcCache or nil
end
function ns.OnFwcRoute(id)
  local set = id and ns.FwcRouteItems()
  return set ~= nil and set[id] == true
end
-- Worked out again at the next look (a test, or the skills a route reads just changed).
function ns.FwcForget() fwcCache = nil end

-- Why an item must stay, or nil. `item` = { id, link, bag, slot } (bag and slot nil for loot); `it` from ItemInfo;
-- `isQuest` for loot (the loot window says so). One equipment-set lookup per call: pass `sets` to reuse one.
function ns.KeepReason(item, it, isQuest, sets)
  local id = item.id
  if isQuest then return "a quest item" end
  if item.bag then
    local q = call((g("C_Container") or {}).GetContainerItemQuestInfo, item.bag, item.slot)
    if q and (q.isQuestItem or q.questID) then return "a quest item" end
  end
  if it and it.bindType == 4 then return "a quest item" end
  if ns.ITEM_TOOLS[id] then return "a profession tool" end
  if it and KEEP_LOC[it.loc or ""] then return KEEP_LOC[it.loc] end
  if (sets or setItems())[id] then return "in an equipment set" end
  local keep = UW_GuildCharDB and UW_GuildCharDB.keepItems
  if type(keep) == "table" and keep[id] then return "kept by you" end
  if ns.OnFwcRoute(id) then return "on your ForeverWowCraft route" end
  if eqolNeverSell(id) then return "on EnhanceQoL's never-sell list" end
  local held = UW_GuildCharDB and UW_GuildCharDB.vendorHeld
  if type(held) == "table" and held[id] then return "auto-equip is asking about it" end
  if ns.GearUndoId and ns.GearUndoId() == id then return "/uw gear undo needs it" end
  if ns.MightUpgrade and item.link and ns.MightUpgrade(item.link, item.bag ~= nil) then return "a possible upgrade" end
  return nil
end
ns.EquipmentSetItems = setItems
