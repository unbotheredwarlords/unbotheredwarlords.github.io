-- Raid-night ready line (addon-value item 4, before raids open 9 Dec 2026). When a raid forms, the leader's client runs
-- the existing kit check (ns.KitReply, the same reply /uw audit reads) on the raid only, and prints one line to the
-- leader's own chat: who lacks the kit's raid addons (boss mod first), who runs an older boss mod than the rest, and
-- which guildmates in the raid didn't answer (no UW_Guild, or one too old to know this check). A short checklist at a
-- fixed moment catches what memory misses (Haynes et al. 2009, NEJM).
--   * Once per raid, out of combat, after the roster has been still for 20 seconds with 5 or more in it.
--   * Only a leader the raid trusts (ns.trustedLeader: Raider rank or up, leading or assisting) can ask; each client
--     answers at most once a minute, by whisper to that leader. Nothing is posted to the raid. No new command.
local _, ns = ...
local say = ns.say

local SETTLE, WAIT, MIN_SIZE, NAMES = 20, 6, 5, 6
local done, collecting, settleToken = false, nil, 0
local lastAnswer = -math.huge

local function short(n) return ns.shortName(n) or n end
local function list(names)
  table.sort(names)
  if #names <= NAMES then return table.concat(names, ", ") end
  return table.concat(names, ", ", 1, NAMES) .. (" +%d"):format(#names - NAMES)
end

-- The raid's guildmates other than me, by short name (pugs can't be asked: they don't run UW_Guild).
local function guildmates()
  local out = {}
  for i = 1, GetNumGroupMembers() do
    local unit = "raid" .. i
    local name = GetRaidRosterInfo(i)
    if type(name) == "string" and not ns.isSecret(name) and UnitIsInMyGuild(unit) and not UnitIsUnit(unit, "player") then
      out[short(name)] = true
    end
  end
  return out
end

-- The line from the replies: { [short] = { boss, bossVer, raid } } and the guildmates asked. Grouped by what's missing
-- (what the leader will say), at most 160 characters.
local LINE_MAX = 160
function ns.RaidReadyLine(rows, asked)
  local missing, old, silent, newest, order = {}, {}, {}, {}, {}
  local function mod(r) return r.boss == "both" and "DBM" or r.boss end -- "both" reports DBM's version
  for _, r in pairs(rows) do
    local m = mod(r)
    if m ~= "" and r.bossVer ~= "" and (not newest[m] or ns.CompareVersions(r.bossVer, newest[m]) > 0) then
      newest[m] = r.bossVer
    end
  end
  local n = 0
  for name in pairs(asked) do
    n = n + 1
    local r = rows[name]
    local need = r and (r.raid ~= "" and r.raid or r.boss == "" and "a boss mod" or nil)
    if not r then silent[#silent + 1] = name
    elseif need then
      if not missing[need] then missing[need] = {} order[#order + 1] = need end
      table.insert(missing[need], name)
    elseif r.bossVer ~= "" and ns.CompareVersions(r.bossVer, newest[mod(r)]) < 0 then old[#old + 1] = name end
  end
  if n == 0 then return nil end
  if #order + #old + #silent == 0 then
    return n == 1 and "Raid ready: your guildmate has UW_Guild and the raid addons."
      or ("Raid ready: all %d guildmates have UW_Guild and the raid addons."):format(n)
  end
  table.sort(order)
  local parts = {}
  for _, need in ipairs(order) do parts[#parts + 1] = "no " .. need .. ": " .. list(missing[need]) .. "." end
  if #old > 0 then parts[#parts + 1] = "Older boss mod: " .. list(old) .. "." end
  if #silent > 0 then parts[#parts + 1] = "No UW_Guild reply: " .. list(silent) .. "." end
  local line = "Raid check: " .. table.concat(parts, " ")
  if #line > LINE_MAX then line = line:sub(1, LINE_MAX - 3):gsub("[^ ,.]*$", "") .. "..." end
  return line
end

local function leading()
  return IsInRaid() and UnitIsGroupLeader("player") and ns.tracksGuild() and ns.canShareRaid(ns.me())
end

local function check()
  if done or collecting or not leading() or InCombatLockdown() or GetNumGroupMembers() < MIN_SIZE then return end
  local asked = guildmates()
  if not next(asked) then return end
  if not ns.send("RDYQ", "RAID") then return end
  done, collecting = true, { rows = {}, asked = asked, at = time() }
  ns.after(WAIT, function()
    local c = collecting
    collecting = nil
    -- A /uw audit started in the window took the replies (Core.lua): it shows them, so no line here.
    local a = UW_GuildDB.lastAudit
    if not c or (type(a) == "table" and (a.at or 0) >= c.at) then return end
    local line = ns.RaidReadyLine(c.rows, c.asked)
    if line then say(line) end
  end)
end

-- Raid members answer a trusted leader with the kit reply /uw audit uses.
ns.handlers.RDYQ = function(sender, channel)
  if channel ~= "RAID" or not ns.trustedLeader(sender) or GetTime() - lastAnswer < 60 then return end
  lastAnswer = GetTime()
  ns.after(math.random() * 2, function() ns.send(ns.KitReply(), "WHISPER", sender) end)
end

-- KIT whispers reach here while no /uw audit runs (Core.lua hands them to the audit when one does).
ns.handlers.KIT = function(sender, channel, _, _, _, boss, raid, _, bossVer)
  local name = short(sender)
  if not collecting or channel ~= "WHISPER" or not collecting.asked[name] then return end
  collecting.rows[name] = { boss = boss or "", raid = raid or "", bossVer = bossVer or "" }
end

local f = CreateFrame("Frame")
ns.listen(f, { "GROUP_ROSTER_UPDATE", "PLAYER_REGEN_ENABLED" })
f:SetScript("OnEvent", ns.guard(function()
  if not IsInRaid() then done = false return end -- a new raid gets its own check
  if done then return end
  settleToken = settleToken + 1
  local token = settleToken
  ns.after(SETTLE, function() if token == settleToken then ns.protect(check) end end)
end))
ns.RaidReadyCheck = check
