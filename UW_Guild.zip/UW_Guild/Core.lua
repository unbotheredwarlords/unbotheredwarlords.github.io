-- UW_Guild: guild kit checker, officer audit, and Discord outbox for WoW: Forever (Interface 16001).
local ADDON, ns = ...
local PREFIX = "UWG1"
local VERSION = C_AddOns.GetAddOnMetadata(ADDON, "Version") or "dev"
if VERSION:find("@") then VERSION = "dev" end

-- Guild config -------------------------------------------------------------
-- UW_Guild's job (Louis, 4 Nov 2026): keep every other addon in the kit working well together, the same way for
-- everyone. ns.KIT below is the kit as shipped. Officers change it in game (/uw kit add, remove, pair: KitShare.lua),
-- and that version reaches every member without a new release; /uw kit reset goes back to this one.
-- An entry is an addon folder name, or a list of alternatives where any one counts. Sorted so a newcomer isn't
-- swamped (docs/future/raid-kit.md): everyone needs two, raiders one more (Louis, 4 Nov 2026: the boss mod is for
-- raiders only), and the extras are optional, one per goal (goals: same order as extras). The lists follow Louis's own
-- UI (5 Nov 2026, his character Veda Skyseer; docs/addon-pack.md): EllesmereUI's own bags and meter instead of
-- Baganator and Details; DialogueUI is the first extra, optional but highly recommended (Louis, 5 Nov). Keep in step with KIT_EVERYONE / KIT_RAIDING / KIT_EXTRAS in
-- bot/uwbot/layout.py (a bot test compares them).
ns.KIT = {
  everyone  = { "EllesmereUI", "Questie" },
  raiding   = { { "DBM-Core", "BigWigs" } },
  extras    = { "DialogueUI", "ForeverDungeonJournal", "Auctionator", "RareScanner", { "OpenMap", "Leatrix_Maps" }, "ForeverLootSparkles", "GatherLite", "Manners", "EnhanceQoL", "Spoken", "Attune", "!BugGrabber" },
  goals     = { "Quest and NPC text (highly recommended)", "Dungeon and raid journal", "Selling and buying", "Rares", "World map", "Loot, ore and herb sparkles", "Herb, ore and fish map", "Buff back in one click", "Small comforts (selling junk, sounds)", "Quests read aloud (big download)", "Attunements and dungeon quests", "Troubleshooting (catches errors)" },
  -- Flagged when both load: two addons doing one job fight each other or split attention (docs/future/redundancy-pass.md).
  -- Each pair is { keep, turn off }: /uw kit fix turns off the second one. The EnhanceQoL pairs follow each module's own
  -- description; the tooltip pair follows EllesmereUI's own conflict list, which names tooltip-ID addons (idTip).
  conflicts = { { "DBM-Core", "BigWigs" }, { "EllesmereUIBags", "Baganator" }, { "EllesmereUIBags", "Bagnon" }, { "EllesmereUIBags", "EnhanceQoLBags" }, { "EllesmereUIDamageMeters", "Details" }, { "EllesmereUIDamageMeters", "EnhanceQoLDamageMeter" }, { "EllesmereUIChat", "Chattynator" }, { "EllesmereUIChat", "EnhanceQoLChatSocial" }, { "EllesmereUIUnitFrames", "EnhanceQoLUnitFrames" }, { "EllesmereUIResourceBars", "EnhanceQoLResourceBars" }, { "EllesmereUICooldownManager", "EnhanceQoLCooldownPanels" }, { "EllesmereUIAuraBuffReminders", "EnhanceQoLClassBuffReminder" }, { "EllesmereUIBlizzardSkin", "EnhanceQoLSkinner" }, { "EllesmereUI", "EnhanceQoLTooltip" }, { "OpenMap", "Leatrix_Maps" }, { "GatherLite", "GatherMate2" } },
}
ns.OFFICER_MAX_RANK = 1    -- rankIndex 0 = Guild Master. Only these ranks may trigger /uw audit.
-- In-game rank names (lowercase) that mean "recruit". New members start as Trial (bot/uwbot/layout.py). Initiate
-- is where WoW puts new invites in a guild whose ranks haven't been renamed yet (the default five ranks).
ns.RECRUIT_RANKS = { trial = true, recruit = true, initiate = true }
ns.MILESTONES = { [10] = true, [20] = true, [30] = true, [40] = true, [50] = true, [60] = true }
ns.MAX_OUTBOX = 1000     -- launch day can bring hundreds of joins before the bot reads the file
ns.MAX_BACKLOG_POSTS = 15  -- after a long absence, cap queued level posts per scan
ns.MAX_ATTENDANCE = 500    -- kill snapshots kept (about 25 weeks of two raids)

local CHAT_ICON = "|TInterface\\AddOns\\UW_Guild\\Media\\emblem:14:14|t"
local function say(msg)
  print(CHAT_ICON .. " |cffc41e3aUW|r " .. msg)
  if ns.echo then ns.echo(msg) end -- the options page shows its buttons' answers too (Options.lua)
end
local function isSecret(v) return issecretvalue and issecretvalue(v) end
ns.say, ns.isSecret, ns.VERSION = say, isSecret, VERSION

-- Start-up isolation (Louis, 4 Nov 2026: launch has to go well while he levels). The tests only model the Forever
-- client, so each file's start-up, each message handler and each /uw command runs protected: one that fails on the
-- real client can't stop the others. The error still goes to the game's error handler (BugSack shows it with its
-- stack); the last few are also kept in UW_GuildDB.errors, so /uw kit report and the launch check (it reads
-- SavedVariables) see what broke without anyone copying it. A message seen again only counts up.
ns.MAX_ERRORS = 10
local errorNoted = false
ns.ownErrors = 0 -- this session
-- Full reports without anyone pasting chat (Louis, 8 Nov 2026): each kept error also holds its stack (UW_Guild's own
-- lines first, 600 characters) and where it last happened: zone, instance type, in combat or not.
local function stackOf(depth)
  local raw = debugstack and debugstack(depth or 3, 12, 0)
  if type(raw) ~= "string" then return nil end
  local own, other = {}, {}
  for l in raw:gmatch("[^\n]+") do
    l = l:gsub("|", " ")
    if l:find("UW_Guild", 1, true) then own[#own + 1] = l elseif not l:find("^%s*%[C%]") then other[#other + 1] = l end
  end
  for _, l in ipairs(other) do own[#own + 1] = l end
  return table.concat(own, "\n"):sub(1, 600)
end
local function context()
  local zone = GetRealZoneText and GetRealZoneText()
  local kind = GetInstanceInfo and select(2, GetInstanceInfo())
  return type(zone) == "string" and not isSecret(zone) and zone:sub(1, 40) or nil,
    type(kind) == "string" and not isSecret(kind) and kind or nil, InCombatLockdown and InCombatLockdown() == true
end
local function noteError(err, depth)
  ns.ownErrors = ns.ownErrors + 1
  local msg = isSecret(err) and "(secret)" or tostring(err):gsub("[%c|]", " "):sub(1, 200)
  local db = UW_GuildDB
  if type(db) == "table" then
    db.errors = type(db.errors) == "table" and db.errors or {}
    local found
    for _, e in ipairs(db.errors) do if e.msg == msg then found = e break end end
    if found then found.n, found.at, found.ver = (found.n or 1) + 1, time(), VERSION
    else
      if #db.errors >= ns.MAX_ERRORS then table.remove(db.errors, 1) end
      found = { msg = msg, n = 1, at = time(), ver = VERSION, stack = stackOf(depth) }
      db.errors[#db.errors + 1] = found
    end
    found.zone, found.inst, found.combat = context()
  end
  if not errorNoted then
    errorNoted = true
    say("|cff808080Part of UW_Guild hit a problem on this client; the rest keeps working. /uw kit report shows it.|r")
  end
  return msg
end
-- The game's error handler (BugGrabber/BugSack) hears each distinct error once a session; every repeat is still
-- counted in UW_GuildDB.errors (n) for /uw kit report (Louis, 8 Nov 15:20: one bug on a timer reached 103x).
local forwarded = {}
local function onError(err)
  local msg = noteError(err, 4)
  if forwarded[msg] then return err end
  forwarded[msg] = true
  local handler = geterrorhandler and geterrorhandler()
  if handler then pcall(handler, err) end
  return err
end
-- Runs fn(...) protected; true when it finished.
function ns.protect(fn, ...)
  local n, args = select("#", ...), { ... }
  return (xpcall(function() return fn(unpack(args, 1, n)) end, onError))
end
local protect = ns.protect

-- Decision log (Louis, 8 Nov 2026: "make sure we're throwing bugs and errors into logs"): what a feature decided when
-- someone asked it for something, so a silent no-op leaves a trace too. The bot reads UW_GuildDB.trace at each save
-- (bot/uwbot/gametrace.py): misses go to its log with who and why, and to officers as counts. ok false is a miss (what
-- was asked for didn't happen; why says what stopped it), ok true says it did. Call it where an intent ends, never
-- per frame or per event. Bounded: misses and done each keep their last rows (a busy evening of done rows never
-- pushes a miss out before the next save), every field cut short, never chat text.
ns.TRACE_MISSES, ns.TRACE_DONE = 200, 100
local function traceField(v, max)
  if v == nil or isSecret(v) then return nil end
  return (tostring(v):gsub("[%c|]", " "):sub(1, max))
end
function ns.trace(area, what, ok, why, who)
  local db = UW_GuildDB
  if type(db) ~= "table" then return end
  local t = type(db.trace) == "table" and db.trace or {}
  db.trace = t
  local list, max = ok == true and "done" or "miss", ok == true and ns.TRACE_DONE or ns.TRACE_MISSES
  t[list] = type(t[list]) == "table" and t[list] or {}
  t.seq = (tonumber(t.seq) or 0) + 1
  while #t[list] >= max do table.remove(t[list], 1) end
  t[list][#t[list] + 1] = { n = t.seq, at = time(), area = traceField(area, 16) or "?", what = traceField(what, 24) or "?",
    why = traceField(why, 80), who = traceField(who, 48), ver = VERSION }
end

ns.handlers = {}  -- addon-message tag -> function(sender, channel, ...fields)
ns.commands = {}  -- /uw <cmd> -> function(args)
ns.onScan = {}    -- functions run after each trusted roster scan (ns.rankOf is current then)
ns.onLoad = {}    -- functions run once SavedVariables are ready
ns.onGuildJoin = {} -- functions run once per session, when the character is first seen in a guild
ns.onGuildKill = {} -- functions run with the boss name after a guild raid kill is recorded
ns.onQueue = {}     -- functions run with the kind after an outbox line is queued (Sync.lua)

-- Kit check ----------------------------------------------------------------
local function isLoaded(name) return (C_AddOns.IsAddOnLoaded(name)) end
-- Kit names are what /uw kit prints and KIT replies carry: "DBM-Core or BigWigs" for a list of alternatives.
local function kitName(e) return type(e) == "table" and table.concat(e, " or ") or e end
local function alternatives(kitname)
  local out = {}
  for n in (kitname .. " or "):gmatch("(.-) or ") do out[#out + 1] = n end
  return out
end
local function isInstalled(kitname)
  for _, n in ipairs(alternatives(kitname)) do
    local _, _, _, _, reason = C_AddOns.GetAddOnInfo(n)
    if reason ~= "MISSING" then return true end
  end
  return false
end
local function anyLoaded(e)
  for _, n in ipairs(type(e) == "table" and e or { e }) do if isLoaded(n) then return true end end
  return false
end

-- The boss mod this client runs, for /uw audit: DBM, BigWigs, both, or "" for none.
function ns.BossMod()
  local dbm, bw = isLoaded("DBM-Core"), isLoaded("BigWigs")
  return (dbm and bw) and "both" or dbm and "DBM" or bw and "BigWigs" or ""
end
-- Its version ("12.1.19"), so a raid leader sees who runs an old one: timers differ between versions. "" if unknown.
function ns.BossModVersion()
  local name = isLoaded("DBM-Core") and "DBM-Core" or isLoaded("BigWigs") and "BigWigs"
  local v = name and C_AddOns.GetAddOnMetadata(name, "Version")
  if type(v) ~= "string" or isSecret(v) then return "" end
  return (v:match("%d[%w%.%-]*") or ""):sub(1, 16)
end
-- -1, 0 or 1: "12.1.9" is older than "12.1.19" (numbers compared part by part).
function ns.CompareVersions(a, b)
  local pa, pb = {}, {}
  for n in tostring(a):gmatch("%d+") do pa[#pa + 1] = tonumber(n) end
  for n in tostring(b):gmatch("%d+") do pb[#pb + 1] = tonumber(n) end
  for i = 1, math.max(#pa, #pb) do
    local x, y = pa[i] or 0, pb[i] or 0
    if x ~= y then return x < y and -1 or 1 end
  end
  return 0
end

-- Missing from Everyone, missing extras, duplicates loaded together, missing from Raiding.
function ns.CheckKit()
  local missReq, missExtra, conflicts, missRaid = {}, {}, {}, {}
  for _, e in ipairs(ns.KIT.everyone) do if not anyLoaded(e) then missReq[#missReq + 1] = kitName(e) end end
  for _, e in ipairs(ns.KIT.extras) do if not anyLoaded(e) then missExtra[#missExtra + 1] = kitName(e) end end
  for _, e in ipairs(ns.KIT.raiding) do if not anyLoaded(e) then missRaid[#missRaid + 1] = kitName(e) end end
  for _, p in ipairs(ns.KIT.conflicts) do
    if isLoaded(p[1]) and isLoaded(p[2]) then conflicts[#conflicts + 1] = p[1] .. "+" .. p[2] end
  end
  return missReq, missExtra, conflicts, missRaid
end
ns.isInstalled, ns.isLoaded, ns.anyLoaded, ns.kitName = isInstalled, isLoaded, anyLoaded, kitName

-- Where anyone gets UW_Guild, Discord or not (site/addon.html; Louis 8 Nov 2026: our own GitHub page). No https://:
-- WoW can't open links, so it's read and typed.
ns.ADDON_URL = "unbotheredwarlords.github.io/addon"
-- Never installed an addon before? Where the kit's addons come from (bot setup.KIT_DESC says the same in #addon-kit).
ns.KIT_HOW = "New to addons? Get each free in the CurseForge or Wago app (pick the Forever version), then restart WoW."

local function printKit(quietIfOk)
  local missReq, _, conflicts, missRaid = ns.CheckKit()
  if #missReq == 0 and #conflicts == 0 and not quietIfOk then say("Kit OK (v" .. VERSION .. ").") end
  if quietIfOk and #missReq > 0 then -- at login: one line, not one per addon
    say(("|cffff4040Addon kit:|r add %s. /uw kit shows how."):format(table.concat(missReq, " and ")))
  else
    for _, n in ipairs(missReq) do
      say(("|cffff4040Missing (everyone):|r %s%s"):format(n, isInstalled(n) and " (installed but disabled)" or ""))
    end
  end
  local notInstalled = false
  for _, n in ipairs(missReq) do notInstalled = notInstalled or not isInstalled(n) end
  if notInstalled and not quietIfOk then say(ns.KIT_HOW) end
  -- Up to three pairs one line each; more as one line, so a full install isn't a wall of text (/uw kit fix follows).
  if #conflicts > 3 then
    say(("|cffff8000Duplicates:|r %d pairs do the same job (%s, …). Turn one of each off."):format(#conflicts,
      table.concat({ conflicts[1], conflicts[2] }, ", ")))
  else
    for _, c in ipairs(conflicts) do say("|cffff8000Duplicate:|r " .. c .. ". Turn one off.") end
  end
  if ns.KitHints then ns.KitHints(quietIfOk) end -- the one-step fix and the guild layout (KitShare.lua)
  if quietIfOk then return end
  for _, n in ipairs(missRaid) do
    say(("|cffffd100Needed to raid:|r %s%s"):format(n, isInstalled(n) and " (installed but disabled)" or ""))
  end
  if ns.KitTrouble then ns.KitTrouble() end
  say("Whole kit: /uw kit list. Optional extras by goal: /uw kit extras. Something broken? /uw kit report")
end
ns.printKit = printKit

-- The kit check 8 s after login. A brand-new install's first day stays quiet: the welcome panel shows the kit
-- gently, so the first thing a newcomer sees isn't red lines. After that, once a day on this account, not every
-- login (don't pester; /uw kit always answers).
local function loginKit()
  local now = time()
  local at = tonumber(UW_GuildDB.installedAt) or 0
  if at > 0 and now - at < 86400 then return end
  local day = math.floor(now / 86400)
  if UW_GuildDB.kitToldDay == day then return end
  UW_GuildDB.kitToldDay = day
  printKit(true)
end
ns.loginKit = loginKit
local function printExtras()
  for i, e in ipairs(ns.KIT.extras) do
    local have = anyLoaded(e)
    -- Plain characters: WoW's chat font has no check mark.
    say(("%s %s: %s"):format(have and "|cff40ff40[x]|r" or "|cff808080[  ]|r", ns.KIT.goals[i] or "", kitName(e)))
  end
end

-- Comms --------------------------------------------------------------------
local function canSend()
  if InCombatLockdown() then return false end
  -- Modern client blocks addon chat during encounters/restricted states.
  if C_ChatInfo.InChatMessagingLockdown and C_ChatInfo.InChatMessagingLockdown() then return false end
  return true
end

ns.canSend = canSend

local function send(msg, channel, target)
  if not canSend() then return false end
  local ok, result = pcall(C_ChatInfo.SendAddonMessage, PREFIX, msg, channel, target)
  -- The modern API returns a result code (0 = success); older builds return nothing or a boolean.
  return ok and (result == nil or result == true or result == 0)
end

-- Paced sends, one per 1.2 s from a single pacer for the whole UWG1 prefix. Classic throttles each prefix to a burst
-- of about 10 that refills about 1 per second, and at server open dozens of logins ask at once: a burst would lose the
-- same late askers on every officer's client, and two pacers of 1.2 s each (this one and the crafting directory's)
-- together sent more than the refill. Lanes, first served first, each with its own cap so one never crowds out
-- another:
--   1. officer whispers that answer a login (BUDDY, BUDN, INV). Past 60 waiting, more are skipped (other officers
--      answer too, and the member asks again at their next login).
--   2. live raid shares (Raid.lua: RK, RL, RU), at most 240 waiting.
--   3. catch-up answers to a guildmate's RQ (Raid.lua), at most 240 waiting; the answer is cut to the room left.
--   4. the crafting directory (Crafts.lua, Gear.lua: CRV, CRD, CRI, CRG, and an officer's CRQ and CRIQ asks), not
--      capped (as before it had its own queue).
-- In combat or messaging lockdown the queue waits instead of dropping what it holds. A message the game refuses
-- (throttled) stays at the head and is tried again every 2 s, at most 5 times, then skipped and noted once.
local lanes, LANE_CAP, draining = { {}, {}, {}, {} }, { 60, 240, 240, math.huge }, false
ns.SEND_GAP, ns.SEND_RETRY, ns.SEND_TRIES = 1.2, 2, 5
local refusedNoted = false
local function drain()
  local lane
  for _, l in ipairs(lanes) do if #l > 0 then lane = l break end end
  if not lane then draining = false return end
  -- Combat first: a share checked while combat holds the queue would count as started, and then hearing another
  -- client's copy during the fight could no longer cancel ours.
  if not canSend() then C_Timer.After(2, drain) return end
  local r = lane[1]
  if r.skip and r.skip() then table.remove(lane, 1) return drain() end -- cancelled while it waited
  if send(r.msg, r.channel, r.target) then
    table.remove(lane, 1)
    if r.sent then r.sent() end -- only now has it gone out (a refused try doesn't count)
    C_Timer.After(ns.SEND_GAP, drain)
    return
  end
  r.tries = (r.tries or 0) + 1
  if r.tries >= ns.SEND_TRIES then
    table.remove(lane, 1)
    if r.dropped then r.dropped() end
    if not refusedNoted then
      refusedNoted = true
      say("The game kept refusing some UW_Guild messages, so they were skipped. Guild records catch up at the next login.")
    end
  end
  C_Timer.After(ns.SEND_RETRY, drain)
end
local function enqueue(i, entry)
  if #lanes[i] >= LANE_CAP[i] then return false end
  lanes[i][#lanes[i] + 1] = entry
  if not draining then
    draining = true
    C_Timer.After(math.random() * 2, drain) -- jitter: officers online together don't answer in step
  end
  return true
end
function ns.reply(msg, target) return enqueue(1, { msg = msg, channel = "WHISPER", target = target }) end
-- An officer's own broadcast (the kit: KitShare.lua) goes in the same first lane, on GUILD.
function ns.officerSend(msg, channel, target) return enqueue(1, { msg = msg, channel = channel, target = target }) end
-- Optional callbacks, all without side effects on the queue: skip() is asked before each try and returns true when
-- the message no longer needs to go out (someone else already shared it); sent() runs once it has gone out;
-- dropped() runs when the game refused it SEND_TRIES times and it was skipped.
function ns.relay(msg, channel, target, skip, sent, dropped)
  return enqueue(2, { msg = msg, channel = channel, target = target, skip = skip, sent = sent, dropped = dropped })
end
function ns.catchUpSend(msg, channel, target, skip, dropped)
  return enqueue(3, { msg = msg, channel = channel, target = target, skip = skip, dropped = dropped })
end
function ns.catchUpRoom() return LANE_CAP[3] - #lanes[3] end
function ns.craftSend(msg, channel, target) return enqueue(4, { msg = msg, channel = channel, target = target }) end

-- Names ----------------------------------------------------------------------
-- Senders and roster entries are compared as full "Name-Realm". A short name alone would let a
-- same-named player on another realm whisper as one of our officers. UW_GuildDB keeps short keys
-- (Ambiguate(full, "none")) so the saved data contract doesn't change.
-- Forever (4 Nov 2026): every character has a first name and a surname that together are unique in the region, so
-- there is no realm. UnitName gives them as two values (elsewhere the second is the realm); senders, the roster and
-- group units give "First Last". There a name's key is the game's own short form, as DBM and Questie use on Forever:
-- nobody of the same name can be on another realm, so the realm guard has nothing to guard.
local REGIONAL = RegionalUniqueNamesEnabled ~= nil and RegionalUniqueNamesEnabled() == true
local SURNAME_SEP = Constants and Constants.CharacterNameSeparatorConsts
  and Constants.CharacterNameSeparatorConsts.CHARACTERNAME_SURNAME_SEPARATOR or " "
ns.REGIONAL, ns.SURNAME_SEP = REGIONAL, SURNAME_SEP
local function fullName(name)
  if type(name) ~= "string" or name == "" or isSecret(name) then return nil end
  if REGIONAL then return (Ambiguate(name, "none")) end
  if name:find("-", 1, true) then return name end
  local realm = GetNormalizedRealmName and GetNormalizedRealmName()
  if realm and realm ~= "" and not isSecret(realm) then return name .. "-" .. realm end
  return name
end
local function shortName(full) return (Ambiguate(full, "none")) end

-- This character's name, as the roster and every sender spell it. Once the roster is read it is the row with this
-- character's GUID, whatever the client's name format; before that, UnitName's parts (on Forever: name, surname).
local myRosterName
function ns.me()
  if myRosterName then return myRosterName end
  local n, s = UnitName("player")
  if type(n) ~= "string" or isSecret(n) then return nil end
  if REGIONAL and type(s) == "string" and s ~= "" and not isSecret(s) then
    local tail = SURNAME_SEP .. s
    if n:sub(-#tail) ~= tail then n = n .. tail end -- some units already carry it
  end
  return fullName(n)
end

-- A group unit's name as the roster spells it (nil when unknown or secret). On Forever UnitName gives the first name
-- and the surname as two values, and the roster says "First Last": the first name alone matches nobody. Elsewhere the
-- second value is the realm, for a player from another one.
function ns.unitFull(unit)
  local n, s = UnitName(unit)
  if type(n) ~= "string" or n == "" or isSecret(n) then return nil end
  if type(s) == "string" and s ~= "" and not isSecret(s) then
    if REGIONAL then
      local tail = SURNAME_SEP .. s
      if n:sub(-#tail) ~= tail then n = n .. tail end
    elseif not n:find("-", 1, true) then
      n = n .. "-" .. s
    end
  end
  return fullName(n)
end

-- A number from another player's addon message, or nil. tonumber("nan") and tonumber("inf") are numbers in Lua 5.1,
-- and NaN written to SavedVariables can corrupt the file, so every number received goes through this.
function ns.finite(v)
  local n = tonumber(v)
  if n and n == n and n > -math.huge and n < math.huge then return n end
end

-- Roster cache, rebuilt on every complete scan: full name -> rankIndex, full name -> rank name,
-- and short key -> full name.
local rankOf, rankNameOf, fullOf = {}, {}, {}
ns.send, ns.rankOf, ns.fullName, ns.shortName = send, rankOf, fullName, shortName

-- Louis, 9 Nov 2026 01:21: "Nothing goes out from my character voice unless I say so." Until his one-click OK ships
-- (#510), the Guild Master's account (any of its characters, remembered in UW_GuildDB.gmAccount) sends no line nobody
-- typed: no join whisper, no whisper answers, no "Added to your note" tells. Commands he types still send. A
-- character whose rank isn't known yet counts as his, so nothing goes out before the roster says who it is.
function ns.VoiceOff()
  if UW_GuildDB and UW_GuildDB.gmAccount then return true end
  local me = ns.me and ns.me()
  local full = me and fullName(me)
  local r = full and rankOf[full]
  if r == 0 and UW_GuildDB then UW_GuildDB.gmAccount = true end
  if r == nil or r == 0 then return true end
  -- An alt logging in before the Guild Master's character has run this build: the account's character list (Mail.lua,
  -- UW_GuildDB.alts) names him, so it's his voice too (hardening, 9 Nov: 8 alts run UW_Guild on his PC).
  for name in pairs(UW_GuildDB and type(UW_GuildDB.alts) == "table" and UW_GuildDB.alts or {}) do
    local alt = type(name) == "string" and fullName(name)
    if alt and rankOf[alt] == 0 then UW_GuildDB.gmAccount = true return true end
  end
  return false
end

-- True when the name (short, as typed, or full) is in the current roster.
function ns.inRoster(name)
  local full = fullName(name)
  return (full and rankOf[full] ~= nil) or fullOf[name] ~= nil
end

-- "<name> <the rest>" from a command, where a name can be two words (Forever: "First Last"). The longest run of
-- leading words that find(words) knows wins, as find returns it; otherwise the first word. Then the rest.
function ns.splitName(text, find)
  local words = {}
  for w in strtrim(text or ""):gmatch("%S+") do words[#words + 1] = w end
  for n = math.min(#words, 3), 1, -1 do
    local hit = find(table.concat(words, " ", 1, n))
    if hit then return hit, table.concat(words, " ", n + 1) end
  end
  return words[1], table.concat(words, " ", 2)
end
function ns.rosterName(name) if ns.inRoster(name) then return name end end

-- Run fn once the roster has been read (now if it already has). Officer checks need it.
local rosterWaiters, rosterReady = {}, false
function ns.afterRoster(fn)
  if rosterReady then fn() else rosterWaiters[#rosterWaiters + 1] = fn end
end

-- A recruit holds a recruit rank (Trial), or joined after this account's addon first read the roster.
-- The join-time test alone fails on the recruit's own client: the addon can only be installed after
-- joining, so the recruit is always in the seeding scan. Rank names are the same on every client, so
-- every client agrees on Trials; name is a members key (short name) or a full Name-Realm.
local function fullKey(name) return fullOf[name] or fullName(name) end
function ns.hasRecruitRank(name)
  local rankName = rankNameOf[fullKey(name) or ""]
  return rankName ~= nil and ns.RECRUIT_RANKS[rankName:lower()] == true
end
function ns.isRecruit(name)
  if ns.hasRecruitRank(name) then return true end
  local m = UW_GuildDB and UW_GuildDB.members[name]
  local seededAt = UW_GuildDB and UW_GuildDB.seededAt
  return m ~= nil and seededAt ~= nil and m.first > seededAt + 60
end
-- True for the guild's lowest rank, where WoW puts every new invite (and, in UW, social Friends too).
function ns.isLowestRank(name)
  local rank = rankOf[fullKey(name) or ""]
  local n = GuildControlGetNumRanks and GuildControlGetNumRanks()
  if rank == nil or type(n) ~= "number" or isSecret(n) or n < 2 then return false end
  return rank == n - 1
end
function ns.isOfficer(name)
  local full = fullName(name)
  local rank = full and rankOf[full]
  return rank ~= nil and rank <= ns.OFFICER_MAX_RANK
end

-- Officer audit ------------------------------------------------------------
local audit

-- Online guildmates (short names, sorted) missing from replies, read fresh from the roster. Not you.
function ns.silentOnline(replied)
  local out, self = {}, ns.me()
  for i = 1, GetNumGuildMembers() do
    local full, _, _, _, _, _, _, _, online = GetGuildRosterInfo(i)
    full = fullName(full)
    if full and online and full ~= self and not replied[shortName(full)] then out[#out + 1] = shortName(full) end
  end
  table.sort(out)
  return out
end
local lastReplyAt = 0

local function startAudit()
  if not IsInGuild() then say("Join Unbothered Warlords first: the audit asks guildmates.") return end
  if audit then say("Audit already running.") return end
  if not send("REQ", "GUILD") then say("Can't send right now (combat or restricted). Try again shortly.") return end
  audit = { rows = {} }
  say("Audit sent. Results in 6s. Only members with UW_Guild reply.")
  C_Timer.After(6, function()
    local names = {}
    for n in pairs(audit.rows) do names[#names + 1] = n end
    table.sort(names)
    say(("Audit: %d member(s) replied."):format(#names))
    -- The newest boss mod version anyone replied with: an older one is marked, since timers change between versions.
    local newest = {}
    for _, n in ipairs(names) do
      local r = audit.rows[n]
      if r.boss and r.boss ~= "" and r.bossVer and r.bossVer ~= "" and (not newest[r.boss]
        or ns.CompareVersions(r.bossVer, newest[r.boss]) > 0) then newest[r.boss] = r.bossVer end
    end
    for _, n in ipairs(names) do
      local r = audit.rows[n]
      local ok = r.req == "" and r.conf == ""
      local boss = r.boss or ""
      if boss ~= "" and r.bossVer and r.bossVer ~= "" then
        boss = boss .. " " .. r.bossVer .. (ns.CompareVersions(r.bossVer, newest[r.boss]) < 0 and " |cffff8000old|r" or "")
      end
      say(("%s v%s  %s%s%s%s"):format(n, r.ver, ok and "|cff40ff40OK|r"
        or ("|cffff4040missing:|r " .. (r.req ~= "" and r.req or "-") .. "  |cffff8000dup:|r " .. (r.conf ~= "" and r.conf or "-")),
        boss ~= "" and ("  [" .. boss .. "]") or "",
        r.raid and r.raid ~= "" and ("  |cffffd100raid:|r " .. r.raid) or "",
        (ns.TroubleText and ns.TroubleText(r.trouble) or "") .. (r.errAt and ("  |cffff8000UW error at|r " .. r.errAt) or "")))
    end
    local silent = ns.silentOnline(audit.rows)
    if #silent > 0 then
      say(("No reply from %d online guildmate(s) (no UW_Guild, an old version, or in combat):"):format(#silent))
      for i = 1, #silent, 12 do say(table.concat(silent, ", ", i, math.min(i + 11, #silent))) end
    end
    UW_GuildDB.lastAudit = { at = time(), rows = audit.rows, silent = silent }
    audit = nil
  end)
end

local function onRequest(sender)
  -- Only officers can trigger guild-wide replies, at most once a minute, so REQ can't be used to spam.
  if not ns.isOfficer(sender) then return end
  if GetTime() - lastReplyAt < 60 then return end
  lastReplyAt = GetTime()
  C_Timer.After(math.random() * 3, function() -- jitter so a full guild doesn't burst the throttle
    send(ns.KitReply(), "WHISPER", sender)
  end)
end

-- The KIT reply to an officer's REQ. 5th field (v0.5): boss mod in use. 6th (v1.1): missing from Raiding. 7th (v1.1):
-- problems this session, as "errors,blocked,outdated,deps" counts. 8th (v1.1): the boss mod's version. 9th (v1.1,
-- 5 Nov): where UW_Guild's latest own error happened ("AutoEquip.lua:118", ns.ErrorSig). Older clients
-- send fewer fields; readers treat a missing one as unknown. Officers can lengthen the kit in game, so any list that
-- doesn't fit 255 bytes becomes its count, duplicates first ("3 pairs"), then Raiding, then Everyone ("5 addons").
function ns.KitReply()
  local missReq, _, conflicts, missRaid = ns.CheckKit()
  local trouble = ns.KitTroubleCounts and table.concat({ ns.KitTroubleCounts() }, ",") or ""
  local req, conf, raid = table.concat(missReq, ","), table.concat(conflicts, ","), table.concat(missRaid, ",")
  local sig = ns.ErrorSig and ns.ErrorSig() or ""
  local function msg() return ("KIT\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s"):format(VERSION:sub(1, 24), req, conf, ns.BossMod(),
    raid, trouble, ns.BossModVersion(), sig) end
  if #msg() > 250 then conf = #conflicts .. " pairs" end
  if #msg() > 250 then raid = #missRaid .. " addons" end
  if #msg() > 250 then req = #missReq .. " addons" end
  return msg()
end

-- Discord outbox -----------------------------------------------------------
-- Addons can't reach the internet. Events queue in SavedVariables, which WoW
-- writes on logout or /reload; bridge/uw-bridge.ps1 posts them.
local function queue(kind, ...)
  local box = UW_GuildDB.outbox
  local fields = { tostring(time()), kind }
  for i = 1, select("#", ...) do
    fields[#fields + 1] = (tostring((select(i, ...))):gsub("[\t\"\\]", "")) -- keep the bridge's line format intact
  end
  box[#box + 1] = table.concat(fields, "\t")
  -- Over the cap the oldest lines go, but never silently: outboxDropped counts them (never reset) so the
  -- bot can say how many older events it never saw.
  while #box > ns.MAX_OUTBOX do
    table.remove(box, 1)
    UW_GuildDB.outboxDropped = (UW_GuildDB.outboxDropped or 0) + 1
  end
  for _, fn in ipairs(ns.onQueue) do protect(fn, kind) end
end
ns.queue = queue

-- Weekly reset as a Unix time. Members not seen since then are flagged stale for the bot.
local function lastWeeklyReset(now)
  local untilNext = C_DateAndTime and C_DateAndTime.GetSecondsUntilWeeklyReset and C_DateAndTime.GetSecondsUntilWeeklyReset()
  if not untilNext or isSecret(untilNext) then return nil end
  return now + untilNext - 7 * 86400
end
ns.lastWeeklyReset = lastWeeklyReset

-- Approximate last-online time for an offline roster entry (the API gives years/months/days/hours ago).
local function approxLastOnline(i, now)
  local y, mo, d, h = GetGuildRosterLastOnline(i)
  if not y then return nil end
  return now - ((((y * 365) + (mo * 30) + d) * 24 + h) * 3600)
end

-- Leavers: members missing from a complete roster get members[name].left = time, once.
-- A roster that is only partly loaded would look like a mass exodus, so if one scan would mark more
-- than max(3, 10%) of known members, nothing is marked; the names wait in leaveHeld for an officer.
-- Who is online when, for raid nights picked from measured play (Louis, 8 Nov 2026: the bot proposes the nights,
-- /uw-event besttime). An officer's client counts, every 15 minutes, how many guildmates the roster shows online.
-- Counts without names, per UTC hour:
--   presence.days["YYYYMMDD"] = { s = 24 digits: samples taken in each hour, n = { 24 numbers: guildmates online,
--   summed over those samples }, o = { [name] = 24 digits } }, kept ns.PRESENCE_DAYS days.
-- o holds only the characters in ns.PRESENCE_OPTIN: members who switched raid calls on in Discord (the bot writes the
-- list into Schedule.lua; it is never shared with other clients). Samples happen only while this officer plays, so
-- the bot divides by s: an hour never sampled is unknown, not empty. The officer's own character is left out.
ns.PRESENCE_DAYS, ns.PRESENCE_SLOT = 29, 900
local ZERO24 = ("0"):rep(24)
local function bumpHour(str, h)
  str = (type(str) == "string" and #str == 24 and str:match("^%d+$")) and str or ZERO24
  local d = tonumber(str:sub(h + 1, h + 1)) or 0
  if d >= 9 then return str end
  return str:sub(1, h) .. (d + 1) .. str:sub(h + 2)
end
local function samplePresence(rows, me)
  if not date then return end
  local at = (GetServerTime and GetServerTime()) or time()
  local p = UW_GuildDB.presence
  if type(p) ~= "table" or type(p.days) ~= "table" then p = { days = {} }; UW_GuildDB.presence = p end
  local slot = math.floor(at / ns.PRESENCE_SLOT)
  if p.slot == slot then return end -- one sample per slot, also across /reload
  p.slot = slot
  local day, h = date("!%Y%m%d", at), tonumber(date("!%H", at))
  local d = p.days[day]
  if type(d) ~= "table" then d = {}; p.days[day] = d end
  if type(d.n) ~= "table" then d.n = {} end
  if type(d.o) ~= "table" then d.o = {} end
  d.s = bumpHour(d.s, h)
  local optin = {}
  for _, n in ipairs(type(ns.PRESENCE_OPTIN) == "table" and ns.PRESENCE_OPTIN or {}) do
    if type(n) == "string" then optin[n:lower()] = true end
  end
  local on = 0
  for _, r in ipairs(rows) do
    if r.online and r.name ~= me then
      on = on + 1
      if optin[r.name:lower()] or optin[(r.name:gsub("-", " ")):lower()] then d.o[r.name] = bumpHour(d.o[r.name], h) end
    end
  end
  for k = 1, 24 do d.n[k] = tonumber(d.n[k]) or 0 end
  d.n[h + 1] = d.n[h + 1] + on
  local oldest = date("!%Y%m%d", at - ns.PRESENCE_DAYS * 86400)
  for k in pairs(p.days) do if type(k) ~= "string" or k < oldest then p.days[k] = nil end end
end
ns.samplePresence = samplePresence

local function markLeavers(db, present, now)
  local gone, known = {}, 0
  for name, m in pairs(db) do
    if not m.left then
      known = known + 1
      if not present[name] then gone[#gone + 1] = name end
    end
  end
  if #gone == 0 then UW_GuildDB.leaveHeld = nil return end
  table.sort(gone)
  if #gone > math.max(3, math.floor(known * 0.1)) then
    local prev = UW_GuildDB.leaveHeld
    UW_GuildDB.leaveHeld = { at = now, names = gone, known = known }
    if (not prev or #prev.names ~= #gone) and ns.isOfficer(ns.me()) then
      say(("%d members vanished from the roster at once, so none were marked as left. Type /uw leavers to review."):format(#gone))
    end
    return
  end
  for _, name in ipairs(gone) do
    db[name].left = now
    queue("leave", name)
  end
  UW_GuildDB.leaveHeld = nil
end

-- Which guild UW_GuildDB describes, as "Guild-Realm". UW_GuildDB is account-wide, so an alt in another
-- guild must not touch it: every UW member would look gone and every stranger would post as a join.
-- Where names are region-wide (Forever), the realm can change between logins or mid-session with server load, so the
-- key is "Guild-Region" there and doesn't wait for a realm.
ns.REGION_KEY = "Region"
local function guildKey()
  local g, _, _, realm = GetGuildInfo("player")
  if type(g) ~= "string" or g == "" or isSecret(g) then return nil end
  if REGIONAL then return g .. "-" .. ns.REGION_KEY end
  if type(realm) ~= "string" or realm == "" or isSecret(realm) then -- nil means the player's own realm
    realm = GetNormalizedRealmName and GetNormalizedRealmName()
  end
  if type(realm) ~= "string" or realm == "" or isSecret(realm) then return nil end
  return g .. "-" .. realm
end

-- The guild this addon is for. A fresh install records only a guild with this name (case and spaces ignored), so an
-- alt in another guild who logs in first can't claim the account-wide save. /uw adopt covers any other name.
ns.GUILD_NAME = "Unbothered Warlords"
local function guildName(key) return key and key:match("^([^%-]+)%-") end -- guild names can't contain "-"
local function isOurName(name) return name ~= nil and name:lower():gsub("%s", "") == ns.GUILD_NAME:lower():gsub("%s", "") end
-- The same guild: the same key, or where names are region-wide the same name (a key saved with a realm).
local function sameGuild(a, b)
  return a ~= nil and b ~= nil and (a == b or (REGIONAL and guildName(a) ~= nil and guildName(a) == guildName(b)))
end

-- True when this character is in the guild UW_GuildDB records.
function ns.tracksGuild()
  return IsInGuild() and sameGuild(guildKey(), UW_GuildDB.guild)
end

-- True when this character is in our guild: the one recorded, or before any is recorded, one with our name.
function ns.inOurGuild()
  if not IsInGuild() then return false end
  if UW_GuildDB.guild then return ns.tracksGuild() end
  return isOurName(guildName(guildKey()))
end

-- Start over on another guild: the next scan seeds it silently, like a fresh install.
local function forgetRoster()
  UW_GuildDB.members, UW_GuildDB.seeded, UW_GuildDB.seededAt = {}, nil, nil
  UW_GuildDB.leaveHeld, UW_GuildDB.invite = nil, nil
end

-- Adopt the current guild on a scan. Only one with our name is adopted on a fresh install, or replaces a guild an
-- older version adopted first (maybe an alt's). A save without a guild (v0.2) or a renamed guild adopts it when at
-- least half of this roster is already in members. A guild chosen with /uw adopt is never replaced automatically.
local function adoptGuild(key, present, rows)
  local tracked = UW_GuildDB.guild
  if sameGuild(tracked, key) then UW_GuildDB.guild = key return true end
  local known = 0
  for name in pairs(present) do if UW_GuildDB.members[name] then known = known + 1 end end
  if not (UW_GuildDB.seeded and known * 2 >= rows) then
    if not isOurName(guildName(key)) or UW_GuildDB.chosen or isOurName(guildName(tracked)) then return false end
    if tracked or UW_GuildDB.seeded then forgetRoster() end
  end
  UW_GuildDB.guild = key
  UW_GuildDB.chosen = not isOurName(guildName(key)) or nil -- a renamed guild keeps its place
  return true
end

local otherGuildNoted = false
local function noteOtherGuild()
  if otherGuildNoted then return end
  otherGuildNoted = true
  local here = IsInGuild() and guildName(guildKey())
  if not here then
    say("This character isn't in the guild UW_Guild was set up for, so nothing is recorded here.")
    return
  end
  local ours = guildName(UW_GuildDB.guild) or ns.GUILD_NAME
  say(("This character is in <%s>, not <%s>, so nothing is recorded here. Renamed our guild to <%s>? Type /uw adopt.")
    :format(here, ours, here))
end
ns.noteOtherGuild = noteOtherGuild

-- A member's public guild note (31 characters, typed by them or an officer), kept as it is now: the crafting directory
-- reads professions from it for guildmates who don't run UW_Guild. Control characters dropped; nil when empty.
local function guildNote(v)
  if type(v) ~= "string" or isSecret(v) then return nil end
  v = strtrim((v:gsub("%c", " ")))
  return v ~= "" and v or nil
end

-- Roster scan: detects joins, leaves and level milestones, including ones that happened while you were offline.
-- members[name] = { first = firstSeenTime, lvl = level, seen = lastSeenTime, stale = seenBeforeWeeklyReset, left = leftTime }
local scanRoster
local scanPending, rosterStableCount, rosterTrusted = false, -1, false
local seedTries = 0
local function rescanSoon()
  C_Timer.After(5, function() if not scanPending then scanPending = true; scanRoster() end end)
end

scanRoster = function()
  scanPending = false
  local key = guildKey()
  if not key then rescanSoon() return end -- guild info not loaded yet early in login
  local total, onlineCount = GetNumGuildMembers()
  -- The roster streams in after login. A partial roster would look like mass joins, so
  -- wait until two scans in a row report the same size before trusting it.
  if total == 0 or total ~= rosterStableCount then
    rosterStableCount = total
    rescanSoon()
    return
  end
  local now, posted = time(), 0
  -- Read the roster first; nothing is kept unless it is the guild we track.
  local rows, present = {}, {}
  local myGUID = UnitGUID and UnitGUID("player")
  local mine
  for i = 1, total do
    local full, rankName, rankIndex, level, _, zone, note, _, online, _, classFile, _, _, _, _, _, guid = GetGuildRosterInfo(i)
    local raw = full
    full = fullName(full)
    if full and myGUID and not isSecret(myGUID) and not isSecret(guid) and guid == myGUID then mine = { full = full, raw = raw } end
    if full and level then
      local name = shortName(full)
      present[name] = true
      if type(rankName) ~= "string" or isSecret(rankName) then rankName = nil end
      if type(classFile) ~= "string" or isSecret(classFile) then classFile = nil end -- "WARRIOR": crafting picks armor by class
      if type(zone) ~= "string" or isSecret(zone) then zone = nil end -- WeekOne.lua: two guildmates in one dungeon
      rows[#rows + 1] = { i = i, full = full, rank = rankIndex, rankName = rankName, name = name, level = level, online = online, cls = classFile,
        note = guildNote(note), zone = zone }
    end
  end
  wipe(rankOf)
  wipe(rankNameOf)
  wipe(fullOf)
  rosterTrusted = false
  if not adoptGuild(key, present, #rows) then noteOtherGuild() return end
  local db, seeded = UW_GuildDB.members, UW_GuildDB.seeded -- after adoption, which may start over
  for _, r in ipairs(rows) do rankOf[r.full], rankNameOf[r.full], fullOf[r.name] = r.rank, r.rankName, r.full end
  if mine then myRosterName = mine.full end
  if ns.NoteNames then ns.NoteNames(mine and mine.raw) end -- KitDoctor.lua: the launch check reads it
  -- Audit G10: the seeding scan defines who was already here, so it must be a complete read. Seeding on a partial
  -- roster would post everyone missing from it as a join on the next scan. After 6 tries (30 s) it seeds anyway.
  if not UW_GuildDB.seeded and #rows < total and seedTries < 6 then
    seedTries = seedTries + 1
    rescanSoon()
    return
  end
  -- Only a complete read can prove someone is gone. A roster with nobody offline may be an
  -- online-only list, which would make every offline member look gone.
  rosterTrusted = #rows == total and not (onlineCount and onlineCount >= total)
  local reset = lastWeeklyReset(now)
  UW_GuildDB.weeklyResetAt = reset
  for _, r in ipairs(rows) do
    local name, level = r.name, r.level
    local m = db[name]
    if not m then
      m = { first = now, lvl = level }
      db[name] = m
      if seeded then queue("join", name, level) end
    else
      if m.left then -- back after leaving: not a new recruit, so it's a rejoin rather than a join
        m.left = nil
        queue("rejoin", name, level)
      end
      if level > (m.lvl or level) and posted < ns.MAX_BACKLOG_POSTS then
        local top -- post only the highest milestone crossed, not one per milestone
        for l = m.lvl + 1, level do if ns.MILESTONES[l] then top = l end end
        if top then queue("level", name, top); posted = posted + 1 end
      end
      m.lvl = level
    end
    m.cls = r.cls or m.cls
    m.rank = r.rankName or m.rank -- "Member": the crafting plan pays bank mats for Members and up
    m.note = r.note -- the public note as it is now (never the officer note): the bot reads professions from it
    local seen = r.online and now or approxLastOnline(r.i, now)
    if seen and seen > (m.seen or 0) then m.seen = seen end
    m.stale = (reset and (m.seen or 0) < reset) or nil
  end
  -- Never on the first (seeding) scan.
  if seeded and rosterTrusted then markLeavers(db, present, now) end
  local meFull = (mine and mine.full) or ns.me()
  if rosterTrusted and meFull and ns.isOfficer(meFull) then protect(samplePresence, rows, shortName(meFull)) end
  if rosterTrusted and ns.WeekOneSample then protect(ns.WeekOneSample, rows, now) end
  if rosterTrusted then for _, fn in ipairs(ns.onScan) do protect(fn) end end
  UW_GuildDB.seeded = true -- first full scan only records; nothing is posted for existing members
  UW_GuildDB.seededAt = UW_GuildDB.seededAt or now -- members first seen at seeding predate the addon (not recruits)
  if not rosterReady then
    rosterReady = true
    for _, fn in ipairs(rosterWaiters) do protect(fn) end
    wipe(rosterWaiters)
  end
end

local function requestScan()
  if scanPending then return end
  scanPending = true
  C_Timer.After(2, scanRoster) -- GUILD_ROSTER_UPDATE fires in bursts; coalesce them
end

-- Kills count as guild kills only when at least half the raid is in the guild.
local function guildRaidShare()
  local n, inGuild = GetNumGroupMembers(), 0
  if n == 0 then return 0 end
  for i = 1, n do if UnitIsInMyGuild("raid" .. i) then inGuild = inGuild + 1 end end
  return inGuild / n
end
ns.guildRaidShare = guildRaidShare

-- Raid attendance: one line per guild kill, read by the bot.
-- Format: time<TAB>encounterID<TAB>boss<TAB>difficultyID<TAB>groupSize<TAB>name1,name2,...[<TAB>via]
-- The time is the realm's (GetServerTime), so reports of one kill from several clients agree. Raid.lua merges a
-- kill another client already shared instead of adding it twice. Returns true when the kill is new here, and the
-- group size it recorded (the event's, or the number of names when the event's is missing or secret).
local function snapshotAttendance(encounterID, boss, difficultyID, groupSize)
  local names = {}
  for i = 1, GetNumGroupMembers() do
    local full = GetRaidRosterInfo(i)
    -- Same-realm players by name, others as Name-Realm, so a cross-realm namesake never gets a member's kills.
    full = fullName(full)
    if full then names[#names + 1] = (shortName(full):gsub("[\t,\"\\]", "")) end
  end
  local size = type(groupSize) == "number" and groupSize or #names
  return ns.RecordKill({ at = (GetServerTime and GetServerTime()) or time(), enc = encounterID or 0,
    boss = (tostring(boss):gsub("[\t\"\\]", "")), diff = difficultyID or 0, size = size, names = names }), size
end

-- Who runs UW_Guild: members[name].addon = last time any UWG1 message came from them. Lets the bot
-- count onboarding stats (first group) only over members who could report them.
local function noteAddonUser(sender)
  if rankOf[sender] == nil or not ns.tracksGuild() then return end
  local m = UW_GuildDB.members[shortName(sender)]
  if m then m.addon = time() end
end

-- Login and mid-session guild joins look the same: IsInGuild() turns true (early in login it can still be
-- false, then PLAYER_GUILD_UPDATE fires). The first time it does, read the roster and start onboarding.
local loaded, guildStarted = false, false
local function checkGuildJoin()
  if not loaded or guildStarted or not IsInGuild() then return end
  guildStarted = true
  C_GuildInfo.GuildRoster()
  for _, fn in ipairs(ns.onGuildJoin) do protect(fn) end
end

-- Guild ranks ---------------------------------------------------------------
-- In-game ranks, top first, named like Discord's rank roles (bot/uwbot/layout.py RANK_ROLES; a bot test compares
-- them): the bot and the crafting plan read the roster's rank names, and new invites land in the lowest rank. A new
-- guild starts with WoW's five default ranks, so the Guild Master is told what to change, once per login, until they
-- match; renaming one in game is checked again at once.
ns.RANKS = { "Guild Master", "Officer", "Raider", "Member", "Trial", "Friend" }
-- Trial is optional in game (UW's own guild, 8 Nov 2026): when Friend is already the bottom rank right under Member,
-- there is no slot for Trial. Invites land on Friend and the recruit welcome finds them by join time (ns.isRecruit).
-- Asking for Trial there meant "rename Friend to Trial", which relabels every Friend (progress-safe). A guild with a
-- spare rank between Member and Friend (WoW's Initiate) still gets Trial in that slot.
-- Trial and Friend are both entry ranks with the same rights, so either may sit at the bottom (where WoW puts invites).
-- Louis's guild, 8 Nov 2026: Friend above Trial; "rename Friend to Trial, rename Trial to Friend" only relabelled people.
local function wantedRanks(names)
  local n, have = #names, {}
  for _, name in ipairs(names) do have[name] = true end
  if names[n] == "Trial" and names[n - 1] == "Friend" then
    local out = {}
    for i, name in ipairs(ns.RANKS) do out[i] = name end
    out[#out - 1], out[#out] = "Friend", "Trial"
    return out
  end
  if have.Trial or names[n] ~= "Friend" or names[n - 1] ~= "Member" then return ns.RANKS end
  local out = {}
  for _, name in ipairs(ns.RANKS) do if name ~= "Trial" then out[#out + 1] = name end end
  return out
end
local function rankNames()
  local n = GuildControlGetNumRanks and GuildControlGetNumRanks()
  -- Fewer than two: the guild's ranks haven't arrived yet (early in login), not a guild to fix.
  if type(n) ~= "number" or isSecret(n) or n < 2 or not GuildControlGetRankName then return nil end
  local names = {}
  for i = 1, n do
    local have = GuildControlGetRankName(i)
    -- A rank the client counts but can't name yet (nil or "" while the guild data loads): nothing to say yet.
    if type(have) ~= "string" or isSecret(have) or have == "" then return nil end
    names[i] = have
  end
  return names, wantedRanks(names)
end
function ns.RankFixes()
  local names, wanted = rankNames()
  if not names then return nil end
  local fixes, n = {}, #names
  for i = 1, math.max(n, #wanted) do
    local have, want = names[i], wanted[i]
    if have and want and have ~= want then fixes[#fixes + 1] = ("rename %s to %s"):format(have, want)
    elseif want and not have then fixes[#fixes + 1] = ("add %s at the bottom"):format(want)
    elseif have and not want then fixes[#fixes + 1] = ("remove %s"):format(have) end
  end
  return fixes
end
-- The guild window's Information text, suggested by /uw ranks only while it's empty (the addon never writes it).
function ns.GuildInfoPlan()
  if not (GetGuildInfoText and CanEditGuildInfo and CanEditGuildInfo()) then return nil end
  local have = GetGuildInfoText()
  if type(have) ~= "string" or isSecret(have) or strtrim(have) ~= "" then return nil end
  local values = ns.VALUES and table.concat(ns.VALUES, ", ") or ""
  local invite = ns.Invite and ns.Invite() or ""
  return ("%s: %s. Discord: %s. Get UW_Guild: %s"):format(ns.GUILD_NAME, values, invite, ns.ADDON_URL)
end

-- Told once per login, at the first check that can read the ranks (the roster's, or a later GUILD_RANKS_UPDATE when
-- the names arrive after it); once they match, said once. Steps only: Forever blocks addons from editing ranks
-- (GuildControlSetRank is protected: Louis's client, 8 Nov 2026, ADDON_ACTION_FORBIDDEN on the old one-click setup).
-- Renaming a rank keeps everyone in it and its rights (rank powers go by place, ns.RAID_LEAD_MAX_RANK).
local ranksTold, ranksDone = false, false
local function isLeader()
  if IsGuildLeader then return IsGuildLeader() == true end
  return rankOf[ns.me() or ""] == 0
end
local RANK_STEPS = "the guild window (J): Roster > Guild Settings > Guild Ranks"
local function rankText(fixes)
  return ("|cffffd100Guild ranks|r need Discord's names (the bot reads them). By hand in %s: %s."):format(RANK_STEPS,
    table.concat(fixes, ", "))
end
local function checkRanks()
  if rankOf[ns.me() or ""] ~= 0 or not ns.tracksGuild() then return end -- the Guild Master only
  local fixes = ns.RankFixes()
  if not fixes then return end
  if #fixes > 0 and not ranksTold then
    ranksTold = true
    say(rankText(fixes))
  elseif #fixes == 0 and ranksTold and not ranksDone then
    ranksDone = true
    say("Guild ranks match Discord's now.")
  end
end
ns.commands.ranks = function()
  if not IsInGuild() or not isLeader() then say("Only the Guild Master can set up ranks.") return end
  local fixes = ns.RankFixes()
  if fixes and #fixes > 0 then ranksTold = true say(rankText(fixes))
  elseif fixes then say("Guild ranks already match Discord's.")
  else say("Guild ranks are still loading. Try /uw ranks again in a moment.") end
  local info = ns.GuildInfoPlan()
  if info then say(("Guild Info is empty. Suggested text: %s"):format(info)) end
end
table.insert(ns.onGuildJoin, function() ns.afterRoster(checkRanks) end)

-- Events -------------------------------------------------------------------
local killReminded = false
local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("CHAT_MSG_ADDON")
f:RegisterEvent("GUILD_ROSTER_UPDATE")
f:RegisterEvent("PLAYER_GUILD_UPDATE")
f:RegisterEvent("ENCOUNTER_END")
do -- only when this client has it: on the modern client an unknown event throws and would stop this file
  local valid = C_EventUtils and C_EventUtils.IsEventValid
  for _, e in ipairs({ "GUILD_RANKS_UPDATE", "ADDON_ACTION_BLOCKED", "ADDON_ACTION_FORBIDDEN" }) do
    if not valid or valid(e) then pcall(f.RegisterEvent, f, e) end
  end
end
f:SetScript("OnEvent", function(_, event, ...)
  if event == "ADDON_ACTION_BLOCKED" or event == "ADDON_ACTION_FORBIDDEN" then
    -- The game stopped one of our calls (no Lua error, so protect() never sees it): keep it with the rest.
    local who, fn = ...
    if who == ADDON then noteError(("%s %s"):format(event == "ADDON_ACTION_FORBIDDEN" and "forbidden:" or "blocked:",
      type(fn) == "string" and fn or "?"), 3) end
    return
  end
  if event == "ADDON_LOADED" then
    if ... ~= ADDON then return end
    -- A first install on this WoW account has no saved data yet: remember when, for the gentler first login.
    -- An install from before this existed gets 0, so it never counts as new.
    local fresh = type(UW_GuildDB) ~= "table" or next(UW_GuildDB) == nil
    UW_GuildDB = UW_GuildDB or {}
    if UW_GuildDB.installedAt == nil then UW_GuildDB.installedAt = fresh and time() or 0 end
    UW_GuildDB.outbox = UW_GuildDB.outbox or {}
    UW_GuildDB.members = UW_GuildDB.members or {}
    UW_GuildDB.attendance = UW_GuildDB.attendance or {}
    UW_GuildDB.schema = 3 -- bump when a saved line format changes
    -- Own errors are kept a week, and only for this version: a fixed one doesn't linger in /uw kit.
    local kept = {}
    for _, e in ipairs(type(UW_GuildDB.errors) == "table" and UW_GuildDB.errors or {}) do
      if type(e) == "table" and e.ver == VERSION and (tonumber(e.at) or 0) > time() - 7 * 86400 then kept[#kept + 1] = e end
    end
    UW_GuildDB.errors = #kept > 0 and kept or nil
    C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
    f:UnregisterEvent("ADDON_LOADED")
    C_Timer.After(8, loginKit)
    if not IsInGuild() and UW_GuildDB.guild then -- guildless alt: nothing is recorded
      C_Timer.After(8, function() if not IsInGuild() then noteOtherGuild() end end)
    end
    -- The server only pushes some roster changes; ask every 5 minutes so levels and last-online stay fresh.
    C_Timer.NewTicker(300, function() if IsInGuild() then C_GuildInfo.GuildRoster() end end)
    for _, fn in ipairs(ns.onLoad) do protect(fn) end
    loaded = true
    checkGuildJoin()
  elseif event == "GUILD_RANKS_UPDATE" then
    if rosterReady then checkRanks() end
  elseif event == "GUILD_ROSTER_UPDATE" or event == "PLAYER_GUILD_UPDATE" then
    if IsInGuild() then checkGuildJoin(); requestScan() end
  elseif event == "ENCOUNTER_END" then
    local encounterID, encounterName, difficultyID, groupSize, success = ...
    if isSecret(success) or isSecret(encounterName) then return end
    if success == 1 and IsInRaid() and guildRaidShare() >= 0.5 then
      if not ns.tracksGuild() then noteOtherGuild() return end
      -- Not new when a guildmate's client in the same raid already shared it (Raid.lua): no second kill post.
      -- The post's group size is the one attendance recorded: never a secret value or a missing one.
      local new, size = snapshotAttendance(not isSecret(encounterID) and encounterID or 0, encounterName,
        not isSecret(difficultyID) and difficultyID or 0, not isSecret(groupSize) and groupSize or nil)
      if new then queue("kill", encounterName, size) end
      for _, fn in ipairs(ns.onGuildKill) do protect(fn, encounterName) end
      if not killReminded then -- SavedVariables are written only on logout or /reload; a crash loses the night
        killReminded = true
        say("Boss kill saved for attendance. Type /reload between pulls or after the raid so a crash can't lose it.")
      end
    end
  elseif event == "CHAT_MSG_ADDON" then
    local prefix, text, channel, sender = ...
    if prefix ~= PREFIX or type(text) ~= "string" then return end
    sender = fullName(sender) -- handlers get the full Name-Realm; use ns.shortName for UW_GuildDB keys
    if not sender then return end
    noteAddonUser(sender)
    if text == "REQ" and channel == "GUILD" then
      onRequest(sender)
    elseif audit and channel == "WHISPER" and text:sub(1, 4) == "KIT\t" then
      -- Whispers can come from anyone; only guildmates' replies count.
      if rankOf[sender] == nil then return end
      local _, ver, req, conf, boss, raid, trouble, bossVer, errAt = strsplit("\t", text)
      audit.rows[shortName(sender)] = { ver = ver or "?", req = req or "", conf = conf or "", boss = boss,
        raid = raid, trouble = trouble, bossVer = bossVer, errAt = errAt and errAt:match("^[%w_.:?]+$") }
    else
      local tag = strsplit("\t", text)
      local handler = ns.handlers[tag]
      if handler then protect(handler, sender, channel, select(2, strsplit("\t", text))) end
    end
  end
end)

-- /uw leavers: review names held back by the partial-roster guard; officers can confirm them.
ns.commands.leavers = function(args)
  local held = UW_GuildDB.leaveHeld
  if not held then say("Nothing held back. Members who leave are recorded automatically.") return end
  if strtrim(args or ""):lower() ~= "confirm" then
    say(("%d member(s) vanished from the roster at once, so I didn't mark them as left in case the roster was incomplete: %s"):format(#held.names, table.concat(held.names, ", ")))
    say("If they really left, an officer can type /uw leavers confirm.")
    return
  end
  if not ns.isOfficer(ns.me()) then say("Only officers can confirm leavers.") return end
  -- Checked against the latest roster, so that roster must be complete and ours.
  if not rosterTrusted then say("The guild roster isn't fully loaded. Try again in a few seconds; if it keeps happening, tick Show Offline Members in the roster.") return end
  local now, n = time(), 0
  for _, name in ipairs(held.names) do
    local m = UW_GuildDB.members[name]
    if m and not m.left and not fullOf[name] then -- still missing from the latest roster
      m.left = now
      queue("leave", name)
      n = n + 1
    end
  end
  UW_GuildDB.leaveHeld = nil
  say(("Marked %d member(s) as left."):format(n))
end

-- /uw adopt: record this character's guild when ours has another name in game. Forgets the roster recorded before,
-- so the next scan seeds this guild silently instead of posting everyone as a join.
ns.commands.adopt = function(args)
  local key = IsInGuild() and guildKey()
  if not key then say("This character isn't in a guild yet.") return end
  local tracked = UW_GuildDB.guild
  if sameGuild(tracked, key) then say(("UW_Guild already records <%s>."):format(guildName(key))) return end
  if strtrim(args or ""):lower() ~= "confirm" then
    local forget = tracked and (" It forgets the members it knew in <%s>."):format(guildName(tracked)) or ""
    say(("Record <%s> for every character on this account?%s Type /uw adopt confirm.")
      :format(guildName(key), forget))
    return
  end
  if tracked or UW_GuildDB.seeded then forgetRoster() end
  UW_GuildDB.guild, UW_GuildDB.chosen = key, true
  otherGuildNoted = false
  say(("UW_Guild now records <%s>."):format(guildName(key)))
  requestScan()
end

-- Usage counts for the daily improvement loop (Louis, 8 Nov 2026: "yes on all" to capture, review, fix, weekly). Per
-- UTC day: which /uw commands and UW_Guild buttons got used, what was used again within REPEAT_SECONDS (a retry usually
-- means the first try didn't do what was hoped), which /uw words don't exist (a feature someone looked for and couldn't
-- find) and which features were switched off. Names only, never what follows them (that can be a player's name).
-- On by default only on the bot's PC (Schedule.lua gen > 0: the Guild Master's client, the one save the bot reads);
-- /uw usage on|off overrides it on any PC, and off deletes what was counted. Nothing here leaves the PC. The bot ranks
-- it with the errors and the decision log (bot/uwbot/uxloop.py).
ns.USAGE_DAYS, ns.REPEAT_SECONDS, ns.USAGE_KEYS = 14, 20, 120
local function usageOn()
  local db = UW_GuildDB
  if type(db) ~= "table" then return false end
  if db.usageOn ~= nil then return db.usageOn == true end
  return type(ns.SCHEDULE) == "table" and (tonumber(ns.SCHEDULE.gen) or 0) > 0
end
ns.UsageOn = usageOn
local lastUse, knownNoted = { key = nil, at = 0 }, false
local function useWord(v)
  if type(v) ~= "string" or isSecret(v) then return nil end
  local w = v:lower():gsub("[^%w ]", ""):sub(1, 32)
  return w ~= "" and w or nil
end
local function usageDay()
  local fmt = date or (os and os.date)
  return fmt and fmt("!%Y-%m-%d", time()) or tostring(math.floor(time() / 86400))
end
-- kind: cmd (typed), options (the options page), button, unknown (a /uw word that isn't one).
function ns.use(kind, name)
  if not usageOn() then return end
  kind, name = useWord(kind), useWord(name)
  if not (kind and name) then return end
  local db = UW_GuildDB
  local u = type(db.usage) == "table" and db.usage or {}
  db.usage, u.v = u, 1
  u.days = type(u.days) == "table" and u.days or {}
  local today = usageDay()
  local d = type(u.days[today]) == "table" and u.days[today] or {}
  u.days[today] = d
  local key, now = kind .. " " .. name, time()
  local function add(k)
    if d[k] == nil then
      local n = 0
      for _ in pairs(d) do n = n + 1 end
      if n >= ns.USAGE_KEYS then return end
    end
    d[k] = (tonumber(d[k]) or 0) + 1
  end
  add(key)
  if lastUse.key == key and now - lastUse.at <= ns.REPEAT_SECONDS then add("repeat " .. key) end
  lastUse.key, lastUse.at = key, now
  local days = {}
  for k in pairs(u.days) do days[#days + 1] = k end
  table.sort(days)
  for i = 1, #days - ns.USAGE_DAYS do u.days[days[i]] = nil end
  if not knownNoted then -- every command this version has, once a session: what nobody touched is a bloat candidate
    knownNoted = true
    local known = {}
    for c in pairs(ns.commands) do known[#known + 1] = c end
    table.sort(known)
    u.known, u.ver = known, VERSION
  end
end
-- Counts a click on a UW_Guild button without changing what the click does (a post-hook, safe on secure buttons).
function ns.useButton(b, name)
  -- A secure button registered for AnyUp and AnyDown runs OnClick twice: only the release counts.
  if type(b) == "table" and b.HookScript then
    b:HookScript("OnClick", function(_, _, down) if not down then ns.use("button", name) end end)
  end
end
ns.commands.usage = function(args)
  local w = strtrim(args or ""):lower()
  if w == "on" or w == "off" then
    UW_GuildDB.usageOn = w == "on"
    if w == "off" then UW_GuildDB.usage = nil end
  end
  say(("Usage counts are %s here (/uw usage on or off)%s."):format(usageOn() and "on" or "off",
    w == "off" and "; what was counted is deleted" or ""))
  say("They count which /uw commands and buttons you use, never what you type after them, and stay on this PC.")
end

SLASH_UWGUILD1, SLASH_UWGUILD2 = "/uw", "/uwguild" -- the long one still works if another addon also takes /uw
ns.commands.audit = startAudit
-- /uw kit and its words: extras and report here, the rest in KitShare.lua (ns.kitCommands: list, fix, layout, nudge,
-- and the officers' add, remove, pair, unpair, reset, edit), KitLook.lua (look) and Macros.lua (macros).
ns.kitCommands = {}
ns.commands.kit = function(args)
  local sub, rest = strtrim(args or ""):match("^(%S*)%s*(.-)$")
  sub = (sub or ""):lower()
  if sub == "extras" then printExtras()
  elseif sub == "report" and ns.KitReport then ns.KitReport()
  elseif ns.kitCommands[sub] then ns.kitCommands[sub](rest)
  else
    -- A word from a newer UW_Guild (the hub cards tell members about new ones) says so instead of quietly listing.
    if sub ~= "" then
      say(("/uw kit %s isn't in this UW_Guild (%s). If a guildmate or Discord mentioned it, get the newest UW_Guild "
        .. "from %s. Your kit:"):format(sub, VERSION, ns.ADDON_URL))
    end
    printKit(false)
  end
end
SlashCmdList.UWGUILD = function(msg)
  local cmd, args = strtrim(msg or ""):match("^(%S*)%s*(.-)$")
  cmd = (cmd or ""):lower()
  if cmd == "" then cmd = "kit" end
  local fn = ns.commands[cmd]
  local sub = (args or ""):match("^(%S+)")
  sub = sub and sub:lower()
  if fn then
    -- on/off and the kit's own words count as their own feature; any other word may be a name, so it isn't kept.
    local named = (sub == "on" or sub == "off") and cmd .. " " .. sub
      or cmd == "kit" and sub and (ns.kitCommands[sub] or sub == "extras" or sub == "report") and "kit " .. sub or cmd
    local from = ns.useFrom or "cmd"
    ns.useFrom = nil
    protect(ns.use, from, named) -- a counting bug never blocks the command itself
    protect(fn, args)
    return
  end
  ns.useFrom = nil
  protect(ns.use, "unknown", cmd)
  -- rate and vibe join the list on the day each opens to members (Thanks.lua), never before (gentle rollouts, rule 2).
  local dated = (ns.RateOpen and ns.RateOpen() and ", rate" or "") .. (ns.VibeOpen and ns.VibeOpen() and ", vibe" or "")
  say(("Everyone: /uw kit, near, welcome, invite, contact, jobs, loot, plan, craft, thanks, likes, events, meet, version%s. /uw options shows each as a button.")
    :format(dated))
  say("Automatic, each with on and off: /uw gear, bags, bars, space, chain, guide, mail, events.")
  say("/uw kit words: list, extras, fix, layout, look, macros, report. Something odd? /uw selftest checks UW_Guild.")
  say("Officers: /uw lead, audit, new, raiders, note, nudge notes, recruit, kit edit, buddy, invite <link>, leavers, discord.")
  say("Guild Master: /uw ranks, charter. Guild bank character: /uw bank.")
end
