-- DialogueUI stays open for the next quest (Louis, 5 Nov 2026: "dialogue key/ui sometimes turns in a quest but fails
-- to stay open to accept quests unlocked from that one").
--
-- Why it closes: after a turn-in, DialogueUI (1.0.7) closes its window 1.5 s later in case the game never says the
-- quest window is done (Code/Core.lua, "TriggerQuestFinished"). Closing ends the talk with the NPC. When the server
-- is slow (launch-week Forever), the follow-up quest arrives after that, so the talk is already over and the player
-- has to click the NPC again.
--
-- What this does: for a few seconds after a turn-in, while the game still says we're talking to the NPC, a close
-- that DialogueUI starts by itself waits. If the next quest, quest list or gossip shows, DialogueUI just carries on.
-- If nothing comes, it closes as before. Esc and the close keys always work at once (they pass DialogueUI's own
-- "from a key" flag). Without DialogueUI nothing happens.
local _, ns = ...

ns.DIALOGUE_HOLD_SECONDS = 4 -- after a turn-in: how long a self-started close waits for the next quest

local function g(name) return rawget(_G, name) end
local function call(fn, ...)
  if type(fn) ~= "function" then return nil end
  local ok, a = pcall(fn, ...)
  if ok then return a end
end

local turnedInAt, nextAt = nil, nil -- GetTime() of the last turn-in, and of the last dialogue shown after it
local function talking()
  local im = g("C_PlayerInteractionManager")
  local types = g("Enum") and Enum.PlayerInteractionType
  if not (im and types) then return false end
  return call(im.IsInteractingWithNpcOfType, types.Gossip) == true
    or call(im.IsInteractingWithNpcOfType, types.QuestGiver) == true
end

local wrapped = false
local function wrap()
  local frame = g("DUIQuestFrame")
  if wrapped or type(frame) ~= "table" or type(frame.HideUI) ~= "function" then return end
  wrapped = true
  local hideUI = frame.HideUI
  frame.HideUI = function(self, cancelPopupFirst, fromPressingKey, ...)
    -- Only between a turn-in and whatever the NPC shows next: after that, DialogueUI decides as always.
    local db = rawget(_G, "UW_GuildDB")
    if type(db) == "table" and db.dialogueHold == false then   -- switched off on the options page
      return hideUI(self, cancelPopupFirst, fromPressingKey, ...)
    end
    local since = turnedInAt and not (nextAt and nextAt >= turnedInAt) and GetTime() - turnedInAt
    local ok, still = pcall(talking)
    if cancelPopupFirst or fromPressingKey or not since or since > ns.DIALOGUE_HOLD_SECONDS or not (ok and still) then
      return hideUI(self, cancelPopupFirst, fromPressingKey, ...)
    end
    -- Wait for the next quest; close as DialogueUI meant to if none shows.
    local at = turnedInAt
    C_Timer.After(ns.DIALOGUE_HOLD_SECONDS - since + 0.1, function()
      if turnedInAt ~= at or (nextAt and nextAt >= at) then return end
      turnedInAt = nil
      if call(self.IsShown, self) then hideUI(self) end
    end)
  end
end
ns.WrapDialogueHide = wrap

local f = CreateFrame("Frame")
ns.listen(f, { "PLAYER_LOGIN", "QUEST_DETAIL", "QUEST_GREETING", "GOSSIP_SHOW", "QUEST_PROGRESS", "QUEST_COMPLETE" })
f:SetScript("OnEvent", function(_, event)
  if event == "PLAYER_LOGIN" then
    ns.protect(wrap)
    if g("hooksecurefunc") and g("GetQuestReward") then
      pcall(g("hooksecurefunc"), "GetQuestReward", function() turnedInAt, nextAt = GetTime(), nil end)
    end
    return
  end
  if turnedInAt then nextAt = GetTime() end
end)
