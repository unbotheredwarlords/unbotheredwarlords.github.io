-- /uw plan: who does what on a boss, from its guide in Discord (raid guides, 4 Nov 2026). The raid leader copies the
-- plan code from the boss's guide card and pastes it into /uw plan. UW_Guild sends it to the raid, and each raider's
-- client prints only that raider's own lines for each step, with raid marker icons. It's a plan, never a radar:
-- addons can't read positions in raids. Nothing is saved; the plan stays for the session, so /uw plan prints it again.
--   UWP1:<len>:<sum>:<body>  The bot writes it (bot/uwbot/plancode.py, which documents the fields); both test suites
--   read the shared codes in bot/tests/fixtures/plan_codes.lua, so the two readers can't drift apart.
-- Only a Raider-or-up raid leader or assistant can send one (ns.trustedLeader, Raid.lua, as for loot), only on RAID,
-- on its own prefix in pieces of at most 200 bytes, cut between characters, one every 1.1 s. Never printed in combat:
-- a plan that arrives mid-fight waits for the fight to end.
local _, ns = ...
local say = ns.say

ns.PLAN_MAX, ns.PLAN_STEPS, ns.PLAN_PEOPLE, ns.PLAN_LINE = 4000, 10, 40, 80
ns.PLAN_GAP, ns.PLAN_PIECE = 1.1, 200
local PPREFIX = "UWG1P" -- its own prefix: the game throttles each prefix, so a plan never slows guild messages
local MAX_PIECES = 25    -- 4000 bytes in pieces of at least 197 (a cut never moves back more than 3 bytes)

-- Reading a code --------------------------------------------------------------------------------------------------
local function split(s, sep)
  local out, start = {}, 1
  while true do
    local i = s:find(sep, start, true)
    if not i then out[#out + 1] = s:sub(start) return out end
    out[#out + 1] = s:sub(start, i - 1)
    start = i + 1
  end
end

-- %XX, either case. A % without two hex digits after it makes the whole code unreadable (plancode.py does the same).
local function unescape(s)
  for i in s:gmatch("()%%") do
    if not s:sub(i + 1, i + 2):match("^%x%x$") then return nil end
  end
  return (s:gsub("%%(%x%x)", function(h) return string.char(tonumber(h, 16)) end))
end

-- As text, from the two halves: %08x of a number at or above 2^31 isn't safe in the client's Lua on Windows.
local function sumText(s)
  local n = ns.Adler32(s)
  return ("%04x%04x"):format(math.floor(n / 65536), n % 65536)
end

-- The plan, or nil and the first problem, checked in the order plancode.py checks them: version, size, len, sum,
-- field ("field" also for a code that isn't one).
function ns.DecodePlan(code)
  if type(code) ~= "string" then return nil, "field" end
  code = strtrim((strtrim(code):gsub("^`+", ""):gsub("`+$", ""))) -- copied with Discord's code marks: no code ends in one
  local ver = code:match("^UWP(%d+):")
  if not ver then return nil, "field" end
  if ver ~= "1" then return nil, "version" end
  if #code > ns.PLAN_MAX then return nil, "size" end
  local len, sum, body = code:match("^UWP1:(%d+):(%x%x%x%x%x%x%x%x):(.*)$")
  if not len or sum:find("[A-F]") then return nil, "field" end
  if #body ~= tonumber(len) then return nil, "len" end
  if sumText(body) ~= sum then return nil, "sum" end
  local f = {}
  for _, part in ipairs(split(body, ";")) do
    local k, val = part:match("^([^=]*)=(.*)$")
    if not k or f[k] then return nil, "field" end
    f[k] = val
  end
  for _, k in ipairs({ "v", "b", "s", "g", "p" }) do
    if not f[k] then return nil, "field" end
  end
  if not f.v:match("^%d+$") then return nil, "field" end
  local steps = split(f.s, "~")
  for i, t in ipairs(steps) do
    steps[i] = unescape(t)
    if not steps[i] then return nil, "field" end
  end
  if #steps > ns.PLAN_STEPS then return nil, "size" end
  local groups = {}
  for _, g in ipairs(split(f.g, ",")) do
    local gid, rest = g:match("^([^:]*):(.*)$")
    if not gid or not gid:match("^[A-Za-z0-9][A-Za-z0-9]?[A-Za-z0-9]?$") or groups[gid] then return nil, "field" end
    local lines = split(rest, "~")
    for i, x in ipairs(lines) do
      lines[i] = unescape(x)
      if not lines[i] then return nil, "field" end
    end
    if #lines ~= #steps then return nil, "field" end
    for _, x in ipairs(lines) do
      if #x > ns.PLAN_LINE then return nil, "size" end
    end
    groups[gid] = lines
  end
  local people, keys, n = {}, {}, 0
  for _, p in ipairs(split(f.p, ",")) do
    local name, gid = p:match("^(.*):([^:]*)$")
    if not name or name == "" or not groups[gid] then return nil, "field" end
    name = unescape(name)
    if not name then return nil, "field" end
    people[#people + 1] = { name, gid }
    local key = ns.NameKey(name)
    if not keys[key] then keys[key], n = true, n + 1 end
  end
  if n > ns.PLAN_PEOPLE then return nil, "size" end
  local boss = unescape(f.b)
  if not boss then return nil, "field" end
  return { v = tonumber(f.v), boss = boss, steps = steps, groups = groups, people = people, sum = sum }
end

-- What one raider is told: for each step, the non-empty lines of their groups, in p= order. Empty when the plan
-- doesn't name them.
function ns.PlanLines(plan, name)
  local key, gids = ns.NameKey(name), {}
  for _, p in ipairs(plan.people) do
    if ns.NameKey(p[1]) == key then gids[#gids + 1] = p[2] end
  end
  if #gids == 0 then return {} end
  local out = {}
  for i = 1, #plan.steps do
    local l = {}
    for _, g in ipairs(gids) do
      local x = plan.groups[g][i]
      if x ~= "" then l[#l + 1] = x end
    end
    out[i] = l
  end
  return out
end

-- Printing ---------------------------------------------------------------------------------------------------------
-- Chat reads | as the start of a color, link or texture, so the guide's text shows it as a plain |; only our own
-- {rt1} to {rt8} become marker icons.
local function chatText(s)
  return (s:gsub("|", "||"):gsub("{rt([1-8])}", "|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_%1:0|t"))
end

local held, heldFrom, waiting -- the plan this session, who sent it, and whether it waits for combat to end
local function show()
  if not held then return end
  if InCombatLockdown() then waiting = true return end
  waiting = false
  local mine = ns.PlanLines(held, ns.me())
  say(("Plan for %s (guide v%d), from %s:"):format(chatText(held.boss), held.v, ns.shortName(heldFrom)))
  if #mine == 0 then
    say("This plan doesn't name you. Ask the raid leader where they want you.")
    return
  end
  local any = false
  for i, step in ipairs(held.steps) do
    if #mine[i] > 0 then
      any = true
      say(("%d. %s: %s"):format(i, chatText(step), chatText(table.concat(mine[i], " · "))))
    end
  end
  if not any then say("Nothing special for you in this plan: follow the raid leader's calls.") end
end
ns.ShowPlan = show

local PROBLEM = {
  version = "That plan code is from a newer UW_Guild. Get the new one at " .. ns.ADDON_URL .. ".",
  size = "That plan code is too long for UW_Guild. Ask whoever wrote the guide to shorten it.",
  len = "Part of that plan code is missing. Copy the whole code from the guide in Discord again.",
  sum = "That plan code was changed or mistyped. Copy it from the guide in Discord again.",
  field = "That isn't a plan code. Copy the code from the boss's guide in Discord.",
}
ns.PLAN_PROBLEM = PROBLEM

-- Sending ------------------------------------------------------------------------------------------------------------
local function maySend()
  return IsInRaid() and ns.tracksGuild() and ns.canShareRaid(ns.me())
    and (UnitIsGroupLeader("player") or UnitIsGroupAssistant("player"))
end

-- Pieces of at most PLAN_PIECE bytes, never cut inside a character: a piece that ends mid-character is not valid
-- UTF-8, and the game may refuse or mangle it.
function ns.PlanPieces(code)
  local out, i = {}, 1
  while i <= #code do
    local j = math.min(i + ns.PLAN_PIECE - 1, #code)
    while j < #code and j > i do
      local b = code:byte(j + 1)
      if b < 0x80 or b >= 0xC0 then break end -- the next piece starts a character
      j = j - 1
    end
    out[#out + 1] = code:sub(i, j)
    i = j + 1
  end
  return out
end

local outgoing -- { msgs, i, tries } while a plan is going out
local function pump()
  local o = outgoing
  if not o then return end
  local got = ns.trySend(PPREFIX, o.msgs[o.i], "RAID") -- "ok", "retry", "wait" or "never" (Core.lua)
  if got == "wait" then ns.after(2, pump) return end -- combat or an encounter: waits, not a try
  if got == "ok" then
    o.i, o.tries = o.i + 1, 0
    if o.i > #o.msgs then
      outgoing = nil
      say("Plan sent to the raid. Each raider sees their own lines; /uw plan shows it again.")
      return
    end
    ns.after(ns.PLAN_GAP, pump)
    return
  end
  o.tries = o.tries + 1
  if o.tries >= 5 or got == "never" then -- "never": not in a raid any more, so no try can work
    outgoing = nil
    say("The game kept refusing the plan, so it wasn't sent. Try /uw plan again in a moment.")
    return
  end
  ns.after(2, pump)
end

function ns.SendPlan(code)
  if not maySend() then
    say("Only a raid leader or assistant of Raider rank or higher can send a plan, in a raid.")
    return false
  end
  if InCombatLockdown() then say("After combat, please.") return false end
  local plan, problem = ns.DecodePlan(code)
  if not plan then say(PROBLEM[problem]) return false end
  code = strtrim((strtrim(code):gsub("^`+", ""):gsub("`+$", "")))
  local pieces = ns.PlanPieces(code)
  local msgs = {}
  for i, p in ipairs(pieces) do msgs[i] = ("PP\t%s\t%d\t%d\t%s"):format(plan.sum, i, #pieces, p) end
  local starting = outgoing == nil
  outgoing = { msgs = msgs, i = 1, tries = 0 } -- a new plan replaces one still going out
  held, heldFrom = plan, ns.me()
  show()
  if starting then pump() end
  return true
end

-- Receiving ----------------------------------------------------------------------------------------------------------
local inbox = {} -- sender -> { id, n, parts, got }
local toldNewer = false
local function onPiece(sender, id, i, n, piece)
  if not ns.trustedLeader(sender) then return end -- a Raider-or-up guildmate leading or assisting (Raid.lua)
  i, n = tonumber(i), tonumber(n)
  if not (id and i and n and piece) or not id:match("^%x+$") or n < 1 or n > MAX_PIECES or i < 1 or i > n
    or i ~= math.floor(i) or n ~= math.floor(n) then return end
  local box = inbox[sender]
  if not box or box.id ~= id or box.n ~= n then
    box = { id = id, n = n, parts = {}, got = 0 }
    inbox[sender] = box
  end
  if box.parts[i] then return end
  box.parts[i], box.got = piece, box.got + 1
  if box.got < n then return end
  inbox[sender] = nil
  local plan, problem = ns.DecodePlan(table.concat(box.parts))
  if not plan or plan.sum ~= id then
    if problem == "version" and not toldNewer then
      toldNewer = true
      say(("%s sent a plan from a newer UW_Guild. Get it at %s."):format(ns.shortName(sender), ns.ADDON_URL))
    end
    return
  end
  held, heldFrom = plan, sender
  show()
end

table.insert(ns.onLoad, function() pcall(C_ChatInfo.RegisterAddonMessagePrefix, PPREFIX) end)

local f = CreateFrame("Frame")
f:RegisterEvent("CHAT_MSG_ADDON")
f:RegisterEvent("PLAYER_REGEN_ENABLED")
f:SetScript("OnEvent", ns.guard(function(_, event, prefix, text, channel, sender)
  if event == "PLAYER_REGEN_ENABLED" then
    if waiting then ns.protect(show) end
    return
  end
  if prefix ~= PPREFIX or channel ~= "RAID" or type(text) ~= "string" then return end
  sender = ns.fullName(sender)
  if not sender then return end
  local tag, id, i, n, piece = strsplit("\t", text)
  if tag == "PP" then ns.protect(onPiece, sender, id, i, n, piece) end
end))

-- /uw plan: a leader pastes a code (also printed: the plan this session, if any); anyone else sees their lines.
ns.commands.plan = function()
  if held then show() end
  if maySend() then
    ns.TextBox("UW raid plan", "Paste the plan code from the boss's guide in Discord, then press Enter.", "", ns.SendPlan)
  elseif not held then
    say("No plan yet. Your raid leader sends one before the pull, from the boss's guide in Discord.")
  end
end
