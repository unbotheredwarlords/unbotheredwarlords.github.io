-- Kit sharing (Louis, 4 Nov 2026: "ensure the overall goal of the uw addon is to ensure all other addons are in optimal
-- function, communication, alignment, cohesion, synergy"). UW_Guild is the kit's conductor, under /uw kit only:
--   * officers change the kit in game (add, remove, pair, unpair, reset) and every member gets it without a release
--     (KC, KCQ below; the bot reads the same saved kit for the #addon-kit post);
--   * an officer shares their EllesmereUI and Details layout (/uw kit layout share), and members apply it with one
--     click through each addon's own import (/uw kit layout), so raid frames, bars and meters match;
--   * /uw kit fix turns off the second addon of each duplicate pair and turns on kit addons that are installed but off
--     (/uw kit fix all: on every character of the account);
--   * /uw kit nudge asks online members to check theirs: only members with something to fix see anything.
local _, ns = ...
local say = ns.say

local function me() return ns.shortName(ns.me() or UnitName("player")) end
local function serverNow() return (GetServerTime and GetServerTime()) or time() end
local fmtDate = rawget(_G, "date") or os.date
local function copy(t)
  if type(t) ~= "table" then return t end
  local o = {}
  for k, v in pairs(t) do o[k] = copy(v) end
  return o
end

-- The kit as shipped (Core.lua). Every in-game version is checked against these limits on every client, so a long or
-- odd kit from any sender can't swamp chat or the 255-byte audit reply.
ns.KIT_DEFAULT = copy(ns.KIT)
local LIMITS = { everyone = 8, raiding = 8, extras = 16, conflicts = 24, alts = 3, name = 64, goal = 48, text = 2400,
  piece = 180, by = 48 } -- a KC piece: 180 bytes + its header (by at 48 bytes) stays under the 255-byte message cap
ns.KIT_LIMITS = LIMITS
ns.KIT_LAYOUT_ADDONS = { "EllesmereUI", "Details" } -- the addons whose own import UW_Guild calls
ns.KIT_LAYOUT_MAX = 256 * 1024                      -- bytes of one layout string
ns.KIT_LAYOUT_PROFILE = "UW Guild"                  -- the profile name the guild layout is imported as
local LAYOUT_ADDON = {}
for _, a in ipairs(ns.KIT_LAYOUT_ADDONS) do LAYOUT_ADDON[a] = true end

-- Adler-32 (RFC 1950), with plain arithmetic: Lua 5.1 has no bit operations. Python's zlib.adler32 gives the same.
function ns.Adler32(s)
  local a, b = 1, 0
  for i = 1, #s, 4096 do
    local chunk = { s:byte(i, math.min(i + 4095, #s)) }
    for j = 1, #chunk do
      a = (a + chunk[j]) % 65521
      b = (b + a) % 65521
    end
  end
  return b * 65536 + a
end

-- Kit text --------------------------------------------------------------------
-- One line, the same in SavedVariables, in KC messages and for the bot (bot/uwbot/kitcfg.py):
--   v1;e=EllesmereUI,Baganator;r=DBM-Core/BigWigs,Details;x=Pawn:Is it an upgrade?;d=Baganator>Bagnon;l=Details:at:len:sum:by
-- e, r, x, d: Everyone, Raiding, Extras (addon:goal) and duplicate pairs (keep>turn off). A missing section means the
-- shipped one, so /uw kit reset keeps a shared layout (l). "/" separates alternatives. Goals and names in l are
-- %-escaped (%2C for a comma). Unknown sections are skipped, so a newer version can add some.
local NAME = "^[%w_%-%.!]+$"
local function validName(n) return type(n) == "string" and #n > 0 and #n <= LIMITS.name and n:find(NAME) ~= nil end
local function enc(s) return (s:gsub("[%%,;:=>/]", function(c) return ("%%%02X"):format(c:byte()) end)) end
local function dec(s) return (s:gsub("%%(%x%x)", function(h) return string.char(tonumber(h, 16)) end)) end
local function validText(s, max) return type(s) == "string" and #s > 0 and #s <= max and not s:find("[%c|]") end
local function entryText(e) return type(e) == "table" and table.concat(e, "/") or e end
local function names(e) return type(e) == "table" and e or { e } end

local function parseEntry(s)
  local alts = {}
  for n in (s .. "/"):gmatch("([^/]*)/") do
    if not validName(n) then return nil end
    alts[#alts + 1] = n
  end
  if #alts == 0 or #alts > LIMITS.alts then return nil end
  return #alts == 1 and alts[1] or alts
end

-- An addon's folder name and why it isn't loading ("MISSING", "DISABLED", ...), never an error for an unknown name.
local function addonInfo(n)
  local ok, real, _, _, _, reason = pcall(C_AddOns.GetAddOnInfo, n)
  if not ok then return nil, "MISSING" end
  return real, reason
end

local function whole(v) local n = ns.finite(v) return n and n >= 0 and n == math.floor(n) and n or nil end

function ns.KitText(kit, lists)
  local parts = { "v1" }
  local function list(t, each)
    local out = {}
    for i, e in ipairs(t) do out[#out + 1] = each(e, i) end
    return table.concat(out, ",")
  end
  if lists then
    parts[#parts + 1] = "e=" .. list(kit.everyone, entryText)
    parts[#parts + 1] = "r=" .. list(kit.raiding, entryText)
    parts[#parts + 1] = "x=" .. list(kit.extras, function(e, i) return entryText(e) .. ":" .. enc(kit.goals[i] or "") end)
    parts[#parts + 1] = "d=" .. list(kit.conflicts, function(p) return p[1] .. ">" .. p[2] end)
  end
  if kit.layouts and #kit.layouts > 0 then
    parts[#parts + 1] = "l=" .. list(kit.layouts, function(l)
      return ("%s:%d:%d:%d:%s"):format(l.addon, l.at, l.len, l.sum, enc(l.by)) end)
  end
  return table.concat(parts, ";")
end

-- The kit a text describes (sections it lacks are the shipped ones), with custom = true when it changes any list;
-- nil when anything in it is malformed or over a limit.
function ns.ParseKit(text)
  if not validText(text, LIMITS.text) then return nil end
  local secs, first = {}, true
  for part in (text .. ";"):gmatch("([^;]*);") do
    if first then
      if part ~= "v1" then return nil end
      first = false
    else
      local k, v = part:match("^(%a)=(.*)$")
      if not k or secs[k] then return nil end
      secs[k] = v
    end
  end
  local function list(v, max, each)
    local out = {}
    if v == "" then return out end
    for item in (v .. ","):gmatch("([^,]*),") do
      local x, y = each(item)
      if x == nil then return nil end
      out[#out + 1] = { x, y }
      if #out > max then return nil end
    end
    return out
  end
  local D = ns.KIT_DEFAULT
  local kit = { everyone = copy(D.everyone), raiding = copy(D.raiding), extras = copy(D.extras), goals = copy(D.goals),
    conflicts = copy(D.conflicts), layouts = {}, custom = (secs.e or secs.r or secs.x or secs.d) ~= nil }
  for _, s in ipairs({ { "e", "everyone" }, { "r", "raiding" } }) do
    if secs[s[1]] then
      local l = list(secs[s[1]], LIMITS[s[2]], parseEntry)
      if not l then return nil end
      kit[s[2]] = {}
      for _, p in ipairs(l) do kit[s[2]][#kit[s[2]] + 1] = p[1] end
    end
  end
  if secs.x then
    local l = list(secs.x, LIMITS.extras, function(item)
      local e, g = item:match("^([^:]+):(.+)$")
      local entry, goal = e and parseEntry(e), g and dec(g)
      if entry and validText(goal, LIMITS.goal) then return entry, goal end
    end)
    if not l then return nil end
    kit.extras, kit.goals = {}, {}
    for _, p in ipairs(l) do kit.extras[#kit.extras + 1], kit.goals[#kit.goals + 1] = p[1], p[2] end
  end
  if secs.d then
    local l = list(secs.d, LIMITS.conflicts, function(item)
      local a, b = item:match("^([^>]+)>([^>]+)$")
      if validName(a) and validName(b) and a ~= b then return a, b end
    end)
    if not l then return nil end
    kit.conflicts = l
  end
  if secs.l then
    local l = list(secs.l, #ns.KIT_LAYOUT_ADDONS, function(item)
      local addon, at, len, sum, by = item:match("^([^:]+):(%d+):(%d+):(%d+):([^:]+)$")
      at, len, sum, by = whole(at), whole(len), whole(sum), by and dec(by)
      if LAYOUT_ADDON[addon] and at and len and len > 0 and len <= ns.KIT_LAYOUT_MAX and sum and sum < 4294967296
        and validText(by, LIMITS.by) then
        return { addon = addon, at = at, len = len, sum = sum, by = by }
      end
    end)
    if not l then return nil end
    local seen = {}
    for _, p in ipairs(l) do
      if seen[p[1].addon] then return nil end
      seen[p[1].addon] = true
      kit.layouts[#kit.layouts + 1] = p[1]
    end
  end
  return kit
end

-- The kit in force: the newest version an officer set in game, else the shipped one.
local function current()
  local saved = UW_GuildDB and UW_GuildDB.kit
  return saved and ns.ParseKit(saved.text) or ns.ParseKit("v1")
end
ns.CurrentKit = current
local function apply(kit)
  for _, f in ipairs({ "everyone", "raiding", "extras", "goals", "conflicts", "layouts" }) do ns.KIT[f] = copy(kit[f]) end
  if ns.RefreshWelcome then ns.RefreshWelcome() end -- its kit line counts the Everyone section
end

local function newer(at, text)
  local cur = UW_GuildDB.kit
  return not cur or at > cur.at or (at == cur.at and text > cur.text)
end

local function pieces(text)
  local out = {}
  for i = 1, math.max(1, math.ceil(#text / LIMITS.piece)) do out[i] = text:sub((i - 1) * LIMITS.piece + 1, i * LIMITS.piece) end
  return out
end
local function kitMessages()
  local k = UW_GuildDB.kit
  local out, p = {}, pieces(k.text)
  for i, piece in ipairs(p) do out[i] = ("KC\t%d\t%s\t%d\t%d\t%s"):format(k.at, k.by, i, #p, piece) end
  return out
end

-- One broadcast on GUILD serves every member online who needs it. At most once a minute, so many logins at once cost
-- one send (members who already have it ignore it), and none when another officer just sent the same version.
local nextBroadcast, scheduled, heard, editToken = 0, false, {}, 0
local function broadcast()
  nextBroadcast = GetTime() + 60
  for _, msg in ipairs(kitMessages()) do ns.officerSend(msg, "GUILD") end
end
local function broadcastSoon(delay)
  if scheduled then return end
  scheduled = true
  local since, k = GetTime(), UW_GuildDB.kit
  C_Timer.After(math.max(delay, nextBroadcast - GetTime()) + math.random() * 4, function()
    scheduled = false
    local cur = UW_GuildDB.kit
    if not cur or (heard[cur.at] and heard[cur.at] >= since and cur.at == k.at) then return end
    broadcast()
  end)
end

-- Officer edits ---------------------------------------------------------------
local function isOfficer() return ns.isOfficer(me()) end

-- Save a new version and send it to guildmates online. lists: whether the Everyone, Raiding, Extras and duplicate
-- lists are the officers' own (false keeps the shipped ones, as /uw kit reset wants).
local function commit(kit, lists, note)
  local text = ns.KitText(kit, lists)
  local parsed = ns.ParseKit(text)
  if not parsed then say("|cffff4040That kit is too long to share.|r Remove something first.") return false end
  local cur, at = UW_GuildDB.kit, serverNow()
  if cur and at <= cur.at then at = cur.at + 1 end -- a later edit always wins, even with a slow clock
  UW_GuildDB.kit = { at = at, by = (me():gsub("[%c|\t]", "")):sub(1, LIMITS.by), text = text }
  apply(parsed)
  -- Sent 3 s after the last of several edits in a row, so members get one update, not one per edit.
  editToken = editToken + 1
  local mine = editToken
  C_Timer.After(3, function() if mine == editToken then broadcast() end end)
  say(note .. " Online guildmates get it now, the rest at login. /uw kit list shows it.")
  return true
end

-- "DBM-Core or BigWigs" or "DBM-Core/BigWigs" -> { names }, each spelled as its folder when installed here.
local function readEntry(s)
  local out = {}
  for n in (s:gsub("%s+[Oo][Rr]%s+", "/") .. "/"):gmatch("%s*([^/]-)%s*/") do
    if n ~= "" then
      local real, reason = addonInfo(n)
      out[#out + 1] = (type(real) == "string" and reason ~= "MISSING" and real ~= "") and real or n
    end
  end
  return out
end
local function lower(s) return s:lower() end
local function contains(e, name)
  for _, n in ipairs(names(e)) do if lower(n) == lower(name) then return true end end
  return false
end
-- Remove every list entry naming one of these addons; returns how many went.
local function removeFrom(kit, list)
  local gone = 0
  for _, field in ipairs({ "everyone", "raiding", "extras" }) do
    local keep, goals = {}, {}
    for i, e in ipairs(kit[field]) do
      local hit = false
      for _, n in ipairs(list) do if contains(e, n) then hit = true end end
      if hit then gone = gone + 1 else keep[#keep + 1] = e; goals[#goals + 1] = kit.goals[i] end
    end
    kit[field] = keep
    if field == "extras" then kit.goals = goals end
  end
  return gone
end
local SECTION = { everyone = "everyone", e = "everyone", all = "everyone", raiding = "raiding", raid = "raiding",
  r = "raiding", extras = "extras", extra = "extras", x = "extras" }

local function notHere(list)
  local missing = {}
  for _, n in ipairs(list) do if not ns.isInstalled(n) then missing[#missing + 1] = n end end
  if #missing > 0 then
    say(("|cffffd100Note:|r %s isn't installed here, so check the spelling: it's the folder name in Interface\\AddOns.")
      :format(table.concat(missing, ", ")))
  end
end

local function editHelp()
  say("Officers change the kit for everyone, in game:")
  say("/uw kit add everyone|raiding <Addon> (or <Addon> or <Other> for either one)")
  say("/uw kit add extras <Addon> = <goal>   e.g. /uw kit add extras TomTom = Waypoints")
  say("/uw kit remove <Addon> · /uw kit pair <Keep> <TurnOff> · /uw kit unpair <Addon>")
  say("/uw kit layout share: your EllesmereUI and Details layout for everyone · /uw kit reset: back to the shipped kit")
  say("/uw kit nudge: online members with something to fix get a reminder · /uw audit: who has what")
end

local cmd = ns.kitCommands
cmd.edit = function()
  if not isOfficer() then say("Only officers can change the kit. /uw kit list shows it.") return end
  editHelp()
end

cmd.add = function(args)
  if not isOfficer() then say("Only officers can change the kit.") return end
  local sec, rest = (args or ""):match("^(%S*)%s*(.-)$")
  local field = SECTION[(sec or ""):lower()]
  local entryPart, goal = rest:match("^(.-)%s*=%s*(.-)$")
  entryPart = entryPart or rest
  local list = readEntry(entryPart)
  if not field or #list == 0 then editHelp() return end
  if field == "extras" and not validText(goal, LIMITS.goal) then
    say(("Extras need a goal, %d characters at most: /uw kit add extras %s = <what it's for>"):format(LIMITS.goal, entryPart))
    return
  end
  for _, n in ipairs(list) do
    if not validName(n) then say(("%q isn't an addon folder name (letters, digits, _ - . ! only)."):format(n)) return end
  end
  if #list > LIMITS.alts then say(("At most %d alternatives in one entry."):format(LIMITS.alts)) return end
  local kit = current()
  local moved = removeFrom(kit, list) > 0
  if #kit[field] >= LIMITS[field] then say(("The %s list is full (%d). Remove one first."):format(field, LIMITS[field])) return end
  kit[field][#kit[field] + 1] = #list == 1 and list[1] or list
  if field == "extras" then kit.goals[#kit.extras] = goal end
  if commit(kit, true, ("%s %s in %s."):format(moved and "Moved" or "Added", table.concat(list, " or "), field)) then
    notHere(list)
  end
end

cmd.remove = function(args)
  if not isOfficer() then say("Only officers can change the kit.") return end
  local name = strtrim(args or "")
  if name == "" then say("/uw kit remove <Addon>") return end
  local kit = current()
  if removeFrom(kit, { name }) == 0 then say(("%s isn't in the kit. /uw kit list shows it."):format(name)) return end
  commit(kit, true, ("Removed %s from the kit."):format(name))
end

cmd.pair = function(args)
  if not isOfficer() then say("Only officers can change the kit.") return end
  local a, b = (args or ""):match("^%s*(%S+)%s+(%S+)%s*$")
  if not (validName(a) and validName(b)) or a:lower() == b:lower() then
    say("/uw kit pair <Keep> <TurnOff>: two addons that do one job. /uw kit fix turns off the second.")
    return
  end
  a, b = readEntry(a)[1], readEntry(b)[1]
  local kit = current()
  for _, p in ipairs(kit.conflicts) do
    if (lower(p[1]) == lower(a) and lower(p[2]) == lower(b)) or (lower(p[1]) == lower(b) and lower(p[2]) == lower(a)) then
      say(("%s and %s are already a pair. /uw kit unpair %s first to swap which one stays."):format(p[1], p[2], p[1]))
      return
    end
  end
  if #kit.conflicts >= LIMITS.conflicts then say("The duplicates list is full. Unpair one first.") return end
  kit.conflicts[#kit.conflicts + 1] = { a, b }
  if commit(kit, true, ("Pair added: keep %s, turn off %s."):format(a, b)) then notHere({ a, b }) end
end

cmd.unpair = function(args)
  if not isOfficer() then say("Only officers can change the kit.") return end
  local a, b = (args or ""):match("^%s*(%S+)%s*(%S*)%s*$")
  if not a then say("/uw kit unpair <Addon> [<Other>]") return end
  local kit, keep, gone = current(), {}, 0
  for _, p in ipairs(kit.conflicts) do
    local hit = lower(p[1]) == lower(a) or lower(p[2]) == lower(a)
    if hit and b ~= "" then hit = lower(p[1]) == lower(b) or lower(p[2]) == lower(b) end
    if hit then gone = gone + 1 else keep[#keep + 1] = p end
  end
  if gone == 0 then say("No pair like that. /uw kit list shows them.") return end
  kit.conflicts = keep
  commit(kit, true, ("Removed %d pair(s)."):format(gone))
end

cmd.reset = function(args)
  if not isOfficer() then say("Only officers can change the kit.") return end
  if strtrim(args or ""):lower() ~= "confirm" then
    say("This puts back the kit as UW_Guild shipped it, for everyone (a shared layout stays). Type /uw kit reset confirm.")
    return
  end
  commit(current(), false, "The kit is back to the shipped one.")
end

-- /uw kit list: the whole kit, for anyone.
cmd.list = function()
  local k = UW_GuildDB.kit
  local kit = ns.KIT
  local function entries(t) local out = {} for _, e in ipairs(t) do out[#out + 1] = ns.kitName(e) end return table.concat(out, ", ") end
  say(k and ns.ParseKit(k.text) and ns.ParseKit(k.text).custom
    and ("Guild addon kit, changed in game by %s on %s:"):format(k.by, fmtDate("%d %b %H:%M", k.at))
    or ("Guild addon kit (as shipped with UW_Guild v%s):"):format(ns.VERSION))
  say("|cffffd100Everyone:|r " .. entries(kit.everyone))
  say("|cffffd100Raiding:|r " .. entries(kit.raiding))
  for i, e in ipairs(kit.extras) do say(("|cffffd100Extra|r, %s: %s"):format(kit.goals[i] or "", ns.kitName(e))) end
  -- One line per addon kept, so a long list stays readable: "EllesmereUIBags over Baganator, Bagnon".
  local over, order = {}, {}
  for _, p in ipairs(kit.conflicts) do
    if not over[p[1]] then over[p[1]] = {} order[#order + 1] = p[1] end
    table.insert(over[p[1]], p[2])
  end
  if #order > 0 then say("|cffffd100One per job|r (keep, over the ones /uw kit fix turns off):") end
  for _, keep in ipairs(order) do say(("  %s over %s"):format(keep, table.concat(over[keep], ", "))) end
  for _, l in ipairs(kit.layouts or {}) do
    say(("|cffffd100Guild layout:|r %s, shared by %s on %s. /uw kit layout uses it."):format(l.addon, l.by,
      fmtDate("%d %b", l.at)))
  end
  if isOfficer() then say("Change it: /uw kit edit") end
end

-- Sync ------------------------------------------------------------------------
-- KC carries a version in pieces; only an officer's counts, and only a newer one replaces ours. Members ask on login
-- with KCQ and the version they have; an officer with a newer one broadcasts it (broadcastSoon above).
local MAX_PIECES = math.ceil(LIMITS.text / LIMITS.piece)
local pending = {}

local function layoutNotice(kit)
  UW_GuildCharDB.layoutNoted = UW_GuildCharDB.layoutNoted or {}
  local applied = UW_GuildCharDB.layoutApplied or {}
  for _, l in ipairs(kit.layouts or {}) do
    if ns.isLoaded(l.addon) and applied[l.addon] ~= l.sum and UW_GuildCharDB.layoutNoted[l.addon] ~= l.sum then
      UW_GuildCharDB.layoutNoted[l.addon] = l.sum
      say(("%s shared the guild's %s layout. Type /uw kit layout to use it; your own stays saved."):format(l.by, l.addon))
    end
  end
end

ns.handlers.KC = function(sender, channel, at, by, i, n, piece)
  if (channel ~= "GUILD" and channel ~= "WHISPER") or not ns.isOfficer(sender) then return end
  at, i, n = whole(at), whole(i), whole(n)
  if not (at and i and n) or n < 1 or n > MAX_PIECES or i < 1 or i > n or type(piece) ~= "string" then return end
  if at > serverNow() + 600 then return end -- an officer's clock in the future can't pin a kit forever
  local p = pending[sender]
  if not p or p.at ~= at or p.n ~= n then p = { at = at, n = n, parts = {}, got = 0 } pending[sender] = p end
  if not p.parts[i] then p.parts[i], p.got = piece, p.got + 1 end
  if p.got < n then return end
  pending[sender] = nil
  local text = table.concat(p.parts)
  local kit = ns.ParseKit(text)
  if not kit then return end
  heard[at] = GetTime() -- an officer sent this version: ours, if we were about to send the same, can wait
  if not newer(at, text) then return end
  if not validText(by, LIMITS.by) then by = ns.shortName(sender) end
  local hadKit = UW_GuildDB.kit ~= nil
  UW_GuildDB.kit = { at = at, by = by, text = text }
  apply(kit)
  if kit.custom or hadKit then say(("%s updated the guild addon kit. /uw kit checks yours."):format(by)) end
  layoutNotice(kit)
end

ns.handlers.KCQ = function(sender, channel, at)
  if channel ~= "GUILD" or not isOfficer() or not ns.inRoster(sender) then return end
  local k, theirs = UW_GuildDB.kit, whole(at) or 0
  if not k or k.at <= theirs then return end
  broadcastSoon(1)
end

table.insert(ns.onLoad, function()
  UW_GuildDB.layouts = UW_GuildDB.layouts or {}
  UW_GuildCharDB = UW_GuildCharDB or {}
  local saved = UW_GuildDB.kit
  if saved and not (type(saved.at) == "number" and type(saved.by) == "string" and ns.ParseKit(saved.text)) then
    UW_GuildDB.kit = nil -- unreadable (a hand edit, or from a newer format): use the shipped kit and ask again
  end
  apply(current())
  pcall(C_ChatInfo.RegisterAddonMessagePrefix, "UWG1L")
end)
table.insert(ns.onGuildJoin, function()
  ns.afterRoster(function()
    if not ns.tracksGuild() then return end
    ns.send("KCQ\t" .. (UW_GuildDB.kit and UW_GuildDB.kit.at or 0), "GUILD")
    C_Timer.After(30, function() layoutNotice(ns.KIT) end) -- after an officer's answer had time to land
  end)
end)

-- Confirm dialogs ---------------------------------------------------------------
-- Shown on the next frame: a dialog opened from another one's button would be hidden again as that one closes.
-- Two names, so a reload question never replaces a layout question.
local function confirm(text, yes, no, which)
  which = which or "UW_GUILD_CONFIRM"
  C_Timer.After(0, function()
    local dialogs = rawget(_G, "StaticPopupDialogs")
    if type(dialogs) == "table" and StaticPopup_Show then
      dialogs[which] = dialogs[which] or { text = "%s", button1 = YES or "Yes", button2 = NO or "No",
        OnAccept = function(_, data) if data and data.yes then data.yes() end end,
        OnCancel = function(_, data) if data and data.no then data.no() end end,
        timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3 }
      if StaticPopup_Show(which, text, nil, { yes = yes, no = no }) then return end
    end
    say(text .. " |cff808080(the game wouldn't open a dialog; try again after combat)|r")
  end)
end
local function askReload(what)
  confirm(what .. " Reload now so it takes effect?", function() ReloadUI() end,
    function() say("It takes effect at your next /reload or login.") end, "UW_GUILD_RELOAD")
end
ns.KitConfirm = confirm

-- /uw kit fix -----------------------------------------------------------------
-- For this character: the second addon of each loaded duplicate pair goes off, and an Everyone addon that is
-- installed but turned off goes on. /uw kit fix all does it for every character on this account, judged by each
-- addon's state over all characters: a pair's second addon goes off everywhere only when the one kept for that job is
-- on for every character, so each character that had the second also has the keeper (a true duplicate, as in plain
-- fix; a BigWigs raider with DBM-Core switched off keeps BigWigs). Pairs that differ between characters are counted and
-- left to /uw kit fix on each. Each installed Everyone addon goes on everywhere. Enable and disable with no character
-- change all characters (warcraft.wiki.gg; Blizzard's AddonList passes nil for All). The game applies it at the next
-- reload or login. Undo: the AddOns button at character select, or /uw kit fix after changing the pairs.
local function character() return (UnitGUID and UnitGUID("player")) or me() end
function ns.KitFixPlan()
  local off, on, seen = {}, {}, {}
  for _, p in ipairs(ns.KIT.conflicts) do
    if ns.isLoaded(p[1]) and ns.isLoaded(p[2]) and not seen[p[2]] then
      seen[p[2]] = true
      off[#off + 1] = { name = p[2], keep = p[1] }
    end
  end
  for _, e in ipairs(ns.KIT.everyone) do
    if not ns.anyLoaded(e) then
      for _, n in ipairs(names(e)) do
        local _, reason = addonInfo(n)
        if reason == "DISABLED" and not seen[n] then on[#on + 1] = n break end
      end
    end
  end
  return off, on
end

-- An addon's state on every character of this account: 0 off everywhere, 1 on for some, 2 on for all; nil when the
-- client can't say.
local function everywhere(n)
  local ok, state = pcall(C_AddOns.GetAddOnEnableState, n)
  return ok and tonumber(state) or nil
end
local function installed(n) local _, reason = addonInfo(n) return reason ~= "MISSING" end
-- The kept addon must be one the game will load: never trade the second addon for one that is out of date or missing
-- a dependency, or a character could lose its only display for that job (such as combo points).
local LOADABLE = { [""] = true, DISABLED = true, DEMAND_LOADED = true }
local function loadable(n) local _, reason = addonInfo(n) return reason == nil or LOADABLE[reason] == true end
-- Returns off, on, and how many pairs differ between characters (left to /uw kit fix on each).
function ns.KitFixAllPlan()
  local off, on, isOff, differ = {}, {}, {}, 0
  for _, p in ipairs(ns.KIT.conflicts) do
    if not isOff[p[2]] and installed(p[1]) and installed(p[2]) and (everywhere(p[2]) or 0) > 0 then
      local keep = everywhere(p[1])
      if keep == 2 and loadable(p[1]) then
        isOff[p[2]] = true
        off[#off + 1] = { name = p[2], keep = p[1] }
      elseif keep ~= 0 then -- a keeper off everywhere is a choice (say no cooldown bars): no character has both
        differ = differ + 1
      end
    end
  end
  for _, e in ipairs(ns.KIT.everyone) do -- one of each entry's alternatives: left alone if one is on everywhere
    local first
    for _, n in ipairs(names(e)) do
      if installed(n) then
        if everywhere(n) == 2 then first = nil break end
        first = first or n
      end
    end
    if first and not isOff[first] then on[#on + 1] = first end
  end
  return off, on, differ
end

cmd.fix = function(args)
  local all = strtrim(args or ""):lower() == "all"
  if all and not C_AddOns.GetAddOnEnableState then
    say("This game client can't see your other characters' addons. Use /uw kit fix on each one.")
    return
  end
  local off, on, differ = (all and ns.KitFixAllPlan or ns.KitFixPlan)()
  local split = (differ or 0) > 0
    and (" %d pair%s differ between characters: /uw kit fix on each."):format(differ, differ == 1 and "" or "s") or ""
  if #off == 0 and #on == 0 then
    if all then say("Nothing to fix on every character at once." .. split)
    else say("Nothing to fix here: no duplicates, and every Everyone addon that's installed is on.") end
    return
  end
  if InCombatLockdown() then say("After combat, please.") return end
  local parts = {}
  for _, o in ipairs(off) do parts[#parts + 1] = ("turn off %s (%s does that job)"):format(o.name, o.keep) end
  for _, n in ipairs(on) do parts[#parts + 1] = "turn on " .. n end
  -- EllesmereUI hides a Forever rogue's combo points until a style is picked (its Class Resource defaults to none), so
  -- turning EnhanceQoL's resource bars off could leave a rogue without them: say where to turn them on.
  local note, ok, _, class = "", pcall(UnitClass, "player")
  for _, o in ipairs(off) do
    if o.name == "EnhanceQoLResourceBars" and (all or (ok and class == "ROGUE")) then
      note = " Rogues: EllesmereUI hides combo points until you pick a style in /eui > Unit Frames > Player > "
        .. "Class Resource."
    end
  end
  local who -- no character: every character on this account
  if not all then who = character() end
  confirm(("UW kit fix, for %s: %s.%s%s"):format(all and "every character on this account" or "this character",
    table.concat(parts, "; "), split, note), function()
    for _, o in ipairs(off) do pcall(C_AddOns.DisableAddOn, o.name, who) end
    for _, n in ipairs(on) do pcall(C_AddOns.EnableAddOn, n, who) end
    askReload(all and "Done. Your other characters get it at their next login." or "Done.")
  end)
end

-- The /uw kit lines after "Missing" and "Duplicate" (Core printKit).
function ns.KitHints(quiet)
  local off, on = ns.KitFixPlan()
  if #off + #on > 0 then say("|cff40ff40Fix it in one step:|r /uw kit fix, or /uw kit fix all for every character") end
  if quiet then return end
  local applied = UW_GuildCharDB.layoutApplied or {}
  local due = {}
  for _, l in ipairs(ns.KIT.layouts or {}) do
    if ns.isLoaded(l.addon) and applied[l.addon] ~= l.sum then due[#due + 1] = l.addon end
  end
  if #due > 0 then say(("|cffffd100Guild layout|r for %s: /uw kit layout"):format(table.concat(due, " and "))) end
end

-- Layouts -----------------------------------------------------------------------
-- Each addon's own public functions, read from the installed copies (4 Nov 2026): EllesmereUI 9.7.3
-- (EllesmereUI_Profiles.lua: ExportProfile, ImportProfileInteractive for partner addons, where the player finishes
-- the import in EllesmereUI's own screen and we own the reload) and Details (functions/profiles.lua:
-- ExportCurrentProfile, ImportProfile). Details' import can carry Lua for Details to run; UW_Guild always passes
-- false for it, so a layout never runs code.
local importers = {
  EllesmereUI = {
    export = function()
      local E = rawget(_G, "EllesmereUI")
      if type(E) ~= "table" or type(E.ExportProfile) ~= "function" then return nil end
      local name = type(E.GetActiveProfileName) == "function" and E.GetActiveProfileName() or "Default"
      return E.ExportProfile(name)
    end,
    apply = function(str, done)
      local E = rawget(_G, "EllesmereUI")
      if type(E) ~= "table" then return false end
      if type(E.ImportProfileInteractive) == "function" then
        local ok, why = E.ImportProfileInteractive({ importString = str, profileName = ns.KIT_LAYOUT_PROFILE,
          source = "UW Guild", callback = function(accepted) done(accepted == true, true) end })
        if ok then say("EllesmereUI's import screen is open: check what to bring in, then press Import.") end
        return ok, why
      elseif type(E.ImportProfile) == "function" then
        local ok, why = E.ImportProfile(str, ns.KIT_LAYOUT_PROFILE)
        if ok then done(true, true) end
        return ok, why
      end
      return false
    end,
  },
  Details = {
    export = function()
      local D = rawget(_G, "Details")
      if type(D) ~= "table" or type(D.ExportCurrentProfile) ~= "function" then return nil end
      return D:ExportCurrentProfile()
    end,
    apply = function(str, done)
      local D = rawget(_G, "Details")
      if type(D) ~= "table" or type(D.ImportProfile) ~= "function" then return false end
      -- (string, profile name, run its code: never, from Details' own import window: no, overwrite our profile: yes)
      local ok = D:ImportProfile(str, ns.KIT_LAYOUT_PROFILE, false, false, true)
      if ok then done(true, false) end
      return ok == true
    end,
  },
}
ns.KitImporters = importers

local LPREFIX = "UWG1L" -- its own prefix: the game throttles each prefix, so a layout never slows guild messages
local PIECE = 200
ns.LAYOUT_GAP, ns.LAYOUT_STREAMS, ns.LAYOUT_WAIT = 1.1, 2, 20

local function sendL(msg, target)
  if not ns.canSend() then return false end
  local ok, result = pcall(C_ChatInfo.SendAddonMessage, LPREFIX, msg, "WHISPER", target)
  return ok and (result == nil or result == true or result == 0)
end

-- Officer: share. The layout lives in UW_GuildDB.layouts (account-wide) and its stamp in the kit (l=), so it reaches
-- members with the kit; the string itself goes only to a member who asks.
local layoutCmd = {}
layoutCmd.share = function()
  -- Without a guild there's nobody to share with and no rank to check (Louis, 5 Nov: he tried before making it).
  if not IsInGuild() then say("Make or join the guild first: the layout goes to your guildmates. Then try again.") return end
  if not isOfficer() then say("Only officers can share the guild layout.") return end
  if InCombatLockdown() then say("After combat, please.") return end
  local kit, now, shared = current(), serverNow(), {}
  for _, addon in ipairs(ns.KIT_LAYOUT_ADDONS) do
    if ns.isLoaded(addon) then
      local ok, str = pcall(importers[addon].export)
      if ok and validText(str, ns.KIT_LAYOUT_MAX) then
        local l = { at = now, by = (me():gsub("[%c|\t]", "")):sub(1, LIMITS.by), len = #str, sum = ns.Adler32(str) }
        UW_GuildDB.layouts[addon] = { at = l.at, by = l.by, len = l.len, sum = l.sum, str = str }
        local keep = {}
        for _, x in ipairs(kit.layouts) do if x.addon ~= addon then keep[#keep + 1] = x end end
        keep[#keep + 1] = { addon = addon, at = l.at, by = l.by, len = l.len, sum = l.sum }
        kit.layouts = keep
        shared[#shared + 1] = ("%s (%d KB)"):format(addon, math.ceil(#str / 1024))
      else
        say(("Couldn't export %s's layout%s."):format(addon, ok and str and " (too big, or characters it can't send)" or ""))
      end
    end
  end
  if #shared == 0 then say("Nothing shared: EllesmereUI or Details has to be loaded.") return end
  if commit(kit, kit.custom, "Shared your layout: " .. table.concat(shared, ", ") .. ".") then
    say("Members type /uw kit layout to use it. /reload now so the layout is saved on this PC.")
  end
end
layoutCmd.unshare = function()
  if not isOfficer() then say("Only officers can change the guild layout.") return end
  local kit = current()
  if #kit.layouts == 0 then say("No guild layout is shared.") return end
  kit.layouts = {}
  commit(kit, kit.custom, "Stopped sharing the guild layout.")
end

-- Officer: serve a member's ask (LQ) from the layout saved here, two members at a time, one piece every 1.1 s.
local streams, turn, pumping, asks = {}, 0, false, {}
local function pump()
  if #streams == 0 then pumping = false return end
  if not ns.canSend() then C_Timer.After(2, pump) return end
  turn = turn % #streams + 1
  local s = streams[turn]
  local piece = s.str:sub((s.i - 1) * PIECE + 1, s.i * PIECE)
  if sendL(("LP\t%s\t%d\t%d\t%d\t%s"):format(s.addon, s.sum, s.i, s.n, piece), s.target) then
    s.i, s.tries = s.i + 1, 0
    if s.i > s.n then table.remove(streams, turn) end
    C_Timer.After(ns.LAYOUT_GAP, pump)
  else
    s.tries = s.tries + 1
    if s.tries >= 5 then table.remove(streams, turn) end -- the member's wait runs out and they ask someone else
    C_Timer.After(2, pump)
  end
end

local L = {}
L.LQ = function(sender, addon, sum)
  if not isOfficer() or not ns.inRoster(sender) or not LAYOUT_ADDON[addon] then return end
  local l = UW_GuildDB.layouts[addon]
  if not l or l.sum ~= whole(sum) or type(l.str) ~= "string" then sendL("LN\t" .. addon .. "\tnone", sender) return end
  for _, s in ipairs(streams) do if s.target == sender and s.addon == addon then return end end
  -- At most 3 asks per member per 10 min, so nobody can keep an officer's layout lane busy.
  local a = asks[sender]
  if not a or GetTime() - a.since > 600 then a = { since = GetTime(), n = 0 } asks[sender] = a end
  if a.n >= 3 or #streams >= ns.LAYOUT_STREAMS then sendL("LN\t" .. addon .. "\tbusy", sender) return end
  a.n = a.n + 1
  streams[#streams + 1] = { target = sender, addon = addon, str = l.str, sum = l.sum, i = 1,
    n = math.ceil(#l.str / PIECE), tries = 0 }
  if not pumping then pumping = true C_Timer.After(0.5, pump) end
end

-- Member: fetch. Ask the officer who shared it first, then each other online officer, until one sends the whole
-- string and it matches the length and checksum the kit carries.
local fetching = {}
local function onlineOfficers(first)
  local out, self = {}, ns.fullName(me())
  for i = 1, GetNumGuildMembers() do
    local full, _, rank, _, _, _, _, _, online = GetGuildRosterInfo(i)
    full = ns.fullName(full)
    if full and online and full ~= self and type(rank) == "number" and rank <= ns.OFFICER_MAX_RANK then
      if ns.shortName(full) == first then table.insert(out, 1, full) else out[#out + 1] = full end
    end
  end
  return out
end

local nextOfficer
local function watch(addon, f)
  C_Timer.After(5, function()
    if fetching[addon] ~= f then return end
    if GetTime() - f.last > ns.LAYOUT_WAIT then nextOfficer(addon) else watch(addon, f) end
  end)
end
nextOfficer = function(addon)
  local f = fetching[addon]
  if not f then return end
  f.k = f.k + 1
  f.from, f.parts, f.got, f.last, f.shown = f.officers[f.k], {}, 0, GetTime(), 0
  if not f.from then
    fetching[addon] = nil
    say(("Couldn't get the %s layout: no officer online has it right now. Try again later."):format(addon))
    f.done(false)
    return
  end
  if not sendL(("LQ\t%s\t%d"):format(addon, f.want.sum), f.from) then
    C_Timer.After(2, function() if fetching[addon] == f then f.k = f.k - 1 nextOfficer(addon) end end)
    return
  end
  watch(addon, f)
end

local function fetch(l, done)
  local cached = UW_GuildDB.layouts[l.addon]
  if cached and cached.sum == l.sum and type(cached.str) == "string" then done(true) return end
  if fetching[l.addon] then say("Already downloading the " .. l.addon .. " layout.") return end
  local officers = onlineOfficers(l.by)
  local f = { want = l, officers = officers, k = 0, done = done }
  fetching[l.addon] = f
  say(("Getting the %s layout (%d KB) from %s. About %d s."):format(l.addon, math.ceil(l.len / 1024),
    officers[1] and ns.shortName(officers[1]) or "an officer", math.ceil(l.len / PIECE * ns.LAYOUT_GAP)))
  nextOfficer(l.addon)
end

L.LP = function(sender, addon, sum, i, n, piece)
  local f = fetching[addon]
  if not f or sender ~= f.from or whole(sum) ~= f.want.sum or type(piece) ~= "string" then return end
  i, n = whole(i), whole(n)
  if not (i and n) or n ~= math.ceil(f.want.len / PIECE) or i < 1 or i > n then nextOfficer(addon) return end
  f.last = GetTime()
  if not f.parts[i] then f.parts[i], f.got = piece, f.got + 1 end
  local pct = math.floor(f.got * 100 / n)
  if pct >= f.shown + 25 and f.got < n then f.shown = pct - pct % 25 say(("%s layout: %d%%"):format(addon, f.shown)) end
  if f.got < n then return end
  local str = table.concat(f.parts)
  if #str ~= f.want.len or ns.Adler32(str) ~= f.want.sum then nextOfficer(addon) return end
  fetching[addon] = nil
  UW_GuildDB.layouts[addon] = { at = f.want.at, by = f.want.by, len = f.want.len, sum = f.want.sum, str = str }
  f.done(true)
end
L.LN = function(sender, addon)
  local f = fetching[addon]
  if f and sender == f.from then nextOfficer(addon) end
end

local lf = CreateFrame("Frame")
lf:RegisterEvent("CHAT_MSG_ADDON")
lf:SetScript("OnEvent", function(_, _, prefix, text, channel, sender)
  if prefix ~= LPREFIX or channel ~= "WHISPER" or type(text) ~= "string" then return end
  sender = ns.fullName(sender)
  if not sender or ns.rankOf[sender] == nil then return end -- guildmates only
  local fields = { strsplit("\t", text) }
  local h = L[fields[1]]
  if h then ns.protect(h, sender, select(2, unpack(fields))) end
end)

-- Member: /uw kit layout. One addon at a time: fetch if needed, ask, then hand it to that addon's own import.
local function applyOne(list, k, state)
  local l = list[k]
  if not l then
    if state.reload then
      askReload(table.concat(state.reload, " and ") .. (#state.reload == 1 and " now uses" or " now use") .. " the guild layout.")
    end
    return
  end
  local function after() applyOne(list, k + 1, state) end
  if not ns.isLoaded(l.addon) then
    say(("Guild layout for %s: you don't have %s on, so it's skipped."):format(l.addon, l.addon))
    return after()
  end
  fetch(l, function(got)
    if not got then return after() end
    confirm(("Use the guild's %s layout, shared by %s? It's added as the profile \"%s\"; your own stays, and you can switch back in %s's options.")
      :format(l.addon, l.by, ns.KIT_LAYOUT_PROFILE, l.addon), function()
        if InCombatLockdown() then say("After combat, please: /uw kit layout") return end
        local called, ok, why = pcall(importers[l.addon].apply, UW_GuildDB.layouts[l.addon].str, function(done, reload)
          if not done then say(l.addon .. ": import cancelled.") return after() end
          UW_GuildCharDB.layoutApplied = UW_GuildCharDB.layoutApplied or {}
          UW_GuildCharDB.layoutApplied[l.addon] = l.sum
          if reload then -- asked once, after the last addon
            state.reload = state.reload or {}
            table.insert(state.reload, l.addon)
          else
            say(l.addon .. " now uses the guild layout.")
          end
          after()
        end)
        if not called or not ok then
          local reason = not called and ok or why
          say(("%s didn't take the layout%s."):format(l.addon, type(reason) == "string" and (": " .. reason) or ""))
          after()
        end
      end, after)
  end)
end

cmd.layout = function(args)
  local sub = strtrim(args or ""):lower()
  if layoutCmd[sub] then layoutCmd[sub]() return end
  local list = ns.KIT.layouts or {}
  if #list == 0 then
    say(isOfficer() and "No guild layout yet. Set up yours (raid frames, bars, meter), then /uw kit layout share."
      or "No guild layout has been shared yet.")
    return
  end
  applyOne(list, 1, {})
end

-- /uw kit nudge -----------------------------------------------------------------
-- An officer asks online members to check their kit. Each client decides for itself: a member with nothing to fix
-- sees nothing, so the nudge never adds chat for the guild at large. Once per 10 min per officer.
local nudged, lastNudge = {}, 0
cmd.nudge = function(args)
  if not isOfficer() then say("Only officers can nudge.") return end
  if GetTime() - lastNudge < 600 then say("You nudged in the last 10 minutes. /uw audit shows who still has something to fix.") return end
  local target = strtrim(args or "")
  if target ~= "" and not ns.inRoster(target) then say(target .. " isn't in the guild roster.") return end
  lastNudge = GetTime()
  ns.officerSend("KN", target ~= "" and "WHISPER" or "GUILD", target ~= "" and target or nil)
  say(target ~= "" and ("Nudged " .. target .. ".")
    or "Nudged: online members with something missing, a duplicate or a new guild layout get a reminder.")
end

local function needsNudge()
  local missReq, _, conflicts = ns.CheckKit()
  local off, on = ns.KitFixPlan()
  local applied, due = UW_GuildCharDB.layoutApplied or {}, false
  for _, l in ipairs(ns.KIT.layouts or {}) do
    if ns.isLoaded(l.addon) and applied[l.addon] ~= l.sum then due = true end
  end
  return #missReq + #conflicts + #off + #on > 0 or due
end
ns.handlers.KN = function(sender, channel)
  if (channel ~= "GUILD" and channel ~= "WHISPER") or not ns.isOfficer(sender) then return end
  if nudged[sender] and GetTime() - nudged[sender] < 600 then return end
  nudged[sender] = GetTime()
  if not needsNudge() then return end
  say(("%s asks everyone to check their addon kit. Here's yours:"):format(ns.shortName(sender)))
  ns.printKit(false)
end
