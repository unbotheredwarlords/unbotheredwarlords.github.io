-- Quest guide (Louis, 8 Nov 2026: "a UI arrow that solves the wandering merchant problem visually for peoples' quests
-- like restedxp").
--
-- The game's own map pin and on-screen marker (with yards; Attune and RareScanner use it on Forever too) points at
-- the nearest thing your tracked quests still need, read from Questie:
--   * what an unfinished objective needs (kill, loot, talk, use), or, once a quest is ready, who takes it in;
--   * an NPC with a patrol route in Questie's data: the nearest spot on its route. Standing on the route, a spot
--     about 80 yards further along it, so the marker walks the route until the NPC shows;
--   * a spawn spot you reach with nothing left there is skipped for 3 minutes, so the marker moves to the next one.
-- No addon can see where an NPC is until its nameplate shows (about 40 yards). When a guided NPC that wanders, or a
-- friendly one, shows up, a line on screen says so. /uw guide skip passes over a step that's bugged on the server.
-- Blizzard's own quest focus (clicking a quest to track it) picks the quest. A pin you place yourself wins: the guide
-- steps aside until /uw guide on. Never in combat or instances. /uw guide off clears the marker and stops.
-- Questie's quest objects and ZoneDB aren't a public interface: every read is protected, and if Questie changes them
-- the guide stops quietly (UW_GuildDB.guideProbe says why).
local _, ns = ...
local say = ns.say

ns.GUIDE_EVERY = 1        -- seconds between looks
ns.GUIDE_AHEAD = 80       -- yards ahead along a route, once on it
ns.GUIDE_ON_ROUTE = 25    -- yards from a route's nearest point that count as on it
ns.GUIDE_REACHED = 20     -- yards: a spawn spot counts as reached
ns.GUIDE_SKIP = 180       -- seconds a reached spawn spot is skipped
ns.GUIDE_MOVE = 8         -- yards the target moves before the pin is set again
ns.GUIDE_REBUILD = 3      -- seconds between rereads after the quest log changes, at least
ns.GUIDE_REREAD = 30      -- seconds between rereads anyway
ns.GUIDE_FOUND_AGAIN = 120 -- seconds before the same NPC is announced again
ns.GUIDE_MAX_POINTS = 400 -- spawn spots read per NPC

-- call() returns up to three values. Wrap it in parentheses where only the first counts: tonumber(call(f)) with a
-- second return reads it as a number base (Louis's client, 8 Nov 15:18: GetNumQuestLogEntries returns entries and
-- quests, so tonumber(entries, 1) threw "base out of range").
local function call(fn, ...)
  if type(fn) ~= "function" and not (type(fn) == "table" and getmetatable(fn)) then return nil end
  local ok, a, b, c = pcall(fn, ...)
  if ok then return a, b, c end
end
local function g(name) return rawget(_G, name) end
-- On for everyone (Louis, 9 Nov 2026 04:29: every feature starts on, with a clear opt-out). It was officers-first
-- from 8 Nov. Whoever switched it with /uw guide on or off keeps their choice (UW_GuildDB.guide).
local function on()
  if not UW_GuildDB then return false end
  if UW_GuildDB.guide ~= nil then return UW_GuildDB.guide == true end
  return true
end
ns.GuideOn = on
local function now() return (g("GetTime") or time)() end

local function probe(k, v)
  if not UW_GuildDB then return end
  local p = UW_GuildDB.guideProbe or {}
  UW_GuildDB.guideProbe = p
  p[k] = v
  p.at = time()
end

-- Questie's pieces, or nil: its quest objects, NPC and object reader, zone IDs and map maths.
local function questie()
  local loader = g("QuestieLoader")
  if type(loader) ~= "table" then return nil end
  local qdb = call(loader.ImportModule, loader, "QuestieDB")
  local zdb = call(loader.ImportModule, loader, "ZoneDB")
  local hbd = call(g("LibStub"), "HereBeDragonsQuestie-2.0", true)
  if type(qdb) ~= "table" or type(zdb) ~= "table" or type(hbd) ~= "table" then return nil end
  if type(qdb.GetQuest) ~= "function" or type(hbd.GetWorldCoordinatesFromZone) ~= "function" then return nil end
  return { db = qdb, zone = zdb, hbd = hbd }
end
ns.GuideQuestie = questie

local function dist(ax, ay, bx, by) return math.sqrt((ax - bx) ^ 2 + (ay - by) ^ 2) end

-- A spot in Questie's percentages on an area, as world yards plus the pin's map and 0-1 coordinates.
local function spot(Q, areaId, xy)
  if type(xy) ~= "table" or type(xy[1]) ~= "number" or type(xy[2]) ~= "number" or xy[1] < 0 or xy[2] < 0 then return end
  local map = call(Q.zone.GetUiMapIdByAreaId, Q.zone, areaId)
  if not map then return end
  local wx, wy, inst = call(Q.hbd.GetWorldCoordinatesFromZone, Q.hbd, xy[1] / 100, xy[2] / 100, map)
  if not wx then return end
  return { wx = wx, wy = wy, inst = inst, map = map, x = xy[1] / 100, y = xy[2] / 100 }
end

-- One thing to go to: its spawn spots and its patrol routes (lists of spots).
local function entity(Q, key, name, quest, spawns, routes, friendly)
  local e = { key = key, name = name, quest = quest, spots = {}, routes = {}, friendly = friendly }
  for areaId, list in pairs(type(spawns) == "table" and spawns or {}) do
    for _, xy in pairs(type(list) == "table" and list or {}) do
      if #e.spots >= ns.GUIDE_MAX_POINTS then break end
      local p = spot(Q, areaId, xy)
      if p then
        e.spots[#e.spots + 1] = p
        p.k = key .. ":" .. #e.spots
      end
    end
  end
  for areaId, paths in pairs(type(routes) == "table" and routes or {}) do
    for _, path in pairs(type(paths) == "table" and paths or {}) do
      local pts = {}
      for _, xy in ipairs(type(path) == "table" and path or {}) do pts[#pts + 1] = spot(Q, areaId, xy) end
      if #pts >= 2 then
        pts.closed = dist(pts[1].wx, pts[1].wy, pts[#pts].wx, pts[#pts].wy) < 15
        e.routes[#e.routes + 1] = pts
      end
    end
  end
  if #e.spots > 0 or #e.routes > 0 then return e end
end

-- The game's own quest data, for a quest Questie has nothing on (Forever's own quests, or gaps in Questie's data; Louis,
-- 8 Nov 13:35: "use ALL available data"): the next waypoint Blizzard's map shows for it, else its spot on your map.
local function isSecretValue(v) local s = g("issecretvalue") return s and s(v) or false end
local function plainNum(v) local s = g("issecretvalue") return type(v) == "number" and not (s and s(v)) and v or nil end
local function questsOnMap()
  local log, map = g("C_QuestLog"), call(g("C_Map") and g("C_Map").GetBestMapForUnit, "player")
  local out = {}
  map = plainNum(map)
  if not (map and type(log) == "table") then return out end
  for _, q in ipairs(type(call(log.GetQuestsOnMap, map)) == "table" and call(log.GetQuestsOnMap, map) or {}) do
    local id = type(q) == "table" and plainNum(q.questID)
    if id then out[id] = { map = map, x = plainNum(q.x), y = plainNum(q.y) } end
  end
  return out
end
local function gameEntity(Q, id, title, onMap)
  local log = g("C_QuestLog")
  if type(log) ~= "table" then return end
  local map, x, y = call(log.GetNextWaypoint, id)
  map, x, y = plainNum(map), plainNum(x), plainNum(y)
  if not (map and x and y) and onMap[id] then map, x, y = onMap[id].map, onMap[id].x, onMap[id].y end
  if not (map and x and y) or x <= 0 or y <= 0 then return end
  local wx, wy, inst = call(Q.hbd.GetWorldCoordinatesFromZone, Q.hbd, x, y, map)
  if not wx then return end
  local text = call(log.GetNextWaypointText, id)
  local s = g("issecretvalue")
  if type(text) ~= "string" or text == "" or (s and s(text)) then text = title end
  local key = "q_" .. id
  return { key = key, name = text, quest = title, routes = {}, friendly = true,
    spots = { { wx = wx, wy = wy, inst = inst, map = map, x = x, y = y, k = key .. ":1" } } }
end

local function sameTitle(a, b)
  if type(a) ~= "string" or type(b) ~= "string" then return true end -- nothing to compare: trust Questie
  local function norm(t) return (t:lower():gsub("[^%w]", "")) end
  return norm(a) == norm(b)
end

local function unfinished(o) return type(o) == "table" and not (o.Needed and o.Needed == o.Collected) end

-- Everything a quest still needs, from Questie's quest object.
local function questNeeds(Q, quest, title, out)
  local complete = call(quest.IsComplete, quest)
  if complete == 1 or (complete ~= -1 and quest.isComplete) then
    local fin = type(quest.Finisher) == "table" and quest.Finisher or {}
    for _, id in pairs(fin.NPC or {}) do
      local npc = call(Q.db.GetNPC, Q.db, id)
      if type(npc) == "table" then
        out[#out + 1] = entity(Q, "m_" .. id, npc.name, title, npc.spawns, npc.waypoints, true)
      end
    end
    for _, id in pairs(fin.GameObject or {}) do
      local obj = call(Q.db.GetObject, Q.db, id)
      if type(obj) == "table" then out[#out + 1] = entity(Q, "o_" .. id, obj.name, title, obj.spawns, nil, true) end
    end
    return
  end
  for _, list in ipairs({ quest.Objectives or {}, quest.SpecialObjectives or {} }) do
    for _, o in pairs(list) do
      if unfinished(o) then
        for id, s in pairs(type(o.spawnList) == "table" and o.spawnList or {}) do
          if type(s) == "table" then
            local key = (s.TooltipKey or ((o.Type == "object" and "o_" or "m_") .. tostring(s.Id or id)))
            out[#out + 1] = entity(Q, key, s.Name, title, s.Spawns, s.Waypoints, not s.Hostile)
          end
        end
      end
    end
  end
end

-- Quests Questie's tracker shows (all of them when it tracks none), or only the one Blizzard's focus picked.
-- Quests far above your level aren't your next step (Louis's live test, 8 Nov 13:26: a level-60 attunement quest in
-- the log sent a level-20 druid across Orgrimmar), so they're left out unless you focus one yourself.
ns.GUIDE_LEVELS_ABOVE = 3
local focus
local function trackedIds()
  local log, ids, all = g("C_QuestLog"), {}, {}
  local mine = tonumber((call(g("UnitLevel"), "player")))
  for i = 1, (log and tonumber((call(log.GetNumQuestLogEntries))) or 0) do
    local info = call(log.GetInfo, i)
    if type(info) == "table" and not info.isHeader and info.questID then
      local q = { info.questID, info.title }
      all[#all + 1] = q
      local lvl = tonumber(info.level)
      if not (mine and lvl and lvl > mine + ns.GUIDE_LEVELS_ABOVE) then ids[#ids + 1] = q end
    end
  end
  if focus then
    for _, q in ipairs(all) do if q[1] == focus then return { q } end end
    focus = nil
  end
  local Questie = g("Questie")
  local char = type(Questie) == "table" and type(Questie.db) == "table" and Questie.db.char or nil
  local prof = type(Questie) == "table" and type(Questie.db) == "table" and Questie.db.profile or nil
  if type(char) ~= "table" then return ids end
  local out = {}
  for _, q in ipairs(ids) do
    local tracked
    if prof and prof.autoTrackQuests then tracked = not (char.AutoUntrackedQuests or {})[q[1]]
    else tracked = (char.TrackedQuests or {})[q[1]] end
    if tracked then out[#out + 1] = q end
  end
  return #out > 0 and out or ids
end

local needs, builtAt, dirty = nil, 0, true
function ns.GuideBuild()
  local Q = questie()
  probe("questie", Q ~= nil)
  if not Q then needs = nil return nil end
  local out, ids = {}, trackedIds()
  probe("quests", #ids)
  local onMap, fromGame, mismatched = questsOnMap(), 0, 0
  local mine = tonumber((call(g("UnitLevel"), "player")))
  for _, q in ipairs(ids) do
    local quest, had = call(Q.db.GetQuest, q[1]), #out
    -- Forever reuses quest IDs: Questie's quest under this ID can be a different quest (Louis's live test, 8 Nov 13:35:
    -- "Unending Torment" in the log, Questie's quest of that ID sends you to Rekkul). Only a matching name is trusted.
    if type(quest) == "table" and not sameTitle(quest.name, q[2]) then quest = nil; mismatched = mismatched + 1 end
    local need = type(quest) == "table" and tonumber(quest.requiredLevel)
    if need and mine and need > mine + ns.GUIDE_LEVELS_ABOVE and q[1] ~= focus then quest = false end
    if type(quest) == "table" then
      local ok = pcall(questNeeds, Q, quest, q[2] or quest.name, out)
      if not ok then probe("readFailed", q[1]) end
      for k = had + 1, #out do
        local e = out[k]
        e.qid, e.src, e.qn, e.rl, e.ql = q[1], "questie", quest.name, quest.requiredLevel, quest.level
      end
    end
    if #out == had and quest ~= false then
      local e = gameEntity(Q, q[1], q[2] or (type(quest) == "table" and quest.name) or "a quest", onMap)
      if e then e.qid, e.src = q[1], "game"; out[#out + 1] = e; fromGame = fromGame + 1 end
    end
  end
  probe("fromGame", fromGame)
  probe("mismatched", mismatched)
  -- Reward XP per quest, for picking by value (above); a quest with none counts as the middle of the rest.
  local QXP = call(g("QuestieLoader") and g("QuestieLoader").ImportModule, g("QuestieLoader"), "QuestXP")
  local known = {}
  for _, e in ipairs(out) do
    if e.qid then
      local xp = type(QXP) == "table" and plainNum(call(QXP.GetQuestLogRewardXP, QXP, e.qid))
      xp = xp or plainNum(call(g("GetQuestLogRewardXP"), e.qid))
      e.xp = xp and xp > 0 and xp or nil
      if e.xp then known[#known + 1] = e.xp end
    end
  end
  table.sort(known)
  local middle = known[math.floor((#known + 1) / 2)] or 1
  for _, e in ipairs(out) do if not e.xp then e.xp = middle end end
  probe("xpKnown", #known)
  -- Steps the player skipped (/uw guide skip: a step that's bugged on the server), per NPC and quest, kept until unskip.
  local skip = UW_GuildCharDB and UW_GuildCharDB.guideSkip
  if type(skip) == "table" and next(skip) then
    local kept = {}
    for _, e in ipairs(out) do if not skip[e.key .. "|" .. tostring(e.quest)] then kept[#kept + 1] = e end end
    out = kept
  end
  needs, builtAt, dirty = out, now(), false
  probe("needs", #out)
  return out
end

-- Where to go: the nearest need in this world, and the spot to aim at. Pure maths on what GuideBuild read.
local skipped, routeDir = {}, {}
-- Best value, not just nearest (Louis, 8 Nov 14:00: "getting the most out of leveling"): a new quest is picked by
-- reward XP per yard walked (plus a fixed cost for the stop itself), from Questie's XP data or the game's. A quest with
-- no XP data counts as the middle of the rest, so with no data at all this is simply the nearest.
ns.GUIDE_STOP_COST = 100 -- yards: what a stop costs beyond the walk (talking, fighting, looting)
local function cost(e, d) return (d + ns.GUIDE_STOP_COST) / (e.xp or 1) end
local function nearest(px, py, inst, list)
  local t, best = nil, math.huge
  for _, e in ipairs(list or needs or {}) do
    for ri, pts in ipairs(e.routes) do
      local ni, nd = nil, math.huge
      for i, p in ipairs(pts) do
        if p.inst == inst then
          local d = dist(px, py, p.wx, p.wy)
          if d < nd then ni, nd = i, d end
        end
      end
      if ni and cost(e, nd) < best then
        best = cost(e, nd)
        local j, rkey = ni, e.key .. "#" .. ri
        if nd <= ns.GUIDE_ON_ROUTE then
          local dir, walked, steps = routeDir[rkey] or 1, 0, 0
          while walked < ns.GUIDE_AHEAD and steps < #pts * 2 do
            local nj = j + dir
            if nj < 1 or nj > #pts then
              if pts.closed then nj = nj < 1 and #pts or 1
              else dir = -dir; nj = j + dir end
            end
            walked = walked + dist(pts[j].wx, pts[j].wy, pts[nj].wx, pts[nj].wy)
            j, steps = nj, steps + 1
          end
          routeDir[rkey] = dir
        end
        t = { e = e, p = pts[j], d = nd, route = true }
      end
    end
    -- Spawn spots: squared distances and keys made at build time, so a look allocates nothing (CPU light).
    local t0, many, reach2 = now(), #e.spots > 1, ns.GUIDE_REACHED * ns.GUIDE_REACHED
    local bp, bd, fp, fd, any = nil, math.huge, nil, math.huge, false
    for _, p in ipairs(e.spots) do
      if p.inst == inst then
        any = true
        local d2 = (px - p.wx) * (px - p.wx) + (py - p.wy) * (py - p.wy)
        if d2 < fd then fp, fd = p, d2 end
        if many and d2 <= reach2 then skipped[p.k] = t0 + ns.GUIDE_SKIP end
        local until_ = skipped[p.k]
        if (not until_ or until_ < t0) and d2 < bd then bp, bd = p, d2 end
      end
    end
    if any and not bp then -- every spot visited: start over
      for _, p in ipairs(e.spots) do skipped[p.k] = nil end
      bp, bd = fp, fd
    end
    if bp then
      bd = math.sqrt(bd)
      if cost(e, bd) < best then best, t = cost(e, bd), { e = e, p = bp, d = bd } end
    end
  end
  return t
end

-- One quest at a time (Louis, 8 Nov 13:35, the way RestedXP does it): once the guide picks a quest it stays on it until
-- that quest has nothing left here, instead of jumping to whatever else is nearest. Focus or /uw guide skip moves on.
local stick, sticky = nil, {}
function ns.GuideTarget(px, py, inst, list)
  list = list or needs or {}
  if stick then
    local n = 0
    for _, e in ipairs(list) do if e.quest == stick then n = n + 1; sticky[n] = e end end
    for k = n + 1, #sticky do sticky[k] = nil end
    local t = n > 0 and nearest(px, py, inst, sticky)
    if t then return t end
  end
  local t = nearest(px, py, inst, list)
  stick = t and t.e.quest or nil
  return t
end
function ns.GuideUnstick() stick = nil end

-- The arrow (Louis's live test, 8 Nov 05:25: Forever's client keeps the map pin but shows no on-screen marker for
-- it, so the guide draws its own, the way TomTom and RestedXP do). One small frame: the game's own minimap arrow
-- art turned toward the target, the name and yards under it in EllesmereUI's font. Light on purpose: it turns
-- at most 20 times a second, only while shown, allocates nothing per frame, and hides when there's nothing to
-- guide to, in instances, and while the pin is yours. Shift-drag moves it. /uw guide arrow: on, off, small,
-- large, faint (half see-through, for a calmer screen), bright. Saved in UW_GuildDB.guideArrow.
local current, paused, selfTrack, toldPause, started, claimed = nil, false, false, false, false, false
ns.GUIDE_ARROW_HZ = 20
ns.GUIDE_ARROW_SIZES = { small = 36, normal = 52, large = 72 }
local arrowFrame, arrowTurning
local function arrowCfg()
  local c = UW_GuildDB and UW_GuildDB.guideArrow
  if type(c) ~= "table" then c = {} if UW_GuildDB then UW_GuildDB.guideArrow = c end end
  return c
end
local function arrowShown() return arrowCfg().off ~= true end
local debugOn = false
local function arrowLog(k, v)
  if not UW_GuildDB then return end
  local p = UW_GuildDB.guideProbe or {}
  UW_GuildDB.guideProbe = p
  p.arrow = p.arrow or {}
  if p.arrow[k] == v then return end
  p.arrow[k] = v
  p.arrow.at = time()
  if debugOn then say(("UW guide debug: arrow %s = %s"):format(k, tostring(v))) end
end

local function styleArrow()
  local f = arrowFrame
  if not f then return end
  local c = arrowCfg()
  local size = ns.GUIDE_ARROW_SIZES[c.size or "normal"] or ns.GUIDE_ARROW_SIZES.normal
  f:SetSize(size, size)
  f:SetAlpha(c.faint and 0.5 or 0.9)
end

-- Our own 128 px arrow (Media\arrow.tga: white body, dark rim and soft shadow, tinted gold here), smoothed while it
-- turns; the game's 32 px minimap arrow if ours isn't loaded (a new media file needs a WoW restart), then a square.
local ART = "Interface\\AddOns\\UW_Guild\\Media\\arrow"
local function arrowArt(tex)
  local ok = tex:SetTexture(ART, nil, nil, "TRILINEAR")
  local which = "uw"
  if ok == false then ok = tex:SetTexture("Interface\\Minimap\\MinimapArrow"); which = "minimap" end
  if ok == false then tex:SetColorTexture(1, 0.82, 0, 0.9); which = "square" end
  if tex.SetSnapToPixelGrid then call(tex.SetSnapToPixelGrid, tex, false) end
  if tex.SetTexelSnappingBias then call(tex.SetTexelSnappingBias, tex, 0) end
  tex:SetVertexColor(1, 0.82, 0)
  arrowLog("art", which)
end

local function buildArrow()
  if arrowFrame or not CreateFrame then return arrowFrame end
  local f = CreateFrame("Frame", "UW_GuideArrow", g("UIParent"))
  f:SetFrameStrata("MEDIUM")
  f:SetClampedToScreen(true)
  local c = arrowCfg()
  f:SetPoint(c.point or "TOP", g("UIParent"), c.point or "TOP", c.x or 0, c.y or -150)
  f:SetMovable(true)
  f:EnableMouse(false) -- clicks pass through; Shift held turns dragging on (OnUpdate below)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", function(self) if call(g("IsShiftKeyDown")) then self:StartMoving() end end)
  f:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local point, _, _, x, y = self:GetPoint(1)
    local cfg = arrowCfg()
    cfg.point, cfg.x, cfg.y = point, x and math.floor(x + 0.5), y and math.floor(y + 0.5)
  end)
  f.tex = f:CreateTexture(nil, "ARTWORK")
  f.tex:SetAllPoints()
  arrowArt(f.tex)
  f.label = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  f.label:SetPoint("TOP", f, "BOTTOM", 0, -2)
  ns.Skin("Font", f.label)
  -- The quest it's for, under the name (Louis, 8 Nov 13:26: an NPC name alone didn't say which quest it was).
  f.quest = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  f.quest:SetPoint("TOP", f.label, "BOTTOM", 0, -1)
  ns.Skin("Font", f.quest)
  f.elapsed, f.lastYards, f.lastName = 0, -1, nil
  f:Hide()
  arrowFrame = f
  styleArrow()
  return f
end

-- Why the arrow last hid or showed, kept in UW_GuildDB.guideProbe.arrow (only when it changes, so it costs nothing
-- per frame), and said in chat while /uw guide test has debug on.
local function hideBecause(f, reason)
  f:Hide()
  arrowLog("hidden", reason)
end
local function isSecret(v) local s = g("issecretvalue") return s and s(v) or false end

-- One arrow on screen (Louis, 13 Nov 2026: ForeverWowCraft in the kit, "no elements can EVER interfere, overlap").
-- ForeverWowCraft's arrow (its Make button points it at a trainer, vendor or anvil: TOP -120, or TomTom's arrow when
-- TomTom is loaded) and its reload box (TOP -140, 560 x 64) sit where ours does (TOP -150). While one of them shows,
-- ours steps aside: the map pin stays, and the next tick (1 s) brings ours back once theirs has gone. Their frames are
-- only asked whether they're visible (and TomTom's what it says), never changed.
ns.GUIDE_YIELD_TO = { "ForeverWowCraftArrow", "TomTomCrazyArrow", "ForeverWowCraftReload" }
-- TomTom's arrow only while it points at ForeverWowCraft's waypoint: FWC titles it "ForeverWowCraft: <place>" (its
-- Places.lua, ViaTomTom), and TomTom writes the title under the arrow. A /way of the player's own leaves ours as before.
ns.GUIDE_YIELD_TITLE = { TomTomCrazyArrow = "ForeverWowCraft: " }
local function saysTitle(prefix, ...) -- the frame's own text regions (no table made: this runs with the arrow's look)
  for i = 1, select("#", ...) do
    local r = select(i, ...)
    if type(r) == "table" and type(r.GetText) == "function" then
      local ok, text = pcall(r.GetText, r)
      if ok and type(text) == "string" and text:sub(1, #prefix) == prefix then return true end
    end
  end
  return false
end
local function otherArrow()
  for _, name in ipairs(ns.GUIDE_YIELD_TO) do
    local fr = g(name)
    if type(fr) == "table" and type(fr.IsVisible) == "function" then
      local ok, vis = pcall(fr.IsVisible, fr)
      if ok and vis == true then
        local prefix = ns.GUIDE_YIELD_TITLE[name]
        if not prefix then return name end
        if type(fr.GetRegions) == "function" then
          local ok2, says = pcall(function() return saysTitle(prefix, fr:GetRegions()) end)
          if ok2 and says then return name end
        end
      end
    end
  end
  return nil
end
ns.GuideOtherArrow = otherArrow

local function arrowUpdate(f, elapsed)
  f.elapsed = f.elapsed + elapsed
  if f.elapsed < 1 / ns.GUIDE_ARROW_HZ then return end
  f.elapsed = 0
  f:EnableMouse(call(g("IsShiftKeyDown")) and true or false)
  local other = otherArrow()
  if other then hideBecause(f, other) return end
  local t, Q = current, nil
  if t then Q = questie() end
  if not t then hideBecause(f, "no target") return end
  if not Q then hideBecause(f, "no Questie") return end
  local facing = g("GetPlayerFacing") and call(g("GetPlayerFacing"))
  if type(facing) ~= "number" or isSecret(facing) then hideBecause(f, "facing " .. type(facing)) return end
  local px, py, inst = call(Q.hbd.GetPlayerWorldPosition, Q.hbd)
  if not px then hideBecause(f, "no position") return end
  if inst ~= t.p.inst then hideBecause(f, ("world %s, target in %s"):format(tostring(inst), tostring(t.p.inst))) return end
  local angle, yards = call(Q.hbd.GetWorldVector, Q.hbd, inst, px, py, t.p.wx, t.p.wy)
  if not angle then hideBecause(f, "no direction") return end
  arrowLog("hidden", nil)
  f.tex:SetRotation(angle - facing)
  yards = math.floor(yards + 0.5)
  if yards ~= f.lastYards or t.e.name ~= f.lastName then
    f.lastYards, f.lastName = yards, t.e.name
    f.label:SetFormattedText("%s  %d yd", t.e.name or "", yards)
    f.quest:SetText(ns.GuideEventLine and ns.GuideEventLine() or (t.e.key == "meet" and "" or (t.e.quest or "")))
  end
end

-- Shown when the guide has a target and you want the arrow; the frame only exists once it's first needed.
local function showArrow()
  if not current or not arrowShown() or not on() or paused then
    if arrowFrame then arrowFrame:Hide() end
    return
  end
  local other = otherArrow()
  if other then
    if arrowFrame then hideBecause(arrowFrame, other) end
    return
  end
  local f = buildArrow()
  if not f then return end
  if not arrowTurning then arrowTurning = true; f:SetScript("OnUpdate", arrowUpdate) end
  f:Show()
  arrowLog("shown", call(f.IsVisible, f) and "visible" or "not visible")
end
ns.GuideShowArrow = showArrow
function ns.GuideArrowFrame() return arrowFrame end

-- The pin: ours (the last one this guide set, kept per character so a reload still knows it), or someone else's.
local function samePoint(a, b)
  return a and b and a.map == b.map and math.abs(a.x - b.x) < 0.0005 and math.abs(a.y - b.y) < 0.0005
end
local function pinNow()
  local map = g("C_Map")
  local w = map and call(map.GetUserWaypoint)
  if type(w) ~= "table" or not w.position then return nil end
  return { map = w.uiMapID, x = w.position.x, y = w.position.y }
end
local function mine() return UW_GuildCharDB and UW_GuildCharDB.guidePin end

local function clearPin()
  local map = g("C_Map")
  if mine() and samePoint(pinNow(), mine()) and map then call(map.ClearUserWaypoint) end
  if UW_GuildCharDB then UW_GuildCharDB.guidePin = nil end
  current, claimed = nil, false
  if arrowFrame then arrowFrame:Hide() end
end
ns.GuideClear = clearPin

-- The decision log (Core.lua ns.trace) gets each reason the guide couldn't do its job once a session, not every tick.
local missed = {}
local function miss(what, why)
  if missed[what .. why] or not ns.trace then return end
  missed[what .. why] = true
  ns.trace("guide", what, false, why)
end
ns.GuideMiss = miss

local function setPin(t)
  local map, sup, P = g("C_Map"), g("C_SuperTrack"), g("UiMapPoint")
  if not (map and P and type(map.SetUserWaypoint) == "function") then
    probe("pin", "no SetUserWaypoint")
    miss("pin", "this client has no map pins (SetUserWaypoint)")
    return
  end
  local m, x, y = t.p.map, t.p.x, t.p.y
  if map.CanSetUserWaypointOnMap and not call(map.CanSetUserWaypointOnMap, m) then
    -- The pin's map can't take one (a city or a sub-zone): put it on the map you're on, at the same world spot.
    local Q = questie()
    m = call(map.GetBestMapForUnit, "player")
    x, y = nil, nil
    if Q and m then x, y = call(Q.hbd.GetZoneCoordinatesFromWorld, Q.hbd, t.p.wx, t.p.wy, m, true) end
    if not x or not call(map.CanSetUserWaypointOnMap, m) then
      probe("pin", "no map takes it")
      miss("pin", "no map here takes a pin; arrow only")
      current = t
      showArrow()
      return
    end
  end
  local point = call(P.CreateFromCoordinates, m, x, y)
  if not point then miss("pin", "the game couldn't make a map point there") return end
  selfTrack = true
  call(map.SetUserWaypoint, point)
  if sup and not call(sup.IsSuperTrackingUserWaypoint) then call(sup.SetSuperTrackedUserWaypoint, true) end
  selfTrack = false
  UW_GuildCharDB.guidePin = { map = m, x = x, y = y }
  claimed = true
  current = t
  probe("pin", "set")
  showArrow()
  -- First contact: once per character, say what just appeared and how to stop it.
  if not UW_GuildCharDB.guideTold then
    UW_GuildCharDB.guideTold = time()
    say("UW guide set this map pin and arrow for your quest. /uw guide off to stop.")
  end
end

local function busy()
  if call(g("InCombatLockdown")) then return true end
  local inInstance = call(g("IsInInstance"))
  return inInstance and true or false
end

-- Meet point (Louis, 8 Nov 2026: "rally points for people in group ... synced"): /uw meet shares where you stand, or
-- your own map pin, with your group. Every groupmate's guide points there first, until they're within 20 yards, it's
-- 30 minutes old, or the sharer clears it. A party: anyone; a raid: the leader or an assist. Guild-wide (and from
-- Discord) needs nothing new: Shift-click your map pin into chat, and the game's link gives anyone the pin in one click.
ns.GUIDE_MEET_FOR = 1800
ns.GUIDE_MEET_GAP = 5     -- seconds between shares
local meet, sharedAt = nil, 0
-- Milliseconds from the game's profiling clock, or nil where it has none.
local function msNow() local f = g("debugprofilestop") if f then return call(f) end end
local function meetTarget(px, py, inst)
  if not meet then return nil end
  if now() - meet.at > ns.GUIDE_MEET_FOR or meet.p.inst ~= inst then meet = nil return nil end
  local d = dist(px, py, meet.p.wx, meet.p.wy)
  if d <= ns.GUIDE_REACHED then
    meet = nil
    say("You're at the meet point. The guide goes back to your quests.")
    return nil
  end
  return { e = meet.e, p = meet.p, d = d }
end

-- Extras (Louis, 8 Nov 14:02: "yes to all"), each with its own switch: /uw guide trainer|group|events on|off.
local function extraOn(k)
  local x = UW_GuildDB and UW_GuildDB.guideExtras
  return not (type(x) == "table" and x[k] == false)
end
ns.GuideExtraOn = extraOn

-- Trainer reminder: at a level with new class skills (every even level from 4, as on Forever's classic classes), the
-- arrow points once to the nearest class trainer of your faction (Questie's Townsfolk list), until you reach one, a
-- trainer window opens, or 30 minutes pass.
ns.GUIDE_TRAINER_FOR = 1800
local trainer
function ns.GuideLevelUp(level)
  level = tonumber(level)
  if not (level and level >= 4 and level % 2 == 0 and extraOn("trainer") and on()) then return end
  trainer = { at = now(), level = level }
end
local function trainerList(Q)
  local loader = g("QuestieLoader")
  local T = loader and call(loader.ImportModule, loader, "Townsfolk")
  local all = type(T) == "table" and call(T.GetClassTrainers)
  local _, cls = call(g("UnitClass"), "player")
  local ids = type(all) == "table" and type(cls) == "string" and all[cls]
  local out = {}
  for _, id in ipairs(type(ids) == "table" and ids or {}) do
    local npc = call(Q.db.GetNPC, Q.db, id)
    if type(npc) == "table" and npc.friendly ~= false then
      local e = entity(Q, "m_" .. id, npc.name, ("New skills at level %d"):format(trainer.level), npc.spawns, nil, true)
      if e then out[#out + 1] = e end
    end
  end
  return out
end
local function trainerTarget(Q, px, py, inst)
  if not trainer then return nil end
  if now() - trainer.at > ns.GUIDE_TRAINER_FOR or not extraOn("trainer") then trainer = nil return nil end
  trainer.list = trainer.list or trainerList(Q)
  local t = nearest(px, py, inst, trainer.list)
  if not t then return nil end
  if t.d <= ns.GUIDE_REACHED then trainer = nil return nil end
  if not trainer.told then
    trainer.told = true
    say(("Level %d: new skills to learn. The arrow points to %s, your nearest trainer. /uw guide trainer off stops these.")
      :format(trainer.level, t.e.name or "your class trainer"))
  end
  return t
end

-- Dungeon prep (/uw prep wc, QuestChain.lua; Louis, 8 Nov 22:53: "an arrow chain in optimal fashion to get what you
-- can before going in", building on Questie rather than repeating it): Questie already marks each giver with a "!";
-- the guide adds the order. One stop per giver (its spot nearest you), the shortest walk through them found by
-- nearest-first then 2-opt, and the dungeon's entrance (Questie's ZoneDB) last. Reaching a stop moves the arrow on; a
-- later stop you happen to pass counts too. /uw guide on or off ends it, or an hour.
ns.GUIDE_PREP_FOR = 3600
local prep
local function stopOf(e, px, py, inst)
  local best, bd = nil, math.huge
  for _, p in ipairs(e.spots) do
    local d = p.inst == inst and dist(px, py, p.wx, p.wy) or math.huge
    if d < bd or not best then best, bd = p, d end
  end
  return best
end
-- Shortest open walk from (px, py) through every stop, the last one fixed (the entrance): nearest first, then 2-opt.
local function order(px, py, stops, fixedLast)
  local left, out = {}, {}
  for i = 1, #stops - (fixedLast and 1 or 0) do left[#left + 1] = stops[i] end
  local x, y = px, py
  while #left > 0 do
    local bi, bd = 1, math.huge
    for i, s in ipairs(left) do
      local d = dist(x, y, s.p.wx, s.p.wy)
      if d < bd then bi, bd = i, d end
    end
    local s = table.remove(left, bi)
    out[#out + 1] = s
    x, y = s.p.wx, s.p.wy
  end
  if fixedLast then out[#out + 1] = stops[#stops] end
  local function at(i) if i == 0 then return px, py end return out[i].p.wx, out[i].p.wy end
  local last = #out - (fixedLast and 1 or 0)
  local better = true
  while better do
    better = false
    for i = 1, last - 1 do
      for j = i + 1, last do
        local ax, ay = at(i - 1)
        local bx, by = at(i)
        local cx, cy = at(j)
        local before = dist(ax, ay, bx, by)
        local after = dist(ax, ay, cx, cy)
        if j < #out then
          local dx, dy = at(j + 1)
          before, after = before + dist(cx, cy, dx, dy), after + dist(bx, by, dx, dy)
        end
        if after + 0.01 < before then
          for k = 0, math.floor((j - i) / 2) do out[i + k], out[j - k] = out[j - k], out[i + k] end
          better = true
        end
      end
    end
  end
  return out
end
-- Quests a groupmate already carries (Questie's party sync, QuestieComms.remoteQuestLogs): { questId = "Name" }.
local function partyHas()
  local loader = g("QuestieLoader")
  local QC = type(loader) == "table" and call(loader.ImportModule, loader, "QuestieComms")
  local logs = type(QC) == "table" and type(QC.remoteQuestLogs) == "table" and QC.remoteQuestLogs or {}
  local out = {}
  if not call(g("IsInGroup")) then return out end
  for qid, players in pairs(logs) do
    for name in pairs(type(players) == "table" and players or {}) do
      if type(name) == "string" then out[qid] = name:match("^[^-]+") or name break end
    end
  end
  return out
end

-- The route, planned again from where you stand: the quests you can take now (QuestChain.lua reads them from Questie
-- and the game each time), minus givers you've reached and quests a groupmate can share, one stop per giver, the
-- shortest walk, the entrance last. Returns the route and the quests a groupmate has.
local function planPrep(Q, px, py, inst)
  local todo = ns.DungeonPrepTodo and ns.DungeonPrepTodo(prep.d) or {}
  local shared, share = partyHas(), {}
  local stops, byGiver = {}, {}
  prep.giverOf = prep.giverOf or {}
  for _, q in ipairs(ns.DungeonQuests and ns.DungeonQuests(prep.d) or {}) do prep.giverOf[q.id] = q.giverId end
  for _, q in ipairs(todo) do
    if shared[q.id] then
      share[#share + 1] = ("%s has %s"):format(shared[q.id], q.name)
    elseif q.giverId and not prep.visited[q.giverId] then
      local s = byGiver[q.giverId]
      if s then
        s.e.quest = s.e.quest .. ", " .. q.name
      else
        local npc = call(Q.db.GetNPC, Q.db, q.giverId)
        local e = type(npc) == "table" and entity(Q, "m_" .. q.giverId, npc.name, q.name, npc.spawns, nil, true)
        local p = e and stopOf(e, px, py, inst)
        if p then
          s = { e = e, p = p, giver = q.giverId }
          byGiver[q.giverId], stops[#stops + 1] = s, s
        end
      end
    end
  end
  if prep.door then
    local p = stopOf(prep.door, px, py, inst)
    if p then stops[#stops + 1] = { e = prep.door, p = p, door = true } end
  end
  local last = stops[#stops]
  return order(px, py, stops, last and last.door), share
end

local function prepSay(route, share)
  local s = route[1]
  if not s then return end
  local line = s.door and ("Next: %s."):format(s.e.name) or ("Next: %s (%s)."):format(s.e.name or "?", s.e.quest or "")
  if #share > 0 then line = line .. " " .. table.concat(share, "; ") .. ": ask them to share it." end
  if line ~= prep.told then prep.told = line say(line) end
end

-- /uw prep wc (QuestChain.lua): start the route. Planned again whenever a quest is picked up, finished or dropped, you
-- level up, change zone, or your group changes; reaching a giver moves on to the next.
function ns.GuidePrepStart(d)
  local Q = questie()
  if not Q then say("The arrow needs Questie: /uw kit shows where to get it.") return nil end
  local px, py, inst = call(Q.hbd.GetPlayerWorldPosition, Q.hbd)
  if not px then return nil end
  local spawns = {}
  for _, v in ipairs(type(call(Q.zone.GetDungeonLocation, Q.zone, d[2])) == "table"
    and call(Q.zone.GetDungeonLocation, Q.zone, d[2]) or {}) do
    if type(v) == "table" and v[1] then spawns[v[1]] = spawns[v[1]] or {}; table.insert(spawns[v[1]], { v[2], v[3] }) end
  end
  prep = { at = now(), d = d, visited = {}, door = entity(Q, "door:" .. d[2], d[1] .. " entrance", "then in you go",
    spawns, nil, true) }
  local route, share = planPrep(Q, px, py, inst)
  if #route == 0 then prep = nil say(("No spots for the %s quest givers in Questie's data, sorry."):format(d[1])) return nil end
  prep.route, prep.share, prep.planned = route, share, now()
  if not on() then UW_GuildDB.guide = true end
  paused, toldPause, dirty, claimed = false, false, true, true
  ns.GuideTick()
  return route, share
end
function ns.GuidePrepDirty() if prep then prep.dirty = true end end
-- A quest dropped (not finished): its giver goes back on the route.
function ns.GuidePrepRemoved(questId)
  if not (prep and prep.giverOf and questId) then return end
  local L = g("C_QuestLog")
  if L and call(L.IsQuestFlaggedCompleted, questId) then return end
  local giver = prep.giverOf[questId]
  if giver then prep.visited[giver] = nil end
end

local function prepTarget(px, py, inst)
  if not prep then return nil end
  if now() - prep.at > ns.GUIDE_PREP_FOR then prep = nil return nil end
  local Q = questie()
  if not Q then return nil end
  -- Reached a stop (the next or a later one): that giver is done; at the door, the route is done.
  for _, s in ipairs(prep.route) do
    if s.p.inst == inst and dist(px, py, s.p.wx, s.p.wy) <= ns.GUIDE_REACHED then
      if s.door then
        say(("You're at %s. Have a good run!"):format(s.e.name))
        prep = nil
        return nil
      end
      prep.visited[s.giver] = true
      prep.dirty = true
    end
  end
  if prep.dirty and now() - (prep.planned or 0) >= ns.GUIDE_REBUILD then
    prep.route, prep.share = planPrep(Q, px, py, inst)
    prep.dirty, prep.planned = false, now()
    prepSay(prep.route, prep.share)
  end
  local s = prep.route[1]
  if not s then prep = nil return nil end
  if s.p.inst ~= inst then return nil end
  return { e = s.e, p = s.p, d = dist(px, py, s.p.wx, s.p.wy) }
end

-- Group up (Louis, 8 Nov 14:02; agreed with matchmaking): a guildmate online in your zone within 3 levels of you, your
-- buddy first (repeat partners stick), named once in chat. From the guild roster only: no messages sent. At most once
-- an hour, never in a group, combat, an instance or a city; looked for at most every 2 minutes. The zone is yours at
-- that moment (GetRealZoneText) against the roster's, which the game refreshes as guildmates move.
ns.GUIDE_GROUP_LEVELS, ns.GUIDE_GROUP_EVERY, ns.GUIDE_GROUP_LOOK = 3, 3600, 120
local groupLookAt = 0
function ns.GuideGroupUp()
  if not (on() and extraOn("group") and UW_GuildCharDB) or busy() or call(g("IsInGroup")) then return end
  -- Not in a city or inn (Louis's log, 8 Nov 14:15: "questing in Orgrimmar" read oddly): IsResting is the game's own test.
  if call(g("IsResting")) then return end
  if now() - groupLookAt < ns.GUIDE_GROUP_LOOK then return end
  groupLookAt = now()
  if now() - (UW_GuildCharDB.guideGroupAt or 0) < ns.GUIDE_GROUP_EVERY then return end
  local myLevel, zone = tonumber((call(g("UnitLevel"), "player"))), call(g("GetRealZoneText"))
  if not myLevel or type(zone) ~= "string" or zone == "" or isSecretValue(zone) then return end
  local short = function(n) return type(n) == "string" and (call(g("Ambiguate"), n, "none") or n) or nil end
  local me, myGUID = short(ns.me and ns.me()), call(g("UnitGUID"), "player")
  local buddy
  local pairs_ = UW_GuildDB and UW_GuildDB.buddies
  if type(pairs_) == "table" and me then
    for recruit, pair in pairs(pairs_) do
      if type(pair) == "table" then
        if short(recruit) == me then buddy = short(pair.buddy) elseif short(pair.buddy) == me then buddy = short(recruit) end
      end
    end
  end
  local pick, isBuddy
  local roster = g("GetGuildRosterInfo")
  if type(roster) ~= "function" then return end
  for i = 1, tonumber((call(g("GetNumGuildMembers")))) or 0 do
    local ok, full, _, _, level, _, z, _, _, online, _, _, _, _, _, _, _, guid = pcall(roster, i) -- call() keeps 3 returns
    if not ok then break end
    if online and z == zone and type(full) == "string" and not isSecretValue(full) and guid ~= myGUID
      and short(full) ~= me and tonumber(level) and math.abs(tonumber(level) - myLevel) <= ns.GUIDE_GROUP_LEVELS then
      local b = buddy and short(full) == buddy
      if b or not pick then pick, isBuddy = { name = short(full), level = tonumber(level) }, b end
      if b then break end
    end
  end
  if not pick then return end
  UW_GuildCharDB.guideGroupAt = now()
  local line = ("%s%s (level %d) is questing in %s too. /w %s to group up? /uw guide group off stops these.")
    :format(isBuddy and "Your buddy " or "", pick.name, pick.level, zone, pick.name)
  say(line)
  return line
end

-- Guild events: the next Rally or raid night within 15 minutes shows under the arrow (WhatsOn.lua's schedule). The
-- schedule has no place to meet, so this is a line, not a target; WhatsOn's own 10-minute heads-up stays as it is.
ns.GUIDE_EVENT_AHEAD = 900
local KIND_WORD = { rally = "Rally", raid = "Raid night", event = "Guild event" }
function ns.GuideEventLine()
  if not extraOn("events") or not ns.ScheduleNow then return nil end
  local held = ns.ScheduleNow()
  local at = (g("GetServerTime") and call(g("GetServerTime"))) or time()
  for _, ev in ipairs(type(held) == "table" and type(held.ev) == "table" and held.ev or {}) do
    local start = type(ev) == "table" and tonumber(ev[1])
    if start and start > at and start - at <= ns.GUIDE_EVENT_AHEAD then
      local title = type(ev[5]) == "string" and ev[5] ~= "" and ev[5] or KIND_WORD[ev[3]] or "Guild event"
      return ("%s in %d min (/uw events)"):format(title, math.max(1, math.floor((start - at) / 60 + 0.5)))
    end
  end
  return nil
end

function ns.GuideTick()
  if call(g("IsInInstance")) and arrowFrame then arrowFrame:Hide() end
  if not on() or busy() or not UW_GuildCharDB then return end
  ns.protect(ns.GuideNobodyTick) -- dead "!"s: works while the arrow steps aside too
  if paused then return end
  local t0 = msNow()
  local pin = pinNow()
  if not started then
    -- After a login or reload: a pin of ours that the game didn't keep is simply gone, not cleared by you.
    started = true
    if mine() and not pin then UW_GuildCharDB.guidePin = nil end
  end
  -- A pin someone else placed (you, or another addon), before ours or since, or ours cleared: step aside.
  if (mine() and not samePoint(pin, mine())) or (not mine() and pin and not claimed) then
    paused = true
    if UW_GuildCharDB then UW_GuildCharDB.guidePin = nil end
    current = nil
    if arrowFrame then arrowFrame:Hide() end
    if not toldPause then
      toldPause = true
      miss("pin", "a map pin it didn't set appeared, so it stepped aside")
      say("You moved or cleared the map pin, so the quest guide stepped aside. /uw guide on brings it back.")
    end
    return
  end
  -- Reread after a quest log change, every few seconds while nothing was found (Questie fills its quest objects in a
  -- while after login), and every 30 seconds anyway.
  local age = now() - builtAt
  if ((dirty or not needs or #needs == 0) and age >= ns.GUIDE_REBUILD) or age >= ns.GUIDE_REREAD then
    local b0 = msNow()
    ns.GuideBuild()
    if b0 then probe("buildMs", math.floor(((msNow() or b0) - b0) * 100) / 100) end
  end
  local Q = questie()
  if not Q or not needs then return end
  local px, py, inst = call(Q.hbd.GetPlayerWorldPosition, Q.hbd)
  if not px then return end
  ns.GuideGroupUp()
  local t = meetTarget(px, py, inst) or prepTarget(px, py, inst) or trainerTarget(Q, px, py, inst)
    or ns.GuideTarget(px, py, inst)
  if t0 then probe("tickMs", math.floor(((msNow() or t0) - t0) * 100) / 100) end
  if not t then
    if current then clearPin() end
    return
  end
  if current and current.e.key == t.e.key and mine() and pin
    and dist(current.p.wx, current.p.wy, t.p.wx, t.p.wy) < ns.GUIDE_MOVE then
    current.d = t.d
    showArrow()
    return
  end
  if not (current and current.e == t.e) then ns.GuideWhy(t) end
  setPin(t)
end

-- Why this target, saved for Claude in UW_GuildDB.guideProbe.why each time the target changes (Louis, 8 Nov 13:42: we
-- check his saved data ourselves instead of asking him to retest): the quest as the log and Questie each see it,
-- and the game's own objectives and waypoint for it.
function ns.GuideWhy(t)
  if not (UW_GuildDB and t and t.e) then return end
  local e, log = t.e, g("C_QuestLog")
  local w = { at = time(), npc = e.name, key = e.key, quest = e.quest, id = e.qid, source = e.src,
    questieName = e.qn, questieReq = e.rl, questieLevel = e.ql, me = call(g("UnitLevel"), "player"), xp = e.xp,
    map = t.p.map, x = t.p.x and math.floor(t.p.x * 1000) / 10, y = t.p.y and math.floor(t.p.y * 1000) / 10 }
  if e.qid and type(log) == "table" then
    local idx = call(log.GetLogIndexForQuestID, e.qid)
    local info = idx and call(log.GetInfo, idx)
    if type(info) == "table" then w.logLevel, w.logDifficulty = plainNum(info.level), plainNum(info.difficultyLevel) end
    local gm, gx, gy = call(log.GetNextWaypoint, e.qid)
    w.gameWaypoint = plainNum(gm) and ("%s %.1f %.1f"):format(gm, (plainNum(gx) or 0) * 100, (plainNum(gy) or 0) * 100)
    local txt = call(log.GetNextWaypointText, e.qid)
    if type(txt) == "string" and not isSecretValue(txt) then w.gameWaypointText = txt end
    local objs = call(log.GetQuestObjectives, e.qid)
    if type(objs) == "table" then
      w.objectives = {}
      for _, o in ipairs(objs) do
        if type(o) == "table" and type(o.text) == "string" and not isSecretValue(o.text) then
          w.objectives[#w.objectives + 1] = o.text .. (o.finished and " (done)" or "")
        end
      end
    end
    w.complete = call(log.IsComplete, e.qid)
  end
  UW_GuildDB.guideProbe = UW_GuildDB.guideProbe or {}
  UW_GuildDB.guideProbe.why = w
  local past = type(UW_GuildDB.guideProbe.whyPast) == "table" and UW_GuildDB.guideProbe.whyPast or {}
  table.insert(past, 1, w)
  for k = #past, 6, -1 do past[k] = nil end -- the last 5 targets, so one that came and went can still be checked
  UW_GuildDB.guideProbe.whyPast = past
  return w
end

-- A guided NPC's nameplate: a line on screen. Only wanderers and friendly NPCs (a mob you're killing is already in
-- sight). No raid star: on Forever's client SetRaidTarget from an addon is a protected call (Louis's live test,
-- 8 Nov 06:37: blocked during right-click turning), so the guide never marks.
local foundAt = {}
local function npcIdOf(guid)
  local secret = g("issecretvalue")
  if type(guid) ~= "string" or (secret and secret(guid)) then return nil end
  local kind, id = guid:match("^(%a+)%-%d+%-%d+%-%d+%-%d+%-(%d+)")
  if kind == "Creature" or kind == "Vehicle" then return "m_" .. id end
end
function ns.GuideNameplate(unit)
  if not on() or not current then return end
  local e = current.e
  if not (#e.routes > 0 or e.friendly) then return end
  if npcIdOf(call(g("UnitGUID"), unit)) ~= e.key then return end
  if foundAt[e.key] and now() - foundAt[e.key] < ns.GUIDE_FOUND_AGAIN then return end
  foundAt[e.key] = now()
  local line = ("Found %s nearby."):format(e.name or "your quest NPC")
  say(line)
  local errs = g("UIErrorsFrame")
  if errs and errs.AddMessage then call(errs.AddMessage, errs, line, 1, 0.82, 0) end
  return line
end

-- Dead "!" pins (Louis, 8 Nov 15:42: "LOTS of problems going to ! on the map and it doesn't have a quest for me").
-- Questie draws a "!" for every quest its data says an NPC starts; on Forever some aren't offered (another chain, a
-- level or step its data doesn't know). Talking to that NPC, the game lists what it offers you: a quest Questie shows
-- for it that isn't on that list (by ID or by name: Forever reuses IDs) gets hidden through Questie's own hide (as its
-- Shift-click does), with a chat line and a record in UW_GuildCharDB.guideHidden. Like Questie's own check, a list
-- that can't be read in full hides nothing. What UW hid comes back at your next level, to be checked again, or with
-- /uw guide unhide; a "!" you hid in Questie yourself is never touched. /uw guide autohide on|off.
local function questieHide()
  local loader, Qs = g("QuestieLoader"), g("Questie")
  if type(loader) ~= "table" then return nil end
  local QQ = call(loader.ImportModule, loader, "QuestieQuest")
  local qdb = call(loader.ImportModule, loader, "QuestieDB")
  local hidden = type(Qs) == "table" and type(Qs.db) == "table" and type(Qs.db.char) == "table" and Qs.db.char.hidden
  if type(QQ) ~= "table" or type(QQ.HideQuest) ~= "function" or type(QQ.UnhideQuest) ~= "function"
    or type(qdb) ~= "table" or type(qdb.GetNPC) ~= "function" or type(qdb.IsDoable) ~= "function"
    or type(hidden) ~= "table" then return nil end
  return QQ, qdb, hidden
end

-- What the open quest window offers: quest IDs and names (normalised), or nil when the list can't be read in full.
local function normTitle(t) return type(t) == "string" and not isSecretValue(t) and (t:lower():gsub("[^%w]", "")) or nil end
local function offeredNow(event)
  local ids, names = {}, {}
  local function add(id, title)
    id, title = plainNum(id), normTitle(title)
    if not (id or title) then return false end
    if id and id > 0 then ids[id] = true end
    if title then names[title] = true end
    return true
  end
  if event == "GOSSIP_SHOW" then
    local G = g("C_GossipInfo")
    if type(G) ~= "table" then return nil end
    for _, fn in ipairs({ G.GetAvailableQuests, G.GetActiveQuests }) do
      local list = call(fn)
      if type(list) ~= "table" then return nil end
      for _, q in ipairs(list) do
        if type(q) ~= "table" or not add(q.questID, q.title) then return nil end
      end
    end
  elseif event == "QUEST_GREETING" then
    for i = 1, tonumber((call(g("GetNumAvailableQuests")))) or 0 do
      local ok, _, _, _, _, id = pcall(g("GetAvailableQuestInfo"), i) -- five returns: call() keeps three
      if not add(ok and id, (call(g("GetAvailableTitle"), i))) then return nil end
    end
    for i = 1, tonumber((call(g("GetNumActiveQuests")))) or 0 do
      if not add((call(g("GetActiveQuestID"), i)), (call(g("GetActiveTitle"), i))) then return nil end
    end
  else
    return nil
  end
  return ids, names
end

local function inLog(id)
  local L = g("C_QuestLog")
  if type(L) ~= "table" then return false end
  local idx = plainNum((call(L.GetLogIndexForQuestID, id)))
  return (idx and idx > 0) or call(L.IsQuestFlaggedCompleted, id) == true
end

-- The in-game decision log (Core.lua ns.trace, #414), when loaded: each hide is a done row, a missing hide call a miss.
local function trace(...) if ns.trace then ns.protect(ns.trace, ...) end end
local toldNoHide = false

local function ours()
  if not UW_GuildCharDB then return nil end
  UW_GuildCharDB.guideHidden = type(UW_GuildCharDB.guideHidden) == "table" and UW_GuildCharDB.guideHidden or {}
  return UW_GuildCharDB.guideHidden
end
local function myLevel() return plainNum((call(g("UnitLevel"), "player"))) end
local function plainName(t)
  if type(t) ~= "string" or isSecretValue(t) then return nil end
  return (t:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))
end
-- Gray "!"s (a quest above your level) are "not yet", not dead: never hidden, as in Questie's own check.
local function tooHigh(quest)
  local req, me = type(quest) == "table" and tonumber(quest.requiredLevel), myLevel()
  return req and me and req > me or false
end
-- One quest's "!" hidden through Questie, recorded and logged; true when Questie took it.
local function hideOne(QQ, hidden, id, rec, why)
  call(QQ.HideQuest, QQ, id)
  if not hidden[id] then return false end
  rec.level, rec.at = myLevel(), time()
  ours()[id] = rec
  trace("guide", "hide map !", true, ("%s (%d): %s"):format(rec.name or "?", id, why))
  return true
end
local function unhideOne(QQ, hidden, id, why)
  local list = ours()
  local rec = list and list[id]
  if not rec then return false end
  if QQ and hidden and hidden[id] then call(QQ.UnhideQuest, QQ, id) end
  list[id] = nil
  trace("guide", "unhide map !", true, ("%s (%d): %s"):format(type(rec) == "table" and rec.name or "?", id, why))
  return true
end

-- Questie's quest "!"s for NPC givers (not items or objects), with world positions: rebuilt every few seconds.
ns.GUIDE_NOBODY_NEAR = 20   -- yards from a "!" that count as standing at it
ns.GUIDE_NOBODY_AFTER = 20  -- seconds at every "!" of a quest, with its giver never seen, before it's hidden
ns.GUIDE_SEEN_FOR = 600     -- seconds a giver you saw still counts as there
ns.GUIDE_PINS_EVERY = 5     -- seconds between rereads of Questie's "!"s
local spots, spotsAt, dwell, lastScan, seenNpc = {}, nil, {}, nil, {}
local worldAt = {} -- a "!"'s map spot -> world yards, worked out once (spots don't move)
local function questieFrames()
  local loader = g("QuestieLoader")
  local QM = type(loader) == "table" and call(loader.ImportModule, loader, "QuestieMap")
  return type(QM) == "table" and type(QM.questIdFrames) == "table" and QM.questIdFrames or nil
end
local function readSpots(Q)
  local frames, out = questieFrames(), {}
  if not frames then return nil end
  for qid, names in pairs(frames) do
    for _, fname in pairs(type(names) == "table" and names or {}) do
      local f = type(fname) == "string" and g(fname)
      local d = type(f) == "table" and f.data
      if type(d) == "table" and d.Type == "available" and d.Id == qid and not d.StarterType and not f.miniMapIcon
        and type(f.x) == "number" and type(f.y) == "number" and f.UiMapID then
        local ck = f.UiMapID .. ":" .. f.x .. ":" .. f.y
        local w = worldAt[ck]
        if not w then
          local wx, wy, inst = call(Q.hbd.GetWorldCoordinatesFromZone, Q.hbd, f.x / 100, f.y / 100, f.UiMapID)
          w = { wx, wy, inst }
          worldAt[ck] = w
        end
        local wx, wy, inst = w[1], w[2], w[3]
        if wx then
          local quest = type(d.QuestData) == "table" and d.QuestData or nil
          out[#out + 1] = { qid = qid, k = ("%d:%d:%d:%d"):format(qid, f.UiMapID, math.floor(f.x * 10), math.floor(f.y * 10)),
            wx = wx, wy = wy, inst = inst, giver = plainName(d.Name), quest = quest,
            npcs = quest and type(quest.Starts) == "table" and type(quest.Starts.NPC) == "table" and quest.Starts.NPC or {} }
        end
      end
    end
  end
  return out
end

-- A giver seen (its nameplate, your mouse or target, a quest window): it's there. A "!" UW hid because nobody was at
-- its spot comes back.
function ns.GuideSeen(unit)
  local key = npcIdOf(call(g("UnitGUID"), unit))
  local id = key and tonumber(key:sub(3))
  if not id then return end
  seenNpc[id] = now()
  local list = UW_GuildCharDB and UW_GuildCharDB.guideHidden
  if type(list) ~= "table" then return end
  local QQ, _, hidden = questieHide()
  for qid, rec in pairs(list) do
    if type(rec) == "table" and rec.nobody and rec.npcId == id then
      unhideOne(QQ, hidden, qid, (rec.npc or "its giver") .. " is there after all")
    end
  end
end
local function seenAny(npcs)
  for _, id in ipairs(npcs) do
    if seenNpc[id] and now() - seenNpc[id] < ns.GUIDE_SEEN_FOR then return true end
  end
  return false
end

-- Each guide tick: time spent at each "!". A quest whose every "!" you stood at for 20 seconds, its giver never seen,
-- is hidden as "nobody there" (Louis, 8 Nov 21:59: "I keep going to them and nothing is there"). The nearest few are
-- kept in UW_GuildDB.guideProbe.pinsNear for checking.
function ns.GuideNobodyTick()
  if not (on() and extraOn("autohide") and UW_GuildCharDB) then return end
  local Q = questie()
  if not Q then return end
  local px, py, inst = call(Q.hbd.GetPlayerWorldPosition, Q.hbd)
  if not px then return end
  local t = now()
  if not spotsAt or t - spotsAt >= ns.GUIDE_PINS_EVERY then
    spots, spotsAt = readSpots(Q) or {}, t
    local near = {}
    for _, sp in ipairs(spots) do
      if sp.inst == inst then
        local d = dist(px, py, sp.wx, sp.wy)
        if d < 300 then near[#near + 1] = { id = sp.qid, quest = sp.quest and sp.quest.name, giver = sp.giver,
          req = sp.quest and sp.quest.requiredLevel, lvl = sp.quest and sp.quest.level, d = math.floor(d),
          at = math.floor(dwell[sp.k] or 0) } end
      end
    end
    table.sort(near, function(a, b) return a.d < b.d end)
    while #near > 12 do table.remove(near) end
    probe("pinsNear", near)
  end
  local dt = lastScan and math.min(t - lastScan, 5) or 0
  lastScan = t
  if dt <= 0 then return end
  local check = {}
  for _, sp in ipairs(spots) do
    if sp.inst == inst and dist(px, py, sp.wx, sp.wy) <= ns.GUIDE_NOBODY_NEAR then
      dwell[sp.k] = (dwell[sp.k] or 0) + dt
      if dwell[sp.k] >= ns.GUIDE_NOBODY_AFTER then check[sp.qid] = sp end
    end
  end
  if not next(check) then return end
  local QQ, _, hidden = questieHide()
  if not QQ then return end
  for qid, sp in pairs(check) do
    local all = true
    for _, other in ipairs(spots) do
      if other.qid == qid and (dwell[other.k] or 0) < ns.GUIDE_NOBODY_AFTER then all = false break end
    end
    if all and #sp.npcs > 0 and not seenAny(sp.npcs) and not hidden[qid] and not inLog(qid) and not tooHigh(sp.quest) then
      local name = sp.quest and sp.quest.name
      if hideOne(QQ, hidden, qid, { name = name, npc = sp.giver, npcId = sp.npcs[1], nobody = true, by = "spot" },
        ("nobody at its spot (%s)"):format(sp.giver or "its giver")) then
        say(("Hid the map \"!\" for %s: %s isn't at its spot. It comes back if %s shows up, at your next level, or with /uw guide unhide.")
          :format(name or ("quest " .. qid), sp.giver or "its quest giver", sp.giver or "the giver"))
      end
    end
  end
end

-- The giver of an open quest window: its NPC id, or by name among the "!"s near you when the game keeps the id secret.
local function windowNpc(qdb)
  local key = npcIdOf(call(g("UnitGUID"), "npc"))
  if key then return tonumber(key:sub(3)), "id" end
  local who = plainName((call(g("UnitName"), "npc")))
  if not who then return nil, "no id or name" end
  for _, sp in ipairs(spots) do
    for _, id in ipairs(sp.npcs) do
      local npc = call(qdb.GetNPC, qdb, id)
      if type(npc) == "table" and npc.name == who then return id, "name" end
    end
  end
  return nil, "secret id, name not near a \"!\""
end

function ns.GuideQuestWindow(event)
  if not (on() and extraOn("autohide") and UW_GuildCharDB) then return end
  local QQ, qdb, hidden = questieHide()
  if not QQ then
    probe("autohide", "Questie's hide isn't there")
    if not toldNoHide then toldNoHide = true trace("guide", "hide map !", false, "Questie's hide call isn't there") end
    return
  end
  local npcId, how = windowNpc(qdb)
  local ids, names = offeredNow(event)
  local seen = { event = event, how = how, npc = npcId, at = time() }
  probe("autohideCheck", seen)
  -- What the game offers is there: a "!" UW hid for it comes back, whoever offers it.
  for id in pairs(ids or {}) do unhideOne(QQ, hidden, id, "offered after all") end
  if not npcId then return end
  seenNpc[npcId] = now()
  local npc = call(qdb.GetNPC, qdb, npcId)
  local starts = type(npc) == "table" and npc.questStarts
  if type(starts) ~= "table" then starts = call(qdb.QueryNPCSingle, npcId, "questStarts") end -- Questie 12.6.4's own read
  seen.starts = type(starts) == "table" and #starts or 0
  if type(starts) ~= "table" or #starts == 0 then return end
  if not ids then seen.why = "the quest list couldn't be read in full" return end
  local who = plainName((call(g("UnitName"), "npc"))) or (type(npc) == "table" and npc.name) or "this NPC"
  local done = {}
  for _, id in ipairs(starts) do
    local quest = call(qdb.GetQuest, id)
    local name = type(quest) == "table" and quest.name
    if type(id) == "number" and not hidden[id] and not ids[id] and not (name and names[normTitle(name)])
      and not inLog(id) and not tooHigh(quest) and call(qdb.IsDoable, id) then
      if hideOne(QQ, hidden, id, { name = name, npc = who, npcId = npcId, by = event }, who .. " doesn't offer it") then
        done[#done + 1] = name or ("quest " .. id)
      end
    end
  end
  seen.hid = #done
  if #done == 0 then return end
  probe("autohideLast", { npc = who, quests = done, at = time() })
  say(("Hid the map %s for %s: %s doesn't offer %s to you. Back at your next level, or now with /uw guide unhide.")
    :format(#done == 1 and "\"!\"" or "\"!\"s", table.concat(done, ", "), who, #done == 1 and "it" or "them"))
  return done
end

-- Back on the map: what UW hid, checked again by talking to the NPC. Level-ups bring back ones hidden at a lower level.
function ns.GuideUnhide(belowLevel)
  local list = UW_GuildCharDB and UW_GuildCharDB.guideHidden
  local QQ, _, hidden = questieHide()
  if type(list) ~= "table" or not QQ then return 0 end
  local n = 0
  for id, rec in pairs(list) do
    if not belowLevel or not (type(rec) == "table" and rec.level) or rec.level < belowLevel then
      if unhideOne(QQ, hidden, id, belowLevel and "level up" or "/uw guide unhide") then n = n + 1 end
    end
  end
  return n
end

-- /uw guide: what it points at, or why not. on / off.
local function status()
  if not on() then return "The quest guide is off. /uw guide on turns it on." end
  if paused then return "The quest guide stepped aside for your own map pin. /uw guide on brings it back." end
  if not questie() then return "The quest guide needs Questie: /uw kit shows where to get it." end
  if busy() then return "The quest guide waits until you're out of combat and out of instances." end
  if not current then
    ns.GuideTick()
    if not current then return "Nothing to guide to: your tracked quests have no spots in Questie's data here." end
  end
  local e = current.e
  if e.key == "meet" then return ("Quest guide: the meet point from %s, %d yards."):format(meet and meet.from or "your group",
    math.floor(current.d + 0.5)) end
  return ("Quest guide: %s for %s, %d yards%s. /uw guide off stops it;"):format(e.name or "?", e.quest or "a quest",
    math.floor(current.d + 0.5), current.route and ", following its patrol route" or "")
    .. " /uw guide skip passes over it"
end
ns.GuideStatus = status

-- Where you are, or your own map pin, as the pin's map and 0-1 coordinates.
local function myPoint()
  local own = pinNow()
  if own and not samePoint(own, mine()) then return own.map, own.x, own.y end
  local map = g("C_Map")
  local m = map and call(map.GetBestMapForUnit, "player")
  local pos = m and call(map.GetPlayerMapPosition, m, "player")
  if type(pos) ~= "table" then return nil end
  local x, y = pos.x, pos.y
  if pos.GetXY then x, y = call(pos.GetXY, pos) end
  local secret = g("issecretvalue")
  if type(x) ~= "number" or type(y) ~= "number" or (secret and (secret(x) or secret(y))) or (x == 0 and y == 0) then return nil end
  return m, x, y
end

local function groupChannel()
  if call(g("IsInRaid")) then return "RAID" end
  if call(g("IsInGroup")) then return "PARTY" end
end
local function canLead(who)
  if not call(g("IsInRaid")) then return true end
  return call(g("UnitIsGroupLeader"), who) or call(g("UnitIsGroupAssistant"), who) or false
end

ns.commands.meet = function(args)
  local sub = strtrim(args or ""):lower()
  local channel = groupChannel()
  if sub == "off" then
    local had = meet
    meet = nil
    if channel and canLead("player") then ns.send("MEET\t0", channel) end
    say(had and "Meet point cleared." or "No meet point to clear.")
    return
  end
  if not channel then say("Meet points are for your group. Guild-wide: Shift-click your map pin into guild chat.") return end
  if not canLead("player") then say("In a raid, the leader or an assist sets the meet point.") return end
  if now() - sharedAt < ns.GUIDE_MEET_GAP then say("Just shared. Try again in a few seconds.") return end
  local m, x, y = myPoint()
  if not m then say("Can't read where you are here. Place a map pin and try /uw meet again.") return end
  sharedAt = now()
  ns.send(("MEET\t%d\t%.4f\t%.4f"):format(m, x, y), channel)
  say("Meet point shared with your group. Their markers point there now. /uw meet off clears it.")
end

ns.handlers.MEET = function(sender, channel, m, x, y)
  if channel ~= "PARTY" and channel ~= "RAID" then return end
  local who = ns.shortName(sender)
  if who == ns.shortName(ns.me() or "") then return end
  if not canLead(who) then return end
  if m == "0" then
    if meet and meet.from == who then meet = nil; say(who .. " cleared the meet point.") end
    return
  end
  m, x, y = tonumber(m), tonumber(x), tonumber(y)
  if not (m and x and y) or x < 0 or x > 1 or y < 0 or y > 1 then return end
  local Q = questie()
  local wx, wy, inst
  if Q then wx, wy, inst = call(Q.hbd.GetWorldCoordinatesFromZone, Q.hbd, x, y, m) end
  if not wx then return end
  meet = { from = who, at = now(), p = { wx = wx, wy = wy, inst = inst, map = m, x = x, y = y },
    e = { key = "meet", name = "Meet " .. who, quest = "your group", spots = {}, routes = {} } }
  if on() and not paused then
    say(who .. " set a meet point. Your marker points there now. /uw meet off ignores it.")
    ns.protect(ns.GuideTick)
  else
    say(who .. " set a meet point. /uw guide on lets your marker point there.")
  end
end

local function arrowCommand(word)
  local c = arrowCfg()
  if word == "off" then c.off = true
  elseif word == "on" then c.off = nil
  elseif word == "small" or word == "large" or word == "normal" then c.size = word ~= "normal" and word or nil
  elseif word == "faint" then c.faint = true
  elseif word == "bright" then c.faint = nil
  elseif word == "reset" then c.point, c.x, c.y = nil, nil, nil
    if arrowFrame then arrowFrame:ClearAllPoints(); arrowFrame:SetPoint("TOP", g("UIParent"), "TOP", 0, -150) end
  else
    say("/uw guide arrow on, off, small, normal, large, faint, bright, reset. Shift-drag the arrow to move it.")
    return
  end
  styleArrow()
  showArrow()
  say(("Guide arrow: %s, %s, %s."):format(c.off and "off" or "on", c.size or "normal", c.faint and "faint" or "bright"))
end

-- /uw guide test (Louis's live test, 8 Nov 05:38: "many tests at once with good logging"): one look at every step,
-- in chat and in UW_GuildDB.guideProbe.test, plus a test arrow in the middle of the screen for 15 seconds that
-- points north whatever the quests say. Seeing it means drawing works and the data is the problem; not seeing it
-- means drawing is the problem. Debug lines stay on until /reload.
local testFrame
function ns.GuideTest()
  debugOn = true
  local out = {}
  local function line(k, v) out[#out + 1] = k .. ": " .. tostring(v); UW_GuildDB.guideProbe = UW_GuildDB.guideProbe or {} end
  local Q = questie()
  line("questie", Q and "yes" or "no")
  line("guide", on() and (paused and "paused (your pin)" or "on") or "off")
  line("busy", busy() and "yes (combat or instance)" or "no")
  ns.GuideBuild()
  line("needs", needs and #needs or "none")
  line("from the game's quest map", UW_GuildDB.guideProbe and UW_GuildDB.guideProbe.fromGame or 0)
  line("Questie data for another quest (ignored)", UW_GuildDB.guideProbe and UW_GuildDB.guideProbe.mismatched or 0)
  line("quests read", UW_GuildDB.guideProbe and UW_GuildDB.guideProbe.quests or "?")
  if not current then ns.GuideTick() end
  line("target", current and ("%s, %d yd"):format(current.e.name or "?", math.floor(current.d + 0.5)) or "none")
  local pin = pinNow()
  line("map pin", pin and ("map %s %.3f %.3f%s"):format(tostring(pin.map), pin.x, pin.y, samePoint(pin, mine()) and " (ours)" or "") or "none")
  local facing = g("GetPlayerFacing") and call(g("GetPlayerFacing"))
  line("facing", type(facing) == "number" and not isSecret(facing) and ("%.2f"):format(facing) or type(facing))
  local px, py, inst
  if Q then px, py, inst = call(Q.hbd.GetPlayerWorldPosition, Q.hbd) end
  line("position", px and ("%d, %d in world %s"):format(px, py, tostring(inst)) or "none")
  if current and Q and px then
    local a, d = call(Q.hbd.GetWorldVector, Q.hbd, inst, px, py, current.p.wx, current.p.wy)
    line("direction", a and ("%.2f rad, %d yd (target world %s)"):format(a, d, tostring(current.p.inst)) or "none")
  end
  line("arrow setting", arrowShown() and "on" or "off")
  showArrow()
  line("arrow frame", arrowFrame and (call(arrowFrame.IsVisible, arrowFrame) and "visible" or "hidden") or "not built")
  -- The test arrow: same art, middle of the screen, pointing north.
  if not testFrame and CreateFrame then
    testFrame = CreateFrame("Frame", "UW_GuideArrowTest", g("UIParent"))
    testFrame:SetSize(64, 64)
    testFrame:SetPoint("CENTER", g("UIParent"), "CENTER", 0, 120)
    testFrame:SetFrameStrata("HIGH")
    testFrame.tex = testFrame:CreateTexture(nil, "ARTWORK")
    testFrame.tex:SetAllPoints()
    arrowArt(testFrame.tex)
    testFrame.label = testFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    testFrame.label:SetPoint("TOP", testFrame, "BOTTOM", 0, -4)
    testFrame.label:SetText("UW arrow test: points north")
    testFrame.elapsed = 0
    testFrame:SetScript("OnUpdate", function(self, e)
      self.elapsed = self.elapsed + e
      if self.elapsed < 0.05 then return end
      self.elapsed = 0
      local fa = call(g("GetPlayerFacing"))
      if type(fa) == "number" and not isSecret(fa) then self.tex:SetRotation(-fa) end
    end)
  end
  if testFrame then
    testFrame:Show()
    line("test arrow", call(testFrame.IsVisible, testFrame) and "visible" or "hidden")
    ns.after(15, function() if testFrame then testFrame:Hide() end end)
  end
  UW_GuildDB.guideProbe.test = out
  UW_GuildDB.guideProbe.testAt = time()
  say("UW guide test (also saved for Claude at /reload):")
  for _, l in ipairs(out) do say("  " .. l) end
  say("A gold test arrow shows mid-screen for 15 seconds. Tell us: did you see it, and the guide arrow up top?")
end

ns.commands.guide = function(args)
  local sub = strtrim(args or ""):lower()
  local first, rest = sub:match("^(%S+)%s*(.-)$")
  if first == "arrow" then arrowCommand(rest) return end
  if first == "test" then ns.GuideTest() return end
  if sub == "" and not on() then sub = "on" end -- the guide's own word turns it on (Louis, 8 Nov: "off ... use that exact command")
  if sub == "skip" then
    if not (current and current.e) then say("The quest guide isn't pointing at anything to skip.") return end
    UW_GuildCharDB.guideSkip = UW_GuildCharDB.guideSkip or {}
    UW_GuildCharDB.guideSkip[current.e.key .. "|" .. tostring(current.e.quest)] = time()
    say(("Skipped %s for %s. /uw guide unskip brings skipped steps back."):format(current.e.name or "that step",
      current.e.quest or "this quest"))
    dirty, builtAt = true, 0
    ns.GuideTick()
    return
  elseif first == "trainer" or first == "group" or first == "events" then
    UW_GuildDB.guideExtras = type(UW_GuildDB.guideExtras) == "table" and UW_GuildDB.guideExtras or {}
    if rest == "off" or rest == "on" then UW_GuildDB.guideExtras[first] = rest == "on" end
    local what = { trainer = "Trainer reminders", group = "Group-up lines", events = "Guild events under the arrow" }
    say(("%s: %s. /uw guide %s on|off."):format(what[first], extraOn(first) and "on" or "off", first))
    return
  elseif first == "autohide" then
    UW_GuildDB.guideExtras = type(UW_GuildDB.guideExtras) == "table" and UW_GuildDB.guideExtras or {}
    if rest == "off" or rest == "on" then UW_GuildDB.guideExtras.autohide = rest == "on" end
    say(("Hiding map \"!\"s an NPC doesn't offer you: %s. /uw guide autohide on|off."):format(extraOn("autohide") and "on" or "off"))
    return
  elseif sub == "unhide" then
    local n = ns.GuideUnhide()
    say(n > 0 and ("%d map \"!\"%s UW hid %s back. Talking to the NPC checks again."):format(n, n == 1 and "" or "s",
      n == 1 and "is" or "are") or "UW hasn't hidden any map \"!\"s.")
    return
  elseif sub == "unskip" then
    UW_GuildCharDB.guideSkip = nil
    dirty, builtAt = true, 0
    ns.GuideTick()
    say("Skipped quest guide steps are back.")
    return
  end
  if sub == "off" then
    UW_GuildDB.guide = false
    prep = nil
    clearPin()
    say("The quest guide is off and its pin is gone. /uw guide on brings it back.")
    return
  elseif sub == "on" then
    UW_GuildDB.guide = true
    prep = nil
    ns.GuideUnstick()
    paused, toldPause, dirty, claimed = false, false, true, true
    ns.GuideTick()
    if not current then
      ns.trace("guide", "/uw guide on", false, not questie() and "Questie isn't loaded" or busy() and "in combat or an instance"
        or "no tracked quest has a spot in Questie's data here")
    end
    if not questie() then say("The quest guide is on, but it needs Questie to point anywhere: /uw kit shows where to get it.") return end
    say("The quest guide is on: the map pin and marker point at your tracked quest's next step.")
    return
  end
  say(status())
end

local f = CreateFrame("Frame")
ns.listen(f, { "PLAYER_ENTERING_WORLD", "QUEST_LOG_UPDATE", "QUEST_WATCH_LIST_CHANGED", "SUPER_TRACKING_CHANGED",
  "ZONE_CHANGED_NEW_AREA", "NAME_PLATE_UNIT_ADDED", "PLAYER_TARGET_CHANGED", "PLAYER_LEVEL_UP", "TRAINER_SHOW",
  "GOSSIP_SHOW", "QUEST_GREETING", "UPDATE_MOUSEOVER_UNIT", "PLAYER_SOFT_INTERACT_CHANGED", "QUEST_ACCEPTED",
  "QUEST_TURNED_IN", "QUEST_REMOVED", "GROUP_ROSTER_UPDATE" })
local ticker
f:SetScript("OnEvent", ns.guard(function(_, event, arg)
  if event == "NAME_PLATE_UNIT_ADDED" then ns.protect(ns.GuideSeen, arg) ns.protect(ns.GuideNameplate, arg) return end
  if event == "PLAYER_TARGET_CHANGED" then ns.protect(ns.GuideSeen, "target") ns.protect(ns.GuideNameplate, "target") return end
  if event == "UPDATE_MOUSEOVER_UNIT" then ns.protect(ns.GuideSeen, "mouseover") return end
  -- Dungeon prep plans again on anything that changes which quests you can take, or where you are.
  if event == "QUEST_ACCEPTED" or event == "QUEST_TURNED_IN" or event == "QUEST_REMOVED" or event == "GROUP_ROSTER_UPDATE"
    or event == "PLAYER_LEVEL_UP" or event == "ZONE_CHANGED_NEW_AREA" or event == "QUEST_LOG_UPDATE" then
    ns.GuidePrepDirty()
    if event == "QUEST_REMOVED" then ns.protect(ns.GuidePrepRemoved, tonumber(arg)) end
  end
  if event == "QUEST_TURNED_IN" or event == "QUEST_REMOVED" or event == "GROUP_ROSTER_UPDATE" then return end
  if event == "PLAYER_SOFT_INTERACT_CHANGED" then ns.protect(ns.GuideSeen, "softinteract") return end
  if event == "GOSSIP_SHOW" or event == "QUEST_GREETING" then ns.protect(ns.GuideQuestWindow, event) return end
  if event == "PLAYER_LEVEL_UP" then
    ns.protect(ns.GuideLevelUp, arg)
    ns.protect(function()
      local n = ns.GuideUnhide(tonumber(arg))
      if n > 0 then say(("%d map \"!\"%s UW hid at a lower level %s back, to check again."):format(n,
        n == 1 and "" or "s", n == 1 and "is" or "are")) end
    end)
  end
  if event == "TRAINER_SHOW" then trainer = nil return end
  if event == "SUPER_TRACKING_CHANGED" then
    if selfTrack then return end
    local sup = g("C_SuperTrack")
    local id = sup and call(sup.GetSuperTrackedQuestID)
    if type(id) == "number" and id > 0 then focus = id end
  end
  dirty = true
  if event == "PLAYER_ENTERING_WORLD" and not ticker and C_Timer and C_Timer.NewTicker then
    ticker = C_Timer.NewTicker(ns.GUIDE_EVERY, function() ns.protect(ns.GuideTick) end)
  end
end))

-- Tests: a fresh session, as after a login (the pins the guide knows of are forgotten).
function ns.GuideResetSession()
  current, paused, toldPause, started, claimed, meet, trainer, groupLookAt = nil, false, false, false, false, nil, nil, 0
  prep = nil
  missed = {}
end
