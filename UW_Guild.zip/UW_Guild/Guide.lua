-- Quest guide (Louis, 8 Nov 2026: "a UI arrow that solves the wandering merchant problem visually for peoples' quests
-- like restedxp").
--
-- The game's own map pin and on-screen marker (with yards; Attune and RareScanner use it on Forever too) points at
-- the nearest thing your tracked quests still need, read from Questie:
--   * what an unfinished objective needs (kill, loot, talk, use), or, once a quest is ready, who takes it in;
--   * an NPC with a patrol route in Questie's data: the nearest spot on its route. Standing on the route, a spot
--     about 80 yards further along it, so the marker walks the route until the NPC shows;
--   * a spawn spot you reach with nothing left there is skipped for 3 minutes, so the marker moves to the next one.
-- No addon can see where an NPC is until its nameplate shows (about 40 yards). When a guided NPC that wanders, or a
-- friendly one, shows up, a line on screen says so. /uw guide skip passes over a step that's bugged on the server.
-- Blizzard's own quest focus (clicking a quest to track it) picks the quest. A pin you place yourself wins: the guide
-- steps aside until /uw guide on. Never in combat or instances. /uw guide off clears the marker and stops.
-- Questie's quest objects and ZoneDB aren't a public interface: every read is protected, and if Questie changes them
-- the guide stops quietly (UW_GuildDB.guideProbe says why).
local _, ns = ...
local say = ns.say

ns.GUIDE_EVERY = 1        -- seconds between looks
ns.GUIDE_AHEAD = 80       -- yards ahead along a route, once on it
ns.GUIDE_ON_ROUTE = 25    -- yards from a route's nearest point that count as on it
ns.GUIDE_REACHED = 20     -- yards: a spawn spot counts as reached
ns.GUIDE_SKIP = 180       -- seconds a reached spawn spot is skipped
ns.GUIDE_MOVE = 8         -- yards the target moves before the pin is set again
ns.GUIDE_REBUILD = 3      -- seconds between rereads after the quest log changes, at least
ns.GUIDE_REREAD = 30      -- seconds between rereads anyway
ns.GUIDE_FOUND_AGAIN = 120 -- seconds before the same NPC is announced again
ns.GUIDE_MAX_POINTS = 400 -- spawn spots read per NPC

local function call(fn, ...)
  if type(fn) ~= "function" and not (type(fn) == "table" and getmetatable(fn)) then return nil end
  local ok, a, b, c = pcall(fn, ...)
  if ok then return a, b, c end
end
local function g(name) return rawget(_G, name) end
-- Gentle rollout (CONTRIBUTING.md, "Introducing a feature to members", Louis 8 Nov 2026): officers have it on, to try
-- it first; everyone else turns it on with /uw guide on (UW_GuildDB.guide = true), after the guild line says it exists.
local function on()
  if not UW_GuildDB then return false end
  if UW_GuildDB.guide ~= nil then return UW_GuildDB.guide == true end
  return ns.isOfficer and ns.me and ns.isOfficer(ns.me() or "") or false
end
ns.GuideOn = on
local function now() return (g("GetTime") or time)() end

local function probe(k, v)
  if not UW_GuildDB then return end
  local p = UW_GuildDB.guideProbe or {}
  UW_GuildDB.guideProbe = p
  p[k] = v
  p.at = time()
end

-- Questie's pieces, or nil: its quest objects, NPC and object reader, zone IDs and map maths.
local function questie()
  local loader = g("QuestieLoader")
  if type(loader) ~= "table" then return nil end
  local qdb = call(loader.ImportModule, loader, "QuestieDB")
  local zdb = call(loader.ImportModule, loader, "ZoneDB")
  local hbd = call(g("LibStub"), "HereBeDragonsQuestie-2.0", true)
  if type(qdb) ~= "table" or type(zdb) ~= "table" or type(hbd) ~= "table" then return nil end
  if type(qdb.GetQuest) ~= "function" or type(hbd.GetWorldCoordinatesFromZone) ~= "function" then return nil end
  return { db = qdb, zone = zdb, hbd = hbd }
end
ns.GuideQuestie = questie

local function dist(ax, ay, bx, by) return math.sqrt((ax - bx) ^ 2 + (ay - by) ^ 2) end

-- A spot in Questie's percentages on an area, as world yards plus the pin's map and 0-1 coordinates.
local function spot(Q, areaId, xy)
  if type(xy) ~= "table" or type(xy[1]) ~= "number" or type(xy[2]) ~= "number" or xy[1] < 0 or xy[2] < 0 then return end
  local map = call(Q.zone.GetUiMapIdByAreaId, Q.zone, areaId)
  if not map then return end
  local wx, wy, inst = call(Q.hbd.GetWorldCoordinatesFromZone, Q.hbd, xy[1] / 100, xy[2] / 100, map)
  if not wx then return end
  return { wx = wx, wy = wy, inst = inst, map = map, x = xy[1] / 100, y = xy[2] / 100 }
end

-- One thing to go to: its spawn spots and its patrol routes (lists of spots).
local function entity(Q, key, name, quest, spawns, routes, friendly)
  local e = { key = key, name = name, quest = quest, spots = {}, routes = {}, friendly = friendly }
  for areaId, list in pairs(type(spawns) == "table" and spawns or {}) do
    for _, xy in pairs(type(list) == "table" and list or {}) do
      if #e.spots >= ns.GUIDE_MAX_POINTS then break end
      local p = spot(Q, areaId, xy)
      if p then
        e.spots[#e.spots + 1] = p
        p.k = key .. ":" .. #e.spots
      end
    end
  end
  for areaId, paths in pairs(type(routes) == "table" and routes or {}) do
    for _, path in pairs(type(paths) == "table" and paths or {}) do
      local pts = {}
      for _, xy in ipairs(type(path) == "table" and path or {}) do pts[#pts + 1] = spot(Q, areaId, xy) end
      if #pts >= 2 then
        pts.closed = dist(pts[1].wx, pts[1].wy, pts[#pts].wx, pts[#pts].wy) < 15
        e.routes[#e.routes + 1] = pts
      end
    end
  end
  if #e.spots > 0 or #e.routes > 0 then return e end
end

-- The game's own quest data, for a quest Questie has nothing on (Forever's own quests, or gaps in Questie's data; Louis,
-- 8 Nov 13:35: "use ALL available data"): the next waypoint Blizzard's map shows for it, else its spot on your map.
local function isSecretValue(v) local s = g("issecretvalue") return s and s(v) or false end
local function plainNum(v) local s = g("issecretvalue") return type(v) == "number" and not (s and s(v)) and v or nil end
local function questsOnMap()
  local log, map = g("C_QuestLog"), call(g("C_Map") and g("C_Map").GetBestMapForUnit, "player")
  local out = {}
  map = plainNum(map)
  if not (map and type(log) == "table") then return out end
  for _, q in ipairs(type(call(log.GetQuestsOnMap, map)) == "table" and call(log.GetQuestsOnMap, map) or {}) do
    local id = type(q) == "table" and plainNum(q.questID)
    if id then out[id] = { map = map, x = plainNum(q.x), y = plainNum(q.y) } end
  end
  return out
end
local function gameEntity(Q, id, title, onMap)
  local log = g("C_QuestLog")
  if type(log) ~= "table" then return end
  local map, x, y = call(log.GetNextWaypoint, id)
  map, x, y = plainNum(map), plainNum(x), plainNum(y)
  if not (map and x and y) and onMap[id] then map, x, y = onMap[id].map, onMap[id].x, onMap[id].y end
  if not (map and x and y) or x <= 0 or y <= 0 then return end
  local wx, wy, inst = call(Q.hbd.GetWorldCoordinatesFromZone, Q.hbd, x, y, map)
  if not wx then return end
  local text = call(log.GetNextWaypointText, id)
  local s = g("issecretvalue")
  if type(text) ~= "string" or text == "" or (s and s(text)) then text = title end
  local key = "q_" .. id
  return { key = key, name = text, quest = title, routes = {}, friendly = true,
    spots = { { wx = wx, wy = wy, inst = inst, map = map, x = x, y = y, k = key .. ":1" } } }
end

local function sameTitle(a, b)
  if type(a) ~= "string" or type(b) ~= "string" then return true end -- nothing to compare: trust Questie
  local function norm(t) return (t:lower():gsub("[^%w]", "")) end
  return norm(a) == norm(b)
end

local function unfinished(o) return type(o) == "table" and not (o.Needed and o.Needed == o.Collected) end

-- Everything a quest still needs, from Questie's quest object.
local function questNeeds(Q, quest, title, out)
  local complete = call(quest.IsComplete, quest)
  if complete == 1 or (complete ~= -1 and quest.isComplete) then
    local fin = type(quest.Finisher) == "table" and quest.Finisher or {}
    for _, id in pairs(fin.NPC or {}) do
      local npc = call(Q.db.GetNPC, Q.db, id)
      if type(npc) == "table" then
        out[#out + 1] = entity(Q, "m_" .. id, npc.name, title, npc.spawns, npc.waypoints, true)
      end
    end
    for _, id in pairs(fin.GameObject or {}) do
      local obj = call(Q.db.GetObject, Q.db, id)
      if type(obj) == "table" then out[#out + 1] = entity(Q, "o_" .. id, obj.name, title, obj.spawns, nil, true) end
    end
    return
  end
  for _, list in ipairs({ quest.Objectives or {}, quest.SpecialObjectives or {} }) do
    for _, o in pairs(list) do
      if unfinished(o) then
        for id, s in pairs(type(o.spawnList) == "table" and o.spawnList or {}) do
          if type(s) == "table" then
            local key = (s.TooltipKey or ((o.Type == "object" and "o_" or "m_") .. tostring(s.Id or id)))
            out[#out + 1] = entity(Q, key, s.Name, title, s.Spawns, s.Waypoints, not s.Hostile)
          end
        end
      end
    end
  end
end

-- Quests Questie's tracker shows (all of them when it tracks none), or only the one Blizzard's focus picked.
-- Quests far above your level aren't your next step (Louis's live test, 8 Nov 13:26: a level-60 attunement quest in
-- the log sent a level-20 druid across Orgrimmar), so they're left out unless you focus one yourself.
ns.GUIDE_LEVELS_ABOVE = 3
local focus
local function trackedIds()
  local log, ids, all = g("C_QuestLog"), {}, {}
  local mine = tonumber(call(g("UnitLevel"), "player"))
  for i = 1, (log and tonumber(call(log.GetNumQuestLogEntries)) or 0) do
    local info = call(log.GetInfo, i)
    if type(info) == "table" and not info.isHeader and info.questID then
      local q = { info.questID, info.title }
      all[#all + 1] = q
      local lvl = tonumber(info.level)
      if not (mine and lvl and lvl > mine + ns.GUIDE_LEVELS_ABOVE) then ids[#ids + 1] = q end
    end
  end
  if focus then
    for _, q in ipairs(all) do if q[1] == focus then return { q } end end
    focus = nil
  end
  local Questie = g("Questie")
  local char = type(Questie) == "table" and type(Questie.db) == "table" and Questie.db.char or nil
  local prof = type(Questie) == "table" and type(Questie.db) == "table" and Questie.db.profile or nil
  if type(char) ~= "table" then return ids end
  local out = {}
  for _, q in ipairs(ids) do
    local tracked
    if prof and prof.autoTrackQuests then tracked = not (char.AutoUntrackedQuests or {})[q[1]]
    else tracked = (char.TrackedQuests or {})[q[1]] end
    if tracked then out[#out + 1] = q end
  end
  return #out > 0 and out or ids
end

local needs, builtAt, dirty = nil, 0, true
function ns.GuideBuild()
  local Q = questie()
  probe("questie", Q ~= nil)
  if not Q then needs = nil return nil end
  local out, ids = {}, trackedIds()
  probe("quests", #ids)
  local onMap, fromGame, mismatched = questsOnMap(), 0, 0
  local mine = tonumber(call(g("UnitLevel"), "player"))
  for _, q in ipairs(ids) do
    local quest, had = call(Q.db.GetQuest, q[1]), #out
    -- Forever reuses quest IDs: Questie's quest under this ID can be a different quest (Louis's live test, 8 Nov 13:35:
    -- "Unending Torment" in the log, Questie's quest of that ID sends you to Rekkul). Only a matching name is trusted.
    if type(quest) == "table" and not sameTitle(quest.name, q[2]) then quest = nil; mismatched = mismatched + 1 end
    local need = type(quest) == "table" and tonumber(quest.requiredLevel)
    if need and mine and need > mine + ns.GUIDE_LEVELS_ABOVE and q[1] ~= focus then quest = false end
    if type(quest) == "table" then
      local ok = pcall(questNeeds, Q, quest, q[2] or quest.name, out)
      if not ok then probe("readFailed", q[1]) end
      for k = had + 1, #out do
        local e = out[k]
        e.qid, e.src, e.qn, e.rl, e.ql = q[1], "questie", quest.name, quest.requiredLevel, quest.level
      end
    end
    if #out == had and quest ~= false then
      local e = gameEntity(Q, q[1], q[2] or (type(quest) == "table" and quest.name) or "a quest", onMap)
      if e then e.qid, e.src = q[1], "game"; out[#out + 1] = e; fromGame = fromGame + 1 end
    end
  end
  probe("fromGame", fromGame)
  probe("mismatched", mismatched)
  -- Steps the player skipped (/uw guide skip: a step that's bugged on the server), per NPC and quest, kept until unskip.
  local skip = UW_GuildCharDB and UW_GuildCharDB.guideSkip
  if type(skip) == "table" and next(skip) then
    local kept = {}
    for _, e in ipairs(out) do if not skip[e.key .. "|" .. tostring(e.quest)] then kept[#kept + 1] = e end end
    out = kept
  end
  needs, builtAt, dirty = out, now(), false
  probe("needs", #out)
  return out
end

-- Where to go: the nearest need in this world, and the spot to aim at. Pure maths on what GuideBuild read.
local skipped, routeDir = {}, {}
local function nearest(px, py, inst, list)
  local t, best = nil, math.huge
  for _, e in ipairs(list or needs or {}) do
    for ri, pts in ipairs(e.routes) do
      local ni, nd = nil, math.huge
      for i, p in ipairs(pts) do
        if p.inst == inst then
          local d = dist(px, py, p.wx, p.wy)
          if d < nd then ni, nd = i, d end
        end
      end
      if ni and nd < best then
        best = nd
        local j, rkey = ni, e.key .. "#" .. ri
        if nd <= ns.GUIDE_ON_ROUTE then
          local dir, walked, steps = routeDir[rkey] or 1, 0, 0
          while walked < ns.GUIDE_AHEAD and steps < #pts * 2 do
            local nj = j + dir
            if nj < 1 or nj > #pts then
              if pts.closed then nj = nj < 1 and #pts or 1
              else dir = -dir; nj = j + dir end
            end
            walked = walked + dist(pts[j].wx, pts[j].wy, pts[nj].wx, pts[nj].wy)
            j, steps = nj, steps + 1
          end
          routeDir[rkey] = dir
        end
        t = { e = e, p = pts[j], d = nd, route = true }
      end
    end
    -- Spawn spots: squared distances and keys made at build time, so a look allocates nothing (CPU light).
    local t0, many, reach2 = now(), #e.spots > 1, ns.GUIDE_REACHED * ns.GUIDE_REACHED
    local bp, bd, fp, fd, any = nil, math.huge, nil, math.huge, false
    for _, p in ipairs(e.spots) do
      if p.inst == inst then
        any = true
        local d2 = (px - p.wx) * (px - p.wx) + (py - p.wy) * (py - p.wy)
        if d2 < fd then fp, fd = p, d2 end
        if many and d2 <= reach2 then skipped[p.k] = t0 + ns.GUIDE_SKIP end
        local until_ = skipped[p.k]
        if (not until_ or until_ < t0) and d2 < bd then bp, bd = p, d2 end
      end
    end
    if any and not bp then -- every spot visited: start over
      for _, p in ipairs(e.spots) do skipped[p.k] = nil end
      bp, bd = fp, fd
    end
    if bp then
      bd = math.sqrt(bd)
      if bd < best then best, t = bd, { e = e, p = bp, d = bd } end
    end
  end
  return t
end

-- One quest at a time (Louis, 8 Nov 13:35, the way RestedXP does it): once the guide picks a quest it stays on it until
-- that quest has nothing left here, instead of jumping to whatever else is nearest. Focus or /uw guide skip moves on.
local stick, sticky = nil, {}
function ns.GuideTarget(px, py, inst, list)
  list = list or needs or {}
  if stick then
    local n = 0
    for _, e in ipairs(list) do if e.quest == stick then n = n + 1; sticky[n] = e end end
    for k = n + 1, #sticky do sticky[k] = nil end
    local t = n > 0 and nearest(px, py, inst, sticky)
    if t then return t end
  end
  local t = nearest(px, py, inst, list)
  stick = t and t.e.quest or nil
  return t
end
function ns.GuideUnstick() stick = nil end

-- The arrow (Louis's live test, 8 Nov 05:25: Forever's client keeps the map pin but shows no on-screen marker for
-- it, so the guide draws its own, the way TomTom and RestedXP do). One small frame: the game's own minimap arrow
-- art turned toward the target, the name and yards under it in EllesmereUI's font. Light on purpose: it turns
-- at most 20 times a second, only while shown, allocates nothing per frame, and hides when there's nothing to
-- guide to, in instances, and while the pin is yours. Shift-drag moves it. /uw guide arrow: on, off, small,
-- large, faint (half see-through, for a calmer screen), bright. Saved in UW_GuildDB.guideArrow.
local current, paused, selfTrack, toldPause, started, claimed = nil, false, false, false, false, false
ns.GUIDE_ARROW_HZ = 20
ns.GUIDE_ARROW_SIZES = { small = 36, normal = 52, large = 72 }
local arrowFrame, arrowTurning
local function arrowCfg()
  local c = UW_GuildDB and UW_GuildDB.guideArrow
  if type(c) ~= "table" then c = {} if UW_GuildDB then UW_GuildDB.guideArrow = c end end
  return c
end
local function arrowShown() return arrowCfg().off ~= true end
local debugOn = false
local function arrowLog(k, v)
  if not UW_GuildDB then return end
  local p = UW_GuildDB.guideProbe or {}
  UW_GuildDB.guideProbe = p
  p.arrow = p.arrow or {}
  if p.arrow[k] == v then return end
  p.arrow[k] = v
  p.arrow.at = time()
  if debugOn then say(("UW guide debug: arrow %s = %s"):format(k, tostring(v))) end
end

local function styleArrow()
  local f = arrowFrame
  if not f then return end
  local c = arrowCfg()
  local size = ns.GUIDE_ARROW_SIZES[c.size or "normal"] or ns.GUIDE_ARROW_SIZES.normal
  f:SetSize(size, size)
  f:SetAlpha(c.faint and 0.5 or 0.9)
end

-- Our own 128 px arrow (Media\arrow.tga: white body, dark rim and soft shadow, tinted gold here), smoothed while it
-- turns; the game's 32 px minimap arrow if ours isn't loaded (a new media file needs a WoW restart), then a square.
local ART = "Interface\\AddOns\\UW_Guild\\Media\\arrow"
local function arrowArt(tex)
  local ok = tex:SetTexture(ART, nil, nil, "TRILINEAR")
  local which = "uw"
  if ok == false then ok = tex:SetTexture("Interface\\Minimap\\MinimapArrow"); which = "minimap" end
  if ok == false then tex:SetColorTexture(1, 0.82, 0, 0.9); which = "square" end
  if tex.SetSnapToPixelGrid then call(tex.SetSnapToPixelGrid, tex, false) end
  if tex.SetTexelSnappingBias then call(tex.SetTexelSnappingBias, tex, 0) end
  tex:SetVertexColor(1, 0.82, 0)
  arrowLog("art", which)
end

local function buildArrow()
  if arrowFrame or not CreateFrame then return arrowFrame end
  local f = CreateFrame("Frame", "UW_GuideArrow", g("UIParent"))
  f:SetFrameStrata("MEDIUM")
  f:SetClampedToScreen(true)
  local c = arrowCfg()
  f:SetPoint(c.point or "TOP", g("UIParent"), c.point or "TOP", c.x or 0, c.y or -150)
  f:SetMovable(true)
  f:EnableMouse(false) -- clicks pass through; Shift held turns dragging on (OnUpdate below)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", function(self) if call(g("IsShiftKeyDown")) then self:StartMoving() end end)
  f:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local point, _, _, x, y = self:GetPoint(1)
    local cfg = arrowCfg()
    cfg.point, cfg.x, cfg.y = point, x and math.floor(x + 0.5), y and math.floor(y + 0.5)
  end)
  f.tex = f:CreateTexture(nil, "ARTWORK")
  f.tex:SetAllPoints()
  arrowArt(f.tex)
  f.label = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  f.label:SetPoint("TOP", f, "BOTTOM", 0, -2)
  ns.Skin("Font", f.label)
  -- The quest it's for, under the name (Louis, 8 Nov 13:26: an NPC name alone didn't say which quest it was).
  f.quest = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  f.quest:SetPoint("TOP", f.label, "BOTTOM", 0, -1)
  ns.Skin("Font", f.quest)
  f.elapsed, f.lastYards, f.lastName = 0, -1, nil
  f:Hide()
  arrowFrame = f
  styleArrow()
  return f
end

-- Why the arrow last hid or showed, kept in UW_GuildDB.guideProbe.arrow (only when it changes, so it costs nothing
-- per frame), and said in chat while /uw guide test has debug on.
local function hideBecause(f, reason)
  f:Hide()
  arrowLog("hidden", reason)
end
local function isSecret(v) local s = g("issecretvalue") return s and s(v) or false end

local function arrowUpdate(f, elapsed)
  f.elapsed = f.elapsed + elapsed
  if f.elapsed < 1 / ns.GUIDE_ARROW_HZ then return end
  f.elapsed = 0
  f:EnableMouse(call(g("IsShiftKeyDown")) and true or false)
  local t, Q = current, nil
  if t then Q = questie() end
  if not t then hideBecause(f, "no target") return end
  if not Q then hideBecause(f, "no Questie") return end
  local facing = g("GetPlayerFacing") and call(g("GetPlayerFacing"))
  if type(facing) ~= "number" or isSecret(facing) then hideBecause(f, "facing " .. type(facing)) return end
  local px, py, inst = call(Q.hbd.GetPlayerWorldPosition, Q.hbd)
  if not px then hideBecause(f, "no position") return end
  if inst ~= t.p.inst then hideBecause(f, ("world %s, target in %s"):format(tostring(inst), tostring(t.p.inst))) return end
  local angle, yards = call(Q.hbd.GetWorldVector, Q.hbd, inst, px, py, t.p.wx, t.p.wy)
  if not angle then hideBecause(f, "no direction") return end
  arrowLog("hidden", nil)
  f.tex:SetRotation(angle - facing)
  yards = math.floor(yards + 0.5)
  if yards ~= f.lastYards or t.e.name ~= f.lastName then
    f.lastYards, f.lastName = yards, t.e.name
    f.label:SetFormattedText("%s  %d yd", t.e.name or "", yards)
    f.quest:SetText(t.e.key == "meet" and "" or (t.e.quest or ""))
  end
end

-- Shown when the guide has a target and you want the arrow; the frame only exists once it's first needed.
local function showArrow()
  if not current or not arrowShown() or not on() or paused then
    if arrowFrame then arrowFrame:Hide() end
    return
  end
  local f = buildArrow()
  if not f then return end
  if not arrowTurning then arrowTurning = true; f:SetScript("OnUpdate", arrowUpdate) end
  f:Show()
  arrowLog("shown", call(f.IsVisible, f) and "visible" or "not visible")
end
ns.GuideShowArrow = showArrow
function ns.GuideArrowFrame() return arrowFrame end

-- The pin: ours (the last one this guide set, kept per character so a reload still knows it), or someone else's.
local function samePoint(a, b)
  return a and b and a.map == b.map and math.abs(a.x - b.x) < 0.0005 and math.abs(a.y - b.y) < 0.0005
end
local function pinNow()
  local map = g("C_Map")
  local w = map and call(map.GetUserWaypoint)
  if type(w) ~= "table" or not w.position then return nil end
  return { map = w.uiMapID, x = w.position.x, y = w.position.y }
end
local function mine() return UW_GuildCharDB and UW_GuildCharDB.guidePin end

local function clearPin()
  local map = g("C_Map")
  if mine() and samePoint(pinNow(), mine()) and map then call(map.ClearUserWaypoint) end
  if UW_GuildCharDB then UW_GuildCharDB.guidePin = nil end
  current, claimed = nil, false
  if arrowFrame then arrowFrame:Hide() end
end
ns.GuideClear = clearPin

local function setPin(t)
  local map, sup, P = g("C_Map"), g("C_SuperTrack"), g("UiMapPoint")
  if not (map and P and type(map.SetUserWaypoint) == "function") then probe("pin", "no SetUserWaypoint") return end
  local m, x, y = t.p.map, t.p.x, t.p.y
  if map.CanSetUserWaypointOnMap and not call(map.CanSetUserWaypointOnMap, m) then
    -- The pin's map can't take one (a city or a sub-zone): put it on the map you're on, at the same world spot.
    local Q = questie()
    m = call(map.GetBestMapForUnit, "player")
    x, y = nil, nil
    if Q and m then x, y = call(Q.hbd.GetZoneCoordinatesFromWorld, Q.hbd, t.p.wx, t.p.wy, m, true) end
    if not x or not call(map.CanSetUserWaypointOnMap, m) then
      probe("pin", "no map takes it")
      current = t
      showArrow()
      return
    end
  end
  local point = call(P.CreateFromCoordinates, m, x, y)
  if not point then return end
  selfTrack = true
  call(map.SetUserWaypoint, point)
  if sup and not call(sup.IsSuperTrackingUserWaypoint) then call(sup.SetSuperTrackedUserWaypoint, true) end
  selfTrack = false
  UW_GuildCharDB.guidePin = { map = m, x = x, y = y }
  claimed = true
  current = t
  probe("pin", "set")
  showArrow()
  -- First contact: once per character, say what just appeared and how to stop it.
  if not UW_GuildCharDB.guideTold then
    UW_GuildCharDB.guideTold = time()
    say("UW guide set this map pin and arrow for your quest. /uw guide off to stop.")
  end
end

local function busy()
  if call(g("InCombatLockdown")) then return true end
  local inInstance = call(g("IsInInstance"))
  return inInstance and true or false
end

-- Meet point (Louis, 8 Nov 2026: "rally points for people in group ... synced"): /uw meet shares where you stand, or
-- your own map pin, with your group. Every groupmate's guide points there first, until they're within 20 yards, it's
-- 30 minutes old, or the sharer clears it. A party: anyone; a raid: the leader or an assist. Guild-wide (and from
-- Discord) needs nothing new: Shift-click your map pin into chat, and the game's link gives anyone the pin in one click.
ns.GUIDE_MEET_FOR = 1800
ns.GUIDE_MEET_GAP = 5     -- seconds between shares
local meet, sharedAt = nil, 0
-- Milliseconds from the game's profiling clock, or nil where it has none.
local function msNow() local f = g("debugprofilestop") if f then return call(f) end end
local function meetTarget(px, py, inst)
  if not meet then return nil end
  if now() - meet.at > ns.GUIDE_MEET_FOR or meet.p.inst ~= inst then meet = nil return nil end
  local d = dist(px, py, meet.p.wx, meet.p.wy)
  if d <= ns.GUIDE_REACHED then
    meet = nil
    say("You're at the meet point. The guide goes back to your quests.")
    return nil
  end
  return { e = meet.e, p = meet.p, d = d }
end

function ns.GuideTick()
  if call(g("IsInInstance")) and arrowFrame then arrowFrame:Hide() end
  if not on() or paused or busy() or not UW_GuildCharDB then return end
  local t0 = msNow()
  local pin = pinNow()
  if not started then
    -- After a login or reload: a pin of ours that the game didn't keep is simply gone, not cleared by you.
    started = true
    if mine() and not pin then UW_GuildCharDB.guidePin = nil end
  end
  -- A pin someone else placed (you, or another addon), before ours or since, or ours cleared: step aside.
  if (mine() and not samePoint(pin, mine())) or (not mine() and pin and not claimed) then
    paused = true
    if UW_GuildCharDB then UW_GuildCharDB.guidePin = nil end
    current = nil
    if arrowFrame then arrowFrame:Hide() end
    if not toldPause then
      toldPause = true
      say("You moved or cleared the map pin, so the quest guide stepped aside. /uw guide on brings it back.")
    end
    return
  end
  -- Reread after a quest log change, every few seconds while nothing was found (Questie fills its quest objects in a
  -- while after login), and every 30 seconds anyway.
  local age = now() - builtAt
  if ((dirty or not needs or #needs == 0) and age >= ns.GUIDE_REBUILD) or age >= ns.GUIDE_REREAD then
    local b0 = msNow()
    ns.GuideBuild()
    if b0 then probe("buildMs", math.floor(((msNow() or b0) - b0) * 100) / 100) end
  end
  local Q = questie()
  if not Q or not needs then return end
  local px, py, inst = call(Q.hbd.GetPlayerWorldPosition, Q.hbd)
  if not px then return end
  local t = meetTarget(px, py, inst) or ns.GuideTarget(px, py, inst)
  if t0 then probe("tickMs", math.floor(((msNow() or t0) - t0) * 100) / 100) end
  if not t then
    if current then clearPin() end
    return
  end
  if current and current.e.key == t.e.key and mine() and pin
    and dist(current.p.wx, current.p.wy, t.p.wx, t.p.wy) < ns.GUIDE_MOVE then
    current.d = t.d
    showArrow()
    return
  end
  if not (current and current.e == t.e) then ns.GuideWhy(t) end
  setPin(t)
end

-- Why this target, saved for Claude in UW_GuildDB.guideProbe.why each time the target changes (Louis, 8 Nov 13:42: we
-- check his saved data ourselves instead of asking him to retest): the quest as the log and Questie each see it,
-- and the game's own objectives and waypoint for it.
function ns.GuideWhy(t)
  if not (UW_GuildDB and t and t.e) then return end
  local e, log = t.e, g("C_QuestLog")
  local w = { at = time(), npc = e.name, key = e.key, quest = e.quest, id = e.qid, source = e.src,
    questieName = e.qn, questieReq = e.rl, questieLevel = e.ql, me = call(g("UnitLevel"), "player"),
    map = t.p.map, x = t.p.x and math.floor(t.p.x * 1000) / 10, y = t.p.y and math.floor(t.p.y * 1000) / 10 }
  if e.qid and type(log) == "table" then
    local idx = call(log.GetLogIndexForQuestID, e.qid)
    local info = idx and call(log.GetInfo, idx)
    if type(info) == "table" then w.logLevel, w.logDifficulty = plainNum(info.level), plainNum(info.difficultyLevel) end
    local gm, gx, gy = call(log.GetNextWaypoint, e.qid)
    w.gameWaypoint = plainNum(gm) and ("%s %.1f %.1f"):format(gm, (plainNum(gx) or 0) * 100, (plainNum(gy) or 0) * 100)
    local txt = call(log.GetNextWaypointText, e.qid)
    if type(txt) == "string" and not isSecretValue(txt) then w.gameWaypointText = txt end
    local objs = call(log.GetQuestObjectives, e.qid)
    if type(objs) == "table" then
      w.objectives = {}
      for _, o in ipairs(objs) do
        if type(o) == "table" and type(o.text) == "string" and not isSecretValue(o.text) then
          w.objectives[#w.objectives + 1] = o.text .. (o.finished and " (done)" or "")
        end
      end
    end
    w.complete = call(log.IsComplete, e.qid)
  end
  UW_GuildDB.guideProbe = UW_GuildDB.guideProbe or {}
  UW_GuildDB.guideProbe.why = w
  local past = type(UW_GuildDB.guideProbe.whyPast) == "table" and UW_GuildDB.guideProbe.whyPast or {}
  table.insert(past, 1, w)
  for k = #past, 6, -1 do past[k] = nil end -- the last 5 targets, so one that came and went can still be checked
  UW_GuildDB.guideProbe.whyPast = past
  return w
end

-- A guided NPC's nameplate: a line on screen. Only wanderers and friendly NPCs (a mob you're killing is already in
-- sight). No raid star: on Forever's client SetRaidTarget from an addon is a protected call (Louis's live test,
-- 8 Nov 06:37: blocked during right-click turning), so the guide never marks.
local foundAt = {}
local function npcIdOf(guid)
  local secret = g("issecretvalue")
  if type(guid) ~= "string" or (secret and secret(guid)) then return nil end
  local kind, id = guid:match("^(%a+)%-%d+%-%d+%-%d+%-%d+%-(%d+)")
  if kind == "Creature" or kind == "Vehicle" then return "m_" .. id end
end
function ns.GuideNameplate(unit)
  if not on() or not current then return end
  local e = current.e
  if not (#e.routes > 0 or e.friendly) then return end
  if npcIdOf(call(g("UnitGUID"), unit)) ~= e.key then return end
  if foundAt[e.key] and now() - foundAt[e.key] < ns.GUIDE_FOUND_AGAIN then return end
  foundAt[e.key] = now()
  local line = ("Found %s nearby."):format(e.name or "your quest NPC")
  say(line)
  local errs = g("UIErrorsFrame")
  if errs and errs.AddMessage then call(errs.AddMessage, errs, line, 1, 0.82, 0) end
  return line
end

-- /uw guide: what it points at, or why not. on / off.
local function status()
  if not on() then return "The quest guide is off. /uw guide on turns it on." end
  if paused then return "The quest guide stepped aside for your own map pin. /uw guide on brings it back." end
  if not questie() then return "The quest guide needs Questie from #addon-kit." end
  if busy() then return "The quest guide waits until you're out of combat and out of instances." end
  if not current then
    ns.GuideTick()
    if not current then return "Nothing to guide to: your tracked quests have no spots in Questie's data here." end
  end
  local e = current.e
  if e.key == "meet" then return ("Quest guide: the meet point from %s, %d yards."):format(meet and meet.from or "your group",
    math.floor(current.d + 0.5)) end
  return ("Quest guide: %s for %s, %d yards%s. /uw guide off stops it;"):format(e.name or "?", e.quest or "a quest",
    math.floor(current.d + 0.5), current.route and ", following its patrol route" or "")
    .. " /uw guide skip passes over it"
end
ns.GuideStatus = status

-- Where you are, or your own map pin, as the pin's map and 0-1 coordinates.
local function myPoint()
  local own = pinNow()
  if own and not samePoint(own, mine()) then return own.map, own.x, own.y end
  local map = g("C_Map")
  local m = map and call(map.GetBestMapForUnit, "player")
  local pos = m and call(map.GetPlayerMapPosition, m, "player")
  if type(pos) ~= "table" then return nil end
  local x, y = pos.x, pos.y
  if pos.GetXY then x, y = call(pos.GetXY, pos) end
  local secret = g("issecretvalue")
  if type(x) ~= "number" or type(y) ~= "number" or (secret and (secret(x) or secret(y))) or (x == 0 and y == 0) then return nil end
  return m, x, y
end

local function groupChannel()
  if call(g("IsInRaid")) then return "RAID" end
  if call(g("IsInGroup")) then return "PARTY" end
end
local function canLead(who)
  if not call(g("IsInRaid")) then return true end
  return call(g("UnitIsGroupLeader"), who) or call(g("UnitIsGroupAssistant"), who) or false
end

ns.commands.meet = function(args)
  local sub = strtrim(args or ""):lower()
  local channel = groupChannel()
  if sub == "off" then
    local had = meet
    meet = nil
    if channel and canLead("player") then ns.send("MEET\t0", channel) end
    say(had and "Meet point cleared." or "No meet point to clear.")
    return
  end
  if not channel then say("Meet points are for your group. Guild-wide: Shift-click your map pin into guild chat.") return end
  if not canLead("player") then say("In a raid, the leader or an assist sets the meet point.") return end
  if now() - sharedAt < ns.GUIDE_MEET_GAP then say("Just shared. Try again in a few seconds.") return end
  local m, x, y = myPoint()
  if not m then say("Can't read where you are here. Place a map pin and try /uw meet again.") return end
  sharedAt = now()
  ns.send(("MEET\t%d\t%.4f\t%.4f"):format(m, x, y), channel)
  say("Meet point shared with your group. Their markers point there now. /uw meet off clears it.")
end

ns.handlers.MEET = function(sender, channel, m, x, y)
  if channel ~= "PARTY" and channel ~= "RAID" then return end
  local who = ns.shortName(sender)
  if who == ns.shortName(ns.me() or "") then return end
  if not canLead(who) then return end
  if m == "0" then
    if meet and meet.from == who then meet = nil; say(who .. " cleared the meet point.") end
    return
  end
  m, x, y = tonumber(m), tonumber(x), tonumber(y)
  if not (m and x and y) or x < 0 or x > 1 or y < 0 or y > 1 then return end
  local Q = questie()
  local wx, wy, inst
  if Q then wx, wy, inst = call(Q.hbd.GetWorldCoordinatesFromZone, Q.hbd, x, y, m) end
  if not wx then return end
  meet = { from = who, at = now(), p = { wx = wx, wy = wy, inst = inst, map = m, x = x, y = y },
    e = { key = "meet", name = "Meet " .. who, quest = "your group", spots = {}, routes = {} } }
  if on() and not paused then
    say(who .. " set a meet point. Your marker points there now. /uw meet off ignores it.")
    ns.protect(ns.GuideTick)
  else
    say(who .. " set a meet point. /uw guide on lets your marker point there.")
  end
end

local function arrowCommand(word)
  local c = arrowCfg()
  if word == "off" then c.off = true
  elseif word == "on" then c.off = nil
  elseif word == "small" or word == "large" or word == "normal" then c.size = word ~= "normal" and word or nil
  elseif word == "faint" then c.faint = true
  elseif word == "bright" then c.faint = nil
  elseif word == "reset" then c.point, c.x, c.y = nil, nil, nil
    if arrowFrame then arrowFrame:ClearAllPoints(); arrowFrame:SetPoint("TOP", g("UIParent"), "TOP", 0, -150) end
  else
    say("/uw guide arrow on, off, small, normal, large, faint, bright, reset. Shift-drag the arrow to move it.")
    return
  end
  styleArrow()
  showArrow()
  say(("Guide arrow: %s, %s, %s."):format(c.off and "off" or "on", c.size or "normal", c.faint and "faint" or "bright"))
end

-- /uw guide test (Louis's live test, 8 Nov 05:38: "many tests at once with good logging"): one look at every step,
-- in chat and in UW_GuildDB.guideProbe.test, plus a test arrow in the middle of the screen for 15 seconds that
-- points north whatever the quests say. Seeing it means drawing works and the data is the problem; not seeing it
-- means drawing is the problem. Debug lines stay on until /reload.
local testFrame
function ns.GuideTest()
  debugOn = true
  local out = {}
  local function line(k, v) out[#out + 1] = k .. ": " .. tostring(v); UW_GuildDB.guideProbe = UW_GuildDB.guideProbe or {} end
  local Q = questie()
  line("questie", Q and "yes" or "no")
  line("guide", on() and (paused and "paused (your pin)" or "on") or "off")
  line("busy", busy() and "yes (combat or instance)" or "no")
  ns.GuideBuild()
  line("needs", needs and #needs or "none")
  line("from the game's quest map", UW_GuildDB.guideProbe and UW_GuildDB.guideProbe.fromGame or 0)
  line("Questie data for another quest (ignored)", UW_GuildDB.guideProbe and UW_GuildDB.guideProbe.mismatched or 0)
  line("quests read", UW_GuildDB.guideProbe and UW_GuildDB.guideProbe.quests or "?")
  if not current then ns.GuideTick() end
  line("target", current and ("%s, %d yd"):format(current.e.name or "?", math.floor(current.d + 0.5)) or "none")
  local pin = pinNow()
  line("map pin", pin and ("map %s %.3f %.3f%s"):format(tostring(pin.map), pin.x, pin.y, samePoint(pin, mine()) and " (ours)" or "") or "none")
  local facing = g("GetPlayerFacing") and call(g("GetPlayerFacing"))
  line("facing", type(facing) == "number" and not isSecret(facing) and ("%.2f"):format(facing) or type(facing))
  local px, py, inst
  if Q then px, py, inst = call(Q.hbd.GetPlayerWorldPosition, Q.hbd) end
  line("position", px and ("%d, %d in world %s"):format(px, py, tostring(inst)) or "none")
  if current and Q and px then
    local a, d = call(Q.hbd.GetWorldVector, Q.hbd, inst, px, py, current.p.wx, current.p.wy)
    line("direction", a and ("%.2f rad, %d yd (target world %s)"):format(a, d, tostring(current.p.inst)) or "none")
  end
  line("arrow setting", arrowShown() and "on" or "off")
  showArrow()
  line("arrow frame", arrowFrame and (call(arrowFrame.IsVisible, arrowFrame) and "visible" or "hidden") or "not built")
  -- The test arrow: same art, middle of the screen, pointing north.
  if not testFrame and CreateFrame then
    testFrame = CreateFrame("Frame", "UW_GuideArrowTest", g("UIParent"))
    testFrame:SetSize(64, 64)
    testFrame:SetPoint("CENTER", g("UIParent"), "CENTER", 0, 120)
    testFrame:SetFrameStrata("HIGH")
    testFrame.tex = testFrame:CreateTexture(nil, "ARTWORK")
    testFrame.tex:SetAllPoints()
    arrowArt(testFrame.tex)
    testFrame.label = testFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    testFrame.label:SetPoint("TOP", testFrame, "BOTTOM", 0, -4)
    testFrame.label:SetText("UW arrow test: points north")
    testFrame.elapsed = 0
    testFrame:SetScript("OnUpdate", function(self, e)
      self.elapsed = self.elapsed + e
      if self.elapsed < 0.05 then return end
      self.elapsed = 0
      local fa = call(g("GetPlayerFacing"))
      if type(fa) == "number" and not isSecret(fa) then self.tex:SetRotation(-fa) end
    end)
  end
  if testFrame then
    testFrame:Show()
    line("test arrow", call(testFrame.IsVisible, testFrame) and "visible" or "hidden")
    C_Timer.After(15, function() if testFrame then testFrame:Hide() end end)
  end
  UW_GuildDB.guideProbe.test = out
  UW_GuildDB.guideProbe.testAt = time()
  say("UW guide test (also saved for Claude at /reload):")
  for _, l in ipairs(out) do say("  " .. l) end
  say("A gold test arrow shows mid-screen for 15 seconds. Tell us: did you see it, and the guide arrow up top?")
end

ns.commands.guide = function(args)
  local sub = strtrim(args or ""):lower()
  local first, rest = sub:match("^(%S+)%s*(.-)$")
  if first == "arrow" then arrowCommand(rest) return end
  if first == "test" then ns.GuideTest() return end
  if sub == "" and not on() then sub = "on" end -- the guide's own word turns it on (Louis, 8 Nov: "off ... use that exact command")
  if sub == "skip" then
    if not (current and current.e) then say("The quest guide isn't pointing at anything to skip.") return end
    UW_GuildCharDB.guideSkip = UW_GuildCharDB.guideSkip or {}
    UW_GuildCharDB.guideSkip[current.e.key .. "|" .. tostring(current.e.quest)] = time()
    say(("Skipped %s for %s. /uw guide unskip brings skipped steps back."):format(current.e.name or "that step",
      current.e.quest or "this quest"))
    dirty, builtAt = true, 0
    ns.GuideTick()
    return
  elseif sub == "unskip" then
    UW_GuildCharDB.guideSkip = nil
    dirty, builtAt = true, 0
    ns.GuideTick()
    say("Skipped quest guide steps are back.")
    return
  end
  if sub == "off" then
    UW_GuildDB.guide = false
    clearPin()
    say("The quest guide is off and its pin is gone. /uw guide on brings it back.")
    return
  elseif sub == "on" then
    UW_GuildDB.guide = true
    ns.GuideUnstick()
    paused, toldPause, dirty, claimed = false, false, true, true
    ns.GuideTick()
    say("The quest guide is on: the map pin and marker point at your tracked quest's next step.")
    return
  end
  say(status())
end

local f = CreateFrame("Frame")
ns.listen(f, { "PLAYER_ENTERING_WORLD", "QUEST_LOG_UPDATE", "QUEST_WATCH_LIST_CHANGED", "SUPER_TRACKING_CHANGED",
  "ZONE_CHANGED_NEW_AREA", "NAME_PLATE_UNIT_ADDED", "PLAYER_TARGET_CHANGED" })
local ticker
f:SetScript("OnEvent", function(_, event, arg)
  if event == "NAME_PLATE_UNIT_ADDED" then ns.protect(ns.GuideNameplate, arg) return end
  if event == "PLAYER_TARGET_CHANGED" then ns.protect(ns.GuideNameplate, "target") return end
  if event == "SUPER_TRACKING_CHANGED" then
    if selfTrack then return end
    local sup = g("C_SuperTrack")
    local id = sup and call(sup.GetSuperTrackedQuestID)
    if type(id) == "number" and id > 0 then focus = id end
  end
  dirty = true
  if event == "PLAYER_ENTERING_WORLD" and not ticker and C_Timer and C_Timer.NewTicker then
    ticker = C_Timer.NewTicker(ns.GUIDE_EVERY, function() ns.protect(ns.GuideTick) end)
  end
end)

-- Tests: a fresh session, as after a login (the pins the guide knows of are forgotten).
function ns.GuideResetSession() current, paused, toldPause, started, claimed, meet = nil, false, false, false, false, nil end
