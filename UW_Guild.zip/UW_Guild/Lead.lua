-- Lead a group: one window with every tool an officer needs to see and direct grouping (Louis, 8 Nov 2026: "ensure I
-- have all the menus, tools, etc. necessary in a clean in game interface", worried about "giving hugely wrong vibes"
-- when grouping starts). /uw lead, or Lead a group on the options page. Officers had it first (CONTRIBUTING.md, gentle
-- rollouts, rule 4); any Raider opens it from Sat 14 Nov and any Member from Sat 21 Nov, each told the day before
-- (Louis, 8 Nov: no appointed leads, "any Raider who wants to lead, leads"; Members too, as recommended, since nobody
-- is 60 yet and Members lead the dungeon groups). Officer work stays with officers: the Notes tab, buddy pairing,
-- asking for job helpers, raid sign-ups and promoting Raiders.
--   * Who's on: online guildmates near your level, at 60 or all, with who answered your call and who signed up.
--   * Call a group: one guild-chat call; whoever says inv in the next 15 minutes is listed, and Invite next invites
--     one per press (an invite needs a click on the real client). Make it a raid, ready check, share the meet point.
--   * Raid: the next raid's sign-ups and bench, from the bot (the Guild Master's PC: Schedule.lua ns.RAID_ROSTER) and
--     the whisper sign-ups this client holds (Charter.lua). Invite signed-up and whisper the bench, one per press.
--   * Leads: pass the group lead or an assist, ask for guild job helpers, pair an online recruit with a buddy.
--   * Say: warm lines written ahead, in the guild's voice. A first click shows the line; a second sends it.
--   * Rehearse: practice guildmates, a practice raid and practice answers; nothing is sent or invited and no practice
--     name is saved, so the flows can be tried alone before a real test (rehearsal before a live run, as in
--     simulation training). The decision log notes only that a rehearsal ran.
-- Every action is an existing game call or /uw command; the window adds no message of its own to the addon protocol.
-- Answers to a call are read only for the 15 minutes after it, and only shown here (gentle rollouts, rule 6, as
-- /uw raiders does). This file writes nothing to UW_GuildDB but decision-log lines (ns.trace) and, through
-- WeekOne.lua, counts per night of calls, answers and asks (with who called or answered, kept on this PC only).
local _, ns = ...
local say = ns.say
-- Who opens /uw lead: officers always; then by rank index from a date (00:00 UTC), told the day before. Friend and
-- Trial (4, 5) are left out: anyone can still call a group by typing in guild chat.
ns.LEAD_OPEN = { [2] = { 1794614400, "Sat 14 Nov" },    -- Raider
  [3] = { 1795219200, "Sat 21 Nov" } }                    -- Member
local HEADSUP_AHEAD = 86400

-- 15 minutes, not 5 (Louis, 8 Nov: "we can't expect people to drop what they're doing"): time to finish a quest or a
-- flight first, so a call asks nothing of anyone mid-task.
ns.LEAD_CALL_WINDOW, ns.LEAD_CONFIRM, ns.LEAD_ROWS = 900, 6, 16 -- LEAD_ROWS: the most rows one page can show
local function g(name) return rawget(_G, name) end
local function now() return (GetServerTime and GetServerTime()) or time() end
local function officer() return ns.isOfficer(ns.me()) end
local function myRank()
  local full = ns.fullName(ns.me())
  return full and ns.rankOf[full]
end
local function opening() local r = myRank() return r and ns.LEAD_OPEN[r] end
-- May this character open /uw lead now? Officers always; others once their rank's date in LEAD_OPEN has passed.
function ns.MayLead()
  if officer() then return true end
  local o = opening()
  return o ~= nil and now() >= o[1]
end
-- The Call a group tab is open to Member and up now (Louis, 9 Nov 00:18: "member and above"), ahead of LEAD_OPEN's
-- dates for the rest of the window. Friend and Trial still call by typing in guild chat. Calling is what anyone can
-- already do there; the tab only adds a line for their level, the answers and one invite per click. A Discord link is
-- preferred, not required (most members never link): every call is a guild chat line under the caller's own name, and
-- moving someone to Friend takes the tab away.
ns.LEAD_CALL_MAX_RANK = 3 -- Member
function ns.MayCall()
  if officer() then return true end
  local r = myRank()
  return r ~= nil and r <= ns.LEAD_CALL_MAX_RANK
end
-- Which tabs this character sees: officers all; from their rank's date everything but officer work; else Call a group.
local function tabOpen(t)
  if officer() then return true end
  if ns.MayLead() then return not t.officer end
  return t[1] == "call" and ns.MayCall()
end
local function short(n) return ns.shortName(n) or n end
local function chat(sender, msg, channel, target) -- sender: a key in Outbound.lua (raid lines are off there)
  return ns.chat(sender, msg, channel, target) and true or false
end

-- Lines written ahead, in Louis's voice (8 Nov 2026, 22:22: "talking AT rather than WITH"). The bar is his own guild
-- line that night: "Big thank you to Cbipok, Deceiver, Flyhigh and Tyrone for bringing new friends into the guild!"
-- One short sentence, peer to peer, a question or an offer; no instructions beyond the one word that makes it work
-- (inv, raid), no pitch, no reassurance filler. Timers (the call's 15 minutes) stay in the addon, not in the line.
-- {key, button, where, text}. where: GUILD, GROUP (party or raid) or WHISPER (the name picked last in any list).
-- %s in a call is what it's for; {here} in a line is where you stand, so it reads the same with or without UW_Guild.
ns.LEAD_CALL = "Getting a group going for %s, who's in? Type inv here when you're free."
ns.LEAD_RAID_OPEN = "%s sign-ups are open, starting %s. Whisper me raid if you're coming!"
ns.LEAD_BENCH = "Thanks for signing up! We're full for now, so you're on the bench. I'll whisper you if a spot opens."
ns.LEAD_LINES = {
  { "full", "Group's full", "GUILD", "Group's full, thanks all! Next one soon." },
  { "help", "Offer a hand", "GUILD", "Anyone need a hand with a quest or dungeon? Happy to help." },
  { "welcome", "Welcome the group", "GROUP", "Welcome in! Ready check in a minute." },
  { "meet", "Meet point is set", "GROUP", "Meeting at {here}, come when you can." },
  { "break", "Short break", "GROUP", "Quick break, back in 5." },
  { "wipe", "After a wipe", "GROUP", "Good tries! Rebuff and we'll go again." },
  { "done", "End of the night", "GROUP", "That's a wrap, thanks for coming everyone!" },
  { "room", "Offer a spot", "WHISPER", "Hey, got a spot in my group if you want in!" },
  { "vet", "Ask to help", "WHISPER", "Hey! Getting a group going for some newer folks around your level, "
    .. "want to come along?" },
  -- In guild chat, 8 Nov: "the quests in the dungeons are where it's at". An offer to run some, never a lecture.
  { "why", "Dungeon run?", "GUILD", "Dungeon quests are great XP, anyone want to run some together?" },
}
-- A line as it goes out: {here} becomes "Crossroads, The Barrens" (or the zone alone).
function ns.LeadLineText(text)
  if not text:find("{here}", 1, true) then return text end
  local zone = GetZoneText and GetZoneText() or ""
  local sub = GetSubZoneText and GetSubZoneText() or ""
  if ns.isSecret(zone) then zone = "" end
  if ns.isSecret(sub) then sub = "" end
  local here = (sub ~= "" and sub ~= zone and zone ~= "") and (sub .. ", " .. zone) or (zone ~= "" and zone or "the meet point")
  return (text:gsub("{here}", function() return here end))
end

local L = { tab = "online", filter = "near", page = 1, rehearse = false, answers = {}, invited = {}, whispered = {},
  notes = {} }
ns.Lead = L
L.TabOpen = tabOpen
local frame -- the window, built on first open

-- Answers shown in the window too: the last few, newest last.
local function note(msg)
  say(msg)
  L.notes[#L.notes + 1] = msg
  while #L.notes > 3 do table.remove(L.notes, 1) end
  if L.refresh then L.refresh() end
end
L.note = note

-- In a rehearsal every action only says what it would do.
local function act(desc, fn)
  if L.rehearse then note("Rehearse: " .. desc) return true end
  return fn()
end

-- Rehearsal data: practice guildmates around your level, a practice raid with a bench, a practice group.
local function practiceRoster()
  local me = UnitLevel("player") or 20
  local rows = {}
  for i, p in ipairs({ { "Ada Vale", 0, "PRIEST" }, { "Brann Holt", 1, "WARRIOR" }, { "Cora Finch", -2, "MAGE" },
    { "Dax Morrow", 2, "ROGUE" }, { "Elle Quill", 0, "DRUID" }, { "Finn Rook", -1, "HUNTER" },
    { "Gale Pike", nil, "SHAMAN" }, { "Hale Stone", nil, "WARLOCK" }, { "Iris Thorn", nil, "PALADIN" },
    { "Kael Moss", nil, "MAGE" } }) do
    local lvl = p[2] and math.max(1, math.min(60, me + p[2])) or 60
    rows[i] = { name = p[1] .. " (practice)", full = p[1] .. " (practice)", level = lvl, cls = p[3],
      zone = lvl == 60 and "Orgrimmar" or "The Barrens", rank = i == 7 and 2 or 3, rankName = i == 7 and "Raider" or "Member" }
  end
  return rows
end
local function practiceRaid(at)
  local n = function(s) return s .. " (practice)" end
  return { start = at + 2 * 3600, title = "Practice raid", cap = { 2, 2, 6 }, size = 10, unlinked = 1, asOf = at,
    list = { { n("Brann Holt"), "t", "in" }, { n("Iris Thorn"), "t", "in" }, { n("Ada Vale"), "h", "in" },
      { n("Elle Quill"), "h", "in" }, { n("Cora Finch"), "d", "in" }, { n("Dax Morrow"), "d", "in" },
      { n("Finn Rook"), "d", "in" }, { n("Gale Pike"), "d", "in" }, { n("Hale Stone"), "d", "in" },
      { n("Jory Lane"), "d", "in" }, { n("Kael Moss"), "d", "bench" }, { n("Lark Penn"), "h", "bench" },
      { n("Mara Dune"), "d", "maybe" } },
    whispered = { { n("Nell Brook"), "d" } } }
end
local PRACTICE_GROUP = { "Gale Pike (practice)", "Iris Thorn (practice)", "Dax Morrow (practice)" }

-- Who's on ---------------------------------------------------------------------------------------------------------
local function roster()
  if L.rehearse then return practiceRoster() end
  local rows, self = {}, ns.me()
  for i = 1, GetNumGuildMembers() or 0 do
    local full, rankName, rank, level, _, zone, _, _, online, status, cls = GetGuildRosterInfo(i)
    full = ns.fullName(full)
    if full and online and full ~= self and type(level) == "number" and not ns.isSecret(level) then
      rows[#rows + 1] = { name = short(full), full = full, level = level, cls = type(cls) == "string" and cls or nil,
        busy = ns.RosterBusy and ns.RosterBusy(status, zone) or nil,
        zone = type(zone) == "string" and not ns.isSecret(zone) and zone or "?", rank = rank,
        rankName = type(rankName) == "string" and not ns.isSecret(rankName) and rankName or "" }
    end
  end
  return rows
end

-- Names in my group, by the roster's spelling (Forever's UnitName gives the parts; ns.unitFull joins them).
local function groupNames()
  local out = {}
  if L.rehearse then
    for _, n in ipairs(PRACTICE_GROUP) do out[n] = true end
    return out
  end
  local raid = IsInRaid()
  for i = 1, GetNumGroupMembers() or 0 do
    local full = ns.unitFull(raid and ("raid" .. i) or ("party" .. i))
    if full then out[short(full)] = true end
  end
  return out
end

local function calledRecently() return L.call and now() - L.call.at < ns.LEAD_CALL_WINDOW end

-- Online guildmates for the list: near (your level +-NEAR_RANGE), sixty (level 60), called (answered your call),
-- or all. Nearest level first, then by name.
function L.Online(filter)
  filter = filter or L.filter
  local mine, range = UnitLevel("player") or 1, (ns.NEAR_RANGE or 3) + 2
  local signed = {}
  local raid = L.Raid()
  for _, p in ipairs(raid and raid.people or {}) do signed[p.name] = p end
  local answered = {}
  for _, a in ipairs(L.answers) do answered[a.name] = true end
  local out = {}
  for _, r in ipairs(roster()) do
    local keep = filter == "all" or (filter == "near" and math.abs(r.level - mine) <= range)
      or (filter == "sixty" and r.level >= 60) or (filter == "called" and answered[r.name])
    if keep then
      r.answered, r.signed = answered[r.name], signed[r.name]
      out[#out + 1] = r
    end
  end
  -- Free first (render pass, 9 Nov 2026): AFK, Do Not Disturb and mid-dungeon guildmates go last, marked.
  table.sort(out, function(a, b)
    if (a.busy ~= nil) ~= (b.busy ~= nil) then return a.busy == nil end
    local da, db = math.abs(a.level - mine), math.abs(b.level - mine)
    if da ~= db then return da < db end
    return a.name < b.name
  end)
  return out
end

-- Online short names, for the raid and call lists.
local function onlineSet()
  local out = {}
  for _, r in ipairs(roster()) do out[r.name] = r end
  return out
end

-- Invites ----------------------------------------------------------------------------------------------------------
local function invite(name, full)
  if L.invited[name] then note(("%s has an invite from you already."):format(name)) return false end
  local ok = act(("would invite %s."):format(name), function()
    local fn = (g("C_PartyInfo") and g("C_PartyInfo").InviteUnit) or g("InviteUnit")
    local sent = type(fn) == "function" and pcall(fn, full or name) or false
    ns.trace("lead", "invite", sent, not sent and "the game refused the invite" or nil, name)
    note(sent and ("Invited %s."):format(name) or ("The game didn't send %s an invite."):format(name))
    return sent
  end)
  if ok then L.invited[name] = now() end -- a refused invite can be tried again
  return ok
end
L.invite = invite

-- The next online name from list (short names, in order) who isn't grouped or invited already: one per press.
local function inviteNext(list, what)
  local on, grouped = onlineSet(), groupNames()
  for _, name in ipairs(list) do
    if on[name] and not grouped[name] and not L.invited[name] then return invite(name, on[name].full) end
  end
  note(("Nobody left to invite from %s: everyone is grouped, invited or offline."):format(what))
  return false
end

-- Call a group -------------------------------------------------------------------------------------------------------
local armed -- { key, until }: a first click shows a line, a second one sends it
-- place: where it goes ("guild chat"); text: the line itself, shown on its own so it reads as members will see it.
local function confirm(key, place, text)
  if armed and armed[1] == key and GetTime() <= armed[2] then armed = nil return true end
  armed = { key, GetTime() + ns.LEAD_CONFIRM }
  note(("Click again within %d s to %s:"):format(ns.LEAD_CONFIRM, place))
  if text then note(text) end
  return false
end
L.confirm = confirm

function L.CallText(what)
  what = strtrim(what or ""):gsub("[|\n]", "")
  if what == "" then what = "a dungeon" end
  return ns.LEAD_CALL:format(what:sub(1, 40))
end

-- Suggested call (8 Nov; Louis asked what "newcomers online with no guild group seen yet" is for; 23:22 priority 1 is
-- a first dungeon for every newcomer): the dungeon whose level range holds the most online newcomers WeekOne.lua
-- hasn't seen in a dungeon with a guildmate, at least 2, leaving out anyone inside an instance now. A call that names
-- the dungeon and its levels is a concrete plan people can say yes to, and lets everyone else tell at a glance it isn't
-- for them; one line in guild chat reaches them all with no addon on their side, and nobody is whispered. A tie goes to
-- the dungeon whose range centres closest on their levels: at the top of a range a run is quick but gives little (grey
-- loot, low XP), at the bottom it's a struggle; the middle is the run a first-timer enjoys. Returns { what = "Wailing Caverns (15-24)", name, n, lo, hi, names,
-- waiting }, lo-hi being the newcomers' own levels (for helpers), or nil.
ns.LEAD_SUGGEST_AT_LEAST = 2
-- Horde 5-player dungeons, low to high, with Forever's suggested levels: its group finder's ranges as listed by two
-- guides that agree (Warcraft Tavern's says they match the in-game tool), Forever's nine new dungeons included (addon
-- search, 13 Nov 2026; Hall of Thanes left out, as Horde rarely go under Ironforge). On a client whose group finder
-- answers, WeekOne.lua's ns.LearnGameDungeons puts the game's own numbers in these rows. Same list as
-- bot/uwbot/dungeons.py (/lfg); bot/tests/test_dungeons.py keeps the two the same.
ns.LEAD_DUNGEONS = {
  { "Ragefire Chasm", 13, 18 }, { "Ruins of Lordaeron", 15, 22 }, { "Wailing Caverns", 15, 24 },
  { "Shadowfang Keep", 20, 30 }, { "Blackfathom Deeps", 24, 32 }, { "Excavation Site", 26, 33 },
  { "City of Dalaran", 28, 35 }, { "Razorfen Kraul", 29, 38 }, { "Gnomeregan", 29, 38 },
  { "Scarlet Monastery: Graveyard", 30, 38 }, { "Scarlet Monastery: Library", 33, 41 }, { "The Drowned City", 35, 42 },
  { "Scarlet Monastery: Armory", 36, 44 }, { "Razorfen Downs", 37, 46 }, { "Scarlet Monastery: Cathedral", 38, 46 },
  { "Krol'dok Stronghold", 40, 47 }, { "Uldaman", 41, 51 }, { "Zul'Farrak", 44, 54 }, { "Maraudon", 46, 55 },
  { "Alcaz Prison", 48, 55 }, { "Sunken Temple", 50, 60 }, { "Blackrock Depths", 52, 60 },
  { "Dire Maul: East", 54, 60 }, { "Lower Blackrock Spire", 55, 60 }, { "Blackmaw Hold", 55, 60 },
  { "Dire Maul: West", 56, 60 }, { "Dire Maul: North", 56, 60 }, { "Shaper's Terrace", 58, 60 },
  { "Stratholme: Live", 58, 60 }, { "Stratholme: Undead", 58, 60 }, { "Scholomance", 58, 60 },
  { "Upper Blackrock Spire", 59, 60 },
}
-- For anyone without the newcomer list (WeekOne.lua shows it to officers and buddies): the dungeon for my own level,
-- the range centred closest on it. { what, name, n = 0, mine = true }, or nil below the first dungeon.
function L.ForMe()
  local mine, best = UnitLevel("player") or 0, nil
  for _, d in ipairs(ns.LEAD_DUNGEONS) do
    local off = math.abs((d[2] + d[3]) / 2 - mine)
    if mine >= d[2] and mine <= d[3] and (not best or off < best.off) then
      best = { off = off, n = 0, mine = true, name = d[1], what = ("%s (%d-%d)"):format(d[1], d[2], d[3]) }
    end
  end
  return best
end

-- The planned call (WeekOne.lua ns.WeekOnePlan): the dungeon and the hour, by the officer's own clock, when the most
-- newcomers who haven't grouped have been on. Members never see a time (Forever has no time zones).
function L.Plan()
  if L.rehearse or not (ns.WeekOnePlan and ns.WeekOneHelper and ns.WeekOneHelper()) then return nil end
  local p = ns.WeekOnePlan()
  if p then p.what = ("%s (%d-%d)"):format(p.name, p.dlo, p.dhi) end
  return p
end

-- names: the waiting newcomers in the range; waiting: every waiting newcomer (so helpers leave them all out).
function L.Suggest()
  local rows = {}
  if L.rehearse then
    for _, r in ipairs(practiceRoster()) do if r.level < 60 and r.rank ~= 2 then rows[#rows + 1] = r end end
  elseif ns.WeekOneWaiting and ns.WeekOneHelper and ns.WeekOneHelper() then
    for _, e in ipairs(ns.WeekOneWaiting()) do rows[#rows + 1] = e.row end
  end
  local best
  for _, d in ipairs(ns.LEAD_DUNGEONS) do
    local n, sum, a, b, names = 0, 0, nil, nil, {}
    for _, r in ipairs(rows) do
      local l = r.level
      if l >= d[2] and l <= d[3] and not (ns.IsInstanceZone and ns.IsInstanceZone(r.zone)) then
        n, sum, a, b = n + 1, sum + l, math.min(a or l, l), math.max(b or l, l)
        names[#names + 1] = r.name
      end
    end
    if n >= ns.LEAD_SUGGEST_AT_LEAST then
      local off = math.abs((d[2] + d[3]) / 2 - sum / n)
      if not best or n > best.n or (n == best.n and off < best.off) then
        best = { n = n, off = off, lo = a, hi = b, names = names, name = d[1],
          what = ("%s (%d-%d)"):format(d[1], d[2], d[3]) }
      end
    end
  end
  if not best then return nil end
  best.waiting = {}
  for _, r in ipairs(rows) do best.waiting[r.name] = true end
  return best
end

-- Helpers for a suggested call (8 Nov: 11 of 152 newcomers had a first dungeon with a guildmate): guildmates online
-- at or a little above those levels who aren't waiting newcomers themselves and aren't in a dungeon now, closest level
-- first. A newcomer's first run goes better with someone who knows the way; the officer asks them, two clicks each.
ns.LEAD_HELP_BELOW, ns.LEAD_HELP_ABOVE = 1, 5
function L.Helpers(s)
  if not s then return {} end
  local out, mid = {}, (s.lo + s.hi) / 2
  for _, r in ipairs(roster()) do
    if not s.waiting[r.name] and r.level >= s.lo - ns.LEAD_HELP_BELOW and r.level <= s.hi + ns.LEAD_HELP_ABOVE
      and not (ns.IsInstanceZone and ns.IsInstanceZone(r.zone)) then
      out[#out + 1] = r
    end
  end
  table.sort(out, function(a, b)
    local da, db = math.abs(a.level - mid), math.abs(b.level - mid)
    if da ~= db then return da < db end
    return a.name < b.name
  end)
  return out
end

-- The ask the Call box holds (render pass 3, 14 Nov): { name, what, at } after a click on a guildmate's ask, so the
-- tab names it instead of offering the caller's own suggestion, which would overwrite the asker's levels. Typing
-- something else, Use suggestion or a sent call ends it.
local function boxAsk()
  local k = L.forAsk
  if k and (k.what ~= L.what or now() - k.at > ns.ASK_KEEP) then L.forAsk, k = nil, nil end
  return k
end

function L.UseSuggestion()
  L.forAsk = nil
  local s = L.Suggest() or (not officer() and L.ForMe())
  if not s then
    note(("No suggestion now: it needs %d newcomers online in one dungeon's levels.")
      :format(ns.LEAD_SUGGEST_AT_LEAST))
    return false
  end
  L.what = s.what
  if frame and frame.input then frame.input:SetText(s.what) end
  if not L.rehearse then
    ns.trace("lead", "suggest", true, s.mine and ("my level, %s"):format(s.name)
      or ("%d newcomers, %s"):format(s.n, s.name))
  end
  return true
end

local practiceToken = 0
function L.Call(what)
  local text = L.CallText(what)
  if calledRecently() then
    note(("Your call is open %d more min. Invite next takes the next answer."):format(
      math.ceil((ns.LEAD_CALL_WINDOW - (now() - L.call.at)) / 60)))
    return false
  end
  -- In Rehearse the prompt says so: "say in guild chat" read as real on Louis's run (8 Nov).
  if not confirm("call", L.rehearse and "practice the call (nothing goes to guild chat)" or "say in guild chat", text)
    then return false end
  if not L.rehearse and not chat("lead.call", text, "GUILD") then
    ns.trace("lead", "call", false, "the game didn't send it")
    note("The game didn't send it.")
    return false
  end
  if not L.rehearse then
    ns.trace("lead", "call", true)
    if ns.WeekOneNight then ns.WeekOneNight("c", ns.me()) end -- groups per night (WeekOne.lua), counts only
  end
  L.call, L.answers, L.forAsk = { at = now(), text = text }, {}, nil
  L.tab, L.filter, L.page = "call", "called", 1
  if L.rehearse then
    note("Rehearse: called in guild chat. Practice answers come in the next few seconds.")
    practiceToken = practiceToken + 1
    local token, rows = practiceToken, practiceRoster()
    for i = 1, 3 do
      ns.after(2 * i, function()
        if token ~= practiceToken or not L.rehearse then return end
        L.answers[#L.answers + 1] = { name = rows[i].name, at = now() }
        note(("%s said inv."):format(rows[i].name))
      end)
    end
  else
    note("Called in guild chat. Answers show here for 15 minutes.")
  end
  return true
end

-- An answer: a short guild line with inv, invite or + in it, or just "x", "in", "im in" or "count me in", inside the
-- call's window, once per person. Not a layer swap ("inv layer pls") and not someone's own group call ("lf2m wc
-- tank+heals"). Not a bare "me": in a busy guild chat it answers someone else's question as often ("who has a bag?").
local ANSWER = { inv = true, invite = true }
local ANSWER_LINE = { x = true, ["im in"] = true, ["in"] = true, ["count me in"] = true }
-- True for a line that answers a call (the rule above), whoever made the call.
function ns.IsCallAnswer(msg)
  if type(msg) ~= "string" or ns.isSecret(msg) or #msg > 40 then return false end
  if ns.ReadAsk(msg) then return false end -- someone's own ask, group or call, not an answer
  local words = ns.AskWords(msg)
  local hit = msg:find("+", 1, true) ~= nil or ANSWER_LINE[table.concat(words, " ")] or false
  for _, w in ipairs(words) do
    if w == "layer" or w == "layers" then return false end
    hit = hit or ANSWER[w] or false
  end
  return hit and #words <= 5 or false
end
function L.Heard(msg, sender)
  if L.rehearse or not calledRecently() or type(msg) ~= "string" or ns.isSecret(msg) then return false end
  if type(sender) ~= "string" or ns.isSecret(sender) then return false end
  local name = short(sender)
  if name == short(ns.me() or "") then return false end
  if not ns.IsCallAnswer(msg) then return false end
  for _, a in ipairs(L.answers) do if a.name == name then return false end end
  L.answers[#L.answers + 1] = { name = name, at = now() }
  if ns.WeekOneNight then
    ns.WeekOneNight("a", sender)
    if #L.answers == 1 then ns.WeekOneNight("ca", nil, L.call and now() - L.call.at) end -- my call drew an answer
  end
  if L.refresh then L.refresh() end
  return true
end

function L.InviteAnswers()
  local names = {}
  for _, a in ipairs(L.answers) do names[#names + 1] = a.name end
  -- With no call open there can be no answers: say what comes first (Louis's Rehearse run, 8 Nov: Call clicked once).
  if #names == 0 then
    note(calledRecently() and "No answers yet." or "No call open: click Call twice first, then answers show here.")
    return false
  end
  return inviteNext(names, "the answers")
end

local function leading()
  if L.rehearse then return true end
  if not IsInGroup() then return true end
  return UnitIsGroupLeader("player") or false
end

function L.MakeRaid()
  return act("would turn the group into a raid.", function()
    if IsInRaid() then note("Already a raid.") return false end
    if not IsInGroup() then note("Invite someone first: a raid starts from a group.") return false end
    if not UnitIsGroupLeader("player") then note("Only the group leader can make it a raid.") return false end
    local fn = (g("C_PartyInfo") and g("C_PartyInfo").ConvertToRaid) or g("ConvertToRaid")
    return type(fn) == "function" and pcall(fn) and true or false
  end)
end

function L.ReadyCheck()
  return act("would start a ready check.", function()
    if not IsInGroup() then note("Ready checks are for groups.") return false end
    local fn = g("DoReadyCheck")
    return type(fn) == "function" and pcall(fn) and true or false
  end)
end

function L.Meet()
  return act("would share your spot as the meet point. Your group's arrows point there.", function()
    SlashCmdList.UWGUILD("meet")
    return true
  end)
end

-- Raid ---------------------------------------------------------------------------------------------------------------
local ROLE_WORD = { t = "Tank", h = "Healer", d = "DPS", tank = "Tank", healer = "Healer", dps = "DPS" }
local ROLE_KEY = { tank = "t", healer = "h", dps = "d" }

local function startsIn(secs)
  local d, h = math.floor(secs / 86400), math.floor(secs % 86400 / 3600)
  if d > 0 then return ("in %d day%s"):format(d, d == 1 and "" or "s") end
  if h > 0 then return ("in %d h %d min"):format(h, math.floor(secs % 3600 / 60)) end
  return ("in %d min"):format(math.max(1, math.floor(secs / 60)))
end
L.startsIn = startsIn

-- The next raid and everyone on it: { start, title, cap, size, unlinked, asOf, fromBot, people = { {name, role,
-- place} } }. Places: in, bench, maybe, new (whispered since the bot last wrote the file), out. Bot rows first, in its
-- order; a whisper newer than the file wins for that name (raid out takes them off).
function L.Raid()
  if L.rehearse then
    local r = practiceRaid(L.practiceAt or now())
    L.practiceAt = L.practiceAt or now()
    r.people = {}
    for _, p in ipairs(r.list) do r.people[#r.people + 1] = { name = p[1], role = p[2], place = p[3] } end
    for _, p in ipairs(r.whispered) do r.people[#r.people + 1] = { name = p[1], role = p[2], place = "new" } end
    r.fromBot = true
    return r
  end
  local held = ns.ScheduleNow and ns.ScheduleNow()
  local at, ev = now(), nil
  for _, e in ipairs(held and held.ev or {}) do
    if e[3] == "raid" and e[2] > at then ev = e break end
  end
  if not ev then return nil end
  local r = { start = ev[1], title = ev[5], going = ev[4], cap = { 0, 0, 0 }, size = 0, unlinked = 0, people = {} }
  local gen = type(ns.SCHEDULE) == "table" and ns.finite(ns.SCHEDULE.gen) or 0
  local index = {}
  for _, x in ipairs(type(ns.RAID_ROSTER) == "table" and ns.RAID_ROSTER or {}) do
    if type(x) == "table" and x.ev == ev[1] and gen > 0 then
      r.fromBot, r.asOf = true, gen
      r.cap = type(x.cap) == "table" and x.cap or r.cap
      r.size, r.unlinked = ns.finite(x.size) or 0, ns.finite(x.unlinked) or 0
      for _, p in ipairs(type(x.list) == "table" and x.list or {}) do
        if type(p) == "table" and type(p[1]) == "string" then
          r.people[#r.people + 1] = { name = p[1], role = p[2], place = p[3] }
          index[p[1]] = #r.people
        end
      end
    end
  end
  -- Whispers this client holds for this raid, the latest per name; only those newer than the bot's file change it.
  local latest = {}
  for _, e in ipairs(type(UW_GuildDB) == "table" and type(UW_GuildDB.raidSignups) == "table" and UW_GuildDB.raidSignups or {}) do
    if type(e) == "table" and e.ev == ev[1] and type(e.n) == "string" then
      local cur = latest[e.n]
      if not cur or (tonumber(e.at) or 0) >= (tonumber(cur.at) or 0) then latest[e.n] = e end
    end
  end
  local names = {}
  for n in pairs(latest) do names[#names + 1] = n end
  table.sort(names, function(a, b) return (tonumber(latest[a].at) or 0) < (tonumber(latest[b].at) or 0) end)
  for _, n in ipairs(names) do
    local e = latest[n]
    if (tonumber(e.at) or 0) > gen or not index[n] then
      local p = { name = n, role = ROLE_KEY[e.r or ""] or "d", place = e.out and "out" or "new" }
      if index[n] then
        if e.out then r.people[index[n]].place = "out" else r.people[index[n]].role = p.role end
      else
        r.people[#r.people + 1] = p
        index[n] = #r.people
      end
    end
  end
  return r
end

function L.RaidCounts(r)
  local c = { t = 0, h = 0, d = 0, bench = 0, maybe = 0, new = 0, out = 0 }
  for _, p in ipairs(r and r.people or {}) do
    if p.place == "in" then c[p.role] = (c[p.role] or 0) + 1
    elseif c[p.place] then c[p.place] = c[p.place] + 1 end
  end
  return c
end

local function inPlace(r, place)
  local out = {}
  for _, p in ipairs(r and r.people or {}) do if p.place == place then out[#out + 1] = p.name end end
  return out
end

function L.InviteRaid()
  local r = L.Raid()
  if not r then note("No raid in the schedule yet.") return false end
  local list = inPlace(r, "in")
  for _, n in ipairs(inPlace(r, "new")) do list[#list + 1] = n end
  return inviteNext(list, "the sign-ups")
end

-- The next benched name online who hasn't heard from you: the bench line, one per press.
function L.WhisperBench()
  local r = L.Raid()
  local on = onlineSet()
  for _, name in ipairs(inPlace(r, "bench")) do
    if on[name] and not L.whispered[name] and not (ns.quiet and ns.quiet(name)) then
      L.whispered[name] = true
      if L.rehearse then note(("Rehearse: would whisper %s:"):format(name)) note(ns.LEAD_BENCH) return true end
      local ok = chat("lead.bench", ns.LEAD_BENCH, "WHISPER", on[name].full)
      note(ok and ("Whispered %s the bench line."):format(name) or "The game didn't send it.")
      return ok
    end
  end
  note("Nobody on the bench to whisper: they're offline or heard from you already.")
  return false
end

function L.RaidOpenText(r)
  return ns.LEAD_RAID_OPEN:format(r.title, startsIn(r.start - now()))
end

function L.AnnounceRaid()
  local r = L.Raid()
  if not r then note("No raid in the schedule yet: post it in Discord first.") return false end
  local text = L.RaidOpenText(r)
  if not confirm("raidopen", "say in guild chat", text) then return false end
  return act("would say it in guild chat.", function()
    local ok = chat("lead.raidopen", text, "GUILD")
    note(ok and "Said in guild chat." or "The game didn't send it.")
    return ok
  end)
end

function L.AskRaiders()
  if L.rehearse then note("Rehearse: would ask in guild chat:") note(ns.RAIDERS_ASK) return true end
  return ns.RaidersAsk()
end
function L.PromoteRaiders()
  return act("would list who said raid, with the Promote button.", function() ns.RaidersList() return true end)
end

-- Leads --------------------------------------------------------------------------------------------------------------
-- My group's units other than me: { unit, name, leader, assist }.
function L.Group()
  local out = {}
  if L.rehearse then
    for i, n in ipairs(PRACTICE_GROUP) do out[i] = { unit = "party" .. i, name = n } end
    return out
  end
  local raid = IsInRaid()
  for i = 1, GetNumGroupMembers() or 0 do
    local unit = raid and ("raid" .. i) or ("party" .. i)
    local full = ns.unitFull(unit)
    if full and full ~= ns.me() then
      out[#out + 1] = { unit = unit, name = short(full), leader = UnitIsGroupLeader(unit) or nil,
        assist = UnitIsGroupAssistant(unit) or nil }
    end
  end
  return out
end

function L.MakeLeader(m)
  if not confirm("leader " .. m.name, ("make %s the group leader"):format(m.name)) then return false end
  return act(("would make %s the group leader."):format(m.name), function()
    if not leading() then note("Only the group leader can pass the lead.") return false end
    local fn = g("PromoteToLeader")
    local ok = type(fn) == "function" and pcall(fn, m.unit)
    if ok then note(("%s leads the group now."):format(m.name)) end
    return ok and true or false
  end)
end

function L.MakeAssist(m)
  return act(("would make %s a raid assist."):format(m.name), function()
    if not IsInRaid() then note("Assists are for raids: Make it a raid first.") return false end
    if not leading() then note("Only the raid leader can make assists.") return false end
    local fn = g("PromoteToAssistant")
    local ok = type(fn) == "function" and pcall(fn, m.unit)
    if ok then note(("%s is an assist now."):format(m.name)) end
    return ok and true or false
  end)
end

function L.AskHelpers()
  if L.rehearse then note("Rehearse: would ask in guild chat:") note(ns.JOBS_ASK) return true end
  SlashCmdList.UWGUILD("jobs ask")
  return true
end

-- Online recruits without a buddy, each with the online guildmate closest in level who isn't a recruit (the same
-- pairing an officer types as /uw buddy Recruit Buddy).
function L.Unpaired()
  local rows, out = roster(), {}
  local buddies = type(UW_GuildDB) == "table" and type(UW_GuildDB.buddies) == "table" and UW_GuildDB.buddies or {}
  local isNew = function(r)
    if L.rehearse then return r.name:find("^Cora") ~= nil end
    return ns.isRecruit(r.name)
  end
  for _, r in ipairs(rows) do
    if isNew(r) and not buddies[r.name] then
      local best
      for _, v in ipairs(rows) do
        if v ~= r and not isNew(v) and (not best or math.abs(v.level - r.level) < math.abs(best.level - r.level)) then
          best = v
        end
      end
      out[#out + 1] = { recruit = r, buddy = best }
    end
  end
  return out
end

function L.Pair(p)
  if not p.buddy then note(("Nobody online to pair with %s yet."):format(p.recruit.name)) return false end
  if not confirm("pair " .. p.recruit.name, ("make %s %s's buddy"):format(p.buddy.name, p.recruit.name)) then
    return false
  end
  return act(("would pair %s with %s."):format(p.recruit.name, p.buddy.name), function()
    SlashCmdList.UWGUILD(("buddy %s %s"):format(p.recruit.name, p.buddy.name))
    return true
  end)
end

-- Say ----------------------------------------------------------------------------------------------------------------
local function groupChannel()
  if L.rehearse then return "PARTY" end
  if IsInRaid() then return "RAID" end
  if IsInGroup() then return "PARTY" end
end

function L.Say(entry)
  local where = entry[3]
  local channel, target = where, nil
  if where == "GROUP" then
    channel = groupChannel()
    if not channel then note("You're not in a group.") return false end
  elseif where == "WHISPER" then
    target = L.target
    if not target then note("Pick a name first: click one on Who's on, Call or Raid.") return false end
  end
  local place = target and ("whisper to " .. short(target)) or (channel == "GUILD" and "guild chat" or "group chat")
  local text = ns.LeadLineText(entry[4])
  if not confirm("say " .. entry[1], "send it to " .. place, text) then return false end
  return act(("would send it to %s."):format(place), function()
    local ok = chat("lead.line", text, channel, target)
    ns.trace("lead", "say " .. entry[1], ok, not ok and "the game didn't send it" or nil)
    note(ok and ("Sent to %s."):format(place) or "The game didn't send it.")
    return ok
  end)
end

-- Rehearse -----------------------------------------------------------------------------------------------------------
function L.SetRehearse(on)
  L.rehearse = on and true or false
  ns.trace("lead", L.rehearse and "rehearse on" or "rehearse off", true) -- the decision log shows a practice run
  L.answers, L.invited, L.whispered, L.call, L.target, L.practiceAt, armed = {}, {}, {}, nil, nil, nil, nil
  practiceToken = practiceToken + 1
  L.page = 1
  note(L.rehearse and "Rehearse is on: practice guildmates and a practice raid. Nothing is sent or invited."
    or "Rehearse is off. Buttons act for real again.")
end

-- What each tab shows: { head = lines, rows = { { text, b1 = {label, fn}, b2 = {label, fn} } }, actions = { {label,
-- fn, tip} } }. The window only draws it, so every tab is testable without the UI. A row is one line, cut with "..."
-- where it runs past its buttons; tall = true marks a sentence (a Say line, the plan), which gets two. Actions sit
-- three to a row, or across to a row where the view says so. primary = true marks the tab's one red button (at most
-- one a tab; the rest are quiet); empty is the one grey line the list shows while it has no rows.
local CLASS_FALLBACK = "ffffff"
local function classed(r)
  local c = r.cls and type(g("RAID_CLASS_COLORS")) == "table" and g("RAID_CLASS_COLORS")[r.cls]
  local hex = c and type(c.colorStr) == "string" and c.colorStr:sub(3) or CLASS_FALLBACK
  return "|cff" .. hex .. r.name .. "|r"
end
local function pick(name)
  return function()
    L.target = name
    note(("%s picked: Say > Offer a spot whispers them."):format(short(name)))
  end
end
local function whisperTo(full)
  return function()
    L.target = full
    -- A clickable name in chat, not ChatFrame_SendTell: the game opens the whisper from the click itself, so no
    -- UW_Guild code writes the chat edit box (that taints every later send; Louis's party-chat error, 10 Nov).
    act(("would open a whisper to %s."):format(short(full)), function()
      say(("Click |Hplayer:%s|h[%s]|h to whisper them."):format(full, short(full)))
      return true
    end)
  end
end

local views = {}
function views.online()
  local list = L.Online()
  local label = { near = "near your level", sixty = "at 60", called = "who answered your call", all = "online" }
  -- Nobody to list: the grey line says what would show, or where to look instead, and the head doesn't ask for a
  -- click on a name that isn't there (design pass, 13 Nov 2026, finding 10).
  local none = { near = "Try Everyone below.", sixty = "Try Everyone below.",
    called = "Guildmates who answer your call show here.", all = "Guildmates show here when they come online." }
  local v = { head = { ("|cffffd100%d guildmates %s.|r%s"):format(#list, label[L.filter],
      #list > 0 and " Click a name to pick it for Say." or "") },
    rows = {}, actions = {}, across = 4, -- the four filters share one row: one choice of four, the one that's on lit
    empty = none[L.filter] }
  for _, r in ipairs(list) do
    local tags = {}
    if r.answered then tags[#tags + 1] = "|cff40ff40said inv|r" end
    if r.signed then tags[#tags + 1] = ("raid: %s"):format(ROLE_WORD[r.signed.role] or "DPS") end
    if r.busy then tags[#tags + 1] = "|cffff8000" .. r.busy .. "|r" end
    if r.rankName ~= "" then tags[#tags + 1] = "|cff808080" .. r.rankName .. "|r" end
    v.rows[#v.rows + 1] = { text = ("%s  %d  %s  %s"):format(classed(r), r.level, r.zone, table.concat(tags, " ")),
      pick = pick(r.full), b1 = { "Whisper", whisperTo(r.full) }, b2 = { "Invite", function() invite(r.name, r.full) end } }
  end
  for _, f in ipairs({ { "near", "Near my level" }, { "sixty", "Level 60" }, { "called", "Answered call" }, { "all", "Everyone" } }) do
    v.actions[#v.actions + 1] = { f[2], function() L.filter, L.page = f[1], 1 end, "Show online guildmates: " .. f[2] .. ".",
      on = L.filter == f[1] }
  end
  return v
end

function views.call()
  local v = { head = {}, rows = {}, actions = {}, empty = "Guildmates who answer your call show here." }
  if calledRecently() then
    v.head[1] = ("|cffffd100Call open %d more min.|r %d answered."):format(
      math.ceil((ns.LEAD_CALL_WINDOW - (now() - L.call.at)) / 60), #L.answers)
  elseif boxAsk() then
    v.head[1] = ("|cffffd100%s asked: %s.|r Call in guild; answers show here."):format(L.forAsk.name, L.forAsk.what)
  else
    local s = L.Suggest()
    local me = not s and not officer() and L.ForMe()
    v.head[1] = s and ("|cffffd100Suggested: %s.|r %d newcomers online at those levels.")
      :format(s.what, s.n)
      or me and ("|cffffd100For your level: %s.|r Use suggestion, then Call in guild; answers show here."):format(me.what)
      or "|cffffd100Type what it's for, then Call in guild.|r Answers show here for 15 minutes."
  end
  v.preview = L.CallText(L.what) -- the line Call in guild says, shown under the box it's typed in
  v.input = true
  if #L.answers == 0 and not calledRecently() then
    local p = L.Plan()
    if p then
      v.rows[#v.rows + 1] = { text = ("|cffffd100Plan:|r %s around %02d:00 your clock: %d newcomers who haven't grouped "
        .. "have been on then."):format(p.what, p.hour, p.n), tall = true,
        b2 = { "Use", function()
          L.what = p.what
          if frame and frame.input then frame.input:SetText(p.what) end
          ns.trace("lead", "plan", true, ("%d newcomers, %s"):format(p.n, p.name))
        end } }
    end
    local s = L.Suggest()
    local ask
    for _, e in ipairs(ns.LEAD_LINES) do if e[1] == "vet" then ask = e end end
    for _, r in ipairs(L.Helpers(s)) do
      v.rows[#v.rows + 1] = { text = ("%s  %d  %s  |cff808080could help|r"):format(classed(r), r.level, r.zone),
        pick = pick(r.full), b1 = { "Whisper", whisperTo(r.full) },
        b2 = { "Ask", function() L.target = r.full; L.Say(ask) end } }
    end
  end
  local on = onlineSet()
  for _, a in ipairs(L.answers) do
    local r = on[a.name]
    v.rows[#v.rows + 1] = { text = r and ("%s  %d  %s"):format(classed(r), r.level, r.zone) or (a.name .. "  |cff808080offline|r"),
      pick = pick(r and r.full or a.name),
      b1 = { "Whisper", whisperTo(r and r.full or a.name) },
      b2 = r and { L.invited[a.name] and "Invited" or "Invite", function() invite(a.name, r.full) end } or nil }
  end
  v.actions = {
    { "Use suggestion", L.UseSuggestion, "Puts the dungeon with the most newcomers waiting for a first one in the box. "
      .. "Then Call in guild: one line reaches them all, nobody is whispered." },
    { "Call in guild", function() L.Call(L.what) end, "One line in guild chat. Click twice: the first shows it.",
      primary = true },
    { "Invite next", L.InviteAnswers, "Invites the next answer who's online and not grouped. One per click." },
    { "Make it a raid", L.MakeRaid, "Turns your group into a raid, for more than 5." },
    { "Ready check", L.ReadyCheck, "Asks everyone in the group if they're ready." },
    { "Share meet point", L.Meet, "Your spot becomes the group's meet point: their arrows point at you (/uw meet)." },
  }
  if boxAsk() then table.remove(v.actions, 1) end -- the asker's levels stay in the box
  return v
end

function views.raid()
  local r = L.Raid()
  local v = { head = {}, rows = {}, actions = {},
    empty = r and "Nobody has signed up yet." or "Sign-ups show here once a raid is posted." }
  if not r then
    v.head[1] = "|cffffd100No raid in the schedule yet.|r Post one in Discord; it shows here after the next /reload."
  else
    local c = L.RaidCounts(r)
    v.head[1] = ("|cffffd100%s|r starts %s. Tanks %d/%d, Healers %d/%d, DPS %d/%d. Bench %d."):format(r.title,
      startsIn(r.start - now()), c.t, r.cap[1] or 0, c.h, r.cap[2] or 0, c.d, r.cap[3] or 0, c.bench)
    if r.fromBot then
      v.head[2] = ("|cff808080As of %s.%s Whispers since then are marked new.|r"):format((date or os.date)("%H:%M", r.asOf or now()),
        (r.unlinked or 0) > 0 and (" %d more on Discord with no character linked."):format(r.unlinked) or "")
    else
      v.head[2] = "|cff808080Whisper sign-ups to you only. Discord sign-ups show on the Guild Master's PC.|r"
    end
    local on, label = onlineSet(), { ["in"] = "", bench = "|cffffd100bench|r", maybe = "|cff808080maybe|r",
      new = "|cff40ff40new|r", out = "|cff808080out|r" }
    for _, p in ipairs(r.people) do
      local o = on[p.name]
      v.rows[#v.rows + 1] = { text = ("%s  %s  %s  %s"):format(o and classed(o) or p.name, ROLE_WORD[p.role] or "DPS",
        label[p.place] or "", o and "" or "|cff808080offline|r"), pick = pick(o and o.full or p.name),
        b1 = { "Whisper", whisperTo(o and o.full or p.name) },
        b2 = o and { L.invited[p.name] and "Invited" or "Invite", function() invite(p.name, o.full) end } or nil }
    end
  end
  v.actions = {
    { "Open sign-ups", L.AnnounceRaid, "Tells guild chat how to sign up by whisper. Click twice: the first shows it.",
      officer = true },
    { "Invite signed-up", L.InviteRaid, "Invites the next signed-up guildmate who's online and not grouped.",
      primary = true },
    { "Whisper the bench", L.WhisperBench, "Thanks the next benched guildmate online, once each." },
    { "Who wants to raid?", L.AskRaiders, "Asks guild chat who wants to be a Raider (/uw raiders).", officer = true },
    { "Promote raiders", L.PromoteRaiders, "Who said raid, and the Promote button (/uw raiders list).", officer = true },
  }
  return v
end

function views.leads()
  local v = { head = {}, rows = {}, actions = {}, empty = "Your group shows here once you're in one." }
  local grp = L.Group()
  v.head[1] = #grp > 0 and "|cffffd100Your group.|r Anyone who wants to lead, leads: pass it on."
    or "|cffffd100Not in a group.|r Call a group first, or invite from Who's on."
  for _, m in ipairs(grp) do
    v.rows[#v.rows + 1] = { text = m.name .. (m.leader and "  |cffffd100leader|r" or m.assist and "  |cff808080assist|r" or ""),
      pick = pick(m.name), b1 = { "Make leader", function() L.MakeLeader(m) end },
      b2 = { "Make assist", function() L.MakeAssist(m) end } }
  end
  local unpaired = L.Unpaired()
  if #unpaired > 0 then
    v.head[2] = ("|cffffd100%d newcomer%s online without a buddy.|r Pair suggests the closest level."):format(#unpaired,
      #unpaired == 1 and "" or "s")
  end
  for _, p in ipairs(unpaired) do
    v.rows[#v.rows + 1] = { text = ("%s  %d  |cff808080buddy: %s|r"):format(classed(p.recruit), p.recruit.level,
      p.buddy and p.buddy.name or "nobody online"), pick = pick(p.recruit.full),
      b1 = { "Whisper", whisperTo(p.recruit.full) }, b2 = { "Pair", function() L.Pair(p) end }, officer = true }
  end
  local jobs = ns.JobHolders and ns.JobHolders() or {}
  local parts = {}
  for _, j in ipairs(ns.JOBS or {}) do parts[#parts + 1] = ("%s %d"):format(j.label, #(jobs[j.key] or {})) end
  v.head[#v.head + 1] = "|cff808080Guild jobs: " .. table.concat(parts, ", ") .. ". Leaders get rated privately after a boss kill.|r"
  v.actions = { { "Ask for helpers", L.AskHelpers, "Asks guild chat for buddies, recruiters and hosts (/uw jobs ask).",
    officer = true, primary = true } }
  return v
end

function views.say()
  local v = { head = { "|cffffd100Lines written ahead.|r The first click shows one; a second sends it." }, rows = {},
    actions = {} }
  v.head[2] = L.target and ("|cff808080Whispers go to %s.|r"):format(short(L.target))
    or "|cff808080Pick a name in any list to whisper them.|r"
  local where = { GUILD = "guild", GROUP = "group", WHISPER = "whisper" }
  for _, e in ipairs(ns.LEAD_LINES) do
    v.rows[#v.rows + 1] = { text = ("|cffffd100%s|r |cff808080(%s)|r %s"):format(e[2], where[e[3]], ns.LeadLineText(e[4])),
      tall = true, b2 = { "Send", function() L.Say(e) end } }
  end
  return v
end
L.views = views
-- Notes: guild notes waiting to be set by hand (Crafts.lua ns.NotesView; no addon can set one on Forever).
function views.notes() return ns.NotesView and ns.NotesView() or { head = {}, rows = {}, actions = {} } end
L.TABS = { { "online", "Who's on" }, { "call", "Call a group" }, { "raid", "Raid" }, { "leads", "Leads" },
  { "say", "Say" }, { "notes", "Notes", officer = true } }
-- A tab as this character sees it: officer-only rows and actions left out for everyone else, so a Raider never meets
-- a button that only answers "officers only" (the Notes tab, buddy pairing, job asks, raid sign-ups, promoting).
function L.View(tab)
  tab = tab or L.tab
  local isOff = officer()
  for _, t in ipairs(L.TABS) do
    if t[1] == tab and not L.TabOpen(t) then tab = ns.MayLead() and "online" or "call" end
  end
  local v = views[tab]()
  v.tab = tab
  if not isOff then
    local keep = function(list)
      local out = {}
      for _, x in ipairs(list) do if not x.officer then out[#out + 1] = x end end
      return out
    end
    v.rows, v.actions = keep(v.rows), keep(v.actions)
  end
  return v
end

-- The window ---------------------------------------------------------------------------------------------------------
local function tooltip(owner, title, text)
  if not GameTooltip then return end
  GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
  GameTooltip:SetText(title, 1, 1, 1)
  GameTooltip:AddLine(text, nil, nil, nil, true)
  GameTooltip:Show()
end
local function hideTooltip() if GameTooltip then GameTooltip:Hide() end end

-- Laid out on ns.UI (Skin.lua), the same size and parts as the UW Guild window:
--   heading (the tab, and the Rehearsal line while it's on) with the pager | what the tab says, its box, the line the
--   call will say | the list | the last answers | up to six actions.
--   * The list and everything above it hang from the top; the actions are pinned to the bottom and never move, so
--     a redraw (every 5 s) or a new answer can't slide a button under the pointer. The list takes the room between.
--   * Answers show right over the actions, where the click that caused them was: "Click again within 6 s" is read
--     next to the button to click again.
--   * A row's buttons are smaller than the actions under the list and share its text size: ten rows of two read as
--     a list with controls, not a wall of buttons (Louis's screenshot, 10 Nov: "crowded"). They're quiet (UI.Quiet),
--     and so is every action under the list but the tab's one red button (design pass, 13 Nov: Leads showed 25 red
--     buttons, Call a group 19). A list with no rows says so in one grey line.
--   * A page holds the rows that fit the list (13 Nov: ten a page left a third of Who's on empty, with 22 names on
--     three pages). The answers' place is counted as taken even while it's empty, so the first answer never sends a
--     row to the next page under the pointer.
--   * A name's row is one line; a sentence's row is taller and takes two, with air between it and the next, so two
--     wrapped lines never read as one block of four.
local UI = ns.UI
ns.LEAD_ROW_H, ns.LEAD_ROW_TALL, ns.LEAD_ROW_BTN = 24, 32, 74
ns.LEAD_TEXT_W1 = UI.CW - 2 - 8 - 8 - ns.LEAD_ROW_BTN - 4  -- a row's text up to its one button
ns.LEAD_TEXT_W2 = ns.LEAD_TEXT_W1 - ns.LEAD_ROW_BTN - 8    -- up to the first of two
ns.LEAD_NOTE_H = 4 * 10 + 3 * 2                             -- answers: four lines
local ACT_GAP = UI.GAP
local ACT_STEP = UI.BTN + ACT_GAP
local function actWidth(across) return (UI.CW - (across - 1) * ACT_GAP) / across end -- that many across the content
local BOX_H, LIST_PAD = 20, 4 -- the edit box; the list's margin over its first row and under its last
local ANSWER_IN = 12          -- the answers start this far in, behind their bar (as in the guide)

local function rowHeight(r) return r.tall and ns.LEAD_ROW_TALL or ns.LEAD_ROW_H end
-- The row each page starts on: a page takes rows while they fit in room (px), always one, never more than there are
-- row frames. Pure, so the paging is tested without the window.
function L.Pages(rows, room)
  local starts, used, n = { 1 }, 0, 0
  for i, r in ipairs(rows) do
    local h = rowHeight(r)
    if n > 0 and (used + h > room or n >= ns.LEAD_ROWS) then starts[#starts + 1], used, n = i, 0, 0 end
    used, n = used + h, n + 1
  end
  return starts
end

local boxInset = UI.BoxInset -- the box sits flush with the text above it, in either look

local function draw()
  if not frame or not frame:IsShown() then return end
  local v = L.View()
  local isOff = officer()
  local name = ""
  for _, t in ipairs(frame.tabs) do
    t.shown = isOff or L.TabOpen({ t.key, officer = t.officer })
    if t.key == v.tab then name = t.name end
  end
  UI.NavSet(frame, frame.tabs, function(t) return t.key == v.tab end)
  frame.heading:SetText(name)
  frame.banner:SetShown(L.rehearse)

  -- What the tab says, then its box, then the call's line: each hangs under the one before.
  frame.head:SetText(table.concat(v.head, "\n"))
  frame.input:SetShown(v.input and true or false)
  frame.copy:SetShown(v.copy and true or false)
  local box = v.input and frame.input or v.copy and frame.copy or nil
  -- top: how far down the window the list starts, counted as the parts are hung (a text the client can't measure
  -- yet is counted by its lines).
  local last, x = frame.head, 0
  local top = UI.BODY + UI.TextHeight(frame.head, UI.Lines(v.head) * UI.LINE - 2)
  if box then last, x, top = box, -boxInset(), top + UI.GAP + BOX_H end
  frame.preview:SetShown(box ~= nil and v.preview ~= nil)
  if box and v.preview then
    frame.preview:SetText(v.preview)
    -- Hung again only when its box changed: a text let go of its place can measure 0 until the next frame.
    if frame.previewOn ~= box or frame.previewX ~= x then
      frame.preview:ClearAllPoints()
      frame.preview:SetPoint("TOPLEFT", box, "BOTTOMLEFT", x, -4)
      frame.previewOn, frame.previewX = box, x
    end
    last, x = frame.preview, 0
    top = top + 4 + UI.TextHeight(frame.preview, UI.Lines({ v.preview }) * UI.LINE - 2)
  end
  top = top + UI.GAP

  local shown = math.min(#v.actions, #frame.slots)
  local across = v.across or 3
  local actW = actWidth(across)
  local actRows = math.ceil(shown / across)
  for i, slot in ipairs(frame.slots) do
    local a = v.actions[i]
    -- Each place holds the tab's red button or a quiet one, whichever this action is.
    local b = a and a.primary and slot.red or slot.quiet
    if b == slot.red then slot.quiet:Hide() else slot.red:Hide() end
    frame.actions[i] = b
    b:SetShown(a ~= nil)
    if a then
      b:SetText(a[1])
      b.fn, b.tip = a[2], a[3]
      -- A choice that's on now (the Who's on filter) is lit like the tab on the rail.
      if b == slot.quiet then UI.QuietOn(b, a.on) end
      b:SetWidth(actW)
      b:ClearAllPoints() -- one row of actions sits on the window's bottom edge (level with the rail), a second above it
      b:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", UI.X + (i - 1) % across * (actW + ACT_GAP),
        UI.EDGE + (actRows - 1 - math.floor((i - 1) / across)) * ACT_STEP)
    end
  end
  -- Over the actions: the answers when there are any, and the list down to them.
  local above = UI.EDGE + actRows * ACT_STEP
  local notes = #L.notes > 0
  frame.answer:SetShown(notes)
  if frame.answerAt ~= above then -- moved only when the actions under it take another row (measured right after)
    frame.answer:ClearAllPoints()
    frame.answer:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", UI.X + ANSWER_IN, above)
    frame.answerAt = above
  end
  frame.answerBar:SetShown(notes)
  frame.answerBar:SetHeight(UI.AnswerSet(frame.answer, L.notes, ns.LEAD_NOTE_H, true))
  frame.list:ClearAllPoints()
  frame.list:SetPoint("TOPLEFT", last, "BOTTOMLEFT", x, -UI.GAP)
  if notes then
    frame.list:SetPoint("BOTTOMRIGHT", frame.answer, "TOPRIGHT", 0, UI.GAP)
  else
    frame.list:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -UI.PAD, above)
  end

  -- The rows that fit between the text above and the answers' place over the actions.
  local room = UI.H - top - above - (ns.LEAD_NOTE_H + UI.GAP) - 2 * LIST_PAD
  local starts = L.Pages(v.rows, room)
  local pages = #starts
  L.page = math.min(L.page, pages)
  local first, y = starts[L.page], LIST_PAD
  local past = starts[L.page + 1] or #v.rows + 1
  for i, row in ipairs(frame.rows) do
    local r = first + i - 1 < past and v.rows[first + i - 1] or nil
    row:SetShown(r ~= nil)
    if r then
      local h = rowHeight(r)
      row:ClearAllPoints()
      row:SetPoint("TOPLEFT", 1, -y)
      row:SetHeight(h)
      y = y + h
      -- Inside its own slot: a name's line on one line, a sentence on two, either cut with "..." past that (Louis,
      -- 8 Nov: "Offer a spot" ran into "Why dungeons"). Hover shows a cut line whole; a Say line's first click too.
      row.text:SetHeight(h)
      if row.text.SetWordWrap then row.text:SetWordWrap(r.tall and true or false) end
      if row.text.SetMaxLines then row.text:SetMaxLines(r.tall and 2 or 1) end
      -- Text runs up to the first shown button: wider when b1 is hidden (Say), so most lines fit in two.
      row.text:SetWidth(r.b1 and ns.LEAD_TEXT_W2 or ns.LEAD_TEXT_W1)
      row.text:SetText(r.text)
      row.full, row.pick = r.text, r.pick
      row.hover:SetAlpha(r.pick and 1 or 0) -- lit under the pointer only where a click picks the name
      for _, k in ipairs({ "b1", "b2" }) do
        row[k]:SetShown(r[k] ~= nil)
        if r[k] then row[k]:SetText(r[k][1]); row[k].fn = r[k][2] end
      end
    end
  end
  -- No rows: one grey line near the top of the list says what shows here.
  frame.empty:SetShown(#v.rows == 0 and v.empty ~= nil)
  frame.empty:SetText(v.empty or "")
  UI.PagerSet(frame.pager, L.page, pages)
end
L.refresh = function() ns.protect(draw) end

local function build()
  local f = UI.Window("UW_GuildLead", "Lead a group", "HIGH")

  -- Tabs on the rail.
  f.tabs = {}
  for i, t in ipairs(L.TABS) do
    local b = UI.Nav(f, t[2])
    b.key, b.name, b.officer = t[1], t[2], t.officer
    b:SetScript("OnClick", function() L.tab, L.page = t[1], 1; L.refresh() end)
    ns.useButton(b, "lead " .. t[1])
    f.tabs[i] = b
  end

  -- Rehearse: the switch at the foot of the rail, and an orange line by the heading while it's on, so a practice
  -- run never looks like a real one.
  local cb = CreateFrame("CheckButton", nil, f.rail, "UICheckButtonTemplate")
  cb:SetSize(UI.CHECK, UI.CHECK)
  cb:SetPoint("BOTTOMLEFT", 8, 8)
  local cbl = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  cbl:SetPoint("LEFT", cb, "RIGHT", 4, 0)
  cbl:SetText("Rehearse")
  if cb.SetHitRectInsets then cb:SetHitRectInsets(0, -64, 0, 0) end -- a click on the word ticks it too
  cb:SetScript("OnClick", function(self) ns.protect(L.SetRehearse, self:GetChecked()) end)
  cb:SetScript("OnEnter", function(self) tooltip(self, "Rehearse", "Practice guildmates, a practice raid and practice "
    .. "answers. Nothing is sent or invited.") end)
  cb:SetScript("OnLeave", hideTooltip)
  ns.Skin("Checkbox", cb)
  ns.useButton(cb, "lead rehearse")
  f.rehearse = cb
  f.banner = UI.Sub(f, "GameFontNormal")
  f.banner:SetText("|cffff8000Rehearsal: nothing is sent.|r")

  f.pager = UI.Pager(f, function(way) L.page = math.max(1, L.page + way); L.refresh() end)
  ns.useButton(f.pager.prev, "lead page")
  ns.useButton(f.pager.next, "lead page")

  f.head = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  f.head:SetPoint("TOPLEFT", UI.X, -UI.BODY)
  f.head:SetWidth(UI.CW)
  f.head:SetJustifyH("LEFT")
  if f.head.SetSpacing then f.head:SetSpacing(2) end
  f.input = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
  f.input:SetSize(260 - boxInset(), BOX_H)
  f.input:SetPoint("TOPLEFT", f.head, "BOTTOMLEFT", boxInset(), -UI.GAP)
  f.input:SetAutoFocus(false)
  f.input:SetMaxLetters(40)
  f.input:SetText("a dungeon")
  f.input:SetScript("OnTextChanged", function(self) L.what = self:GetText(); L.refresh() end)
  f.input:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
  f.input:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  ns.Skin("EditBox", f.input)
  -- Notes: Copy puts the text here, selected, so Ctrl+C copies it. Typing in it changes nothing (it snaps back).
  f.copy = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
  f.copy:SetSize(320 - boxInset(), BOX_H)
  f.copy:SetPoint("TOPLEFT", f.head, "BOTTOMLEFT", boxInset(), -UI.GAP)
  f.copy:SetAutoFocus(false)
  f.copy:SetScript("OnTextChanged", function(self, user) if user then self:SetText(L.copyText or "") self:HighlightText() end end)
  f.copy:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
  f.copy:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  ns.Skin("EditBox", f.copy)
  -- The line the call will say, in guild chat's own colour: it reads as chat, not as one more instruction.
  f.preview = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  f.preview:SetWidth(UI.CW)
  f.preview:SetJustifyH("LEFT")
  if f.preview.SetSpacing then f.preview:SetSpacing(2) end
  local guild = type(g("ChatTypeInfo")) == "table" and g("ChatTypeInfo").GUILD or nil
  f.preview:SetTextColor(guild and guild.r or 0.25, guild and guild.g or 1, guild and guild.b or 0.25)

  f.list = UI.Well(f)
  f.rows = {}
  for i = 1, ns.LEAD_ROWS do
    local row = CreateFrame("Button", nil, f.list)
    row:SetSize(UI.CW - 2, ns.LEAD_ROW_H) -- placed, and made taller for a sentence, when it's drawn
    row:SetPoint("TOPLEFT", 1, -LIST_PAD - (i - 1) * ns.LEAD_ROW_H)
    row.hover = UI.Fill(row, "HIGHLIGHT", 1, 1, 1, 0.06)
    row.hover:SetAllPoints()
    row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.text:SetPoint("LEFT", 8, 0)
    row.text:SetWidth(ns.LEAD_TEXT_W2)
    row.text:SetHeight(ns.LEAD_ROW_H)
    if row.text.SetSpacing then row.text:SetSpacing(2) end
    row.text:SetJustifyH("LEFT")
    row.text:SetJustifyV("MIDDLE")
    row:SetScript("OnClick", function(self) if self.pick then ns.protect(self.pick); L.refresh() end end)
    row:SetScript("OnEnter", function(self)
      local cut = self.text.IsTruncated and self.text:IsTruncated()
      if cut == nil then cut = #(self.full or "") > 100 end
      if cut and GameTooltip then
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(self.full, 1, 1, 1, 1, true)
        GameTooltip:Show()
      end
    end)
    row:SetScript("OnLeave", hideTooltip)
    -- Two columns against the right edge, so every row's Whisper sits over the next row's.
    row.b2 = UI.Quiet(row, ns.LEAD_ROW_BTN, "", UI.SMALL)
    row.b2:SetPoint("RIGHT", -4, 0)
    row.b1 = UI.Quiet(row, ns.LEAD_ROW_BTN, "", UI.SMALL)
    row.b1:SetPoint("RIGHT", row.b2, "LEFT", -8, 0)
    for _, b in ipairs({ row.b1, row.b2 }) do
      b:SetScript("OnClick", function(self) if self.fn then ns.protect(self.fn); L.refresh() end end)
      ns.useButton(b, "lead row")
    end
    f.rows[i] = row
  end

  -- One grey line near the top of a list with no rows: what shows here.
  f.empty = f.list:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  f.empty:SetPoint("TOP", f.list, "TOP", 0, -24)
  f.empty:SetWidth(UI.CW - 2 * UI.PAD)
  f.empty:Hide()

  -- Six places, two rows of three, so every label fits. Each holds a red button and a quiet one; the tab's view
  -- says which shows (f.actions: the ones in use now).
  f.slots, f.actions = {}, {}
  for i = 1, 6 do
    local slot = { red = UI.Button(f, actWidth(3), ""), quiet = UI.Quiet(f, actWidth(3), "") }
    for _, b in pairs(slot) do
      b:SetScript("OnClick", function(self) if self.fn then ns.protect(self.fn); L.refresh() end end)
      ns.useButton(b, "lead action")
      b:SetScript("OnEnter", function(self) if self.tip then tooltip(self, self:GetText(), self.tip) end end)
      b:SetScript("OnLeave", hideTooltip)
      b:Hide()
    end
    f.slots[i], f.actions[i] = slot, slot.quiet
  end
  -- The last answers, over the actions: the same body text behind a thin bar as the guide's answer.
  f.answer = UI.Body(f, UI.CW - ANSWER_IN)
  f.answer:SetJustifyV("BOTTOM")
  f.answerBar = UI.Thin(UI.Fill(f.body, "ARTWORK", 1, 1, 1, 0.25), 2)
  f.answerBar:SetPoint("BOTTOMLEFT", f.answer, "BOTTOMLEFT", -ANSWER_IN, 0)
  f.answerBar:Hide()
  f:SetScript("OnShow", function() L.refresh() end)
  -- The call's minutes and who's online change on their own: redraw every 5 seconds while open.
  local tick = 0
  f:SetScript("OnUpdate", function(_, dt)
    tick = tick + (dt or 0)
    if tick >= 5 then tick = 0; L.refresh() end
  end)
  return f
end

-- Puts text in the Notes tab's copy box, focused and selected: Ctrl+C copies it.
function L.Copy(text)
  L.copyText = text
  if not frame then return end
  frame.copy:SetText(text)
  frame.copy:SetFocus()
  frame.copy:HighlightText()
end

local callTold = {} -- per character, once a session
function L.Open()
  if not ns.MayLead() then
    if not ns.MayCall() then
      say("Members and up: /uw lead call writes a group call for you. Anyone can call one by typing in guild chat.")
      return false
    end
    L.tab, L.page = "call", 1
    if not callTold[ns.me() or ""] then
      callTold[ns.me() or ""] = true
      say("Call a group is yours now: /uw lead call.")
    end
  end
  if InCombatLockdown() then say("After the fight: /uw lead.") return false end
  frame = frame or build()
  frame:Show()
  L.refresh()
  return true
end

-- Opens /uw lead on one tab. quiet: no "officers only" line (the caller has its own fallback). False if it can't open.
-- An officer-only tab (Notes) opens only for officers.
function L.OpenTab(tab, quiet)
  local gated, open = false, false
  for _, t in ipairs(L.TABS) do
    if t[1] == tab then gated, open = t.officer and true or false, L.TabOpen(t) end
  end
  if gated and not officer() then
    if not quiet then say("Officers only: the Notes tab is guild notes waiting to be set by hand.") end
    return false
  end
  if quiet and (not open or InCombatLockdown()) then return false end
  L.tab, L.page = tab, 1
  return L.Open()
end

-- /uw asks off|on: whether guildmates' group asks in guild chat show on this account (Member and up, officers).
ns.commands.asks = function(args)
  local w = strtrim(args or ""):lower()
  if not ns.MayCall() then say("Group asks show for Members and up.") return end
  if w == "off" then
    UW_GuildDB.asksOff, L.asks = true, {}
    L.UpdateNow(true)
    say("Group asks from guild chat won't show for you now; officers and other guildmates still see them."
      .. " /uw asks on brings them back.")
  elseif w == "on" then
    UW_GuildDB.asksOff, UW_GuildDB.asksTold = nil, true
    say("Group asks from guild chat show again, so you can call a group for whoever is waiting.")
  else
    say(("Group asks from guild chat: %s. /uw asks %s"):format(UW_GuildDB.asksOff and "off" or "on",
      UW_GuildDB.asksOff and "on" or "off"))
  end
end

ns.commands.lead = function(args)
  local w = strtrim(args or ""):lower()
  -- A guildmate's ask waiting while the buttons above chat are hidden (/uw hide): call it as the button would.
  if w == "call" and L.nowAction and L.nowAction.kind == "ask" then L.NowClick("LeftButton") return end
  if w == "call" or w == "notes" then L.OpenTab(w) return end
  if w == "rehearse" then
    if not L.Open() then return end
    frame.rehearse:SetChecked(true)
    L.SetRehearse(true)
    return
  end
  L.Open()
end

-- Say it before it shows (gentle rollouts, rule 2): one line, once per account, to a Raider or Member who isn't an
-- officer, from the day before their rank's date. Not in the same session as the /uw rate line (rule 5): the rate line comes first, this one the
-- next time they log in.
function L.HeadsUp(rateToldBefore)
  local o = opening()
  if UW_GuildDB.leadTold or officer() or not rateToldBefore or not o or now() < o[1] - HEADSUP_AHEAD
    or not ns.NewLineFree() then return false end
  UW_GuildDB.leadTold = true
  local text = ": /uw lead helps you run a group. Call one in guild chat, invite who answers, pass the lead. Use it if you like."
  if now() >= o[1] then say("New" .. text) else say(("From %s"):format(o[2]) .. text) end
  return true
end

local f = CreateFrame("Frame")
ns.listen(f, { "CHAT_MSG_GUILD", "GROUP_ROSTER_UPDATE", "PLAYER_ENTERING_WORLD" })
f:SetScript("OnEvent", ns.guard(function(_, event, msg, sender)
  if event == "CHAT_MSG_GUILD" then
    ns.protect(L.Heard, msg, sender)
    ns.protect(L.TellAsks) -- also here: the roster's rank can land after the login events
    if L.HearsAsks() then
      ns.protect(function()
        L.AskAnswered(msg, sender)
        if L.HeardAsk(msg, sender) or L.nowAction and L.nowAction.kind == "ask" then L.UpdateNow(true) end
      end)
    end
  elseif event == "PLAYER_ENTERING_WORLD" then
    local isLogin, isReload = msg, sender
    if not ((isLogin or isReload) and IsInGuild()) or type(UW_GuildDB) ~= "table" then return end
    local told = UW_GuildDB.rateTold   -- before Thanks.lua's line can set it this session
    ns.after(65, function() ns.protect(L.HeadsUp, told) end)
  elseif L.refresh then L.refresh() end
end))

-- The "now" button (8 Nov 2026, member journey, bot/uwbot/funnel.py): the two biggest leaks were a first dungeon
-- with a guildmate (11 of 152 newcomers) and the Discord welcome (91 of 157 never whispered: they joined before it
-- existed, or while no officer was online). Both have a fix already, the suggested call and /uw discord ask, but each
-- waited for an officer to remember it; the login line says it once. So while one is worth doing right now, an
-- officer sees one button above chat (over the notes button). A click opens the call with the suggestion filled in,
-- or runs /uw discord ask (the welcome Louis approved, once ever per member, 25 a run). The officer still sends the
-- call with the usual two clicks, and the button itself sends nothing members see. Prompting at the moment it can be
-- acted on, with the step spelled out, is what turns intent into action (Fogg 2009); one button, not a list, keeps it
-- calm. Hidden in combat, in instances and while a call is open; 30 min quiet after a click; right-click hides it
-- until the next login.
-- An offer, not a nag (Louis, 9 Nov 03:17 "enhance, don't interfere"; 03:37 "...call a group button still shows?"):
-- the suggested call shows once per login. It's gone for the session once you click it or call a group any way, and
-- an offer you leave alone folds after NOW_CALL_SHOW. Only a guildmate's own ask in guild chat brings the button
-- back, because then someone is waiting.
ns.NOW_CALL_AT_LEAST, ns.NOW_WELCOME_AT_LEAST, ns.NOW_SNOOZE, ns.NOW_EVERY = 3, 3, 1800, 30
ns.NOW_CALL_SHOW = 600
local nowButton, nowSnoozed, nowHidden, nowChecked, nowAskSeen = nil, 0, false, -math.huge, 0
local nowAskTold = 0 -- the ask last said in chat while the buttons above chat are hidden
local nowCallDone, nowCallSince = false, nil -- the suggested call had its one showing this login

local function inInstance()
  if type(IsInInstance) ~= "function" then return false end
  local inside, kind = IsInInstance()
  return inside and kind ~= "none"
end

-- Asks heard in guild chat (8 Nov, first dungeon for every newcomer): a member with no addon and no Discord has one way
-- to get a dungeon group themselves, asking in /g ("lfg wc", "anyone up for rfc?"). When nobody leading is around to
-- answer, the ask scrolls away. While no call is open, this officer's client keeps the newest ask per guildmate for
-- ASK_KEEP seconds, and the button offers a call for that level. It whispers nobody: the call is the answer, in the
-- same channel they asked in. Only short lines that name a group or a dungeon and read as a request count.
ns.ASK_KEEP, ns.ASK_MAX_LEN, ns.ASK_MAX_WORDS = 1800, 60, 8
-- A Member's button waits a random 20-40 s after the ask; officers' shows at once. The first call posted clears the ask on
-- every client (CALL_OPENS), so one guildmate answers and the rest never see a button for an ask already taken.
ns.ASK_HOLD_MIN, ns.ASK_HOLD_MAX = 20, 40
-- A typed call (auditor, 13 Nov, ops/audit-people-shift.md item 3): "anyone up for WC? type inv" is someone starting a
-- group and asking for answers in guild chat, the same as the Call button, not someone asking for one. It was read
-- as an ask, so it lit the ask button on officers' screens (inviting a rival call), and neither it nor its answers
-- were counted: only Call-button presses on the pressing client were, so "only Louis calls" was the counter, not the
-- guild. A call names a group and tells people what to type back ("type inv", "say x", "x for inv"); it may run
-- longer than an ask, as the Call button's own line does.
ns.CALL_MAX_LEN, ns.CALL_MAX_WORDS = 140, 24
-- The words of a guild line, as the ask and answer tests read them (addon search, 13 Nov 2026: a re-read of 60 real
-- shapes found "dm me if you need a group" and "need 5 more linen for my run" counted as asks, "lf healer" and
-- "anyone for sunken temple?" missed, "zul'farrak" split in two, and "inv layer pls" taken as an answer). A link's
-- text is one word, "link" (an item called "Wailing Robe" names no dungeon); an apostrophe joins ("zul'farrak" is
-- "zulfarrak"); colour codes and punctuation go.
function ns.AskWords(msg)
  local t = msg:gsub("|H.-|h.-|h", " link "):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
  t = t:gsub("\226\128\153", ""):gsub("['`]", ""):lower()
  local words = {}
  for w in t:gmatch("[%w]+") do words[#words + 1] = w end
  return words
end
-- Words that name a group or a place to take one. Dungeons and raids as people type them, Forever's nine included
-- (Ruins of Lordaeron, Excavation Site, City of Dalaran, The Drowned City, Krol'dok Stronghold, Alcaz Prison,
-- Blackmaw Hold, Shaper's Terrace, Hall of Thanes). Short forms that are also everyday words ("lib", "arm", "gy",
-- "east") are left out: a full wing name still counts.
local ASK_GROUP = {}
for w in ([[group groups grp dungeon dungeons dung dungeoning instance instances
  rfc ragefire wc wailing dm deadmines vc sfk shadowfang bfd blackfathom stocks stockade rfk kraul
  gnomer gnomeregan gnome sm scarlet smgy smlib smarm smcath graveyard library armory armoury cathedral cath
  rfd downs ulda uld uldaman zf zulfarrak farrak mara maraudon st sunken atal atalhakkar brd lbrs ubrs brs
  dme dmw dmn diremaul maul tribute strat stratholme strath scholo scholomance sholo
  ony onyxia mc bwl zg naxx hyjal barrow
  thanes lordaeron ruins excavation dalaran drowned kroldok alcaz blackmaw shaper shapers]]):gmatch("%S+") do
  ASK_GROUP[w] = true
end
-- Every word QuestChain.lua's whisper list knows, so one list names the dungeons.
for _, d in ipairs(ns.DUNGEONS or {}) do for _, w in ipairs(d[3]) do ASK_GROUP[w] = true end end
-- Roles name a group too ("lf healer", "need a tank").
local ASK_ROLE = { tank = true, tanks = true, heal = true, heals = true, healer = true, healers = true, dps = true,
  dd = true }
local ASK_REQUEST = { lfg = true, lfm = true, lf = true, anyone = true, any1 = true, anybody = true, who = true,
  wanna = true, want = true, need = true, needs = true, looking = true, lftank = true, lfheal = true,
  lfhealer = true, lfheals = true, lfdps = true }
-- Not a group ask: a question about a place, trade, items, travel, layers, or a line with a link in it.
local ASK_NOT = { know = true, where = true, wheres = true, how = true, hows = true, layer = true, layers = true,
  wts = true, wtb = true, wtt = true, sell = true, selling = true, seller = true, buy = true, buying = true,
  item = true, items = true, boe = true, boes = true, boost = true, boosting = true, summon = true, summons = true,
  summ = true, port = true, portal = true, link = true }
-- "dm me", "dm us": a direct message, not Dire Maul or the Deadmines.
local DM_TO = { me = true, us = true, you = true, him = true, her = true, them = true, pls = true, please = true }
-- "run" alone is any trip ("want to run to org?", "5 more linen for my run"): it names a group only as "a run",
-- "some runs", "quick run".
local RUN_AFTER = { a = true, some = true, quick = true, few = true }
local function requestWord(w) return ASK_REQUEST[w] or w:match("^lf%dm$") ~= nil end -- lf1m .. lf4m
L.asks = {}
-- Who keeps asks (13 Nov, priority 2: more member leaders): everyone who may call a group (officers, and Member and up
-- since #504), unless they switched it off with /uw asks off. Officers get every "now" offer; the others only asks,
-- and only once L.TellAsks has said so (gentle rollouts rule 2: say it before it shows).
function L.HearsAsks()
  if type(UW_GuildDB) ~= "table" or UW_GuildDB.asksOff then return false end
  if ns.isOfficer(ns.me()) then return true end
  return UW_GuildDB.asksTold == true and ns.MayCall()
end
ns.ASKS_NEW = "when a guildmate asks for a group in guild chat, UW_Guild offers you a call for their level."
  .. " /uw asks off turns it off."
-- Once per account, before a Member's first ask button can show; never in combat. Officers have had asks since 8 Nov.
function L.TellAsks()
  if type(UW_GuildDB) ~= "table" or UW_GuildDB.asksTold or UW_GuildDB.asksOff or InCombatLockdown() then return end
  if ns.isOfficer(ns.me()) or not ns.MayCall() then return end
  -- A first install reads as a welcome, not a changelog: no "New: " then (ns.TellNew). Told only once said.
  if ns.TellNew(ns.ASKS_NEW) then UW_GuildDB.asksTold = true end
end
-- Answered elsewhere (red team R7, 8 Nov): asks live on each officer's client, so another officer's call (any guild
-- line that opens like ns.LEAD_CALL) clears them all here, and the asker's own "inv" or "+" drops theirs.
local CALL_OPENS = (ns.LEAD_CALL:match("^(.-)%%s") or ns.LEAD_CALL):lower()
function L.AskAnswered(msg, sender)
  if type(msg) ~= "string" or ns.isSecret(msg) or type(sender) ~= "string" or ns.isSecret(sender) then return end
  local text = strtrim(msg):lower()
  if CALL_OPENS ~= "" and text:sub(1, #CALL_OPENS) == CALL_OPENS then L.asks = {} return end -- the Call button's line
  if ns.IsGroupCall(msg) then L.asks[short(sender)] = nil return end -- a typed call: the caller's own ask is moot
  if #text <= 12 and (text:match("^inv") or text:match("^%+")) then L.asks[short(sender)] = nil end
end
-- The shape alone: "call" for a group with a "type inv" (below), "ask" for a short line that names a group or a dungeon
-- and reads as a request, "fill" when the writer is filling their own group ("lf2m wc", "lf healer", "need 2 more",
-- "lfm"), "start" for a group started another way ("starting wc, pst"), nil for anything else. A fill
-- isn't an ask (journey sim, 13 Nov 2026): every guildmate has read it already, whoever wants in whispers them, and an
-- officer's call would start a rival group. "anyone need a tank?" offers to join, so it stays an ask.
local ROLE_COMPOUND = { lftank = true, lfheal = true, lfhealer = true, lfheals = true, lfdps = true }
local OFFERS = { anyone = true, any1 = true, anybody = true, who = true }
-- The reply a call asks for: a verb ("type", "say", ...) then, within two words, inv, invite or x ("type inv",
-- "say x", "drop an x in guild"); or "x for inv" / "+ for inv". Not "in" (integrator review: "put me in for wc pls",
-- "say in guild if you have room" are asks), and not a verb about the writer themselves ("put me in", "drop me inv",
-- "i'll type inv when ready"): those are someone asking to join.
local CUE_VERB = { type = true, say = true, put = true, drop = true, reply = true, post = true, write = true }
local CUE_WORD = { inv = true, invite = true, x = true }
local CUE_SELF = { i = true, ill = true, im = true, id = true, me = true, us = true }
local CUE_NOT = { someone = true, somebody = true, pls = true, please = true, dont = true, cant = true, wont = true,
  no = true, never = true }
local function forMe(words, i)
  for j = i + 1, i + 3 do if words[j] == "me" or words[j] == "us" then return true end end
  return false
end
local function callCue(words, text)
  for i, w in ipairs(words) do
    local before = words[i - 1] or ""
    if CUE_VERB[w] and not CUE_SELF[before] and not CUE_NOT[before] and not forMe(words, i)
      and (CUE_WORD[words[i + 1] or ""] or CUE_WORD[words[i + 2] or ""]) then return true end
  end
  return text:find("[x%+] for inv") ~= nil
end
local function readCall(msg)
  if #msg > ns.CALL_MAX_LEN then return false end
  local text = strtrim(msg):lower()
  if CALL_OPENS ~= "" and text:sub(1, #CALL_OPENS) == CALL_OPENS then return true end -- the Call button's own line
  local words = ns.AskWords(msg)
  if #words == 0 or #words > ns.CALL_MAX_WORDS or not callCue(words, text) then return false end
  for _, w in ipairs(words) do
    if ASK_NOT[w] then return false end
    if ASK_GROUP[w] or ASK_ROLE[w] or w == "lfm" or w:match("^lf%dm$") then return true end
  end
  return false
end
-- A group someone starts the usual way, with no "type inv" (auditor, 14 Nov: "starting wc, pst", "running rfc in 5 w
-- me" were counted nowhere): a group word, no offer or question ("anyone starting wc?" is an ask), and either a start
-- word (starting, forming, making) or a whisper cue (pst, hmu, "w me", "msg me", "pm me"). Up to a call's length.
-- Long fills ("lf2m wc need a tank and heals then we go") count here too, since ReadAsk's own fill test stops at an
-- ask's length. Not "pm me if you need a group": an offer of help. Not an answer to a call ("+1 healer, pst", "inv
-- healer pst", "x healer w me", "im in, tank, w me": integrator, 14 Nov), so the call's answers stay as they were. Not
-- "making gold in wc, pst". Not someone offering themselves for a group ("tank for wc pst", "i can tank wc pst": red
-- team, 14 Nov): a role about the writer, with no wanted word before it and no start word or fill.
local SELF_BEFORE = { can = true, i = true, im = true, am = true, as = true }
local SELF_AFTER = { ["for"] = true, lf = true, lfg = true, looking = true, here = true, available = true, avail = true }
local WANTED = { need = true, needs = true, lf = true, lfm = true, looking = true, want = true, wanna = true }
local START_VERB = { starting = true, forming = true, making = true }
local START_NOT_AFTER = { gold = true, money = true }
local ANSWER_FIRST = { inv = true, invite = true, x = true, ["in"] = true }
local WHISPER_CUE = { pst = true, psst = true, whisper = true, hmu = true }
local WHISPER_ME = { w = true, msg = true, pm = true, message = true }
local function readStart(msg)
  if #msg > ns.CALL_MAX_LEN or msg:find("?", 1, true) then return false end
  local words = ns.AskWords(msg)
  if #words == 0 or #words > ns.CALL_MAX_WORDS then return false end
  if msg:match("^%s*%+") or ANSWER_FIRST[words[1]] or (words[1] == "im" and words[2] == "in") then return false end
  local group, start, cue, wanted, self = false, false, false, false, false
  for i, w in ipairs(words) do
    local prev, nxt, after = words[i - 1], words[i + 1], words[i + 2]
    if ASK_NOT[w] or OFFERS[w] or (w == "dm" and nxt and DM_TO[nxt]) then return false end
    if (w == "you" or w == "u") and (nxt == "need" or nxt == "needs" or after == "need") then return false end
    if (w == "run" or w == "runs") and prev and RUN_AFTER[prev] then group = true end
    group = group or ASK_GROUP[w] or ASK_ROLE[w] or false
    local fill = w == "lfm" or w:match("^lf%dm$") ~= nil or ROLE_COMPOUND[w]
      or (w == "lf" and nxt and (ASK_ROLE[nxt] or nxt == "more" or nxt:match("^%d$") ~= nil))
    if START_VERB[w] and nxt and START_NOT_AFTER[nxt] then return false end
    start = start or START_VERB[w] or fill or false
    cue = cue or WHISPER_CUE[w] or (WHISPER_ME[w] and nxt == "me") or false
    if ASK_ROLE[w] and not wanted and (SELF_BEFORE[prev] or (nxt and SELF_AFTER[nxt])) then self = true end
    wanted = wanted or WANTED[w] or w:match("^lf%dm$") ~= nil
  end
  return group and (start or (cue and not self))
end
function ns.ReadAsk(msg)
  if type(msg) ~= "string" or ns.isSecret(msg) then return nil end
  if readCall(msg) then return "call" end
  local kind = ns.ReadShortAsk(msg)
  if kind then return kind end
  return readStart(msg) and "start" or nil
end
-- ReadAsk for a line within an ask's length: "ask", "fill" or nil.
function ns.ReadShortAsk(msg)
  if #msg > ns.ASK_MAX_LEN then return nil end
  local words = ns.AskWords(msg)
  local n = #words
  if n == 0 or n > ns.ASK_MAX_WORDS then return nil end
  local group, request, fill, offer = false, msg:find("?", 1, true) ~= nil, false, false
  for _, w in ipairs(words) do offer = offer or OFFERS[w] or false end -- "need a tank anyone?" offers too
  for i, w in ipairs(words) do
    local prev, nxt, after = words[i - 1], words[i + 1], words[i + 2]
    if ASK_NOT[w] or (w == "dm" and nxt and DM_TO[nxt]) then return nil end
    if (w == "run" or w == "runs") and prev and RUN_AFTER[prev] then group = true end
    group = group or ASK_GROUP[w] or ASK_ROLE[w] or requestWord(w) and w ~= "lf" and w:match("^lf") ~= nil
    request = request or requestWord(w)
    -- Filling: lfm, lf2m, lftank; "lf healer", "lf more", "lf 1 tank"; "need a healer", "need 2 more"; "last spot".
    local someone = nxt and (ASK_ROLE[nxt] or nxt == "more" or (nxt:match("^%d$") and after
      and (after == "more" or ASK_ROLE[after])) or ((nxt == "a" or nxt == "an") and after and ASK_ROLE[after]))
    fill = fill or w == "lfm" or w:match("^lf%dm$") ~= nil or ROLE_COMPOUND[w] or (w == "lf" and someone)
      or ((w == "need" or w == "needs") and someone and not offer) or (w == "spot" and prev == "last") or false
  end
  if not (group and request) then return nil end
  return fill and "fill" or "ask"
end
-- A group ask (Lead.lua L.HeardAsk, and the counts on the bot's PC: Core.lua ns.CountGuildChat).
function ns.IsGroupAsk(msg) return ns.ReadAsk(msg) == "ask" end
-- A "maybe ask" (harvest item 4, 13 Nov 2026: count the misses, not only the false alarms): a line ReadAsk passes
-- over only for its length (over ASK_MAX_LEN characters or ASK_MAX_WORDS words, and not a call) that names a group or a
-- dungeon, has a request word and isn't filling the writer's own group, like "hey is anyone around level 17 up for
-- wailing caverns tonight?". Counted per night (WeekOne.lua mg), never shown: whether officers should see these
-- waits for the number. Lines over MAYBE_MAX_LEN are chat walls, not asks.
ns.MAYBE_MAX_LEN = 200
function ns.MaybeAsk(msg)
  if type(msg) ~= "string" or ns.isSecret(msg) or #msg > ns.MAYBE_MAX_LEN or ns.ReadAsk(msg) ~= nil then return false end
  local words = ns.AskWords(msg)
  if #msg <= ns.ASK_MAX_LEN and #words <= ns.ASK_MAX_WORDS then return false end -- short: ReadAsk's own "no"
  local group, request, offer = false, false, false
  for i, w in ipairs(words) do
    local prev, nxt, after = words[i - 1], words[i + 1], words[i + 2]
    if ASK_NOT[w] or (w == "dm" and nxt and DM_TO[nxt]) then return false end
    if (w == "run" or w == "runs") and prev and RUN_AFTER[prev] then group = true end
    group = group or ASK_GROUP[w] or ASK_ROLE[w] or requestWord(w) and w ~= "lf" and w:match("^lf") ~= nil or false
    request = request or requestWord(w)
    offer = offer or OFFERS[w] or false
    local someone = nxt and (ASK_ROLE[nxt] or nxt == "more" or (nxt:match("^%d$") and after
      and (after == "more" or ASK_ROLE[after])) or ((nxt == "a" or nxt == "an") and after and ASK_ROLE[after]))
    if w == "lfm" or w:match("^lf%dm$") or ROLE_COMPOUND[w] or (w == "lf" and someone)
      or ((w == "need" or w == "needs") and someone and not offer) or (w == "spot" and prev == "last") then
      return false -- filling their own group
    end
  end
  return group and request
end
-- A group call anyone typed, the Call button's line included (Core.lua ns.CountGuildChat counts them too).
function ns.IsGroupCall(msg) return ns.ReadAsk(msg) == "call" end
function L.HeardAsk(msg, sender)
  if L.rehearse or calledRecently() or not ns.IsGroupAsk(msg) then return false end
  if type(sender) ~= "string" or ns.isSecret(sender) then return false end
  local name = short(sender)
  if name == short(ns.me() or "") then return false end
  local level
  for _, r in ipairs(roster()) do if r.name == name then level = r.level break end end
  if not level or level >= 60 then return false end
  local prev = L.asks[name]
  local hold = prev and prev.hold or (ns.isOfficer(ns.me()) and 0 or math.random(ns.ASK_HOLD_MIN, ns.ASK_HOLD_MAX))
  L.asks[name] = { at = now(), level = level, first = prev and prev.first or now(), hold = hold }
  if not prev then
    ns.trace("lead", "ask heard", true, ("level %d"):format(level))
    if hold > 0 then C_Timer.After(hold, function() ns.protect(L.UpdateNow, true) end) end
  end
  nowChecked = -math.huge -- show it at the next update
  return true
end

-- Calls anyone made, counted where they're heard (auditor item 3, 13 Nov): a typed call, or another officer's Call
-- button, counts as a call ("c" in WeekOne.lua's nights), and the first answer from each guildmate inside its window
-- counts as an answer ("a"); a call's first answer also counts it as answered ("ca"). The bot gets counts only: the
-- callers' names stay in this session (L.heard), and WeekOne.lua keeps who called or answered on this PC for 7 nights
-- so each person counts once (xo, wo), never shared. This client's own button call was counted when it was pressed,
-- and while it's open its answers count in L.Heard.
L.heard = { calls = {}, answered = {} }
ns.CALL_OWN_ECHO = 10 -- seconds: my own Call line coming back in guild chat
function L.HeardCall(msg, sender)
  if L.rehearse or type(sender) ~= "string" or ns.isSecret(sender) or not ns.IsGroupCall(msg) then return false end
  local name, at = short(sender), now()
  if name == short(ns.me() or "") and L.call and at - L.call.at <= ns.CALL_OWN_ECHO then return false end
  local was = L.heard.calls[name]
  if was and at - was < ns.LEAD_CALL_WINDOW then return true end -- the same call again: counted once
  L.heard.calls[name], L.heard.answered[name] = at, {}
  ns.trace("lead", "call heard", true)
  if ns.WeekOneNight then ns.WeekOneNight("c", sender) end
  return true
end
function L.HeardCallAnswer(msg, sender)
  if L.rehearse or calledRecently() or type(sender) ~= "string" or ns.isSecret(sender) then return false end
  if not ns.IsCallAnswer(msg) then return false end
  local name, at, caller = short(sender), now(), nil
  for who, t in pairs(L.heard.calls) do
    if at - t >= ns.LEAD_CALL_WINDOW then L.heard.calls[who], L.heard.answered[who] = nil, nil
    elseif who ~= name and not L.heard.answered[who][name] and (not caller or t > L.heard.calls[caller]) then
      caller = who
    end
  end
  if not caller then return false end
  local first = next(L.heard.answered[caller]) == nil
  L.heard.answered[caller][name] = true
  if ns.WeekOneNight then
    ns.WeekOneNight("a", sender)
    if first then ns.WeekOneNight("ca", nil, at - L.heard.calls[caller]) end -- the call drew an answer
  end
  return true
end
-- Asks counted (audit section 8, 13 Nov: does an ask draw an answer?). On a helper's client (WeekOne.lua
-- ns.WeekOneHelper), each guildmate's group ask in guild chat counts once per asker per ASK_KEEP ("g" in WeekOne.lua's
-- nights), and once when it is answered inside that window ("ga"): a Call-button line by someone else, the asker
-- answering an open call, or the asker joining this client's group. The asker's own call makes their ask moot, not
-- answered (as L.AskAnswered drops it). Nothing the ask button needs matters here (their level, a call open, /uw asks
-- off), and this character's own asks are never counted. Asker names stay in this session, never saved.
-- The window is the ask button's own ASK_KEEP: 30 minutes, longer than a call's 15 (LEAD_CALL_WINDOW), so it needs
-- no floor of its own.
L.openAsks, L.groupNow = {}, {}
local function openAsk(name, at)
  local a = L.openAsks[name]
  if a and at - a.at >= ns.ASK_KEEP then L.openAsks[name], a = nil, nil end
  return a
end
-- An ask answered outside guild chat (auditor C5, 14 Nov 2026): most answers are a whisper or an invite this client
-- never sees, so an ask also counts as answered ("gr") when a roster read finds the asker in a dungeon with a guildmate
-- within ASK_GROUPED of asking (WeekOne.lua calls ns.AsksGrouped at each quarter-hour read). An asker the read before
-- the ask already had in one counts only after a read without. gr counts each ask once, answered either way, so every
-- ga counts in it too. Not a floor; it can overstate (red team, 14 Nov): two guildmates in different groups in the same
-- instance count as together, and an asker already partied with a guildmate (questing as a duo, "lf group wc") who
-- goes in with them counts as answered. It can also miss, as reads come only while a helper plays.
-- L.askWatch[name] = { at, out (not in a dungeon group at the last read), got }; L.inDungeon = the last read
-- ({ at, names }). Names stay in this session, never saved.
-- Followed to the end (gf; auditor C6, 14 Nov 2026): a logout or /reload ends every watch, and Louis's sessions are
-- often shorter than a group takes to form, so an ask counts as followed once it is answered (with gr), its hour has
-- passed, the asker's own call made it moot, or the asker asked again. An ask still under an hour old at logout was
-- cut short (g minus gf), and rule 3 bounds it both ways (people_counts). Rows keep each field's highest across
-- clients, so the officer
-- who followed the most asks decides gf; a count of cut-short asks would let Louis's short sessions decide instead.
ns.ASK_GROUPED, ns.ASK_READ_FRESH = 3600, 1800
L.askWatch, L.inDungeon = {}, nil
local function askDone(w, at) -- followed to the end without an answer: its hour passed, or its asker called
  if w.got then return end
  w.got = true
  if ns.WeekOneNight then ns.WeekOneNight("gf", nil, at - w.at) end
end
local function watchAsk(name, at)
  for who, w in pairs(L.askWatch) do
    if at - w.at > ns.ASK_GROUPED then askDone(w, at) L.askWatch[who] = nil end
  end
  local last = L.inDungeon
  local inside = last and at - last.at <= ns.ASK_READ_FRESH and last.names[name]
  if L.askWatch[name] then askDone(L.askWatch[name], at) end -- asking again ends the last ask, unanswered (red team)
  L.askWatch[name] = { at = at, out = not inside }
end
local function askGot(name, at, since)
  local w = L.askWatch[name]
  if not w or w.got or w.at ~= since then return end
  w.got = true
  if ns.WeekOneNight then -- on the ask's night, like ga; answered is followed to the end too
    ns.WeekOneNight("gr", nil, at - w.at)
    ns.WeekOneNight("gf", nil, at - w.at)
  end
end
local function askAnswered(name, at)
  local a = openAsk(name, at)
  if not a or a.done then return false end
  a.done = true
  if ns.WeekOneNight then ns.WeekOneNight("ga", nil, at - a.at) end -- counted on the ask's night
  askGot(name, at, a.at)
  return true
end
local function callOpenFor(name, at)
  if calledRecently() then return true end
  for who, t in pairs(L.heard.calls) do if who ~= name and at - t < ns.LEAD_CALL_WINDOW then return true end end
  return false
end
local function counting()
  return not L.rehearse and type(UW_GuildDB) == "table" and ns.WeekOneHelper ~= nil and ns.WeekOneHelper()
end
L.maybeAt = {} -- this session only: when each writer's last maybe ask counted (once per ASK_KEEP, like an ask)
L.startAt = {} -- this session only: when each writer's last started group counted (gs, once per ASK_KEEP)
function L.CountAsk(msg, sender)
  if type(msg) ~= "string" or ns.isSecret(msg) or type(sender) ~= "string" or ns.isSecret(sender) then return end
  if not counting() then return end
  local name, at, kind = short(sender), now(), ns.ReadAsk(msg)
  if kind == "call" then
    if CALL_OPENS ~= "" and strtrim(msg):lower():sub(1, #CALL_OPENS) == CALL_OPENS then -- the Call button's line
      for who in pairs(L.openAsks) do if who ~= name then askAnswered(who, at) end end
    end
    local mine = openAsk(name, at)
    if mine then -- their own call makes the ask moot: never counted as answered, in a reply or a dungeon
      mine.done = true
      if L.askWatch[name] and L.askWatch[name].at == mine.at then askDone(L.askWatch[name], at) end
    end
  elseif kind == "ask" then
    if name ~= short(ns.me() or "") and not openAsk(name, at) then
      for who in pairs(L.openAsks) do openAsk(who, at) end -- past their window: gone from the session too
      L.openAsks[name] = { at = at }
      if ns.WeekOneNight then ns.WeekOneNight("g") end
      watchAsk(name, at)
    end
  elseif openAsk(name, at) and callOpenFor(name, at) and ns.IsCallAnswer(msg) then
    askAnswered(name, at)
  elseif kind == nil and name ~= short(ns.me() or "") and ns.MaybeAsk(msg) then
    local last = L.maybeAt[name]
    if not last or at - last >= ns.ASK_KEEP then
      L.maybeAt[name] = at
      if ns.WeekOneNight then ns.WeekOneNight("mg") end
    end
  end
  -- A group a guildmate started without a call (auditor, 14 Nov): a fill or a start, Louis's own left out, once per
  -- writer per ASK_KEEP like a maybe ask. Counted only (WeekOne.lua gs).
  if (kind == "fill" or kind == "start") and not ns.IsLouis(sender) then
    local last = L.startAt[name]
    if not last or at - last >= ns.ASK_KEEP then
      L.startAt[name] = at
      if ns.WeekOneNight then ns.WeekOneNight("gs", sender) end -- counts them in xo/wo too
    end
  end
end
-- A roster read (WeekOne.lua ns.WeekOneSample, byZone = { [instance zone] = { names } }): an asker in a dungeon with a
-- guildmate within ASK_GROUPED of asking was answered (gr). Times are this file's now(), as the ask's.
function ns.AsksGrouped(byZone)
  local at, inside = now(), {}
  for _, list in pairs(type(byZone) == "table" and byZone or {}) do
    if type(list) == "table" and #list >= 2 then for _, n in ipairs(list) do inside[n] = true end end
  end
  L.inDungeon = { at = at, names = inside }
  if not counting() then return end
  for name, w in pairs(L.askWatch) do
    if at - w.at > ns.ASK_GROUPED then askDone(w, at) L.askWatch[name] = nil
    elseif not inside[name] then w.out = true
    elseif w.out then askGot(name, at, w.at) end
  end
end
-- At logout or /reload (PLAYER_LOGOUT, just before WoW writes the save): an ask past its hour was followed to the end;
-- one under it was cut short and stays out of gf.
function L.AsksAtLogout()
  local at = now()
  for _, w in pairs(L.askWatch) do
    if at - w.at > ns.ASK_GROUPED then askDone(w, at) end
  end
end
-- Guildmates newly in this client's group (L.groupNow: who was in it at the last change): an asker among them was
-- answered. Someone already in the group when they asked isn't a join.
function L.CountAskJoins()
  local at, raid, was, count = now(), IsInRaid(), L.groupNow, counting()
  L.groupNow = {}
  if not IsInGroup() then return end
  for i = 1, raid and GetNumGroupMembers() or math.max(0, GetNumGroupMembers() - 1) do
    local unit = (raid and "raid" or "party") .. i
    local full = ns.unitFull(unit)
    if full and UnitIsInMyGuild(unit) and not UnitIsUnit(unit, "player") then
      local name = short(full)
      L.groupNow[name] = true
      if count and not was[name] then askAnswered(name, at) end
    end
  end
end
local heardFrame = CreateFrame("Frame")
ns.listen(heardFrame, { "CHAT_MSG_GUILD", "GROUP_ROSTER_UPDATE", "PLAYER_LOGOUT" })
heardFrame:SetScript("OnEvent", ns.guard(function(_, event, msg, sender)
  if event == "GROUP_ROSTER_UPDATE" then L.CountAskJoins() return end
  if event == "PLAYER_LOGOUT" then L.AsksAtLogout() return end
  if not (L.HeardCall(msg, sender)) then L.HeardCallAnswer(msg, sender) end
  L.CountAsk(msg, sender)
end))

-- The newest ask still fresh, as { name, level, what } (the band around their level), or nil. ready: only asks
-- past their hold.
function L.NewestAsk(ready)
  local best
  for name, a in pairs(L.asks) do
    local holding = ready and now() - (a.first or a.at) < (a.hold or 0)
    if now() - a.at > ns.ASK_KEEP then L.asks[name] = nil
    elseif not holding and (not best or a.at > best.at) then best = { name = name, at = a.at, level = a.level } end
  end
  if not best then return nil end
  local lo = math.max(1, math.min(best.level - 2, 56)) -- never past 60
  best.what = ("levels %d-%d"):format(lo, lo + 4)
  return best
end

-- What the button would offer now: { kind = "ask" | "call" | "welcome", n, label }, or nil.
function L.NowAction()
  if L.rehearse or calledRecently() then return nil end
  local isOfficer = officer()
  local ask = L.HearsAsks() and L.NewestAsk(not isOfficer)
  if ask then
    return { kind = "ask", n = 1, what = ask.what, at = ask.at, name = ask.name, level = ask.level,
      label = ("%s asked for a group (%d): call one"):format(ask.name:match("^(%S+)") or ask.name, ask.level) }
  end
  if not isOfficer then return nil end -- the suggested call and welcomes stay officers' work
  local s = not (nowCallDone or L.call) and L.Suggest()
  if s and s.n >= ns.NOW_CALL_AT_LEAST then
    return { kind = "call", n = s.n, label = ("%d newcomers for %s: call a group"):format(s.n, s.name) }
  end
  -- /uw discord ask is retired (Louis, 9 Nov 02:39): while its sender is off, this never suggests it.
  local todo = (not UW_GuildDB.discordAskOff and ns.DiscordToAsk and ns.ChatOn("discord.ask")) and ns.DiscordToAsk(true)
    or {}
  if #todo >= ns.NOW_WELCOME_AT_LEAST then
    local n = math.min(#todo, ns.DISCORD_ASK_RUN or 25)
    return { kind = "welcome", n = n, label = ("Welcome %d guildmate%s online"):format(n, n == 1 and "" or "s") }
  end
  return nil
end

function L.NowClick(which)
  local a = L.nowAction
  if which == "RightButton" then
    nowHidden = true
    say("Hidden until your next login. /uw lead call still works.")
  elseif a then
    nowSnoozed = now() + ns.NOW_SNOOZE
    ns.trace("lead", "now " .. a.kind, true, ("%d"):format(a.n))
    if a.kind == "ask" then
      L.asks, nowAskSeen = {}, a.at
      if L.OpenTab("call", true) then
        L.what = a.what
        L.forAsk = { name = a.name:match("^(%S+)") or a.name, what = a.what, at = now() }
        if frame and frame.input then frame.input:SetText(a.what) end
      end
    elseif a.kind == "call" then
      nowCallDone = true
      if L.OpenTab("call", true) then L.UseSuggestion() end
    elseif ns.commands.discord then
      ns.commands.discord("ask")
    end
  end
  L.UpdateNow(true)
end

-- Shows, relabels or hides the button. force: skip the NOW_EVERY throttle. Returns the action shown, or nil.
function L.UpdateNow(force)
  if not force and GetTime() - nowChecked < ns.NOW_EVERY then return L.nowAction end
  nowChecked = GetTime()
  -- A new ask is news: it shows even inside the 30 min after a click.
  local fresh = L.NewestAsk()
  local awake = now() >= nowSnoozed or (fresh and fresh.at > nowAskSeen)
  local a = not nowHidden and awake and not InCombatLockdown() and not inInstance() and L.NowAction()
  if a and a.kind == "call" then
    nowCallSince = nowCallSince or now()
    if now() - nowCallSince >= ns.NOW_CALL_SHOW then
      nowCallDone = true -- before asking again: a multiple assignment would ask first
      a = L.NowAction()
    end
  end
  if not a then
    L.nowAction = nil
    if nowButton then nowButton:Hide() end
    return nil
  end
  if not nowButton then
    nowButton = CreateFrame("Button", "UWGuildLeadNow", UIParent, "UIPanelButtonTemplate")
    nowButton:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    nowButton:SetScript("OnClick", function(_, which) ns.protect(L.NowClick, which) end)
    ns.useButton(nowButton, "lead now")
    L.nowButton = nowButton
    if ns.ChatBarAdd then ns.ChatBarAdd("lead now", nowButton, 10) end -- Skin.lua: the bar above chat, first
  end
  L.nowAction, nowButton.label = a, a.label
  nowButton:Show()
  -- /uw hide hides the bar and this button with it, so a guildmate waiting in guild chat would reach nobody (journey
  -- re-walk on 112, 13 Nov: a no-addon newcomer's /g ask is their only way to a first dungeon). One chat line per ask
  -- instead, on this officer's screen only; /uw lead call then sets up the call for their level (Call still sends).
  if a.kind == "ask" and ns.ChatBarHidden and ns.ChatBarHidden() and a.at ~= nowAskTold then
    nowAskTold = a.at
    say(("%s asked for a group in guild chat (level %d). /uw lead call sets up a call for their level.")
      :format(a.name:match("^(%S+)") or a.name, a.level))
  end
  if ns.ChatBarText then ns.ChatBarText(nowButton, a.label) else nowButton:SetText(a.label) end
  return a
end

local nowFrame = CreateFrame("Frame")
ns.listen(nowFrame, { "GUILD_ROSTER_UPDATE", "PLAYER_REGEN_ENABLED", "PLAYER_REGEN_DISABLED", "PLAYER_ENTERING_WORLD" })
nowFrame:SetScript("OnEvent", ns.guard(function(_, event)
  if not (UW_GuildDB and ns.inOurGuild and ns.inOurGuild()) then return end
  if event == "GUILD_ROSTER_UPDATE" or event == "PLAYER_ENTERING_WORLD" then ns.protect(L.TellAsks) end
  ns.protect(L.UpdateNow, event ~= "GUILD_ROSTER_UPDATE")
end))
