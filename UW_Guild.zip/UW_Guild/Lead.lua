-- Lead a group: one window with every tool an officer needs to see and direct grouping (Louis, 8 Nov 2026: "ensure I
-- have all the menus, tools, etc. necessary in a clean in game interface", worried about "giving hugely wrong vibes"
-- when grouping starts). /uw lead, or Lead a group on the options page. Officers only for now (CONTRIBUTING.md, gentle
-- rollouts, rule 4); any Raider who leads can get it later.
--   * Who's on: online guildmates near your level, at 60 or all, with who answered your call and who signed up.
--   * Call a group: one guild-chat call; whoever says inv in the next 5 minutes is listed, and Invite next invites
--     one per press (an invite needs a click on the real client). Make it a raid, ready check, share the meet point.
--   * Raid: the next raid's sign-ups and bench, from the bot (the Guild Master's PC: Schedule.lua ns.RAID_ROSTER) and
--     the whisper sign-ups this client holds (Charter.lua). Invite signed-up and whisper the bench, one per press.
--   * Leads: pass the group lead or an assist, ask for guild job helpers, pair an online recruit with a buddy.
--   * Say: warm lines written ahead, in the guild's voice. A first click shows the line; a second sends it.
--   * Rehearse: practice guildmates, a practice raid and practice answers; nothing is sent or invited and no practice
--     name is saved, so the flows can be tried alone before a real test (rehearsal before a live run, as in
--     simulation training). The decision log notes only that a rehearsal ran.
-- Every action is an existing game call or /uw command; the window adds no message of its own to the addon protocol.
-- Answers to a call are read only for the 5 minutes after it, and only shown here (gentle rollouts, rule 6, as
-- /uw raiders does). This file writes nothing to UW_GuildDB but decision-log lines (ns.trace).
local _, ns = ...
local say = ns.say

ns.LEAD_CALL_WINDOW, ns.LEAD_CONFIRM, ns.LEAD_ROWS = 300, 6, 10
local function g(name) return rawget(_G, name) end
local function now() return (GetServerTime and GetServerTime()) or time() end
local function short(n) return ns.shortName(n) or n end
local function chat(msg, channel, target)
  local fn = (C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage
  return pcall(fn, msg, channel, nil, target) and true or false
end

-- Lines written ahead (Louis's voice: short, plain, warm, a concrete offer). {key, button, where, text}. where: GUILD,
-- GROUP (party or raid) or WHISPER (the name picked last in any list). %s in a call is what it's for.
ns.LEAD_CALL = "Putting a group together for %s. Say inv in guild chat in the next 5 minutes and I'll invite you."
ns.LEAD_RAID_OPEN = "Sign-ups are open for %s, starting %s. Whisper me raid, or raid tank or raid heal. Whisper "
  .. "raid out if plans change."
ns.LEAD_BENCH = "Thanks for signing up! The raid is full, so you're on the bench in sign-up order. I'll whisper you "
  .. "if a spot opens."
ns.LEAD_LINES = {
  { "full", "Group's full", "GUILD", "Group's full, thanks everyone. I'll call the next one here." },
  { "help", "Offer a hand", "GUILD", "Anyone stuck on a quest or a dungeon? Say where you're at and we'll get you a group." },
  { "welcome", "Welcome the group", "GROUP", "Welcome in! Ready check in a minute, then we head out. Ask anything, anytime." },
  { "meet", "Meet point is set", "GROUP", "Meet point is on your map arrow. Come when you can, no rush." },
  { "break", "Short break", "GROUP", "Short break, back in 5." },
  { "wipe", "After a wipe", "GROUP", "Good tries. Wipes happen. Rebuff and we'll go again." },
  { "done", "End of the night", "GROUP", "That's it for tonight. Thanks for coming, it was a good run." },
  { "room", "Offer a spot", "WHISPER", "Hey! There's room in my group if you want in. No pressure." },
}

local L = { tab = "online", filter = "near", page = 1, rehearse = false, answers = {}, invited = {}, whispered = {},
  notes = {} }
ns.Lead = L

-- Answers shown in the window too: the last few, newest last.
local function note(msg)
  say(msg)
  L.notes[#L.notes + 1] = msg
  while #L.notes > 3 do table.remove(L.notes, 1) end
  if L.refresh then L.refresh() end
end
L.note = note

-- In a rehearsal every action only says what it would do.
local function act(desc, fn)
  if L.rehearse then note("Rehearse: " .. desc) return true end
  return fn()
end

-- Rehearsal data: practice guildmates around your level, a practice raid with a bench, a practice group.
local function practiceRoster()
  local me = UnitLevel("player") or 20
  local rows = {}
  for i, p in ipairs({ { "Ada Vale", 0, "PRIEST" }, { "Brann Holt", 1, "WARRIOR" }, { "Cora Finch", -2, "MAGE" },
    { "Dax Morrow", 2, "ROGUE" }, { "Elle Quill", 0, "DRUID" }, { "Finn Rook", -1, "HUNTER" },
    { "Gale Pike", nil, "SHAMAN" }, { "Hale Stone", nil, "WARLOCK" }, { "Iris Thorn", nil, "PALADIN" },
    { "Kael Moss", nil, "MAGE" } }) do
    local lvl = p[2] and math.max(1, math.min(60, me + p[2])) or 60
    rows[i] = { name = p[1] .. " (practice)", full = p[1] .. " (practice)", level = lvl, cls = p[3],
      zone = lvl == 60 and "Orgrimmar" or "The Barrens", rank = i == 7 and 2 or 3, rankName = i == 7 and "Raider" or "Member" }
  end
  return rows
end
local function practiceRaid(at)
  local n = function(s) return s .. " (practice)" end
  return { start = at + 2 * 3600, title = "Practice raid", cap = { 2, 2, 6 }, size = 10, unlinked = 1, asOf = at,
    list = { { n("Brann Holt"), "t", "in" }, { n("Iris Thorn"), "t", "in" }, { n("Ada Vale"), "h", "in" },
      { n("Elle Quill"), "h", "in" }, { n("Cora Finch"), "d", "in" }, { n("Dax Morrow"), "d", "in" },
      { n("Finn Rook"), "d", "in" }, { n("Gale Pike"), "d", "in" }, { n("Hale Stone"), "d", "in" },
      { n("Jory Lane"), "d", "in" }, { n("Kael Moss"), "d", "bench" }, { n("Lark Penn"), "h", "bench" },
      { n("Mara Dune"), "d", "maybe" } },
    whispered = { { n("Nell Brook"), "d" } } }
end
local PRACTICE_GROUP = { "Gale Pike (practice)", "Iris Thorn (practice)", "Dax Morrow (practice)" }

-- Who's on ---------------------------------------------------------------------------------------------------------
local function roster()
  if L.rehearse then return practiceRoster() end
  local rows, self = {}, ns.me()
  for i = 1, GetNumGuildMembers() or 0 do
    local full, rankName, rank, level, _, zone, _, _, online, _, cls = GetGuildRosterInfo(i)
    full = ns.fullName(full)
    if full and online and full ~= self and type(level) == "number" and not ns.isSecret(level) then
      rows[#rows + 1] = { name = short(full), full = full, level = level, cls = type(cls) == "string" and cls or nil,
        zone = type(zone) == "string" and not ns.isSecret(zone) and zone or "?", rank = rank,
        rankName = type(rankName) == "string" and not ns.isSecret(rankName) and rankName or "" }
    end
  end
  return rows
end

-- Names in my group, by the roster's spelling (Forever's UnitName gives the parts; ns.unitFull joins them).
local function groupNames()
  local out = {}
  if L.rehearse then
    for _, n in ipairs(PRACTICE_GROUP) do out[n] = true end
    return out
  end
  local raid = IsInRaid()
  for i = 1, GetNumGroupMembers() or 0 do
    local full = ns.unitFull(raid and ("raid" .. i) or ("party" .. i))
    if full then out[short(full)] = true end
  end
  return out
end

local function calledRecently() return L.call and now() - L.call.at < ns.LEAD_CALL_WINDOW end

-- Online guildmates for the list: near (your level +-NEAR_RANGE), sixty (level 60), called (answered your call),
-- or all. Nearest level first, then by name.
function L.Online(filter)
  filter = filter or L.filter
  local mine, range = UnitLevel("player") or 1, (ns.NEAR_RANGE or 3) + 2
  local signed = {}
  local raid = L.Raid()
  for _, p in ipairs(raid and raid.people or {}) do signed[p.name] = p end
  local answered = {}
  for _, a in ipairs(L.answers) do answered[a.name] = true end
  local out = {}
  for _, r in ipairs(roster()) do
    local keep = filter == "all" or (filter == "near" and math.abs(r.level - mine) <= range)
      or (filter == "sixty" and r.level >= 60) or (filter == "called" and answered[r.name])
    if keep then
      r.answered, r.signed = answered[r.name], signed[r.name]
      out[#out + 1] = r
    end
  end
  table.sort(out, function(a, b)
    local da, db = math.abs(a.level - mine), math.abs(b.level - mine)
    if da ~= db then return da < db end
    return a.name < b.name
  end)
  return out
end

-- Online short names, for the raid and call lists.
local function onlineSet()
  local out = {}
  for _, r in ipairs(roster()) do out[r.name] = r end
  return out
end

-- Invites ----------------------------------------------------------------------------------------------------------
local function invite(name, full)
  if L.invited[name] then note(("%s has an invite from you already."):format(name)) return false end
  local ok = act(("would invite %s."):format(name), function()
    local fn = (g("C_PartyInfo") and g("C_PartyInfo").InviteUnit) or g("InviteUnit")
    local sent = type(fn) == "function" and pcall(fn, full or name) or false
    ns.trace("lead", "invite", sent, not sent and "the game refused the invite" or nil, name)
    note(sent and ("Invited %s."):format(name) or ("The game didn't send %s an invite."):format(name))
    return sent
  end)
  if ok then L.invited[name] = now() end -- a refused invite can be tried again
  return ok
end
L.invite = invite

-- The next online name from list (short names, in order) who isn't grouped or invited already: one per press.
local function inviteNext(list, what)
  local on, grouped = onlineSet(), groupNames()
  for _, name in ipairs(list) do
    if on[name] and not grouped[name] and not L.invited[name] then return invite(name, on[name].full) end
  end
  note(("Nobody left to invite from %s: everyone is grouped, invited or offline."):format(what))
  return false
end

-- Call a group -------------------------------------------------------------------------------------------------------
local armed -- { key, until }: a first click shows a line, a second one sends it
-- place: where it goes ("guild chat"); text: the line itself, shown on its own so it reads as members will see it.
local function confirm(key, place, text)
  if armed and armed[1] == key and GetTime() <= armed[2] then armed = nil return true end
  armed = { key, GetTime() + ns.LEAD_CONFIRM }
  note(("Click again within %d s to %s:"):format(ns.LEAD_CONFIRM, place))
  if text then note(text) end
  return false
end
L.confirm = confirm

function L.CallText(what)
  what = strtrim(what or ""):gsub("[|\n]", "")
  if what == "" then what = "a dungeon" end
  return ns.LEAD_CALL:format(what:sub(1, 40))
end

local practiceToken = 0
function L.Call(what)
  local text = L.CallText(what)
  if calledRecently() then
    note(("Your call is open %d more min. Invite next takes the next answer."):format(
      math.ceil((ns.LEAD_CALL_WINDOW - (now() - L.call.at)) / 60)))
    return false
  end
  if not confirm("call", "say in guild chat", text) then return false end
  if not L.rehearse and not chat(text, "GUILD") then
    ns.trace("lead", "call", false, "the game didn't send it")
    note("The game didn't send it.")
    return false
  end
  if not L.rehearse then ns.trace("lead", "call", true) end
  L.call, L.answers = { at = now(), text = text }, {}
  L.tab, L.filter, L.page = "call", "called", 1
  if L.rehearse then
    note("Rehearse: called in guild chat. Practice answers come in the next few seconds.")
    practiceToken = practiceToken + 1
    local token, rows = practiceToken, practiceRoster()
    for i = 1, 3 do
      C_Timer.After(2 * i, function()
        if token ~= practiceToken or not L.rehearse then return end
        L.answers[#L.answers + 1] = { name = rows[i].name, at = now() }
        note(("%s said inv."):format(rows[i].name))
      end)
    end
  else
    note("Called in guild chat. Answers show here for 5 minutes.")
  end
  return true
end

-- An answer: a short guild line with inv, invite or + in it, inside the call's window, once per person.
local ANSWER = { inv = true, invite = true }
function L.Heard(msg, sender)
  if L.rehearse or not calledRecently() or type(msg) ~= "string" or ns.isSecret(msg) then return false end
  if type(sender) ~= "string" or ns.isSecret(sender) or #msg > 40 then return false end
  local name = short(sender)
  if name == short(ns.me() or "") then return false end
  local hit = msg:find("+", 1, true) ~= nil
  local n = 0
  for w in msg:lower():gmatch("[%a]+") do
    n = n + 1
    hit = hit or ANSWER[w] or false
  end
  if not hit or n > 5 then return false end
  for _, a in ipairs(L.answers) do if a.name == name then return false end end
  L.answers[#L.answers + 1] = { name = name, at = now() }
  if L.refresh then L.refresh() end
  return true
end

function L.InviteAnswers()
  local names = {}
  for _, a in ipairs(L.answers) do names[#names + 1] = a.name end
  if #names == 0 then note("No answers yet.") return false end
  return inviteNext(names, "the answers")
end

local function leading()
  if L.rehearse then return true end
  if not IsInGroup() then return true end
  return UnitIsGroupLeader("player") or false
end

function L.MakeRaid()
  return act("would turn the group into a raid.", function()
    if IsInRaid() then note("Already a raid.") return false end
    if not IsInGroup() then note("Invite someone first: a raid starts from a group.") return false end
    if not UnitIsGroupLeader("player") then note("Only the group leader can make it a raid.") return false end
    local fn = (g("C_PartyInfo") and g("C_PartyInfo").ConvertToRaid) or g("ConvertToRaid")
    return type(fn) == "function" and pcall(fn) and true or false
  end)
end

function L.ReadyCheck()
  return act("would start a ready check.", function()
    if not IsInGroup() then note("Ready checks are for groups.") return false end
    local fn = g("DoReadyCheck")
    return type(fn) == "function" and pcall(fn) and true or false
  end)
end

function L.Meet()
  return act("would share your spot as the meet point. Your group's arrows point there.", function()
    SlashCmdList.UWGUILD("meet")
    return true
  end)
end

-- Raid ---------------------------------------------------------------------------------------------------------------
local ROLE_WORD = { t = "Tank", h = "Healer", d = "DPS", tank = "Tank", healer = "Healer", dps = "DPS" }
local ROLE_KEY = { tank = "t", healer = "h", dps = "d" }

local function startsIn(secs)
  local d, h = math.floor(secs / 86400), math.floor(secs % 86400 / 3600)
  if d > 0 then return ("in %d day%s"):format(d, d == 1 and "" or "s") end
  if h > 0 then return ("in %d h %d min"):format(h, math.floor(secs % 3600 / 60)) end
  return ("in %d min"):format(math.max(1, math.floor(secs / 60)))
end
L.startsIn = startsIn

-- The next raid and everyone on it: { start, title, cap, size, unlinked, asOf, fromBot, people = { {name, role,
-- place} } }. Places: in, bench, maybe, new (whispered since the bot last wrote the file), out. Bot rows first, in its
-- order; a whisper newer than the file wins for that name (raid out takes them off).
function L.Raid()
  if L.rehearse then
    local r = practiceRaid(L.practiceAt or now())
    L.practiceAt = L.practiceAt or now()
    r.people = {}
    for _, p in ipairs(r.list) do r.people[#r.people + 1] = { name = p[1], role = p[2], place = p[3] } end
    for _, p in ipairs(r.whispered) do r.people[#r.people + 1] = { name = p[1], role = p[2], place = "new" } end
    r.fromBot = true
    return r
  end
  local held = ns.ScheduleNow and ns.ScheduleNow()
  local at, ev = now(), nil
  for _, e in ipairs(held and held.ev or {}) do
    if e[3] == "raid" and e[2] > at then ev = e break end
  end
  if not ev then return nil end
  local r = { start = ev[1], title = ev[5], going = ev[4], cap = { 0, 0, 0 }, size = 0, unlinked = 0, people = {} }
  local gen = type(ns.SCHEDULE) == "table" and ns.finite(ns.SCHEDULE.gen) or 0
  local index = {}
  for _, x in ipairs(type(ns.RAID_ROSTER) == "table" and ns.RAID_ROSTER or {}) do
    if type(x) == "table" and x.ev == ev[1] and gen > 0 then
      r.fromBot, r.asOf = true, gen
      r.cap = type(x.cap) == "table" and x.cap or r.cap
      r.size, r.unlinked = ns.finite(x.size) or 0, ns.finite(x.unlinked) or 0
      for _, p in ipairs(type(x.list) == "table" and x.list or {}) do
        if type(p) == "table" and type(p[1]) == "string" then
          r.people[#r.people + 1] = { name = p[1], role = p[2], place = p[3] }
          index[p[1]] = #r.people
        end
      end
    end
  end
  -- Whispers this client holds for this raid, the latest per name; only those newer than the bot's file change it.
  local latest = {}
  for _, e in ipairs(type(UW_GuildDB) == "table" and type(UW_GuildDB.raidSignups) == "table" and UW_GuildDB.raidSignups or {}) do
    if type(e) == "table" and e.ev == ev[1] and type(e.n) == "string" then
      local cur = latest[e.n]
      if not cur or (tonumber(e.at) or 0) >= (tonumber(cur.at) or 0) then latest[e.n] = e end
    end
  end
  local names = {}
  for n in pairs(latest) do names[#names + 1] = n end
  table.sort(names, function(a, b) return (tonumber(latest[a].at) or 0) < (tonumber(latest[b].at) or 0) end)
  for _, n in ipairs(names) do
    local e = latest[n]
    if (tonumber(e.at) or 0) > gen or not index[n] then
      local p = { name = n, role = ROLE_KEY[e.r or ""] or "d", place = e.out and "out" or "new" }
      if index[n] then
        if e.out then r.people[index[n]].place = "out" else r.people[index[n]].role = p.role end
      else
        r.people[#r.people + 1] = p
        index[n] = #r.people
      end
    end
  end
  return r
end

function L.RaidCounts(r)
  local c = { t = 0, h = 0, d = 0, bench = 0, maybe = 0, new = 0, out = 0 }
  for _, p in ipairs(r and r.people or {}) do
    if p.place == "in" then c[p.role] = (c[p.role] or 0) + 1
    elseif c[p.place] then c[p.place] = c[p.place] + 1 end
  end
  return c
end

local function inPlace(r, place)
  local out = {}
  for _, p in ipairs(r and r.people or {}) do if p.place == place then out[#out + 1] = p.name end end
  return out
end

function L.InviteRaid()
  local r = L.Raid()
  if not r then note("No raid in the schedule yet.") return false end
  local list = inPlace(r, "in")
  for _, n in ipairs(inPlace(r, "new")) do list[#list + 1] = n end
  return inviteNext(list, "the sign-ups")
end

-- The next benched name online who hasn't heard from you: the bench line, one per press.
function L.WhisperBench()
  local r = L.Raid()
  local on = onlineSet()
  for _, name in ipairs(inPlace(r, "bench")) do
    if on[name] and not L.whispered[name] and not (ns.quiet and ns.quiet(name)) then
      L.whispered[name] = true
      if L.rehearse then note(("Rehearse: would whisper %s:"):format(name)) note(ns.LEAD_BENCH) return true end
      local ok = chat(ns.LEAD_BENCH, "WHISPER", on[name].full)
      note(ok and ("Whispered %s the bench line."):format(name) or "The game didn't send it.")
      return ok
    end
  end
  note("Nobody on the bench to whisper: they're offline or heard from you already.")
  return false
end

function L.RaidOpenText(r)
  return ns.LEAD_RAID_OPEN:format(r.title, startsIn(r.start - now()))
end

function L.AnnounceRaid()
  local r = L.Raid()
  if not r then note("No raid in the schedule yet: post it in Discord first.") return false end
  local text = L.RaidOpenText(r)
  if not confirm("raidopen", "say in guild chat", text) then return false end
  return act("would say it in guild chat.", function()
    local ok = chat(text, "GUILD")
    note(ok and "Said in guild chat." or "The game didn't send it.")
    return ok
  end)
end

function L.AskRaiders()
  if L.rehearse then note("Rehearse: would ask in guild chat:") note(ns.RAIDERS_ASK) return true end
  return ns.RaidersAsk()
end
function L.PromoteRaiders()
  return act("would list who said raid, with the Promote button.", function() ns.RaidersList() return true end)
end

-- Leads --------------------------------------------------------------------------------------------------------------
-- My group's units other than me: { unit, name, leader, assist }.
function L.Group()
  local out = {}
  if L.rehearse then
    for i, n in ipairs(PRACTICE_GROUP) do out[i] = { unit = "party" .. i, name = n } end
    return out
  end
  local raid = IsInRaid()
  for i = 1, GetNumGroupMembers() or 0 do
    local unit = raid and ("raid" .. i) or ("party" .. i)
    local full = ns.unitFull(unit)
    if full and full ~= ns.me() then
      out[#out + 1] = { unit = unit, name = short(full), leader = UnitIsGroupLeader(unit) or nil,
        assist = UnitIsGroupAssistant(unit) or nil }
    end
  end
  return out
end

function L.MakeLeader(m)
  if not confirm("leader " .. m.name, ("make %s the group leader"):format(m.name)) then return false end
  return act(("would make %s the group leader."):format(m.name), function()
    if not leading() then note("Only the group leader can pass the lead.") return false end
    local fn = g("PromoteToLeader")
    local ok = type(fn) == "function" and pcall(fn, m.unit)
    if ok then note(("%s leads the group now."):format(m.name)) end
    return ok and true or false
  end)
end

function L.MakeAssist(m)
  return act(("would make %s a raid assist."):format(m.name), function()
    if not IsInRaid() then note("Assists are for raids: Make it a raid first.") return false end
    if not leading() then note("Only the raid leader can make assists.") return false end
    local fn = g("PromoteToAssistant")
    local ok = type(fn) == "function" and pcall(fn, m.unit)
    if ok then note(("%s is an assist now."):format(m.name)) end
    return ok and true or false
  end)
end

function L.AskHelpers()
  if L.rehearse then note("Rehearse: would ask in guild chat:") note(ns.JOBS_ASK) return true end
  SlashCmdList.UWGUILD("jobs ask")
  return true
end

-- Online recruits without a buddy, each with the online guildmate closest in level who isn't a recruit (the same
-- pairing an officer types as /uw buddy Recruit Buddy).
function L.Unpaired()
  local rows, out = roster(), {}
  local buddies = type(UW_GuildDB) == "table" and type(UW_GuildDB.buddies) == "table" and UW_GuildDB.buddies or {}
  local isNew = function(r)
    if L.rehearse then return r.name:find("^Cora") ~= nil end
    return ns.isRecruit(r.name)
  end
  for _, r in ipairs(rows) do
    if isNew(r) and not buddies[r.name] then
      local best
      for _, v in ipairs(rows) do
        if v ~= r and not isNew(v) and (not best or math.abs(v.level - r.level) < math.abs(best.level - r.level)) then
          best = v
        end
      end
      out[#out + 1] = { recruit = r, buddy = best }
    end
  end
  return out
end

function L.Pair(p)
  if not p.buddy then note(("Nobody online to pair with %s yet."):format(p.recruit.name)) return false end
  if not confirm("pair " .. p.recruit.name, ("make %s %s's buddy"):format(p.buddy.name, p.recruit.name)) then
    return false
  end
  return act(("would pair %s with %s."):format(p.recruit.name, p.buddy.name), function()
    SlashCmdList.UWGUILD(("buddy %s %s"):format(p.recruit.name, p.buddy.name))
    return true
  end)
end

-- Say ----------------------------------------------------------------------------------------------------------------
local function groupChannel()
  if L.rehearse then return "PARTY" end
  if IsInRaid() then return "RAID" end
  if IsInGroup() then return "PARTY" end
end

function L.Say(entry)
  local where = entry[3]
  local channel, target = where, nil
  if where == "GROUP" then
    channel = groupChannel()
    if not channel then note("You're not in a group.") return false end
  elseif where == "WHISPER" then
    target = L.target
    if not target then note("Pick a name first: click one on Who's on, Call or Raid.") return false end
  end
  local place = target and ("whisper to " .. short(target)) or (channel == "GUILD" and "guild chat" or "group chat")
  if not confirm("say " .. entry[1], "send it to " .. place, entry[4]) then return false end
  return act(("would send it to %s."):format(place), function()
    local ok = chat(entry[4], channel, target)
    ns.trace("lead", "say " .. entry[1], ok, not ok and "the game didn't send it" or nil)
    note(ok and ("Sent to %s."):format(place) or "The game didn't send it.")
    return ok
  end)
end

-- Rehearse -----------------------------------------------------------------------------------------------------------
function L.SetRehearse(on)
  L.rehearse = on and true or false
  ns.trace("lead", L.rehearse and "rehearse on" or "rehearse off", true) -- the decision log shows a practice run
  L.answers, L.invited, L.whispered, L.call, L.target, L.practiceAt, armed = {}, {}, {}, nil, nil, nil, nil
  practiceToken = practiceToken + 1
  L.page = 1
  note(L.rehearse and "Rehearse is on: practice guildmates and a practice raid. Nothing is sent or invited."
    or "Rehearse is off. Buttons act for real again.")
end

-- What each tab shows: { head = lines, rows = { { text, b1 = {label, fn}, b2 = {label, fn} } }, actions = { {label,
-- fn, tip} } }. The window only draws it, so every tab is testable without the UI.
local CLASS_FALLBACK = "ffffff"
local function classed(r)
  local c = r.cls and type(g("RAID_CLASS_COLORS")) == "table" and g("RAID_CLASS_COLORS")[r.cls]
  local hex = c and type(c.colorStr) == "string" and c.colorStr:sub(3) or CLASS_FALLBACK
  return "|cff" .. hex .. r.name .. "|r"
end
local function pick(name)
  return function()
    L.target = name
    note(("%s picked: Say > Offer a spot whispers them."):format(short(name)))
  end
end
local function whisperTo(full)
  return function()
    L.target = full
    act(("would open a whisper to %s."):format(short(full)), function()
      local fn = g("ChatFrame_SendTell")
      if type(fn) == "function" then pcall(fn, full) end
      return true
    end)
  end
end

local views = {}
function views.online()
  local list = L.Online()
  local label = { near = "near your level", sixty = "at 60", called = "who answered your call", all = "online" }
  local v = { head = { ("|cffffd100%d guildmates %s.|r Click a name to pick it for Say."):format(#list, label[L.filter]) },
    rows = {}, actions = {} }
  for _, r in ipairs(list) do
    local tags = {}
    if r.answered then tags[#tags + 1] = "|cff40ff40said inv|r" end
    if r.signed then tags[#tags + 1] = ("raid: %s"):format(ROLE_WORD[r.signed.role] or "DPS") end
    if r.rankName ~= "" then tags[#tags + 1] = "|cff808080" .. r.rankName .. "|r" end
    v.rows[#v.rows + 1] = { text = ("%s  %d  %s  %s"):format(classed(r), r.level, r.zone, table.concat(tags, " ")),
      pick = pick(r.full), b1 = { "Whisper", whisperTo(r.full) }, b2 = { "Invite", function() invite(r.name, r.full) end } }
  end
  for _, f in ipairs({ { "near", "Near my level" }, { "sixty", "Level 60" }, { "called", "Answered call" }, { "all", "Everyone" } }) do
    v.actions[#v.actions + 1] = { f[2], function() L.filter, L.page = f[1], 1 end, "Show online guildmates: " .. f[2] .. "." }
  end
  return v
end

function views.call()
  local v = { head = {}, rows = {}, actions = {} }
  if calledRecently() then
    v.head[1] = ("|cffffd100Call open %d more min.|r %d answered."):format(
      math.ceil((ns.LEAD_CALL_WINDOW - (now() - L.call.at)) / 60), #L.answers)
  else
    v.head[1] = "|cffffd100Type what it's for, then Call in guild.|r Answers show here for 5 minutes."
  end
  v.head[2] = "|cff808080" .. L.CallText(L.what) .. "|r"
  v.input = true
  local on = onlineSet()
  for _, a in ipairs(L.answers) do
    local r = on[a.name]
    v.rows[#v.rows + 1] = { text = r and ("%s  %d  %s"):format(classed(r), r.level, r.zone) or (a.name .. "  |cff808080offline|r"),
      pick = pick(r and r.full or a.name),
      b1 = { "Whisper", whisperTo(r and r.full or a.name) },
      b2 = r and { L.invited[a.name] and "Invited" or "Invite", function() invite(a.name, r.full) end } or nil }
  end
  v.actions = {
    { "Call in guild", function() L.Call(L.what) end, "One line in guild chat. Click twice: the first shows it." },
    { "Invite next", L.InviteAnswers, "Invites the next answer who's online and not grouped. One per click." },
    { "Make it a raid", L.MakeRaid, "Turns your group into a raid, for more than 5." },
    { "Ready check", L.ReadyCheck, "Asks everyone in the group if they're ready." },
    { "Share meet point", L.Meet, "Your spot becomes the group's meet point: their arrows point at you (/uw meet)." },
  }
  return v
end

function views.raid()
  local r = L.Raid()
  local v = { head = {}, rows = {}, actions = {} }
  if not r then
    v.head[1] = "|cffffd100No raid in the schedule yet.|r Post one in Discord; it shows here after the next /reload."
  else
    local c = L.RaidCounts(r)
    v.head[1] = ("|cffffd100%s|r starts %s. Tanks %d/%d, Healers %d/%d, DPS %d/%d. Bench %d."):format(r.title,
      startsIn(r.start - now()), c.t, r.cap[1] or 0, c.h, r.cap[2] or 0, c.d, r.cap[3] or 0, c.bench)
    if r.fromBot then
      v.head[2] = ("|cff808080As of %s.%s Whispers since then are marked new.|r"):format((date or os.date)("%H:%M", r.asOf or now()),
        (r.unlinked or 0) > 0 and (" %d more on Discord with no character linked."):format(r.unlinked) or "")
    else
      v.head[2] = "|cff808080Whisper sign-ups to you only. Discord sign-ups show on the Guild Master's PC.|r"
    end
    local on, label = onlineSet(), { ["in"] = "", bench = "|cffffd100bench|r", maybe = "|cff808080maybe|r",
      new = "|cff40ff40new|r", out = "|cff808080out|r" }
    for _, p in ipairs(r.people) do
      local o = on[p.name]
      v.rows[#v.rows + 1] = { text = ("%s  %s  %s  %s"):format(o and classed(o) or p.name, ROLE_WORD[p.role] or "DPS",
        label[p.place] or "", o and "" or "|cff808080offline|r"), pick = pick(o and o.full or p.name),
        b1 = { "Whisper", whisperTo(o and o.full or p.name) },
        b2 = o and { L.invited[p.name] and "Invited" or "Invite", function() invite(p.name, o.full) end } or nil }
    end
  end
  v.actions = {
    { "Open sign-ups", L.AnnounceRaid, "Tells guild chat how to sign up by whisper. Click twice: the first shows it." },
    { "Invite signed-up", L.InviteRaid, "Invites the next signed-up guildmate who's online and not grouped." },
    { "Whisper the bench", L.WhisperBench, "Thanks the next benched guildmate online, once each." },
    { "Who wants to raid?", L.AskRaiders, "Asks guild chat who wants to be a Raider (/uw raiders)." },
    { "Promote raiders", L.PromoteRaiders, "Who said raid, and the Promote button (/uw raiders list)." },
  }
  return v
end

function views.leads()
  local v = { head = {}, rows = {}, actions = {} }
  local grp = L.Group()
  v.head[1] = #grp > 0 and "|cffffd100Your group.|r Anyone who wants to lead, leads: pass it on."
    or "|cffffd100Not in a group.|r Call a group first, or invite from Who's on."
  for _, m in ipairs(grp) do
    v.rows[#v.rows + 1] = { text = m.name .. (m.leader and "  |cffffd100leader|r" or m.assist and "  |cff808080assist|r" or ""),
      pick = pick(m.name), b1 = { "Make leader", function() L.MakeLeader(m) end },
      b2 = { "Make assist", function() L.MakeAssist(m) end } }
  end
  local unpaired = L.Unpaired()
  if #unpaired > 0 then
    v.head[2] = ("|cffffd100%d new recruit%s online without a buddy.|r Pair suggests the closest level."):format(#unpaired,
      #unpaired == 1 and "" or "s")
  end
  for _, p in ipairs(unpaired) do
    v.rows[#v.rows + 1] = { text = ("%s  %d  |cff808080buddy: %s|r"):format(classed(p.recruit), p.recruit.level,
      p.buddy and p.buddy.name or "nobody online"), pick = pick(p.recruit.full),
      b1 = { "Whisper", whisperTo(p.recruit.full) }, b2 = { "Pair", function() L.Pair(p) end } }
  end
  local jobs = ns.JobHolders and ns.JobHolders() or {}
  local parts = {}
  for _, j in ipairs(ns.JOBS or {}) do parts[#parts + 1] = ("%s %d"):format(j.label, #(jobs[j.key] or {})) end
  v.head[#v.head + 1] = "|cff808080Guild jobs: " .. table.concat(parts, ", ") .. ". Leaders get rated privately after a boss kill.|r"
  v.actions = { { "Ask for helpers", L.AskHelpers, "Asks guild chat for buddies, recruiters and hosts (/uw jobs ask)." } }
  return v
end

function views.say()
  local v = { head = { "|cffffd100Lines written ahead.|r The first click shows one; a second sends it." }, rows = {},
    actions = {} }
  v.head[2] = L.target and ("|cff808080Whispers go to %s.|r"):format(short(L.target))
    or "|cff808080Pick a name in any list to whisper them.|r"
  local where = { GUILD = "guild", GROUP = "group", WHISPER = "whisper" }
  for _, e in ipairs(ns.LEAD_LINES) do
    v.rows[#v.rows + 1] = { text = ("|cffffd100%s|r |cff808080(%s)|r %s"):format(e[2], where[e[3]], e[4]),
      b2 = { "Send", function() L.Say(e) end } }
  end
  return v
end
L.views = views
L.TABS = { { "online", "Who's on" }, { "call", "Call a group" }, { "raid", "Raid" }, { "leads", "Leads" },
  { "say", "Say" } }
function L.View(tab) return views[tab or L.tab]() end

-- The window ---------------------------------------------------------------------------------------------------------
local frame
local function tooltip(owner, title, text)
  if not GameTooltip then return end
  GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
  GameTooltip:SetText(title, 1, 1, 1)
  GameTooltip:AddLine(text, nil, nil, nil, true)
  GameTooltip:Show()
end
local function hideTooltip() if GameTooltip then GameTooltip:Hide() end end

local function button(parent, w, label)
  local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  b:SetSize(w, 22)
  b:SetText(label)
  ns.Skin("Button", b)
  return b
end

local function draw()
  if not frame or not frame:IsShown() then return end
  local v = L.View()
  frame.banner:SetShown(L.rehearse)
  for _, t in ipairs(frame.tabs) do t:SetEnabled(t.key ~= L.tab) end
  frame.head:SetText(table.concat(v.head, "\n"))
  frame.input:SetShown(v.input and true or false)
  local pages = math.max(1, math.ceil(#v.rows / ns.LEAD_ROWS))
  L.page = math.min(L.page, pages)
  for i, row in ipairs(frame.rows) do
    local r = v.rows[(L.page - 1) * ns.LEAD_ROWS + i]
    row:SetShown(r ~= nil)
    if r then
      row.text:SetText(r.text)
      row.pick = r.pick
      for _, k in ipairs({ "b1", "b2" }) do
        row[k]:SetShown(r[k] ~= nil)
        if r[k] then row[k]:SetText(r[k][1]); row[k].fn = r[k][2] end
      end
    end
  end
  frame.more:SetShown(pages > 1)
  frame.more:SetText(("Page %d of %d"):format(L.page, pages))
  for i, b in ipairs(frame.actions) do
    local a = v.actions[i]
    b:SetShown(a ~= nil)
    if a then b:SetText(a[1]); b.fn, b.tip = a[2], a[3] end
  end
  frame.answer:SetText(table.concat(L.notes, "\n"))
end
L.refresh = function() ns.protect(draw) end

local function build()
  local ok, f = pcall(CreateFrame, "Frame", "UW_GuildLead", UIParent, "BasicFrameTemplateWithInset")
  if not ok or not f then f = CreateFrame("Frame", "UW_GuildLead", UIParent, "BackdropTemplate") end
  f:SetSize(620, 470)
  f:SetPoint("CENTER")
  f:SetFrameStrata("HIGH")
  f:SetMovable(true)
  f:EnableMouse(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  tinsert(UISpecialFrames, "UW_GuildLead") -- Esc closes it
  ns.SkinWindow(f)
  local title = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  title:SetPoint("TOP", 0, -6)
  title:SetText("Lead a group")
  ns.Skin("Font", title)

  -- Rehearse: the switch top right, and an orange line while it's on, so a practice run never looks like a real one.
  local cb = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate")
  cb:SetSize(22, 22)
  cb:SetPoint("TOPRIGHT", -96, -26)
  local cbl = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  cbl:SetPoint("LEFT", cb, "RIGHT", 2, 0)
  cbl:SetText("Rehearse")
  cb:SetScript("OnClick", function(self) ns.protect(L.SetRehearse, self:GetChecked()) end)
  cb:SetScript("OnEnter", function(self) tooltip(self, "Rehearse", "Practice guildmates, a practice raid and practice "
    .. "answers. Nothing is sent or invited.") end)
  cb:SetScript("OnLeave", hideTooltip)
  ns.Skin("Checkbox", cb)
  ns.useButton(cb, "lead rehearse")
  f.rehearse = cb
  f.banner = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  f.banner:SetPoint("TOPLEFT", 16, -30)
  f.banner:SetText("|cffff8000Rehearsal: nothing is sent.|r")

  -- Tabs down the left.
  f.tabs = {}
  for i, t in ipairs(L.TABS) do
    local b = button(f, 110, t[2])
    b:SetPoint("TOPLEFT", 12, -56 - (i - 1) * 26)
    b.key = t[1]
    b:SetScript("OnClick", function() L.tab, L.page = t[1], 1; L.refresh() end)
    ns.useButton(b, "lead " .. t[1])
    f.tabs[i] = b
  end

  f.head = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  f.head:SetPoint("TOPLEFT", 132, -56)
  f.head:SetWidth(470)
  f.head:SetJustifyH("LEFT")
  f.input = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
  f.input:SetSize(200, 20)
  f.input:SetPoint("TOPLEFT", 138, -88)
  f.input:SetAutoFocus(false)
  f.input:SetMaxLetters(40)
  f.input:SetText("a dungeon")
  f.input:SetScript("OnTextChanged", function(self) L.what = self:GetText(); L.refresh() end)
  f.input:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
  f.input:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  ns.Skin("EditBox", f.input)

  f.rows = {}
  for i = 1, ns.LEAD_ROWS do
    local row = CreateFrame("Button", nil, f)
    row:SetSize(470, 22)
    row:SetPoint("TOPLEFT", 132, -112 - (i - 1) * 24)
    row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.text:SetPoint("LEFT", 0, 0)
    row.text:SetWidth(300)
    row.text:SetJustifyH("LEFT")
    row:SetScript("OnClick", function(self) if self.pick then ns.protect(self.pick); L.refresh() end end)
    for k, x in pairs({ b1 = 306, b2 = 392 }) do
      local b = button(row, 82, "")
      b:SetPoint("LEFT", x, 0)
      b:SetScript("OnClick", function(self) if self.fn then ns.protect(self.fn); L.refresh() end end)
      ns.useButton(b, "lead row")
      row[k] = b
    end
    f.rows[i] = row
  end
  f.more = button(f, 110, "Page 1 of 1")
  f.more:SetPoint("TOPLEFT", 12, -56 - #L.TABS * 26 - 10)
  f.more:SetScript("OnClick", function()
    local v = L.View()
    L.page = L.page % math.max(1, math.ceil(#v.rows / ns.LEAD_ROWS)) + 1
    L.refresh()
  end)
  ns.useButton(f.more, "lead page")

  f.actions = {}
  for i = 1, 5 do
    local b = button(f, 150, "") -- two rows of three, so every label fits
    b:SetPoint("BOTTOMLEFT", 132 + (i - 1) % 3 * 156, 84 - math.floor((i - 1) / 3) * 26)
    b:SetScript("OnClick", function(self) if self.fn then ns.protect(self.fn); L.refresh() end end)
    ns.useButton(b, "lead action")
    b:SetScript("OnEnter", function(self) if self.tip then tooltip(self, self:GetText(), self.tip) end end)
    b:SetScript("OnLeave", hideTooltip)
    f.actions[i] = b
  end
  f.answer = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  f.answer:SetPoint("BOTTOMLEFT", 16, 12)
  f.answer:SetWidth(590)
  f.answer:SetJustifyH("LEFT")
  f:SetScript("OnShow", function() L.refresh() end)
  -- The call's minutes and who's online change on their own: redraw every 5 seconds while open.
  local tick = 0
  f:SetScript("OnUpdate", function(_, dt)
    tick = tick + (dt or 0)
    if tick >= 5 then tick = 0; L.refresh() end
  end)
  return f
end

function L.Open()
  if not ns.isOfficer(ns.me()) then say("Officers only for now: /uw lead opens the tools for running groups.") return false end
  if InCombatLockdown() then say("After the fight: /uw lead.") return false end
  frame = frame or build()
  frame:Show()
  L.refresh()
  return true
end

ns.commands.lead = function(args)
  local w = strtrim(args or ""):lower()
  if w == "rehearse" then
    if not L.Open() then return end
    frame.rehearse:SetChecked(true)
    L.SetRehearse(true)
    return
  end
  L.Open()
end

local f = CreateFrame("Frame")
ns.listen(f, { "CHAT_MSG_GUILD", "GROUP_ROSTER_UPDATE" })
f:SetScript("OnEvent", function(_, event, msg, sender)
  if event == "CHAT_MSG_GUILD" then ns.protect(L.Heard, msg, sender)
  elseif L.refresh then L.refresh() end
end)
