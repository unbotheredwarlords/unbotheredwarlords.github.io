-- Lead a group: one window with every tool an officer needs to see and direct grouping (Louis, 8 Nov 2026: "ensure I
-- have all the menus, tools, etc. necessary in a clean in game interface", worried about "giving hugely wrong vibes"
-- when grouping starts). /uw lead, or Lead a group on the options page. Officers had it first (CONTRIBUTING.md, gentle
-- rollouts, rule 4); any Raider opens it from Sat 14 Nov and any Member from Sat 21 Nov, each told the day before
-- (Louis, 8 Nov: no appointed leads, "any Raider who wants to lead, leads"; Members too, as recommended, since nobody
-- is 60 yet and Members lead the dungeon groups). Officer work stays with officers: the Notes tab, buddy pairing,
-- asking for job helpers, raid sign-ups and promoting Raiders.
--   * Dungeons (behind ns.PARTY_SUGGEST): the dungeons guildmates online fit now, the best one chosen already; the
--     group for it as a table, the call as guild chat will show it, and one red button that says it.
--   * Who's on: online guildmates near your level, at 60 or all, with who answered your call and who signed up.
--   * Call a group: one guild-chat call; whoever says inv in the next 15 minutes is listed, and Invite next invites
--     one per press (an invite needs a click on the real client). Make it a raid, ready check, share the meet point.
--   * Raid: the next raid's sign-ups and bench, from the bot (the Guild Master's PC: Schedule.lua ns.RAID_ROSTER) and
--     the whisper sign-ups this client holds (Charter.lua). Invite signed-up and whisper the bench, one per press.
--   * Leads: pass the group lead or an assist, ask for guild job helpers, pair an online recruit with a buddy.
--   * Say: warm lines written ahead, in the guild's voice. A first click shows the line; a second sends it.
--   * Rehearse: practice guildmates, a practice raid and practice answers; nothing is sent or invited and no practice
--     name is saved, so the flows can be tried alone before a real test (rehearsal before a live run, as in
--     simulation training). The decision log notes only that a rehearsal ran.
-- Every action is an existing game call or /uw command; the window adds no message of its own to the addon protocol.
-- Answers to a call are read only for the 15 minutes after it, and only shown here (gentle rollouts, rule 6, as
-- /uw raiders does). This file writes nothing to UW_GuildDB but decision-log lines (ns.trace), the journal probe's
-- counts (UW_GuildDB.partyProbe and journalProbe, officers' clients and the Guild Master's account, below) and, through
-- WeekOne.lua, counts per night of calls, answers and asks (with who called or answered, kept on this PC only).
local _, ns = ...
local say = ns.say
-- Who opens /uw lead: officers always; then by rank index from a date (00:00 UTC), told the day before. Friend and
-- Trial (4, 5) are left out: anyone can still call a group by typing in guild chat.
ns.LEAD_OPEN = { [2] = { 1794614400, "Sat 14 Nov" },    -- Raider
  [3] = { 1795219200, "Sat 21 Nov" } }                    -- Member
local HEADSUP_AHEAD = 86400

-- 15 minutes, not 5 (Louis, 8 Nov: "we can't expect people to drop what they're doing"): time to finish a quest or a
-- flight first, so a call asks nothing of anyone mid-task.
ns.LEAD_CALL_WINDOW, ns.LEAD_CONFIRM, ns.LEAD_ROWS = 900, 6, 16 -- LEAD_ROWS: the most rows one page can show
local function g(name) return rawget(_G, name) end
local function now() return (GetServerTime and GetServerTime()) or time() end
local function officer() return ns.isOfficer(ns.me()) end
local function myRank()
  local full = ns.fullName(ns.me())
  return full and ns.rankOf[full]
end
local function opening() local r = myRank() return r and ns.LEAD_OPEN[r] end
-- May this character open /uw lead now? Officers always; others once their rank's date in LEAD_OPEN has passed.
function ns.MayLead()
  if officer() then return true end
  local o = opening()
  return o ~= nil and now() >= o[1]
end
-- The Call a group tab is open to Member and up now (Louis, 9 Nov 00:18: "member and above"), ahead of LEAD_OPEN's
-- dates for the rest of the window. Friend and Trial still call by typing in guild chat. Calling is what anyone can
-- already do there; the tab only adds a line for their level, the answers and one invite per click. A Discord link is
-- preferred, not required (most members never link): every call is a guild chat line under the caller's own name, and
-- moving someone to Friend takes the tab away.
ns.LEAD_CALL_MAX_RANK = 3 -- Member
function ns.MayCall()
  if officer() then return true end
  local r = myRank()
  return r ~= nil and r <= ns.LEAD_CALL_MAX_RANK
end
-- Which tabs this character sees: officers all; from their rank's date everything but officer work; else Call a group.
local function tabOpen(t)
  -- Dungeons is a way to call a group, so whoever may call sees it, once Suggest a party is on.
  if t[1] == "dungeons" then return ns.PARTY_SUGGEST == true and ns.MayCall() end
  if officer() then return true end
  if ns.MayLead() then return not t.officer end
  return t[1] == "call" and ns.MayCall()
end
local function short(n) return ns.shortName(n) or n end
local function chat(sender, msg, channel, target) -- sender: a key in Outbound.lua (raid lines are off there)
  return ns.chat(sender, msg, channel, target) and true or false
end

-- Lines written ahead, in Louis's voice (8 Nov 2026, 22:22: "talking AT rather than WITH"). The bar is his own guild
-- line that night: "Big thank you to Cbipok, Deceiver, Flyhigh and Tyrone for bringing new friends into the guild!"
-- One short sentence, peer to peer, a question or an offer; no instructions beyond the one word that makes it work
-- (inv, raid), no pitch, no reassurance filler. Timers (the call's 15 minutes) stay in the addon, not in the line.
-- {key, button, where, text}. where: GUILD, GROUP (party or raid) or WHISPER (the name picked last in any list).
-- %s in a call is what it's for; {here} in a line is where you stand, so it reads the same with or without UW_Guild.
ns.LEAD_CALL = "Getting a group going for %s, who's in? Type inv here when you're free."
ns.LEAD_RAID_OPEN = "%s sign-ups are open, starting %s. Whisper me raid if you're coming!"
ns.LEAD_BENCH = "Thanks for signing up! We're full for now, so you're on the bench. I'll whisper you if a spot opens."
ns.LEAD_LINES = {
  { "full", "Group's full", "GUILD", "Group's full, thanks all! Next one soon." },
  { "help", "Offer a hand", "GUILD", "Anyone need a hand with a quest or dungeon? Happy to help." },
  { "welcome", "Welcome the group", "GROUP", "Welcome in! Ready check in a minute." },
  { "meet", "Meet point is set", "GROUP", "Meeting at {here}, come when you can." },
  { "break", "Short break", "GROUP", "Quick break, back in 5." },
  { "wipe", "After a wipe", "GROUP", "Good tries! Rebuff and we'll go again." },
  { "done", "End of the night", "GROUP", "That's a wrap, thanks for coming everyone!" },
  { "room", "Offer a spot", "WHISPER", "Hey, got a spot in my group if you want in!" },
  { "vet", "Ask to help", "WHISPER", "Hey! Getting a group going for some newer folks around your level, "
    .. "want to come along?" },
  -- In guild chat, 8 Nov: "the quests in the dungeons are where it's at". An offer to run some, never a lecture.
  { "why", "Dungeon run?", "GUILD", "Dungeon quests are great XP, anyone want to run some together?" },
}
-- A line as it goes out: {here} becomes "Crossroads, The Barrens" (or the zone alone).
function ns.LeadLineText(text)
  if not text:find("{here}", 1, true) then return text end
  local zone = GetZoneText and GetZoneText() or ""
  local sub = GetSubZoneText and GetSubZoneText() or ""
  if ns.isSecret(zone) then zone = "" end
  if ns.isSecret(sub) then sub = "" end
  local here = (sub ~= "" and sub ~= zone and zone ~= "") and (sub .. ", " .. zone) or (zone ~= "" and zone or "the meet point")
  return (text:gsub("{here}", function() return here end))
end

local L = { tab = "online", filter = "near", page = 1, rehearse = false, answers = {}, invited = {}, whispered = {},
  notes = {} }
ns.Lead = L
L.TabOpen = tabOpen
local frame -- the window, built on first open

-- Answers shown in the window too: the last few, newest last.
local function note(msg)
  say(msg)
  L.notes[#L.notes + 1] = msg
  while #L.notes > 3 do table.remove(L.notes, 1) end
  if L.refresh then L.refresh() end
end
L.note = note

-- In a rehearsal every action only says what it would do.
local function act(desc, fn)
  if L.rehearse then note("Rehearse: " .. desc) return true end
  return fn()
end

-- Rehearsal data: practice guildmates around your level, a practice raid with a bench, a practice group.
local function practiceRoster()
  local me = UnitLevel("player") or 20
  local rows = {}
  for i, p in ipairs({ { "Ada Vale", 0, "PRIEST" }, { "Brann Holt", 1, "WARRIOR" }, { "Cora Finch", -2, "MAGE" },
    { "Dax Morrow", 2, "ROGUE" }, { "Elle Quill", 0, "DRUID" }, { "Finn Rook", -1, "HUNTER" },
    { "Gale Pike", nil, "SHAMAN" }, { "Hale Stone", nil, "WARLOCK" }, { "Iris Thorn", nil, "PALADIN" },
    { "Kael Moss", nil, "MAGE" } }) do
    local lvl = p[2] and math.max(1, math.min(60, me + p[2])) or 60
    rows[i] = { name = p[1] .. " (practice)", full = p[1] .. " (practice)", level = lvl, cls = p[3],
      zone = lvl == 60 and "Orgrimmar" or "The Barrens", rank = i == 7 and 2 or 3, rankName = i == 7 and "Raider" or "Member" }
  end
  return rows
end
local function practiceRaid(at)
  local n = function(s) return s .. " (practice)" end
  return { start = at + 2 * 3600, title = "Practice raid", cap = { 2, 2, 6 }, size = 10, unlinked = 1, asOf = at,
    list = { { n("Brann Holt"), "t", "in" }, { n("Iris Thorn"), "t", "in" }, { n("Ada Vale"), "h", "in" },
      { n("Elle Quill"), "h", "in" }, { n("Cora Finch"), "d", "in" }, { n("Dax Morrow"), "d", "in" },
      { n("Finn Rook"), "d", "in" }, { n("Gale Pike"), "d", "in" }, { n("Hale Stone"), "d", "in" },
      { n("Jory Lane"), "d", "in" }, { n("Kael Moss"), "d", "bench" }, { n("Lark Penn"), "h", "bench" },
      { n("Mara Dune"), "d", "maybe" } },
    whispered = { { n("Nell Brook"), "d" } } }
end
local PRACTICE_GROUP = { "Gale Pike (practice)", "Iris Thorn (practice)", "Dax Morrow (practice)" }

-- Who's on ---------------------------------------------------------------------------------------------------------
local function roster()
  if L.rehearse then return practiceRoster() end
  local rows, self = {}, ns.me()
  for i = 1, GetNumGuildMembers() or 0 do
    local full, rankName, rank, level, _, zone, _, _, online, status, cls = GetGuildRosterInfo(i)
    full = ns.fullName(full)
    if full and online and full ~= self and type(level) == "number" and not ns.isSecret(level) then
      rows[#rows + 1] = { name = short(full), full = full, level = level, cls = type(cls) == "string" and cls or nil,
        busy = ns.RosterBusy and ns.RosterBusy(status, zone) or nil,
        zone = type(zone) == "string" and not ns.isSecret(zone) and zone or "?", rank = rank,
        rankName = type(rankName) == "string" and not ns.isSecret(rankName) and rankName or "" }
    end
  end
  return rows
end

-- Names in my group, by the roster's spelling (Forever's UnitName gives the parts; ns.unitFull joins them).
local function groupNames()
  local out = {}
  if L.rehearse then
    for _, n in ipairs(PRACTICE_GROUP) do out[n] = true end
    return out
  end
  local raid = IsInRaid()
  for i = 1, GetNumGroupMembers() or 0 do
    local full = ns.unitFull(raid and ("raid" .. i) or ("party" .. i))
    if full then out[short(full)] = true end
  end
  return out
end

local function calledRecently() return L.call and now() - L.call.at < ns.LEAD_CALL_WINDOW end

-- Online guildmates for the list: near (your level +-NEAR_RANGE), sixty (level 60), called (answered your call),
-- or all. Nearest level first, then by name.
function L.Online(filter)
  filter = filter or L.filter
  local mine, range = UnitLevel("player") or 1, (ns.NEAR_RANGE or 3) + 2
  local signed = {}
  local raid = L.Raid()
  for _, p in ipairs(raid and raid.people or {}) do signed[p.name] = p end
  local answered = {}
  for _, a in ipairs(L.answers) do answered[a.name] = true end
  local out = {}
  for _, r in ipairs(roster()) do
    local keep = filter == "all" or (filter == "near" and math.abs(r.level - mine) <= range)
      or (filter == "sixty" and r.level >= 60) or (filter == "called" and answered[r.name])
    if keep then
      r.answered, r.signed = answered[r.name], signed[r.name]
      out[#out + 1] = r
    end
  end
  -- Free first (render pass, 9 Nov 2026): AFK, Do Not Disturb and mid-dungeon guildmates go last, marked.
  table.sort(out, function(a, b)
    if (a.busy ~= nil) ~= (b.busy ~= nil) then return a.busy == nil end
    local da, db = math.abs(a.level - mine), math.abs(b.level - mine)
    if da ~= db then return da < db end
    return a.name < b.name
  end)
  return out
end

-- Online short names, for the raid and call lists.
local function onlineSet()
  local out = {}
  for _, r in ipairs(roster()) do out[r.name] = r end
  return out
end

-- Invites ----------------------------------------------------------------------------------------------------------
local function invite(name, full)
  if L.invited[name] then note(("%s has an invite from you already."):format(name)) return false end
  local ok = act(("would invite %s."):format(name), function()
    local fn = (g("C_PartyInfo") and g("C_PartyInfo").InviteUnit) or g("InviteUnit")
    local sent = type(fn) == "function" and pcall(fn, full or name) or false
    ns.trace("lead", "invite", sent, not sent and "the game refused the invite" or nil, name)
    note(sent and ("Invited %s."):format(name) or ("The game didn't send %s an invite."):format(name))
    return sent
  end)
  if ok then L.invited[name] = now() end -- a refused invite can be tried again
  return ok
end
L.invite = invite

-- The next online name from list (short names, in order) who isn't grouped or invited already: one per press.
local function inviteNext(list, what)
  local on, grouped = onlineSet(), groupNames()
  for _, name in ipairs(list) do
    if on[name] and not grouped[name] and not L.invited[name] then return invite(name, on[name].full) end
  end
  note(("Nobody left to invite from %s: everyone is grouped, invited or offline."):format(what))
  return false
end

-- Call a group -------------------------------------------------------------------------------------------------------
local armed -- { key, until }: a first click shows a line, a second one sends it
-- place: where it goes ("guild chat"); text: the line itself, shown on its own so it reads as members will see it.
-- above: the line is already on screen over the notice (the Dungeons tab's strip), so the notice doesn't say it again
-- (design director and coordinator, 15 Nov 2026).
local function confirm(key, place, text, above)
  if armed and armed[1] == key and GetTime() <= armed[2] then armed = nil return true end
  armed = { key, GetTime() + ns.LEAD_CONFIRM }
  note(("Click again within %d s to %s%s"):format(ns.LEAD_CONFIRM, place, above and "." or ":"))
  if text and not above then note(text) end
  return false
end
L.confirm = confirm

function L.CallText(what)
  what = strtrim(what or ""):gsub("[|\n]", "")
  if what == "" then what = "a dungeon" end
  return ns.LEAD_CALL:format(what:sub(1, 40))
end

-- Suggested call (8 Nov; Louis asked what "newcomers online with no guild group seen yet" is for; 23:22 priority 1 is
-- a first dungeon for every newcomer): the dungeon whose level range holds the most online newcomers WeekOne.lua
-- hasn't seen in a dungeon with a guildmate, at least 2, leaving out anyone inside an instance now. A call that names
-- the dungeon and its levels is a concrete plan people can say yes to, and lets everyone else tell at a glance it isn't
-- for them; one line in guild chat reaches them all with no addon on their side, and nobody is whispered. A tie goes to
-- the dungeon whose range centres closest on their levels: at the top of a range a run is quick but gives little (grey
-- loot, low XP), at the bottom it's a struggle; the middle is the run a first-timer enjoys. Returns { what = "Wailing Caverns (15-24)", name, n, lo, hi, names,
-- waiting }, lo-hi being the newcomers' own levels (for helpers), or nil.
ns.LEAD_SUGGEST_AT_LEAST = 2
-- Horde 5-player dungeons, low to high, with Forever's suggested levels: its group finder's ranges as listed by two
-- guides that agree (Warcraft Tavern's says they match the in-game tool), Forever's nine new dungeons included (addon
-- search, 13 Nov 2026; Hall of Thanes left out, as Horde rarely go under Ironforge). On a client whose group finder
-- answers, WeekOne.lua's ns.LearnGameDungeons puts the game's own numbers in these rows. Same list as
-- bot/uwbot/dungeons.py (/lfg); bot/tests/test_dungeons.py keeps the two the same.
ns.LEAD_DUNGEONS = {
  { "Ragefire Chasm", 13, 18 }, { "Ruins of Lordaeron", 15, 22 }, { "Wailing Caverns", 15, 24 },
  { "Shadowfang Keep", 20, 30 }, { "Blackfathom Deeps", 24, 32 }, { "Excavation Site", 26, 33 },
  { "City of Dalaran", 28, 35 }, { "Razorfen Kraul", 29, 38 }, { "Gnomeregan", 29, 38 },
  { "Scarlet Monastery: Graveyard", 30, 38 }, { "Scarlet Monastery: Library", 33, 41 }, { "The Drowned City", 35, 42 },
  { "Scarlet Monastery: Armory", 36, 44 }, { "Razorfen Downs", 37, 46 }, { "Scarlet Monastery: Cathedral", 38, 46 },
  { "Krol'dok Stronghold", 40, 47 }, { "Uldaman", 41, 51 }, { "Zul'Farrak", 44, 54 }, { "Maraudon", 46, 55 },
  { "Alcaz Prison", 48, 55 }, { "Sunken Temple", 50, 60 }, { "Blackrock Depths", 52, 60 },
  { "Dire Maul: East", 54, 60 }, { "Lower Blackrock Spire", 55, 60 }, { "Blackmaw Hold", 55, 60 },
  { "Dire Maul: West", 56, 60 }, { "Dire Maul: North", 56, 60 }, { "Shaper's Terrace", 58, 60 },
  { "Stratholme: Live", 58, 60 }, { "Stratholme: Undead", 58, 60 }, { "Scholomance", 58, 60 },
  { "Upper Blackrock Spire", 59, 60 },
}
-- For anyone without the newcomer list (WeekOne.lua shows it to officers and buddies): the dungeon for my own level,
-- the range centred closest on it. { what, name, n = 0, mine = true }, or nil below the first dungeon.
function L.ForMe()
  local mine, best = UnitLevel("player") or 0, nil
  for _, d in ipairs(ns.LEAD_DUNGEONS) do
    local off = math.abs((d[2] + d[3]) / 2 - mine)
    if mine >= d[2] and mine <= d[3] and (not best or off < best.off) then
      best = { off = off, n = 0, mine = true, name = d[1], what = ("%s (%d-%d)"):format(d[1], d[2], d[3]) }
    end
  end
  return best
end

-- The planned call (WeekOne.lua ns.WeekOnePlan): the dungeon and the hour, by the officer's own clock, when the most
-- newcomers who haven't grouped have been on. Members never see a time (Forever has no time zones).
function L.Plan()
  if L.rehearse or not (ns.WeekOnePlan and ns.WeekOneHelper and ns.WeekOneHelper()) then return nil end
  local p = ns.WeekOnePlan()
  if p then p.what = ("%s (%d-%d)"):format(p.name, p.dlo, p.dhi) end
  return p
end

-- names: the waiting newcomers in the range; waiting: every waiting newcomer (so helpers leave them all out).
function L.Suggest()
  local rows = {}
  if L.rehearse then
    for _, r in ipairs(practiceRoster()) do if r.level < 60 and r.rank ~= 2 then rows[#rows + 1] = r end end
  elseif ns.WeekOneWaiting and ns.WeekOneHelper and ns.WeekOneHelper() then
    for _, e in ipairs(ns.WeekOneWaiting()) do rows[#rows + 1] = e.row end
  end
  local best
  for _, d in ipairs(ns.LEAD_DUNGEONS) do
    local n, sum, a, b, names = 0, 0, nil, nil, {}
    for _, r in ipairs(rows) do
      local l = r.level
      if l >= d[2] and l <= d[3] and not (ns.IsInstanceZone and ns.IsInstanceZone(r.zone)) then
        n, sum, a, b = n + 1, sum + l, math.min(a or l, l), math.max(b or l, l)
        names[#names + 1] = r.name
      end
    end
    if n >= ns.LEAD_SUGGEST_AT_LEAST then
      local off = math.abs((d[2] + d[3]) / 2 - sum / n)
      if not best or n > best.n or (n == best.n and off < best.off) then
        best = { n = n, off = off, lo = a, hi = b, names = names, name = d[1],
          what = ("%s (%d-%d)"):format(d[1], d[2], d[3]) }
      end
    end
  end
  if not best then return nil end
  best.waiting = {}
  for _, r in ipairs(rows) do best.waiting[r.name] = true end
  return best
end

-- Helpers for a suggested call (8 Nov: 11 of 152 newcomers had a first dungeon with a guildmate): guildmates online
-- at or a little above those levels who aren't waiting newcomers themselves and aren't in a dungeon now, closest level
-- first. A newcomer's first run goes better with someone who knows the way; the officer asks them, two clicks each.
ns.LEAD_HELP_BELOW, ns.LEAD_HELP_ABOVE = 1, 5
function L.Helpers(s)
  if not s then return {} end
  local out, mid = {}, (s.lo + s.hi) / 2
  for _, r in ipairs(roster()) do
    if not s.waiting[r.name] and r.level >= s.lo - ns.LEAD_HELP_BELOW and r.level <= s.hi + ns.LEAD_HELP_ABOVE
      and not (ns.IsInstanceZone and ns.IsInstanceZone(r.zone)) then
      out[#out + 1] = r
    end
  end
  table.sort(out, function(a, b)
    local da, db = math.abs(a.level - mid), math.abs(b.level - mid)
    if da ~= db then return da < db end
    return a.name < b.name
  end)
  return out
end

-- Suggest a party (Louis, 14 Nov 2026: "'suggest a party' ... a highlight when it's available for a good and even
-- optimal grouping, given loot tables"; design: project file ops/matchmaking/suggest-party-design.md, coordinator OK
-- 05:04). The best five online for one dungeon, from what the roster shows for everyone (level, class, zone, busy):
-- other players' specs and gear aren't readable, so roles come from class (one who can tank, one who can heal) and
-- "loot" is the drops each class can use at its level, read from the client's own dungeon journal or, where that is
-- empty and the member has it, from the Dungeon Journal addon on their own client (ns.PartyLoot; no shipped data,
-- nothing of that addon kept or saved), a soft factor only. Waiting newcomers count (priority 1: a first dungeon), as do pairs not yet seen together, and
-- anyone suggested in the last 2 hours drops back so the same few aren't always picked. The names show only on the
-- caller's screen; the call line names the dungeon and a missing role, never people (coordinator, 14 Nov 05:04).
-- On since 15 Nov 2026 (coordinator, 03:28: wording W1-W7 cleared, flag on): it shows as the Dungeons tab, only to
-- someone who opens /uw lead, and sends nothing but the one call line a click asks for. PARTY_SUGGEST = false takes
-- the tab, the list and the highlight away again.
ns.PARTY_SUGGEST = true
if ns.PARTY_SUGGEST then L.tab = "dungeons" end -- where the window opens the first time in a session
ns.PARTY = { size = 5, slack = 2, pool = 10, recent = 7200, recentCost = 0.1,
  w = { level = 0.4, loot = 0.25, new = 0.25, pairs = 0.1 },
  choices = 6,  -- dungeon buttons at the Dungeons tab's foot (one of them "More dungeons" when more fit)
  hold = 15,    -- seconds the choices keep their order while the tab stays open, so no button slides under a click
  keep = 30,    -- seconds the highlight's party is kept before it's worked out again
  rest = 600 }  -- seconds the highlight rests once the Dungeons tab has been on screen
ns.PARTY_TANK = { WARRIOR = 2, DRUID = 1, PALADIN = 1 }                -- who can; the higher number takes the role first
ns.PARTY_HEAL = { PRIEST = 2, SHAMAN = 1, DRUID = 1, PALADIN = 1 }
-- What each class looks for in a drop: its best armor at a level (it can wear lighter, but won't want it) and stats.
local BEST_ARMOR = { WARRIOR = { 3, 4 }, PALADIN = { 3, 4 }, HUNTER = { 2, 3 }, SHAMAN = { 2, 3 }, ROGUE = { 2, 2 },
  DRUID = { 2, 2 }, MAGE = { 1, 1 }, PRIEST = { 1, 1 }, WARLOCK = { 1, 1 } } -- armor subclass before 40, from 40
local WANT_STAT = { WARRIOR = { STR = 1 }, PALADIN = { STR = 1, INT = 1 }, HUNTER = { AGI = 1 }, ROGUE = { AGI = 1 },
  SHAMAN = { INT = 1, STR = 1, AGI = 1 }, DRUID = { INT = 1, AGI = 1, STR = 1 }, MAGE = { INT = 1 },
  PRIEST = { INT = 1, SPI = 1 }, WARLOCK = { INT = 1 } }

-- Does this class want this drop at this level? item = { lvl, armor (1 cloth .. 4 plate, nil: not body armor), stat }.
function ns.PartyWants(cls, level, item)
  if not (cls and BEST_ARMOR[cls]) then return false end
  local lvl = item.lvl or level
  if lvl > level + 4 or lvl < level - 2 then return false end
  if item.armor and item.armor ~= BEST_ARMOR[cls][level >= 40 and 2 or 1] then return false end
  return not item.stat or WANT_STAT[cls][item.stat] == 1
end

-- Who plays what in a set: one tank and one healer, two different people (a druid can be either), the rest damage.
-- { [name] = "tank" | "healer" | "damage" }, and what's missing ({ "a tank" } ...). Among the ways to fill both, the
-- classes that most often play the role take it (PARTY_TANK, PARTY_HEAL: a warrior tanks before a druid, a priest
-- heals before a shaman), so a druid who calls a group with a priest in it isn't told they'd heal. The caller
-- settles it in chat: nobody's spec can be read.
local function roles(set)
  local best, bestMiss, bestFit
  local function try(t, h)
    local r, miss = {}, {}
    for _, m in ipairs(set) do r[m.name] = (m == t and "tank") or (m == h and "healer") or "damage" end
    if not t then miss[#miss + 1] = "a tank" end
    if not h then miss[#miss + 1] = "a healer" end
    local fit = (t and ns.PARTY_TANK[t.cls] or 0) + (h and ns.PARTY_HEAL[h.cls] or 0)
    if not bestMiss or #miss < #bestMiss or (#miss == #bestMiss and fit > bestFit) then best, bestMiss, bestFit = r, miss, fit end
  end
  local tanks, heals = { false }, { false }
  for _, m in ipairs(set) do
    if ns.PARTY_TANK[m.cls or ""] then tanks[#tanks + 1] = m end
    if ns.PARTY_HEAL[m.cls or ""] then heals[#heals + 1] = m end
  end
  for _, t in ipairs(tanks) do
    for _, h in ipairs(heals) do
      if not (t and h and t == h) then try(t or nil, h or nil) end
    end
  end
  return best, bestMiss
end
ns.PartyRoles = roles

-- The pure rule. d = { name, lo, hi }; rows = { name, full, level, cls, new }; opts = { me = row or nil, loot = { item
-- ... } (an item may stand for n alike) or nil (no drop list at all: the classes are mixed instead) or {} (a drop list with nothing for this dungeon),
-- together = { ["A|B"] = t }, recent = { [name] = at }, now }. The best party (score, good) or nil.
function ns.PartyPick(d, rows, opts)
  opts = opts or {}
  local P, lo, hi = ns.PARTY, d.lo - ns.PARTY.slack, d.hi + ns.PARTY.slack
  local mid, half = (d.lo + d.hi) / 2, (d.hi - d.lo) / 2 + ns.PARTY.slack
  local me = opts.me and opts.me.level >= lo and opts.me.level <= hi and opts.me or nil
  local pool = {}
  for _, r in ipairs(rows) do
    if r ~= opts.me and r.level >= lo and r.level <= hi then pool[#pool + 1] = r end
  end
  table.sort(pool, function(a, b)               -- the pool closest to the dungeon's middle, newcomers first on a tie
    local da, db = math.abs(a.level - mid), math.abs(b.level - mid)
    if da ~= db then return da < db end
    if (a.new and 1 or 0) ~= (b.new and 1 or 0) then return a.new == true end
    return a.name < b.name
  end)
  while #pool > P.pool do pool[#pool] = nil end
  local need = P.size - (me and 1 or 0)
  if #pool + (me and 1 or 0) < 2 then return nil end
  -- Drops, once a pick: grouped by who among the people considered wants them, so scoring a set looks at a handful
  -- of groups and not at every drop (a journal addon lists a few hundred a dungeon; a pool gives 210 sets).
  local groups, want, get = nil, {}, {}
  if opts.loot and #opts.loot > 0 then
    local all, byKey = { me }, {}
    if not me then all = {} end
    for _, m in ipairs(pool) do all[#all + 1] = m end
    groups = {}
    for _, it in ipairs(opts.loot) do
      local key, who = "", {}
      for i, m in ipairs(all) do
        if ns.PartyWants(m.cls, m.level, it) then who[m], key = true, key .. i .. "," end
      end
      if key ~= "" then
        local gr = byKey[key]
        if not gr then gr = { n = 0, who = who } byKey[key], groups[#groups + 1] = gr, gr end
        gr.n = gr.n + (it.n or 1)
      end
    end
  end
  local function score(set)
    local n, lvl, newN, pairsNew, pairsAll, recent = #set, 0, 0, 0, 0, 0
    for i, m in ipairs(set) do
      lvl = lvl + math.max(0, 1 - math.abs(m.level - mid) / half)
      if m.new then newN = newN + 1 end
      if m ~= me and opts.recent and opts.recent[m.name] and (opts.now or 0) - opts.recent[m.name] < P.recent then
        recent = recent + 1
      end
      for j = i + 1, n do
        local a, b = m.full or m.name, set[j].full or set[j].name
        local k = a < b and (a .. "|" .. b) or (b .. "|" .. a)
        pairsAll = pairsAll + 1
        if not (opts.together and opts.together[k]) then pairsNew = pairsNew + 1 end
      end
    end
    -- No journal (Forever's reports no tiers, 15 Nov): how many different classes, for the same reason as loot
    -- spread. Two of a class want the same drops, and main spec first makes one of them lose.
    local seen, kinds = {}, 0
    for _, m in ipairs(set) do
      if m.cls and not seen[m.cls] then seen[m.cls], kinds = true, kinds + 1 end
    end
    local loot = kinds / n
    if groups then
      -- Each member: of the drops they want, the share they wouldn't have to contest (a drop two want is half a
      -- drop each); nothing when the dungeon holds none for them. A share, so a long drop list doesn't make every
      -- set look the same (15 Nov: "three drops each is plenty" did, once a list held 90).
      for _, m in ipairs(set) do want[m], get[m] = nil, nil end
      for _, gr in ipairs(groups) do
        local c = 0
        for _, m in ipairs(set) do if gr.who[m] then c = c + 1 end end
        if c > 0 then
          for _, m in ipairs(set) do
            if gr.who[m] then want[m], get[m] = (want[m] or 0) + gr.n, (get[m] or 0) + gr.n / c end
          end
        end
      end
      local share = 0
      for _, m in ipairs(set) do
        if want[m] then share = share + get[m] / want[m] end
      end
      -- Half by the drops, half by the class mix: a list that only tells cloth from leather can't see that two
      -- mages want the very same piece and a mage and a priest less so.
      loot = (loot + share / n) / 2
    elseif opts.loot then
      -- A drop list is there but has nothing for this dungeon (or none of it is body armor): the armor each class
      -- wears stands in, on the same scale, so this dungeon isn't scored by another rule than the ones beside it.
      local by, worn = {}, {}
      for _, m in ipairs(set) do
        local a = m.cls and BEST_ARMOR[m.cls]
        worn[m] = a and a[(m.level or 0) >= 40 and 2 or 1]
        if worn[m] then by[worn[m]] = (by[worn[m]] or 0) + 1 end
      end
      local share = 0
      for _, m in ipairs(set) do if worn[m] then share = share + 1 / by[worn[m]] end end
      loot = (loot + share / n) / 2
    end
    local w = P.w
    return w.level * lvl / n + w.loot * loot + w.new * math.min(newN, 2) / 2
      + w.pairs * (pairsAll > 0 and pairsNew / pairsAll or 0) - P.recentCost * recent
  end
  local best
  local function consider(set)
    local r, miss = roles(set)
    local full = #set == P.size and #miss == 0
    local sc = score(set)
    -- A full party with both roles beats any partial one; then the higher score.
    if not best or (full and not best.full) or (full == best.full and #set > #best.set)
      or (full == best.full and #set == #best.set and sc > best.score) then
      best = { set = { unpack(set) }, roles = r, need = miss, score = sc, full = full }
    end
  end
  local pick = {}
  local k = math.min(need, #pool)
  local function walk(from, left)
    if left == 0 then
      local set = { me }
      if not me then set = {} end
      for _, m in ipairs(pick) do set[#set + 1] = m end
      consider(set)
      return
    end
    for i = from, #pool - left + 1 do
      pick[#pick + 1] = pool[i]
      walk(i + 1, left - 1)
      pick[#pick] = nil
    end
  end
  walk(1, k)
  if not best then return nil end
  best.name, best.lo, best.hi = d.name, d.lo, d.hi
  best.what = ("%s (%d-%d)"):format(d.name, d.lo, d.hi)
  -- Good: five, a tank and a healer, everyone inside the dungeon's own levels (the slack only widens who's
  -- considered). The best of those is the one shown: newcomers, loot and new pairs raise it, they don't gate it.
  best.good = best.full
  for _, m in ipairs(best.set) do if m.level < d.lo or m.level > d.hi then best.good = false end end
  return best
end

-- Drops per dungeon from the client's own journal, read once per session per dungeon, out of combat: { lvl, armor,
-- stat } per drop, or nil when the journal has no loot for it. Every call is guarded: a missing or changed API means
-- no loot factor, never an error.
local gameCache = {}
local STATS = { ITEM_MOD_STRENGTH_SHORT = "STR", ITEM_MOD_AGILITY_SHORT = "AGI", ITEM_MOD_INTELLECT_SHORT = "INT",
  ITEM_MOD_SPIRIT_SHORT = "SPI" }
local function pcallv(fn, ...) if type(fn) ~= "function" then return nil end local r = { pcall(fn, ...) }
  if r[1] then return select(2, unpack(r)) end end
local function journalInstances()
  local out, tiers = {}, pcallv(g("EJ_GetNumTiers"))
  if type(tiers) ~= "number" or ns.isSecret(tiers) then return out end
  local before = pcallv(g("EJ_GetCurrentTier"))
  for t = 1, math.min(tiers, 40) do
    pcallv(g("EJ_SelectTier"), t)
    for i = 1, 80 do
      local id, name = pcallv(g("EJ_GetInstanceByIndex"), i, false)
      if not id then break end
      if type(name) == "string" and not ns.isSecret(name) then out[ns.PlainDungeonKey(name)] = id end
    end
  end
  if type(before) == "number" then pcallv(g("EJ_SelectTier"), before) end
  return out
end
function ns.PlainDungeonKey(s)
  return (s:lower():gsub("['`]", ""):gsub("[%p%s]+", " "):gsub("^the ", ""):gsub("^ +", ""):gsub(" +$", ""))
end
-- The client's item functions live in C_Item on Forever, which has no GetItemInfoInstant global (the Guild Master's
-- probe, 15 Nov 17:22: 0 of 2,727 rows could be asked through the global); the old global where there is one.
local function itemFn(name)
  local items = g("C_Item")
  local fn = type(items) == "table" and items[name]
  if type(fn) == "function" then return fn end
  return g(name)
end
-- 1 cloth .. 4 plate when the game client knows the item as body armor, else nil. From the client's own item data
-- (GetItemInfoInstant: nothing is asked of the server). A cloak is cloth in that data and everyone wears one, so it
-- is not cloth armor here.
-- Second value: whether the client's item data knows the item at all (the probe counts both from one ask).
function ns.BodyArmor(itemID)
  local id, _, _, loc, _, classID, subID = pcallv(itemFn("GetItemInfoInstant"), itemID)
  if classID == 4 and type(subID) == "number" and subID >= 1 and subID <= 4 and loc ~= "INVTYPE_CLOAK" then
    return subID, true
  end
  return nil, id ~= nil
end
local instances
local function gameLoot(name)
  if gameCache[name] ~= nil then return gameCache[name] or nil end
  if InCombatLockdown() or (g("EncounterJournal") and g("EncounterJournal"):IsShown()) then return nil end
  if not instances then
    local found = journalInstances()
    if not next(found) then return nil end        -- no journal yet (or none at all): ask again later, cache nothing
    instances = found
  end
  local id = instances[ns.PlainDungeonKey(name)]
  if not id then gameCache[name] = false return nil end
  -- The journal lists only what its class and slot filters show, by default the player's own class (integrator, 14
  -- Nov): clear both for the read, then put them back, so every class's drops count.
  local cej = g("C_EncounterJournal") or {}
  local cls, spec = pcallv(g("EJ_GetLootFilter"))
  local slot = pcallv(cej.GetSlotFilter)
  -- Slot filter values follow Enum.ItemSlotFilterType where it exists (NoFilter is 15 on retail, Head is 0), so "set"
  -- is "not NoFilter", and unknown without the enum; it's always put back as it was.
  local enum = g("Enum") and g("Enum").ItemSlotFilterType
  local none = type(enum) == "table" and enum.NoFilter or nil
  if (type(cls) == "number" and cls > 0) or (type(slot) == "number" and none ~= nil and slot ~= none) then
    ns.partyFiltered = true
  end
  pcallv(g("EJ_SelectInstance"), id)
  pcallv(g("EJ_ResetLootFilter"))
  pcallv(cej.ResetSlotFilter)
  local n = pcallv(g("EJ_GetNumLoot"))
  local function restore()
    if type(cls) == "number" and cls > 0 then pcallv(g("EJ_SetLootFilter"), cls, spec or 0) end
    if type(slot) == "number" then pcallv(cej.SetSlotFilter, slot) end
  end
  if type(n) ~= "number" or ns.isSecret(n) or n < 1 then restore() gameCache[name] = false return nil end
  local items, info = {}, cej.GetLootInfoByIndex
  for i = 1, math.min(n, 120) do
    local itemID, link
    local t = pcallv(info, i)
    if type(t) == "table" then itemID, link = t.itemID, t.link
    else local a, _, _, _, _, _, l = pcallv(g("EJ_GetLootInfoByIndex"), i) itemID, link = a, l end
    if type(itemID) == "number" then
      local minLevel = select(5, pcallv(itemFn("GetItemInfo"), itemID))
      local it = { lvl = type(minLevel) == "number" and minLevel > 0 and minLevel or nil, armor = ns.BodyArmor(itemID) }
      local st = link and pcallv(itemFn("GetItemStats"), link)
      if type(st) == "table" then
        local top, v = nil, 0
        for k, x in pairs(st) do if STATS[k] and type(x) == "number" and x > v then top, v = STATS[k], x end end
        it.stat = top
      end
      items[#items + 1] = it
    end
  end
  restore()
  local ej = g("EncounterJournal")                -- the journal window's own pick, put back (red team, 15 Nov)
  if type(ej) == "table" and type(ej.instanceID) == "number" then pcallv(g("EJ_SelectInstance"), ej.instanceID) end
  gameCache[name] = #items > 0 and items or false
  return gameCache[name] or nil
end
ns.PartyGameLoot = gameLoot
-- (ns.PartyLoot, the read the pick uses, is below the other journal's probe: it falls back to that journal.)

-- Suggested this session: { [name] = at }, kept in memory only (nothing saved), so the same few aren't always picked.
L.partySeen = L.partySeen or {}
local function together()
  local w = UW_GuildDB and UW_GuildDB.weekOne
  return type(w) == "table" and type(w.together) == "table" and w.together or {}
end

-- The suggestion for a dungeon (or for my own level's dungeons when d is nil): the best party, or nil. Off while
-- PARTY_SUGGEST is off. Online guildmates who are busy (AFK, Do Not Disturb) or inside an instance are left out.
-- Who could come now: online guildmates who aren't busy or inside an instance, waiting newcomers marked (new).
local function freeRows()
  local waiting = {}
  if not L.rehearse and ns.WeekOneWaiting and ns.WeekOneHelper and ns.WeekOneHelper() then
    for _, e in ipairs(ns.WeekOneWaiting() or {}) do if e.row then waiting[e.row.name] = true end end
  end
  local rows = {}
  for _, r in ipairs(roster()) do
    if not r.busy and not (ns.IsInstanceZone and ns.IsInstanceZone(r.zone)) then
      r.new = waiting[r.name] or nil
      rows[#rows + 1] = r
    end
  end
  return rows
end
local function meRow()
  local fn, cls = g("UnitClass"), nil
  if type(fn) == "function" then cls = select(2, fn("player")) end
  return { name = short(ns.me() or "you"), full = ns.me(), level = UnitLevel("player") or 1, cls = cls, me = true }
end
function L.Party(d)
  if not ns.PARTY_SUGGEST or not ns.MayCall() then return nil end
  local rows, me = freeRows(), meRow()
  local list = {}
  if d then list = { d } else
    for _, x in ipairs(ns.LEAD_DUNGEONS) do
      if me.level >= x[2] and me.level <= x[3] then list[#list + 1] = { name = x[1], lo = x[2], hi = x[3] } end
    end
  end
  local best
  for _, x in ipairs(list) do
    local p = ns.PartyPick(x, rows, { me = me, loot = ns.PartyLoot(x.name), together = together(),
      recent = L.partySeen, now = now() })
    if p and (not best or (p.full and not best.full) or (p.full == best.full and p.score > best.score)) then best = p end
  end
  return best
end

-- One sentence over the group's table (coordinator, 15 Nov 03:28): "Good group for Wailing Caverns (15-24): 4
-- guildmates and you." It is the sentence cleared at 02:19 with a count where the names were: the names are the
-- table's rows. "and you (healer)" when the caller would fill a role, no "and you" for a dungeon outside the caller's
-- levels, and a partial group ends "Still needs a healer."
function ns.PartyHead(p, gold)
  local others, mine = 0, nil
  for _, m in ipairs(p.set) do if m.me then mine = m else others = others + 1 end end
  local who = ("%d %s"):format(others, others == 1 and "guildmate" or "guildmates")
  if mine then
    local role = p.roles[mine.name]
    who = who .. " and you" .. (role and role ~= "damage" and (" (%s)"):format(role) or "")
  end
  local lead = ("Good group for %s:"):format(p.what)
  if gold then lead = "|cffffd100" .. lead .. "|r" end   -- the Plan line's form: a gold lead-in, then the sentence
  return ("%s %s.%s"):format(lead, who,
    #p.need > 0 and (" Still needs " .. table.concat(p.need, " and ") .. ".") or "")
end

-- The guild-chat call: the dungeon and a missing role, never people (coordinator, 14 Nov 05:16: Louis's call tail kept,
-- no "now?"). Full: the usual call. Its own length check, not L.CallText's 40-character cap: a game-named dungeon is
-- cut so the line stays inside CALL_MAX_LEN (counted as a call) and far inside chat's 255.
ns.PARTY_CALL_NEED = "Getting a group going for %s, need %s. Type inv here when you're free."
function ns.PartyCallText(p)
  if #p.need == 0 then return L.CallText(p.what) end
  local need = table.concat(p.need, " and ")
  local room = math.min(ns.CALL_MAX_LEN or 140, 255) - #ns.PARTY_CALL_NEED:format("", need)
  local what = tostring(p.what or ""):gsub("[|\n]", "")
  return ns.PARTY_CALL_NEED:format(what:sub(1, math.max(room, 1)), need)
end

-- Call this group: the usual call (L.Call, so it counts, takes answers and ends the once-per-login offer the same way)
-- with the party's line. Marks its people as suggested. seen: the click came from the button beside the line in the
-- window (the Dungeons tab), so a line that has been on screen there goes on the first click (L.Shown).
function L.CallParty(p, seen)
  if not p then return false end
  local text = ns.PartyCallText(p)
  local sent = L.Call(p.what, text, seen)
  if sent then
    -- While the call is open, Dungeons keeps showing the group it was called for, and Call a group (where the
    -- window turns for the answers) has the dungeon in its box and the line that went out under it.
    L.call.party, L.what, L.dPick = p, p.what, p.name
    if frame and frame.input then frame.input:SetText(p.what) end
    for _, m in ipairs(p.set) do if not m.me then L.partySeen[m.name] = now() end end
    if not L.rehearse then ns.trace("lead", "party", true, ("%s, %d of %d"):format(p.name, #p.set, ns.PARTY.size)) end
  end
  return sent
end

-- The journal probe (coordinator, 14 Nov: read on the bot PC at hardening's next read): does Forever's journal have
-- loot for our dungeons? Officers' clients, once per client build, a minute after login, out of combat: counts only,
-- UW_GuildDB.partyProbe = { build, at, n = { [dungeon] = drops read } }, or { build, at, api = false } on a client
-- with no journal API. Runs whatever PARTY_SUGGEST says.
ns.PARTY_PROBE_TRIES, ns.PARTY_PROBE_GAP = 4, 300
-- Whose clients probe: an officer's character, and any character on the Guild Master's account (Outbound.lua's
-- ns.VoiceGated knows it; UW_GuildDB.gmAccount). His PC's save is the one that's read, and on 15 Nov he played a
-- Raider for the whole session: no officer on that client, so neither probe ran and neither left a stamp (hardening).
local function probes()
  if officer() then return true end
  if ns.VoiceGated then pcall(ns.VoiceGated) end -- notices his account from his alts' list, once the roster is read
  return type(UW_GuildDB) == "table" and UW_GuildDB.gmAccount == true
end
local probeTries = 0
-- A probe that breaks says so in the trace (hardening, 15 Nov: with no stamp in the save, "never ran", "nothing to
-- read" and "broke" looked the same). Only the place in our own file, never the message: it could carry another
-- addon's text.
function ns.ProbeSafely(what, fn)
  local ok, err = pcall(fn)
  if not ok and ns.trace then pcall(ns.trace, "lead", what, false, tostring(err):match("Lead%.lua:%d+") or "broke") end
  return ok
end
local function partyProbeLater(delay) ns.after(delay, function() ns.ProbeSafely("party probe", ns.PartyProbe) end) end
function ns.PartyProbe()
  if not probes() then return false end
  if InCombatLockdown() then                     -- in combat: the same try a little later, so the chain goes on
    if ns.after then partyProbeLater(ns.PARTY_PROBE_GAP) end
    return false
  end
  local build = tostring(select(2, pcallv(g("GetBuildInfo"))) or "?")
  local old = UW_GuildDB.partyProbe
  local same = type(old) == "table" and old.build == build
  -- No journal API at all: nothing to learn here, so no retry. The stamp says so (api = false), so a save with no
  -- stamp means the probe never ran, not that there was nothing to read.
  if type(g("EJ_GetNumTiers")) ~= "function" or type(g("EJ_GetNumLoot")) ~= "function" then
    if not same then UW_GuildDB.partyProbe = { build = build, at = now(), api = false } end
    return false
  end
  if same and old.api ~= false then return false end
  local n, total = {}, 0
  for _, d in ipairs(ns.LEAD_DUNGEONS) do
    local items = ns.PartyGameLoot(d[1])
    n[d[1]] = items and #items or 0
    total = total + n[d[1]]
  end
  -- Nothing read can mean a journal that hasn't loaded its loot yet (red team, 15 Nov): try again later in the
  -- session instead of stamping zeros for the whole build; the last try stamps what it found.
  probeTries = probeTries + 1
  if total == 0 and probeTries < ns.PARTY_PROBE_TRIES then
    for k in pairs(gameCache) do gameCache[k] = nil end
    instances = nil
    if ns.after then partyProbeLater(ns.PARTY_PROBE_GAP) end
    return false
  end
  UW_GuildDB.partyProbe = { build = build, at = now(), n = n, journal = instances and next(instances) ~= nil,
    filtered = ns.partyFiltered == true, tries = probeTries } -- filtered: a class or slot filter was set (and cleared)
  return true
end
-- After the roster is read (an officer check needs it; red team, 15 Nov), then a minute on.
table.insert(ns.onLoad, function()
  if ns.after and ns.afterRoster then
    ns.afterRoster(function() partyProbeLater(60) end)
  end
end)

-- Another journal (coordinator, 15 Nov 2026 04:07). Forever's own journal reports no tiers, so the pick has no drops
-- to spread. Dungeon Journal by Exehn (ForeverDungeonJournal), where a member has installed it, holds each boss's
-- drops. It has no licence, so nothing of it is copied, stored or shipped: it may only be read live, on the member's
-- own client, and everything falls back cleanly when it is absent or shaped differently. This is the first step, a
-- probe that saves counts only (no name, no item, no text of theirs): is it there, how many of our dungeons does it
-- know by our names, and what do its drop rows look like? Officers' clients, once per client build and journal
-- version, with the probe above. UW_GuildDB.journalProbe = { build, v, at, d = dungeons it lists, m = ours found,
-- miss = our own names it doesn't have, b = bosses, l = drop rows, ids = rows that open with a number,
-- asked = of those, the rows the client's own item data was asked about (0: it has no such function), inst = asked
-- rows it describes at once, arm = of those the body armor, f, sig = { [shape] = rows } },
-- or { build, v, at, db = false, g, t } when there was nothing to read (g, t: the type of its global and of its table).
-- A row's shape is the type of each field, one letter each ("nssn": number, string, string, number; "-" a hole).
ns.JOURNAL_ADDON, ns.JOURNAL_GLOBAL, ns.JOURNAL_SHAPES = "ForeverDungeonJournal", "ForeverDungeonJournal_NS", 6
-- What the probe counts; a stamp of an older count is read again. 2: inst and arm. 3: asked through C_Item, and no
-- sample through GetItemInfo any more (known: the pick never used it, and it would ask the server). Both 15 Nov.
ns.JOURNAL_PROBE_F = 3
ns.JOURNAL_PROBE_ASKS = 6000 -- rows the probe asks the client's item data about, at most
-- Its dungeon table, or nil and what was there instead: the type of its global and of its DB ("err": reading it broke).
local function journalAddon()
  local fdj = g(ns.JOURNAL_GLOBAL)
  if type(fdj) ~= "table" then return nil, type(fdj), nil end
  local ok, db = pcall(function() return fdj.DB end)
  if ok and type(db) == "table" then return db end
  return nil, "table", ok and type(db) or "err"
end
local function journalCount(db)
  local out = { d = 0, m = 0, miss = {}, b = 0, l = 0, ids = 0, asked = 0, inst = 0, arm = 0, sig = {} }
  local shapes, instant = 0, itemFn("GetItemInfoInstant")
  for _ in pairs(db) do out.d = out.d + 1 end
  for _, x in ipairs(ns.LEAD_DUNGEONS) do
    local e = db[x[1]]
    if type(e) ~= "table" then
      out.miss[#out.miss + 1] = x[1] -- our own name for it, from our own list
    else
      out.m = out.m + 1
      for _, boss in pairs(type(e.bosses) == "table" and e.bosses or {}) do
        out.b = out.b + 1
        for _, row in pairs(type(boss) == "table" and type(boss.loot) == "table" and boss.loot or {}) do
          out.l = out.l + 1
          local shape = ""
          if type(row) == "table" then
            for i = 1, math.min(#row, 8) do -- a hole in a row is "-", so it never reads as a number (integrator)
              shape = shape .. (row[i] == nil and "-" or type(row[i]):sub(1, 1))
            end
            if type(row[1]) == "number" then
              out.ids = out.ids + 1
              -- What the pick's live read (ns.PartyLoot) will find: rows the client's own item data describes,
              -- and of those the body armor. No server query, so every row is asked.
              -- One ask a row, and no more than JOURNAL_PROBE_ASKS in all (red team, 15 Nov: it was two a row with no
              -- cap; their list holds 2,727 rows). asked says how many rows inst and arm are counted over.
              if out.asked < ns.JOURNAL_PROBE_ASKS and type(instant) == "function" then
                out.asked = out.asked + 1
                local armor, there = ns.BodyArmor(row[1])
                if there then out.inst = out.inst + 1 end
                if armor then out.arm = out.arm + 1 end
              end
            end
          else
            shape = type(row):sub(1, 1) .. "!" -- not a row at all
          end
          if out.sig[shape] == nil and shapes >= ns.JOURNAL_SHAPES then shape = "other" end
          if out.sig[shape] == nil then shapes = shapes + 1 end
          out.sig[shape] = (out.sig[shape] or 0) + 1
        end
      end
    end
  end
  return out
end
function ns.JournalProbe()
  if not probes() or InCombatLockdown() then return false end
  local db, gt, dt = journalAddon()
  local build = tostring(select(2, pcallv(g("GetBuildInfo"))) or "?")
  local meta = type(C_AddOns) == "table" and C_AddOns.GetAddOnMetadata or g("GetAddOnMetadata")
  local v = pcallv(meta, ns.JOURNAL_ADDON, "Version")
  v = type(v) == "string" and v:match("^[%w%.%-]+$") and v:sub(1, 16) or "?"
  local old = UW_GuildDB.journalProbe
  local same = type(old) == "table" and old.build == build and old.v == v
  local read = same and old.db ~= false and old.f == ns.JOURNAL_PROBE_F
  -- Nothing to read (not installed, not loaded yet, its table gone or broken): the stamp says which, by type only,
  -- so a save with no stamp means the probe never ran (integrator, 15 Nov). A read of this build and version is
  -- kept; db = false is tried again, later this session and at each login.
  if not db then
    if not read and not (same and old.g == gt and old.t == dt) then -- the same answer again: the first stamp stands
      UW_GuildDB.journalProbe = { build = build, v = v, at = now(), db = false, g = gt, t = dt }
    end
    return false
  end
  if read then return false end
  local ok, out = pcall(journalCount, db)
  if not ok or type(out) ~= "table" then
    UW_GuildDB.journalProbe = { build = build, v = v, at = now(), err = true, f = ns.JOURNAL_PROBE_F } -- its shape broke the count
    return true
  end
  out.build, out.v, out.at, out.f = build, v, now(), ns.JOURNAL_PROBE_F
  UW_GuildDB.journalProbe = out
  return true
end
-- The pick's drops (coordinator, 15 Nov 04:07; the probe on the Guild Master's client, 15 Nov 14:15: the game's own
-- journal gave 0 drops for all 32 dungeons in four tries, the addon listed 30 of them by our names, 2,727 drop rows,
-- every one opening with an item number). Where the game's journal has nothing and a member has that addon, its list
-- for the dungeon is read in place, on their own client, when the pick asks: only each row's item number is looked
-- at, and only to ask the game client what armor it is (ns.BodyArmor: no server query). What is kept, for the
-- session and in memory only, is our own count per kind of armor ({ armor = 1..4, n = drops }, four rows at most):
-- no number, name or text of theirs, nothing saved, nothing sent. No addon, or it has changed shape: nil, and the pick mixes classes as before. The
-- addon is there but lists nothing for this dungeon: {}, and the pick goes by the armor each class wears.
ns.JOURNAL_ROWS = 400 -- drop rows looked at for one dungeon, at most
local theirCache = {}
local function addonLoot(name)
  local db = journalAddon()
  if not db then return nil end                  -- not installed, or not loaded yet: ask again next time
  if type(itemFn("GetItemInfoInstant")) ~= "function" then return nil end
  local ok, out = pcall(function()
    local e = db[name]
    local items, by, seen, n, walked = {}, {}, {}, 0, 0
    for _, boss in pairs(type(e) == "table" and type(e.bosses) == "table" and e.bosses or {}) do
      for _, row in pairs(type(boss) == "table" and type(boss.loot) == "table" and boss.loot or {}) do
        -- Enough: JOURNAL_ROWS different item numbers, or four times that many rows of any kind (repeats, rows
        -- that aren't rows). The walk ends there (red team, 15 Nov: it used to go on to the end of the list).
        walked = walked + 1
        if n >= ns.JOURNAL_ROWS or walked > ns.JOURNAL_ROWS * 4 then break end
        local id = type(row) == "table" and row[1]
        if type(id) == "number" and not seen[id] then
          seen[id], n = true, n + 1
          local armor = ns.BodyArmor(id)
          if armor and not by[armor] then by[armor] = { armor = armor, n = 0 } items[#items + 1] = by[armor] end
          if armor then by[armor].n = by[armor].n + 1 end
        end
      end
      if n >= ns.JOURNAL_ROWS or walked > ns.JOURNAL_ROWS * 4 then break end
    end
    table.sort(items, function(a, b) return a.armor < b.armor end)
    return items
  end)
  if not ok or type(out) ~= "table" then return false end -- its shape broke the read: not again this session
  return out
end
function ns.PartyLoot(name)
  local items = gameLoot(name)
  if items then return items end
  if theirCache[name] ~= nil then return theirCache[name] or nil end
  if InCombatLockdown() then return nil end
  local theirs = addonLoot(name)
  if theirs ~= nil then theirCache[name] = theirs end
  return theirs or nil
end

-- In combat when its turn comes, or nothing to read yet: the same try a little later, a few times in all.
local journalTries = 0
local function journalProbeLater(delay)
  ns.after(delay, function()
    if InCombatLockdown() and journalTries < ns.PARTY_PROBE_TRIES then
      journalTries = journalTries + 1
      return journalProbeLater(ns.PARTY_PROBE_GAP)
    end
    ns.ProbeSafely("journal probe", ns.JournalProbe)
    local p = UW_GuildDB and UW_GuildDB.journalProbe -- not there yet (an addon that loads late): a few more looks
    if type(p) == "table" and p.db == false and journalTries < ns.PARTY_PROBE_TRIES then
      journalTries = journalTries + 1
      journalProbeLater(ns.PARTY_PROBE_GAP)
    end
  end)
end
ns.JournalProbeLater = journalProbeLater
table.insert(ns.onLoad, function()
  if ns.after and ns.afterRoster then ns.afterRoster(function() journalProbeLater(75) end) end
end)

-- The highlight (drawn by the window lane, on the Dungeons tab): the good party for my own level, every time it's
-- asked while the mark should show, so a redraw keeps it. The window calls L.PartySeen() when it shows Dungeons, which
-- ends it for that dungeon this session. The party is worked out at most once in PARTY.keep seconds: at 60 a dozen
-- dungeons hold the caller's level, and a redraw comes every 5 seconds.
L.partyMarked = L.partyMarked or {}
local markAt, markParty, markSeen = nil, nil, nil
function L.PartyMark()
  if not ns.PARTY_SUGGEST then return nil end
  local t = GetTime()
  if markSeen and t >= markSeen and t - markSeen < ns.PARTY.rest then return nil end -- just looked at: nothing to flag
  if not markAt or t - markAt >= ns.PARTY.keep or t < markAt then
    markAt, markParty = t, nil -- set before the pick, so one that raises rests PARTY.keep too (red team, 15 Nov)
    markParty = L.Party()
  end
  local p = markParty
  if not (p and p.good) or L.partyMarked[p.name] then return nil end
  return p
end
-- The Dungeons tab is on screen (every draw of it): the highlight has done its work. Nothing is worked out here (the
-- pick over every dungeon at the caller's level costs tens of milliseconds with 40 online; integrator, 15 Nov), and
-- the mark rests for PARTY.rest.
function L.PartySeen()
  if markParty and markParty.good then L.partyMarked[markParty.name] = true end
  markSeen = GetTime()
end

-- The dungeons a group could form for now (Louis, 15 Nov 2026: "a better more curated experience ... for forming
-- groups for specific dungeons in one click"): every dungeon two or more people who could come fit (PartyPick's own
-- reach: the dungeon's levels and PARTY.slack either side; the caller counts where their level does), best first.
-- Best: the caller's own levels, then a full five with a tank and a healer who are two people, then the most people,
-- then both roles, then waiting newcomers (priority 1: a first dungeon), then the range centred closest on the caller.
-- Counts only, so the whole list costs one pass over the roster; the group itself is picked for the chosen dungeon.
-- { name, lo, hi, what, n, mine, roles, full }.
function L.DungeonList()
  if not ns.PARTY_SUGGEST or not ns.MayCall() then return {} end
  local rows, me, P, out = freeRows(), meRow(), ns.PARTY, {}
  for i, x in ipairs(ns.LEAD_DUNGEONS) do
    local lo, hi = x[2] - P.slack, x[3] + P.slack
    local n, tanks, heals, both, new = 0, 0, 0, 0, 0
    local function count(r)
      n = n + 1
      local t, h = ns.PARTY_TANK[r.cls or ""], ns.PARTY_HEAL[r.cls or ""]
      if t then tanks = tanks + 1 end
      if h then heals = heals + 1 end
      if t and h then both = both + 1 end
      if r.new then new = new + 1 end
    end
    if me.level >= lo and me.level <= hi then count(me) end
    for _, r in ipairs(rows) do if r.level >= lo and r.level <= hi then count(r) end end
    if n >= 2 then
      -- One druid or paladin fills one role, never both: with a single tank and a single healer, they're two people.
      local filled = tanks >= 1 and heals >= 1 and not (tanks == 1 and heals == 1 and both == 1)
      out[#out + 1] = { name = x[1], lo = x[2], hi = x[3], what = ("%s (%d-%d)"):format(x[1], x[2], x[3]),
        n = n, mine = me.level >= x[2] and me.level <= x[3], roles = filled, full = filled and n >= P.size,
        new = math.min(new, 2), off = math.abs((x[2] + x[3]) / 2 - me.level), i = i }
    end
  end
  table.sort(out, function(a, b)
    if a.mine ~= b.mine then return a.mine end
    if a.full ~= b.full then return a.full end
    local na, nb = math.min(a.n, P.size), math.min(b.n, P.size)
    if na ~= nb then return na > nb end
    if a.roles ~= b.roles then return a.roles end
    if a.new ~= b.new then return a.new > b.new end
    if a.off ~= b.off then return a.off < b.off end
    return a.i < b.i
  end)
  return out
end

-- The Dungeons tab's choices: the list above, kept in its order while the tab stays on screen (a redraw comes every 5
-- seconds; a button that slid under the pointer would choose another dungeon), and made again, with the best one
-- chosen, when the tab is come back to after PARTY.hold seconds, when it had nothing, or when the chosen dungeon's
-- group has gone. L.dPick: the chosen dungeon's name; L.dPage: which choices show when more than PARTY.choices fit.
local function choices(again)
  local t = GetTime()
  if again or not L.dList or #L.dList == 0 or not L.dSeen or t - L.dSeen > ns.PARTY.hold or t < L.dSeen then
    L.dList, L.dPage = L.DungeonList(), 1
    local called = calledRecently() and L.call.party -- an open call's dungeon stays the chosen one
    L.dPick = called and called.name or L.dList[1] and L.dList[1].name or nil
  end
  L.dSeen = t
  return L.dList
end
function L.PickDungeon(name)
  L.dPick, L.page = name, 1
  L.notes, armed = {}, nil -- "Click again to say ..." was about the dungeon chosen before
  if not L.rehearse then ns.trace("lead", "dungeon", true, name) end
end
-- A dungeon's name on its button, three to a row: Scarlet Monastery's wings by the name everyone types.
function ns.DungeonShort(name) return (name:gsub("^Scarlet Monastery: ", "SM: ")) end

-- The ask the Call box holds (render pass 3, 14 Nov): { name, what, at } after a click on a guildmate's ask, so the
-- tab names it instead of offering the caller's own suggestion, which would overwrite the asker's levels. Typing
-- something else, Use suggestion or a sent call ends it.
local function boxAsk()
  local k = L.forAsk
  if k and (k.what ~= L.what or now() - k.at > ns.ASK_KEEP) then L.forAsk, k = nil, nil end
  return k
end

function L.UseSuggestion()
  L.forAsk = nil
  local s = L.Suggest() or (not officer() and L.ForMe())
  if not s then
    note(("No suggestion now: it needs %d newcomers online in one dungeon's levels.")
      :format(ns.LEAD_SUGGEST_AT_LEAST))
    return false
  end
  L.what = s.what
  if frame and frame.input then frame.input:SetText(s.what) end
  if not L.rehearse then
    ns.trace("lead", "suggest", true, s.mine and ("my level, %s"):format(s.name)
      or ("%d newcomers, %s"):format(s.n, s.name))
  end
  return true
end

local practiceToken = 0
-- Has the window had this exact line on screen, beside the button that sends it, for LEAD_SHOWN seconds? Then the
-- caller has seen what the click sends (red team, 15 Nov: every line is shown before it's sent), and it goes on the
-- first click (coordinator, 15 Nov 03:28). A line that changed under the pointer (someone came online) hasn't, and
-- takes the usual two, and so does one whose button has only just appeared beside it. L.shown = { text, at, beside }:
-- set by the window where it draws the line, cleared when it doesn't.
ns.LEAD_SHOWN = 1
function L.Shown(text)
  local s = L.shown
  if not (s and frame and frame:IsShown()) then return false end
  local t = GetTime()
  return s.beside == true and s.text == text and t - s.at >= ns.LEAD_SHOWN
end

-- line: a whole call written elsewhere (L.CallParty), else the usual one for what. seen: see L.Shown.
function L.Call(what, line, seen)
  local text = line or L.CallText(what)
  if calledRecently() then
    note(("Your call is open %d more min. Invite next takes the next answer."):format(
      math.ceil((ns.LEAD_CALL_WINDOW - (now() - L.call.at)) / 60)))
    return false
  end
  -- In Rehearse the prompt says so: "say in guild chat" read as real on Louis's run (8 Nov).
  -- Armed per line (red team, 15 Nov): a second click sends only the line the first click showed, so Call this group
  -- after Call in guild (or a changed box) shows its own line first.
  local place = L.rehearse and "practice the call (nothing goes to guild chat)"
    or seen and "say the line above in guild chat" or "say in guild chat"
  if not (seen and L.Shown(text)) and not confirm("call " .. text, place, text, seen) then return false end
  if not L.rehearse and not chat("lead.call", text, "GUILD") then
    ns.trace("lead", "call", false, "the game didn't send it")
    note("The game didn't send it.")
    return false
  end
  if not L.rehearse then
    ns.trace("lead", "call", true)
    if ns.WeekOneNight then ns.WeekOneNight("c", ns.me()) end -- groups per night (WeekOne.lua), counts only
  end
  L.call, L.answers, L.forAsk = { at = now(), text = text }, {}, nil
  L.tab, L.filter, L.page = "call", "called", 1
  if L.rehearse then
    note("Rehearse: called in guild chat. Practice answers come in the next few seconds.")
    practiceToken = practiceToken + 1
    local token, rows = practiceToken, practiceRoster()
    for i = 1, 3 do
      ns.after(2 * i, function()
        if token ~= practiceToken or not L.rehearse then return end
        L.answers[#L.answers + 1] = { name = rows[i].name, at = now() }
        note(("%s said inv."):format(rows[i].name))
      end)
    end
  else
    note("Called in guild chat. Answers show here for 15 minutes.")
  end
  return true
end

-- An answer: a short guild line with inv, invite or + in it, or just "x", "in", "im in" or "count me in", inside the
-- call's window, once per person. Not a layer swap ("inv layer pls") and not someone's own group call ("lf2m wc
-- tank+heals"). Not a bare "me": in a busy guild chat it answers someone else's question as often ("who has a bag?").
local ANSWER = { inv = true, invite = true }
local ANSWER_LINE = { x = true, ["im in"] = true, ["in"] = true, ["count me in"] = true }
-- True for a line that answers a call (the rule above), whoever made the call.
function ns.IsCallAnswer(msg)
  if type(msg) ~= "string" or ns.isSecret(msg) or #msg > 40 then return false end
  if ns.ReadAsk(msg) then return false end -- someone's own ask, group or call, not an answer
  local words = ns.AskWords(msg)
  local hit = msg:find("+", 1, true) ~= nil or ANSWER_LINE[table.concat(words, " ")] or false
  for _, w in ipairs(words) do
    if w == "layer" or w == "layers" then return false end
    hit = hit or ANSWER[w] or false
  end
  return hit and #words <= 5 or false
end
function L.Heard(msg, sender)
  if L.rehearse or not calledRecently() or type(msg) ~= "string" or ns.isSecret(msg) then return false end
  if type(sender) ~= "string" or ns.isSecret(sender) then return false end
  local name = short(sender)
  if name == short(ns.me() or "") then return false end
  if not ns.IsCallAnswer(msg) then return false end
  for _, a in ipairs(L.answers) do if a.name == name then return false end end
  L.answers[#L.answers + 1] = { name = name, at = now() }
  if ns.WeekOneNight then
    ns.WeekOneNight("a", sender)
    if #L.answers == 1 then ns.WeekOneNight("ca", nil, L.call and now() - L.call.at) end -- my call drew an answer
  end
  if L.refresh then L.refresh() end
  return true
end

function L.InviteAnswers()
  local names = {}
  for _, a in ipairs(L.answers) do names[#names + 1] = a.name end
  -- With no call open there can be no answers: say what comes first (Louis's Rehearse run, 8 Nov: Call clicked once).
  if #names == 0 then
    note(calledRecently() and "No answers yet." or "No call open: click Call twice first, then answers show here.")
    return false
  end
  return inviteNext(names, "the answers")
end

local function leading()
  if L.rehearse then return true end
  if not IsInGroup() then return true end
  return UnitIsGroupLeader("player") or false
end

function L.MakeRaid()
  return act("would turn the group into a raid.", function()
    if IsInRaid() then note("Already a raid.") return false end
    if not IsInGroup() then note("Invite someone first: a raid starts from a group.") return false end
    if not UnitIsGroupLeader("player") then note("Only the group leader can make it a raid.") return false end
    local fn = (g("C_PartyInfo") and g("C_PartyInfo").ConvertToRaid) or g("ConvertToRaid")
    return type(fn) == "function" and pcall(fn) and true or false
  end)
end

function L.ReadyCheck()
  return act("would start a ready check.", function()
    if not IsInGroup() then note("Ready checks are for groups.") return false end
    local fn = g("DoReadyCheck")
    return type(fn) == "function" and pcall(fn) and true or false
  end)
end

function L.Meet()
  return act("would share your spot as the meet point. Your group's arrows point there.", function()
    SlashCmdList.UWGUILD("meet")
    return true
  end)
end

-- Raid ---------------------------------------------------------------------------------------------------------------
local ROLE_WORD = { t = "Tank", h = "Healer", d = "DPS", tank = "Tank", healer = "Healer", dps = "DPS" }
local ROLE_KEY = { tank = "t", healer = "h", dps = "d" }

local function startsIn(secs)
  local d, h = math.floor(secs / 86400), math.floor(secs % 86400 / 3600)
  if d > 0 then return ("in %d day%s"):format(d, d == 1 and "" or "s") end
  if h > 0 then return ("in %d h %d min"):format(h, math.floor(secs % 3600 / 60)) end
  return ("in %d min"):format(math.max(1, math.floor(secs / 60)))
end
L.startsIn = startsIn

-- The next raid and everyone on it: { start, title, cap, size, unlinked, asOf, fromBot, people = { {name, role,
-- place} } }. Places: in, bench, maybe, new (whispered since the bot last wrote the file), out. Bot rows first, in its
-- order; a whisper newer than the file wins for that name (raid out takes them off).
function L.Raid()
  if L.rehearse then
    local r = practiceRaid(L.practiceAt or now())
    L.practiceAt = L.practiceAt or now()
    r.people = {}
    for _, p in ipairs(r.list) do r.people[#r.people + 1] = { name = p[1], role = p[2], place = p[3] } end
    for _, p in ipairs(r.whispered) do r.people[#r.people + 1] = { name = p[1], role = p[2], place = "new" } end
    r.fromBot = true
    return r
  end
  local held = ns.ScheduleNow and ns.ScheduleNow()
  local at, ev = now(), nil
  for _, e in ipairs(held and held.ev or {}) do
    if e[3] == "raid" and e[2] > at then ev = e break end
  end
  if not ev then return nil end
  local r = { start = ev[1], title = ev[5], going = ev[4], cap = { 0, 0, 0 }, size = 0, unlinked = 0, people = {} }
  local gen = type(ns.SCHEDULE) == "table" and ns.finite(ns.SCHEDULE.gen) or 0
  local index = {}
  for _, x in ipairs(type(ns.RAID_ROSTER) == "table" and ns.RAID_ROSTER or {}) do
    if type(x) == "table" and x.ev == ev[1] and gen > 0 then
      r.fromBot, r.asOf = true, gen
      r.cap = type(x.cap) == "table" and x.cap or r.cap
      r.size, r.unlinked = ns.finite(x.size) or 0, ns.finite(x.unlinked) or 0
      for _, p in ipairs(type(x.list) == "table" and x.list or {}) do
        if type(p) == "table" and type(p[1]) == "string" then
          r.people[#r.people + 1] = { name = p[1], role = p[2], place = p[3] }
          index[p[1]] = #r.people
        end
      end
    end
  end
  -- Whispers this client holds for this raid, the latest per name; only those newer than the bot's file change it.
  local latest = {}
  for _, e in ipairs(type(UW_GuildDB) == "table" and type(UW_GuildDB.raidSignups) == "table" and UW_GuildDB.raidSignups or {}) do
    if type(e) == "table" and e.ev == ev[1] and type(e.n) == "string" then
      local cur = latest[e.n]
      if not cur or (tonumber(e.at) or 0) >= (tonumber(cur.at) or 0) then latest[e.n] = e end
    end
  end
  local names = {}
  for n in pairs(latest) do names[#names + 1] = n end
  table.sort(names, function(a, b) return (tonumber(latest[a].at) or 0) < (tonumber(latest[b].at) or 0) end)
  for _, n in ipairs(names) do
    local e = latest[n]
    if (tonumber(e.at) or 0) > gen or not index[n] then
      local p = { name = n, role = ROLE_KEY[e.r or ""] or "d", place = e.out and "out" or "new" }
      if index[n] then
        if e.out then r.people[index[n]].place = "out" else r.people[index[n]].role = p.role end
      else
        r.people[#r.people + 1] = p
        index[n] = #r.people
      end
    end
  end
  return r
end

function L.RaidCounts(r)
  local c = { t = 0, h = 0, d = 0, bench = 0, maybe = 0, new = 0, out = 0 }
  for _, p in ipairs(r and r.people or {}) do
    if p.place == "in" then c[p.role] = (c[p.role] or 0) + 1
    elseif c[p.place] then c[p.place] = c[p.place] + 1 end
  end
  return c
end

local function inPlace(r, place)
  local out = {}
  for _, p in ipairs(r and r.people or {}) do if p.place == place then out[#out + 1] = p.name end end
  return out
end

function L.InviteRaid()
  local r = L.Raid()
  if not r then note("No raid in the schedule yet.") return false end
  local list = inPlace(r, "in")
  for _, n in ipairs(inPlace(r, "new")) do list[#list + 1] = n end
  return inviteNext(list, "the sign-ups")
end

-- The next benched name online who hasn't heard from you: the bench line, one per press.
function L.WhisperBench()
  local r = L.Raid()
  local on = onlineSet()
  for _, name in ipairs(inPlace(r, "bench")) do
    if on[name] and not L.whispered[name] and not (ns.quiet and ns.quiet(name)) then
      L.whispered[name] = true
      if L.rehearse then note(("Rehearse: would whisper %s:"):format(name)) note(ns.LEAD_BENCH) return true end
      local ok = chat("lead.bench", ns.LEAD_BENCH, "WHISPER", on[name].full)
      note(ok and ("Whispered %s the bench line."):format(name) or "The game didn't send it.")
      return ok
    end
  end
  note("Nobody on the bench to whisper: they're offline or heard from you already.")
  return false
end

function L.RaidOpenText(r)
  return ns.LEAD_RAID_OPEN:format(r.title, startsIn(r.start - now()))
end

function L.AnnounceRaid()
  local r = L.Raid()
  if not r then note("No raid in the schedule yet: post it in Discord first.") return false end
  local text = L.RaidOpenText(r)
  if not confirm("raidopen", "say in guild chat", text) then return false end
  return act("would say it in guild chat.", function()
    local ok = chat("lead.raidopen", text, "GUILD")
    note(ok and "Said in guild chat." or "The game didn't send it.")
    return ok
  end)
end

function L.AskRaiders()
  if L.rehearse then note("Rehearse: would ask in guild chat:") note(ns.RAIDERS_ASK) return true end
  return ns.RaidersAsk()
end
function L.PromoteRaiders()
  return act("would list who said raid, with the Promote button.", function() ns.RaidersList() return true end)
end

-- Leads --------------------------------------------------------------------------------------------------------------
-- My group's units other than me: { unit, name, leader, assist }.
function L.Group()
  local out = {}
  if L.rehearse then
    for i, n in ipairs(PRACTICE_GROUP) do out[i] = { unit = "party" .. i, name = n } end
    return out
  end
  local raid = IsInRaid()
  for i = 1, GetNumGroupMembers() or 0 do
    local unit = raid and ("raid" .. i) or ("party" .. i)
    local full = ns.unitFull(unit)
    if full and full ~= ns.me() then
      out[#out + 1] = { unit = unit, name = short(full), leader = UnitIsGroupLeader(unit) or nil,
        assist = UnitIsGroupAssistant(unit) or nil }
    end
  end
  return out
end

function L.MakeLeader(m)
  if not confirm("leader " .. m.name, ("make %s the group leader"):format(m.name)) then return false end
  return act(("would make %s the group leader."):format(m.name), function()
    if not leading() then note("Only the group leader can pass the lead.") return false end
    local fn = g("PromoteToLeader")
    local ok = type(fn) == "function" and pcall(fn, m.unit)
    if ok then note(("%s leads the group now."):format(m.name)) end
    return ok and true or false
  end)
end

function L.MakeAssist(m)
  return act(("would make %s a raid assist."):format(m.name), function()
    if not IsInRaid() then note("Assists are for raids: Make it a raid first.") return false end
    if not leading() then note("Only the raid leader can make assists.") return false end
    local fn = g("PromoteToAssistant")
    local ok = type(fn) == "function" and pcall(fn, m.unit)
    if ok then note(("%s is an assist now."):format(m.name)) end
    return ok and true or false
  end)
end

function L.AskHelpers()
  if L.rehearse then note("Rehearse: would ask in guild chat:") note(ns.JOBS_ASK) return true end
  SlashCmdList.UWGUILD("jobs ask")
  return true
end

-- Online recruits without a buddy, each with the online guildmate closest in level who isn't a recruit (the same
-- pairing an officer types as /uw buddy Recruit Buddy).
function L.Unpaired()
  local rows, out = roster(), {}
  local buddies = type(UW_GuildDB) == "table" and type(UW_GuildDB.buddies) == "table" and UW_GuildDB.buddies or {}
  local isNew = function(r)
    if L.rehearse then return r.name:find("^Cora") ~= nil end
    return ns.isRecruit(r.name)
  end
  for _, r in ipairs(rows) do
    if isNew(r) and not buddies[r.name] then
      local best
      for _, v in ipairs(rows) do
        if v ~= r and not isNew(v) and (not best or math.abs(v.level - r.level) < math.abs(best.level - r.level)) then
          best = v
        end
      end
      out[#out + 1] = { recruit = r, buddy = best }
    end
  end
  return out
end

function L.Pair(p)
  if not p.buddy then note(("Nobody online to pair with %s yet."):format(p.recruit.name)) return false end
  if not confirm("pair " .. p.recruit.name, ("make %s %s's buddy"):format(p.buddy.name, p.recruit.name)) then
    return false
  end
  return act(("would pair %s with %s."):format(p.recruit.name, p.buddy.name), function()
    SlashCmdList.UWGUILD(("buddy %s %s"):format(p.recruit.name, p.buddy.name))
    return true
  end)
end

-- Say ----------------------------------------------------------------------------------------------------------------
local function groupChannel()
  if L.rehearse then return "PARTY" end
  if IsInRaid() then return "RAID" end
  if IsInGroup() then return "PARTY" end
end

function L.Say(entry)
  local where = entry[3]
  local channel, target = where, nil
  if where == "GROUP" then
    channel = groupChannel()
    if not channel then note("You're not in a group.") return false end
  elseif where == "WHISPER" then
    target = L.target
    if not target then note("Pick a name first: click one on Who's on, Call or Raid.") return false end
  end
  local place = target and ("whisper to " .. short(target)) or (channel == "GUILD" and "guild chat" or "group chat")
  local text = ns.LeadLineText(entry[4])
  if not confirm("say " .. entry[1], "send it to " .. place, text) then return false end
  return act(("would send it to %s."):format(place), function()
    local ok = chat("lead.line", text, channel, target)
    ns.trace("lead", "say " .. entry[1], ok, not ok and "the game didn't send it" or nil)
    note(ok and ("Sent to %s."):format(place) or "The game didn't send it.")
    return ok
  end)
end
-- The Guild Master's trade ad (Charter.lua ns.TradeAd): the same two clicks as every line here, the second one posts.
function L.SayTrade()
  -- Too soon, or no Trade channel here: say why on the first click rather than after the second.
  if not L.rehearse and (ns.TradeWait() > 0 or not ns.TradeChannel()
    or (ns.LineWaiting and ns.LineWaiting("recruit.trade"))) then
    local _, msg = ns.TradeAd()
    if msg then note(msg) end
    return false
  end
  -- The whole line shows under the list on the first click (the row has room for two lines of it).
  if not confirm("say trade", "send it to Trade chat", ns.TRADE_LINE) then return false end
  return act("would post the trade ad in Trade chat.", function()
    local ok, msg = ns.TradeAd()
    note(ok and "Sent to Trade chat." or msg)
    return ok
  end)
end

-- Rehearse -----------------------------------------------------------------------------------------------------------
function L.SetRehearse(on)
  L.rehearse = on and true or false
  ns.trace("lead", L.rehearse and "rehearse on" or "rehearse off", true) -- the decision log shows a practice run
  L.answers, L.invited, L.whispered, L.call, L.target, L.practiceAt, armed = {}, {}, {}, nil, nil, nil, nil
  practiceToken = practiceToken + 1
  L.page, L.dList = 1, nil
  L.shown = nil -- a practice line seen is not the real line seen: the first real click shows it again (integrator, 15 Nov)
  note(L.rehearse and "Rehearse is on: practice guildmates and a practice raid. Nothing is sent or invited."
    or "Rehearse is off. Buttons act for real again.")
end

-- What each tab shows: { head = lines, rows = { { text, b1 = {label, fn}, b2 = {label, fn} } }, actions = { {label,
-- fn, tip} } }. The window only draws it, so every tab is testable without the UI. A row is one line, cut with "..."
-- where it runs past its buttons; tall = true marks a sentence (a Say line), which gets two. above = { text, act =
-- {label, fn} } is a sentence over the table with its button beside it (the plan): a table holds only people. Actions
-- sit in one row at the window's foot where they fit, else three to a row, or across to a row where the view says so.
-- primary = true marks the tab's one red button (at most one a tab; the rest are quiet); empty is the one grey line
-- the list shows while it has no rows.
-- People are a table (design director's spec, section 4, 14 Nov 2026): a person's row also carries who (the roster
-- row: name, cls, level, zone), and what the window can't read out of a sentence: last (the last column's text,
-- the zone when there's none), mate (a guildmate in the last column: the closest buddy), tag (the short word at the
-- row's right end), grey (busy or away). cols on the view names the columns; a row that is only { cols } starts a
-- second table under the first, and { group, n } is a label over the rows after it. place on an action puts it
-- beside what it acts on ("head": beside what the tab says; "box": beside the box) instead of at the foot, and
-- foot is a grey line beside the foot's buttons.
local COLS, NEW_COLS, RAID_COLS = { "Name", "Lvl", "Zone" }, { "Newcomer", "Lvl", "Closest buddy" }, { "Name", "", "Role" }
local CLASS_FALLBACK = "ffffff"
local function classed(r)
  local c = r.cls and type(g("RAID_CLASS_COLORS")) == "table" and g("RAID_CLASS_COLORS")[r.cls]
  local hex = c and type(c.colorStr) == "string" and c.colorStr:sub(3) or CLASS_FALLBACK
  return "|cff" .. hex .. r.name .. "|r"
end
local function pick(name)
  return function()
    L.target = name
    note(("%s picked: Say > Offer a spot whispers them."):format(short(name)))
  end
end
local function whisperTo(full)
  return function()
    L.target = full
    -- A clickable name in chat, not ChatFrame_SendTell: the game opens the whisper from the click itself, so no
    -- UW_Guild code writes the chat edit box (that taints every later send; Louis's party-chat error, 10 Nov).
    act(("would open a whisper to %s."):format(short(full)), function() return L.WhisperHint(full) end)
  end
end
-- The line itself, for the guide's lists too (Handbook.lua): the same words wherever Whisper is clicked.
function L.WhisperHint(full)
  say(("Click |Hplayer:%s|h[%s]|h to whisper them."):format(full, short(full)))
  return true
end

local views = {}
function views.online()
  local list = L.Online()
  local label = { near = "near your level", sixty = "at 60", called = "who answered your call", all = "online" }
  -- Nobody to list: the grey line says what would show, or where to look instead, and the head doesn't ask for a
  -- click on a name that isn't there (design pass, 13 Nov 2026, finding 10).
  local none = { near = "Try Everyone below.", sixty = "Try Everyone below.",
    called = "Guildmates who answer your call show here.", all = "Guildmates show here when they come online." }
  local v = { head = { ("|cffffd100%d %s %s.|r%s"):format(#list, #list == 1 and "guildmate" or "guildmates", label[L.filter],
      #list > 0 and " Click a name to pick it for Say." or "") },
    rows = {}, actions = {}, across = 4, -- the four filters share one row: one choice of four, the one that's on lit
    empty = none[L.filter], cols = COLS }
  for _, r in ipairs(list) do
    -- text: the whole row as one line, for the pointer when a column is cut. tag: the words at the row's right end
    -- (a busy guildmate's row is grey, so their word is too).
    local tags, words = {}, {}
    if r.answered then tags[#tags + 1] = "|cff40ff40said inv|r" words[#words + 1] = tags[#tags] end
    if r.signed then tags[#tags + 1] = ("raid: %s"):format(ROLE_WORD[r.signed.role] or "DPS") words[#words + 1] = tags[#tags] end
    if r.busy then tags[#tags + 1] = "|cffff8000" .. r.busy .. "|r" words[#words + 1] = r.busy end
    if r.rankName ~= "" then tags[#tags + 1] = "|cff808080" .. r.rankName .. "|r" words[#words + 1] = r.rankName end
    v.rows[#v.rows + 1] = { text = ("%s  %d  %s  %s"):format(classed(r), r.level, r.zone, table.concat(tags, " ")),
      who = r, tag = table.concat(words, "  "), grey = r.busy ~= nil,
      pick = pick(r.full), b1 = { "Whisper", whisperTo(r.full) }, b2 = { "Invite", function() invite(r.name, r.full) end } }
  end
  for _, f in ipairs({ { "near", "Near my level" }, { "sixty", "Level 60" }, { "called", "Answered call" }, { "all", "Everyone" } }) do
    v.actions[#v.actions + 1] = { f[2], function() L.filter, L.page = f[1], 1 end, "Show online guildmates: " .. f[2] .. ".",
      on = L.filter == f[1] }
  end
  return v
end

-- Dungeons (Suggest a party, 14-15 Nov 2026): choose a dungeon, see a good group for it, call it with one click. The
-- best dungeon is chosen already (L.DungeonList), so the common case is one click on the red button. The head is one
-- sentence; under it the call exactly as guild chat will show it, the button that says it beside it; the table is
-- the group (roles from class, since nobody's spec can be read); the foot is the other dungeons, the chosen one lit.
-- The call names the dungeon and a missing role, never people, so a member with no addon answers "inv"; the names
-- stay on this screen, and nobody is whispered or invited without a click. The window calls L.PartySeen() when it
-- shows this tab (building the view alone never ends the mark).
local ROLE_FIRST = { tank = 1, healer = 2, damage = 3 }
function views.dungeons()
  local v = { head = {}, rows = {}, actions = {}, cols = COLS, across = 3,
    empty = "Dungeons show here when two guildmates near their levels are online." }
  local function chosen(list)
    for _, x in ipairs(list) do if x.name == L.dPick then return x end end
    return list[1]
  end
  -- While a call made here is open, the group it was called for stays (the people just suggested drop back in the
  -- next pick, and a table that changed under an open call would read as a different plan). Another dungeon chosen
  -- meanwhile shows its own group, with the open call's line still over it and no button.
  local function calledParty()
    local c = calledRecently() and L.call.party or nil
    return c and L.dPick == c.name and c or nil
  end
  local list = choices()
  local d = chosen(list)
  local called = calledParty()
  local p = called or (d and L.Party(d))
  if d and not p then -- the chosen dungeon's group has gone: the list is made again, the best one chosen
    list = choices(true)
    d = chosen(list)
    called = calledParty()
    p = called or (d and L.Party(d))
  end
  if not p then
    v.head[1] = "|cffffd100No group to suggest right now.|r"
    return v
  end
  local lit = called and called.name or (d and d.name)
  -- Room for the longest usual head (a partial group: two lines) and call (three), whichever dungeon is chosen.
  v.headLines, v.sayLines = 2, 3
  if calledRecently() then
    v.head[1] = ("|cffffd100Call open %d more min.|r %d answered."):format(
      math.ceil((ns.LEAD_CALL_WINDOW - (now() - L.call.at)) / 60), #L.answers)
    v.preview, v.said = L.call.text, true
  else
    v.head[1] = ns.PartyHead(p, true)
    v.preview = ns.PartyCallText(p)
    v.actions[1] = { "Call this group", function() L.CallParty(p, true) end, "Says the line beside it in guild chat.",
      primary = true, place = "say" }
  end
  local answered, order, on = {}, {}, called and onlineSet() or nil
  for _, a in ipairs(L.answers) do answered[a.name] = true end
  for i, m in ipairs(p.set) do if not m.me then order[#order + 1] = { m = m, i = i, role = p.roles[m.name] or "damage" } end end
  table.sort(order, function(a, b)               -- the tank, the healer, then the rest as they were picked
    if ROLE_FIRST[a.role] ~= ROLE_FIRST[b.role] then return ROLE_FIRST[a.role] < ROLE_FIRST[b.role] end
    return a.i < b.i
  end)
  for _, o in ipairs(order) do
    local m, tags, words = o.m, {}, {}
    local gone = on ~= nil and not on[m.name] -- called a while ago: they've logged off since
    if on and on[m.name] then m = on[m.name] end
    if answered[m.name] then tags[#tags + 1] = "|cff40ff40said inv|r" words[#words + 1] = tags[#tags] end
    if o.role ~= "damage" then tags[#tags + 1] = o.role words[#words + 1] = o.role end
    if gone then tags[#tags + 1] = "|cff808080offline|r" words[#words + 1] = "offline" end
    v.rows[#v.rows + 1] = { text = ("%s  %d  %s  %s"):format(classed(m), m.level, m.zone or "?", table.concat(tags, " ")),
      who = m, tag = table.concat(words, "  "), grey = gone, pick = pick(m.full),
      b1 = { "Whisper", whisperTo(m.full) },
      b2 = not gone and { L.invited[m.name] and "Invited" or "Invite", function() invite(m.name, m.full) end } or nil }
  end
  -- The choices: all of them where they fit the foot, else one fewer and "More dungeons", which turns to the next.
  local C = ns.PARTY.choices
  local per = #list > C and C - 1 or C
  local pages = math.max(1, math.ceil(#list / per))
  L.dPage = math.min(L.dPage or 1, pages)
  for i = (L.dPage - 1) * per + 1, math.min(#list, L.dPage * per) do
    local x = list[i]
    local label = ns.DungeonShort(x.name)
    -- Under the pointer: the dungeon's whole name, then its levels (the guide's dungeon buttons say the same, E18).
    v.actions[#v.actions + 1] = { label, function() L.PickDungeon(x.name) end,
      ("Best at levels %d-%d."):format(x.lo, x.hi), title = x.name, on = x.name == lit }
  end
  if pages > 1 then
    v.actions[#v.actions + 1] = { "More dungeons", function() L.dPage, L.notes, armed = L.dPage % pages + 1, {}, nil end }
  end
  return v
end

function views.call()
  local v = { head = {}, rows = {}, actions = {}, empty = "Guildmates who answer your call show here.", cols = COLS }
  if calledRecently() then
    v.head[1] = ("|cffffd100Call open %d more min.|r %d answered."):format(
      math.ceil((ns.LEAD_CALL_WINDOW - (now() - L.call.at)) / 60), #L.answers)
  elseif boxAsk() then
    v.head[1] = ("|cffffd100%s asked: %s.|r Call in guild; answers show here."):format(L.forAsk.name, L.forAsk.what)
  else
    local s = L.Suggest()
    local me = not s and not officer() and L.ForMe()
    v.head[1] = s and ("|cffffd100Suggested: %s.|r %d newcomers online at those levels.")
      :format(s.what, s.n)
      or me and ("|cffffd100For your level: %s.|r Use suggestion, then Call in guild; answers show here."):format(me.what)
      or "|cffffd100Type what it's for, then Call in guild.|r Answers show here for 15 minutes."
  end
  v.preview = L.CallText(L.what) -- the line Call in guild says, shown under the box it's typed in
  -- A call from Dungeons that asked for a role: the line that went out, while its dungeon is still in the box.
  local party = calledRecently() and L.call.party
  if party and L.what == party.what then v.preview = L.call.text end
  v.input = true
  if #L.answers == 0 and not calledRecently() then
    local p = L.Plan()
    if p then
      -- Over the table, not in it: a table holds only people (design director, 14 Nov 2026).
      v.above = { text = ("|cffffd100Plan:|r %s around %02d:00 your clock: %d newcomers who haven't grouped "
        .. "have been on then."):format(p.what, p.hour, p.n),
        act = { "Use", function()
          L.what = p.what
          if frame and frame.input then frame.input:SetText(p.what) end
          ns.trace("lead", "plan", true, ("%d newcomers, %s"):format(p.n, p.name))
        end } }
    end
    local s = L.Suggest()
    local ask
    for _, e in ipairs(ns.LEAD_LINES) do if e[1] == "vet" then ask = e end end
    -- One label over the helpers, with how many (it was "could help" on every row).
    local helpers = L.Helpers(s)
    if #helpers > 0 then v.rows[#v.rows + 1] = { group = "Near their level", n = #helpers } end
    for _, r in ipairs(helpers) do
      v.rows[#v.rows + 1] = { text = ("%s  %d  %s"):format(classed(r), r.level, r.zone), who = r,
        pick = pick(r.full), b1 = { "Whisper", whisperTo(r.full) },
        b2 = { "Ask", function() L.target = r.full; L.Say(ask) end } }
    end
  end
  local on = onlineSet()
  for _, a in ipairs(L.answers) do
    local r = on[a.name]
    v.rows[#v.rows + 1] = { text = r and ("%s  %d  %s"):format(classed(r), r.level, r.zone) or (a.name .. "  |cff808080offline|r"),
      who = r or { name = a.name }, last = not r and "" or nil, tag = not r and "offline" or nil, grey = not r,
      pick = pick(r and r.full or a.name),
      b1 = { "Whisper", whisperTo(r and r.full or a.name) },
      b2 = r and { L.invited[a.name] and "Invited" or "Invite", function() invite(a.name, r.full) end } or nil }
  end
  v.actions = {
    { "Use suggestion", L.UseSuggestion, "Puts the dungeon with the most newcomers waiting for a first one in the box. "
      .. "Then Call in guild: one line reaches them all, nobody is whispered.", place = "head" },
    { "Call in guild", function() L.Call(L.what) end, "One line in guild chat. Click twice: the first shows it.",
      primary = true, place = "box" },
    { "Invite next", L.InviteAnswers, "Invites the next answer who's online and not grouped. One per click." },
    { "Make it a raid", L.MakeRaid, "Turns your group into a raid, for more than 5." },
    { "Ready check", L.ReadyCheck, "Asks everyone in the group if they're ready." },
    { "Share meet point", L.Meet, "Your spot becomes the group's meet point: their arrows point at you (/uw meet)." },
  }
  if boxAsk() then table.remove(v.actions, 1) end -- the asker's levels stay in the box
  return v
end

function views.raid()
  local r = L.Raid()
  local v = { head = {}, rows = {}, actions = {},
    empty = r and "Nobody has signed up yet." or "Sign-ups show here once a raid is posted.", cols = RAID_COLS }
  if not r then
    v.head[1] = "|cffffd100No raid in the schedule yet.|r Post one in Discord; it shows here after the next /reload."
  else
    local c = L.RaidCounts(r)
    v.head[1] = ("|cffffd100%s|r starts %s. Tanks %d/%d, Healers %d/%d, DPS %d/%d. Bench %d."):format(r.title,
      startsIn(r.start - now()), c.t, r.cap[1] or 0, c.h, r.cap[2] or 0, c.d, r.cap[3] or 0, c.bench)
    if r.fromBot then
      v.head[2] = ("|cff808080As of %s.%s Whispers since then are marked new.|r"):format((date or os.date)("%H:%M", r.asOf or now()),
        (r.unlinked or 0) > 0 and (" %d more on Discord with no character linked."):format(r.unlinked) or "")
    else
      v.head[2] = "|cff808080Whisper sign-ups to you only. Discord sign-ups show on the Guild Master's PC.|r"
    end
    local on, label = onlineSet(), { ["in"] = "", bench = "|cffffd100bench|r", maybe = "|cff808080maybe|r",
      new = "|cff40ff40new|r", out = "|cff808080out|r" }
    for _, p in ipairs(r.people) do
      local o = on[p.name]
      local place = label[p.place] or ""
      v.rows[#v.rows + 1] = { text = ("%s  %s  %s  %s"):format(o and classed(o) or p.name, ROLE_WORD[p.role] or "DPS",
        place, o and "" or "|cff808080offline|r"), pick = pick(o and o.full or p.name),
        who = { name = p.name, cls = o and o.cls or nil }, last = ROLE_WORD[p.role] or "DPS", grey = not o,
        tag = (place ~= "" and place or "") .. (o and "" or (place ~= "" and "  " or "") .. "offline"),
        b1 = { "Whisper", whisperTo(o and o.full or p.name) },
        b2 = o and { L.invited[p.name] and "Invited" or "Invite", function() invite(p.name, o.full) end } or nil }
    end
  end
  v.actions = {
    { "Open sign-ups", L.AnnounceRaid, "Tells guild chat how to sign up by whisper. Click twice: the first shows it.",
      officer = true },
    { "Invite signed-up", L.InviteRaid, "Invites the next signed-up guildmate who's online and not grouped.",
      primary = true },
    { "Whisper the bench", L.WhisperBench, "Thanks the next benched guildmate online, once each." },
    { "Who wants to raid?", L.AskRaiders, "Asks guild chat who wants to be a Raider (/uw raiders).", officer = true },
    { "Promote raiders", L.PromoteRaiders, "Who said raid, and the Promote button (/uw raiders list).", officer = true },
  }
  return v
end

function views.leads()
  local v = { head = {}, rows = {}, actions = {}, empty = "Your group shows here once you're in one." }
  local grp = L.Group()
  v.head[1] = #grp > 0 and "|cffffd100Your group.|r Anyone who wants to lead, leads: pass it on."
    or "|cffffd100Not in a group.|r Call a group first, or invite from Who's on."
  -- My group: a guildmate has a class, a level and a zone in the roster; anyone else is a name.
  local on = onlineSet()
  for _, m in ipairs(grp) do
    local o = on[m.name]
    v.rows[#v.rows + 1] = { text = m.name .. (m.leader and "  |cffffd100leader|r" or m.assist and "  |cff808080assist|r" or ""),
      who = o or { name = m.name }, last = not o and "" or nil,
      tag = m.leader and "|cffffd100leader|r" or m.assist and "assist" or nil,
      pick = pick(m.name), b1 = { "Make leader", function() L.MakeLeader(m) end },
      b2 = { "Make assist", function() L.MakeAssist(m) end } }
  end
  local unpaired = L.Unpaired()
  if #unpaired > 0 then
    v.head[2] = ("|cffffd100%d newcomer%s online without a buddy.|r Pair suggests the closest level."):format(#unpaired,
      #unpaired == 1 and "" or "s")
  end
  -- The newcomers are a table of their own: its header is the tab's when there's no group, a row under the group.
  v.cols = #grp > 0 and COLS or NEW_COLS
  if #grp > 0 and #unpaired > 0 then v.rows[#v.rows + 1] = { cols = NEW_COLS, officer = true } end
  for _, p in ipairs(unpaired) do
    v.rows[#v.rows + 1] = { text = ("%s  %d  |cff808080buddy: %s|r"):format(classed(p.recruit), p.recruit.level,
      p.buddy and p.buddy.name or "nobody online"), pick = pick(p.recruit.full),
      who = p.recruit, mate = p.buddy, last = p.buddy and p.buddy.name or "|cff808080nobody online|r",
      b1 = { "Whisper", whisperTo(p.recruit.full) }, b2 = { "Pair", function() L.Pair(p) end }, officer = true }
  end
  local jobs = ns.JobHolders and ns.JobHolders() or {}
  local parts = {}
  for _, j in ipairs(ns.JOBS or {}) do parts[#parts + 1] = ("%s %d"):format(j.label, #(jobs[j.key] or {})) end
  -- Beside Ask for helpers at the foot, which is what it's about (it was a third line over the list).
  v.foot = "Guild jobs: " .. table.concat(parts, ", ") .. ". Leaders get rated privately after a boss kill."
  v.actions = { { "Ask for helpers", L.AskHelpers, "Asks guild chat for buddies, recruiters and hosts (/uw jobs ask).",
    officer = true, primary = true } }
  return v
end

function views.say()
  local v = { head = { "|cffffd100Lines written ahead.|r The first click shows one; a second sends it." }, rows = {},
    actions = {} }
  v.head[2] = L.target and ("|cff808080Whispers go to %s.|r"):format(short(L.target))
    or "|cff808080Pick a name in any list to whisper them.|r"
  local where = { GUILD = "guild", GROUP = "group", WHISPER = "whisper" }
  if ns.TradeAd and ns.TRADE_LINE and UW_GuildDB and UW_GuildDB.gmAccount == true then
    v.rows[#v.rows + 1] = { text = ("|cffffd100Trade ad|r |cff808080(trade, in a city)|r Your own trade line, "
      .. "once every %d minutes at most."):format(ns.TRADE_GAP / 60), tall = true, b2 = { "Send", L.SayTrade } }
  end
  for _, e in ipairs(ns.LEAD_LINES) do
    v.rows[#v.rows + 1] = { text = ("|cffffd100%s|r |cff808080(%s)|r %s"):format(e[2], where[e[3]], ns.LeadLineText(e[4])),
      tall = true, b2 = { "Send", function() L.Say(e) end } }
  end
  return v
end
L.views = views
-- Notes: guild notes waiting to be set by hand (Crafts.lua ns.NotesView; no addon can set one on Forever).
function views.notes() return ns.NotesView and ns.NotesView() or { head = {}, rows = {}, actions = {} } end
L.TABS = { { "dungeons", "Dungeons" }, { "online", "Who's on" }, { "call", "Call a group" }, { "raid", "Raid" }, { "leads", "Leads" },
  { "say", "Say" }, { "notes", "Notes", officer = true } }
-- A tab as this character sees it: officer-only rows and actions left out for everyone else, so a Raider never meets
-- a button that only answers "officers only" (the Notes tab, buddy pairing, job asks, raid sign-ups, promoting).
function L.View(tab)
  tab = tab or L.tab
  local isOff = officer()
  for _, t in ipairs(L.TABS) do
    if t[1] == tab and not L.TabOpen(t) then tab = ns.MayLead() and "online" or "call" end
  end
  local v = views[tab]()
  v.tab = tab
  if not isOff then
    local keep = function(list)
      local out = {}
      for _, x in ipairs(list) do if not x.officer then out[#out + 1] = x end end
      return out
    end
    v.rows, v.actions = keep(v.rows), keep(v.actions)
  end
  return v
end

-- The window ---------------------------------------------------------------------------------------------------------
-- Laid out on ns.UI (Skin.lua), the same size and parts as the UW Guild window:
--   heading (the tab, and the Rehearsal line while it's on) with the pager | what the tab says, with the button that
--   uses it beside it | the box with the tab's red button beside it | the call as guild chat will show it | the list
--   | the last answers | the actions at the window's foot.
--   * The list and everything above it hang from the top; the actions are pinned to the bottom and never move, so
--     a redraw (every 5 s) or a new answer can't slide a button under the pointer. The list takes the room between.
--   * Answers show right over the actions, where the click that caused them was: "Click again within 6 s" is read
--     next to the button to click again.
--   * People are a table (design director's spec, section 4, 14 Nov 2026; Skin.lua UI.Person): a header names the
--     columns, and a person's buttons show on the row under the pointer only. Leads had 24 buttons for 12 newcomers,
--     Call a group 12 for six helpers, and "could help" on every row is one label over them, with how many.
--   * Every button but the tab's one red one is quiet (design pass, 13 Nov: Leads showed 25 red buttons, Call a
--     group 19). The red one sits beside what it acts on: Call in guild beside the box it reads. A list with no
--     rows says so in one grey line.
--   * A page holds the rows that fit the list (13 Nov: ten a page left a third of Who's on empty, with 22 names on
--     three pages). The answers' place is counted as taken even while it's empty, so the first answer never sends a
--     row to the next page under the pointer. A label or a header is never the last thing on a page.
--   * A name's row is one line; a sentence's row is taller and takes two, with air between it and the next, so two
--     wrapped lines never read as one block of four.
local UI = ns.UI
local P = UI.PERSON
ns.LEAD_ROW_H, ns.LEAD_ROW_TALL, ns.LEAD_HEAD_H, ns.LEAD_GROUP_H = P.h, P.tall, P.head, P.group
ns.LEAD_STEP = 12 + UI.SPACING                       -- a line of the window's text, to the next
ns.LEAD_NOTE_H = 4 * 12 + 3 * UI.SPACING             -- answers: four lines
ns.LEAD_LIST_W = UI.CW - 2                           -- a row, inside the list's hairlines
local STEP, LIST_W = ns.LEAD_STEP, ns.LEAD_LIST_W
local ACT_GAP, FOOT_GAP = UI.GAP, 6                  -- between actions that share the width; between fitted ones
local ACT_STEP = UI.BTN + ACT_GAP
local function actWidth(across) return (UI.CW - (across - 1) * ACT_GAP) / across end -- that many across the content
local BOX_H, LIST_PAD = 20, 4 -- the edit box; the list's margin over its first row and under its last
local ANSWER_IN = 12          -- the answers start this far in, behind their bar (as in the guide)
local SAY = { top = 6, side = 9, bar = 2 } -- the call's line: its padding, and the bar in guild chat's colour
local BESIDE = 10             -- from a text to the button beside it
-- A list with no rows (design spec 6, board 8): the tab's own picture, grey, over the one grey line that says what
-- shows here, so the box reads as "nothing yet", not "broken". icon: the pick tile's picture size; gap: from it to
-- the line; lift: the picture's foot over the list's middle, so the pair stands a little above it; dim: how grey.
-- top: where the line stands alone, as it always did: in a list with no room for the pair (under `room` high), and
-- on a client with no picture for the tab.
ns.LEAD_EMPTY = { icon = 40, gap = UI.GAP, lift = 12, dim = 0.6, top = 24 }
ns.LEAD_EMPTY.room = 2 * (ns.LEAD_EMPTY.lift + ns.LEAD_EMPTY.icon + UI.GAP)
local EMPTY = ns.LEAD_EMPTY
-- The mark on a rail tab (design spec 1): something new is behind it. A solid dot at the tab's right end, `edge`
-- from it, on the label's line; no number, no pulse, no red. 7 across, as the guide's online dot is: at 6 the steps
-- leave flat sides of 2 and it reads as a diamond at some scales (design director, 15 Nov 2026).
ns.LEAD_MARK = { dot = 7, edge = 8 }

-- A tab's icon is the guide's for the same thing (Handbook.lua ns.HANDBOOK_ICONS), so one thing has one picture.
local TAB_ICON = { dungeons = { "entry", "prep" }, online = { "entry", "near" }, call = { "entry", "call" }, raid = { "page", "raids" },
  leads = { "entry", "lead" }, say = { "tab", "say" }, notes = { "entry", "notes" } }
local function tabIcon(key)
  local at, all = TAB_ICON[key], ns.HANDBOOK_ICONS
  return at and type(all) == "table" and type(all[at[1]]) == "table" and all[at[1]][at[2]] or nil
end

local function rowHeight(r)
  return r.cols and ns.LEAD_HEAD_H or r.group and ns.LEAD_GROUP_H or r.tall and ns.LEAD_ROW_TALL or ns.LEAD_ROW_H
end
local function names(r) return r.cols ~= nil or r.group ~= nil end -- a header or a label: it names the rows after it
-- The row each page starts on: a page takes rows while they fit in room (px), always one, never more than there are
-- row frames. A header or a label goes over to the next page with the first row it names. Pure, so the paging is
-- tested without the window.
function L.Pages(rows, room)
  local starts, used, n = { 1 }, 0, 0
  local glued = false -- the row before this one names it: the two stay on one page
  for i, r in ipairs(rows) do
    local h, with, more = rowHeight(r), 0, 0
    if names(r) then
      local j = i + 1
      while rows[j] do
        with, more = with + rowHeight(rows[j]), more + 1
        if not names(rows[j]) then break end
        j = j + 1
      end
    end
    if n > 0 and not glued and (used + h + with > room or n + more >= ns.LEAD_ROWS) then
      starts[#starts + 1], used, n = i, 0, 0
    end
    used, n = used + h, n + 1
    glued = names(r)
  end
  return starts
end

local boxInset = UI.BoxInset -- the box sits flush with the text above it, in either look

-- The call as guild chat will show it: the game's own "[Guild] [Name]: " before the line.
local function chatLine(text)
  local fmt = g("CHAT_GUILD_GET")
  fmt = type(fmt) == "string" and fmt:gsub("|H.-|h", ""):gsub("|h", "") or "[Guild] %s: "
  local ok, lead = pcall(string.format, fmt, "[" .. short(ns.me() or "") .. "]")
  return (ok and lead or ("[Guild] [%s]: "):format(short(ns.me() or ""))) .. text
end

-- What a sentence's row has for its text, before the buttons it will show (as wide as their words: UI.ActSet).
local function textRoom(ruler, r)
  local taken, n = P.right, 0
  for _, b in ipairs({ r.b1 or false, r.b2 or false }) do
    if b then taken, n = taken + math.max(40, math.min(120, UI.TextWidth(ruler, b[1], 6) + 18)) + P.act, n + 1 end
  end
  return LIST_W - P.pad - (n > 0 and taken - P.act + P.before or taken)
end

-- One row of the list, for what it holds: a person, a sentence, a label over a group, or a second table's header.
local function fillRow(row, r, nameW)
  row.full, row.pick = r.text, r.pick
  -- Lit under the pointer where there's a name to act on; in the title's colour while it's the name whispers go to.
  row.lights = r.who ~= nil or r.pick ~= nil
  row.sel = r.who ~= nil and L.target ~= nil and (r.who.full == L.target or r.who.name == L.target) or false
  UI.ActSet(row.acts[1], r.b1 and r.b1[1], r.b1 and r.b1[2])
  UI.ActSet(row.acts[2], r.b2 and r.b2[1], r.b2 and r.b2[2])
  row.always = not r.who -- a sentence keeps its button; a person's show under the pointer
  row.label:SetShown(r.group ~= nil)
  row.count:SetShown(r.group ~= nil)
  if r.group then
    row.label:SetText(r.group)
    row.count:SetText(r.n and tostring(r.n) or "")
  end
  if r.who then
    row.text:Hide()
    UI.PersonSet(row, { name = r.who.name, cls = r.who.cls, level = r.who.level, last = r.last or r.who.zone,
      mate = r.mate, tag = r.tag, grey = r.grey }, nameW, LIST_W)
    return
  end
  UI.PersonOff(row)
  UI.PersonLay(row)
  local sentence = r.text ~= nil and not names(r)
  row.text:SetShown(sentence)
  if sentence then
    -- Inside its own slot: one line, or a sentence on two, either cut with "..." past that (Louis, 8 Nov: "Offer a
    -- spot" ran into "Why dungeons"). Hover shows a cut line whole; a Say line's first click too.
    row.text:SetHeight(rowHeight(r))
    if row.text.SetWordWrap then row.text:SetWordWrap(r.tall and true or false) end
    if row.text.SetMaxLines then row.text:SetMaxLines(r.tall and 2 or 1) end
    row.text:SetWidth(LIST_W - P.pad - row.taken) -- up to its buttons, or the row's right margin
    row.text:SetText(r.text)
  end
end

local function draw()
  if not frame or not frame:IsShown() then return end
  local v = L.View()
  local name = ""
  for _, t in ipairs(frame.tabs) do
    t.shown = L.TabOpen({ t.key, officer = t.officer })
    if t.key == v.tab then name = t.name end
  end
  UI.NavSet(frame, frame.tabs, function(t) return t.key == v.tab end)
  frame.heading:SetText(name)
  frame.banner:SetShown(L.rehearse)

  -- Where each action goes: beside what the tab says, beside the box, or at the foot.
  local box = v.input and frame.input or v.copy and frame.copy or nil
  -- "say": beside the call's line where the tab has no box (Dungeons): the line is what the button says.
  local headAct, boxAct, sayAct, foot = nil, nil, nil, {}
  for i, a in ipairs(v.actions) do
    if a.place == "head" and not headAct then headAct = i
    elseif a.place == "box" and box and not boxAct then boxAct = i
    elseif a.place == "say" and not box and v.preview and not sayAct then sayAct = i
    elseif #foot < #frame.slots then foot[#foot + 1] = i end
  end
  for i in pairs(frame.actions) do frame.actions[i] = nil end -- a view may have one more action than the foot has places
  local function wire(b, i)
    local a = v.actions[i]
    b:SetText(a[1])
    b.fn, b.tip, b.tipTitle = a[2], a[3], a.title -- title: the tooltip's first line where it isn't the button's own
    frame.actions[i] = b
    b:Show()
    return a
  end

  -- What the tab says, with the button that uses it beside it, centred on its lines.
  local hb = frame.headBtn
  hb:SetShown(headAct ~= nil)
  local headW = UI.CW
  if headAct then headW = UI.CW - UI.FitButton(hb, wire(hb, headAct)[1], 18, 44, 160) - BESIDE end
  frame.head:SetWidth(headW)
  frame.head:SetText(table.concat(v.head, "\n"))
  local textH = UI.TextHeight(frame.head, UI.Lines(v.head, 1, headW / 7) * STEP - UI.SPACING)
  local headH = headAct and math.max(textH, UI.SMALL) or textH
  frame.headBox:ClearAllPoints()
  frame.headBox:SetPoint("TOPLEFT", frame, "TOPLEFT", UI.X, -UI.BODY - (headH - textH) / 2)
  if headAct then
    hb:ClearAllPoints()
    hb:SetPoint("RIGHT", frame, "TOPRIGHT", -UI.PAD, -UI.BODY - headH / 2)
  end
  -- top: how far down the window the next part starts, counted as the parts are hung (a text the client can't
  -- measure yet is counted by its lines).
  -- v.headLines: the head keeps room for that many lines, so what's under it stays at one height whatever it says
  -- (Dungeons: the red button doesn't move as dungeons are clicked through; design lane, 15 Nov 2026).
  local top = UI.BODY + math.max(headH, (v.headLines or 0) * STEP - UI.SPACING)

  -- The box, with the tab's red button beside it: the button acts on what the box holds.
  frame.input:SetShown(v.input and true or false)
  frame.copy:SetShown(v.copy and true or false)
  local red = frame.boxRed
  red:SetShown(boxAct ~= nil or sayAct ~= nil)
  if box then
    top = top + UI.GAP
    local wide = v.input and UI.CW - boxInset() or 320 - boxInset()
    if boxAct then
      wide = wide - UI.FitButton(red, wire(red, boxAct)[1], 28, 90, 160) - UI.GAP
      red:ClearAllPoints()
      red:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -UI.PAD, -top)
    end
    box:SetWidth(wide)
    box:ClearAllPoints()
    box:SetPoint("TOPLEFT", frame, "TOPLEFT", UI.X + boxInset(), -top - (UI.BTN - BOX_H) / 2)
    top = top + UI.BTN
  end
  -- The line the call will say, as guild chat will show it: it reads as chat, not as one more instruction.
  -- v.said: the line already went out (Dungeons while its call is open), so it shows with no button beside it.
  local shows = v.preview ~= nil and (box ~= nil or sayAct ~= nil or v.said == true)
  frame.say:SetShown(shows)
  if shows then
    -- The strip's width on every draw, both ways: the content's, or up to the red button beside it (Dungeons).
    local wide = UI.CW
    if sayAct then wide = wide - UI.FitButton(red, wire(red, sayAct)[1], 28, 90, 160) - UI.GAP end
    frame.say:SetWidth(wide)
    frame.preview.wide = wide - SAY.bar - 2 * SAY.side
    frame.preview:SetWidth(frame.preview.wide)
    local line = chatLine(v.preview)
    frame.preview:SetText(line)
    -- What the caller has had in front of them, and since when (L.Shown): the time starts again only when the
    -- line changes, or when its button comes or goes beside it.
    local beside = sayAct ~= nil
    if not (L.shown and L.shown.text == v.preview and L.shown.beside == beside) then
      L.shown = { text = v.preview, at = GetTime(), beside = beside }
    end
    local h = UI.TextHeight(frame.preview, UI.Lines({ line }, 1, frame.preview.wide / 7) * 16 - UI.SPACING) + 2 * SAY.top
    if sayAct then h = math.max(h, UI.BTN) end
    if v.sayLines then h = math.max(h, v.sayLines * 16 - UI.SPACING + 2 * SAY.top) end -- the same room, for the line
    top = top + UI.GAP
    frame.say:ClearAllPoints()
    frame.say:SetPoint("TOPLEFT", frame, "TOPLEFT", UI.X, -top)
    frame.say:SetHeight(h)
    if sayAct then -- centred on the line it says, its right edge on the content's
      red:ClearAllPoints()
      red:SetPoint("RIGHT", frame, "TOPRIGHT", -UI.PAD, -top - h / 2)
    end
    top = top + h
  else
    L.shown = nil
  end
  -- Shown: the highlight for this dungeon has done its work (the tab's mark, drawn by the window lane).
  if v.tab == "dungeons" then L.PartySeen() end
  -- The mark itself: while another tab is on screen and a good group for the caller's own level is waiting behind
  -- Dungeons (L.PartyMark: asked once a draw, never while Dungeons shows), a dot on that tab in the title's gold
  -- (ember under EllesmereUI). It goes when the tab is on screen; the tab's own head says what it was about.
  -- A pick that breaks costs only the dot: the list, the pager and the buttons under this line still draw (red team,
  -- 15 Nov 2026: the pick reads every guildmate, and before the dot only Dungeons asked for it). It says so once a
  -- session in the trace, with only the place in our own file.
  local marked = false
  if v.tab ~= "dungeons" then
    local ok, party = pcall(L.PartyMark)
    marked = ok and party ~= nil
    if not ok and not frame.markBroke then
      frame.markBroke = true
      if ns.trace then pcall(ns.trace, "lead", "tab mark", false, tostring(party):match("Lead%.lua:%d+") or "broke") end
    end
  end
  for _, t in ipairs(frame.tabs) do
    local on = marked and t.key == "dungeons" and t.shown and true or false
    if on then UI.DotColor(t.dot, ns.Skinned() and UI.EMBER or UI.GOLD) end
    t.dot:SetShown(on)
  end
  -- A sentence over the table with its button beside it (the plan): the table under it holds only people.
  local ab = v.above
  frame.aboveBox:SetShown(ab ~= nil)
  frame.aboveBtn:SetShown(ab ~= nil and ab.act ~= nil)
  if ab then
    local wide, btn = UI.CW, frame.aboveBtn
    if ab.act then
      btn:SetText(ab.act[1])
      btn.fn = ab.act[2]
      wide = UI.CW - UI.FitButton(btn, ab.act[1], 18, 44, 160) - BESIDE
    end
    frame.above:SetWidth(wide)
    frame.above:SetText(ab.text)
    local lines = UI.TextHeight(frame.above, UI.Lines({ ab.text }, 1, wide / 7) * STEP - UI.SPACING)
    local h = ab.act and math.max(lines, UI.SMALL) or lines
    top = top + UI.GAP
    frame.aboveBox:ClearAllPoints()
    frame.aboveBox:SetPoint("TOPLEFT", frame, "TOPLEFT", UI.X, -top - (h - lines) / 2)
    if ab.act then
      btn:ClearAllPoints()
      btn:SetPoint("RIGHT", frame, "TOPRIGHT", -UI.PAD, -top - h / 2)
    end
    top = top + h
  end
  top = top + UI.GAP

  -- The foot: the actions that aren't beside something. In one row as wide as their words where they fit (then
  -- from the left, a grey line after them where the view has one); else sharing the width, three to a row, or
  -- across to a row where the view says so (the four filters: one choice of four).
  local across, fitted, x = v.across, false, 0
  local used, widths = {}, {}
  for k, i in ipairs(foot) do
    local a = v.actions[i]
    local slot = frame.slots[k]
    -- Each place holds the tab's red button or a quiet one, whichever this action is.
    local b = a.primary and slot.red or slot.quiet
    if b == slot.red then slot.quiet:Hide() else slot.red:Hide() end
    wire(b, i)
    -- A choice that's on now (the Who's on filter) is lit like the tab on the rail.
    if b == slot.quiet then UI.QuietOn(b, a.on) end
    used[k] = b
  end
  for k = #foot + 1, #frame.slots do
    frame.slots[k].red:Hide()
    frame.slots[k].quiet:Hide()
  end
  if not across then
    for k, b in ipairs(used) do
      widths[k] = UI.FitButton(b, v.actions[foot[k]][1], b == frame.slots[k].red and 28 or 24, 60, 200)
      x = x + widths[k] + (k > 1 and FOOT_GAP or 0)
    end
    fitted = x <= UI.CW
    if not fitted then across = 3 end
  end
  local actRows = across and math.ceil(#used / across) or (#used > 0 and 1 or 0)
  if fitted then
    local at = 0
    for k, b in ipairs(used) do
      b:ClearAllPoints()
      b:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", UI.X + at, UI.EDGE)
      at = at + widths[k] + FOOT_GAP
    end
  else
    local actW = actWidth(across)
    for k, b in ipairs(used) do
      b:SetWidth(actW)
      b:ClearAllPoints() -- one row of actions sits on the window's bottom edge (level with the rail), a second above it
      b:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", UI.X + (k - 1) % across * (actW + ACT_GAP),
        UI.EDGE + (actRows - 1 - math.floor((k - 1) / across)) * ACT_STEP)
    end
  end
  -- The places not in use stay in the list the tests and the usage counts read, hidden.
  local spare = #foot
  for i = #v.actions + 1, #frame.slots do
    spare = spare + 1
    frame.actions[i] = frame.slots[spare] and frame.slots[spare].quiet or nil
  end
  -- The foot's grey line: after the buttons, its last line on the window's bottom edge with them.
  local footH = actRows > 0 and UI.BTN or 0
  frame.foot:SetShown(v.foot ~= nil)
  if v.foot then
    local from = fitted and #used > 0 and x + BESIDE or 0
    frame.footBox:ClearAllPoints()
    frame.footBox:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", UI.X + from, UI.EDGE)
    frame.foot:SetWidth(UI.CW - from)
    frame.foot:SetText(v.foot)
    footH = math.max(footH, UI.TextHeight(frame.foot, UI.Lines({ v.foot }, 1, (UI.CW - from) / 7) * STEP - UI.SPACING))
  end
  -- Over the actions: the answers when there are any, and the list down to them.
  local above = UI.EDGE + (footH > 0 and footH + ACT_GAP + math.max(0, actRows - 1) * ACT_STEP or 0)
  local notes = #L.notes > 0
  frame.answer:SetShown(notes)
  if frame.answerAt ~= above then -- moved only when the actions under it take another row (measured right after)
    frame.answer:ClearAllPoints()
    frame.answer:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", UI.X + ANSWER_IN, above)
    frame.answerAt = above
  end
  frame.answerBar:SetShown(notes)
  frame.answerBar:SetHeight(UI.AnswerSet(frame.answer, L.notes, ns.LEAD_NOTE_H, true, (UI.CW - ANSWER_IN) / 7, STEP))
  frame.list:ClearAllPoints()
  frame.list:SetPoint("TOPLEFT", frame, "TOPLEFT", UI.X, -top)
  if notes then
    frame.list:SetPoint("BOTTOMRIGHT", frame.answer, "TOPRIGHT", 0, UI.GAP)
  else
    frame.list:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -UI.PAD, above)
  end

  -- The rows that fit between the text above and the answers' place over the actions, under the table's header
  -- where the tab has one.
  local tabled = v.cols ~= nil and #v.rows > 0
  local over = tabled and ns.LEAD_HEAD_H or LIST_PAD
  local room = UI.H - top - above - (ns.LEAD_NOTE_H + UI.GAP) - over - LIST_PAD
  -- A sentence that fits on one line takes a plain row; only one that wraps is tall (a Say tab of ten lines was
  -- ten tall rows for one that wrapped).
  for _, r in ipairs(v.rows) do
    if r.tall and r.text and UI.TextWidth(frame.ruler, r.text) <= textRoom(frame.ruler, r) - 6 then r.tall = nil end
  end
  local starts = L.Pages(v.rows, room)
  local pages = #starts
  L.page = math.min(L.page, pages)
  local first, y = starts[L.page], over
  local past = starts[L.page + 1] or #v.rows + 1
  -- The header over this page: the tab's, or the second table's when the page starts in it (then that table's own
  -- header row is the one at the top, and takes no row).
  local cols = v.cols
  for i = 1, first do if v.rows[i] and v.rows[i].cols then cols = v.rows[i].cols end end
  if v.rows[first] and v.rows[first].cols then first = first + 1 end
  local people = {}
  for _, r in ipairs(v.rows) do if r.who then people[#people + 1] = r.who.name end end
  local nameW = UI.NameWidth(frame.ruler, people)
  UI.ColsSet(frame.cols, tabled and cols or nil, nameW)
  -- A second table's header takes a row's place in the list but not a row frame's pointer: the strip is drawn
  -- there and the row under it stays hidden, so nothing lights or clicks behind a header.
  local second, secondY = nil, 0
  for i, row in ipairs(frame.rows) do
    local r = first + i - 1 < past and v.rows[first + i - 1] or nil
    row:SetShown(r ~= nil and not r.cols)
    if r then
      local h = rowHeight(r)
      row:ClearAllPoints()
      row:SetPoint("TOPLEFT", 1, -y)
      row:SetHeight(h)
      if r.cols then second, secondY = r.cols, y end
      y = y + h
      fillRow(row, r, nameW)
    end
    if not r or r.cols then row.over = false end
  end
  UI.ColsSet(frame.cols2, second, nameW)
  if second and frame.cols2At ~= secondY then
    frame.cols2:ClearAllPoints()
    frame.cols2:SetPoint("TOPLEFT", frame.list, "TOPLEFT", 1, -secondY)
    frame.cols2At = secondY
  end
  -- No rows: the tab's picture, grey, over one grey line that says what shows here, the pair a little above the
  -- list's middle. The line alone near the top where the list is too short for the pair (the answers' place is
  -- counted as taken while they show) or this client has no picture for the tab. The line is hung again only when
  -- that changes.
  local none = #v.rows == 0 and v.empty ~= nil
  local listH = UI.H - top - above - (notes and ns.LEAD_NOTE_H + UI.GAP or 0)
  local pic = none and listH >= EMPTY.room and UI.IconSet(frame.emptyIcon, tabIcon(v.tab), true) or false
  if not pic then frame.emptyIcon:Hide() end
  if frame.emptyPic ~= pic then
    frame.empty:ClearAllPoints()
    if pic then
      frame.empty:SetPoint("TOP", frame.emptyIcon, "BOTTOM", 0, -EMPTY.gap)
    else
      frame.empty:SetPoint("TOP", frame.list, "TOP", 0, -EMPTY.top)
    end
    frame.emptyPic = pic
  end
  frame.empty:SetShown(none)
  frame.empty:SetText(v.empty or "")
  UI.PagerSet(frame.pager, L.page, pages)
end
L.refresh = function() ns.protect(draw) end

local function build()
  local f = UI.Window("UW_GuildLead", "Lead a group", "HIGH")

  -- Tabs on the rail, each with its icon where this client has the pictures (one that shows means its lookups
  -- work: then every tab's name starts in by the same amount, even where one picture is missing).
  local pictures = false
  for _, t in ipairs(L.TABS) do
    local row = tabIcon(t[1])
    if row and row[1] ~= "class" and UI.GameIcon(row) then pictures = true end
  end
  f.tabs = {}
  for i, t in ipairs(L.TABS) do
    local b = UI.Nav(f, t[2])
    b.key, b.name, b.officer = t[1], t[2], t.officer
    b.icon = UI.Icon(b, UI.NAV_ICON)
    b.icon:SetPoint("LEFT", UI.GAP, 0)
    if pictures then
      UI.IconSet(b.icon, tabIcon(t[1]))
      b.label:SetPoint("LEFT", UI.GAP + UI.NAV_ICON + 6, 0)
    end
    -- Its mark: a dot at its right end, on the label's line, shown by draw while something new is behind the tab.
    b.dot = UI.Dot(b, ns.LEAD_MARK.dot)
    b.dot:SetPoint("RIGHT", b, "RIGHT", -ns.LEAD_MARK.edge, 0)
    b:SetScript("OnClick", function() L.tab, L.page = t[1], 1; L.refresh() end)
    ns.useButton(b, "lead " .. t[1])
    f.tabs[i] = b
  end

  -- Rehearse: the switch at the foot of the rail, and an orange line by the heading while it's on, so a practice
  -- run never looks like a real one.
  local cb = CreateFrame("CheckButton", nil, f.rail, "UICheckButtonTemplate")
  cb:SetSize(UI.CHECK, UI.CHECK)
  cb:SetPoint("BOTTOMLEFT", 8, 8)
  local cbl = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  cbl:SetPoint("LEFT", cb, "RIGHT", 4, 0)
  cbl:SetText("Rehearse")
  if cb.SetHitRectInsets then cb:SetHitRectInsets(0, -72, 0, 0) end -- a click on the word ticks it too
  cb:SetScript("OnClick", function(self) ns.protect(L.SetRehearse, self:GetChecked()) end)
  cb:SetScript("OnEnter", function(self) UI.Tip(self, "Rehearse", "Practice guildmates, a practice raid and practice "
    .. "answers. Nothing is sent or invited.") end)
  cb:SetScript("OnLeave", function(self) UI.TipHide(self) end)
  ns.Skin("Checkbox", cb)
  ns.useButton(cb, "lead rehearse")
  f.rehearse = cb
  f.banner = UI.Sub(f, "GameFontNormal")
  f.banner:SetText("|cffff8000Rehearsal: nothing is sent.|r")

  f.pager = UI.Pager(f, function(way) L.page = math.max(1, L.page + way); L.refresh() end)
  ns.useButton(f.pager.prev, "lead page")
  ns.useButton(f.pager.next, "lead page")

  -- An action: its click, its tooltip, its usage count.
  local function action(b)
    b:SetScript("OnClick", function(self) if self.fn then ns.protect(self.fn); L.refresh() end end)
    ns.useButton(b, "lead action")
    b:SetScript("OnEnter", function(self) if self.tip then UI.Tip(self, self.tipTitle or self:GetText(), self.tip) end end)
    b:SetScript("OnLeave", function(self) UI.TipHide(self) end)
    b:Hide()
    return b
  end

  -- What the tab says. Its text sits on a frame of its own and is never hung again (a text let go of its place
  -- can measure 0 until the next frame); the frame moves down a little when a taller button sits beside one line.
  f.headBox = CreateFrame("Frame", nil, f)
  f.headBox:SetSize(UI.CW, 1)
  f.headBox:SetPoint("TOPLEFT", f, "TOPLEFT", UI.X, -UI.BODY)
  f.head = UI.Body(f.headBox, UI.CW, "GameFontHighlight")
  f.head:SetPoint("TOPLEFT")
  f.headBtn = action(UI.Quiet(f, 100, "", UI.SMALL, true))
  -- A sentence over the table (the plan), on a frame of its own like the head, with its button: counted as the
  -- row button it was.
  f.aboveBox = CreateFrame("Frame", nil, f)
  f.aboveBox:SetSize(UI.CW, 1)
  f.above = UI.Body(f.aboveBox, UI.CW, "GameFontHighlight")
  f.above:SetPoint("TOPLEFT")
  f.aboveBox:Hide()
  f.aboveBtn = UI.Quiet(f, 60, "", UI.SMALL, true)
  f.aboveBtn.fn = false
  f.aboveBtn:SetScript("OnClick", function(self) if self.fn then ns.protect(self.fn); L.refresh() end end)
  ns.useButton(f.aboveBtn, "lead row")
  f.aboveBtn:Hide()
  f.input = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
  f.input:SetSize(260 - boxInset(), BOX_H)
  f.input:SetPoint("TOPLEFT", f, "TOPLEFT", UI.X + boxInset(), -UI.BODY - UI.LINE - UI.GAP)
  f.input:SetAutoFocus(false)
  f.input:SetMaxLetters(40)
  f.input:SetText("a dungeon")
  f.input:SetScript("OnTextChanged", function(self) L.what = self:GetText(); L.refresh() end)
  f.input:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
  f.input:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  ns.Skin("EditBox", f.input)
  f.boxRed = action(UI.Button(f, 110, ""))
  -- Notes: Copy puts the text here, selected, so Ctrl+C copies it. Typing in it changes nothing (it snaps back).
  f.copy = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
  f.copy:SetSize(320 - boxInset(), BOX_H)
  f.copy:SetPoint("TOPLEFT", f, "TOPLEFT", UI.X + boxInset(), -UI.BODY - UI.LINE - UI.GAP)
  f.copy:SetAutoFocus(false)
  f.copy:SetScript("OnTextChanged", function(self, user) if user then self:SetText(L.copyText or "") self:HighlightText() end end)
  f.copy:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
  f.copy:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  ns.Skin("EditBox", f.copy)
  -- The line the call will say, as guild chat will show it: chat's own font and colour, behind a bar of that
  -- colour, on a darker strip.
  local guild = type(g("ChatTypeInfo")) == "table" and g("ChatTypeInfo").GUILD or nil
  local gr, gg, gb = guild and guild.r or 0.25, guild and guild.g or 1, guild and guild.b or 0.25
  f.say = CreateFrame("Frame", nil, f)
  f.say:SetSize(UI.CW, 2 * SAY.top + 14)
  UI.Fill(f.say, "BACKGROUND", 0, 0, 0, 0.42):SetAllPoints()
  local bar = UI.Thin(UI.Fill(f.say, "ARTWORK", gr, gg, gb, 1), SAY.bar)
  bar:SetPoint("TOPLEFT")
  bar:SetPoint("BOTTOMLEFT")
  f.preview = UI.Body(f.say, UI.CW - SAY.bar - 2 * SAY.side, rawget(_G, "ChatFontNormal") and "ChatFontNormal" or "GameFontHighlight")
  f.preview.wide = UI.CW - SAY.bar - 2 * SAY.side
  f.preview:SetPoint("TOPLEFT", SAY.bar + SAY.side, -SAY.top)
  f.preview:SetTextColor(gr, gg, gb)
  f.say:Hide()

  f.list = UI.Well(f)
  f.ruler = f.list:CreateFontString(nil, "BACKGROUND", "GameFontHighlight") -- measures names; never shows one
  f.ruler:SetPoint("TOPLEFT")
  if f.ruler.SetAlpha then f.ruler:SetAlpha(0) end
  f.cols = UI.Cols(f.list, LIST_W)
  f.cols:SetPoint("TOPLEFT", 1, 0)
  f.cols2 = UI.Cols(f.list, LIST_W)
  f.rows = {}
  for i = 1, ns.LEAD_ROWS do
    local row = CreateFrame("Button", nil, f.list)
    row:SetSize(LIST_W, ns.LEAD_ROW_H) -- placed, and made taller for a sentence, when it's drawn
    row:SetPoint("TOPLEFT", 1, -LIST_PAD - (i - 1) * ns.LEAD_ROW_H)
    row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.text:SetPoint("LEFT", P.pad, 0)
    row.text:SetHeight(ns.LEAD_ROW_H)
    if row.text.SetSpacing then row.text:SetSpacing(UI.SPACING) end
    row.text:SetJustifyH("LEFT")
    row.text:SetJustifyV("MIDDLE")
    -- A label over a group of rows: its words in the title's gold, how many in grey.
    row.label = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    row.label:SetPoint("BOTTOMLEFT", P.pad, 4)
    row.count = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    row.count:SetPoint("BOTTOMLEFT", row.label, "BOTTOMRIGHT", 6, 1)
    UI.RowActs(row, 2)
    UI.Person(row)
    row:SetScript("OnClick", function(self) if self.pick then ns.protect(self.pick); L.refresh() end end)
    row:SetScript("OnEnter", function(self)
      UI.RowEnter(self)
      -- A line or a column that's cut shows whole under the pointer.
      local function cut(fs) return fs.IsTruncated ~= nil and fs:IsTruncated() == true end
      if self.person then
        if self.cut == true or cut(self.last) or cut(self.name) then UI.PersonTip(self, f) end
      elseif cut(self.text) and self.full then
        UI.TipBeside(self, f, self.full)
      end
    end)
    row:SetScript("OnLeave", function(self) UI.RowLeave(self) end)
    for _, b in ipairs(row.acts) do
      b:SetScript("OnClick", function(self) if self.fn then ns.protect(self.fn); L.refresh() end end)
      ns.useButton(b, "lead row")
    end
    f.rows[i] = row
  end

  -- A list with no rows: one grey line says what shows here, under the tab's picture in grey where there is one
  -- (draw places the line: under the picture, or alone near the top).
  f.emptyIcon = UI.Icon(f.list, EMPTY.icon)
  f.emptyIcon:SetPoint("BOTTOM", f.list, "CENTER", 0, EMPTY.lift)
  if f.emptyIcon.SetAlpha then f.emptyIcon:SetAlpha(EMPTY.dim) end
  f.empty = f.list:CreateFontString(nil, "OVERLAY", "GameFontDisable")
  f.empty:SetPoint("TOP", f.list, "TOP", 0, -EMPTY.top)
  f.empty:SetWidth(UI.CW - 2 * UI.PAD)
  f.empty:Hide()
  f.emptyPic = false
  f.markBroke = false -- the tab mark's pick has broken this session (draw says so once)

  -- Six places at the foot. Each holds a red button and a quiet one; the tab's view says which shows (f.actions:
  -- the button each of the view's actions is on now, wherever it sits).
  f.slots, f.actions = {}, {}
  for i = 1, 6 do
    local slot = { red = action(UI.Button(f, actWidth(3), "")), quiet = action(UI.Quiet(f, actWidth(3), "", nil, true)) }
    f.slots[i], f.actions[i] = slot, slot.quiet
  end
  -- The foot's grey line, on a frame of its own: the frame moves, the text never does.
  f.footBox = CreateFrame("Frame", nil, f)
  f.footBox:SetSize(UI.CW, 1)
  f.footBox:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", UI.X, UI.EDGE)
  f.foot = UI.Body(f.footBox, UI.CW, "GameFontDisable")
  f.foot:SetPoint("BOTTOMLEFT")
  f.foot:Hide()
  -- The last answers, over the actions: the same body text behind a thin bar as the guide's answer.
  f.answer = UI.Body(f, UI.CW - ANSWER_IN, "GameFontHighlight")
  f.answer:SetJustifyV("BOTTOM")
  f.answerBar = UI.Thin(UI.Fill(f.body, "ARTWORK", 1, 1, 1, 0.25), 2)
  f.answerBar:SetPoint("BOTTOMLEFT", f.answer, "BOTTOMLEFT", -ANSWER_IN, 0)
  f.answerBar:Hide()
  f:SetScript("OnShow", function() L.refresh() end)
  -- Closed with the pointer on a row: its buttons don't wait there for the next time it opens.
  f:SetScript("OnHide", function(self)
    for _, row in ipairs(self.rows) do row.over = false end
    L.shown = nil -- a line is "seen" only while the window shows it
  end)
  -- The call's minutes and who's online change on their own: redraw every 5 seconds while open.
  local tick = 0
  f:SetScript("OnUpdate", function(_, dt)
    tick = tick + (dt or 0)
    if tick >= 5 then tick = 0; L.refresh() end
  end)
  return f
end

-- Puts text in the Notes tab's copy box, focused and selected: Ctrl+C copies it.
function L.Copy(text)
  L.copyText = text
  if not frame then return end
  frame.copy:SetText(text)
  frame.copy:SetFocus()
  frame.copy:HighlightText()
end

local callTold = {} -- per character, once a session
-- asked: the tab the caller named (L.OpenTab). The window opens where it was left, and the first time in a session
-- that is Dungeons (with Suggest a party on). Someone who has only the calling tabs gets Dungeons each time, unless
-- the Call tab was asked for. It never opens on a Dungeons tab with nothing to suggest: then Who's on, or the Call
-- tab, is the place to start.
function L.Open(asked)
  local some = ns.PARTY_SUGGEST and (asked == "dungeons" or #L.DungeonList() > 0)
  if not ns.MayLead() then
    if not ns.MayCall() then
      say("Members and up: /uw lead call writes a group call for you. Anyone can call one by typing in guild chat.")
      return false
    end
    -- Two tabs for a Member: Dungeons when there's a group to suggest, unless Call a group was asked for or is
    -- where the window was left.
    L.tab, L.page = (some and (asked or L.tab) ~= "call") and "dungeons" or "call", 1
    if not callTold[ns.me() or ""] then
      callTold[ns.me() or ""] = true
      say("Call a group is yours now: /uw lead call.")
    end
  elseif L.tab == "dungeons" and not some then
    L.tab, L.page = "online", 1
  end
  if InCombatLockdown() then say("After the fight: /uw lead.") return false end
  frame = frame or build()
  frame:Show()
  L.refresh()
  return true
end

-- Opens /uw lead on one tab. quiet: no "officers only" line (the caller has its own fallback). False if it can't open.
-- An officer-only tab (Notes) opens only for officers.
function L.OpenTab(tab, quiet)
  local gated, open = false, false
  for _, t in ipairs(L.TABS) do
    if t[1] == tab then gated, open = t.officer and true or false, L.TabOpen(t) end
  end
  if gated and not officer() then
    if not quiet then say("Officers only: the Notes tab is guild notes waiting to be set by hand.") end
    return false
  end
  if quiet and (not open or InCombatLockdown()) then return false end
  L.tab, L.page = tab, 1
  return L.Open(tab)
end

-- /uw asks off|on: whether guildmates' group asks in guild chat show on this account (Member and up, officers).
ns.commands.asks = function(args)
  local w = strtrim(args or ""):lower()
  if not ns.MayCall() then say("Group asks show for Members and up.") return end
  if w == "off" then
    UW_GuildDB.asksOff, L.asks = true, {}
    L.UpdateNow(true)
    say("Group asks from guild chat won't show for you now; officers and other guildmates still see them."
      .. " /uw asks on brings them back.")
  elseif w == "on" then
    UW_GuildDB.asksOff, UW_GuildDB.asksTold = nil, true
    say("Group asks from guild chat show again, so you can call a group for whoever is waiting.")
  else
    say(("Group asks from guild chat: %s. /uw asks %s"):format(UW_GuildDB.asksOff and "off" or "on",
      UW_GuildDB.asksOff and "on" or "off"))
  end
end

ns.commands.lead = function(args)
  local w = strtrim(args or ""):lower()
  -- A guildmate's ask waiting while the buttons above chat are hidden (/uw hide): call it as the button would.
  if w == "call" and L.nowAction and L.nowAction.kind == "ask" then L.NowClick("LeftButton") return end
  -- The guide's Call a group button comes here too: with a group to suggest, no call open and nobody's ask in the
  -- box, calling starts on Dungeons (coordinator, 15 Nov 03:28).
  if w == "dungeons" or (w == "call" and ns.PARTY_SUGGEST and not calledRecently() and not boxAsk()
    and #L.DungeonList() > 0) then
    L.OpenTab(ns.PARTY_SUGGEST and "dungeons" or "call")
    return
  end
  if w == "call" or w == "notes" then L.OpenTab(w) return end
  if w == "rehearse" then
    if not L.Open() then return end
    frame.rehearse:SetChecked(true)
    L.SetRehearse(true)
    return
  end
  L.Open()
end

-- Say it before it shows (gentle rollouts, rule 2): one line, once per account, to a Raider or Member who isn't an
-- officer, from the day before their rank's date. Not in the same session as the /uw rate line (rule 5): the rate line comes first, this one the
-- next time they log in.
function L.HeadsUp(rateToldBefore)
  local o = opening()
  if UW_GuildDB.leadTold or officer() or not rateToldBefore or not o or now() < o[1] - HEADSUP_AHEAD
    or not ns.NewLineFree() then return false end
  UW_GuildDB.leadTold = true
  local text = ": /uw lead helps you run a group. Call one in guild chat, invite who answers, pass the lead. Use it if you like."
  if now() >= o[1] then say("New" .. text) else say(("From %s"):format(o[2]) .. text) end
  return true
end

local f = CreateFrame("Frame")
ns.listen(f, { "CHAT_MSG_GUILD", "GROUP_ROSTER_UPDATE", "PLAYER_ENTERING_WORLD" })
f:SetScript("OnEvent", ns.guard(function(_, event, msg, sender)
  if event == "CHAT_MSG_GUILD" then
    ns.protect(L.Heard, msg, sender)
    ns.protect(L.TellAsks) -- also here: the roster's rank can land after the login events
    if L.HearsAsks() then
      ns.protect(function()
        L.AskAnswered(msg, sender)
        if L.HeardAsk(msg, sender) or L.nowAction and L.nowAction.kind == "ask" then L.UpdateNow(true) end
      end)
    end
  elseif event == "PLAYER_ENTERING_WORLD" then
    local isLogin, isReload = msg, sender
    if not ((isLogin or isReload) and IsInGuild()) or type(UW_GuildDB) ~= "table" then return end
    local told = UW_GuildDB.rateTold   -- before Thanks.lua's line can set it this session
    ns.after(65, function() ns.protect(L.HeadsUp, told) end)
  elseif L.refresh then L.refresh() end
end))

-- The "now" button (8 Nov 2026, member journey, bot/uwbot/funnel.py): the two biggest leaks were a first dungeon
-- with a guildmate (11 of 152 newcomers) and the Discord welcome (91 of 157 never whispered: they joined before it
-- existed, or while no officer was online). Both have a fix already, the suggested call and /uw discord ask, but each
-- waited for an officer to remember it; the login line says it once. So while one is worth doing right now, an
-- officer sees one button above chat (over the notes button). A click opens the call with the suggestion filled in,
-- or runs /uw discord ask (the welcome Louis approved, once ever per member, 25 a run). The officer still sends the
-- call with the usual two clicks, and the button itself sends nothing members see. Prompting at the moment it can be
-- acted on, with the step spelled out, is what turns intent into action (Fogg 2009); one button, not a list, keeps it
-- calm. Hidden in combat, in instances and while a call is open; 30 min quiet after a click; right-click hides it
-- until the next login.
-- An offer, not a nag (Louis, 9 Nov 03:17 "enhance, don't interfere"; 03:37 "...call a group button still shows?"):
-- the suggested call shows once per login. It's gone for the session once you click it or call a group any way, and
-- an offer you leave alone folds after NOW_CALL_SHOW. Only a guildmate's own ask in guild chat brings the button
-- back, because then someone is waiting.
ns.NOW_CALL_AT_LEAST, ns.NOW_WELCOME_AT_LEAST, ns.NOW_SNOOZE, ns.NOW_EVERY = 3, 3, 1800, 30
ns.NOW_CALL_SHOW = 600
local nowButton, nowSnoozed, nowHidden, nowChecked, nowAskSeen = nil, 0, false, -math.huge, 0
local nowAskTold = 0 -- the ask last said in chat while the buttons above chat are hidden
local nowCallDone, nowCallSince = false, nil -- the suggested call had its one showing this login

local function inInstance()
  if type(IsInInstance) ~= "function" then return false end
  local inside, kind = IsInInstance()
  return inside and kind ~= "none"
end

-- Asks heard in guild chat (8 Nov, first dungeon for every newcomer): a member with no addon and no Discord has one way
-- to get a dungeon group themselves, asking in /g ("lfg wc", "anyone up for rfc?"). When nobody leading is around to
-- answer, the ask scrolls away. While no call is open, this officer's client keeps the newest ask per guildmate for
-- ASK_KEEP seconds, and the button offers a call for that level. It whispers nobody: the call is the answer, in the
-- same channel they asked in. Only short lines that name a group or a dungeon and read as a request count.
ns.ASK_KEEP, ns.ASK_MAX_LEN, ns.ASK_MAX_WORDS = 1800, 60, 8
-- A Member's button waits a random 20-40 s after the ask; officers' shows at once. The first call posted clears the ask on
-- every client (CALL_OPENS), so one guildmate answers and the rest never see a button for an ask already taken.
ns.ASK_HOLD_MIN, ns.ASK_HOLD_MAX = 20, 40
-- A typed call (auditor, 13 Nov, ops/audit-people-shift.md item 3): "anyone up for WC? type inv" is someone starting a
-- group and asking for answers in guild chat, the same as the Call button, not someone asking for one. It was read
-- as an ask, so it lit the ask button on officers' screens (inviting a rival call), and neither it nor its answers
-- were counted: only Call-button presses on the pressing client were, so "only Louis calls" was the counter, not the
-- guild. A call names a group and tells people what to type back ("type inv", "say x", "x for inv"); it may run
-- longer than an ask, as the Call button's own line does.
ns.CALL_MAX_LEN, ns.CALL_MAX_WORDS = 140, 24
-- The words of a guild line, as the ask and answer tests read them (addon search, 13 Nov 2026: a re-read of 60 real
-- shapes found "dm me if you need a group" and "need 5 more linen for my run" counted as asks, "lf healer" and
-- "anyone for sunken temple?" missed, "zul'farrak" split in two, and "inv layer pls" taken as an answer). A link's
-- text is one word, "link" (an item called "Wailing Robe" names no dungeon); an apostrophe joins ("zul'farrak" is
-- "zulfarrak"); colour codes and punctuation go.
function ns.AskWords(msg)
  local t = msg:gsub("|H.-|h.-|h", " link "):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
  t = t:gsub("\226\128\153", ""):gsub("['`]", ""):lower()
  local words = {}
  for w in t:gmatch("[%w]+") do words[#words + 1] = w end
  return words
end
-- Words that name a group or a place to take one. Dungeons and raids as people type them, Forever's nine included
-- (Ruins of Lordaeron, Excavation Site, City of Dalaran, The Drowned City, Krol'dok Stronghold, Alcaz Prison,
-- Blackmaw Hold, Shaper's Terrace, Hall of Thanes). Short forms that are also everyday words ("lib", "arm", "gy",
-- "east") are left out: a full wing name still counts.
local ASK_GROUP = {}
for w in ([[group groups grp dungeon dungeons dung dungeoning instance instances
  rfc ragefire wc wailing dm deadmines vc sfk shadowfang bfd blackfathom stocks stockade rfk kraul
  gnomer gnomeregan gnome sm scarlet smgy smlib smarm smcath graveyard library armory armoury cathedral cath
  rfd downs ulda uld uldaman zf zulfarrak farrak mara maraudon st sunken atal atalhakkar brd lbrs ubrs brs
  dme dmw dmn diremaul maul tribute strat stratholme strath scholo scholomance sholo
  ony onyxia mc bwl zg naxx hyjal barrow
  thanes lordaeron ruins excavation dalaran drowned kroldok alcaz blackmaw shaper shapers]]):gmatch("%S+") do
  ASK_GROUP[w] = true
end
-- Every word QuestChain.lua's whisper list knows, so one list names the dungeons.
for _, d in ipairs(ns.DUNGEONS or {}) do for _, w in ipairs(d[3]) do ASK_GROUP[w] = true end end
-- Roles name a group too ("lf healer", "need a tank").
local ASK_ROLE = { tank = true, tanks = true, heal = true, heals = true, healer = true, healers = true, dps = true,
  dd = true }
local ASK_REQUEST = { lfg = true, lfm = true, lf = true, anyone = true, any1 = true, anybody = true, who = true,
  wanna = true, want = true, need = true, needs = true, looking = true, lftank = true, lfheal = true,
  lfhealer = true, lfheals = true, lfdps = true }
-- Not a group ask: a question about a place, trade, items, travel, layers, or a line with a link in it.
local ASK_NOT = { know = true, where = true, wheres = true, how = true, hows = true, layer = true, layers = true,
  wts = true, wtb = true, wtt = true, sell = true, selling = true, seller = true, buy = true, buying = true,
  item = true, items = true, boe = true, boes = true, boost = true, boosting = true, summon = true, summons = true,
  summ = true, port = true, portal = true, link = true }
-- "dm me", "dm us": a direct message, not Dire Maul or the Deadmines.
local DM_TO = { me = true, us = true, you = true, him = true, her = true, them = true, pls = true, please = true }
-- "run" alone is any trip ("want to run to org?", "5 more linen for my run"): it names a group only as "a run",
-- "some runs", "quick run".
local RUN_AFTER = { a = true, some = true, quick = true, few = true }
local function requestWord(w) return ASK_REQUEST[w] or w:match("^lf%dm$") ~= nil end -- lf1m .. lf4m
L.asks = {}
-- Who keeps asks (13 Nov, priority 2: more member leaders): everyone who may call a group (officers, and Member and up
-- since #504), unless they switched it off with /uw asks off. Officers get every "now" offer; the others only asks,
-- and only once L.TellAsks has said so (gentle rollouts rule 2: say it before it shows).
function L.HearsAsks()
  if type(UW_GuildDB) ~= "table" or UW_GuildDB.asksOff then return false end
  if ns.isOfficer(ns.me()) then return true end
  return UW_GuildDB.asksTold == true and ns.MayCall()
end
ns.ASKS_NEW = "when a guildmate asks for a group in guild chat, UW_Guild offers you a call for their level."
  .. " /uw asks off turns it off."
-- Once per account, before a Member's first ask button can show; never in combat. Officers have had asks since 8 Nov.
function L.TellAsks()
  if type(UW_GuildDB) ~= "table" or UW_GuildDB.asksTold or UW_GuildDB.asksOff or InCombatLockdown() then return end
  if ns.isOfficer(ns.me()) or not ns.MayCall() then return end
  -- A first install reads as a welcome, not a changelog: no "New: " then (ns.TellNew). Told only once said.
  if ns.TellNew(ns.ASKS_NEW) then UW_GuildDB.asksTold = true end
end
-- Answered elsewhere (red team R7, 8 Nov): asks live on each officer's client, so another officer's call (any guild
-- line that opens like ns.LEAD_CALL) clears them all here, and the asker's own "inv" or "+" drops theirs.
local CALL_OPENS = (ns.LEAD_CALL:match("^(.-)%%s") or ns.LEAD_CALL):lower()
function L.AskAnswered(msg, sender)
  if type(msg) ~= "string" or ns.isSecret(msg) or type(sender) ~= "string" or ns.isSecret(sender) then return end
  local text = strtrim(msg):lower()
  if CALL_OPENS ~= "" and text:sub(1, #CALL_OPENS) == CALL_OPENS then L.asks = {} return end -- the Call button's line
  if ns.IsGroupCall(msg) then L.asks[short(sender)] = nil return end -- a typed call: the caller's own ask is moot
  if #text <= 12 and (text:match("^inv") or text:match("^%+")) then L.asks[short(sender)] = nil end
end
-- The shape alone: "call" for a group with a "type inv" (below), "ask" for a short line that names a group or a dungeon
-- and reads as a request, "fill" when the writer is filling their own group ("lf2m wc", "lf healer", "need 2 more",
-- "lfm"), "start" for a group started another way ("starting wc, pst"), nil for anything else. A fill
-- isn't an ask (journey sim, 13 Nov 2026): every guildmate has read it already, whoever wants in whispers them, and an
-- officer's call would start a rival group. "anyone need a tank?" offers to join, so it stays an ask.
local ROLE_COMPOUND = { lftank = true, lfheal = true, lfhealer = true, lfheals = true, lfdps = true }
local OFFERS = { anyone = true, any1 = true, anybody = true, who = true }
-- The reply a call asks for: a verb ("type", "say", ...) then, within two words, inv, invite or x ("type inv",
-- "say x", "drop an x in guild"); or "x for inv" / "+ for inv". Not "in" (integrator review: "put me in for wc pls",
-- "say in guild if you have room" are asks), and not a verb about the writer themselves ("put me in", "drop me inv",
-- "i'll type inv when ready"): those are someone asking to join.
local CUE_VERB = { type = true, say = true, put = true, drop = true, reply = true, post = true, write = true }
local CUE_WORD = { inv = true, invite = true, x = true }
local CUE_SELF = { i = true, ill = true, im = true, id = true, me = true, us = true }
local CUE_NOT = { someone = true, somebody = true, pls = true, please = true, dont = true, cant = true, wont = true,
  no = true, never = true }
local function forMe(words, i)
  for j = i + 1, i + 3 do if words[j] == "me" or words[j] == "us" then return true end end
  return false
end
local function callCue(words, text)
  for i, w in ipairs(words) do
    local before = words[i - 1] or ""
    if CUE_VERB[w] and not CUE_SELF[before] and not CUE_NOT[before] and not forMe(words, i)
      and (CUE_WORD[words[i + 1] or ""] or CUE_WORD[words[i + 2] or ""]) then return true end
  end
  return text:find("[x%+] for inv") ~= nil
end
local function readCall(msg)
  if #msg > ns.CALL_MAX_LEN then return false end
  local text = strtrim(msg):lower()
  if CALL_OPENS ~= "" and text:sub(1, #CALL_OPENS) == CALL_OPENS then return true end -- the Call button's own line
  local words = ns.AskWords(msg)
  if #words == 0 or #words > ns.CALL_MAX_WORDS or not callCue(words, text) then return false end
  for _, w in ipairs(words) do
    if ASK_NOT[w] then return false end
    if ASK_GROUP[w] or ASK_ROLE[w] or w == "lfm" or w:match("^lf%dm$") then return true end
  end
  return false
end
-- A group someone starts the usual way, with no "type inv" (auditor, 14 Nov: "starting wc, pst", "running rfc in 5 w
-- me" were counted nowhere): a group word, no offer or question ("anyone starting wc?" is an ask), and either a start
-- word (starting, forming, making) or a whisper cue (pst, hmu, "w me", "msg me", "pm me"). Up to a call's length.
-- Long fills ("lf2m wc need a tank and heals then we go") count here too, since ReadAsk's own fill test stops at an
-- ask's length. Not "pm me if you need a group": an offer of help. Not an answer to a call ("+1 healer, pst", "inv
-- healer pst", "x healer w me", "im in, tank, w me": integrator, 14 Nov), so the call's answers stay as they were. Not
-- "making gold in wc, pst". Not someone offering themselves for a group ("tank for wc pst", "i can tank wc pst": red
-- team, 14 Nov): a role about the writer, with no wanted word before it and no start word or fill.
local SELF_BEFORE = { can = true, i = true, im = true, am = true, as = true }
local SELF_AFTER = { ["for"] = true, lf = true, lfg = true, looking = true, here = true, available = true, avail = true }
local WANTED = { need = true, needs = true, lf = true, lfm = true, looking = true, want = true, wanna = true }
local START_VERB = { starting = true, forming = true, making = true }
local START_NOT_AFTER = { gold = true, money = true }
local ANSWER_FIRST = { inv = true, invite = true, x = true, ["in"] = true }
local WHISPER_CUE = { pst = true, psst = true, whisper = true, hmu = true }
local WHISPER_ME = { w = true, msg = true, pm = true, message = true }
local function readStart(msg)
  if #msg > ns.CALL_MAX_LEN or msg:find("?", 1, true) then return false end
  local words = ns.AskWords(msg)
  if #words == 0 or #words > ns.CALL_MAX_WORDS then return false end
  if msg:match("^%s*%+") or ANSWER_FIRST[words[1]] or (words[1] == "im" and words[2] == "in") then return false end
  local group, start, cue, wanted, self = false, false, false, false, false
  for i, w in ipairs(words) do
    local prev, nxt, after = words[i - 1], words[i + 1], words[i + 2]
    if ASK_NOT[w] or OFFERS[w] or (w == "dm" and nxt and DM_TO[nxt]) then return false end
    if (w == "you" or w == "u") and (nxt == "need" or nxt == "needs" or after == "need") then return false end
    if (w == "run" or w == "runs") and prev and RUN_AFTER[prev] then group = true end
    group = group or ASK_GROUP[w] or ASK_ROLE[w] or false
    local fill = w == "lfm" or w:match("^lf%dm$") ~= nil or ROLE_COMPOUND[w]
      or (w == "lf" and nxt and (ASK_ROLE[nxt] or nxt == "more" or nxt:match("^%d$") ~= nil))
    if START_VERB[w] and nxt and START_NOT_AFTER[nxt] then return false end
    start = start or START_VERB[w] or fill or false
    cue = cue or WHISPER_CUE[w] or (WHISPER_ME[w] and nxt == "me") or false
    if ASK_ROLE[w] and not wanted and (SELF_BEFORE[prev] or (nxt and SELF_AFTER[nxt])) then self = true end
    wanted = wanted or WANTED[w] or w:match("^lf%dm$") ~= nil
  end
  return group and (start or (cue and not self))
end
function ns.ReadAsk(msg)
  if type(msg) ~= "string" or ns.isSecret(msg) then return nil end
  if readCall(msg) then return "call" end
  local kind = ns.ReadShortAsk(msg)
  if kind then return kind end
  return readStart(msg) and "start" or nil
end
-- ReadAsk for a line within an ask's length: "ask", "fill" or nil.
function ns.ReadShortAsk(msg)
  if #msg > ns.ASK_MAX_LEN then return nil end
  local words = ns.AskWords(msg)
  local n = #words
  if n == 0 or n > ns.ASK_MAX_WORDS then return nil end
  local group, request, fill, offer = false, msg:find("?", 1, true) ~= nil, false, false
  for _, w in ipairs(words) do offer = offer or OFFERS[w] or false end -- "need a tank anyone?" offers too
  for i, w in ipairs(words) do
    local prev, nxt, after = words[i - 1], words[i + 1], words[i + 2]
    if ASK_NOT[w] or (w == "dm" and nxt and DM_TO[nxt]) then return nil end
    if (w == "run" or w == "runs") and prev and RUN_AFTER[prev] then group = true end
    group = group or ASK_GROUP[w] or ASK_ROLE[w] or requestWord(w) and w ~= "lf" and w:match("^lf") ~= nil
    request = request or requestWord(w)
    -- Filling: lfm, lf2m, lftank; "lf healer", "lf more", "lf 1 tank"; "need a healer", "need 2 more"; "last spot".
    local someone = nxt and (ASK_ROLE[nxt] or nxt == "more" or (nxt:match("^%d$") and after
      and (after == "more" or ASK_ROLE[after])) or ((nxt == "a" or nxt == "an") and after and ASK_ROLE[after]))
    fill = fill or w == "lfm" or w:match("^lf%dm$") ~= nil or ROLE_COMPOUND[w] or (w == "lf" and someone)
      or ((w == "need" or w == "needs") and someone and not offer) or (w == "spot" and prev == "last") or false
  end
  if not (group and request) then return nil end
  return fill and "fill" or "ask"
end
-- A group ask (Lead.lua L.HeardAsk, and the counts on the bot's PC: Core.lua ns.CountGuildChat).
function ns.IsGroupAsk(msg) return ns.ReadAsk(msg) == "ask" end
-- A "maybe ask" (harvest item 4, 13 Nov 2026: count the misses, not only the false alarms): a line ReadAsk passes
-- over only for its length (over ASK_MAX_LEN characters or ASK_MAX_WORDS words, and not a call) that names a group or a
-- dungeon, has a request word and isn't filling the writer's own group, like "hey is anyone around level 17 up for
-- wailing caverns tonight?". Counted per night (WeekOne.lua mg), never shown: whether officers should see these
-- waits for the number. Lines over MAYBE_MAX_LEN are chat walls, not asks.
ns.MAYBE_MAX_LEN = 200
function ns.MaybeAsk(msg)
  if type(msg) ~= "string" or ns.isSecret(msg) or #msg > ns.MAYBE_MAX_LEN or ns.ReadAsk(msg) ~= nil then return false end
  local words = ns.AskWords(msg)
  if #msg <= ns.ASK_MAX_LEN and #words <= ns.ASK_MAX_WORDS then return false end -- short: ReadAsk's own "no"
  local group, request, offer = false, false, false
  for i, w in ipairs(words) do
    local prev, nxt, after = words[i - 1], words[i + 1], words[i + 2]
    if ASK_NOT[w] or (w == "dm" and nxt and DM_TO[nxt]) then return false end
    if (w == "run" or w == "runs") and prev and RUN_AFTER[prev] then group = true end
    group = group or ASK_GROUP[w] or ASK_ROLE[w] or requestWord(w) and w ~= "lf" and w:match("^lf") ~= nil or false
    request = request or requestWord(w)
    offer = offer or OFFERS[w] or false
    local someone = nxt and (ASK_ROLE[nxt] or nxt == "more" or (nxt:match("^%d$") and after
      and (after == "more" or ASK_ROLE[after])) or ((nxt == "a" or nxt == "an") and after and ASK_ROLE[after]))
    if w == "lfm" or w:match("^lf%dm$") or ROLE_COMPOUND[w] or (w == "lf" and someone)
      or ((w == "need" or w == "needs") and someone and not offer) or (w == "spot" and prev == "last") then
      return false -- filling their own group
    end
  end
  return group and request
end
-- A group call anyone typed, the Call button's line included (Core.lua ns.CountGuildChat counts them too).
function ns.IsGroupCall(msg) return ns.ReadAsk(msg) == "call" end
function L.HeardAsk(msg, sender)
  if L.rehearse or calledRecently() or not ns.IsGroupAsk(msg) then return false end
  if type(sender) ~= "string" or ns.isSecret(sender) then return false end
  local name = short(sender)
  if name == short(ns.me() or "") then return false end
  local level
  for _, r in ipairs(roster()) do if r.name == name then level = r.level break end end
  if not level or level >= 60 then return false end
  local prev = L.asks[name]
  local hold = prev and prev.hold or (ns.isOfficer(ns.me()) and 0 or math.random(ns.ASK_HOLD_MIN, ns.ASK_HOLD_MAX))
  L.asks[name] = { at = now(), level = level, first = prev and prev.first or now(), hold = hold }
  if not prev then
    ns.trace("lead", "ask heard", true, ("level %d"):format(level))
    if hold > 0 then C_Timer.After(hold, function() ns.protect(L.UpdateNow, true) end) end
  end
  nowChecked = -math.huge -- show it at the next update
  return true
end

-- Calls anyone made, counted where they're heard (auditor item 3, 13 Nov): a typed call, or another officer's Call
-- button, counts as a call ("c" in WeekOne.lua's nights), and the first answer from each guildmate inside its window
-- counts as an answer ("a"); a call's first answer also counts it as answered ("ca"). The bot gets counts only: the
-- callers' names stay in this session (L.heard), and WeekOne.lua keeps who called or answered on this PC for 7 nights
-- so each person counts once (xo, wo), never shared. This client's own button call was counted when it was pressed,
-- and while it's open its answers count in L.Heard.
L.heard = { calls = {}, answered = {} }
ns.CALL_OWN_ECHO = 10 -- seconds: my own Call line coming back in guild chat
function L.HeardCall(msg, sender)
  if L.rehearse or type(sender) ~= "string" or ns.isSecret(sender) or not ns.IsGroupCall(msg) then return false end
  local name, at = short(sender), now()
  if name == short(ns.me() or "") and L.call and at - L.call.at <= ns.CALL_OWN_ECHO then return false end
  local was = L.heard.calls[name]
  if was and at - was < ns.LEAD_CALL_WINDOW then return true end -- the same call again: counted once
  L.heard.calls[name], L.heard.answered[name] = at, {}
  ns.trace("lead", "call heard", true)
  if ns.WeekOneNight then ns.WeekOneNight("c", sender) end
  return true
end
function L.HeardCallAnswer(msg, sender)
  if L.rehearse or calledRecently() or type(sender) ~= "string" or ns.isSecret(sender) then return false end
  if not ns.IsCallAnswer(msg) then return false end
  local name, at, caller = short(sender), now(), nil
  for who, t in pairs(L.heard.calls) do
    if at - t >= ns.LEAD_CALL_WINDOW then L.heard.calls[who], L.heard.answered[who] = nil, nil
    elseif who ~= name and not L.heard.answered[who][name] and (not caller or t > L.heard.calls[caller]) then
      caller = who
    end
  end
  if not caller then return false end
  local first = next(L.heard.answered[caller]) == nil
  L.heard.answered[caller][name] = true
  if ns.WeekOneNight then
    ns.WeekOneNight("a", sender)
    if first then ns.WeekOneNight("ca", nil, at - L.heard.calls[caller]) end -- the call drew an answer
  end
  return true
end
-- Asks counted (audit section 8, 13 Nov: does an ask draw an answer?). On a helper's client (WeekOne.lua
-- ns.WeekOneHelper), each guildmate's group ask in guild chat counts once per asker per ASK_KEEP ("g" in WeekOne.lua's
-- nights), and once when it is answered inside that window ("ga"): a Call-button line by someone else (on its own that
-- is not a real answer: "gt" below), the asker answering an open call, or the asker joining this client's group. The
-- asker's own call makes their ask moot, not answered (as L.AskAnswered drops it). Nothing the ask button needs matters here (their level, a call open, /uw asks
-- off), and this character's own asks are never counted. Asker names stay in this session, never saved.
-- The window is the ask button's own ASK_KEEP: 30 minutes, longer than a call's 15 (LEAD_CALL_WINDOW), so it needs
-- no floor of its own.
L.openAsks, L.groupNow = {}, {}
local function openAsk(name, at)
  local a = L.openAsks[name]
  if a and at - a.at >= ns.ASK_KEEP then L.openAsks[name], a = nil, nil end
  return a
end
-- An ask answered outside guild chat (auditor C5, 14 Nov 2026): most answers are a whisper or an invite this client
-- never sees, so an ask also counts as answered ("gr") when a roster read finds the asker in a dungeon with a guildmate
-- within ASK_GROUPED of asking (WeekOne.lua calls ns.AsksGrouped at each quarter-hour read). An asker the read before
-- the ask already had in one counts only after a read without. gr counts each ask once, answered either way, so every
-- ga counts in it too. Not a floor; it can overstate (red team, 14 Nov): two guildmates in different groups in the same
-- instance count as together, and an asker already partied with a guildmate (questing as a duo, "lf group wc") who
-- goes in with them counts as answered. It can also miss, as reads come only while a helper plays.
-- L.askWatch[name] = { at, out (not in a dungeon group at the last read), got }; L.inDungeon = the last read
-- ({ at, names }). Names stay in this session, never saved.
-- Followed to the end (gf; auditor C6, 14 Nov 2026): a logout or /reload ends every watch, and Louis's sessions are
-- often shorter than a group takes to form, so an ask counts as followed once it is answered (with gr), its hour has
-- passed, the asker's own call made it moot, or the asker asked again. An ask still under an hour old at logout was
-- cut short (g minus gf), and rule 3 bounds it both ways (people_counts). Rows keep each field's highest across
-- clients, so the officer
-- who followed the most asks decides gf; a count of cut-short asks would let Louis's short sessions decide instead.
-- Taken up (gt; auditor C9 and amendment A8, 15 Nov 2026): any Call-button line marks every open ask but the caller's
-- as answered (ga, gr, gf), whatever dungeon it named, and the Dungeons tab makes that call one click. ga, gr and gf
-- keep their meaning (amendment A1). gt counts each ask once when its asker did something about it: answered an open
-- call ("inv", "+"), joined this client's group, or was read in a dungeon with a guildmate, within the ask's hour and
-- on the ask's night, before or after a button call closed it. So every gt ask is in gr, and gr minus gt is the asks
-- that only a button call closed, which rule 3 reads both ways (people_counts). The real answers are what is counted,
-- not the button-only ones, because rows keep each field's highest across clients: a client on a build without gt
-- then adds nothing, where a count of button-only asks would be too low and so overstate real answers.
-- An ask its asker's own call made moot is never in gt, whether a button call closed it first or not.
-- w.called: a button call closed it; w.real: counted in gt; w.moot: its asker called, so never in gt.
ns.ASK_GROUPED, ns.ASK_READ_FRESH = 3600, 1800
L.askWatch, L.inDungeon = {}, nil
local function askDone(w, at) -- followed to the end without an answer: its hour passed, or its asker called
  if w.got then return end
  w.got = true
  -- Over a day old (a long session whose roster reads stopped; red team, 15 Nov 2026): WeekOneNight places a late
  -- count at most a day back, so this gf would land on a later night than its ask and could pass that night's g,
  -- and a row that doesn't add up is refused whole. Left out: the ask reads as cut short, which rule 3 bounds.
  if ns.WeekOneNight and at - w.at <= 86400 then ns.WeekOneNight("gf", nil, at - w.at) end
end
local function askReal(w, at) -- its asker took it up: answered some other way than a button call alone
  if w.real or w.moot then return end
  w.real = true
  if ns.WeekOneNight then ns.WeekOneNight("gt", nil, at - w.at) end
end
local function watchAsk(name, at)
  for who, w in pairs(L.askWatch) do
    if at - w.at > ns.ASK_GROUPED then askDone(w, at) L.askWatch[who] = nil end
  end
  local last = L.inDungeon
  local inside = last and at - last.at <= ns.ASK_READ_FRESH and last.names[name]
  if L.askWatch[name] then askDone(L.askWatch[name], at) end -- asking again ends the last ask, unanswered (red team)
  L.askWatch[name] = { at = at, out = not inside }
end
local function askGot(name, at, since)
  local w = L.askWatch[name]
  if not w or w.got or w.at ~= since then return end
  w.got = true
  if ns.WeekOneNight then -- on the ask's night, like ga; answered is followed to the end too
    ns.WeekOneNight("gr", nil, at - w.at)
    ns.WeekOneNight("gf", nil, at - w.at)
  end
end
-- byCall: a button call closed it, nothing the asker did. Counted as answered all the same (ga, gr, gf).
local function askAnswered(name, at, byCall)
  local a = openAsk(name, at)
  if not a or a.done then return false end
  a.done = true
  if ns.WeekOneNight then ns.WeekOneNight("ga", nil, at - a.at) end -- counted on the ask's night
  local w = L.askWatch[name]
  if w and w.at ~= a.at then w = nil end
  if w and byCall and not w.got then w.called = true end -- got already: a dungeon read was first
  askGot(name, at, a.at)
  if w and not byCall then askReal(w, at) end
  return true
end
-- The asker took up a call after a button call had closed their ask: a real answer, counted once (gt).
local function askTakenUp(name, at)
  local w = L.askWatch[name]
  if w and w.called and at - w.at <= ns.ASK_GROUPED then askReal(w, at) end
end
local function callOpenFor(name, at)
  if calledRecently() then return true end
  for who, t in pairs(L.heard.calls) do if who ~= name and at - t < ns.LEAD_CALL_WINDOW then return true end end
  return false
end
local function counting()
  -- helpers, and on the bot's PC whichever character Louis plays (WeekOne.lua measures)
  return not L.rehearse and type(UW_GuildDB) == "table" and ns.WeekOneMeasures ~= nil and ns.WeekOneMeasures()
end
L.maybeAt = {} -- this session only: when each writer's last maybe ask counted (once per ASK_KEEP, like an ask)
L.startAt = {} -- this session only: when each writer's last started group counted (gs, once per ASK_KEEP)
function L.CountAsk(msg, sender)
  if type(msg) ~= "string" or ns.isSecret(msg) or type(sender) ~= "string" or ns.isSecret(sender) then return end
  if not counting() then return end
  local name, at, kind = short(sender), now(), ns.ReadAsk(msg)
  if kind == "call" then
    if CALL_OPENS ~= "" and strtrim(msg):lower():sub(1, #CALL_OPENS) == CALL_OPENS then -- the Call button's line
      for who in pairs(L.openAsks) do if who ~= name then askAnswered(who, at, true) end end
    end
    local mine = openAsk(name, at)
    if mine then -- their own call makes the ask moot: never counted as answered, in a reply or a dungeon
      mine.done = true
      local w = L.askWatch[name]
      -- moot stays on the watch: a button call may have closed the ask already (ga, gr, gf), and nothing the asker
      -- does after their own call is a take-up of it (integrator, 15 Nov 2026)
      if w and w.at == mine.at then w.moot = true askDone(w, at) end
    end
  elseif kind == "ask" then
    if name ~= short(ns.me() or "") and not openAsk(name, at) then
      for who in pairs(L.openAsks) do openAsk(who, at) end -- past their window: gone from the session too
      L.openAsks[name] = { at = at }
      if ns.WeekOneNight then ns.WeekOneNight("g") end
      watchAsk(name, at)
    end
  elseif (openAsk(name, at) or (L.askWatch[name] or {}).called) and callOpenFor(name, at) and ns.IsCallAnswer(msg) then
    if not askAnswered(name, at) then askTakenUp(name, at) end
  elseif kind == nil and name ~= short(ns.me() or "") and ns.MaybeAsk(msg) then
    local last = L.maybeAt[name]
    if not last or at - last >= ns.ASK_KEEP then
      L.maybeAt[name] = at
      if ns.WeekOneNight then ns.WeekOneNight("mg") end
    end
  end
  -- A group a guildmate started without a call (auditor, 14 Nov): a fill or a start, Louis's own left out, once per
  -- writer per ASK_KEEP like a maybe ask. Counted only (WeekOne.lua gs).
  if (kind == "fill" or kind == "start") and not ns.IsLouis(sender) then
    local last = L.startAt[name]
    if not last or at - last >= ns.ASK_KEEP then
      L.startAt[name] = at
      if ns.WeekOneNight then ns.WeekOneNight("gs", sender) end -- counts them in xo/wo too
    end
  end
end
-- A roster read (WeekOne.lua ns.WeekOneSample, byZone = { [instance zone] = { names } }): an asker in a dungeon with a
-- guildmate within ASK_GROUPED of asking was answered (gr). Times are this file's now(), as the ask's.
function ns.AsksGrouped(byZone)
  local at, inside = now(), {}
  for _, list in pairs(type(byZone) == "table" and byZone or {}) do
    if type(list) == "table" and #list >= 2 then for _, n in ipairs(list) do inside[n] = true end end
  end
  L.inDungeon = { at = at, names = inside }
  if not counting() then return end
  for name, w in pairs(L.askWatch) do
    if at - w.at > ns.ASK_GROUPED then askDone(w, at) L.askWatch[name] = nil
    elseif not inside[name] then w.out = true
    elseif w.out then
      local real = w.called or not w.got -- not an ask its hour or its asker's own call already ended
      askGot(name, at, w.at)
      if real then askReal(w, at) end
    end
  end
end
-- At logout or /reload (PLAYER_LOGOUT, just before WoW writes the save): an ask past its hour was followed to the end;
-- one under it was cut short and stays out of gf. One a button call closed is already in gf, and stays out of gt
-- unless its asker took it up before now.
function L.AsksAtLogout()
  local at = now()
  for _, w in pairs(L.askWatch) do
    if at - w.at > ns.ASK_GROUPED then askDone(w, at) end
  end
end
-- Guildmates newly in this client's group (L.groupNow: who was in it at the last change): an asker among them was
-- answered. Someone already in the group when they asked isn't a join.
function L.CountAskJoins()
  local at, raid, was, count = now(), IsInRaid(), L.groupNow, counting()
  L.groupNow = {}
  if not IsInGroup() then return end
  for i = 1, raid and GetNumGroupMembers() or math.max(0, GetNumGroupMembers() - 1) do
    local unit = (raid and "raid" or "party") .. i
    local full = ns.unitFull(unit)
    if full and UnitIsInMyGuild(unit) and not UnitIsUnit(unit, "player") then
      local name = short(full)
      L.groupNow[name] = true
      if count and not was[name] and not askAnswered(name, at) then askTakenUp(name, at) end
    end
  end
end
local heardFrame = CreateFrame("Frame")
ns.listen(heardFrame, { "CHAT_MSG_GUILD", "GROUP_ROSTER_UPDATE", "PLAYER_LOGOUT" })
heardFrame:SetScript("OnEvent", ns.guard(function(_, event, msg, sender)
  if event == "GROUP_ROSTER_UPDATE" then L.CountAskJoins() return end
  if event == "PLAYER_LOGOUT" then L.AsksAtLogout() return end
  if not (L.HeardCall(msg, sender)) then L.HeardCallAnswer(msg, sender) end
  L.CountAsk(msg, sender)
end))

-- The newest ask still fresh, as { name, level, what } (the band around their level), or nil. ready: only asks
-- past their hold.
function L.NewestAsk(ready)
  local best
  for name, a in pairs(L.asks) do
    local holding = ready and now() - (a.first or a.at) < (a.hold or 0)
    if now() - a.at > ns.ASK_KEEP then L.asks[name] = nil
    elseif not holding and (not best or a.at > best.at) then best = { name = name, at = a.at, level = a.level } end
  end
  if not best then return nil end
  local lo = math.max(1, math.min(best.level - 2, 56)) -- never past 60
  best.what = ("levels %d-%d"):format(lo, lo + 4)
  return best
end

-- What the button would offer now: { kind = "ask" | "call" | "welcome", n, label }, or nil.
function L.NowAction()
  if L.rehearse or calledRecently() then return nil end
  local isOfficer = officer()
  local ask = L.HearsAsks() and L.NewestAsk(not isOfficer)
  if ask then
    return { kind = "ask", n = 1, what = ask.what, at = ask.at, name = ask.name, level = ask.level,
      label = ("%s asked for a group (%d): call one"):format(ask.name:match("^(%S+)") or ask.name, ask.level) }
  end
  if not isOfficer then return nil end -- the suggested call and welcomes stay officers' work
  local s = not (nowCallDone or L.call) and L.Suggest()
  if s and s.n >= ns.NOW_CALL_AT_LEAST then
    return { kind = "call", n = s.n, label = ("%d newcomers for %s: call a group"):format(s.n, s.name) }
  end
  -- /uw discord ask is retired (Louis, 9 Nov 02:39): while its sender is off, this never suggests it.
  local todo = (not UW_GuildDB.discordAskOff and ns.DiscordToAsk and ns.ChatOn("discord.ask")) and ns.DiscordToAsk(true)
    or {}
  if #todo >= ns.NOW_WELCOME_AT_LEAST then
    local n = math.min(#todo, ns.DISCORD_ASK_RUN or 25)
    return { kind = "welcome", n = n, label = ("Welcome %d guildmate%s online"):format(n, n == 1 and "" or "s") }
  end
  return nil
end

function L.NowClick(which)
  local a = L.nowAction
  if which == "RightButton" then
    nowHidden = true
    say("Hidden until your next login. /uw lead call still works.")
  elseif which == "close" then
    -- The notice's close mark (design spec section 8, 15 Nov 2026): the one showing is set aside, nothing more and
    -- nothing said. An ask leaves the list, so an older one still waiting shows next and a new one shows when it
    -- comes: a close mark is clicked far more than a right-click, and one click must not hide every later ask.
    -- What was last answered (nowAskSeen) stays as it was, so inside the half hour after a call an older ask still
    -- waiting counts as news the same way. The suggested call has had its showing.
    if a then
      ns.trace("lead", "now close", true, a.kind)
      if a.kind == "ask" then
        L.asks[a.name] = nil
      elseif a.kind == "call" then
        nowCallDone = true
      else
        nowSnoozed = now() + ns.NOW_SNOOZE
      end
    end
  elseif a then
    nowSnoozed = now() + ns.NOW_SNOOZE
    ns.trace("lead", "now " .. a.kind, true, ("%d"):format(a.n))
    if a.kind == "ask" then
      L.asks, nowAskSeen = {}, a.at
      if L.OpenTab("call", true) then
        L.what = a.what
        L.forAsk = { name = a.name:match("^(%S+)") or a.name, what = a.what, at = now() }
        if frame and frame.input then frame.input:SetText(a.what) end
      end
    elseif a.kind == "call" then
      nowCallDone = true
      if L.OpenTab("call", true) then L.UseSuggestion() end
    elseif ns.commands.discord then
      ns.commands.discord("ask")
    end
  end
  L.UpdateNow(true)
end

-- The notice's picture (Skin.lua, the bar above chat): an ask's is the asker's class, from the roster; the suggested
-- call keeps Call a group's (the bar's own for this button), the welcome has Discord's. Returns a row, a class.
function L.NowIcon(a)
  if a.kind == "ask" then
    for _, r in ipairs(roster()) do if r.name == a.name then return nil, r.cls end end
  elseif a.kind == "welcome" then
    local all = ns.HANDBOOK_ICONS
    return type(all) == "table" and type(all.entry) == "table" and all.entry.discord or nil
  end
end

-- Shows, relabels or hides the button. force: skip the NOW_EVERY throttle. Returns the action shown, or nil.
function L.UpdateNow(force)
  if not force and GetTime() - nowChecked < ns.NOW_EVERY then return L.nowAction end
  nowChecked = GetTime()
  -- A new ask is news: it shows even inside the 30 min after a click.
  local fresh = L.NewestAsk()
  local awake = now() >= nowSnoozed or (fresh and fresh.at > nowAskSeen)
  local a = not nowHidden and awake and not InCombatLockdown() and not inInstance() and L.NowAction()
  if a and a.kind == "call" then
    nowCallSince = nowCallSince or now()
    if now() - nowCallSince >= ns.NOW_CALL_SHOW then
      nowCallDone = true -- before asking again: a multiple assignment would ask first
      a = L.NowAction()
    end
  end
  if not a then
    L.nowAction = nil
    if nowButton then nowButton:Hide() end
    return nil
  end
  if not nowButton then
    -- A plain button: the bar above chat draws it as a notice (Skin.lua). It is the one about people, so it has
    -- a close mark.
    nowButton = CreateFrame("Button", "UWGuildLeadNow", UIParent)
    nowButton:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    nowButton:SetScript("OnClick", function(_, which) ns.protect(L.NowClick, which) end)
    ns.useButton(nowButton, "lead now")
    nowButton.uwClose = function() L.NowClick("close") end
    L.nowButton = nowButton
    ns.ChatBarAdd("lead now", nowButton, 10) -- first on the bar
  end
  L.nowAction, nowButton.label = a, a.label
  nowButton.uwIcon, nowButton.uwClass = L.NowIcon(a)
  nowButton:Show()
  -- /uw hide hides the bar and this button with it, so a guildmate waiting in guild chat would reach nobody (journey
  -- re-walk on 112, 13 Nov: a no-addon newcomer's /g ask is their only way to a first dungeon). One chat line per ask
  -- instead, on this officer's screen only; /uw lead call then sets up the call for their level (Call still sends).
  if a.kind == "ask" and ns.ChatBarHidden and ns.ChatBarHidden() and a.at ~= nowAskTold then
    nowAskTold = a.at
    say(("%s asked for a group in guild chat (level %d). /uw lead call sets up a call for their level.")
      :format(a.name:match("^(%S+)") or a.name, a.level))
  end
  ns.ChatBarText(nowButton, a.label)
  return a
end

local nowFrame = CreateFrame("Frame")
ns.listen(nowFrame, { "GUILD_ROSTER_UPDATE", "PLAYER_REGEN_ENABLED", "PLAYER_REGEN_DISABLED", "PLAYER_ENTERING_WORLD" })
nowFrame:SetScript("OnEvent", ns.guard(function(_, event)
  if not (UW_GuildDB and ns.inOurGuild and ns.inOurGuild()) then return end
  if event == "GUILD_ROSTER_UPDATE" or event == "PLAYER_ENTERING_WORLD" then ns.protect(L.TellAsks) end
  ns.protect(L.UpdateNow, event ~= "GUILD_ROSTER_UPDATE")
end))
